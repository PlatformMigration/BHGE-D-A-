
package og_applications.j_x_man_finance_lagtime_0_1;

import routines.MyRoutineDemo;
import routines.TalendDataGenerator;
import routines.GEDynamicRoutine_masking;
import routines.GetRandomPhoneNum;
import routines.DataTypeMaps;
import routines.insertTimeToDate;
import routines.Numeric;
import routines.TransformMetadata;
import routines.DQTechnical;
import routines.MDM;
import routines.DemoRoutines;
import routines.GPLoadRoutine;
import routines.GEPostgreSQLViewConverter;
import routines.DataOperation;
import routines.GEDynamicRoutine;
import routines.DataQuality;
import routines.Relational;
import routines.GEroutines;
import routines.DataQualityDependencies;
import routines.Mathematical;
import routines.SQLike;
import routines.TalendString;
import routines.StringHandling;
import routines.DataMasking;
import routines.TalendDate;
import routines.DqStringHandling;
import routines.KeyManagementForSqoop;
import routines.PopulateFromDynamic;
import routines.system.*;
import routines.system.api.*;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.math.BigDecimal;
import java.io.ByteArrayOutputStream;
import java.io.ByteArrayInputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.ObjectOutputStream;
import java.io.ObjectInputStream;
import java.io.IOException;
import java.util.Comparator;
 




	//the import part of tJavaRow_1
	//import java.util.List;

	//the import part of tJavaRow_2
	//import java.util.List;


@SuppressWarnings("unused")

/**
 * Job: J_X_MAN_FINANCE_LAGTIME Purpose: J_X_MAN_FINANCE_LAGTIME<br>
 * Description: J_X_MAN_FINANCE_LAGTIME <br>
 * @author Nandi, Dytiman
 * @version 6.3.1.20161216_1026
 * @status 
 */
public class J_X_MAN_FINANCE_LAGTIME implements TalendJob {
	static {System.setProperty("TalendJob.log", "J_X_MAN_FINANCE_LAGTIME.log");}
	private static org.apache.log4j.Logger log = org.apache.log4j.Logger.getLogger(J_X_MAN_FINANCE_LAGTIME.class);



	public final Object obj = new Object();

	// for transmiting parameters purpose
	private Object valueObject = null;

	public Object getValueObject() {
		return this.valueObject;
	}

	public void setValueObject(Object valueObject) {
		this.valueObject = valueObject;
	}
	
	private final static String defaultCharset = java.nio.charset.Charset.defaultCharset().name();

	
	private final static String utf8Charset = "UTF-8";

	// create and load default properties
	private java.util.Properties defaultProps = new java.util.Properties();
	// create application properties with default
	public class ContextProperties extends java.util.Properties {

		private static final long serialVersionUID = 1L;

		public ContextProperties(java.util.Properties properties){
			super(properties);
		}
		public ContextProperties(){
			super();
		}

		public void synchronizeContext(){
			
			if(aws_gp_prof_Login != null){
				
					this.setProperty("aws_gp_prof_Login", aws_gp_prof_Login.toString());
				
			}
			
			if(aws_gp_prof_Password != null){
				
					this.setProperty("aws_gp_prof_Password", aws_gp_prof_Password.toString());
				
			}
			
			if(aws_gp_prof_Schema != null){
				
					this.setProperty("aws_gp_prof_Schema", aws_gp_prof_Schema.toString());
				
			}
			
			if(aws_gp_prof_Server != null){
				
					this.setProperty("aws_gp_prof_Server", aws_gp_prof_Server.toString());
				
			}
			
			if(aws_gp_prof_Database != null){
				
					this.setProperty("aws_gp_prof_Database", aws_gp_prof_Database.toString());
				
			}
			
			if(aws_gp_prof_Port != null){
				
					this.setProperty("aws_gp_prof_Port", aws_gp_prof_Port.toString());
				
			}
			
			if(mail != null){
				
					this.setProperty("mail", mail.toString());
				
			}
			
			if(master_job != null){
				
					this.setProperty("master_job", master_job.toString());
				
			}
			
			if(TABLE != null){
				
					this.setProperty("TABLE", TABLE.toString());
				
			}
			
			if(Table2 != null){
				
					this.setProperty("Table2", Table2.toString());
				
			}
			
			if(SAP_QA1_Host != null){
				
					this.setProperty("SAP_QA1_Host", SAP_QA1_Host.toString());
				
			}
			
			if(SAP_QA1_Language != null){
				
					this.setProperty("SAP_QA1_Language", SAP_QA1_Language.toString());
				
			}
			
			if(SAP_QA1_Password != null){
				
					this.setProperty("SAP_QA1_Password", SAP_QA1_Password.toString());
				
			}
			
			if(SAP_QA1_Client != null){
				
					this.setProperty("SAP_QA1_Client", SAP_QA1_Client.toString());
				
			}
			
			if(SAP_QA1_SystemNumber != null){
				
					this.setProperty("SAP_QA1_SystemNumber", SAP_QA1_SystemNumber.toString());
				
			}
			
			if(SAP_QA1_UserName != null){
				
					this.setProperty("SAP_QA1_UserName", SAP_QA1_UserName.toString());
				
			}
			
			if(api_use_z_talend_read_table != null){
				
					this.setProperty("api_use_z_talend_read_table", api_use_z_talend_read_table.toString());
				
			}
			
		}

public String aws_gp_prof_Login;
public String getAws_gp_prof_Login(){
	return this.aws_gp_prof_Login;
}
public java.lang.String aws_gp_prof_Password;
public java.lang.String getAws_gp_prof_Password(){
	return this.aws_gp_prof_Password;
}
public String aws_gp_prof_Schema;
public String getAws_gp_prof_Schema(){
	return this.aws_gp_prof_Schema;
}
public String aws_gp_prof_Server;
public String getAws_gp_prof_Server(){
	return this.aws_gp_prof_Server;
}
public String aws_gp_prof_Database;
public String getAws_gp_prof_Database(){
	return this.aws_gp_prof_Database;
}
public String aws_gp_prof_Port;
public String getAws_gp_prof_Port(){
	return this.aws_gp_prof_Port;
}
public String mail;
public String getMail(){
	return this.mail;
}
public String master_job;
public String getMaster_job(){
	return this.master_job;
}
public String TABLE;
public String getTABLE(){
	return this.TABLE;
}
public String Table2;
public String getTable2(){
	return this.Table2;
}
public String SAP_QA1_Host;
public String getSAP_QA1_Host(){
	return this.SAP_QA1_Host;
}
public String SAP_QA1_Language;
public String getSAP_QA1_Language(){
	return this.SAP_QA1_Language;
}
public java.lang.String SAP_QA1_Password;
public java.lang.String getSAP_QA1_Password(){
	return this.SAP_QA1_Password;
}
public String SAP_QA1_Client;
public String getSAP_QA1_Client(){
	return this.SAP_QA1_Client;
}
public String SAP_QA1_SystemNumber;
public String getSAP_QA1_SystemNumber(){
	return this.SAP_QA1_SystemNumber;
}
public String SAP_QA1_UserName;
public String getSAP_QA1_UserName(){
	return this.SAP_QA1_UserName;
}
public String api_use_z_talend_read_table;
public String getApi_use_z_talend_read_table(){
	return this.api_use_z_talend_read_table;
}
	}
	private ContextProperties context = new ContextProperties();
	public ContextProperties getContext() {
		return this.context;
	}
	private final String jobVersion = "0.1";
	private final String jobName = "J_X_MAN_FINANCE_LAGTIME";
	private final String projectName = "OG_APPLICATIONS";
	public Integer errorCode = null;
	private String currentComponent = "";
	
		private final java.util.Map<String, Object> globalMap = new java.util.HashMap<String, Object>();
        private final static java.util.Map<String, Object> junitGlobalMap = new java.util.HashMap<String, Object>();
	
		private final java.util.Map<String, Long> start_Hash = new java.util.HashMap<String, Long>();
		private final java.util.Map<String, Long> end_Hash = new java.util.HashMap<String, Long>();
		private final java.util.Map<String, Boolean> ok_Hash = new java.util.HashMap<String, Boolean>();
		public  final java.util.List<String[]> globalBuffer = new java.util.ArrayList<String[]>();
	

private RunStat runStat = new RunStat();

	// OSGi DataSource
	private final static String KEY_DB_DATASOURCES = "KEY_DB_DATASOURCES";

	public void setDataSources(java.util.Map<String, javax.sql.DataSource> dataSources) {
		java.util.Map<String, routines.system.TalendDataSource> talendDataSources = new java.util.HashMap<String, routines.system.TalendDataSource>();
		for (java.util.Map.Entry<String, javax.sql.DataSource> dataSourceEntry : dataSources.entrySet()) {
			talendDataSources.put(dataSourceEntry.getKey(), new routines.system.TalendDataSource(dataSourceEntry.getValue()));
		}
		globalMap.put(KEY_DB_DATASOURCES, talendDataSources);
	}

	LogCatcherUtils tLogCatcher_1 = new LogCatcherUtils();
	MetterCatcherUtils tFlowMeterCatcher_1 = new MetterCatcherUtils("_buT2YLCIEeiDgInc6Dzt-w", "0.1");

private final java.io.ByteArrayOutputStream baos = new java.io.ByteArrayOutputStream();
private final java.io.PrintStream errorMessagePS = new java.io.PrintStream(new java.io.BufferedOutputStream(baos));

public String getExceptionStackTrace() {
	if ("failure".equals(this.getStatus())) {
		errorMessagePS.flush();
		return baos.toString();
	}
	return null;
}

private Exception exception;

public Exception getException() {
	if ("failure".equals(this.getStatus())) {
		return this.exception;
	}
	return null;
}

private class TalendException extends Exception {

	private static final long serialVersionUID = 1L;

	private java.util.Map<String, Object> globalMap = null;
	private Exception e = null;
	private String currentComponent = null;
	private String virtualComponentName = null;
	
	public void setVirtualComponentName (String virtualComponentName){
		this.virtualComponentName = virtualComponentName;
	}

	private TalendException(Exception e, String errorComponent, final java.util.Map<String, Object> globalMap) {
		this.currentComponent= errorComponent;
		this.globalMap = globalMap;
		this.e = e;
	}

	public Exception getException() {
		return this.e;
	}

	public String getCurrentComponent() {
		return this.currentComponent;
	}

	
    public String getExceptionCauseMessage(Exception e){
        Throwable cause = e;
        String message = null;
        int i = 10;
        while (null != cause && 0 < i--) {
            message = cause.getMessage();
            if (null == message) {
                cause = cause.getCause();
            } else {
                break;          
            }
        }
        if (null == message) {
            message = e.getClass().getName();
        }   
        return message;
    }

	@Override
	public void printStackTrace() {
		if (!(e instanceof TalendException || e instanceof TDieException)) {
			if(virtualComponentName!=null && currentComponent.indexOf(virtualComponentName+"_")==0){
				globalMap.put(virtualComponentName+"_ERROR_MESSAGE",getExceptionCauseMessage(e));
			}
			 globalMap.put(currentComponent+"_ERROR_MESSAGE",getExceptionCauseMessage(e));
			System.err.println("Exception in component " + currentComponent);
		}
		if (!(e instanceof TDieException)) {
			if(e instanceof TalendException){
				e.printStackTrace();
			} else {
				e.printStackTrace();
				e.printStackTrace(errorMessagePS);
				J_X_MAN_FINANCE_LAGTIME.this.exception = e;
			}
		}
		if (!(e instanceof TalendException)) {
		try {
			for (java.lang.reflect.Method m : this.getClass().getEnclosingClass().getMethods()) {
				if (m.getName().compareTo(currentComponent + "_error") == 0) {
					m.invoke(J_X_MAN_FINANCE_LAGTIME.this, new Object[] { e , currentComponent, globalMap});
					break;
				}
			}

			if(!(e instanceof TDieException)){
				tLogCatcher_1.addMessage("Java Exception", currentComponent, 6, e.getClass().getName() + ":" + e.getMessage(), 1);
				tLogCatcher_1Process(globalMap);
			}
				} catch (TalendException e) {
					// do nothing
				
		} catch (Exception e) {
			this.e.printStackTrace();
		}
		}
	}
}

			public void tFlowMeterCatcher_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tFlowMeterCatcher_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tMap_2_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tFlowMeterCatcher_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tPostgresqlOutput_2_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tFlowMeterCatcher_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tLogRow_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tFlowMeterCatcher_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tJavaRow_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tFlowMeterCatcher_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tLogRow_2_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tFlowMeterCatcher_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tSendMail_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tSendMail_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tLogCatcher_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tLogCatcher_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tLogRow_3_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tLogCatcher_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tMap_3_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tLogCatcher_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tPostgresqlOutput_3_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tLogCatcher_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tLogRow_4_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tLogCatcher_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tJavaRow_2_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tLogCatcher_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tSendMail_2_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tLogCatcher_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tSAPTableInput_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tSAPTableInput_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tFlowMeter_16_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tSAPTableInput_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tMap_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tSAPTableInput_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tPostgresqlOutput_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tSAPTableInput_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tPrejob_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tPrejob_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tPostgresqlInput_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tPostgresqlInput_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tSetGlobalVar_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tPostgresqlInput_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tFlowMeterCatcher_1_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tSendMail_1_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tLogCatcher_1_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tSAPTableInput_1_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tPrejob_1_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tPostgresqlInput_1_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			









public static class row9Struct implements routines.system.IPersistableRow<row9Struct> {
    final static byte[] commonByteArrayLock_OG_APPLICATIONS_J_X_MAN_FINANCE_LAGTIME = new byte[0];
    static byte[] commonByteArray_OG_APPLICATIONS_J_X_MAN_FINANCE_LAGTIME = new byte[0];

	



    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_OG_APPLICATIONS_J_X_MAN_FINANCE_LAGTIME) {

        	try {

        		int length = 0;
		

		

        }

		
			finally {}
		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
        }

			finally {}
		

    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(row9Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public static class row8Struct implements routines.system.IPersistableRow<row8Struct> {
    final static byte[] commonByteArrayLock_OG_APPLICATIONS_J_X_MAN_FINANCE_LAGTIME = new byte[0];
    static byte[] commonByteArray_OG_APPLICATIONS_J_X_MAN_FINANCE_LAGTIME = new byte[0];

	
			    public String job_name;

				public String getJob_name () {
					return this.job_name;
				}
				
			    public java.util.Date start_time;

				public java.util.Date getStart_time () {
					return this.start_time;
				}
				
			    public java.util.Date end_time;

				public java.util.Date getEnd_time () {
					return this.end_time;
				}
				
			    public String source_table_name;

				public String getSource_table_name () {
					return this.source_table_name;
				}
				
			    public Integer source_count;

				public Integer getSource_count () {
					return this.source_count;
				}
				
			    public String target_table_name;

				public String getTarget_table_name () {
					return this.target_table_name;
				}
				
			    public Integer target_count;

				public Integer getTarget_count () {
					return this.target_count;
				}
				
			    public String flag;

				public String getFlag () {
					return this.flag;
				}
				
			    public String sub_job;

				public String getSub_job () {
					return this.sub_job;
				}
				



	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_OG_APPLICATIONS_J_X_MAN_FINANCE_LAGTIME.length) {
				if(length < 1024 && commonByteArray_OG_APPLICATIONS_J_X_MAN_FINANCE_LAGTIME.length == 0) {
   					commonByteArray_OG_APPLICATIONS_J_X_MAN_FINANCE_LAGTIME = new byte[1024];
				} else {
   					commonByteArray_OG_APPLICATIONS_J_X_MAN_FINANCE_LAGTIME = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_OG_APPLICATIONS_J_X_MAN_FINANCE_LAGTIME, 0, length);
			strReturn = new String(commonByteArray_OG_APPLICATIONS_J_X_MAN_FINANCE_LAGTIME, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }

	private java.util.Date readDate(ObjectInputStream dis) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(dis.readLong());
		}
		return dateReturn;
	}

    private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException{
		if(date1 == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeLong(date1.getTime());
    	}
    }
	private Integer readInteger(ObjectInputStream dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}

	private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException{
		if(intNum == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeInt(intNum);
    	}
	}

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_OG_APPLICATIONS_J_X_MAN_FINANCE_LAGTIME) {

        	try {

        		int length = 0;
		
					this.job_name = readString(dis);
					
					this.start_time = readDate(dis);
					
					this.end_time = readDate(dis);
					
					this.source_table_name = readString(dis);
					
						this.source_count = readInteger(dis);
					
					this.target_table_name = readString(dis);
					
						this.target_count = readInteger(dis);
					
					this.flag = readString(dis);
					
					this.sub_job = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// String
				
						writeString(this.job_name,dos);
					
					// java.util.Date
				
						writeDate(this.start_time,dos);
					
					// java.util.Date
				
						writeDate(this.end_time,dos);
					
					// String
				
						writeString(this.source_table_name,dos);
					
					// Integer
				
						writeInteger(this.source_count,dos);
					
					// String
				
						writeString(this.target_table_name,dos);
					
					// Integer
				
						writeInteger(this.target_count,dos);
					
					// String
				
						writeString(this.flag,dos);
					
					// String
				
						writeString(this.sub_job,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("job_name="+job_name);
		sb.append(",start_time="+String.valueOf(start_time));
		sb.append(",end_time="+String.valueOf(end_time));
		sb.append(",source_table_name="+source_table_name);
		sb.append(",source_count="+String.valueOf(source_count));
		sb.append(",target_table_name="+target_table_name);
		sb.append(",target_count="+String.valueOf(target_count));
		sb.append(",flag="+flag);
		sb.append(",sub_job="+sub_job);
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				if(job_name == null){
        					sb.append("<null>");
        				}else{
            				sb.append(job_name);
            			}
            		
        			sb.append("|");
        		
        				if(start_time == null){
        					sb.append("<null>");
        				}else{
            				sb.append(start_time);
            			}
            		
        			sb.append("|");
        		
        				if(end_time == null){
        					sb.append("<null>");
        				}else{
            				sb.append(end_time);
            			}
            		
        			sb.append("|");
        		
        				if(source_table_name == null){
        					sb.append("<null>");
        				}else{
            				sb.append(source_table_name);
            			}
            		
        			sb.append("|");
        		
        				if(source_count == null){
        					sb.append("<null>");
        				}else{
            				sb.append(source_count);
            			}
            		
        			sb.append("|");
        		
        				if(target_table_name == null){
        					sb.append("<null>");
        				}else{
            				sb.append(target_table_name);
            			}
            		
        			sb.append("|");
        		
        				if(target_count == null){
        					sb.append("<null>");
        				}else{
            				sb.append(target_count);
            			}
            		
        			sb.append("|");
        		
        				if(flag == null){
        					sb.append("<null>");
        				}else{
            				sb.append(flag);
            			}
            		
        			sb.append("|");
        		
        				if(sub_job == null){
        					sb.append("<null>");
        				}else{
            				sb.append(sub_job);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(row8Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public static class row7Struct implements routines.system.IPersistableRow<row7Struct> {
    final static byte[] commonByteArrayLock_OG_APPLICATIONS_J_X_MAN_FINANCE_LAGTIME = new byte[0];
    static byte[] commonByteArray_OG_APPLICATIONS_J_X_MAN_FINANCE_LAGTIME = new byte[0];

	
			    public String job_name;

				public String getJob_name () {
					return this.job_name;
				}
				
			    public java.util.Date start_time;

				public java.util.Date getStart_time () {
					return this.start_time;
				}
				
			    public java.util.Date end_time;

				public java.util.Date getEnd_time () {
					return this.end_time;
				}
				
			    public String source_table_name;

				public String getSource_table_name () {
					return this.source_table_name;
				}
				
			    public Integer source_count;

				public Integer getSource_count () {
					return this.source_count;
				}
				
			    public String target_table_name;

				public String getTarget_table_name () {
					return this.target_table_name;
				}
				
			    public Integer target_count;

				public Integer getTarget_count () {
					return this.target_count;
				}
				
			    public String flag;

				public String getFlag () {
					return this.flag;
				}
				
			    public String sub_job;

				public String getSub_job () {
					return this.sub_job;
				}
				



	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_OG_APPLICATIONS_J_X_MAN_FINANCE_LAGTIME.length) {
				if(length < 1024 && commonByteArray_OG_APPLICATIONS_J_X_MAN_FINANCE_LAGTIME.length == 0) {
   					commonByteArray_OG_APPLICATIONS_J_X_MAN_FINANCE_LAGTIME = new byte[1024];
				} else {
   					commonByteArray_OG_APPLICATIONS_J_X_MAN_FINANCE_LAGTIME = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_OG_APPLICATIONS_J_X_MAN_FINANCE_LAGTIME, 0, length);
			strReturn = new String(commonByteArray_OG_APPLICATIONS_J_X_MAN_FINANCE_LAGTIME, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }

	private java.util.Date readDate(ObjectInputStream dis) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(dis.readLong());
		}
		return dateReturn;
	}

    private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException{
		if(date1 == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeLong(date1.getTime());
    	}
    }
	private Integer readInteger(ObjectInputStream dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}

	private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException{
		if(intNum == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeInt(intNum);
    	}
	}

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_OG_APPLICATIONS_J_X_MAN_FINANCE_LAGTIME) {

        	try {

        		int length = 0;
		
					this.job_name = readString(dis);
					
					this.start_time = readDate(dis);
					
					this.end_time = readDate(dis);
					
					this.source_table_name = readString(dis);
					
						this.source_count = readInteger(dis);
					
					this.target_table_name = readString(dis);
					
						this.target_count = readInteger(dis);
					
					this.flag = readString(dis);
					
					this.sub_job = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// String
				
						writeString(this.job_name,dos);
					
					// java.util.Date
				
						writeDate(this.start_time,dos);
					
					// java.util.Date
				
						writeDate(this.end_time,dos);
					
					// String
				
						writeString(this.source_table_name,dos);
					
					// Integer
				
						writeInteger(this.source_count,dos);
					
					// String
				
						writeString(this.target_table_name,dos);
					
					// Integer
				
						writeInteger(this.target_count,dos);
					
					// String
				
						writeString(this.flag,dos);
					
					// String
				
						writeString(this.sub_job,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("job_name="+job_name);
		sb.append(",start_time="+String.valueOf(start_time));
		sb.append(",end_time="+String.valueOf(end_time));
		sb.append(",source_table_name="+source_table_name);
		sb.append(",source_count="+String.valueOf(source_count));
		sb.append(",target_table_name="+target_table_name);
		sb.append(",target_count="+String.valueOf(target_count));
		sb.append(",flag="+flag);
		sb.append(",sub_job="+sub_job);
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				if(job_name == null){
        					sb.append("<null>");
        				}else{
            				sb.append(job_name);
            			}
            		
        			sb.append("|");
        		
        				if(start_time == null){
        					sb.append("<null>");
        				}else{
            				sb.append(start_time);
            			}
            		
        			sb.append("|");
        		
        				if(end_time == null){
        					sb.append("<null>");
        				}else{
            				sb.append(end_time);
            			}
            		
        			sb.append("|");
        		
        				if(source_table_name == null){
        					sb.append("<null>");
        				}else{
            				sb.append(source_table_name);
            			}
            		
        			sb.append("|");
        		
        				if(source_count == null){
        					sb.append("<null>");
        				}else{
            				sb.append(source_count);
            			}
            		
        			sb.append("|");
        		
        				if(target_table_name == null){
        					sb.append("<null>");
        				}else{
            				sb.append(target_table_name);
            			}
            		
        			sb.append("|");
        		
        				if(target_count == null){
        					sb.append("<null>");
        				}else{
            				sb.append(target_count);
            			}
            		
        			sb.append("|");
        		
        				if(flag == null){
        					sb.append("<null>");
        				}else{
            				sb.append(flag);
            			}
            		
        			sb.append("|");
        		
        				if(sub_job == null){
        					sb.append("<null>");
        				}else{
            				sb.append(sub_job);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(row7Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public static class copyOfAStruct implements routines.system.IPersistableRow<copyOfAStruct> {
    final static byte[] commonByteArrayLock_OG_APPLICATIONS_J_X_MAN_FINANCE_LAGTIME = new byte[0];
    static byte[] commonByteArray_OG_APPLICATIONS_J_X_MAN_FINANCE_LAGTIME = new byte[0];

	
			    public String job_name;

				public String getJob_name () {
					return this.job_name;
				}
				
			    public java.util.Date start_time;

				public java.util.Date getStart_time () {
					return this.start_time;
				}
				
			    public java.util.Date end_time;

				public java.util.Date getEnd_time () {
					return this.end_time;
				}
				
			    public String source_table_name;

				public String getSource_table_name () {
					return this.source_table_name;
				}
				
			    public Integer source_count;

				public Integer getSource_count () {
					return this.source_count;
				}
				
			    public String target_table_name;

				public String getTarget_table_name () {
					return this.target_table_name;
				}
				
			    public Integer target_count;

				public Integer getTarget_count () {
					return this.target_count;
				}
				
			    public String flag;

				public String getFlag () {
					return this.flag;
				}
				
			    public String sub_job;

				public String getSub_job () {
					return this.sub_job;
				}
				



	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_OG_APPLICATIONS_J_X_MAN_FINANCE_LAGTIME.length) {
				if(length < 1024 && commonByteArray_OG_APPLICATIONS_J_X_MAN_FINANCE_LAGTIME.length == 0) {
   					commonByteArray_OG_APPLICATIONS_J_X_MAN_FINANCE_LAGTIME = new byte[1024];
				} else {
   					commonByteArray_OG_APPLICATIONS_J_X_MAN_FINANCE_LAGTIME = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_OG_APPLICATIONS_J_X_MAN_FINANCE_LAGTIME, 0, length);
			strReturn = new String(commonByteArray_OG_APPLICATIONS_J_X_MAN_FINANCE_LAGTIME, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }

	private java.util.Date readDate(ObjectInputStream dis) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(dis.readLong());
		}
		return dateReturn;
	}

    private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException{
		if(date1 == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeLong(date1.getTime());
    	}
    }
	private Integer readInteger(ObjectInputStream dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}

	private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException{
		if(intNum == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeInt(intNum);
    	}
	}

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_OG_APPLICATIONS_J_X_MAN_FINANCE_LAGTIME) {

        	try {

        		int length = 0;
		
					this.job_name = readString(dis);
					
					this.start_time = readDate(dis);
					
					this.end_time = readDate(dis);
					
					this.source_table_name = readString(dis);
					
						this.source_count = readInteger(dis);
					
					this.target_table_name = readString(dis);
					
						this.target_count = readInteger(dis);
					
					this.flag = readString(dis);
					
					this.sub_job = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// String
				
						writeString(this.job_name,dos);
					
					// java.util.Date
				
						writeDate(this.start_time,dos);
					
					// java.util.Date
				
						writeDate(this.end_time,dos);
					
					// String
				
						writeString(this.source_table_name,dos);
					
					// Integer
				
						writeInteger(this.source_count,dos);
					
					// String
				
						writeString(this.target_table_name,dos);
					
					// Integer
				
						writeInteger(this.target_count,dos);
					
					// String
				
						writeString(this.flag,dos);
					
					// String
				
						writeString(this.sub_job,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("job_name="+job_name);
		sb.append(",start_time="+String.valueOf(start_time));
		sb.append(",end_time="+String.valueOf(end_time));
		sb.append(",source_table_name="+source_table_name);
		sb.append(",source_count="+String.valueOf(source_count));
		sb.append(",target_table_name="+target_table_name);
		sb.append(",target_count="+String.valueOf(target_count));
		sb.append(",flag="+flag);
		sb.append(",sub_job="+sub_job);
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				if(job_name == null){
        					sb.append("<null>");
        				}else{
            				sb.append(job_name);
            			}
            		
        			sb.append("|");
        		
        				if(start_time == null){
        					sb.append("<null>");
        				}else{
            				sb.append(start_time);
            			}
            		
        			sb.append("|");
        		
        				if(end_time == null){
        					sb.append("<null>");
        				}else{
            				sb.append(end_time);
            			}
            		
        			sb.append("|");
        		
        				if(source_table_name == null){
        					sb.append("<null>");
        				}else{
            				sb.append(source_table_name);
            			}
            		
        			sb.append("|");
        		
        				if(source_count == null){
        					sb.append("<null>");
        				}else{
            				sb.append(source_count);
            			}
            		
        			sb.append("|");
        		
        				if(target_table_name == null){
        					sb.append("<null>");
        				}else{
            				sb.append(target_table_name);
            			}
            		
        			sb.append("|");
        		
        				if(target_count == null){
        					sb.append("<null>");
        				}else{
            				sb.append(target_count);
            			}
            		
        			sb.append("|");
        		
        				if(flag == null){
        					sb.append("<null>");
        				}else{
            				sb.append(flag);
            			}
            		
        			sb.append("|");
        		
        				if(sub_job == null){
        					sb.append("<null>");
        				}else{
            				sb.append(sub_job);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(copyOfAStruct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public static class row4Struct implements routines.system.IPersistableRow<row4Struct> {
    final static byte[] commonByteArrayLock_OG_APPLICATIONS_J_X_MAN_FINANCE_LAGTIME = new byte[0];
    static byte[] commonByteArray_OG_APPLICATIONS_J_X_MAN_FINANCE_LAGTIME = new byte[0];

	
			    public java.util.Date moment;

				public java.util.Date getMoment () {
					return this.moment;
				}
				
			    public String pid;

				public String getPid () {
					return this.pid;
				}
				
			    public String father_pid;

				public String getFather_pid () {
					return this.father_pid;
				}
				
			    public String root_pid;

				public String getRoot_pid () {
					return this.root_pid;
				}
				
			    public Long system_pid;

				public Long getSystem_pid () {
					return this.system_pid;
				}
				
			    public String project;

				public String getProject () {
					return this.project;
				}
				
			    public String job;

				public String getJob () {
					return this.job;
				}
				
			    public String job_repository_id;

				public String getJob_repository_id () {
					return this.job_repository_id;
				}
				
			    public String job_version;

				public String getJob_version () {
					return this.job_version;
				}
				
			    public String context;

				public String getContext () {
					return this.context;
				}
				
			    public String origin;

				public String getOrigin () {
					return this.origin;
				}
				
			    public String label;

				public String getLabel () {
					return this.label;
				}
				
			    public Integer count;

				public Integer getCount () {
					return this.count;
				}
				
			    public Integer reference;

				public Integer getReference () {
					return this.reference;
				}
				
			    public String thresholds;

				public String getThresholds () {
					return this.thresholds;
				}
				



	private java.util.Date readDate(ObjectInputStream dis) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(dis.readLong());
		}
		return dateReturn;
	}

    private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException{
		if(date1 == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeLong(date1.getTime());
    	}
    }

	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_OG_APPLICATIONS_J_X_MAN_FINANCE_LAGTIME.length) {
				if(length < 1024 && commonByteArray_OG_APPLICATIONS_J_X_MAN_FINANCE_LAGTIME.length == 0) {
   					commonByteArray_OG_APPLICATIONS_J_X_MAN_FINANCE_LAGTIME = new byte[1024];
				} else {
   					commonByteArray_OG_APPLICATIONS_J_X_MAN_FINANCE_LAGTIME = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_OG_APPLICATIONS_J_X_MAN_FINANCE_LAGTIME, 0, length);
			strReturn = new String(commonByteArray_OG_APPLICATIONS_J_X_MAN_FINANCE_LAGTIME, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
	private Integer readInteger(ObjectInputStream dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}

	private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException{
		if(intNum == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeInt(intNum);
    	}
	}

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_OG_APPLICATIONS_J_X_MAN_FINANCE_LAGTIME) {

        	try {

        		int length = 0;
		
					this.moment = readDate(dis);
					
					this.pid = readString(dis);
					
					this.father_pid = readString(dis);
					
					this.root_pid = readString(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.system_pid = null;
           				} else {
           			    	this.system_pid = dis.readLong();
           				}
					
					this.project = readString(dis);
					
					this.job = readString(dis);
					
					this.job_repository_id = readString(dis);
					
					this.job_version = readString(dis);
					
					this.context = readString(dis);
					
					this.origin = readString(dis);
					
					this.label = readString(dis);
					
						this.count = readInteger(dis);
					
						this.reference = readInteger(dis);
					
					this.thresholds = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// java.util.Date
				
						writeDate(this.moment,dos);
					
					// String
				
						writeString(this.pid,dos);
					
					// String
				
						writeString(this.father_pid,dos);
					
					// String
				
						writeString(this.root_pid,dos);
					
					// Long
				
						if(this.system_pid == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeLong(this.system_pid);
		            	}
					
					// String
				
						writeString(this.project,dos);
					
					// String
				
						writeString(this.job,dos);
					
					// String
				
						writeString(this.job_repository_id,dos);
					
					// String
				
						writeString(this.job_version,dos);
					
					// String
				
						writeString(this.context,dos);
					
					// String
				
						writeString(this.origin,dos);
					
					// String
				
						writeString(this.label,dos);
					
					// Integer
				
						writeInteger(this.count,dos);
					
					// Integer
				
						writeInteger(this.reference,dos);
					
					// String
				
						writeString(this.thresholds,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("moment="+String.valueOf(moment));
		sb.append(",pid="+pid);
		sb.append(",father_pid="+father_pid);
		sb.append(",root_pid="+root_pid);
		sb.append(",system_pid="+String.valueOf(system_pid));
		sb.append(",project="+project);
		sb.append(",job="+job);
		sb.append(",job_repository_id="+job_repository_id);
		sb.append(",job_version="+job_version);
		sb.append(",context="+context);
		sb.append(",origin="+origin);
		sb.append(",label="+label);
		sb.append(",count="+String.valueOf(count));
		sb.append(",reference="+String.valueOf(reference));
		sb.append(",thresholds="+thresholds);
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				if(moment == null){
        					sb.append("<null>");
        				}else{
            				sb.append(moment);
            			}
            		
        			sb.append("|");
        		
        				if(pid == null){
        					sb.append("<null>");
        				}else{
            				sb.append(pid);
            			}
            		
        			sb.append("|");
        		
        				if(father_pid == null){
        					sb.append("<null>");
        				}else{
            				sb.append(father_pid);
            			}
            		
        			sb.append("|");
        		
        				if(root_pid == null){
        					sb.append("<null>");
        				}else{
            				sb.append(root_pid);
            			}
            		
        			sb.append("|");
        		
        				if(system_pid == null){
        					sb.append("<null>");
        				}else{
            				sb.append(system_pid);
            			}
            		
        			sb.append("|");
        		
        				if(project == null){
        					sb.append("<null>");
        				}else{
            				sb.append(project);
            			}
            		
        			sb.append("|");
        		
        				if(job == null){
        					sb.append("<null>");
        				}else{
            				sb.append(job);
            			}
            		
        			sb.append("|");
        		
        				if(job_repository_id == null){
        					sb.append("<null>");
        				}else{
            				sb.append(job_repository_id);
            			}
            		
        			sb.append("|");
        		
        				if(job_version == null){
        					sb.append("<null>");
        				}else{
            				sb.append(job_version);
            			}
            		
        			sb.append("|");
        		
        				if(context == null){
        					sb.append("<null>");
        				}else{
            				sb.append(context);
            			}
            		
        			sb.append("|");
        		
        				if(origin == null){
        					sb.append("<null>");
        				}else{
            				sb.append(origin);
            			}
            		
        			sb.append("|");
        		
        				if(label == null){
        					sb.append("<null>");
        				}else{
            				sb.append(label);
            			}
            		
        			sb.append("|");
        		
        				if(count == null){
        					sb.append("<null>");
        				}else{
            				sb.append(count);
            			}
            		
        			sb.append("|");
        		
        				if(reference == null){
        					sb.append("<null>");
        				}else{
            				sb.append(reference);
            			}
            		
        			sb.append("|");
        		
        				if(thresholds == null){
        					sb.append("<null>");
        				}else{
            				sb.append(thresholds);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(row4Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}
public void tFlowMeterCatcher_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tFlowMeterCatcher_1_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;



		row4Struct row4 = new row4Struct();
copyOfAStruct copyOfA = new copyOfAStruct();
row7Struct row7 = new row7Struct();
row7Struct row8 = row7;
row9Struct row9 = new row9Struct();








	
	/**
	 * [tLogRow_2 begin ] start
	 */

	

	
		
		ok_Hash.put("tLogRow_2", false);
		start_Hash.put("tLogRow_2", System.currentTimeMillis());
		
	
	currentComponent="tLogRow_2";

	
			if (execStat) {
				if(resourceMap.get("inIterateVComp") == null){
					
						runStat.updateStatOnConnection("row9" + iterateId, 0, 0);
					
				}
			} 

		
		int tos_count_tLogRow_2 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tLogRow_2 - "  + ("Start to work.") );
    	class BytesLimit65535_tLogRow_2{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tLogRow_2 = new StringBuilder();
            log4jParamters_tLogRow_2.append("Parameters:");
                    log4jParamters_tLogRow_2.append("BASIC_MODE" + " = " + "false");
                log4jParamters_tLogRow_2.append(" | ");
                    log4jParamters_tLogRow_2.append("TABLE_PRINT" + " = " + "true");
                log4jParamters_tLogRow_2.append(" | ");
                    log4jParamters_tLogRow_2.append("VERTICAL" + " = " + "false");
                log4jParamters_tLogRow_2.append(" | ");
                    log4jParamters_tLogRow_2.append("PRINT_CONTENT_WITH_LOG4J" + " = " + "false");
                log4jParamters_tLogRow_2.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tLogRow_2 - "  + (log4jParamters_tLogRow_2) );
    		}
    	}
    	
        new BytesLimit65535_tLogRow_2().limitLog4jByte();

	///////////////////////
	
         class Util_tLogRow_2 {

        String[] des_top = { ".", ".", "-", "+" };

        String[] des_head = { "|=", "=|", "-", "+" };

        String[] des_bottom = { "'", "'", "-", "+" };

        String name="";

        java.util.List<String[]> list = new java.util.ArrayList<String[]>();

        int[] colLengths = new int[0];

        public void addRow(String[] row) {

            for (int i = 0; i < 0; i++) {
                if (row[i]!=null) {
                  colLengths[i] = Math.max(colLengths[i], row[i].length());
                }
            }
            list.add(row);
        }

        public void setTableName(String name) {

            this.name = name;
        }

            public StringBuilder format() {
            
                StringBuilder sb = new StringBuilder();
                
                return sb;
            }
            
            public boolean isTableEmpty(){
            	if (list.size() > 1)
            		return false;
            	return true;
            }
        }
        Util_tLogRow_2 util_tLogRow_2 = new Util_tLogRow_2();
        util_tLogRow_2.setTableName("tLogRow_2");
        util_tLogRow_2.addRow(new String[]{});        
 		StringBuilder strBuffer_tLogRow_2 = null;
		int nb_line_tLogRow_2 = 0;
///////////////////////    			



 



/**
 * [tLogRow_2 begin ] stop
 */



	
	/**
	 * [tJavaRow_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tJavaRow_1", false);
		start_Hash.put("tJavaRow_1", System.currentTimeMillis());
		
	
	currentComponent="tJavaRow_1";

	
			if (execStat) {
				if(resourceMap.get("inIterateVComp") == null){
					
						runStat.updateStatOnConnection("row8" + iterateId, 0, 0);
					
				}
			} 

		
		int tos_count_tJavaRow_1 = 0;
		
    	class BytesLimit65535_tJavaRow_1{
    		public void limitLog4jByte() throws Exception{
    			
    		}
    	}
    	
        new BytesLimit65535_tJavaRow_1().limitLog4jByte();

int nb_line_tJavaRow_1 = 0;

 



/**
 * [tJavaRow_1 begin ] stop
 */



	
	/**
	 * [tLogRow_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tLogRow_1", false);
		start_Hash.put("tLogRow_1", System.currentTimeMillis());
		
	
	currentComponent="tLogRow_1";

	
			if (execStat) {
				if(resourceMap.get("inIterateVComp") == null){
					
						runStat.updateStatOnConnection("row7" + iterateId, 0, 0);
					
				}
			} 

		
		int tos_count_tLogRow_1 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tLogRow_1 - "  + ("Start to work.") );
    	class BytesLimit65535_tLogRow_1{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tLogRow_1 = new StringBuilder();
            log4jParamters_tLogRow_1.append("Parameters:");
                    log4jParamters_tLogRow_1.append("BASIC_MODE" + " = " + "false");
                log4jParamters_tLogRow_1.append(" | ");
                    log4jParamters_tLogRow_1.append("TABLE_PRINT" + " = " + "true");
                log4jParamters_tLogRow_1.append(" | ");
                    log4jParamters_tLogRow_1.append("VERTICAL" + " = " + "false");
                log4jParamters_tLogRow_1.append(" | ");
                    log4jParamters_tLogRow_1.append("PRINT_CONTENT_WITH_LOG4J" + " = " + "false");
                log4jParamters_tLogRow_1.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tLogRow_1 - "  + (log4jParamters_tLogRow_1) );
    		}
    	}
    	
        new BytesLimit65535_tLogRow_1().limitLog4jByte();

	///////////////////////
	
         class Util_tLogRow_1 {

        String[] des_top = { ".", ".", "-", "+" };

        String[] des_head = { "|=", "=|", "-", "+" };

        String[] des_bottom = { "'", "'", "-", "+" };

        String name="";

        java.util.List<String[]> list = new java.util.ArrayList<String[]>();

        int[] colLengths = new int[9];

        public void addRow(String[] row) {

            for (int i = 0; i < 9; i++) {
                if (row[i]!=null) {
                  colLengths[i] = Math.max(colLengths[i], row[i].length());
                }
            }
            list.add(row);
        }

        public void setTableName(String name) {

            this.name = name;
        }

            public StringBuilder format() {
            
                StringBuilder sb = new StringBuilder();
  
            
                    sb.append(print(des_top));
    
                    int totals = 0;
                    for (int i = 0; i < colLengths.length; i++) {
                        totals = totals + colLengths[i];
                    }
    
                    // name
                    sb.append("|");
                    int k = 0;
                    for (k = 0; k < (totals + 8 - name.length()) / 2; k++) {
                        sb.append(' ');
                    }
                    sb.append(name);
                    for (int i = 0; i < totals + 8 - name.length() - k; i++) {
                        sb.append(' ');
                    }
                    sb.append("|\n");

                    // head and rows
                    sb.append(print(des_head));
                    for (int i = 0; i < list.size(); i++) {
    
                        String[] row = list.get(i);
    
                        java.util.Formatter formatter = new java.util.Formatter(new StringBuilder());
                        
                        StringBuilder sbformat = new StringBuilder();                                             
        			        sbformat.append("|%1$-");
        			        sbformat.append(colLengths[0]);
        			        sbformat.append("s");
        			              
        			        sbformat.append("|%2$-");
        			        sbformat.append(colLengths[1]);
        			        sbformat.append("s");
        			              
        			        sbformat.append("|%3$-");
        			        sbformat.append(colLengths[2]);
        			        sbformat.append("s");
        			              
        			        sbformat.append("|%4$-");
        			        sbformat.append(colLengths[3]);
        			        sbformat.append("s");
        			              
        			        sbformat.append("|%5$-");
        			        sbformat.append(colLengths[4]);
        			        sbformat.append("s");
        			              
        			        sbformat.append("|%6$-");
        			        sbformat.append(colLengths[5]);
        			        sbformat.append("s");
        			              
        			        sbformat.append("|%7$-");
        			        sbformat.append(colLengths[6]);
        			        sbformat.append("s");
        			              
        			        sbformat.append("|%8$-");
        			        sbformat.append(colLengths[7]);
        			        sbformat.append("s");
        			              
        			        sbformat.append("|%9$-");
        			        sbformat.append(colLengths[8]);
        			        sbformat.append("s");
        			                      
                        sbformat.append("|\n");                    
       
                        formatter.format(sbformat.toString(), (Object[])row);	
                                
                        sb.append(formatter.toString());
                        if (i == 0)
                            sb.append(print(des_head)); // print the head
                    }
    
                    // end
                    sb.append(print(des_bottom));
                    return sb;
                }
            

            private StringBuilder print(String[] fillChars) {
                StringBuilder sb = new StringBuilder();
                //first column
                sb.append(fillChars[0]);                
                    for (int i = 0; i < colLengths[0] - fillChars[0].length() + 1; i++) {
                        sb.append(fillChars[2]);
                    }
                    sb.append(fillChars[3]);	                

                    for (int i = 0; i < colLengths[1] - fillChars[3].length() + 1; i++) {
                        sb.append(fillChars[2]);
                    }
                    sb.append(fillChars[3]);
                    for (int i = 0; i < colLengths[2] - fillChars[3].length() + 1; i++) {
                        sb.append(fillChars[2]);
                    }
                    sb.append(fillChars[3]);
                    for (int i = 0; i < colLengths[3] - fillChars[3].length() + 1; i++) {
                        sb.append(fillChars[2]);
                    }
                    sb.append(fillChars[3]);
                    for (int i = 0; i < colLengths[4] - fillChars[3].length() + 1; i++) {
                        sb.append(fillChars[2]);
                    }
                    sb.append(fillChars[3]);
                    for (int i = 0; i < colLengths[5] - fillChars[3].length() + 1; i++) {
                        sb.append(fillChars[2]);
                    }
                    sb.append(fillChars[3]);
                    for (int i = 0; i < colLengths[6] - fillChars[3].length() + 1; i++) {
                        sb.append(fillChars[2]);
                    }
                    sb.append(fillChars[3]);
                    for (int i = 0; i < colLengths[7] - fillChars[3].length() + 1; i++) {
                        sb.append(fillChars[2]);
                    }
                    sb.append(fillChars[3]);
                
                    //last column
                    for (int i = 0; i < colLengths[8] - fillChars[1].length() + 1; i++) {
                        sb.append(fillChars[2]);
                    }         
                sb.append(fillChars[1]);
                sb.append("\n");               
                return sb;
            }
            
            public boolean isTableEmpty(){
            	if (list.size() > 1)
            		return false;
            	return true;
            }
        }
        Util_tLogRow_1 util_tLogRow_1 = new Util_tLogRow_1();
        util_tLogRow_1.setTableName("tLogRow_1");
        util_tLogRow_1.addRow(new String[]{"job_name","start_time","end_time","source_table_name","source_count","target_table_name","target_count","flag","sub_job",});        
 		StringBuilder strBuffer_tLogRow_1 = null;
		int nb_line_tLogRow_1 = 0;
///////////////////////    			



 



/**
 * [tLogRow_1 begin ] stop
 */



	
	/**
	 * [tPostgresqlOutput_2 begin ] start
	 */

	

	
		
		ok_Hash.put("tPostgresqlOutput_2", false);
		start_Hash.put("tPostgresqlOutput_2", System.currentTimeMillis());
		
	
	currentComponent="tPostgresqlOutput_2";

	
			if (execStat) {
				if(resourceMap.get("inIterateVComp") == null){
					
						runStat.updateStatOnConnection("copyOfA" + iterateId, 0, 0);
					
				}
			} 

		
		int tos_count_tPostgresqlOutput_2 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tPostgresqlOutput_2 - "  + ("Start to work.") );
    	class BytesLimit65535_tPostgresqlOutput_2{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tPostgresqlOutput_2 = new StringBuilder();
            log4jParamters_tPostgresqlOutput_2.append("Parameters:");
                    log4jParamters_tPostgresqlOutput_2.append("USE_EXISTING_CONNECTION" + " = " + "false");
                log4jParamters_tPostgresqlOutput_2.append(" | ");
                    log4jParamters_tPostgresqlOutput_2.append("DB_VERSION" + " = " + "V9_X");
                log4jParamters_tPostgresqlOutput_2.append(" | ");
                    log4jParamters_tPostgresqlOutput_2.append("HOST" + " = " + "context.aws_gp_prof_Server");
                log4jParamters_tPostgresqlOutput_2.append(" | ");
                    log4jParamters_tPostgresqlOutput_2.append("PORT" + " = " + "context.aws_gp_prof_Port");
                log4jParamters_tPostgresqlOutput_2.append(" | ");
                    log4jParamters_tPostgresqlOutput_2.append("DBNAME" + " = " + "\"bhdl\"");
                log4jParamters_tPostgresqlOutput_2.append(" | ");
                    log4jParamters_tPostgresqlOutput_2.append("SCHEMA_DB" + " = " + "\"og_bhone_bw\"");
                log4jParamters_tPostgresqlOutput_2.append(" | ");
                    log4jParamters_tPostgresqlOutput_2.append("USER" + " = " + "context.aws_gp_prof_Login");
                log4jParamters_tPostgresqlOutput_2.append(" | ");
                    log4jParamters_tPostgresqlOutput_2.append("PASS" + " = " + String.valueOf(routines.system.PasswordEncryptUtil.encryptPassword(context.aws_gp_prof_Password)).substring(0, 4) + "...");     
                log4jParamters_tPostgresqlOutput_2.append(" | ");
                    log4jParamters_tPostgresqlOutput_2.append("TABLE" + " = " + "\"bh_bw_stat\"");
                log4jParamters_tPostgresqlOutput_2.append(" | ");
                    log4jParamters_tPostgresqlOutput_2.append("TABLE_ACTION" + " = " + "NONE");
                log4jParamters_tPostgresqlOutput_2.append(" | ");
                    log4jParamters_tPostgresqlOutput_2.append("DATA_ACTION" + " = " + "INSERT");
                log4jParamters_tPostgresqlOutput_2.append(" | ");
                    log4jParamters_tPostgresqlOutput_2.append("SPECIFY_DATASOURCE_ALIAS" + " = " + "false");
                log4jParamters_tPostgresqlOutput_2.append(" | ");
                    log4jParamters_tPostgresqlOutput_2.append("DIE_ON_ERROR" + " = " + "false");
                log4jParamters_tPostgresqlOutput_2.append(" | ");
                    log4jParamters_tPostgresqlOutput_2.append("USE_SSL" + " = " + "true");
                log4jParamters_tPostgresqlOutput_2.append(" | ");
                    log4jParamters_tPostgresqlOutput_2.append("COMMIT_EVERY" + " = " + "10000");
                log4jParamters_tPostgresqlOutput_2.append(" | ");
                    log4jParamters_tPostgresqlOutput_2.append("ADD_COLS" + " = " + "[]");
                log4jParamters_tPostgresqlOutput_2.append(" | ");
                    log4jParamters_tPostgresqlOutput_2.append("USE_FIELD_OPTIONS" + " = " + "false");
                log4jParamters_tPostgresqlOutput_2.append(" | ");
                    log4jParamters_tPostgresqlOutput_2.append("ENABLE_DEBUG_MODE" + " = " + "false");
                log4jParamters_tPostgresqlOutput_2.append(" | ");
                    log4jParamters_tPostgresqlOutput_2.append("SUPPORT_NULL_WHERE" + " = " + "false");
                log4jParamters_tPostgresqlOutput_2.append(" | ");
                    log4jParamters_tPostgresqlOutput_2.append("USE_BATCH_SIZE" + " = " + "true");
                log4jParamters_tPostgresqlOutput_2.append(" | ");
                    log4jParamters_tPostgresqlOutput_2.append("BATCH_SIZE" + " = " + "10000");
                log4jParamters_tPostgresqlOutput_2.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tPostgresqlOutput_2 - "  + (log4jParamters_tPostgresqlOutput_2) );
    		}
    	}
    	
        new BytesLimit65535_tPostgresqlOutput_2().limitLog4jByte();





String dbschema_tPostgresqlOutput_2 = null;
	dbschema_tPostgresqlOutput_2 = "og_bhone_bw";
	

String tableName_tPostgresqlOutput_2 = null;
if(dbschema_tPostgresqlOutput_2 == null || dbschema_tPostgresqlOutput_2.trim().length() == 0) {
	tableName_tPostgresqlOutput_2 = "bh_bw_stat";
} else {
	tableName_tPostgresqlOutput_2 = dbschema_tPostgresqlOutput_2 + "\".\"" + "bh_bw_stat";
}

int nb_line_tPostgresqlOutput_2 = 0;
int nb_line_update_tPostgresqlOutput_2 = 0;
int nb_line_inserted_tPostgresqlOutput_2 = 0;
int nb_line_deleted_tPostgresqlOutput_2 = 0;
int nb_line_rejected_tPostgresqlOutput_2 = 0;

int deletedCount_tPostgresqlOutput_2=0;
int updatedCount_tPostgresqlOutput_2=0;
int insertedCount_tPostgresqlOutput_2=0;
int rejectedCount_tPostgresqlOutput_2=0;

boolean whetherReject_tPostgresqlOutput_2 = false;

java.sql.Connection conn_tPostgresqlOutput_2 = null;
String dbUser_tPostgresqlOutput_2 = null;

	
                if(log.isDebugEnabled())
            log.debug("tPostgresqlOutput_2 - "  + ("Driver ClassName: ")  + ("org.postgresql.Driver")  + (".") );
    java.lang.Class.forName("org.postgresql.Driver");
	
	
			String url_tPostgresqlOutput_2 = "jdbc:postgresql://"+context.aws_gp_prof_Server+":"+context.aws_gp_prof_Port+"/"+"bhdl"+"?ssl=true&sslfactory=org.postgresql.ssl.NonValidatingFactory";
	
    
    dbUser_tPostgresqlOutput_2 = context.aws_gp_prof_Login;

	final String decryptedPassword_tPostgresqlOutput_2 = context.aws_gp_prof_Password; 

    String dbPwd_tPostgresqlOutput_2 = decryptedPassword_tPostgresqlOutput_2;

                if(log.isDebugEnabled())
            log.debug("tPostgresqlOutput_2 - "  + ("Connection attempts to '")  + (url_tPostgresqlOutput_2)  + ("' with the username '")  + (dbUser_tPostgresqlOutput_2)  + ("'.") );
    conn_tPostgresqlOutput_2 = java.sql.DriverManager.getConnection(url_tPostgresqlOutput_2,dbUser_tPostgresqlOutput_2,dbPwd_tPostgresqlOutput_2);
                if(log.isDebugEnabled())
            log.debug("tPostgresqlOutput_2 - "  + ("Connection to '")  + (url_tPostgresqlOutput_2)  + ("' has succeeded.") );
	
	resourceMap.put("conn_tPostgresqlOutput_2", conn_tPostgresqlOutput_2);
        conn_tPostgresqlOutput_2.setAutoCommit(false);
        int commitEvery_tPostgresqlOutput_2 = 10000;
        int commitCounter_tPostgresqlOutput_2 = 0;
                if(log.isDebugEnabled())
            log.debug("tPostgresqlOutput_2 - "  + ("Connection is set auto commit to '")  + (conn_tPostgresqlOutput_2.getAutoCommit())  + ("'.") );


   int batchSize_tPostgresqlOutput_2 = 10000;
   int batchSizeCounter_tPostgresqlOutput_2=0;

int count_tPostgresqlOutput_2=0;
	    String insert_tPostgresqlOutput_2 = "INSERT INTO \"" + tableName_tPostgresqlOutput_2 + "\" (\"job_name\",\"start_time\",\"end_time\",\"source_table_name\",\"source_count\",\"target_table_name\",\"target_count\",\"flag\",\"sub_job\") VALUES (?,?,?,?,?,?,?,?,?)";
	    java.sql.PreparedStatement pstmt_tPostgresqlOutput_2 = conn_tPostgresqlOutput_2.prepareStatement(insert_tPostgresqlOutput_2);
	    

 



/**
 * [tPostgresqlOutput_2 begin ] stop
 */



	
	/**
	 * [tMap_2 begin ] start
	 */

	

	
		
		ok_Hash.put("tMap_2", false);
		start_Hash.put("tMap_2", System.currentTimeMillis());
		
	
	currentComponent="tMap_2";

	
			if (execStat) {
				if(resourceMap.get("inIterateVComp") == null){
					
						runStat.updateStatOnConnection("row4" + iterateId, 0, 0);
					
				}
			} 

		
		int tos_count_tMap_2 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tMap_2 - "  + ("Start to work.") );
    	class BytesLimit65535_tMap_2{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tMap_2 = new StringBuilder();
            log4jParamters_tMap_2.append("Parameters:");
                    log4jParamters_tMap_2.append("LINK_STYLE" + " = " + "AUTO");
                log4jParamters_tMap_2.append(" | ");
                    log4jParamters_tMap_2.append("TEMPORARY_DATA_DIRECTORY" + " = " + "");
                log4jParamters_tMap_2.append(" | ");
                    log4jParamters_tMap_2.append("ROWS_BUFFER_SIZE" + " = " + "2000000");
                log4jParamters_tMap_2.append(" | ");
                    log4jParamters_tMap_2.append("CHANGE_HASH_AND_EQUALS_FOR_BIGDECIMAL" + " = " + "false");
                log4jParamters_tMap_2.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tMap_2 - "  + (log4jParamters_tMap_2) );
    		}
    	}
    	
        new BytesLimit65535_tMap_2().limitLog4jByte();




// ###############################
// # Lookup's keys initialization
		int count_row4_tMap_2 = 0;
		
// ###############################        

// ###############################
// # Vars initialization
class  Var__tMap_2__Struct  {
}
Var__tMap_2__Struct Var__tMap_2 = new Var__tMap_2__Struct();
// ###############################

// ###############################
// # Outputs initialization
				int count_copyOfA_tMap_2 = 0;
				
copyOfAStruct copyOfA_tmp = new copyOfAStruct();
// ###############################

        
        



        









 



/**
 * [tMap_2 begin ] stop
 */



	
	/**
	 * [tFlowMeterCatcher_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tFlowMeterCatcher_1", false);
		start_Hash.put("tFlowMeterCatcher_1", System.currentTimeMillis());
		
	
	currentComponent="tFlowMeterCatcher_1";

	
		int tos_count_tFlowMeterCatcher_1 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tFlowMeterCatcher_1 - "  + ("Start to work.") );
    	class BytesLimit65535_tFlowMeterCatcher_1{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tFlowMeterCatcher_1 = new StringBuilder();
            log4jParamters_tFlowMeterCatcher_1.append("Parameters:");
                if(log.isDebugEnabled())
            log.debug("tFlowMeterCatcher_1 - "  + (log4jParamters_tFlowMeterCatcher_1) );
    		}
    	}
    	
        new BytesLimit65535_tFlowMeterCatcher_1().limitLog4jByte();

	for (MetterCatcherUtils.MetterCatcherMessage mcm : tFlowMeterCatcher_1.getMessages()) {
		row4.pid = pid;
		row4.root_pid = rootPid;
		row4.father_pid = fatherPid;	
        row4.project = projectName;
        row4.job = jobName;
        row4.context = contextStr;
		row4.origin = (mcm.getOrigin()==null || mcm.getOrigin().length()<1 ? null : mcm.getOrigin());
		row4.moment = mcm.getMoment();
		row4.job_version = mcm.getJobVersion();
		row4.job_repository_id = mcm.getJobId();
		row4.system_pid = mcm.getSystemPid();
		row4.label = mcm.getLabel();
		row4.count = mcm.getCount();
		row4.reference = tFlowMeterCatcher_1.getConnLinesCount(mcm.getReferense()+"_count");
		row4.thresholds = mcm.getThresholds();
		

 



/**
 * [tFlowMeterCatcher_1 begin ] stop
 */
	
	/**
	 * [tFlowMeterCatcher_1 main ] start
	 */

	

	
	
	currentComponent="tFlowMeterCatcher_1";

	

 


	tos_count_tFlowMeterCatcher_1++;

/**
 * [tFlowMeterCatcher_1 main ] stop
 */

	
	/**
	 * [tMap_2 main ] start
	 */

	

	
	
	currentComponent="tMap_2";

	

			//row4
			//row4


			
				if(execStat){
					runStat.updateStatOnConnection("row4"+iterateId,1, 1);
				} 
			

		
    			if(log.isTraceEnabled()){
    				log.trace("row4 - " + (row4==null? "": row4.toLogString()));
    			}
    		

		
		
		boolean hasCasePrimitiveKeyWithNull_tMap_2 = false;
		
        // ###############################
        // # Input tables (lookups)
		  boolean rejectedInnerJoin_tMap_2 = false;
		  boolean mainRowRejected_tMap_2 = false;
            				    								  
		// ###############################
        { // start of Var scope
        
	        // ###############################
        	// # Vars tables
        
Var__tMap_2__Struct Var = Var__tMap_2;// ###############################
        // ###############################
        // # Output tables

copyOfA = null;


// # Output table : 'copyOfA'
count_copyOfA_tMap_2++;

copyOfA_tmp.job_name = context.master_job ;
copyOfA_tmp.start_time = row4.moment ;
copyOfA_tmp.end_time = TalendDate.getCurrentDate() ;
copyOfA_tmp.source_table_name = row4.label ;
copyOfA_tmp.source_count = row4.count ;
copyOfA_tmp.target_table_name = context.Table2;
copyOfA_tmp.target_count = ((Integer)globalMap.get("tPostgresqlOutput_1_NB_LINE_INSERTED")) ;
copyOfA_tmp.flag = row4.count.equals((Integer)globalMap.get("tPostgresqlOutput_1_NB_LINE_INSERTED"))?"Y":"N" ;
copyOfA_tmp.sub_job = row4.job ;
copyOfA = copyOfA_tmp;
log.debug("tMap_2 - Outputting the record " + count_copyOfA_tMap_2 + " of the output table 'copyOfA'.");

// ###############################

} // end of Var scope

rejectedInnerJoin_tMap_2 = false;










 


	tos_count_tMap_2++;

/**
 * [tMap_2 main ] stop
 */
// Start of branch "copyOfA"
if(copyOfA != null) { 



	
	/**
	 * [tPostgresqlOutput_2 main ] start
	 */

	

	
	
	currentComponent="tPostgresqlOutput_2";

	

			//copyOfA
			//copyOfA


			
				if(execStat){
					runStat.updateStatOnConnection("copyOfA"+iterateId,1, 1);
				} 
			

		
    			if(log.isTraceEnabled()){
    				log.trace("copyOfA - " + (copyOfA==null? "": copyOfA.toLogString()));
    			}
    		



            row7 = null;
        whetherReject_tPostgresqlOutput_2 = false;
                    if(copyOfA.job_name == null) {
pstmt_tPostgresqlOutput_2.setNull(1, java.sql.Types.VARCHAR);
} else {pstmt_tPostgresqlOutput_2.setString(1, copyOfA.job_name);
}

                    if(copyOfA.start_time != null) {
pstmt_tPostgresqlOutput_2.setTimestamp(2, new java.sql.Timestamp(copyOfA.start_time.getTime()));
} else {
pstmt_tPostgresqlOutput_2.setNull(2, java.sql.Types.TIMESTAMP);
}

                    if(copyOfA.end_time != null) {
pstmt_tPostgresqlOutput_2.setTimestamp(3, new java.sql.Timestamp(copyOfA.end_time.getTime()));
} else {
pstmt_tPostgresqlOutput_2.setNull(3, java.sql.Types.TIMESTAMP);
}

                    if(copyOfA.source_table_name == null) {
pstmt_tPostgresqlOutput_2.setNull(4, java.sql.Types.VARCHAR);
} else {pstmt_tPostgresqlOutput_2.setString(4, copyOfA.source_table_name);
}

                    if(copyOfA.source_count == null) {
pstmt_tPostgresqlOutput_2.setNull(5, java.sql.Types.INTEGER);
} else {pstmt_tPostgresqlOutput_2.setInt(5, copyOfA.source_count);
}

                    if(copyOfA.target_table_name == null) {
pstmt_tPostgresqlOutput_2.setNull(6, java.sql.Types.VARCHAR);
} else {pstmt_tPostgresqlOutput_2.setString(6, copyOfA.target_table_name);
}

                    if(copyOfA.target_count == null) {
pstmt_tPostgresqlOutput_2.setNull(7, java.sql.Types.INTEGER);
} else {pstmt_tPostgresqlOutput_2.setInt(7, copyOfA.target_count);
}

                    if(copyOfA.flag == null) {
pstmt_tPostgresqlOutput_2.setNull(8, java.sql.Types.VARCHAR);
} else {pstmt_tPostgresqlOutput_2.setString(8, copyOfA.flag);
}

                    if(copyOfA.sub_job == null) {
pstmt_tPostgresqlOutput_2.setNull(9, java.sql.Types.VARCHAR);
} else {pstmt_tPostgresqlOutput_2.setString(9, copyOfA.sub_job);
}

			
    		pstmt_tPostgresqlOutput_2.addBatch();
    		nb_line_tPostgresqlOutput_2++;
    		  
                if(log.isDebugEnabled())
            log.debug("tPostgresqlOutput_2 - "  + ("Adding the record ")  + (nb_line_tPostgresqlOutput_2)  + (" to the ")  + ("INSERT")  + (" batch.") );
    		  batchSizeCounter_tPostgresqlOutput_2++;
    		  
            if(!whetherReject_tPostgresqlOutput_2) {
                            row7 = new row7Struct();
                                row7.job_name = copyOfA.job_name;
                                row7.start_time = copyOfA.start_time;
                                row7.end_time = copyOfA.end_time;
                                row7.source_table_name = copyOfA.source_table_name;
                                row7.source_count = copyOfA.source_count;
                                row7.target_table_name = copyOfA.target_table_name;
                                row7.target_count = copyOfA.target_count;
                                row7.flag = copyOfA.flag;
                                row7.sub_job = copyOfA.sub_job;
            }
    			if ((batchSize_tPostgresqlOutput_2 > 0) && (batchSize_tPostgresqlOutput_2 <= batchSizeCounter_tPostgresqlOutput_2)) {
                try {
						int countSum_tPostgresqlOutput_2 = 0;
						    
                if(log.isDebugEnabled())
            log.debug("tPostgresqlOutput_2 - "  + ("Executing the ")  + ("INSERT")  + (" batch.") );
						for(int countEach_tPostgresqlOutput_2: pstmt_tPostgresqlOutput_2.executeBatch()) {
							countSum_tPostgresqlOutput_2 += (countEach_tPostgresqlOutput_2 < 0 ? 0 : countEach_tPostgresqlOutput_2);
						}
                if(log.isDebugEnabled())
            log.debug("tPostgresqlOutput_2 - "  + ("The ")  + ("INSERT")  + (" batch execution has succeeded.") );
				    	
				    		insertedCount_tPostgresqlOutput_2 += countSum_tPostgresqlOutput_2;
				    	
            	    	batchSizeCounter_tPostgresqlOutput_2 = 0;
                }catch (java.sql.BatchUpdateException e){
                	
                	int countSum_tPostgresqlOutput_2 = 0;
					for(int countEach_tPostgresqlOutput_2: e.getUpdateCounts()) {
						countSum_tPostgresqlOutput_2 += (countEach_tPostgresqlOutput_2 < 0 ? 0 : countEach_tPostgresqlOutput_2);
					}
					
			    		insertedCount_tPostgresqlOutput_2 += countSum_tPostgresqlOutput_2;
			    	
            log.error("tPostgresqlOutput_2 - "  + (e.getMessage()) );
                	System.err.println(e.getMessage());
                	
                }
    			}
    		
    		    commitCounter_tPostgresqlOutput_2++;
                if(commitEvery_tPostgresqlOutput_2 <= commitCounter_tPostgresqlOutput_2) {
                if ((batchSize_tPostgresqlOutput_2 > 0) && (batchSizeCounter_tPostgresqlOutput_2 > 0)) {
                try {
                		int countSum_tPostgresqlOutput_2 = 0;
                		    
                if(log.isDebugEnabled())
            log.debug("tPostgresqlOutput_2 - "  + ("Executing the ")  + ("INSERT")  + (" batch.") );
						for(int countEach_tPostgresqlOutput_2: pstmt_tPostgresqlOutput_2.executeBatch()) {
							countSum_tPostgresqlOutput_2 += (countEach_tPostgresqlOutput_2 < 0 ? 0 : countEach_tPostgresqlOutput_2);
						}
                if(log.isDebugEnabled())
            log.debug("tPostgresqlOutput_2 - "  + ("The ")  + ("INSERT")  + (" batch execution has succeeded.") );
            	    	
            	    		insertedCount_tPostgresqlOutput_2 += countSum_tPostgresqlOutput_2;
            	    	
                batchSizeCounter_tPostgresqlOutput_2 = 0;
                }catch (java.sql.BatchUpdateException e){
                	
                		int countSum_tPostgresqlOutput_2 = 0;
						for(int countEach_tPostgresqlOutput_2: e.getUpdateCounts()) {
							countSum_tPostgresqlOutput_2 += (countEach_tPostgresqlOutput_2 < 0 ? 0 : countEach_tPostgresqlOutput_2);
						}
						
				    		insertedCount_tPostgresqlOutput_2 += countSum_tPostgresqlOutput_2;
				    	
            log.error("tPostgresqlOutput_2 - "  + (e.getMessage()) );
                        System.err.println(e.getMessage());
                	
                }
            }
                if(log.isDebugEnabled())
            log.debug("tPostgresqlOutput_2 - "  + ("Connection starting to commit ")  + (commitCounter_tPostgresqlOutput_2)  + (" record(s).") );
                	conn_tPostgresqlOutput_2.commit();
                	
                if(log.isDebugEnabled())
            log.debug("tPostgresqlOutput_2 - "  + ("Connection commit has succeeded.") );
                	commitCounter_tPostgresqlOutput_2=0;
                }

 


	tos_count_tPostgresqlOutput_2++;

/**
 * [tPostgresqlOutput_2 main ] stop
 */
// Start of branch "row7"
if(row7 != null) { 



	
	/**
	 * [tLogRow_1 main ] start
	 */

	

	
	
	currentComponent="tLogRow_1";

	

			//row7
			//row7


			
				if(execStat){
					runStat.updateStatOnConnection("row7"+iterateId,1, 1);
				} 
			

		
    			if(log.isTraceEnabled()){
    				log.trace("row7 - " + (row7==null? "": row7.toLogString()));
    			}
    		
///////////////////////		
						

				
				String[] row_tLogRow_1 = new String[9];
   				
	    		if(row7.job_name != null) { //              
                 row_tLogRow_1[0]=    						    
				                String.valueOf(row7.job_name)			
					          ;	
							
	    		} //			
    			   				
	    		if(row7.start_time != null) { //              
                 row_tLogRow_1[1]=    						
								FormatterUtils.format_Date(row7.start_time, "dd-MM-yyyy")
					          ;	
							
	    		} //			
    			   				
	    		if(row7.end_time != null) { //              
                 row_tLogRow_1[2]=    						
								FormatterUtils.format_Date(row7.end_time, "dd-MM-yyyy")
					          ;	
							
	    		} //			
    			   				
	    		if(row7.source_table_name != null) { //              
                 row_tLogRow_1[3]=    						    
				                String.valueOf(row7.source_table_name)			
					          ;	
							
	    		} //			
    			   				
	    		if(row7.source_count != null) { //              
                 row_tLogRow_1[4]=    						    
				                String.valueOf(row7.source_count)			
					          ;	
							
	    		} //			
    			   				
	    		if(row7.target_table_name != null) { //              
                 row_tLogRow_1[5]=    						    
				                String.valueOf(row7.target_table_name)			
					          ;	
							
	    		} //			
    			   				
	    		if(row7.target_count != null) { //              
                 row_tLogRow_1[6]=    						    
				                String.valueOf(row7.target_count)			
					          ;	
							
	    		} //			
    			   				
	    		if(row7.flag != null) { //              
                 row_tLogRow_1[7]=    						    
				                String.valueOf(row7.flag)			
					          ;	
							
	    		} //			
    			   				
	    		if(row7.sub_job != null) { //              
                 row_tLogRow_1[8]=    						    
				                String.valueOf(row7.sub_job)			
					          ;	
							
	    		} //			
    			 

				util_tLogRow_1.addRow(row_tLogRow_1);	
				nb_line_tLogRow_1++;
//////

//////                    
                    
///////////////////////    			

 
     row8 = row7;


	tos_count_tLogRow_1++;

/**
 * [tLogRow_1 main ] stop
 */

	
	/**
	 * [tJavaRow_1 main ] start
	 */

	

	
	
	currentComponent="tJavaRow_1";

	

			//row8
			//row8


			
				if(execStat){
					runStat.updateStatOnConnection("row8"+iterateId,1, 1);
				} 
			

		
    			if(log.isTraceEnabled()){
    				log.trace("row8 - " + (row8==null? "": row8.toLogString()));
    			}
    		

    globalMap.put("flag",row8.flag);
globalMap.put("job_name",row8.sub_job);
globalMap.put("source_count",row8.source_count);
globalMap.put("target_count",row8.target_count);

    nb_line_tJavaRow_1++;   

 


	tos_count_tJavaRow_1++;

/**
 * [tJavaRow_1 main ] stop
 */

	
	/**
	 * [tLogRow_2 main ] start
	 */

	

	
	
	currentComponent="tLogRow_2";

	

			//row9
			//row9


			
				if(execStat){
					runStat.updateStatOnConnection("row9"+iterateId,1, 1);
				} 
			

		
    			if(log.isTraceEnabled()){
    				log.trace("row9 - " + (row9==null? "": row9.toLogString()));
    			}
    		
///////////////////////		
						

				
				String[] row_tLogRow_2 = new String[0];
 

				util_tLogRow_2.addRow(row_tLogRow_2);	
				nb_line_tLogRow_2++;
//////

//////                    
                    
///////////////////////    			

 


	tos_count_tLogRow_2++;

/**
 * [tLogRow_2 main ] stop
 */







} // End of branch "row7"





} // End of branch "copyOfA"







	
	/**
	 * [tFlowMeterCatcher_1 end ] start
	 */

	

	
	
	currentComponent="tFlowMeterCatcher_1";

	

	}


 
                if(log.isDebugEnabled())
            log.debug("tFlowMeterCatcher_1 - "  + ("Done.") );

ok_Hash.put("tFlowMeterCatcher_1", true);
end_Hash.put("tFlowMeterCatcher_1", System.currentTimeMillis());




/**
 * [tFlowMeterCatcher_1 end ] stop
 */

	
	/**
	 * [tMap_2 end ] start
	 */

	

	
	
	currentComponent="tMap_2";

	


// ###############################
// # Lookup hashes releasing
// ###############################      
				log.debug("tMap_2 - Written records count in the table 'copyOfA': " + count_copyOfA_tMap_2 + ".");





			if(execStat){
				if(resourceMap.get("inIterateVComp") == null || !((Boolean)resourceMap.get("inIterateVComp"))){
			 		runStat.updateStatOnConnection("row4"+iterateId,2, 0); 
			 	}
			}
		
 
                if(log.isDebugEnabled())
            log.debug("tMap_2 - "  + ("Done.") );

ok_Hash.put("tMap_2", true);
end_Hash.put("tMap_2", System.currentTimeMillis());




/**
 * [tMap_2 end ] stop
 */

	
	/**
	 * [tPostgresqlOutput_2 end ] start
	 */

	

	
	
	currentComponent="tPostgresqlOutput_2";

	



	    try {
				int countSum_tPostgresqlOutput_2 = 0;
				if (pstmt_tPostgresqlOutput_2 != null && batchSizeCounter_tPostgresqlOutput_2 > 0) {
						
                if(log.isDebugEnabled())
            log.debug("tPostgresqlOutput_2 - "  + ("Executing the ")  + ("INSERT")  + (" batch.") );
					for(int countEach_tPostgresqlOutput_2: pstmt_tPostgresqlOutput_2.executeBatch()) {
						countSum_tPostgresqlOutput_2 += (countEach_tPostgresqlOutput_2 < 0 ? 0 : countEach_tPostgresqlOutput_2);
					}
						
                if(log.isDebugEnabled())
            log.debug("tPostgresqlOutput_2 - "  + ("The ")  + ("INSERT")  + (" batch execution has succeeded.") );
				}
		    	
		    		insertedCount_tPostgresqlOutput_2 += countSum_tPostgresqlOutput_2;
		    	
	    }catch (java.sql.BatchUpdateException e){
	    	
	    	int countSum_tPostgresqlOutput_2 = 0;
			for(int countEach_tPostgresqlOutput_2: e.getUpdateCounts()) {
				countSum_tPostgresqlOutput_2 += (countEach_tPostgresqlOutput_2 < 0 ? 0 : countEach_tPostgresqlOutput_2);
			}
			
	    		insertedCount_tPostgresqlOutput_2 += countSum_tPostgresqlOutput_2;
	    	
            log.error("tPostgresqlOutput_2 - "  + (e.getMessage()) );
	    	System.err.println(e.getMessage());
	    	
		}
	    
        if(pstmt_tPostgresqlOutput_2 != null) {
            pstmt_tPostgresqlOutput_2.close();
        }

			
                if(log.isDebugEnabled())
            log.debug("tPostgresqlOutput_2 - "  + ("Connection starting to commit ")  + (commitCounter_tPostgresqlOutput_2)  + (" record(s).") );
			conn_tPostgresqlOutput_2.commit();
			
                if(log.isDebugEnabled())
            log.debug("tPostgresqlOutput_2 - "  + ("Connection commit has succeeded.") );
		
                if(log.isDebugEnabled())
            log.debug("tPostgresqlOutput_2 - "  + ("Closing the connection to the database.") );
    	conn_tPostgresqlOutput_2 .close();
    	
                if(log.isDebugEnabled())
            log.debug("tPostgresqlOutput_2 - "  + ("Connection to the database has closed.") );
    	resourceMap.put("finish_tPostgresqlOutput_2", true);
    	

	nb_line_deleted_tPostgresqlOutput_2=nb_line_deleted_tPostgresqlOutput_2+ deletedCount_tPostgresqlOutput_2;
	nb_line_update_tPostgresqlOutput_2=nb_line_update_tPostgresqlOutput_2 + updatedCount_tPostgresqlOutput_2;
	nb_line_inserted_tPostgresqlOutput_2=nb_line_inserted_tPostgresqlOutput_2 + insertedCount_tPostgresqlOutput_2;
	nb_line_rejected_tPostgresqlOutput_2=nb_line_rejected_tPostgresqlOutput_2 + rejectedCount_tPostgresqlOutput_2;
	
        globalMap.put("tPostgresqlOutput_2_NB_LINE",nb_line_tPostgresqlOutput_2);
        globalMap.put("tPostgresqlOutput_2_NB_LINE_UPDATED",nb_line_update_tPostgresqlOutput_2);
        globalMap.put("tPostgresqlOutput_2_NB_LINE_INSERTED",nb_line_inserted_tPostgresqlOutput_2);
        globalMap.put("tPostgresqlOutput_2_NB_LINE_DELETED",nb_line_deleted_tPostgresqlOutput_2);
        globalMap.put("tPostgresqlOutput_2_NB_LINE_REJECTED", nb_line_rejected_tPostgresqlOutput_2);
    
	
                if(log.isDebugEnabled())
            log.debug("tPostgresqlOutput_2 - "  + ("Has ")  + ("inserted")  + (" ")  + (nb_line_inserted_tPostgresqlOutput_2)  + (" record(s).") );


			if(execStat){
				if(resourceMap.get("inIterateVComp") == null || !((Boolean)resourceMap.get("inIterateVComp"))){
			 		runStat.updateStatOnConnection("copyOfA"+iterateId,2, 0); 
			 	}
			}
		
 
                if(log.isDebugEnabled())
            log.debug("tPostgresqlOutput_2 - "  + ("Done.") );

ok_Hash.put("tPostgresqlOutput_2", true);
end_Hash.put("tPostgresqlOutput_2", System.currentTimeMillis());




/**
 * [tPostgresqlOutput_2 end ] stop
 */

	
	/**
	 * [tLogRow_1 end ] start
	 */

	

	
	
	currentComponent="tLogRow_1";

	


//////

                    
                    java.io.PrintStream consoleOut_tLogRow_1 = null;
                    if (globalMap.get("tLogRow_CONSOLE")!=null)
                    {
                    	consoleOut_tLogRow_1 = (java.io.PrintStream) globalMap.get("tLogRow_CONSOLE");
                    }
                    else
                    {
                    	consoleOut_tLogRow_1 = new java.io.PrintStream(new java.io.BufferedOutputStream(System.out));
                    	globalMap.put("tLogRow_CONSOLE",consoleOut_tLogRow_1);
                    }
                    
                    consoleOut_tLogRow_1.println(util_tLogRow_1.format().toString());
                    consoleOut_tLogRow_1.flush();
//////
globalMap.put("tLogRow_1_NB_LINE",nb_line_tLogRow_1);
                if(log.isInfoEnabled())
            log.info("tLogRow_1 - "  + ("Printed row count: ")  + (nb_line_tLogRow_1)  + (".") );

///////////////////////    			

			if(execStat){
				if(resourceMap.get("inIterateVComp") == null || !((Boolean)resourceMap.get("inIterateVComp"))){
			 		runStat.updateStatOnConnection("row7"+iterateId,2, 0); 
			 	}
			}
		
 
                if(log.isDebugEnabled())
            log.debug("tLogRow_1 - "  + ("Done.") );

ok_Hash.put("tLogRow_1", true);
end_Hash.put("tLogRow_1", System.currentTimeMillis());




/**
 * [tLogRow_1 end ] stop
 */

	
	/**
	 * [tJavaRow_1 end ] start
	 */

	

	
	
	currentComponent="tJavaRow_1";

	

globalMap.put("tJavaRow_1_NB_LINE",nb_line_tJavaRow_1);
			if(execStat){
				if(resourceMap.get("inIterateVComp") == null || !((Boolean)resourceMap.get("inIterateVComp"))){
			 		runStat.updateStatOnConnection("row8"+iterateId,2, 0); 
			 	}
			}
		
 

ok_Hash.put("tJavaRow_1", true);
end_Hash.put("tJavaRow_1", System.currentTimeMillis());




/**
 * [tJavaRow_1 end ] stop
 */

	
	/**
	 * [tLogRow_2 end ] start
	 */

	

	
	
	currentComponent="tLogRow_2";

	


//////

                    
                    java.io.PrintStream consoleOut_tLogRow_2 = null;
                    if (globalMap.get("tLogRow_CONSOLE")!=null)
                    {
                    	consoleOut_tLogRow_2 = (java.io.PrintStream) globalMap.get("tLogRow_CONSOLE");
                    }
                    else
                    {
                    	consoleOut_tLogRow_2 = new java.io.PrintStream(new java.io.BufferedOutputStream(System.out));
                    	globalMap.put("tLogRow_CONSOLE",consoleOut_tLogRow_2);
                    }
                    
                    consoleOut_tLogRow_2.println(util_tLogRow_2.format().toString());
                    consoleOut_tLogRow_2.flush();
//////
globalMap.put("tLogRow_2_NB_LINE",nb_line_tLogRow_2);
                if(log.isInfoEnabled())
            log.info("tLogRow_2 - "  + ("Printed row count: ")  + (nb_line_tLogRow_2)  + (".") );

///////////////////////    			

			if(execStat){
				if(resourceMap.get("inIterateVComp") == null || !((Boolean)resourceMap.get("inIterateVComp"))){
			 		runStat.updateStatOnConnection("row9"+iterateId,2, 0); 
			 	}
			}
		
 
                if(log.isDebugEnabled())
            log.debug("tLogRow_2 - "  + ("Done.") );

ok_Hash.put("tLogRow_2", true);
end_Hash.put("tLogRow_2", System.currentTimeMillis());

   			if (((String)globalMap.get("flag"))=="N") {
   				
					if(execStat){   
   	 					runStat.updateStatOnConnection("If1", 0, "true");
					}
				
    			tSendMail_1Process(globalMap);
   			}

			   
   				else{
					if(execStat){   
   	 					runStat.updateStatOnConnection("If1", 0, "false");
					}   	 
   				}



/**
 * [tLogRow_2 end ] stop
 */















				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage());
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tFlowMeterCatcher_1 finally ] start
	 */

	

	
	
	currentComponent="tFlowMeterCatcher_1";

	

 



/**
 * [tFlowMeterCatcher_1 finally ] stop
 */

	
	/**
	 * [tMap_2 finally ] start
	 */

	

	
	
	currentComponent="tMap_2";

	

 



/**
 * [tMap_2 finally ] stop
 */

	
	/**
	 * [tPostgresqlOutput_2 finally ] start
	 */

	

	
	
	currentComponent="tPostgresqlOutput_2";

	



	
		if(resourceMap.get("finish_tPostgresqlOutput_2")==null){
			if(resourceMap.get("conn_tPostgresqlOutput_2")!=null){
				try {
					
                if(log.isDebugEnabled())
            log.debug("tPostgresqlOutput_2 - "  + ("Closing the connection to the database.") );
					((java.sql.Connection)resourceMap.get("conn_tPostgresqlOutput_2")).close();
					
                if(log.isDebugEnabled())
            log.debug("tPostgresqlOutput_2 - "  + ("Connection to the database has closed.") );
				} catch (java.sql.SQLException sqlEx_tPostgresqlOutput_2) {
					String errorMessage_tPostgresqlOutput_2 = "failed to close the connection in tPostgresqlOutput_2 :" + sqlEx_tPostgresqlOutput_2.getMessage();
					
            log.error("tPostgresqlOutput_2 - "  + (errorMessage_tPostgresqlOutput_2) );
					System.err.println(errorMessage_tPostgresqlOutput_2);
				}
			}
		}
	

 



/**
 * [tPostgresqlOutput_2 finally ] stop
 */

	
	/**
	 * [tLogRow_1 finally ] start
	 */

	

	
	
	currentComponent="tLogRow_1";

	

 



/**
 * [tLogRow_1 finally ] stop
 */

	
	/**
	 * [tJavaRow_1 finally ] start
	 */

	

	
	
	currentComponent="tJavaRow_1";

	

 



/**
 * [tJavaRow_1 finally ] stop
 */

	
	/**
	 * [tLogRow_2 finally ] start
	 */

	

	
	
	currentComponent="tLogRow_2";

	

 



/**
 * [tLogRow_2 finally ] stop
 */















				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tFlowMeterCatcher_1_SUBPROCESS_STATE", 1);
	}
	

public void tSendMail_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tSendMail_1_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;





	
	/**
	 * [tSendMail_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tSendMail_1", false);
		start_Hash.put("tSendMail_1", System.currentTimeMillis());
		
	
	currentComponent="tSendMail_1";

	
		int tos_count_tSendMail_1 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tSendMail_1 - "  + ("Start to work.") );
    	class BytesLimit65535_tSendMail_1{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tSendMail_1 = new StringBuilder();
            log4jParamters_tSendMail_1.append("Parameters:");
                    log4jParamters_tSendMail_1.append("TO" + " = " + "context.mail");
                log4jParamters_tSendMail_1.append(" | ");
                    log4jParamters_tSendMail_1.append("FROM" + " = " + "\"job_scheduler@talend.com\"");
                log4jParamters_tSendMail_1.append(" | ");
                    log4jParamters_tSendMail_1.append("NEED_PERSONAL_NAME" + " = " + "false");
                log4jParamters_tSendMail_1.append(" | ");
                    log4jParamters_tSendMail_1.append("CC" + " = " + "");
                log4jParamters_tSendMail_1.append(" | ");
                    log4jParamters_tSendMail_1.append("BCC" + " = " + "");
                log4jParamters_tSendMail_1.append(" | ");
                    log4jParamters_tSendMail_1.append("SUBJECT" + " = " + "\"Job Failure: \"+(String)globalMap.get(\"job_name\")");
                log4jParamters_tSendMail_1.append(" | ");
                    log4jParamters_tSendMail_1.append("MESSAGE" + " = " + "\"Hi Team,    The Subjob: \"+(String)globalMap.get(\"job_name\")+\" has failed because of incosistant rowcount between source and target...Please look into this.    Source Table Count: \"+(Integer)globalMap.get(\"source_count\")+\"  Target Table Count: \"+(Integer)globalMap.get(\"target_count\")+\"    Thanks,    Talend Support\"");
                log4jParamters_tSendMail_1.append(" | ");
                    log4jParamters_tSendMail_1.append("CHECK_ATTACHMENT" + " = " + "false");
                log4jParamters_tSendMail_1.append(" | ");
                    log4jParamters_tSendMail_1.append("ATTACHMENTS" + " = " + "[]");
                log4jParamters_tSendMail_1.append(" | ");
                    log4jParamters_tSendMail_1.append("HEADERS" + " = " + "[]");
                log4jParamters_tSendMail_1.append(" | ");
                    log4jParamters_tSendMail_1.append("SMTP_HOST" + " = " + "\"bsemsx01.ae.ge.com\"");
                log4jParamters_tSendMail_1.append(" | ");
                    log4jParamters_tSendMail_1.append("SMTP_PORT" + " = " + "25");
                log4jParamters_tSendMail_1.append(" | ");
                    log4jParamters_tSendMail_1.append("SSL" + " = " + "false");
                log4jParamters_tSendMail_1.append(" | ");
                    log4jParamters_tSendMail_1.append("STARTTLS" + " = " + "false");
                log4jParamters_tSendMail_1.append(" | ");
                    log4jParamters_tSendMail_1.append("IMPORTANCE" + " = " + "Normal");
                log4jParamters_tSendMail_1.append(" | ");
                    log4jParamters_tSendMail_1.append("NEED_AUTH" + " = " + "false");
                log4jParamters_tSendMail_1.append(" | ");
                    log4jParamters_tSendMail_1.append("DIE_ON_ERROR" + " = " + "false");
                log4jParamters_tSendMail_1.append(" | ");
                    log4jParamters_tSendMail_1.append("TEXT_SUBTYPE" + " = " + "plain");
                log4jParamters_tSendMail_1.append(" | ");
                    log4jParamters_tSendMail_1.append("ENCODING" + " = " + "\"ISO-8859-15\"");
                log4jParamters_tSendMail_1.append(" | ");
                    log4jParamters_tSendMail_1.append("SET_LOCALHOST" + " = " + "false");
                log4jParamters_tSendMail_1.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tSendMail_1 - "  + (log4jParamters_tSendMail_1) );
    		}
    	}
    	
        new BytesLimit65535_tSendMail_1().limitLog4jByte();

 



/**
 * [tSendMail_1 begin ] stop
 */
	
	/**
	 * [tSendMail_1 main ] start
	 */

	

	
	
	currentComponent="tSendMail_1";

	

 

	String smtpHost_tSendMail_1 = "bsemsx01.ae.ge.com";
        String smtpPort_tSendMail_1 = "25";
	String from_tSendMail_1 = ("job_scheduler@talend.com");
    String to_tSendMail_1 = (context.mail).replace(";",",");
    String cc_tSendMail_1 = (("")==null || "".equals(""))?null:("").replace(";",",");
    String bcc_tSendMail_1 = (("")==null || "".equals(""))?null:("").replace(";",",");
    String subject_tSendMail_1 = ("Job Failure: "+(String)globalMap.get("job_name"));
    
	java.util.List<java.util.Map<String, String>> headers_tSendMail_1 = new java.util.ArrayList<java.util.Map<String,String>>();
	java.util.List<String> attachments_tSendMail_1 = new java.util.ArrayList<String>();
	java.util.List<String> contentTransferEncoding_tSendMail_1 = new java.util.ArrayList<String>();

	String message_tSendMail_1 = (("Hi Team,\n\nThe Subjob: "+(String)globalMap.get("job_name")+" has failed because of incosistant rowcount between source and target...Please look into this.\n\nSource Table Count: "+(Integer)globalMap.get("source_count")+"\nTarget Table Count: "+(Integer)globalMap.get("target_count")+"\n\nThanks,\n\nTalend Support") == null || "".equals("Hi Team,\n\nThe Subjob: "+(String)globalMap.get("job_name")+" has failed because of incosistant rowcount between source and target...Please look into this.\n\nSource Table Count: "+(Integer)globalMap.get("source_count")+"\nTarget Table Count: "+(Integer)globalMap.get("target_count")+"\n\nThanks,\n\nTalend Support")) ? "\"\"" : ("Hi Team,\n\nThe Subjob: "+(String)globalMap.get("job_name")+" has failed because of incosistant rowcount between source and target...Please look into this.\n\nSource Table Count: "+(Integer)globalMap.get("source_count")+"\nTarget Table Count: "+(Integer)globalMap.get("target_count")+"\n\nThanks,\n\nTalend Support") ;
	java.util.Properties props_tSendMail_1 = System.getProperties();     
	props_tSendMail_1.put("mail.smtp.host", smtpHost_tSendMail_1);
	props_tSendMail_1.put("mail.smtp.port", smtpPort_tSendMail_1);
		props_tSendMail_1.put("mail.mime.encodefilename", "true");     
	try {
		
			log.info("tSendMail_1 - Connection attempt to '" + smtpHost_tSendMail_1 +"'.");
		
		  
			props_tSendMail_1.put("mail.smtp.auth", "false");
			javax.mail.Session session_tSendMail_1 = javax.mail.Session.getInstance(props_tSendMail_1, null);    
		
		
			log.info("tSendMail_1 - Connection to '" + smtpHost_tSendMail_1 + "' has succeeded.");
		
		javax.mail.Message msg_tSendMail_1 = new javax.mail.internet.MimeMessage(session_tSendMail_1);
		msg_tSendMail_1.setFrom(new javax.mail.internet.InternetAddress(from_tSendMail_1, null));
		msg_tSendMail_1.setRecipients(javax.mail.Message.RecipientType.TO,javax.mail.internet.InternetAddress.parse(to_tSendMail_1, false));
		if (cc_tSendMail_1 != null) msg_tSendMail_1.setRecipients(javax.mail.Message.RecipientType.CC, javax.mail.internet.InternetAddress.parse(cc_tSendMail_1, false));
		if (bcc_tSendMail_1 != null) msg_tSendMail_1.setRecipients(javax.mail.Message.RecipientType.BCC, javax.mail.internet.InternetAddress.parse(bcc_tSendMail_1, false));
		msg_tSendMail_1.setSubject(subject_tSendMail_1);

		for (int i_tSendMail_1 = 0; i_tSendMail_1 < headers_tSendMail_1.size(); i_tSendMail_1++) {
			java.util.Map<String, String> header_tSendMail_1 = headers_tSendMail_1.get(i_tSendMail_1);
			msg_tSendMail_1.setHeader(header_tSendMail_1.get("KEY"), header_tSendMail_1.get("VALUE"));    
		}  
		msg_tSendMail_1.setSentDate(new Date());
		msg_tSendMail_1.setHeader("X-Priority", "3"); //High->1 Normal->3 Low->5
		javax.mail.Multipart mp_tSendMail_1 = new javax.mail.internet.MimeMultipart();
		javax.mail.internet.MimeBodyPart mbpText_tSendMail_1 = new javax.mail.internet.MimeBodyPart();
		mbpText_tSendMail_1.setText(message_tSendMail_1,"ISO-8859-15", "plain");
		mp_tSendMail_1.addBodyPart(mbpText_tSendMail_1);
  
		javax.mail.internet.MimeBodyPart mbpFile_tSendMail_1 = null;

		for (int i_tSendMail_1 = 0; i_tSendMail_1 < attachments_tSendMail_1.size(); i_tSendMail_1++){
			String filename_tSendMail_1 = attachments_tSendMail_1.get(i_tSendMail_1);
			javax.activation.FileDataSource fds_tSendMail_1 = null;
			java.io.File file_tSendMail_1 = new java.io.File(filename_tSendMail_1);
			
				if (!file_tSendMail_1.exists()){
					continue;
				}
			
    		if (file_tSendMail_1.isDirectory()){
				java.io.File[] subFiles_tSendMail_1 = file_tSendMail_1.listFiles();
				for(java.io.File subFile_tSendMail_1 : subFiles_tSendMail_1){
					if (subFile_tSendMail_1.isFile()){
						fds_tSendMail_1 = new javax.activation.FileDataSource(subFile_tSendMail_1.getAbsolutePath());
						mbpFile_tSendMail_1 = new javax.mail.internet.MimeBodyPart();
						mbpFile_tSendMail_1.setDataHandler(new javax.activation.DataHandler(fds_tSendMail_1));
						mbpFile_tSendMail_1.setFileName(javax.mail.internet.MimeUtility.encodeText(fds_tSendMail_1.getName()));
						if(contentTransferEncoding_tSendMail_1.get(i_tSendMail_1).equalsIgnoreCase("base64")){
							mbpFile_tSendMail_1.setHeader("Content-Transfer-Encoding", "base64");
						}
						mp_tSendMail_1.addBodyPart(mbpFile_tSendMail_1);
					}
				}
    		}else{
				mbpFile_tSendMail_1 = new javax.mail.internet.MimeBodyPart();
				fds_tSendMail_1 = new javax.activation.FileDataSource(filename_tSendMail_1);
				mbpFile_tSendMail_1.setDataHandler(new javax.activation.DataHandler(fds_tSendMail_1)); 
				mbpFile_tSendMail_1.setFileName(javax.mail.internet.MimeUtility.encodeText(fds_tSendMail_1.getName()));
				if(contentTransferEncoding_tSendMail_1.get(i_tSendMail_1).equalsIgnoreCase("base64")){
					mbpFile_tSendMail_1.setHeader("Content-Transfer-Encoding", "base64");
				}
				mp_tSendMail_1.addBodyPart(mbpFile_tSendMail_1);
			}
		}
		// -- set the content --
		msg_tSendMail_1.setContent(mp_tSendMail_1);
		// add handlers for main MIME types
		javax.activation.MailcapCommandMap mc_tSendMail_1 = ( javax.activation.MailcapCommandMap)javax.activation.CommandMap.getDefaultCommandMap();
		mc_tSendMail_1.addMailcap("text/html;; x-java-content-handler=com.sun.mail.handlers.text_html");
		mc_tSendMail_1.addMailcap("text/xml;; x-java-content-handler=com.sun.mail.handlers.text_xml");
		mc_tSendMail_1.addMailcap("text/plain;; x-java-content-handler=com.sun.mail.handlers.text_plain");
		mc_tSendMail_1.addMailcap("multipart/*;; x-java-content-handler=com.sun.mail.handlers.multipart_mixed");
		mc_tSendMail_1.addMailcap("message/rfc822;; x-java-content-handler=com.sun.mail.handlers.message_rfc822");
		javax.activation.CommandMap.setDefaultCommandMap(mc_tSendMail_1);
		// -- Send the message --
		javax.mail.Transport.send(msg_tSendMail_1);
	} catch(java.lang.Exception e){
  		
			
				log.error("tSendMail_1 - " + e.toString());
			
  			System.err.println(e.toString());
		
	}finally{
		props_tSendMail_1.remove("mail.smtp.host");
		props_tSendMail_1.remove("mail.smtp.port");
		
		props_tSendMail_1.remove("mail.mime.encodefilename");
		
		props_tSendMail_1.remove("mail.smtp.auth");     
	}

 


	tos_count_tSendMail_1++;

/**
 * [tSendMail_1 main ] stop
 */
	
	/**
	 * [tSendMail_1 end ] start
	 */

	

	
	
	currentComponent="tSendMail_1";

	

 
                if(log.isDebugEnabled())
            log.debug("tSendMail_1 - "  + ("Done.") );

ok_Hash.put("tSendMail_1", true);
end_Hash.put("tSendMail_1", System.currentTimeMillis());




/**
 * [tSendMail_1 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage());
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tSendMail_1 finally ] start
	 */

	

	
	
	currentComponent="tSendMail_1";

	

 



/**
 * [tSendMail_1 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tSendMail_1_SUBPROCESS_STATE", 1);
	}
	


public static class row11Struct implements routines.system.IPersistableRow<row11Struct> {
    final static byte[] commonByteArrayLock_OG_APPLICATIONS_J_X_MAN_FINANCE_LAGTIME = new byte[0];
    static byte[] commonByteArray_OG_APPLICATIONS_J_X_MAN_FINANCE_LAGTIME = new byte[0];

	
			    public String job_name;

				public String getJob_name () {
					return this.job_name;
				}
				
			    public java.util.Date start_time;

				public java.util.Date getStart_time () {
					return this.start_time;
				}
				
			    public java.util.Date end_time;

				public java.util.Date getEnd_time () {
					return this.end_time;
				}
				
			    public String source_table_name;

				public String getSource_table_name () {
					return this.source_table_name;
				}
				
			    public Integer source_count;

				public Integer getSource_count () {
					return this.source_count;
				}
				
			    public String target_table_name;

				public String getTarget_table_name () {
					return this.target_table_name;
				}
				
			    public Integer target_count;

				public Integer getTarget_count () {
					return this.target_count;
				}
				
			    public String flag;

				public String getFlag () {
					return this.flag;
				}
				
			    public String sub_job;

				public String getSub_job () {
					return this.sub_job;
				}
				



	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_OG_APPLICATIONS_J_X_MAN_FINANCE_LAGTIME.length) {
				if(length < 1024 && commonByteArray_OG_APPLICATIONS_J_X_MAN_FINANCE_LAGTIME.length == 0) {
   					commonByteArray_OG_APPLICATIONS_J_X_MAN_FINANCE_LAGTIME = new byte[1024];
				} else {
   					commonByteArray_OG_APPLICATIONS_J_X_MAN_FINANCE_LAGTIME = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_OG_APPLICATIONS_J_X_MAN_FINANCE_LAGTIME, 0, length);
			strReturn = new String(commonByteArray_OG_APPLICATIONS_J_X_MAN_FINANCE_LAGTIME, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }

	private java.util.Date readDate(ObjectInputStream dis) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(dis.readLong());
		}
		return dateReturn;
	}

    private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException{
		if(date1 == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeLong(date1.getTime());
    	}
    }
	private Integer readInteger(ObjectInputStream dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}

	private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException{
		if(intNum == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeInt(intNum);
    	}
	}

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_OG_APPLICATIONS_J_X_MAN_FINANCE_LAGTIME) {

        	try {

        		int length = 0;
		
					this.job_name = readString(dis);
					
					this.start_time = readDate(dis);
					
					this.end_time = readDate(dis);
					
					this.source_table_name = readString(dis);
					
						this.source_count = readInteger(dis);
					
					this.target_table_name = readString(dis);
					
						this.target_count = readInteger(dis);
					
					this.flag = readString(dis);
					
					this.sub_job = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// String
				
						writeString(this.job_name,dos);
					
					// java.util.Date
				
						writeDate(this.start_time,dos);
					
					// java.util.Date
				
						writeDate(this.end_time,dos);
					
					// String
				
						writeString(this.source_table_name,dos);
					
					// Integer
				
						writeInteger(this.source_count,dos);
					
					// String
				
						writeString(this.target_table_name,dos);
					
					// Integer
				
						writeInteger(this.target_count,dos);
					
					// String
				
						writeString(this.flag,dos);
					
					// String
				
						writeString(this.sub_job,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("job_name="+job_name);
		sb.append(",start_time="+String.valueOf(start_time));
		sb.append(",end_time="+String.valueOf(end_time));
		sb.append(",source_table_name="+source_table_name);
		sb.append(",source_count="+String.valueOf(source_count));
		sb.append(",target_table_name="+target_table_name);
		sb.append(",target_count="+String.valueOf(target_count));
		sb.append(",flag="+flag);
		sb.append(",sub_job="+sub_job);
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				if(job_name == null){
        					sb.append("<null>");
        				}else{
            				sb.append(job_name);
            			}
            		
        			sb.append("|");
        		
        				if(start_time == null){
        					sb.append("<null>");
        				}else{
            				sb.append(start_time);
            			}
            		
        			sb.append("|");
        		
        				if(end_time == null){
        					sb.append("<null>");
        				}else{
            				sb.append(end_time);
            			}
            		
        			sb.append("|");
        		
        				if(source_table_name == null){
        					sb.append("<null>");
        				}else{
            				sb.append(source_table_name);
            			}
            		
        			sb.append("|");
        		
        				if(source_count == null){
        					sb.append("<null>");
        				}else{
            				sb.append(source_count);
            			}
            		
        			sb.append("|");
        		
        				if(target_table_name == null){
        					sb.append("<null>");
        				}else{
            				sb.append(target_table_name);
            			}
            		
        			sb.append("|");
        		
        				if(target_count == null){
        					sb.append("<null>");
        				}else{
            				sb.append(target_count);
            			}
            		
        			sb.append("|");
        		
        				if(flag == null){
        					sb.append("<null>");
        				}else{
            				sb.append(flag);
            			}
            		
        			sb.append("|");
        		
        				if(sub_job == null){
        					sb.append("<null>");
        				}else{
            				sb.append(sub_job);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(row11Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public static class row10Struct implements routines.system.IPersistableRow<row10Struct> {
    final static byte[] commonByteArrayLock_OG_APPLICATIONS_J_X_MAN_FINANCE_LAGTIME = new byte[0];
    static byte[] commonByteArray_OG_APPLICATIONS_J_X_MAN_FINANCE_LAGTIME = new byte[0];

	
			    public String job_name;

				public String getJob_name () {
					return this.job_name;
				}
				
			    public java.util.Date start_time;

				public java.util.Date getStart_time () {
					return this.start_time;
				}
				
			    public java.util.Date end_time;

				public java.util.Date getEnd_time () {
					return this.end_time;
				}
				
			    public String source_table_name;

				public String getSource_table_name () {
					return this.source_table_name;
				}
				
			    public Integer source_count;

				public Integer getSource_count () {
					return this.source_count;
				}
				
			    public String target_table_name;

				public String getTarget_table_name () {
					return this.target_table_name;
				}
				
			    public Integer target_count;

				public Integer getTarget_count () {
					return this.target_count;
				}
				
			    public String flag;

				public String getFlag () {
					return this.flag;
				}
				
			    public String sub_job;

				public String getSub_job () {
					return this.sub_job;
				}
				



	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_OG_APPLICATIONS_J_X_MAN_FINANCE_LAGTIME.length) {
				if(length < 1024 && commonByteArray_OG_APPLICATIONS_J_X_MAN_FINANCE_LAGTIME.length == 0) {
   					commonByteArray_OG_APPLICATIONS_J_X_MAN_FINANCE_LAGTIME = new byte[1024];
				} else {
   					commonByteArray_OG_APPLICATIONS_J_X_MAN_FINANCE_LAGTIME = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_OG_APPLICATIONS_J_X_MAN_FINANCE_LAGTIME, 0, length);
			strReturn = new String(commonByteArray_OG_APPLICATIONS_J_X_MAN_FINANCE_LAGTIME, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }

	private java.util.Date readDate(ObjectInputStream dis) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(dis.readLong());
		}
		return dateReturn;
	}

    private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException{
		if(date1 == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeLong(date1.getTime());
    	}
    }
	private Integer readInteger(ObjectInputStream dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}

	private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException{
		if(intNum == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeInt(intNum);
    	}
	}

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_OG_APPLICATIONS_J_X_MAN_FINANCE_LAGTIME) {

        	try {

        		int length = 0;
		
					this.job_name = readString(dis);
					
					this.start_time = readDate(dis);
					
					this.end_time = readDate(dis);
					
					this.source_table_name = readString(dis);
					
						this.source_count = readInteger(dis);
					
					this.target_table_name = readString(dis);
					
						this.target_count = readInteger(dis);
					
					this.flag = readString(dis);
					
					this.sub_job = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// String
				
						writeString(this.job_name,dos);
					
					// java.util.Date
				
						writeDate(this.start_time,dos);
					
					// java.util.Date
				
						writeDate(this.end_time,dos);
					
					// String
				
						writeString(this.source_table_name,dos);
					
					// Integer
				
						writeInteger(this.source_count,dos);
					
					// String
				
						writeString(this.target_table_name,dos);
					
					// Integer
				
						writeInteger(this.target_count,dos);
					
					// String
				
						writeString(this.flag,dos);
					
					// String
				
						writeString(this.sub_job,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("job_name="+job_name);
		sb.append(",start_time="+String.valueOf(start_time));
		sb.append(",end_time="+String.valueOf(end_time));
		sb.append(",source_table_name="+source_table_name);
		sb.append(",source_count="+String.valueOf(source_count));
		sb.append(",target_table_name="+target_table_name);
		sb.append(",target_count="+String.valueOf(target_count));
		sb.append(",flag="+flag);
		sb.append(",sub_job="+sub_job);
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				if(job_name == null){
        					sb.append("<null>");
        				}else{
            				sb.append(job_name);
            			}
            		
        			sb.append("|");
        		
        				if(start_time == null){
        					sb.append("<null>");
        				}else{
            				sb.append(start_time);
            			}
            		
        			sb.append("|");
        		
        				if(end_time == null){
        					sb.append("<null>");
        				}else{
            				sb.append(end_time);
            			}
            		
        			sb.append("|");
        		
        				if(source_table_name == null){
        					sb.append("<null>");
        				}else{
            				sb.append(source_table_name);
            			}
            		
        			sb.append("|");
        		
        				if(source_count == null){
        					sb.append("<null>");
        				}else{
            				sb.append(source_count);
            			}
            		
        			sb.append("|");
        		
        				if(target_table_name == null){
        					sb.append("<null>");
        				}else{
            				sb.append(target_table_name);
            			}
            		
        			sb.append("|");
        		
        				if(target_count == null){
        					sb.append("<null>");
        				}else{
            				sb.append(target_count);
            			}
            		
        			sb.append("|");
        		
        				if(flag == null){
        					sb.append("<null>");
        				}else{
            				sb.append(flag);
            			}
            		
        			sb.append("|");
        		
        				if(sub_job == null){
        					sb.append("<null>");
        				}else{
            				sb.append(sub_job);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(row10Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public static class row6Struct implements routines.system.IPersistableRow<row6Struct> {
    final static byte[] commonByteArrayLock_OG_APPLICATIONS_J_X_MAN_FINANCE_LAGTIME = new byte[0];
    static byte[] commonByteArray_OG_APPLICATIONS_J_X_MAN_FINANCE_LAGTIME = new byte[0];

	
			    public String job_name;

				public String getJob_name () {
					return this.job_name;
				}
				
			    public java.util.Date start_time;

				public java.util.Date getStart_time () {
					return this.start_time;
				}
				
			    public java.util.Date end_time;

				public java.util.Date getEnd_time () {
					return this.end_time;
				}
				
			    public String source_table_name;

				public String getSource_table_name () {
					return this.source_table_name;
				}
				
			    public Integer source_count;

				public Integer getSource_count () {
					return this.source_count;
				}
				
			    public String target_table_name;

				public String getTarget_table_name () {
					return this.target_table_name;
				}
				
			    public Integer target_count;

				public Integer getTarget_count () {
					return this.target_count;
				}
				
			    public String flag;

				public String getFlag () {
					return this.flag;
				}
				
			    public String sub_job;

				public String getSub_job () {
					return this.sub_job;
				}
				



	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_OG_APPLICATIONS_J_X_MAN_FINANCE_LAGTIME.length) {
				if(length < 1024 && commonByteArray_OG_APPLICATIONS_J_X_MAN_FINANCE_LAGTIME.length == 0) {
   					commonByteArray_OG_APPLICATIONS_J_X_MAN_FINANCE_LAGTIME = new byte[1024];
				} else {
   					commonByteArray_OG_APPLICATIONS_J_X_MAN_FINANCE_LAGTIME = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_OG_APPLICATIONS_J_X_MAN_FINANCE_LAGTIME, 0, length);
			strReturn = new String(commonByteArray_OG_APPLICATIONS_J_X_MAN_FINANCE_LAGTIME, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }

	private java.util.Date readDate(ObjectInputStream dis) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(dis.readLong());
		}
		return dateReturn;
	}

    private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException{
		if(date1 == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeLong(date1.getTime());
    	}
    }
	private Integer readInteger(ObjectInputStream dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}

	private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException{
		if(intNum == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeInt(intNum);
    	}
	}

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_OG_APPLICATIONS_J_X_MAN_FINANCE_LAGTIME) {

        	try {

        		int length = 0;
		
					this.job_name = readString(dis);
					
					this.start_time = readDate(dis);
					
					this.end_time = readDate(dis);
					
					this.source_table_name = readString(dis);
					
						this.source_count = readInteger(dis);
					
					this.target_table_name = readString(dis);
					
						this.target_count = readInteger(dis);
					
					this.flag = readString(dis);
					
					this.sub_job = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// String
				
						writeString(this.job_name,dos);
					
					// java.util.Date
				
						writeDate(this.start_time,dos);
					
					// java.util.Date
				
						writeDate(this.end_time,dos);
					
					// String
				
						writeString(this.source_table_name,dos);
					
					// Integer
				
						writeInteger(this.source_count,dos);
					
					// String
				
						writeString(this.target_table_name,dos);
					
					// Integer
				
						writeInteger(this.target_count,dos);
					
					// String
				
						writeString(this.flag,dos);
					
					// String
				
						writeString(this.sub_job,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("job_name="+job_name);
		sb.append(",start_time="+String.valueOf(start_time));
		sb.append(",end_time="+String.valueOf(end_time));
		sb.append(",source_table_name="+source_table_name);
		sb.append(",source_count="+String.valueOf(source_count));
		sb.append(",target_table_name="+target_table_name);
		sb.append(",target_count="+String.valueOf(target_count));
		sb.append(",flag="+flag);
		sb.append(",sub_job="+sub_job);
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				if(job_name == null){
        					sb.append("<null>");
        				}else{
            				sb.append(job_name);
            			}
            		
        			sb.append("|");
        		
        				if(start_time == null){
        					sb.append("<null>");
        				}else{
            				sb.append(start_time);
            			}
            		
        			sb.append("|");
        		
        				if(end_time == null){
        					sb.append("<null>");
        				}else{
            				sb.append(end_time);
            			}
            		
        			sb.append("|");
        		
        				if(source_table_name == null){
        					sb.append("<null>");
        				}else{
            				sb.append(source_table_name);
            			}
            		
        			sb.append("|");
        		
        				if(source_count == null){
        					sb.append("<null>");
        				}else{
            				sb.append(source_count);
            			}
            		
        			sb.append("|");
        		
        				if(target_table_name == null){
        					sb.append("<null>");
        				}else{
            				sb.append(target_table_name);
            			}
            		
        			sb.append("|");
        		
        				if(target_count == null){
        					sb.append("<null>");
        				}else{
            				sb.append(target_count);
            			}
            		
        			sb.append("|");
        		
        				if(flag == null){
        					sb.append("<null>");
        				}else{
            				sb.append(flag);
            			}
            		
        			sb.append("|");
        		
        				if(sub_job == null){
        					sb.append("<null>");
        				}else{
            				sb.append(sub_job);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(row6Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public static class copyOfoutStruct implements routines.system.IPersistableRow<copyOfoutStruct> {
    final static byte[] commonByteArrayLock_OG_APPLICATIONS_J_X_MAN_FINANCE_LAGTIME = new byte[0];
    static byte[] commonByteArray_OG_APPLICATIONS_J_X_MAN_FINANCE_LAGTIME = new byte[0];

	
			    public String job_name;

				public String getJob_name () {
					return this.job_name;
				}
				
			    public java.util.Date start_time;

				public java.util.Date getStart_time () {
					return this.start_time;
				}
				
			    public java.util.Date end_time;

				public java.util.Date getEnd_time () {
					return this.end_time;
				}
				
			    public String source_table_name;

				public String getSource_table_name () {
					return this.source_table_name;
				}
				
			    public Integer source_count;

				public Integer getSource_count () {
					return this.source_count;
				}
				
			    public String target_table_name;

				public String getTarget_table_name () {
					return this.target_table_name;
				}
				
			    public Integer target_count;

				public Integer getTarget_count () {
					return this.target_count;
				}
				
			    public String flag;

				public String getFlag () {
					return this.flag;
				}
				
			    public String sub_job;

				public String getSub_job () {
					return this.sub_job;
				}
				



	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_OG_APPLICATIONS_J_X_MAN_FINANCE_LAGTIME.length) {
				if(length < 1024 && commonByteArray_OG_APPLICATIONS_J_X_MAN_FINANCE_LAGTIME.length == 0) {
   					commonByteArray_OG_APPLICATIONS_J_X_MAN_FINANCE_LAGTIME = new byte[1024];
				} else {
   					commonByteArray_OG_APPLICATIONS_J_X_MAN_FINANCE_LAGTIME = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_OG_APPLICATIONS_J_X_MAN_FINANCE_LAGTIME, 0, length);
			strReturn = new String(commonByteArray_OG_APPLICATIONS_J_X_MAN_FINANCE_LAGTIME, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }

	private java.util.Date readDate(ObjectInputStream dis) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(dis.readLong());
		}
		return dateReturn;
	}

    private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException{
		if(date1 == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeLong(date1.getTime());
    	}
    }
	private Integer readInteger(ObjectInputStream dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}

	private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException{
		if(intNum == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeInt(intNum);
    	}
	}

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_OG_APPLICATIONS_J_X_MAN_FINANCE_LAGTIME) {

        	try {

        		int length = 0;
		
					this.job_name = readString(dis);
					
					this.start_time = readDate(dis);
					
					this.end_time = readDate(dis);
					
					this.source_table_name = readString(dis);
					
						this.source_count = readInteger(dis);
					
					this.target_table_name = readString(dis);
					
						this.target_count = readInteger(dis);
					
					this.flag = readString(dis);
					
					this.sub_job = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// String
				
						writeString(this.job_name,dos);
					
					// java.util.Date
				
						writeDate(this.start_time,dos);
					
					// java.util.Date
				
						writeDate(this.end_time,dos);
					
					// String
				
						writeString(this.source_table_name,dos);
					
					// Integer
				
						writeInteger(this.source_count,dos);
					
					// String
				
						writeString(this.target_table_name,dos);
					
					// Integer
				
						writeInteger(this.target_count,dos);
					
					// String
				
						writeString(this.flag,dos);
					
					// String
				
						writeString(this.sub_job,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("job_name="+job_name);
		sb.append(",start_time="+String.valueOf(start_time));
		sb.append(",end_time="+String.valueOf(end_time));
		sb.append(",source_table_name="+source_table_name);
		sb.append(",source_count="+String.valueOf(source_count));
		sb.append(",target_table_name="+target_table_name);
		sb.append(",target_count="+String.valueOf(target_count));
		sb.append(",flag="+flag);
		sb.append(",sub_job="+sub_job);
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				if(job_name == null){
        					sb.append("<null>");
        				}else{
            				sb.append(job_name);
            			}
            		
        			sb.append("|");
        		
        				if(start_time == null){
        					sb.append("<null>");
        				}else{
            				sb.append(start_time);
            			}
            		
        			sb.append("|");
        		
        				if(end_time == null){
        					sb.append("<null>");
        				}else{
            				sb.append(end_time);
            			}
            		
        			sb.append("|");
        		
        				if(source_table_name == null){
        					sb.append("<null>");
        				}else{
            				sb.append(source_table_name);
            			}
            		
        			sb.append("|");
        		
        				if(source_count == null){
        					sb.append("<null>");
        				}else{
            				sb.append(source_count);
            			}
            		
        			sb.append("|");
        		
        				if(target_table_name == null){
        					sb.append("<null>");
        				}else{
            				sb.append(target_table_name);
            			}
            		
        			sb.append("|");
        		
        				if(target_count == null){
        					sb.append("<null>");
        				}else{
            				sb.append(target_count);
            			}
            		
        			sb.append("|");
        		
        				if(flag == null){
        					sb.append("<null>");
        				}else{
            				sb.append(flag);
            			}
            		
        			sb.append("|");
        		
        				if(sub_job == null){
        					sb.append("<null>");
        				}else{
            				sb.append(sub_job);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(copyOfoutStruct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public static class row3Struct implements routines.system.IPersistableRow<row3Struct> {
    final static byte[] commonByteArrayLock_OG_APPLICATIONS_J_X_MAN_FINANCE_LAGTIME = new byte[0];
    static byte[] commonByteArray_OG_APPLICATIONS_J_X_MAN_FINANCE_LAGTIME = new byte[0];

	
			    public java.util.Date moment;

				public java.util.Date getMoment () {
					return this.moment;
				}
				
			    public String pid;

				public String getPid () {
					return this.pid;
				}
				
			    public String root_pid;

				public String getRoot_pid () {
					return this.root_pid;
				}
				
			    public String father_pid;

				public String getFather_pid () {
					return this.father_pid;
				}
				
			    public String project;

				public String getProject () {
					return this.project;
				}
				
			    public String job;

				public String getJob () {
					return this.job;
				}
				
			    public String context;

				public String getContext () {
					return this.context;
				}
				
			    public Integer priority;

				public Integer getPriority () {
					return this.priority;
				}
				
			    public String type;

				public String getType () {
					return this.type;
				}
				
			    public String origin;

				public String getOrigin () {
					return this.origin;
				}
				
			    public String message;

				public String getMessage () {
					return this.message;
				}
				
			    public Integer code;

				public Integer getCode () {
					return this.code;
				}
				



	private java.util.Date readDate(ObjectInputStream dis) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(dis.readLong());
		}
		return dateReturn;
	}

    private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException{
		if(date1 == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeLong(date1.getTime());
    	}
    }

	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_OG_APPLICATIONS_J_X_MAN_FINANCE_LAGTIME.length) {
				if(length < 1024 && commonByteArray_OG_APPLICATIONS_J_X_MAN_FINANCE_LAGTIME.length == 0) {
   					commonByteArray_OG_APPLICATIONS_J_X_MAN_FINANCE_LAGTIME = new byte[1024];
				} else {
   					commonByteArray_OG_APPLICATIONS_J_X_MAN_FINANCE_LAGTIME = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_OG_APPLICATIONS_J_X_MAN_FINANCE_LAGTIME, 0, length);
			strReturn = new String(commonByteArray_OG_APPLICATIONS_J_X_MAN_FINANCE_LAGTIME, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
	private Integer readInteger(ObjectInputStream dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}

	private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException{
		if(intNum == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeInt(intNum);
    	}
	}

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_OG_APPLICATIONS_J_X_MAN_FINANCE_LAGTIME) {

        	try {

        		int length = 0;
		
					this.moment = readDate(dis);
					
					this.pid = readString(dis);
					
					this.root_pid = readString(dis);
					
					this.father_pid = readString(dis);
					
					this.project = readString(dis);
					
					this.job = readString(dis);
					
					this.context = readString(dis);
					
						this.priority = readInteger(dis);
					
					this.type = readString(dis);
					
					this.origin = readString(dis);
					
					this.message = readString(dis);
					
						this.code = readInteger(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// java.util.Date
				
						writeDate(this.moment,dos);
					
					// String
				
						writeString(this.pid,dos);
					
					// String
				
						writeString(this.root_pid,dos);
					
					// String
				
						writeString(this.father_pid,dos);
					
					// String
				
						writeString(this.project,dos);
					
					// String
				
						writeString(this.job,dos);
					
					// String
				
						writeString(this.context,dos);
					
					// Integer
				
						writeInteger(this.priority,dos);
					
					// String
				
						writeString(this.type,dos);
					
					// String
				
						writeString(this.origin,dos);
					
					// String
				
						writeString(this.message,dos);
					
					// Integer
				
						writeInteger(this.code,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("moment="+String.valueOf(moment));
		sb.append(",pid="+pid);
		sb.append(",root_pid="+root_pid);
		sb.append(",father_pid="+father_pid);
		sb.append(",project="+project);
		sb.append(",job="+job);
		sb.append(",context="+context);
		sb.append(",priority="+String.valueOf(priority));
		sb.append(",type="+type);
		sb.append(",origin="+origin);
		sb.append(",message="+message);
		sb.append(",code="+String.valueOf(code));
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				if(moment == null){
        					sb.append("<null>");
        				}else{
            				sb.append(moment);
            			}
            		
        			sb.append("|");
        		
        				if(pid == null){
        					sb.append("<null>");
        				}else{
            				sb.append(pid);
            			}
            		
        			sb.append("|");
        		
        				if(root_pid == null){
        					sb.append("<null>");
        				}else{
            				sb.append(root_pid);
            			}
            		
        			sb.append("|");
        		
        				if(father_pid == null){
        					sb.append("<null>");
        				}else{
            				sb.append(father_pid);
            			}
            		
        			sb.append("|");
        		
        				if(project == null){
        					sb.append("<null>");
        				}else{
            				sb.append(project);
            			}
            		
        			sb.append("|");
        		
        				if(job == null){
        					sb.append("<null>");
        				}else{
            				sb.append(job);
            			}
            		
        			sb.append("|");
        		
        				if(context == null){
        					sb.append("<null>");
        				}else{
            				sb.append(context);
            			}
            		
        			sb.append("|");
        		
        				if(priority == null){
        					sb.append("<null>");
        				}else{
            				sb.append(priority);
            			}
            		
        			sb.append("|");
        		
        				if(type == null){
        					sb.append("<null>");
        				}else{
            				sb.append(type);
            			}
            		
        			sb.append("|");
        		
        				if(origin == null){
        					sb.append("<null>");
        				}else{
            				sb.append(origin);
            			}
            		
        			sb.append("|");
        		
        				if(message == null){
        					sb.append("<null>");
        				}else{
            				sb.append(message);
            			}
            		
        			sb.append("|");
        		
        				if(code == null){
        					sb.append("<null>");
        				}else{
            				sb.append(code);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(row3Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public static class row5Struct implements routines.system.IPersistableRow<row5Struct> {
    final static byte[] commonByteArrayLock_OG_APPLICATIONS_J_X_MAN_FINANCE_LAGTIME = new byte[0];
    static byte[] commonByteArray_OG_APPLICATIONS_J_X_MAN_FINANCE_LAGTIME = new byte[0];

	
			    public java.util.Date moment;

				public java.util.Date getMoment () {
					return this.moment;
				}
				
			    public String pid;

				public String getPid () {
					return this.pid;
				}
				
			    public String root_pid;

				public String getRoot_pid () {
					return this.root_pid;
				}
				
			    public String father_pid;

				public String getFather_pid () {
					return this.father_pid;
				}
				
			    public String project;

				public String getProject () {
					return this.project;
				}
				
			    public String job;

				public String getJob () {
					return this.job;
				}
				
			    public String context;

				public String getContext () {
					return this.context;
				}
				
			    public Integer priority;

				public Integer getPriority () {
					return this.priority;
				}
				
			    public String type;

				public String getType () {
					return this.type;
				}
				
			    public String origin;

				public String getOrigin () {
					return this.origin;
				}
				
			    public String message;

				public String getMessage () {
					return this.message;
				}
				
			    public Integer code;

				public Integer getCode () {
					return this.code;
				}
				



	private java.util.Date readDate(ObjectInputStream dis) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(dis.readLong());
		}
		return dateReturn;
	}

    private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException{
		if(date1 == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeLong(date1.getTime());
    	}
    }

	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_OG_APPLICATIONS_J_X_MAN_FINANCE_LAGTIME.length) {
				if(length < 1024 && commonByteArray_OG_APPLICATIONS_J_X_MAN_FINANCE_LAGTIME.length == 0) {
   					commonByteArray_OG_APPLICATIONS_J_X_MAN_FINANCE_LAGTIME = new byte[1024];
				} else {
   					commonByteArray_OG_APPLICATIONS_J_X_MAN_FINANCE_LAGTIME = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_OG_APPLICATIONS_J_X_MAN_FINANCE_LAGTIME, 0, length);
			strReturn = new String(commonByteArray_OG_APPLICATIONS_J_X_MAN_FINANCE_LAGTIME, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
	private Integer readInteger(ObjectInputStream dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}

	private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException{
		if(intNum == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeInt(intNum);
    	}
	}

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_OG_APPLICATIONS_J_X_MAN_FINANCE_LAGTIME) {

        	try {

        		int length = 0;
		
					this.moment = readDate(dis);
					
					this.pid = readString(dis);
					
					this.root_pid = readString(dis);
					
					this.father_pid = readString(dis);
					
					this.project = readString(dis);
					
					this.job = readString(dis);
					
					this.context = readString(dis);
					
						this.priority = readInteger(dis);
					
					this.type = readString(dis);
					
					this.origin = readString(dis);
					
					this.message = readString(dis);
					
						this.code = readInteger(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// java.util.Date
				
						writeDate(this.moment,dos);
					
					// String
				
						writeString(this.pid,dos);
					
					// String
				
						writeString(this.root_pid,dos);
					
					// String
				
						writeString(this.father_pid,dos);
					
					// String
				
						writeString(this.project,dos);
					
					// String
				
						writeString(this.job,dos);
					
					// String
				
						writeString(this.context,dos);
					
					// Integer
				
						writeInteger(this.priority,dos);
					
					// String
				
						writeString(this.type,dos);
					
					// String
				
						writeString(this.origin,dos);
					
					// String
				
						writeString(this.message,dos);
					
					// Integer
				
						writeInteger(this.code,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("moment="+String.valueOf(moment));
		sb.append(",pid="+pid);
		sb.append(",root_pid="+root_pid);
		sb.append(",father_pid="+father_pid);
		sb.append(",project="+project);
		sb.append(",job="+job);
		sb.append(",context="+context);
		sb.append(",priority="+String.valueOf(priority));
		sb.append(",type="+type);
		sb.append(",origin="+origin);
		sb.append(",message="+message);
		sb.append(",code="+String.valueOf(code));
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				if(moment == null){
        					sb.append("<null>");
        				}else{
            				sb.append(moment);
            			}
            		
        			sb.append("|");
        		
        				if(pid == null){
        					sb.append("<null>");
        				}else{
            				sb.append(pid);
            			}
            		
        			sb.append("|");
        		
        				if(root_pid == null){
        					sb.append("<null>");
        				}else{
            				sb.append(root_pid);
            			}
            		
        			sb.append("|");
        		
        				if(father_pid == null){
        					sb.append("<null>");
        				}else{
            				sb.append(father_pid);
            			}
            		
        			sb.append("|");
        		
        				if(project == null){
        					sb.append("<null>");
        				}else{
            				sb.append(project);
            			}
            		
        			sb.append("|");
        		
        				if(job == null){
        					sb.append("<null>");
        				}else{
            				sb.append(job);
            			}
            		
        			sb.append("|");
        		
        				if(context == null){
        					sb.append("<null>");
        				}else{
            				sb.append(context);
            			}
            		
        			sb.append("|");
        		
        				if(priority == null){
        					sb.append("<null>");
        				}else{
            				sb.append(priority);
            			}
            		
        			sb.append("|");
        		
        				if(type == null){
        					sb.append("<null>");
        				}else{
            				sb.append(type);
            			}
            		
        			sb.append("|");
        		
        				if(origin == null){
        					sb.append("<null>");
        				}else{
            				sb.append(origin);
            			}
            		
        			sb.append("|");
        		
        				if(message == null){
        					sb.append("<null>");
        				}else{
            				sb.append(message);
            			}
            		
        			sb.append("|");
        		
        				if(code == null){
        					sb.append("<null>");
        				}else{
            				sb.append(code);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(row5Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}
public void tLogCatcher_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tLogCatcher_1_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;



		row5Struct row5 = new row5Struct();
row5Struct row3 = row5;
copyOfoutStruct copyOfout = new copyOfoutStruct();
row6Struct row6 = new row6Struct();
row6Struct row10 = row6;
row11Struct row11 = new row11Struct();









	
	/**
	 * [tSendMail_2 begin ] start
	 */

	

	
		
		ok_Hash.put("tSendMail_2", false);
		start_Hash.put("tSendMail_2", System.currentTimeMillis());
		
	
	currentComponent="tSendMail_2";

	
			if (execStat) {
				if(resourceMap.get("inIterateVComp") == null){
					
						runStat.updateStatOnConnection("row11" + iterateId, 0, 0);
					
				}
			} 

		
		int tos_count_tSendMail_2 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tSendMail_2 - "  + ("Start to work.") );
    	class BytesLimit65535_tSendMail_2{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tSendMail_2 = new StringBuilder();
            log4jParamters_tSendMail_2.append("Parameters:");
                    log4jParamters_tSendMail_2.append("TO" + " = " + "context.mail");
                log4jParamters_tSendMail_2.append(" | ");
                    log4jParamters_tSendMail_2.append("FROM" + " = " + "\"job_scheduler@talend.com\"");
                log4jParamters_tSendMail_2.append(" | ");
                    log4jParamters_tSendMail_2.append("NEED_PERSONAL_NAME" + " = " + "false");
                log4jParamters_tSendMail_2.append(" | ");
                    log4jParamters_tSendMail_2.append("CC" + " = " + "");
                log4jParamters_tSendMail_2.append(" | ");
                    log4jParamters_tSendMail_2.append("BCC" + " = " + "");
                log4jParamters_tSendMail_2.append(" | ");
                    log4jParamters_tSendMail_2.append("SUBJECT" + " = " + "\"Job Failure: \"+(String)globalMap.get(\"job_name\")");
                log4jParamters_tSendMail_2.append(" | ");
                    log4jParamters_tSendMail_2.append("MESSAGE" + " = " + "\"Hi team,    A job has failed with the following details:    Job Name: \"+(String)globalMap.get(\"Master_job\")+\"  Sub Job Name:  \"+(String)globalMap.get(\"job_name\")+\"  Error code:  \"+(String)globalMap.get(\"error_code\")+\"   Time of Failure:  \"+(Date)globalMap.get(\"error_time\")+\"      Thanks,    Talend Support\"");
                log4jParamters_tSendMail_2.append(" | ");
                    log4jParamters_tSendMail_2.append("CHECK_ATTACHMENT" + " = " + "false");
                log4jParamters_tSendMail_2.append(" | ");
                    log4jParamters_tSendMail_2.append("ATTACHMENTS" + " = " + "[]");
                log4jParamters_tSendMail_2.append(" | ");
                    log4jParamters_tSendMail_2.append("HEADERS" + " = " + "[]");
                log4jParamters_tSendMail_2.append(" | ");
                    log4jParamters_tSendMail_2.append("SMTP_HOST" + " = " + "\"bsemsx01.ae.ge.com\"");
                log4jParamters_tSendMail_2.append(" | ");
                    log4jParamters_tSendMail_2.append("SMTP_PORT" + " = " + "25");
                log4jParamters_tSendMail_2.append(" | ");
                    log4jParamters_tSendMail_2.append("SSL" + " = " + "false");
                log4jParamters_tSendMail_2.append(" | ");
                    log4jParamters_tSendMail_2.append("STARTTLS" + " = " + "false");
                log4jParamters_tSendMail_2.append(" | ");
                    log4jParamters_tSendMail_2.append("IMPORTANCE" + " = " + "Normal");
                log4jParamters_tSendMail_2.append(" | ");
                    log4jParamters_tSendMail_2.append("NEED_AUTH" + " = " + "false");
                log4jParamters_tSendMail_2.append(" | ");
                    log4jParamters_tSendMail_2.append("DIE_ON_ERROR" + " = " + "false");
                log4jParamters_tSendMail_2.append(" | ");
                    log4jParamters_tSendMail_2.append("TEXT_SUBTYPE" + " = " + "plain");
                log4jParamters_tSendMail_2.append(" | ");
                    log4jParamters_tSendMail_2.append("ENCODING" + " = " + "\"ISO-8859-15\"");
                log4jParamters_tSendMail_2.append(" | ");
                    log4jParamters_tSendMail_2.append("SET_LOCALHOST" + " = " + "false");
                log4jParamters_tSendMail_2.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tSendMail_2 - "  + (log4jParamters_tSendMail_2) );
    		}
    	}
    	
        new BytesLimit65535_tSendMail_2().limitLog4jByte();

 



/**
 * [tSendMail_2 begin ] stop
 */



	
	/**
	 * [tJavaRow_2 begin ] start
	 */

	

	
		
		ok_Hash.put("tJavaRow_2", false);
		start_Hash.put("tJavaRow_2", System.currentTimeMillis());
		
	
	currentComponent="tJavaRow_2";

	
			if (execStat) {
				if(resourceMap.get("inIterateVComp") == null){
					
						runStat.updateStatOnConnection("row10" + iterateId, 0, 0);
					
				}
			} 

		
		int tos_count_tJavaRow_2 = 0;
		
    	class BytesLimit65535_tJavaRow_2{
    		public void limitLog4jByte() throws Exception{
    			
    		}
    	}
    	
        new BytesLimit65535_tJavaRow_2().limitLog4jByte();

int nb_line_tJavaRow_2 = 0;

 



/**
 * [tJavaRow_2 begin ] stop
 */



	
	/**
	 * [tLogRow_4 begin ] start
	 */

	

	
		
		ok_Hash.put("tLogRow_4", false);
		start_Hash.put("tLogRow_4", System.currentTimeMillis());
		
	
	currentComponent="tLogRow_4";

	
			if (execStat) {
				if(resourceMap.get("inIterateVComp") == null){
					
						runStat.updateStatOnConnection("row6" + iterateId, 0, 0);
					
				}
			} 

		
		int tos_count_tLogRow_4 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tLogRow_4 - "  + ("Start to work.") );
    	class BytesLimit65535_tLogRow_4{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tLogRow_4 = new StringBuilder();
            log4jParamters_tLogRow_4.append("Parameters:");
                    log4jParamters_tLogRow_4.append("BASIC_MODE" + " = " + "false");
                log4jParamters_tLogRow_4.append(" | ");
                    log4jParamters_tLogRow_4.append("TABLE_PRINT" + " = " + "true");
                log4jParamters_tLogRow_4.append(" | ");
                    log4jParamters_tLogRow_4.append("VERTICAL" + " = " + "false");
                log4jParamters_tLogRow_4.append(" | ");
                    log4jParamters_tLogRow_4.append("PRINT_CONTENT_WITH_LOG4J" + " = " + "false");
                log4jParamters_tLogRow_4.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tLogRow_4 - "  + (log4jParamters_tLogRow_4) );
    		}
    	}
    	
        new BytesLimit65535_tLogRow_4().limitLog4jByte();

	///////////////////////
	
         class Util_tLogRow_4 {

        String[] des_top = { ".", ".", "-", "+" };

        String[] des_head = { "|=", "=|", "-", "+" };

        String[] des_bottom = { "'", "'", "-", "+" };

        String name="";

        java.util.List<String[]> list = new java.util.ArrayList<String[]>();

        int[] colLengths = new int[9];

        public void addRow(String[] row) {

            for (int i = 0; i < 9; i++) {
                if (row[i]!=null) {
                  colLengths[i] = Math.max(colLengths[i], row[i].length());
                }
            }
            list.add(row);
        }

        public void setTableName(String name) {

            this.name = name;
        }

            public StringBuilder format() {
            
                StringBuilder sb = new StringBuilder();
  
            
                    sb.append(print(des_top));
    
                    int totals = 0;
                    for (int i = 0; i < colLengths.length; i++) {
                        totals = totals + colLengths[i];
                    }
    
                    // name
                    sb.append("|");
                    int k = 0;
                    for (k = 0; k < (totals + 8 - name.length()) / 2; k++) {
                        sb.append(' ');
                    }
                    sb.append(name);
                    for (int i = 0; i < totals + 8 - name.length() - k; i++) {
                        sb.append(' ');
                    }
                    sb.append("|\n");

                    // head and rows
                    sb.append(print(des_head));
                    for (int i = 0; i < list.size(); i++) {
    
                        String[] row = list.get(i);
    
                        java.util.Formatter formatter = new java.util.Formatter(new StringBuilder());
                        
                        StringBuilder sbformat = new StringBuilder();                                             
        			        sbformat.append("|%1$-");
        			        sbformat.append(colLengths[0]);
        			        sbformat.append("s");
        			              
        			        sbformat.append("|%2$-");
        			        sbformat.append(colLengths[1]);
        			        sbformat.append("s");
        			              
        			        sbformat.append("|%3$-");
        			        sbformat.append(colLengths[2]);
        			        sbformat.append("s");
        			              
        			        sbformat.append("|%4$-");
        			        sbformat.append(colLengths[3]);
        			        sbformat.append("s");
        			              
        			        sbformat.append("|%5$-");
        			        sbformat.append(colLengths[4]);
        			        sbformat.append("s");
        			              
        			        sbformat.append("|%6$-");
        			        sbformat.append(colLengths[5]);
        			        sbformat.append("s");
        			              
        			        sbformat.append("|%7$-");
        			        sbformat.append(colLengths[6]);
        			        sbformat.append("s");
        			              
        			        sbformat.append("|%8$-");
        			        sbformat.append(colLengths[7]);
        			        sbformat.append("s");
        			              
        			        sbformat.append("|%9$-");
        			        sbformat.append(colLengths[8]);
        			        sbformat.append("s");
        			                      
                        sbformat.append("|\n");                    
       
                        formatter.format(sbformat.toString(), (Object[])row);	
                                
                        sb.append(formatter.toString());
                        if (i == 0)
                            sb.append(print(des_head)); // print the head
                    }
    
                    // end
                    sb.append(print(des_bottom));
                    return sb;
                }
            

            private StringBuilder print(String[] fillChars) {
                StringBuilder sb = new StringBuilder();
                //first column
                sb.append(fillChars[0]);                
                    for (int i = 0; i < colLengths[0] - fillChars[0].length() + 1; i++) {
                        sb.append(fillChars[2]);
                    }
                    sb.append(fillChars[3]);	                

                    for (int i = 0; i < colLengths[1] - fillChars[3].length() + 1; i++) {
                        sb.append(fillChars[2]);
                    }
                    sb.append(fillChars[3]);
                    for (int i = 0; i < colLengths[2] - fillChars[3].length() + 1; i++) {
                        sb.append(fillChars[2]);
                    }
                    sb.append(fillChars[3]);
                    for (int i = 0; i < colLengths[3] - fillChars[3].length() + 1; i++) {
                        sb.append(fillChars[2]);
                    }
                    sb.append(fillChars[3]);
                    for (int i = 0; i < colLengths[4] - fillChars[3].length() + 1; i++) {
                        sb.append(fillChars[2]);
                    }
                    sb.append(fillChars[3]);
                    for (int i = 0; i < colLengths[5] - fillChars[3].length() + 1; i++) {
                        sb.append(fillChars[2]);
                    }
                    sb.append(fillChars[3]);
                    for (int i = 0; i < colLengths[6] - fillChars[3].length() + 1; i++) {
                        sb.append(fillChars[2]);
                    }
                    sb.append(fillChars[3]);
                    for (int i = 0; i < colLengths[7] - fillChars[3].length() + 1; i++) {
                        sb.append(fillChars[2]);
                    }
                    sb.append(fillChars[3]);
                
                    //last column
                    for (int i = 0; i < colLengths[8] - fillChars[1].length() + 1; i++) {
                        sb.append(fillChars[2]);
                    }         
                sb.append(fillChars[1]);
                sb.append("\n");               
                return sb;
            }
            
            public boolean isTableEmpty(){
            	if (list.size() > 1)
            		return false;
            	return true;
            }
        }
        Util_tLogRow_4 util_tLogRow_4 = new Util_tLogRow_4();
        util_tLogRow_4.setTableName("tLogRow_4");
        util_tLogRow_4.addRow(new String[]{"job_name","start_time","end_time","source_table_name","source_count","target_table_name","target_count","flag","sub_job",});        
 		StringBuilder strBuffer_tLogRow_4 = null;
		int nb_line_tLogRow_4 = 0;
///////////////////////    			



 



/**
 * [tLogRow_4 begin ] stop
 */



	
	/**
	 * [tPostgresqlOutput_3 begin ] start
	 */

	

	
		
		ok_Hash.put("tPostgresqlOutput_3", false);
		start_Hash.put("tPostgresqlOutput_3", System.currentTimeMillis());
		
	
	currentComponent="tPostgresqlOutput_3";

	
			if (execStat) {
				if(resourceMap.get("inIterateVComp") == null){
					
						runStat.updateStatOnConnection("copyOfout" + iterateId, 0, 0);
					
				}
			} 

		
		int tos_count_tPostgresqlOutput_3 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tPostgresqlOutput_3 - "  + ("Start to work.") );
    	class BytesLimit65535_tPostgresqlOutput_3{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tPostgresqlOutput_3 = new StringBuilder();
            log4jParamters_tPostgresqlOutput_3.append("Parameters:");
                    log4jParamters_tPostgresqlOutput_3.append("USE_EXISTING_CONNECTION" + " = " + "false");
                log4jParamters_tPostgresqlOutput_3.append(" | ");
                    log4jParamters_tPostgresqlOutput_3.append("DB_VERSION" + " = " + "V9_X");
                log4jParamters_tPostgresqlOutput_3.append(" | ");
                    log4jParamters_tPostgresqlOutput_3.append("HOST" + " = " + "context.aws_gp_prof_Server");
                log4jParamters_tPostgresqlOutput_3.append(" | ");
                    log4jParamters_tPostgresqlOutput_3.append("PORT" + " = " + "context.aws_gp_prof_Port");
                log4jParamters_tPostgresqlOutput_3.append(" | ");
                    log4jParamters_tPostgresqlOutput_3.append("DBNAME" + " = " + "\"bhdl\"");
                log4jParamters_tPostgresqlOutput_3.append(" | ");
                    log4jParamters_tPostgresqlOutput_3.append("SCHEMA_DB" + " = " + "\"og_bhone_bw\"");
                log4jParamters_tPostgresqlOutput_3.append(" | ");
                    log4jParamters_tPostgresqlOutput_3.append("USER" + " = " + "context.aws_gp_prof_Login");
                log4jParamters_tPostgresqlOutput_3.append(" | ");
                    log4jParamters_tPostgresqlOutput_3.append("PASS" + " = " + String.valueOf(routines.system.PasswordEncryptUtil.encryptPassword(context.aws_gp_prof_Password)).substring(0, 4) + "...");     
                log4jParamters_tPostgresqlOutput_3.append(" | ");
                    log4jParamters_tPostgresqlOutput_3.append("TABLE" + " = " + "\"bh_bw_stat\"");
                log4jParamters_tPostgresqlOutput_3.append(" | ");
                    log4jParamters_tPostgresqlOutput_3.append("TABLE_ACTION" + " = " + "NONE");
                log4jParamters_tPostgresqlOutput_3.append(" | ");
                    log4jParamters_tPostgresqlOutput_3.append("DATA_ACTION" + " = " + "INSERT");
                log4jParamters_tPostgresqlOutput_3.append(" | ");
                    log4jParamters_tPostgresqlOutput_3.append("SPECIFY_DATASOURCE_ALIAS" + " = " + "false");
                log4jParamters_tPostgresqlOutput_3.append(" | ");
                    log4jParamters_tPostgresqlOutput_3.append("DIE_ON_ERROR" + " = " + "false");
                log4jParamters_tPostgresqlOutput_3.append(" | ");
                    log4jParamters_tPostgresqlOutput_3.append("USE_SSL" + " = " + "true");
                log4jParamters_tPostgresqlOutput_3.append(" | ");
                    log4jParamters_tPostgresqlOutput_3.append("COMMIT_EVERY" + " = " + "10000");
                log4jParamters_tPostgresqlOutput_3.append(" | ");
                    log4jParamters_tPostgresqlOutput_3.append("ADD_COLS" + " = " + "[]");
                log4jParamters_tPostgresqlOutput_3.append(" | ");
                    log4jParamters_tPostgresqlOutput_3.append("USE_FIELD_OPTIONS" + " = " + "false");
                log4jParamters_tPostgresqlOutput_3.append(" | ");
                    log4jParamters_tPostgresqlOutput_3.append("ENABLE_DEBUG_MODE" + " = " + "false");
                log4jParamters_tPostgresqlOutput_3.append(" | ");
                    log4jParamters_tPostgresqlOutput_3.append("SUPPORT_NULL_WHERE" + " = " + "false");
                log4jParamters_tPostgresqlOutput_3.append(" | ");
                    log4jParamters_tPostgresqlOutput_3.append("USE_BATCH_SIZE" + " = " + "true");
                log4jParamters_tPostgresqlOutput_3.append(" | ");
                    log4jParamters_tPostgresqlOutput_3.append("BATCH_SIZE" + " = " + "10000");
                log4jParamters_tPostgresqlOutput_3.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tPostgresqlOutput_3 - "  + (log4jParamters_tPostgresqlOutput_3) );
    		}
    	}
    	
        new BytesLimit65535_tPostgresqlOutput_3().limitLog4jByte();





String dbschema_tPostgresqlOutput_3 = null;
	dbschema_tPostgresqlOutput_3 = "og_bhone_bw";
	

String tableName_tPostgresqlOutput_3 = null;
if(dbschema_tPostgresqlOutput_3 == null || dbschema_tPostgresqlOutput_3.trim().length() == 0) {
	tableName_tPostgresqlOutput_3 = "bh_bw_stat";
} else {
	tableName_tPostgresqlOutput_3 = dbschema_tPostgresqlOutput_3 + "\".\"" + "bh_bw_stat";
}

int nb_line_tPostgresqlOutput_3 = 0;
int nb_line_update_tPostgresqlOutput_3 = 0;
int nb_line_inserted_tPostgresqlOutput_3 = 0;
int nb_line_deleted_tPostgresqlOutput_3 = 0;
int nb_line_rejected_tPostgresqlOutput_3 = 0;

int deletedCount_tPostgresqlOutput_3=0;
int updatedCount_tPostgresqlOutput_3=0;
int insertedCount_tPostgresqlOutput_3=0;
int rejectedCount_tPostgresqlOutput_3=0;

boolean whetherReject_tPostgresqlOutput_3 = false;

java.sql.Connection conn_tPostgresqlOutput_3 = null;
String dbUser_tPostgresqlOutput_3 = null;

	
                if(log.isDebugEnabled())
            log.debug("tPostgresqlOutput_3 - "  + ("Driver ClassName: ")  + ("org.postgresql.Driver")  + (".") );
    java.lang.Class.forName("org.postgresql.Driver");
	
	
			String url_tPostgresqlOutput_3 = "jdbc:postgresql://"+context.aws_gp_prof_Server+":"+context.aws_gp_prof_Port+"/"+"bhdl"+"?ssl=true&sslfactory=org.postgresql.ssl.NonValidatingFactory";
	
    
    dbUser_tPostgresqlOutput_3 = context.aws_gp_prof_Login;

	final String decryptedPassword_tPostgresqlOutput_3 = context.aws_gp_prof_Password; 

    String dbPwd_tPostgresqlOutput_3 = decryptedPassword_tPostgresqlOutput_3;

                if(log.isDebugEnabled())
            log.debug("tPostgresqlOutput_3 - "  + ("Connection attempts to '")  + (url_tPostgresqlOutput_3)  + ("' with the username '")  + (dbUser_tPostgresqlOutput_3)  + ("'.") );
    conn_tPostgresqlOutput_3 = java.sql.DriverManager.getConnection(url_tPostgresqlOutput_3,dbUser_tPostgresqlOutput_3,dbPwd_tPostgresqlOutput_3);
                if(log.isDebugEnabled())
            log.debug("tPostgresqlOutput_3 - "  + ("Connection to '")  + (url_tPostgresqlOutput_3)  + ("' has succeeded.") );
	
	resourceMap.put("conn_tPostgresqlOutput_3", conn_tPostgresqlOutput_3);
        conn_tPostgresqlOutput_3.setAutoCommit(false);
        int commitEvery_tPostgresqlOutput_3 = 10000;
        int commitCounter_tPostgresqlOutput_3 = 0;
                if(log.isDebugEnabled())
            log.debug("tPostgresqlOutput_3 - "  + ("Connection is set auto commit to '")  + (conn_tPostgresqlOutput_3.getAutoCommit())  + ("'.") );


   int batchSize_tPostgresqlOutput_3 = 10000;
   int batchSizeCounter_tPostgresqlOutput_3=0;

int count_tPostgresqlOutput_3=0;
	    String insert_tPostgresqlOutput_3 = "INSERT INTO \"" + tableName_tPostgresqlOutput_3 + "\" (\"job_name\",\"start_time\",\"end_time\",\"source_table_name\",\"source_count\",\"target_table_name\",\"target_count\",\"flag\",\"sub_job\") VALUES (?,?,?,?,?,?,?,?,?)";
	    java.sql.PreparedStatement pstmt_tPostgresqlOutput_3 = conn_tPostgresqlOutput_3.prepareStatement(insert_tPostgresqlOutput_3);
	    

 



/**
 * [tPostgresqlOutput_3 begin ] stop
 */



	
	/**
	 * [tMap_3 begin ] start
	 */

	

	
		
		ok_Hash.put("tMap_3", false);
		start_Hash.put("tMap_3", System.currentTimeMillis());
		
	
	currentComponent="tMap_3";

	
			if (execStat) {
				if(resourceMap.get("inIterateVComp") == null){
					
						runStat.updateStatOnConnection("row3" + iterateId, 0, 0);
					
				}
			} 

		
		int tos_count_tMap_3 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tMap_3 - "  + ("Start to work.") );
    	class BytesLimit65535_tMap_3{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tMap_3 = new StringBuilder();
            log4jParamters_tMap_3.append("Parameters:");
                    log4jParamters_tMap_3.append("LINK_STYLE" + " = " + "AUTO");
                log4jParamters_tMap_3.append(" | ");
                    log4jParamters_tMap_3.append("TEMPORARY_DATA_DIRECTORY" + " = " + "");
                log4jParamters_tMap_3.append(" | ");
                    log4jParamters_tMap_3.append("ROWS_BUFFER_SIZE" + " = " + "2000000");
                log4jParamters_tMap_3.append(" | ");
                    log4jParamters_tMap_3.append("CHANGE_HASH_AND_EQUALS_FOR_BIGDECIMAL" + " = " + "false");
                log4jParamters_tMap_3.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tMap_3 - "  + (log4jParamters_tMap_3) );
    		}
    	}
    	
        new BytesLimit65535_tMap_3().limitLog4jByte();




// ###############################
// # Lookup's keys initialization
		int count_row3_tMap_3 = 0;
		
// ###############################        

// ###############################
// # Vars initialization
class  Var__tMap_3__Struct  {
}
Var__tMap_3__Struct Var__tMap_3 = new Var__tMap_3__Struct();
// ###############################

// ###############################
// # Outputs initialization
				int count_copyOfout_tMap_3 = 0;
				
copyOfoutStruct copyOfout_tmp = new copyOfoutStruct();
// ###############################

        
        



        









 



/**
 * [tMap_3 begin ] stop
 */



	
	/**
	 * [tLogRow_3 begin ] start
	 */

	

	
		
		ok_Hash.put("tLogRow_3", false);
		start_Hash.put("tLogRow_3", System.currentTimeMillis());
		
	
	currentComponent="tLogRow_3";

	
			if (execStat) {
				if(resourceMap.get("inIterateVComp") == null){
					
						runStat.updateStatOnConnection("row5" + iterateId, 0, 0);
					
				}
			} 

		
		int tos_count_tLogRow_3 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tLogRow_3 - "  + ("Start to work.") );
    	class BytesLimit65535_tLogRow_3{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tLogRow_3 = new StringBuilder();
            log4jParamters_tLogRow_3.append("Parameters:");
                    log4jParamters_tLogRow_3.append("BASIC_MODE" + " = " + "false");
                log4jParamters_tLogRow_3.append(" | ");
                    log4jParamters_tLogRow_3.append("TABLE_PRINT" + " = " + "false");
                log4jParamters_tLogRow_3.append(" | ");
                    log4jParamters_tLogRow_3.append("VERTICAL" + " = " + "true");
                log4jParamters_tLogRow_3.append(" | ");
                    log4jParamters_tLogRow_3.append("PRINT_UNIQUE" + " = " + "false");
                log4jParamters_tLogRow_3.append(" | ");
                    log4jParamters_tLogRow_3.append("PRINT_LABEL" + " = " + "false");
                log4jParamters_tLogRow_3.append(" | ");
                    log4jParamters_tLogRow_3.append("PRINT_UNIQUE_LABEL" + " = " + "true");
                log4jParamters_tLogRow_3.append(" | ");
                    log4jParamters_tLogRow_3.append("PRINT_CONTENT_WITH_LOG4J" + " = " + "false");
                log4jParamters_tLogRow_3.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tLogRow_3 - "  + (log4jParamters_tLogRow_3) );
    		}
    	}
    	
        new BytesLimit65535_tLogRow_3().limitLog4jByte();

	///////////////////////
		


	class Util_tLogRow_3 {
	
		String[] des_top = { ".", "-" };

        String[] des_data = { "-", "+" };

        String[] des_frame = { "|" }; 
        
        public void printLine(StringBuilder sb, int titleWidth, int dataWidth){
        
        	sb.append("+");
			for(int i=0; i<titleWidth+2; i++)
				sb.append("-");
			sb.append("+");
			for(int i=0; i<dataWidth+2; i++)
				sb.append("-");
        	sb.append("+" + "\n");
        }      

		public String print(String[] row, int nbLine){
			
			StringBuilder sb = new StringBuilder();
			
			    String title = "#" + nbLine + ". " + "tLogRow_3--tLogRow_3";
			    
		
			//step 1: get the max length of all the row[] member;
			int dataWidth = 5;		//the length of the string "value"	
			for(int i=0;i<row.length;i++) {
				if(row[i] == null && 4 > dataWidth) {
					dataWidth = 4;
				}
				else if(row[i] != null && row[i].length()>dataWidth) 
					dataWidth = row[i].length();
			}			
						
			int titleWidth = 10;
			
			int totalWidth = dataWidth + titleWidth + 5;
			
			//step 2: print the header with line number
			sb.append(".");
			for(int i=0 ; i<totalWidth ; i++)
				sb.append("-");			
			sb.append("." + "\n" + "|");
			
			int emptyCenterWidth = (totalWidth-title.length())/2;
			for(int i=0 ; i<emptyCenterWidth; i++)
				sb.append(" ");	
			sb.append(title);
			for(int i=0 ; i<totalWidth - emptyCenterWidth - title.length() ; i++)
				sb.append(" ");	
			sb.append("|" + "\n");
			
			//step 3: print "key" and "value"			
			printLine(sb,titleWidth,dataWidth);
			
			sb.append("|" + " key");
			for(int i=0; i<titleWidth-2; i++)
				sb.append(" ");
        	sb.append("|" + " value");
			for(int i=0; i<dataWidth-4; i++)
				sb.append(" ");
			sb.append("|" + "\n");
			
			printLine(sb,titleWidth,dataWidth);
			
			//step 4: print dataset
			
			//for(int i=0; i<row.length; i++){
				sb.append("| " + "moment");
				for(int i=0; i<titleWidth -"moment".length()+ 1 ;i++)
					sb.append(" ");
				sb.append("| " + row[0]);
				for(int i=0; row[0] == null && i<dataWidth - 3 || row[0] != null && i<dataWidth -row[0].length()+ 1 ;i++)
					sb.append(" ");
				sb.append("|" + "\n");
			
			//}

			
			//for(int i=0; i<row.length; i++){
				sb.append("| " + "pid");
				for(int i=0; i<titleWidth -"pid".length()+ 1 ;i++)
					sb.append(" ");
				sb.append("| " + row[1]);
				for(int i=0; row[1] == null && i<dataWidth - 3 || row[1] != null && i<dataWidth -row[1].length()+ 1 ;i++)
					sb.append(" ");
				sb.append("|" + "\n");
			
			//}

			
			//for(int i=0; i<row.length; i++){
				sb.append("| " + "root_pid");
				for(int i=0; i<titleWidth -"root_pid".length()+ 1 ;i++)
					sb.append(" ");
				sb.append("| " + row[2]);
				for(int i=0; row[2] == null && i<dataWidth - 3 || row[2] != null && i<dataWidth -row[2].length()+ 1 ;i++)
					sb.append(" ");
				sb.append("|" + "\n");
			
			//}

			
			//for(int i=0; i<row.length; i++){
				sb.append("| " + "father_pid");
				for(int i=0; i<titleWidth -"father_pid".length()+ 1 ;i++)
					sb.append(" ");
				sb.append("| " + row[3]);
				for(int i=0; row[3] == null && i<dataWidth - 3 || row[3] != null && i<dataWidth -row[3].length()+ 1 ;i++)
					sb.append(" ");
				sb.append("|" + "\n");
			
			//}

			
			//for(int i=0; i<row.length; i++){
				sb.append("| " + "project");
				for(int i=0; i<titleWidth -"project".length()+ 1 ;i++)
					sb.append(" ");
				sb.append("| " + row[4]);
				for(int i=0; row[4] == null && i<dataWidth - 3 || row[4] != null && i<dataWidth -row[4].length()+ 1 ;i++)
					sb.append(" ");
				sb.append("|" + "\n");
			
			//}

			
			//for(int i=0; i<row.length; i++){
				sb.append("| " + "job");
				for(int i=0; i<titleWidth -"job".length()+ 1 ;i++)
					sb.append(" ");
				sb.append("| " + row[5]);
				for(int i=0; row[5] == null && i<dataWidth - 3 || row[5] != null && i<dataWidth -row[5].length()+ 1 ;i++)
					sb.append(" ");
				sb.append("|" + "\n");
			
			//}

			
			//for(int i=0; i<row.length; i++){
				sb.append("| " + "context");
				for(int i=0; i<titleWidth -"context".length()+ 1 ;i++)
					sb.append(" ");
				sb.append("| " + row[6]);
				for(int i=0; row[6] == null && i<dataWidth - 3 || row[6] != null && i<dataWidth -row[6].length()+ 1 ;i++)
					sb.append(" ");
				sb.append("|" + "\n");
			
			//}

			
			//for(int i=0; i<row.length; i++){
				sb.append("| " + "priority");
				for(int i=0; i<titleWidth -"priority".length()+ 1 ;i++)
					sb.append(" ");
				sb.append("| " + row[7]);
				for(int i=0; row[7] == null && i<dataWidth - 3 || row[7] != null && i<dataWidth -row[7].length()+ 1 ;i++)
					sb.append(" ");
				sb.append("|" + "\n");
			
			//}

			
			//for(int i=0; i<row.length; i++){
				sb.append("| " + "type");
				for(int i=0; i<titleWidth -"type".length()+ 1 ;i++)
					sb.append(" ");
				sb.append("| " + row[8]);
				for(int i=0; row[8] == null && i<dataWidth - 3 || row[8] != null && i<dataWidth -row[8].length()+ 1 ;i++)
					sb.append(" ");
				sb.append("|" + "\n");
			
			//}

			
			//for(int i=0; i<row.length; i++){
				sb.append("| " + "origin");
				for(int i=0; i<titleWidth -"origin".length()+ 1 ;i++)
					sb.append(" ");
				sb.append("| " + row[9]);
				for(int i=0; row[9] == null && i<dataWidth - 3 || row[9] != null && i<dataWidth -row[9].length()+ 1 ;i++)
					sb.append(" ");
				sb.append("|" + "\n");
			
			//}

			
			//for(int i=0; i<row.length; i++){
				sb.append("| " + "message");
				for(int i=0; i<titleWidth -"message".length()+ 1 ;i++)
					sb.append(" ");
				sb.append("| " + row[10]);
				for(int i=0; row[10] == null && i<dataWidth - 3 || row[10] != null && i<dataWidth -row[10].length()+ 1 ;i++)
					sb.append(" ");
				sb.append("|" + "\n");
			
			//}

			
			//for(int i=0; i<row.length; i++){
				sb.append("| " + "code");
				for(int i=0; i<titleWidth -"code".length()+ 1 ;i++)
					sb.append(" ");
				sb.append("| " + row[11]);
				for(int i=0; row[11] == null && i<dataWidth - 3 || row[11] != null && i<dataWidth -row[11].length()+ 1 ;i++)
					sb.append(" ");
				sb.append("|" + "\n");
			
			//}

			
			//step 5: print a line gap
			printLine(sb,titleWidth,dataWidth);
			return sb.toString();

		}


	}

	Util_tLogRow_3 util_tLogRow_3 = new Util_tLogRow_3();




	java.io.PrintStream consoleOut_tLogRow_3 = null;
	if (globalMap.get("tLogRow_CONSOLE")!=null){
        consoleOut_tLogRow_3 = (java.io.PrintStream) globalMap.get("tLogRow_CONSOLE");
    }else{
        consoleOut_tLogRow_3 = new java.io.PrintStream(new java.io.BufferedOutputStream(System.out));
        globalMap.put("tLogRow_CONSOLE",consoleOut_tLogRow_3);
    }

 		StringBuilder strBuffer_tLogRow_3 = null;
		int nb_line_tLogRow_3 = 0;
///////////////////////    			



 



/**
 * [tLogRow_3 begin ] stop
 */



	
	/**
	 * [tLogCatcher_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tLogCatcher_1", false);
		start_Hash.put("tLogCatcher_1", System.currentTimeMillis());
		
	
	currentComponent="tLogCatcher_1";

	
		int tos_count_tLogCatcher_1 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tLogCatcher_1 - "  + ("Start to work.") );
    	class BytesLimit65535_tLogCatcher_1{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tLogCatcher_1 = new StringBuilder();
            log4jParamters_tLogCatcher_1.append("Parameters:");
                    log4jParamters_tLogCatcher_1.append("CATCH_JAVA_EXCEPTION" + " = " + "true");
                log4jParamters_tLogCatcher_1.append(" | ");
                    log4jParamters_tLogCatcher_1.append("CATCH_TDIE" + " = " + "true");
                log4jParamters_tLogCatcher_1.append(" | ");
                    log4jParamters_tLogCatcher_1.append("CATCH_TWARN" + " = " + "true");
                log4jParamters_tLogCatcher_1.append(" | ");
                    log4jParamters_tLogCatcher_1.append("CATCH_TACTIONFAILURE" + " = " + "true");
                log4jParamters_tLogCatcher_1.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tLogCatcher_1 - "  + (log4jParamters_tLogCatcher_1) );
    		}
    	}
    	
        new BytesLimit65535_tLogCatcher_1().limitLog4jByte();

	for (LogCatcherUtils.LogCatcherMessage lcm : tLogCatcher_1.getMessages()) {
		row5.type = lcm.getType();
		row5.origin = (lcm.getOrigin()==null || lcm.getOrigin().length()<1 ? null : lcm.getOrigin());
		row5.priority = lcm.getPriority();
		row5.message = lcm.getMessage();
		row5.code = lcm.getCode();
		
		row5.moment = java.util.Calendar.getInstance().getTime();
	
    	row5.pid = pid;
		row5.root_pid = rootPid;
		row5.father_pid = fatherPid;
	
    	row5.project = projectName;
    	row5.job = jobName;
    	row5.context = contextStr;
    		
 



/**
 * [tLogCatcher_1 begin ] stop
 */
	
	/**
	 * [tLogCatcher_1 main ] start
	 */

	

	
	
	currentComponent="tLogCatcher_1";

	

 


	tos_count_tLogCatcher_1++;

/**
 * [tLogCatcher_1 main ] stop
 */

	
	/**
	 * [tLogRow_3 main ] start
	 */

	

	
	
	currentComponent="tLogRow_3";

	

			//row5
			//row5


			
				if(execStat){
					runStat.updateStatOnConnection("row5"+iterateId,1, 1);
				} 
			

		
    			if(log.isTraceEnabled()){
    				log.trace("row5 - " + (row5==null? "": row5.toLogString()));
    			}
    		
///////////////////////		
						



				strBuffer_tLogRow_3 = new StringBuilder();




   				
	    		if(row5.moment != null) { //              
                    							
       
				strBuffer_tLogRow_3.append(
								FormatterUtils.format_Date(row5.moment, "yyyy-MM-dd HH:mm:ss")				
				);


							
	    		} //  			

    			strBuffer_tLogRow_3.append("|");
    			


   				
	    		if(row5.pid != null) { //              
                    							
       
				strBuffer_tLogRow_3.append(
				                String.valueOf(row5.pid)							
				);


							
	    		} //  			

    			strBuffer_tLogRow_3.append("|");
    			


   				
	    		if(row5.root_pid != null) { //              
                    							
       
				strBuffer_tLogRow_3.append(
				                String.valueOf(row5.root_pid)							
				);


							
	    		} //  			

    			strBuffer_tLogRow_3.append("|");
    			


   				
	    		if(row5.father_pid != null) { //              
                    							
       
				strBuffer_tLogRow_3.append(
				                String.valueOf(row5.father_pid)							
				);


							
	    		} //  			

    			strBuffer_tLogRow_3.append("|");
    			


   				
	    		if(row5.project != null) { //              
                    							
       
				strBuffer_tLogRow_3.append(
				                String.valueOf(row5.project)							
				);


							
	    		} //  			

    			strBuffer_tLogRow_3.append("|");
    			


   				
	    		if(row5.job != null) { //              
                    							
       
				strBuffer_tLogRow_3.append(
				                String.valueOf(row5.job)							
				);


							
	    		} //  			

    			strBuffer_tLogRow_3.append("|");
    			


   				
	    		if(row5.context != null) { //              
                    							
       
				strBuffer_tLogRow_3.append(
				                String.valueOf(row5.context)							
				);


							
	    		} //  			

    			strBuffer_tLogRow_3.append("|");
    			


   				
	    		if(row5.priority != null) { //              
                    							
       
				strBuffer_tLogRow_3.append(
				                String.valueOf(row5.priority)							
				);


							
	    		} //  			

    			strBuffer_tLogRow_3.append("|");
    			


   				
	    		if(row5.type != null) { //              
                    							
       
				strBuffer_tLogRow_3.append(
				                String.valueOf(row5.type)							
				);


							
	    		} //  			

    			strBuffer_tLogRow_3.append("|");
    			


   				
	    		if(row5.origin != null) { //              
                    							
       
				strBuffer_tLogRow_3.append(
				                String.valueOf(row5.origin)							
				);


							
	    		} //  			

    			strBuffer_tLogRow_3.append("|");
    			


   				
	    		if(row5.message != null) { //              
                    							
       
				strBuffer_tLogRow_3.append(
				                String.valueOf(row5.message)							
				);


							
	    		} //  			

    			strBuffer_tLogRow_3.append("|");
    			


   				
	    		if(row5.code != null) { //              
                    							
       
				strBuffer_tLogRow_3.append(
				                String.valueOf(row5.code)							
				);


							
	    		} //  			

				
				String[] row_tLogRow_3 = new String[12];
   				
	    		if(row5.moment != null) { //              
                 row_tLogRow_3[0]=    						
								FormatterUtils.format_Date(row5.moment, "yyyy-MM-dd HH:mm:ss")
					          ;	
							
	    		} //			
    			   				
	    		if(row5.pid != null) { //              
                 row_tLogRow_3[1]=    						    
				                String.valueOf(row5.pid)			
					          ;	
							
	    		} //			
    			   				
	    		if(row5.root_pid != null) { //              
                 row_tLogRow_3[2]=    						    
				                String.valueOf(row5.root_pid)			
					          ;	
							
	    		} //			
    			   				
	    		if(row5.father_pid != null) { //              
                 row_tLogRow_3[3]=    						    
				                String.valueOf(row5.father_pid)			
					          ;	
							
	    		} //			
    			   				
	    		if(row5.project != null) { //              
                 row_tLogRow_3[4]=    						    
				                String.valueOf(row5.project)			
					          ;	
							
	    		} //			
    			   				
	    		if(row5.job != null) { //              
                 row_tLogRow_3[5]=    						    
				                String.valueOf(row5.job)			
					          ;	
							
	    		} //			
    			   				
	    		if(row5.context != null) { //              
                 row_tLogRow_3[6]=    						    
				                String.valueOf(row5.context)			
					          ;	
							
	    		} //			
    			   				
	    		if(row5.priority != null) { //              
                 row_tLogRow_3[7]=    						    
				                String.valueOf(row5.priority)			
					          ;	
							
	    		} //			
    			   				
	    		if(row5.type != null) { //              
                 row_tLogRow_3[8]=    						    
				                String.valueOf(row5.type)			
					          ;	
							
	    		} //			
    			   				
	    		if(row5.origin != null) { //              
                 row_tLogRow_3[9]=    						    
				                String.valueOf(row5.origin)			
					          ;	
							
	    		} //			
    			   				
	    		if(row5.message != null) { //              
                 row_tLogRow_3[10]=    						    
				                String.valueOf(row5.message)			
					          ;	
							
	    		} //			
    			   				
	    		if(row5.code != null) { //              
                 row_tLogRow_3[11]=    						    
				                String.valueOf(row5.code)			
					          ;	
							
	    		} //			
    			
				nb_line_tLogRow_3++;
                consoleOut_tLogRow_3.println(util_tLogRow_3.print(row_tLogRow_3,nb_line_tLogRow_3));
                consoleOut_tLogRow_3.flush();
//////

//////                    
                    
///////////////////////    			

 
     row3 = row5;


	tos_count_tLogRow_3++;

/**
 * [tLogRow_3 main ] stop
 */

	
	/**
	 * [tMap_3 main ] start
	 */

	

	
	
	currentComponent="tMap_3";

	

			//row3
			//row3


			
				if(execStat){
					runStat.updateStatOnConnection("row3"+iterateId,1, 1);
				} 
			

		
    			if(log.isTraceEnabled()){
    				log.trace("row3 - " + (row3==null? "": row3.toLogString()));
    			}
    		

		
		
		boolean hasCasePrimitiveKeyWithNull_tMap_3 = false;
		
        // ###############################
        // # Input tables (lookups)
		  boolean rejectedInnerJoin_tMap_3 = false;
		  boolean mainRowRejected_tMap_3 = false;
            				    								  
		// ###############################
        { // start of Var scope
        
	        // ###############################
        	// # Vars tables
        
Var__tMap_3__Struct Var = Var__tMap_3;// ###############################
        // ###############################
        // # Output tables

copyOfout = null;


// # Output table : 'copyOfout'
count_copyOfout_tMap_3++;

copyOfout_tmp.job_name = context.master_job;
copyOfout_tmp.start_time = row3.moment ;
copyOfout_tmp.end_time = TalendDate.getCurrentDate() ;
copyOfout_tmp.source_table_name = context.TABLE ;
copyOfout_tmp.source_count = ((Integer)globalMap.get("tOracleInput_1_NB_LINE")) ;
copyOfout_tmp.target_table_name = context.Table2;
copyOfout_tmp.target_count = ((Integer)globalMap.get("tPostgresqlOutput_1_NB_LINE_INSERTED")) ;
copyOfout_tmp.flag = row3.message ;
copyOfout_tmp.sub_job = row3.job ;
copyOfout = copyOfout_tmp;
log.debug("tMap_3 - Outputting the record " + count_copyOfout_tMap_3 + " of the output table 'copyOfout'.");

// ###############################

} // end of Var scope

rejectedInnerJoin_tMap_3 = false;










 


	tos_count_tMap_3++;

/**
 * [tMap_3 main ] stop
 */
// Start of branch "copyOfout"
if(copyOfout != null) { 



	
	/**
	 * [tPostgresqlOutput_3 main ] start
	 */

	

	
	
	currentComponent="tPostgresqlOutput_3";

	

			//copyOfout
			//copyOfout


			
				if(execStat){
					runStat.updateStatOnConnection("copyOfout"+iterateId,1, 1);
				} 
			

		
    			if(log.isTraceEnabled()){
    				log.trace("copyOfout - " + (copyOfout==null? "": copyOfout.toLogString()));
    			}
    		



            row6 = null;
        whetherReject_tPostgresqlOutput_3 = false;
                    if(copyOfout.job_name == null) {
pstmt_tPostgresqlOutput_3.setNull(1, java.sql.Types.VARCHAR);
} else {pstmt_tPostgresqlOutput_3.setString(1, copyOfout.job_name);
}

                    if(copyOfout.start_time != null) {
pstmt_tPostgresqlOutput_3.setTimestamp(2, new java.sql.Timestamp(copyOfout.start_time.getTime()));
} else {
pstmt_tPostgresqlOutput_3.setNull(2, java.sql.Types.TIMESTAMP);
}

                    if(copyOfout.end_time != null) {
pstmt_tPostgresqlOutput_3.setTimestamp(3, new java.sql.Timestamp(copyOfout.end_time.getTime()));
} else {
pstmt_tPostgresqlOutput_3.setNull(3, java.sql.Types.TIMESTAMP);
}

                    if(copyOfout.source_table_name == null) {
pstmt_tPostgresqlOutput_3.setNull(4, java.sql.Types.VARCHAR);
} else {pstmt_tPostgresqlOutput_3.setString(4, copyOfout.source_table_name);
}

                    if(copyOfout.source_count == null) {
pstmt_tPostgresqlOutput_3.setNull(5, java.sql.Types.INTEGER);
} else {pstmt_tPostgresqlOutput_3.setInt(5, copyOfout.source_count);
}

                    if(copyOfout.target_table_name == null) {
pstmt_tPostgresqlOutput_3.setNull(6, java.sql.Types.VARCHAR);
} else {pstmt_tPostgresqlOutput_3.setString(6, copyOfout.target_table_name);
}

                    if(copyOfout.target_count == null) {
pstmt_tPostgresqlOutput_3.setNull(7, java.sql.Types.INTEGER);
} else {pstmt_tPostgresqlOutput_3.setInt(7, copyOfout.target_count);
}

                    if(copyOfout.flag == null) {
pstmt_tPostgresqlOutput_3.setNull(8, java.sql.Types.VARCHAR);
} else {pstmt_tPostgresqlOutput_3.setString(8, copyOfout.flag);
}

                    if(copyOfout.sub_job == null) {
pstmt_tPostgresqlOutput_3.setNull(9, java.sql.Types.VARCHAR);
} else {pstmt_tPostgresqlOutput_3.setString(9, copyOfout.sub_job);
}

			
    		pstmt_tPostgresqlOutput_3.addBatch();
    		nb_line_tPostgresqlOutput_3++;
    		  
                if(log.isDebugEnabled())
            log.debug("tPostgresqlOutput_3 - "  + ("Adding the record ")  + (nb_line_tPostgresqlOutput_3)  + (" to the ")  + ("INSERT")  + (" batch.") );
    		  batchSizeCounter_tPostgresqlOutput_3++;
    		  
            if(!whetherReject_tPostgresqlOutput_3) {
                            row6 = new row6Struct();
                                row6.job_name = copyOfout.job_name;
                                row6.start_time = copyOfout.start_time;
                                row6.end_time = copyOfout.end_time;
                                row6.source_table_name = copyOfout.source_table_name;
                                row6.source_count = copyOfout.source_count;
                                row6.target_table_name = copyOfout.target_table_name;
                                row6.target_count = copyOfout.target_count;
                                row6.flag = copyOfout.flag;
                                row6.sub_job = copyOfout.sub_job;
            }
    			if ((batchSize_tPostgresqlOutput_3 > 0) && (batchSize_tPostgresqlOutput_3 <= batchSizeCounter_tPostgresqlOutput_3)) {
                try {
						int countSum_tPostgresqlOutput_3 = 0;
						    
                if(log.isDebugEnabled())
            log.debug("tPostgresqlOutput_3 - "  + ("Executing the ")  + ("INSERT")  + (" batch.") );
						for(int countEach_tPostgresqlOutput_3: pstmt_tPostgresqlOutput_3.executeBatch()) {
							countSum_tPostgresqlOutput_3 += (countEach_tPostgresqlOutput_3 < 0 ? 0 : countEach_tPostgresqlOutput_3);
						}
                if(log.isDebugEnabled())
            log.debug("tPostgresqlOutput_3 - "  + ("The ")  + ("INSERT")  + (" batch execution has succeeded.") );
				    	
				    		insertedCount_tPostgresqlOutput_3 += countSum_tPostgresqlOutput_3;
				    	
            	    	batchSizeCounter_tPostgresqlOutput_3 = 0;
                }catch (java.sql.BatchUpdateException e){
                	
                	int countSum_tPostgresqlOutput_3 = 0;
					for(int countEach_tPostgresqlOutput_3: e.getUpdateCounts()) {
						countSum_tPostgresqlOutput_3 += (countEach_tPostgresqlOutput_3 < 0 ? 0 : countEach_tPostgresqlOutput_3);
					}
					
			    		insertedCount_tPostgresqlOutput_3 += countSum_tPostgresqlOutput_3;
			    	
            log.error("tPostgresqlOutput_3 - "  + (e.getMessage()) );
                	System.err.println(e.getMessage());
                	
                }
    			}
    		
    		    commitCounter_tPostgresqlOutput_3++;
                if(commitEvery_tPostgresqlOutput_3 <= commitCounter_tPostgresqlOutput_3) {
                if ((batchSize_tPostgresqlOutput_3 > 0) && (batchSizeCounter_tPostgresqlOutput_3 > 0)) {
                try {
                		int countSum_tPostgresqlOutput_3 = 0;
                		    
                if(log.isDebugEnabled())
            log.debug("tPostgresqlOutput_3 - "  + ("Executing the ")  + ("INSERT")  + (" batch.") );
						for(int countEach_tPostgresqlOutput_3: pstmt_tPostgresqlOutput_3.executeBatch()) {
							countSum_tPostgresqlOutput_3 += (countEach_tPostgresqlOutput_3 < 0 ? 0 : countEach_tPostgresqlOutput_3);
						}
                if(log.isDebugEnabled())
            log.debug("tPostgresqlOutput_3 - "  + ("The ")  + ("INSERT")  + (" batch execution has succeeded.") );
            	    	
            	    		insertedCount_tPostgresqlOutput_3 += countSum_tPostgresqlOutput_3;
            	    	
                batchSizeCounter_tPostgresqlOutput_3 = 0;
                }catch (java.sql.BatchUpdateException e){
                	
                		int countSum_tPostgresqlOutput_3 = 0;
						for(int countEach_tPostgresqlOutput_3: e.getUpdateCounts()) {
							countSum_tPostgresqlOutput_3 += (countEach_tPostgresqlOutput_3 < 0 ? 0 : countEach_tPostgresqlOutput_3);
						}
						
				    		insertedCount_tPostgresqlOutput_3 += countSum_tPostgresqlOutput_3;
				    	
            log.error("tPostgresqlOutput_3 - "  + (e.getMessage()) );
                        System.err.println(e.getMessage());
                	
                }
            }
                if(log.isDebugEnabled())
            log.debug("tPostgresqlOutput_3 - "  + ("Connection starting to commit ")  + (commitCounter_tPostgresqlOutput_3)  + (" record(s).") );
                	conn_tPostgresqlOutput_3.commit();
                	
                if(log.isDebugEnabled())
            log.debug("tPostgresqlOutput_3 - "  + ("Connection commit has succeeded.") );
                	commitCounter_tPostgresqlOutput_3=0;
                }

 


	tos_count_tPostgresqlOutput_3++;

/**
 * [tPostgresqlOutput_3 main ] stop
 */
// Start of branch "row6"
if(row6 != null) { 



	
	/**
	 * [tLogRow_4 main ] start
	 */

	

	
	
	currentComponent="tLogRow_4";

	

			//row6
			//row6


			
				if(execStat){
					runStat.updateStatOnConnection("row6"+iterateId,1, 1);
				} 
			

		
    			if(log.isTraceEnabled()){
    				log.trace("row6 - " + (row6==null? "": row6.toLogString()));
    			}
    		
///////////////////////		
						

				
				String[] row_tLogRow_4 = new String[9];
   				
	    		if(row6.job_name != null) { //              
                 row_tLogRow_4[0]=    						    
				                String.valueOf(row6.job_name)			
					          ;	
							
	    		} //			
    			   				
	    		if(row6.start_time != null) { //              
                 row_tLogRow_4[1]=    						
								FormatterUtils.format_Date(row6.start_time, "dd-MM-yyyy")
					          ;	
							
	    		} //			
    			   				
	    		if(row6.end_time != null) { //              
                 row_tLogRow_4[2]=    						
								FormatterUtils.format_Date(row6.end_time, "dd-MM-yyyy")
					          ;	
							
	    		} //			
    			   				
	    		if(row6.source_table_name != null) { //              
                 row_tLogRow_4[3]=    						    
				                String.valueOf(row6.source_table_name)			
					          ;	
							
	    		} //			
    			   				
	    		if(row6.source_count != null) { //              
                 row_tLogRow_4[4]=    						    
				                String.valueOf(row6.source_count)			
					          ;	
							
	    		} //			
    			   				
	    		if(row6.target_table_name != null) { //              
                 row_tLogRow_4[5]=    						    
				                String.valueOf(row6.target_table_name)			
					          ;	
							
	    		} //			
    			   				
	    		if(row6.target_count != null) { //              
                 row_tLogRow_4[6]=    						    
				                String.valueOf(row6.target_count)			
					          ;	
							
	    		} //			
    			   				
	    		if(row6.flag != null) { //              
                 row_tLogRow_4[7]=    						    
				                String.valueOf(row6.flag)			
					          ;	
							
	    		} //			
    			   				
	    		if(row6.sub_job != null) { //              
                 row_tLogRow_4[8]=    						    
				                String.valueOf(row6.sub_job)			
					          ;	
							
	    		} //			
    			 

				util_tLogRow_4.addRow(row_tLogRow_4);	
				nb_line_tLogRow_4++;
//////

//////                    
                    
///////////////////////    			

 
     row10 = row6;


	tos_count_tLogRow_4++;

/**
 * [tLogRow_4 main ] stop
 */

	
	/**
	 * [tJavaRow_2 main ] start
	 */

	

	
	
	currentComponent="tJavaRow_2";

	

			//row10
			//row10


			
				if(execStat){
					runStat.updateStatOnConnection("row10"+iterateId,1, 1);
				} 
			

		
    			if(log.isTraceEnabled()){
    				log.trace("row10 - " + (row10==null? "": row10.toLogString()));
    			}
    		

    globalMap.put("error_code", row10.flag);
globalMap.put("job_name",row10.sub_job);
globalMap.put("error_time",row10.start_time);
globalMap.put("Master_job",context.master_job);
    nb_line_tJavaRow_2++;   

 


	tos_count_tJavaRow_2++;

/**
 * [tJavaRow_2 main ] stop
 */

	
	/**
	 * [tSendMail_2 main ] start
	 */

	

	
	
	currentComponent="tSendMail_2";

	

			//row11
			//row11


			
				if(execStat){
					runStat.updateStatOnConnection("row11"+iterateId,1, 1);
				} 
			

		
    			if(log.isTraceEnabled()){
    				log.trace("row11 - " + (row11==null? "": row11.toLogString()));
    			}
    		

 

	String smtpHost_tSendMail_2 = "bsemsx01.ae.ge.com";
        String smtpPort_tSendMail_2 = "25";
	String from_tSendMail_2 = ("job_scheduler@talend.com");
    String to_tSendMail_2 = (context.mail).replace(";",",");
    String cc_tSendMail_2 = (("")==null || "".equals(""))?null:("").replace(";",",");
    String bcc_tSendMail_2 = (("")==null || "".equals(""))?null:("").replace(";",",");
    String subject_tSendMail_2 = ("Job Failure: "+(String)globalMap.get("job_name"));
    
	java.util.List<java.util.Map<String, String>> headers_tSendMail_2 = new java.util.ArrayList<java.util.Map<String,String>>();
	java.util.List<String> attachments_tSendMail_2 = new java.util.ArrayList<String>();
	java.util.List<String> contentTransferEncoding_tSendMail_2 = new java.util.ArrayList<String>();

	String message_tSendMail_2 = (("Hi team,\n\nA job has failed with the following details:\n\nJob Name: "+(String)globalMap.get("Master_job")+"\nSub Job Name:  "+(String)globalMap.get("job_name")+"\nError code:  "+(String)globalMap.get("error_code")+" \nTime of Failure:  "+(Date)globalMap.get("error_time")+"  \n\nThanks,\n\nTalend Support") == null || "".equals("Hi team,\n\nA job has failed with the following details:\n\nJob Name: "+(String)globalMap.get("Master_job")+"\nSub Job Name:  "+(String)globalMap.get("job_name")+"\nError code:  "+(String)globalMap.get("error_code")+" \nTime of Failure:  "+(Date)globalMap.get("error_time")+"  \n\nThanks,\n\nTalend Support")) ? "\"\"" : ("Hi team,\n\nA job has failed with the following details:\n\nJob Name: "+(String)globalMap.get("Master_job")+"\nSub Job Name:  "+(String)globalMap.get("job_name")+"\nError code:  "+(String)globalMap.get("error_code")+" \nTime of Failure:  "+(Date)globalMap.get("error_time")+"  \n\nThanks,\n\nTalend Support") ;
	java.util.Properties props_tSendMail_2 = System.getProperties();     
	props_tSendMail_2.put("mail.smtp.host", smtpHost_tSendMail_2);
	props_tSendMail_2.put("mail.smtp.port", smtpPort_tSendMail_2);
		props_tSendMail_2.put("mail.mime.encodefilename", "true");     
	try {
		
			log.info("tSendMail_2 - Connection attempt to '" + smtpHost_tSendMail_2 +"'.");
		
		  
			props_tSendMail_2.put("mail.smtp.auth", "false");
			javax.mail.Session session_tSendMail_2 = javax.mail.Session.getInstance(props_tSendMail_2, null);    
		
		
			log.info("tSendMail_2 - Connection to '" + smtpHost_tSendMail_2 + "' has succeeded.");
		
		javax.mail.Message msg_tSendMail_2 = new javax.mail.internet.MimeMessage(session_tSendMail_2);
		msg_tSendMail_2.setFrom(new javax.mail.internet.InternetAddress(from_tSendMail_2, null));
		msg_tSendMail_2.setRecipients(javax.mail.Message.RecipientType.TO,javax.mail.internet.InternetAddress.parse(to_tSendMail_2, false));
		if (cc_tSendMail_2 != null) msg_tSendMail_2.setRecipients(javax.mail.Message.RecipientType.CC, javax.mail.internet.InternetAddress.parse(cc_tSendMail_2, false));
		if (bcc_tSendMail_2 != null) msg_tSendMail_2.setRecipients(javax.mail.Message.RecipientType.BCC, javax.mail.internet.InternetAddress.parse(bcc_tSendMail_2, false));
		msg_tSendMail_2.setSubject(subject_tSendMail_2);

		for (int i_tSendMail_2 = 0; i_tSendMail_2 < headers_tSendMail_2.size(); i_tSendMail_2++) {
			java.util.Map<String, String> header_tSendMail_2 = headers_tSendMail_2.get(i_tSendMail_2);
			msg_tSendMail_2.setHeader(header_tSendMail_2.get("KEY"), header_tSendMail_2.get("VALUE"));    
		}  
		msg_tSendMail_2.setSentDate(new Date());
		msg_tSendMail_2.setHeader("X-Priority", "3"); //High->1 Normal->3 Low->5
		javax.mail.Multipart mp_tSendMail_2 = new javax.mail.internet.MimeMultipart();
		javax.mail.internet.MimeBodyPart mbpText_tSendMail_2 = new javax.mail.internet.MimeBodyPart();
		mbpText_tSendMail_2.setText(message_tSendMail_2,"ISO-8859-15", "plain");
		mp_tSendMail_2.addBodyPart(mbpText_tSendMail_2);
  
		javax.mail.internet.MimeBodyPart mbpFile_tSendMail_2 = null;

		for (int i_tSendMail_2 = 0; i_tSendMail_2 < attachments_tSendMail_2.size(); i_tSendMail_2++){
			String filename_tSendMail_2 = attachments_tSendMail_2.get(i_tSendMail_2);
			javax.activation.FileDataSource fds_tSendMail_2 = null;
			java.io.File file_tSendMail_2 = new java.io.File(filename_tSendMail_2);
			
				if (!file_tSendMail_2.exists()){
					continue;
				}
			
    		if (file_tSendMail_2.isDirectory()){
				java.io.File[] subFiles_tSendMail_2 = file_tSendMail_2.listFiles();
				for(java.io.File subFile_tSendMail_2 : subFiles_tSendMail_2){
					if (subFile_tSendMail_2.isFile()){
						fds_tSendMail_2 = new javax.activation.FileDataSource(subFile_tSendMail_2.getAbsolutePath());
						mbpFile_tSendMail_2 = new javax.mail.internet.MimeBodyPart();
						mbpFile_tSendMail_2.setDataHandler(new javax.activation.DataHandler(fds_tSendMail_2));
						mbpFile_tSendMail_2.setFileName(javax.mail.internet.MimeUtility.encodeText(fds_tSendMail_2.getName()));
						if(contentTransferEncoding_tSendMail_2.get(i_tSendMail_2).equalsIgnoreCase("base64")){
							mbpFile_tSendMail_2.setHeader("Content-Transfer-Encoding", "base64");
						}
						mp_tSendMail_2.addBodyPart(mbpFile_tSendMail_2);
					}
				}
    		}else{
				mbpFile_tSendMail_2 = new javax.mail.internet.MimeBodyPart();
				fds_tSendMail_2 = new javax.activation.FileDataSource(filename_tSendMail_2);
				mbpFile_tSendMail_2.setDataHandler(new javax.activation.DataHandler(fds_tSendMail_2)); 
				mbpFile_tSendMail_2.setFileName(javax.mail.internet.MimeUtility.encodeText(fds_tSendMail_2.getName()));
				if(contentTransferEncoding_tSendMail_2.get(i_tSendMail_2).equalsIgnoreCase("base64")){
					mbpFile_tSendMail_2.setHeader("Content-Transfer-Encoding", "base64");
				}
				mp_tSendMail_2.addBodyPart(mbpFile_tSendMail_2);
			}
		}
		// -- set the content --
		msg_tSendMail_2.setContent(mp_tSendMail_2);
		// add handlers for main MIME types
		javax.activation.MailcapCommandMap mc_tSendMail_2 = ( javax.activation.MailcapCommandMap)javax.activation.CommandMap.getDefaultCommandMap();
		mc_tSendMail_2.addMailcap("text/html;; x-java-content-handler=com.sun.mail.handlers.text_html");
		mc_tSendMail_2.addMailcap("text/xml;; x-java-content-handler=com.sun.mail.handlers.text_xml");
		mc_tSendMail_2.addMailcap("text/plain;; x-java-content-handler=com.sun.mail.handlers.text_plain");
		mc_tSendMail_2.addMailcap("multipart/*;; x-java-content-handler=com.sun.mail.handlers.multipart_mixed");
		mc_tSendMail_2.addMailcap("message/rfc822;; x-java-content-handler=com.sun.mail.handlers.message_rfc822");
		javax.activation.CommandMap.setDefaultCommandMap(mc_tSendMail_2);
		// -- Send the message --
		javax.mail.Transport.send(msg_tSendMail_2);
	} catch(java.lang.Exception e){
  		
			
				log.error("tSendMail_2 - " + e.toString());
			
  			System.err.println(e.toString());
		
	}finally{
		props_tSendMail_2.remove("mail.smtp.host");
		props_tSendMail_2.remove("mail.smtp.port");
		
		props_tSendMail_2.remove("mail.mime.encodefilename");
		
		props_tSendMail_2.remove("mail.smtp.auth");     
	}

 


	tos_count_tSendMail_2++;

/**
 * [tSendMail_2 main ] stop
 */







} // End of branch "row6"





} // End of branch "copyOfout"










	
	/**
	 * [tLogCatcher_1 end ] start
	 */

	

	
	
	currentComponent="tLogCatcher_1";

	
	}
 
                if(log.isDebugEnabled())
            log.debug("tLogCatcher_1 - "  + ("Done.") );

ok_Hash.put("tLogCatcher_1", true);
end_Hash.put("tLogCatcher_1", System.currentTimeMillis());




/**
 * [tLogCatcher_1 end ] stop
 */

	
	/**
	 * [tLogRow_3 end ] start
	 */

	

	
	
	currentComponent="tLogRow_3";

	


//////
//////
globalMap.put("tLogRow_3_NB_LINE",nb_line_tLogRow_3);
                if(log.isInfoEnabled())
            log.info("tLogRow_3 - "  + ("Printed row count: ")  + (nb_line_tLogRow_3)  + (".") );

///////////////////////    			

			if(execStat){
				if(resourceMap.get("inIterateVComp") == null || !((Boolean)resourceMap.get("inIterateVComp"))){
			 		runStat.updateStatOnConnection("row5"+iterateId,2, 0); 
			 	}
			}
		
 
                if(log.isDebugEnabled())
            log.debug("tLogRow_3 - "  + ("Done.") );

ok_Hash.put("tLogRow_3", true);
end_Hash.put("tLogRow_3", System.currentTimeMillis());




/**
 * [tLogRow_3 end ] stop
 */

	
	/**
	 * [tMap_3 end ] start
	 */

	

	
	
	currentComponent="tMap_3";

	


// ###############################
// # Lookup hashes releasing
// ###############################      
				log.debug("tMap_3 - Written records count in the table 'copyOfout': " + count_copyOfout_tMap_3 + ".");





			if(execStat){
				if(resourceMap.get("inIterateVComp") == null || !((Boolean)resourceMap.get("inIterateVComp"))){
			 		runStat.updateStatOnConnection("row3"+iterateId,2, 0); 
			 	}
			}
		
 
                if(log.isDebugEnabled())
            log.debug("tMap_3 - "  + ("Done.") );

ok_Hash.put("tMap_3", true);
end_Hash.put("tMap_3", System.currentTimeMillis());




/**
 * [tMap_3 end ] stop
 */

	
	/**
	 * [tPostgresqlOutput_3 end ] start
	 */

	

	
	
	currentComponent="tPostgresqlOutput_3";

	



	    try {
				int countSum_tPostgresqlOutput_3 = 0;
				if (pstmt_tPostgresqlOutput_3 != null && batchSizeCounter_tPostgresqlOutput_3 > 0) {
						
                if(log.isDebugEnabled())
            log.debug("tPostgresqlOutput_3 - "  + ("Executing the ")  + ("INSERT")  + (" batch.") );
					for(int countEach_tPostgresqlOutput_3: pstmt_tPostgresqlOutput_3.executeBatch()) {
						countSum_tPostgresqlOutput_3 += (countEach_tPostgresqlOutput_3 < 0 ? 0 : countEach_tPostgresqlOutput_3);
					}
						
                if(log.isDebugEnabled())
            log.debug("tPostgresqlOutput_3 - "  + ("The ")  + ("INSERT")  + (" batch execution has succeeded.") );
				}
		    	
		    		insertedCount_tPostgresqlOutput_3 += countSum_tPostgresqlOutput_3;
		    	
	    }catch (java.sql.BatchUpdateException e){
	    	
	    	int countSum_tPostgresqlOutput_3 = 0;
			for(int countEach_tPostgresqlOutput_3: e.getUpdateCounts()) {
				countSum_tPostgresqlOutput_3 += (countEach_tPostgresqlOutput_3 < 0 ? 0 : countEach_tPostgresqlOutput_3);
			}
			
	    		insertedCount_tPostgresqlOutput_3 += countSum_tPostgresqlOutput_3;
	    	
            log.error("tPostgresqlOutput_3 - "  + (e.getMessage()) );
	    	System.err.println(e.getMessage());
	    	
		}
	    
        if(pstmt_tPostgresqlOutput_3 != null) {
            pstmt_tPostgresqlOutput_3.close();
        }

			
                if(log.isDebugEnabled())
            log.debug("tPostgresqlOutput_3 - "  + ("Connection starting to commit ")  + (commitCounter_tPostgresqlOutput_3)  + (" record(s).") );
			conn_tPostgresqlOutput_3.commit();
			
                if(log.isDebugEnabled())
            log.debug("tPostgresqlOutput_3 - "  + ("Connection commit has succeeded.") );
		
                if(log.isDebugEnabled())
            log.debug("tPostgresqlOutput_3 - "  + ("Closing the connection to the database.") );
    	conn_tPostgresqlOutput_3 .close();
    	
                if(log.isDebugEnabled())
            log.debug("tPostgresqlOutput_3 - "  + ("Connection to the database has closed.") );
    	resourceMap.put("finish_tPostgresqlOutput_3", true);
    	

	nb_line_deleted_tPostgresqlOutput_3=nb_line_deleted_tPostgresqlOutput_3+ deletedCount_tPostgresqlOutput_3;
	nb_line_update_tPostgresqlOutput_3=nb_line_update_tPostgresqlOutput_3 + updatedCount_tPostgresqlOutput_3;
	nb_line_inserted_tPostgresqlOutput_3=nb_line_inserted_tPostgresqlOutput_3 + insertedCount_tPostgresqlOutput_3;
	nb_line_rejected_tPostgresqlOutput_3=nb_line_rejected_tPostgresqlOutput_3 + rejectedCount_tPostgresqlOutput_3;
	
        globalMap.put("tPostgresqlOutput_3_NB_LINE",nb_line_tPostgresqlOutput_3);
        globalMap.put("tPostgresqlOutput_3_NB_LINE_UPDATED",nb_line_update_tPostgresqlOutput_3);
        globalMap.put("tPostgresqlOutput_3_NB_LINE_INSERTED",nb_line_inserted_tPostgresqlOutput_3);
        globalMap.put("tPostgresqlOutput_3_NB_LINE_DELETED",nb_line_deleted_tPostgresqlOutput_3);
        globalMap.put("tPostgresqlOutput_3_NB_LINE_REJECTED", nb_line_rejected_tPostgresqlOutput_3);
    
	
                if(log.isDebugEnabled())
            log.debug("tPostgresqlOutput_3 - "  + ("Has ")  + ("inserted")  + (" ")  + (nb_line_inserted_tPostgresqlOutput_3)  + (" record(s).") );


			if(execStat){
				if(resourceMap.get("inIterateVComp") == null || !((Boolean)resourceMap.get("inIterateVComp"))){
			 		runStat.updateStatOnConnection("copyOfout"+iterateId,2, 0); 
			 	}
			}
		
 
                if(log.isDebugEnabled())
            log.debug("tPostgresqlOutput_3 - "  + ("Done.") );

ok_Hash.put("tPostgresqlOutput_3", true);
end_Hash.put("tPostgresqlOutput_3", System.currentTimeMillis());




/**
 * [tPostgresqlOutput_3 end ] stop
 */

	
	/**
	 * [tLogRow_4 end ] start
	 */

	

	
	
	currentComponent="tLogRow_4";

	


//////

                    
                    java.io.PrintStream consoleOut_tLogRow_4 = null;
                    if (globalMap.get("tLogRow_CONSOLE")!=null)
                    {
                    	consoleOut_tLogRow_4 = (java.io.PrintStream) globalMap.get("tLogRow_CONSOLE");
                    }
                    else
                    {
                    	consoleOut_tLogRow_4 = new java.io.PrintStream(new java.io.BufferedOutputStream(System.out));
                    	globalMap.put("tLogRow_CONSOLE",consoleOut_tLogRow_4);
                    }
                    
                    consoleOut_tLogRow_4.println(util_tLogRow_4.format().toString());
                    consoleOut_tLogRow_4.flush();
//////
globalMap.put("tLogRow_4_NB_LINE",nb_line_tLogRow_4);
                if(log.isInfoEnabled())
            log.info("tLogRow_4 - "  + ("Printed row count: ")  + (nb_line_tLogRow_4)  + (".") );

///////////////////////    			

			if(execStat){
				if(resourceMap.get("inIterateVComp") == null || !((Boolean)resourceMap.get("inIterateVComp"))){
			 		runStat.updateStatOnConnection("row6"+iterateId,2, 0); 
			 	}
			}
		
 
                if(log.isDebugEnabled())
            log.debug("tLogRow_4 - "  + ("Done.") );

ok_Hash.put("tLogRow_4", true);
end_Hash.put("tLogRow_4", System.currentTimeMillis());




/**
 * [tLogRow_4 end ] stop
 */

	
	/**
	 * [tJavaRow_2 end ] start
	 */

	

	
	
	currentComponent="tJavaRow_2";

	

globalMap.put("tJavaRow_2_NB_LINE",nb_line_tJavaRow_2);
			if(execStat){
				if(resourceMap.get("inIterateVComp") == null || !((Boolean)resourceMap.get("inIterateVComp"))){
			 		runStat.updateStatOnConnection("row10"+iterateId,2, 0); 
			 	}
			}
		
 

ok_Hash.put("tJavaRow_2", true);
end_Hash.put("tJavaRow_2", System.currentTimeMillis());




/**
 * [tJavaRow_2 end ] stop
 */

	
	/**
	 * [tSendMail_2 end ] start
	 */

	

	
	
	currentComponent="tSendMail_2";

	

			if(execStat){
				if(resourceMap.get("inIterateVComp") == null || !((Boolean)resourceMap.get("inIterateVComp"))){
			 		runStat.updateStatOnConnection("row11"+iterateId,2, 0); 
			 	}
			}
		
 
                if(log.isDebugEnabled())
            log.debug("tSendMail_2 - "  + ("Done.") );

ok_Hash.put("tSendMail_2", true);
end_Hash.put("tSendMail_2", System.currentTimeMillis());




/**
 * [tSendMail_2 end ] stop
 */


















				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage());
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tLogCatcher_1 finally ] start
	 */

	

	
	
	currentComponent="tLogCatcher_1";

	

 



/**
 * [tLogCatcher_1 finally ] stop
 */

	
	/**
	 * [tLogRow_3 finally ] start
	 */

	

	
	
	currentComponent="tLogRow_3";

	

 



/**
 * [tLogRow_3 finally ] stop
 */

	
	/**
	 * [tMap_3 finally ] start
	 */

	

	
	
	currentComponent="tMap_3";

	

 



/**
 * [tMap_3 finally ] stop
 */

	
	/**
	 * [tPostgresqlOutput_3 finally ] start
	 */

	

	
	
	currentComponent="tPostgresqlOutput_3";

	



	
		if(resourceMap.get("finish_tPostgresqlOutput_3")==null){
			if(resourceMap.get("conn_tPostgresqlOutput_3")!=null){
				try {
					
                if(log.isDebugEnabled())
            log.debug("tPostgresqlOutput_3 - "  + ("Closing the connection to the database.") );
					((java.sql.Connection)resourceMap.get("conn_tPostgresqlOutput_3")).close();
					
                if(log.isDebugEnabled())
            log.debug("tPostgresqlOutput_3 - "  + ("Connection to the database has closed.") );
				} catch (java.sql.SQLException sqlEx_tPostgresqlOutput_3) {
					String errorMessage_tPostgresqlOutput_3 = "failed to close the connection in tPostgresqlOutput_3 :" + sqlEx_tPostgresqlOutput_3.getMessage();
					
            log.error("tPostgresqlOutput_3 - "  + (errorMessage_tPostgresqlOutput_3) );
					System.err.println(errorMessage_tPostgresqlOutput_3);
				}
			}
		}
	

 



/**
 * [tPostgresqlOutput_3 finally ] stop
 */

	
	/**
	 * [tLogRow_4 finally ] start
	 */

	

	
	
	currentComponent="tLogRow_4";

	

 



/**
 * [tLogRow_4 finally ] stop
 */

	
	/**
	 * [tJavaRow_2 finally ] start
	 */

	

	
	
	currentComponent="tJavaRow_2";

	

 



/**
 * [tJavaRow_2 finally ] stop
 */

	
	/**
	 * [tSendMail_2 finally ] start
	 */

	

	
	
	currentComponent="tSendMail_2";

	

 



/**
 * [tSendMail_2 finally ] stop
 */


















				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tLogCatcher_1_SUBPROCESS_STATE", 1);
	}
	


public static class AStruct implements routines.system.IPersistableRow<AStruct> {
    final static byte[] commonByteArrayLock_OG_APPLICATIONS_J_X_MAN_FINANCE_LAGTIME = new byte[0];
    static byte[] commonByteArray_OG_APPLICATIONS_J_X_MAN_FINANCE_LAGTIME = new byte[0];

	
			    public String company_code_key;

				public String getCompany_code_key () {
					return this.company_code_key;
				}
				
			    public String company_code_text;

				public String getCompany_code_text () {
					return this.company_code_text;
				}
				
			    public String company_code_country_text;

				public String getCompany_code_country_text () {
					return this.company_code_country_text;
				}
				
			    public String profit_center_key;

				public String getProfit_center_key () {
					return this.profit_center_key;
				}
				
			    public String profit_center_text;

				public String getProfit_center_text () {
					return this.profit_center_text;
				}
				
			    public String to_division;

				public String getTo_division () {
					return this.to_division;
				}
				
			    public String plant;

				public String getPlant () {
					return this.plant;
				}
				
			    public String billing_document;

				public String getBilling_document () {
					return this.billing_document;
				}
				
			    public String billing_document_item;

				public String getBilling_document_item () {
					return this.billing_document_item;
				}
				
			    public String payer_key;

				public String getPayer_key () {
					return this.payer_key;
				}
				
			    public String payer_text;

				public String getPayer_text () {
					return this.payer_text;
				}
				
			    public String fiscal_year_period_key;

				public String getFiscal_year_period_key () {
					return this.fiscal_year_period_key;
				}
				
			    public java.util.Date entry_date;

				public java.util.Date getEntry_date () {
					return this.entry_date;
				}
				
			    public java.util.Date rta_date;

				public java.util.Date getRta_date () {
					return this.rta_date;
				}
				
			    public java.util.Date serv_rendered_date;

				public java.util.Date getServ_rendered_date () {
					return this.serv_rendered_date;
				}
				
			    public java.util.Date act_goods_issue_date;

				public java.util.Date getAct_goods_issue_date () {
					return this.act_goods_issue_date;
				}
				
			    public String sales_document;

				public String getSales_document () {
					return this.sales_document;
				}
				
			    public String sales_document_item;

				public String getSales_document_item () {
					return this.sales_document_item;
				}
				
			    public String delivery_number;

				public String getDelivery_number () {
					return this.delivery_number;
				}
				
			    public String delivery_item;

				public String getDelivery_item () {
					return this.delivery_item;
				}
				
			    public String gl_account_key;

				public String getGl_account_key () {
					return this.gl_account_key;
				}
				
			    public String gl_account_text;

				public String getGl_account_text () {
					return this.gl_account_text;
				}
				
			    public String material_key;

				public String getMaterial_key () {
					return this.material_key;
				}
				
			    public String material_text;

				public String getMaterial_text () {
					return this.material_text;
				}
				
			    public String ship_to_party_key;

				public String getShip_to_party_key () {
					return this.ship_to_party_key;
				}
				
			    public String ship_to_party_text;

				public String getShip_to_party_text () {
					return this.ship_to_party_text;
				}
				
			    public String street_name_key;

				public String getStreet_name_key () {
					return this.street_name_key;
				}
				
			    public String location_key;

				public String getLocation_key () {
					return this.location_key;
				}
				
			    public String country_key;

				public String getCountry_key () {
					return this.country_key;
				}
				
			    public String country_text;

				public String getCountry_text () {
					return this.country_text;
				}
				
			    public String plant_key;

				public String getPlant_key () {
					return this.plant_key;
				}
				
			    public String plant_text;

				public String getPlant_text () {
					return this.plant_text;
				}
				
			    public String plant_bas_pstcdegeorelkey;

				public String getPlant_bas_pstcdegeorelkey () {
					return this.plant_bas_pstcdegeorelkey;
				}
				
			    public String plant_country_key;

				public String getPlant_country_key () {
					return this.plant_country_key;
				}
				
			    public String plant_country_text;

				public String getPlant_country_text () {
					return this.plant_country_text;
				}
				
			    public String incoterms;

				public String getIncoterms () {
					return this.incoterms;
				}
				
			    public String incoterms_2;

				public String getIncoterms_2 () {
					return this.incoterms_2;
				}
				
			    public String cancellation_flag_key;

				public String getCancellation_flag_key () {
					return this.cancellation_flag_key;
				}
				
			    public Double sales_in_document_currency;

				public Double getSales_in_document_currency () {
					return this.sales_in_document_currency;
				}
				
			    public String document_currency_key;

				public String getDocument_currency_key () {
					return this.document_currency_key;
				}
				
			    public Double amount_in_local_currency;

				public Double getAmount_in_local_currency () {
					return this.amount_in_local_currency;
				}
				
			    public Double amount_in_usd;

				public Double getAmount_in_usd () {
					return this.amount_in_usd;
				}
				
			    public String currency_key;

				public String getCurrency_key () {
					return this.currency_key;
				}
				
			    public Double lc1_for_cogs;

				public Double getLc1_for_cogs () {
					return this.lc1_for_cogs;
				}
				
			    public String local_currency_key;

				public String getLocal_currency_key () {
					return this.local_currency_key;
				}
				
			    public Double lc3_for_cogs;

				public Double getLc3_for_cogs () {
					return this.lc3_for_cogs;
				}
				
			    public String third_local_currency_key;

				public String getThird_local_currency_key () {
					return this.third_local_currency_key;
				}
				
			    public String movement_type;

				public String getMovement_type () {
					return this.movement_type;
				}
				
			    public Double group_currency_amount;

				public Double getGroup_currency_amount () {
					return this.group_currency_amount;
				}
				
			    public String group_currency;

				public String getGroup_currency () {
					return this.group_currency;
				}
				
			    public String ship_to_state;

				public String getShip_to_state () {
					return this.ship_to_state;
				}
				
			    public String plant_state;

				public String getPlant_state () {
					return this.plant_state;
				}
				
			    public String sales_assignment_number;

				public String getSales_assignment_number () {
					return this.sales_assignment_number;
				}
				
			    public java.util.Date load_date;

				public java.util.Date getLoad_date () {
					return this.load_date;
				}
				



	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_OG_APPLICATIONS_J_X_MAN_FINANCE_LAGTIME.length) {
				if(length < 1024 && commonByteArray_OG_APPLICATIONS_J_X_MAN_FINANCE_LAGTIME.length == 0) {
   					commonByteArray_OG_APPLICATIONS_J_X_MAN_FINANCE_LAGTIME = new byte[1024];
				} else {
   					commonByteArray_OG_APPLICATIONS_J_X_MAN_FINANCE_LAGTIME = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_OG_APPLICATIONS_J_X_MAN_FINANCE_LAGTIME, 0, length);
			strReturn = new String(commonByteArray_OG_APPLICATIONS_J_X_MAN_FINANCE_LAGTIME, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }

	private java.util.Date readDate(ObjectInputStream dis) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(dis.readLong());
		}
		return dateReturn;
	}

    private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException{
		if(date1 == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeLong(date1.getTime());
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_OG_APPLICATIONS_J_X_MAN_FINANCE_LAGTIME) {

        	try {

        		int length = 0;
		
					this.company_code_key = readString(dis);
					
					this.company_code_text = readString(dis);
					
					this.company_code_country_text = readString(dis);
					
					this.profit_center_key = readString(dis);
					
					this.profit_center_text = readString(dis);
					
					this.to_division = readString(dis);
					
					this.plant = readString(dis);
					
					this.billing_document = readString(dis);
					
					this.billing_document_item = readString(dis);
					
					this.payer_key = readString(dis);
					
					this.payer_text = readString(dis);
					
					this.fiscal_year_period_key = readString(dis);
					
					this.entry_date = readDate(dis);
					
					this.rta_date = readDate(dis);
					
					this.serv_rendered_date = readDate(dis);
					
					this.act_goods_issue_date = readDate(dis);
					
					this.sales_document = readString(dis);
					
					this.sales_document_item = readString(dis);
					
					this.delivery_number = readString(dis);
					
					this.delivery_item = readString(dis);
					
					this.gl_account_key = readString(dis);
					
					this.gl_account_text = readString(dis);
					
					this.material_key = readString(dis);
					
					this.material_text = readString(dis);
					
					this.ship_to_party_key = readString(dis);
					
					this.ship_to_party_text = readString(dis);
					
					this.street_name_key = readString(dis);
					
					this.location_key = readString(dis);
					
					this.country_key = readString(dis);
					
					this.country_text = readString(dis);
					
					this.plant_key = readString(dis);
					
					this.plant_text = readString(dis);
					
					this.plant_bas_pstcdegeorelkey = readString(dis);
					
					this.plant_country_key = readString(dis);
					
					this.plant_country_text = readString(dis);
					
					this.incoterms = readString(dis);
					
					this.incoterms_2 = readString(dis);
					
					this.cancellation_flag_key = readString(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.sales_in_document_currency = null;
           				} else {
           			    	this.sales_in_document_currency = dis.readDouble();
           				}
					
					this.document_currency_key = readString(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.amount_in_local_currency = null;
           				} else {
           			    	this.amount_in_local_currency = dis.readDouble();
           				}
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.amount_in_usd = null;
           				} else {
           			    	this.amount_in_usd = dis.readDouble();
           				}
					
					this.currency_key = readString(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.lc1_for_cogs = null;
           				} else {
           			    	this.lc1_for_cogs = dis.readDouble();
           				}
					
					this.local_currency_key = readString(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.lc3_for_cogs = null;
           				} else {
           			    	this.lc3_for_cogs = dis.readDouble();
           				}
					
					this.third_local_currency_key = readString(dis);
					
					this.movement_type = readString(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.group_currency_amount = null;
           				} else {
           			    	this.group_currency_amount = dis.readDouble();
           				}
					
					this.group_currency = readString(dis);
					
					this.ship_to_state = readString(dis);
					
					this.plant_state = readString(dis);
					
					this.sales_assignment_number = readString(dis);
					
					this.load_date = readDate(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// String
				
						writeString(this.company_code_key,dos);
					
					// String
				
						writeString(this.company_code_text,dos);
					
					// String
				
						writeString(this.company_code_country_text,dos);
					
					// String
				
						writeString(this.profit_center_key,dos);
					
					// String
				
						writeString(this.profit_center_text,dos);
					
					// String
				
						writeString(this.to_division,dos);
					
					// String
				
						writeString(this.plant,dos);
					
					// String
				
						writeString(this.billing_document,dos);
					
					// String
				
						writeString(this.billing_document_item,dos);
					
					// String
				
						writeString(this.payer_key,dos);
					
					// String
				
						writeString(this.payer_text,dos);
					
					// String
				
						writeString(this.fiscal_year_period_key,dos);
					
					// java.util.Date
				
						writeDate(this.entry_date,dos);
					
					// java.util.Date
				
						writeDate(this.rta_date,dos);
					
					// java.util.Date
				
						writeDate(this.serv_rendered_date,dos);
					
					// java.util.Date
				
						writeDate(this.act_goods_issue_date,dos);
					
					// String
				
						writeString(this.sales_document,dos);
					
					// String
				
						writeString(this.sales_document_item,dos);
					
					// String
				
						writeString(this.delivery_number,dos);
					
					// String
				
						writeString(this.delivery_item,dos);
					
					// String
				
						writeString(this.gl_account_key,dos);
					
					// String
				
						writeString(this.gl_account_text,dos);
					
					// String
				
						writeString(this.material_key,dos);
					
					// String
				
						writeString(this.material_text,dos);
					
					// String
				
						writeString(this.ship_to_party_key,dos);
					
					// String
				
						writeString(this.ship_to_party_text,dos);
					
					// String
				
						writeString(this.street_name_key,dos);
					
					// String
				
						writeString(this.location_key,dos);
					
					// String
				
						writeString(this.country_key,dos);
					
					// String
				
						writeString(this.country_text,dos);
					
					// String
				
						writeString(this.plant_key,dos);
					
					// String
				
						writeString(this.plant_text,dos);
					
					// String
				
						writeString(this.plant_bas_pstcdegeorelkey,dos);
					
					// String
				
						writeString(this.plant_country_key,dos);
					
					// String
				
						writeString(this.plant_country_text,dos);
					
					// String
				
						writeString(this.incoterms,dos);
					
					// String
				
						writeString(this.incoterms_2,dos);
					
					// String
				
						writeString(this.cancellation_flag_key,dos);
					
					// Double
				
						if(this.sales_in_document_currency == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this.sales_in_document_currency);
		            	}
					
					// String
				
						writeString(this.document_currency_key,dos);
					
					// Double
				
						if(this.amount_in_local_currency == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this.amount_in_local_currency);
		            	}
					
					// Double
				
						if(this.amount_in_usd == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this.amount_in_usd);
		            	}
					
					// String
				
						writeString(this.currency_key,dos);
					
					// Double
				
						if(this.lc1_for_cogs == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this.lc1_for_cogs);
		            	}
					
					// String
				
						writeString(this.local_currency_key,dos);
					
					// Double
				
						if(this.lc3_for_cogs == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this.lc3_for_cogs);
		            	}
					
					// String
				
						writeString(this.third_local_currency_key,dos);
					
					// String
				
						writeString(this.movement_type,dos);
					
					// Double
				
						if(this.group_currency_amount == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this.group_currency_amount);
		            	}
					
					// String
				
						writeString(this.group_currency,dos);
					
					// String
				
						writeString(this.ship_to_state,dos);
					
					// String
				
						writeString(this.plant_state,dos);
					
					// String
				
						writeString(this.sales_assignment_number,dos);
					
					// java.util.Date
				
						writeDate(this.load_date,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("company_code_key="+company_code_key);
		sb.append(",company_code_text="+company_code_text);
		sb.append(",company_code_country_text="+company_code_country_text);
		sb.append(",profit_center_key="+profit_center_key);
		sb.append(",profit_center_text="+profit_center_text);
		sb.append(",to_division="+to_division);
		sb.append(",plant="+plant);
		sb.append(",billing_document="+billing_document);
		sb.append(",billing_document_item="+billing_document_item);
		sb.append(",payer_key="+payer_key);
		sb.append(",payer_text="+payer_text);
		sb.append(",fiscal_year_period_key="+fiscal_year_period_key);
		sb.append(",entry_date="+String.valueOf(entry_date));
		sb.append(",rta_date="+String.valueOf(rta_date));
		sb.append(",serv_rendered_date="+String.valueOf(serv_rendered_date));
		sb.append(",act_goods_issue_date="+String.valueOf(act_goods_issue_date));
		sb.append(",sales_document="+sales_document);
		sb.append(",sales_document_item="+sales_document_item);
		sb.append(",delivery_number="+delivery_number);
		sb.append(",delivery_item="+delivery_item);
		sb.append(",gl_account_key="+gl_account_key);
		sb.append(",gl_account_text="+gl_account_text);
		sb.append(",material_key="+material_key);
		sb.append(",material_text="+material_text);
		sb.append(",ship_to_party_key="+ship_to_party_key);
		sb.append(",ship_to_party_text="+ship_to_party_text);
		sb.append(",street_name_key="+street_name_key);
		sb.append(",location_key="+location_key);
		sb.append(",country_key="+country_key);
		sb.append(",country_text="+country_text);
		sb.append(",plant_key="+plant_key);
		sb.append(",plant_text="+plant_text);
		sb.append(",plant_bas_pstcdegeorelkey="+plant_bas_pstcdegeorelkey);
		sb.append(",plant_country_key="+plant_country_key);
		sb.append(",plant_country_text="+plant_country_text);
		sb.append(",incoterms="+incoterms);
		sb.append(",incoterms_2="+incoterms_2);
		sb.append(",cancellation_flag_key="+cancellation_flag_key);
		sb.append(",sales_in_document_currency="+String.valueOf(sales_in_document_currency));
		sb.append(",document_currency_key="+document_currency_key);
		sb.append(",amount_in_local_currency="+String.valueOf(amount_in_local_currency));
		sb.append(",amount_in_usd="+String.valueOf(amount_in_usd));
		sb.append(",currency_key="+currency_key);
		sb.append(",lc1_for_cogs="+String.valueOf(lc1_for_cogs));
		sb.append(",local_currency_key="+local_currency_key);
		sb.append(",lc3_for_cogs="+String.valueOf(lc3_for_cogs));
		sb.append(",third_local_currency_key="+third_local_currency_key);
		sb.append(",movement_type="+movement_type);
		sb.append(",group_currency_amount="+String.valueOf(group_currency_amount));
		sb.append(",group_currency="+group_currency);
		sb.append(",ship_to_state="+ship_to_state);
		sb.append(",plant_state="+plant_state);
		sb.append(",sales_assignment_number="+sales_assignment_number);
		sb.append(",load_date="+String.valueOf(load_date));
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				if(company_code_key == null){
        					sb.append("<null>");
        				}else{
            				sb.append(company_code_key);
            			}
            		
        			sb.append("|");
        		
        				if(company_code_text == null){
        					sb.append("<null>");
        				}else{
            				sb.append(company_code_text);
            			}
            		
        			sb.append("|");
        		
        				if(company_code_country_text == null){
        					sb.append("<null>");
        				}else{
            				sb.append(company_code_country_text);
            			}
            		
        			sb.append("|");
        		
        				if(profit_center_key == null){
        					sb.append("<null>");
        				}else{
            				sb.append(profit_center_key);
            			}
            		
        			sb.append("|");
        		
        				if(profit_center_text == null){
        					sb.append("<null>");
        				}else{
            				sb.append(profit_center_text);
            			}
            		
        			sb.append("|");
        		
        				if(to_division == null){
        					sb.append("<null>");
        				}else{
            				sb.append(to_division);
            			}
            		
        			sb.append("|");
        		
        				if(plant == null){
        					sb.append("<null>");
        				}else{
            				sb.append(plant);
            			}
            		
        			sb.append("|");
        		
        				if(billing_document == null){
        					sb.append("<null>");
        				}else{
            				sb.append(billing_document);
            			}
            		
        			sb.append("|");
        		
        				if(billing_document_item == null){
        					sb.append("<null>");
        				}else{
            				sb.append(billing_document_item);
            			}
            		
        			sb.append("|");
        		
        				if(payer_key == null){
        					sb.append("<null>");
        				}else{
            				sb.append(payer_key);
            			}
            		
        			sb.append("|");
        		
        				if(payer_text == null){
        					sb.append("<null>");
        				}else{
            				sb.append(payer_text);
            			}
            		
        			sb.append("|");
        		
        				if(fiscal_year_period_key == null){
        					sb.append("<null>");
        				}else{
            				sb.append(fiscal_year_period_key);
            			}
            		
        			sb.append("|");
        		
        				if(entry_date == null){
        					sb.append("<null>");
        				}else{
            				sb.append(entry_date);
            			}
            		
        			sb.append("|");
        		
        				if(rta_date == null){
        					sb.append("<null>");
        				}else{
            				sb.append(rta_date);
            			}
            		
        			sb.append("|");
        		
        				if(serv_rendered_date == null){
        					sb.append("<null>");
        				}else{
            				sb.append(serv_rendered_date);
            			}
            		
        			sb.append("|");
        		
        				if(act_goods_issue_date == null){
        					sb.append("<null>");
        				}else{
            				sb.append(act_goods_issue_date);
            			}
            		
        			sb.append("|");
        		
        				if(sales_document == null){
        					sb.append("<null>");
        				}else{
            				sb.append(sales_document);
            			}
            		
        			sb.append("|");
        		
        				if(sales_document_item == null){
        					sb.append("<null>");
        				}else{
            				sb.append(sales_document_item);
            			}
            		
        			sb.append("|");
        		
        				if(delivery_number == null){
        					sb.append("<null>");
        				}else{
            				sb.append(delivery_number);
            			}
            		
        			sb.append("|");
        		
        				if(delivery_item == null){
        					sb.append("<null>");
        				}else{
            				sb.append(delivery_item);
            			}
            		
        			sb.append("|");
        		
        				if(gl_account_key == null){
        					sb.append("<null>");
        				}else{
            				sb.append(gl_account_key);
            			}
            		
        			sb.append("|");
        		
        				if(gl_account_text == null){
        					sb.append("<null>");
        				}else{
            				sb.append(gl_account_text);
            			}
            		
        			sb.append("|");
        		
        				if(material_key == null){
        					sb.append("<null>");
        				}else{
            				sb.append(material_key);
            			}
            		
        			sb.append("|");
        		
        				if(material_text == null){
        					sb.append("<null>");
        				}else{
            				sb.append(material_text);
            			}
            		
        			sb.append("|");
        		
        				if(ship_to_party_key == null){
        					sb.append("<null>");
        				}else{
            				sb.append(ship_to_party_key);
            			}
            		
        			sb.append("|");
        		
        				if(ship_to_party_text == null){
        					sb.append("<null>");
        				}else{
            				sb.append(ship_to_party_text);
            			}
            		
        			sb.append("|");
        		
        				if(street_name_key == null){
        					sb.append("<null>");
        				}else{
            				sb.append(street_name_key);
            			}
            		
        			sb.append("|");
        		
        				if(location_key == null){
        					sb.append("<null>");
        				}else{
            				sb.append(location_key);
            			}
            		
        			sb.append("|");
        		
        				if(country_key == null){
        					sb.append("<null>");
        				}else{
            				sb.append(country_key);
            			}
            		
        			sb.append("|");
        		
        				if(country_text == null){
        					sb.append("<null>");
        				}else{
            				sb.append(country_text);
            			}
            		
        			sb.append("|");
        		
        				if(plant_key == null){
        					sb.append("<null>");
        				}else{
            				sb.append(plant_key);
            			}
            		
        			sb.append("|");
        		
        				if(plant_text == null){
        					sb.append("<null>");
        				}else{
            				sb.append(plant_text);
            			}
            		
        			sb.append("|");
        		
        				if(plant_bas_pstcdegeorelkey == null){
        					sb.append("<null>");
        				}else{
            				sb.append(plant_bas_pstcdegeorelkey);
            			}
            		
        			sb.append("|");
        		
        				if(plant_country_key == null){
        					sb.append("<null>");
        				}else{
            				sb.append(plant_country_key);
            			}
            		
        			sb.append("|");
        		
        				if(plant_country_text == null){
        					sb.append("<null>");
        				}else{
            				sb.append(plant_country_text);
            			}
            		
        			sb.append("|");
        		
        				if(incoterms == null){
        					sb.append("<null>");
        				}else{
            				sb.append(incoterms);
            			}
            		
        			sb.append("|");
        		
        				if(incoterms_2 == null){
        					sb.append("<null>");
        				}else{
            				sb.append(incoterms_2);
            			}
            		
        			sb.append("|");
        		
        				if(cancellation_flag_key == null){
        					sb.append("<null>");
        				}else{
            				sb.append(cancellation_flag_key);
            			}
            		
        			sb.append("|");
        		
        				if(sales_in_document_currency == null){
        					sb.append("<null>");
        				}else{
            				sb.append(sales_in_document_currency);
            			}
            		
        			sb.append("|");
        		
        				if(document_currency_key == null){
        					sb.append("<null>");
        				}else{
            				sb.append(document_currency_key);
            			}
            		
        			sb.append("|");
        		
        				if(amount_in_local_currency == null){
        					sb.append("<null>");
        				}else{
            				sb.append(amount_in_local_currency);
            			}
            		
        			sb.append("|");
        		
        				if(amount_in_usd == null){
        					sb.append("<null>");
        				}else{
            				sb.append(amount_in_usd);
            			}
            		
        			sb.append("|");
        		
        				if(currency_key == null){
        					sb.append("<null>");
        				}else{
            				sb.append(currency_key);
            			}
            		
        			sb.append("|");
        		
        				if(lc1_for_cogs == null){
        					sb.append("<null>");
        				}else{
            				sb.append(lc1_for_cogs);
            			}
            		
        			sb.append("|");
        		
        				if(local_currency_key == null){
        					sb.append("<null>");
        				}else{
            				sb.append(local_currency_key);
            			}
            		
        			sb.append("|");
        		
        				if(lc3_for_cogs == null){
        					sb.append("<null>");
        				}else{
            				sb.append(lc3_for_cogs);
            			}
            		
        			sb.append("|");
        		
        				if(third_local_currency_key == null){
        					sb.append("<null>");
        				}else{
            				sb.append(third_local_currency_key);
            			}
            		
        			sb.append("|");
        		
        				if(movement_type == null){
        					sb.append("<null>");
        				}else{
            				sb.append(movement_type);
            			}
            		
        			sb.append("|");
        		
        				if(group_currency_amount == null){
        					sb.append("<null>");
        				}else{
            				sb.append(group_currency_amount);
            			}
            		
        			sb.append("|");
        		
        				if(group_currency == null){
        					sb.append("<null>");
        				}else{
            				sb.append(group_currency);
            			}
            		
        			sb.append("|");
        		
        				if(ship_to_state == null){
        					sb.append("<null>");
        				}else{
            				sb.append(ship_to_state);
            			}
            		
        			sb.append("|");
        		
        				if(plant_state == null){
        					sb.append("<null>");
        				}else{
            				sb.append(plant_state);
            			}
            		
        			sb.append("|");
        		
        				if(sales_assignment_number == null){
        					sb.append("<null>");
        				}else{
            				sb.append(sales_assignment_number);
            			}
            		
        			sb.append("|");
        		
        				if(load_date == null){
        					sb.append("<null>");
        				}else{
            				sb.append(load_date);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(AStruct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public static class row2Struct implements routines.system.IPersistableRow<row2Struct> {
    final static byte[] commonByteArrayLock_OG_APPLICATIONS_J_X_MAN_FINANCE_LAGTIME = new byte[0];
    static byte[] commonByteArray_OG_APPLICATIONS_J_X_MAN_FINANCE_LAGTIME = new byte[0];

	
			    public Integer OHREQUID;

				public Integer getOHREQUID () {
					return this.OHREQUID;
				}
				
			    public Integer DATAPAKID;

				public Integer getDATAPAKID () {
					return this.DATAPAKID;
				}
				
			    public Integer RECORD;

				public Integer getRECORD () {
					return this.RECORD;
				}
				
			    public String BILL_ITEM;

				public String getBILL_ITEM () {
					return this.BILL_ITEM;
				}
				
			    public String BILL_NUM;

				public String getBILL_NUM () {
					return this.BILL_NUM;
				}
				
			    public String DOC_NUMBER;

				public String getDOC_NUMBER () {
					return this.DOC_NUMBER;
				}
				
			    public String S_ORD_ITEM;

				public String getS_ORD_ITEM () {
					return this.S_ORD_ITEM;
				}
				
			    public String MATERIAL;

				public String getMATERIAL () {
					return this.MATERIAL;
				}
				
			    public String CHRT_ACCTS;

				public String getCHRT_ACCTS () {
					return this.CHRT_ACCTS;
				}
				
			    public String GL_ACCOUNT;

				public String getGL_ACCOUNT () {
					return this.GL_ACCOUNT;
				}
				
			    public java.util.Date ACT_GI_DTE;

				public java.util.Date getACT_GI_DTE () {
					return this.ACT_GI_DTE;
				}
				
			    public String DELIV_ITEM;

				public String getDELIV_ITEM () {
					return this.DELIV_ITEM;
				}
				
			    public String DELIV_NUMB;

				public String getDELIV_NUMB () {
					return this.DELIV_NUMB;
				}
				
			    public String INCOTERMS;

				public String getINCOTERMS () {
					return this.INCOTERMS;
				}
				
			    public String INCOTERMS2;

				public String getINCOTERMS2 () {
					return this.INCOTERMS2;
				}
				
			    public Double SALES;

				public Double getSALES () {
					return this.SALES;
				}
				
			    public String CURRENCY;

				public String getCURRENCY () {
					return this.CURRENCY;
				}
				
			    public String DOC_CURRCY;

				public String getDOC_CURRCY () {
					return this.DOC_CURRCY;
				}
				
			    public String FISCPER;

				public String getFISCPER () {
					return this.FISCPER;
				}
				
			    public String FISCVARNT;

				public String getFISCVARNT () {
					return this.FISCVARNT;
				}
				
			    public String COMP_CODE;

				public String getCOMP_CODE () {
					return this.COMP_CODE;
				}
				
			    public String CO_AREA;

				public String getCO_AREA () {
					return this.CO_AREA;
				}
				
			    public String DIVISION;

				public String getDIVISION () {
					return this.DIVISION;
				}
				
			    public String PROFIT_CTR;

				public String getPROFIT_CTR () {
					return this.PROFIT_CTR;
				}
				
			    public String SHIP_TO;

				public String getSHIP_TO () {
					return this.SHIP_TO;
				}
				
			    public String LOC_CURRC3;

				public String getLOC_CURRC3 () {
					return this.LOC_CURRC3;
				}
				
			    public String PAYER;

				public String getPAYER () {
					return this.PAYER;
				}
				
			    public String PLANT;

				public String getPLANT () {
					return this.PLANT;
				}
				
			    public java.util.Date SERV_DATE;

				public java.util.Date getSERV_DATE () {
					return this.SERV_DATE;
				}
				
			    public Double _BIC_ZSALESLCY;

				public Double get_BIC_ZSALESLCY () {
					return this._BIC_ZSALESLCY;
				}
				
			    public String LOC_CURRCY;

				public String getLOC_CURRCY () {
					return this.LOC_CURRCY;
				}
				
			    public Double _BIC_ZSALESDCY;

				public Double get_BIC_ZSALESDCY () {
					return this._BIC_ZSALESDCY;
				}
				
			    public Double DEB_CRE_LC;

				public Double getDEB_CRE_LC () {
					return this.DEB_CRE_LC;
				}
				
			    public Double DEB_CRE_L3;

				public Double getDEB_CRE_L3 () {
					return this.DEB_CRE_L3;
				}
				
			    public String COUNTRY;

				public String getCOUNTRY () {
					return this.COUNTRY;
				}
				
			    public String _BIC_ZSTREET;

				public String get_BIC_ZSTREET () {
					return this._BIC_ZSTREET;
				}
				
			    public String _BIC_ZCITY;

				public String get_BIC_ZCITY () {
					return this._BIC_ZCITY;
				}
				
			    public String _BIC_ZCMPCDET;

				public String get_BIC_ZCMPCDET () {
					return this._BIC_ZCMPCDET;
				}
				
			    public String COMPANY;

				public String getCOMPANY () {
					return this.COMPANY;
				}
				
			    public String _BIC_ZPFTCTRT;

				public String get_BIC_ZPFTCTRT () {
					return this._BIC_ZPFTCTRT;
				}
				
			    public String _BIC_ZPAYERT;

				public String get_BIC_ZPAYERT () {
					return this._BIC_ZPAYERT;
				}
				
			    public java.util.Date PSTNG_DATE;

				public java.util.Date getPSTNG_DATE () {
					return this.PSTNG_DATE;
				}
				
			    public java.util.Date CREATEDON;

				public java.util.Date getCREATEDON () {
					return this.CREATEDON;
				}
				
			    public String _BIC_ZGLACCT;

				public String get_BIC_ZGLACCT () {
					return this._BIC_ZGLACCT;
				}
				
			    public String _BIC_ZSHIPT;

				public String get_BIC_ZSHIPT () {
					return this._BIC_ZSHIPT;
				}
				
			    public String _BIC_ZPLANTT;

				public String get_BIC_ZPLANTT () {
					return this._BIC_ZPLANTT;
				}
				
			    public String POSTCD_GIS;

				public String getPOSTCD_GIS () {
					return this.POSTCD_GIS;
				}
				
			    public String _BIC_ZPLANTC;

				public String get_BIC_ZPLANTC () {
					return this._BIC_ZPLANTC;
				}
				
			    public String REVERSEDOC;

				public String getREVERSEDOC () {
					return this.REVERSEDOC;
				}
				
			    public String _BIC_ZMATNAME;

				public String get_BIC_ZMATNAME () {
					return this._BIC_ZMATNAME;
				}
				
			    public String _BIC_ZCOUNTRYT;

				public String get_BIC_ZCOUNTRYT () {
					return this._BIC_ZCOUNTRYT;
				}
				
			    public String _BIC_ZPLANTCT;

				public String get_BIC_ZPLANTCT () {
					return this._BIC_ZPLANTCT;
				}
				
			    public String _BIC_ZCOMPC;

				public String get_BIC_ZCOMPC () {
					return this._BIC_ZCOMPC;
				}
				
			    public String _BIC_ZCOMPCT;

				public String get_BIC_ZCOMPCT () {
					return this._BIC_ZCOMPCT;
				}
				
			    public String _BIC_ZDIVISIONT;

				public String get_BIC_ZDIVISIONT () {
					return this._BIC_ZDIVISIONT;
				}
				
			    public String _BIC_ZINCOTERMT;

				public String get_BIC_ZINCOTERMT () {
					return this._BIC_ZINCOTERMT;
				}
				
			    public String _BIC_ZASSG_NUM;

				public String get_BIC_ZASSG_NUM () {
					return this._BIC_ZASSG_NUM;
				}
				
			    public String MOVETYPE;

				public String getMOVETYPE () {
					return this.MOVETYPE;
				}
				
			    public Double DEB_CRE_L2;

				public Double getDEB_CRE_L2 () {
					return this.DEB_CRE_L2;
				}
				
			    public String LOC_CURRC2;

				public String getLOC_CURRC2 () {
					return this.LOC_CURRC2;
				}
				
			    public String REGION;

				public String getREGION () {
					return this.REGION;
				}
				
			    public java.util.Date _BIC_ZDATE;

				public java.util.Date get_BIC_ZDATE () {
					return this._BIC_ZDATE;
				}
				


	private Integer readInteger(ObjectInputStream dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}

	private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException{
		if(intNum == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeInt(intNum);
    	}
	}

	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_OG_APPLICATIONS_J_X_MAN_FINANCE_LAGTIME.length) {
				if(length < 1024 && commonByteArray_OG_APPLICATIONS_J_X_MAN_FINANCE_LAGTIME.length == 0) {
   					commonByteArray_OG_APPLICATIONS_J_X_MAN_FINANCE_LAGTIME = new byte[1024];
				} else {
   					commonByteArray_OG_APPLICATIONS_J_X_MAN_FINANCE_LAGTIME = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_OG_APPLICATIONS_J_X_MAN_FINANCE_LAGTIME, 0, length);
			strReturn = new String(commonByteArray_OG_APPLICATIONS_J_X_MAN_FINANCE_LAGTIME, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }

	private java.util.Date readDate(ObjectInputStream dis) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(dis.readLong());
		}
		return dateReturn;
	}

    private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException{
		if(date1 == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeLong(date1.getTime());
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_OG_APPLICATIONS_J_X_MAN_FINANCE_LAGTIME) {

        	try {

        		int length = 0;
		
						this.OHREQUID = readInteger(dis);
					
						this.DATAPAKID = readInteger(dis);
					
						this.RECORD = readInteger(dis);
					
					this.BILL_ITEM = readString(dis);
					
					this.BILL_NUM = readString(dis);
					
					this.DOC_NUMBER = readString(dis);
					
					this.S_ORD_ITEM = readString(dis);
					
					this.MATERIAL = readString(dis);
					
					this.CHRT_ACCTS = readString(dis);
					
					this.GL_ACCOUNT = readString(dis);
					
					this.ACT_GI_DTE = readDate(dis);
					
					this.DELIV_ITEM = readString(dis);
					
					this.DELIV_NUMB = readString(dis);
					
					this.INCOTERMS = readString(dis);
					
					this.INCOTERMS2 = readString(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.SALES = null;
           				} else {
           			    	this.SALES = dis.readDouble();
           				}
					
					this.CURRENCY = readString(dis);
					
					this.DOC_CURRCY = readString(dis);
					
					this.FISCPER = readString(dis);
					
					this.FISCVARNT = readString(dis);
					
					this.COMP_CODE = readString(dis);
					
					this.CO_AREA = readString(dis);
					
					this.DIVISION = readString(dis);
					
					this.PROFIT_CTR = readString(dis);
					
					this.SHIP_TO = readString(dis);
					
					this.LOC_CURRC3 = readString(dis);
					
					this.PAYER = readString(dis);
					
					this.PLANT = readString(dis);
					
					this.SERV_DATE = readDate(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this._BIC_ZSALESLCY = null;
           				} else {
           			    	this._BIC_ZSALESLCY = dis.readDouble();
           				}
					
					this.LOC_CURRCY = readString(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this._BIC_ZSALESDCY = null;
           				} else {
           			    	this._BIC_ZSALESDCY = dis.readDouble();
           				}
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.DEB_CRE_LC = null;
           				} else {
           			    	this.DEB_CRE_LC = dis.readDouble();
           				}
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.DEB_CRE_L3 = null;
           				} else {
           			    	this.DEB_CRE_L3 = dis.readDouble();
           				}
					
					this.COUNTRY = readString(dis);
					
					this._BIC_ZSTREET = readString(dis);
					
					this._BIC_ZCITY = readString(dis);
					
					this._BIC_ZCMPCDET = readString(dis);
					
					this.COMPANY = readString(dis);
					
					this._BIC_ZPFTCTRT = readString(dis);
					
					this._BIC_ZPAYERT = readString(dis);
					
					this.PSTNG_DATE = readDate(dis);
					
					this.CREATEDON = readDate(dis);
					
					this._BIC_ZGLACCT = readString(dis);
					
					this._BIC_ZSHIPT = readString(dis);
					
					this._BIC_ZPLANTT = readString(dis);
					
					this.POSTCD_GIS = readString(dis);
					
					this._BIC_ZPLANTC = readString(dis);
					
					this.REVERSEDOC = readString(dis);
					
					this._BIC_ZMATNAME = readString(dis);
					
					this._BIC_ZCOUNTRYT = readString(dis);
					
					this._BIC_ZPLANTCT = readString(dis);
					
					this._BIC_ZCOMPC = readString(dis);
					
					this._BIC_ZCOMPCT = readString(dis);
					
					this._BIC_ZDIVISIONT = readString(dis);
					
					this._BIC_ZINCOTERMT = readString(dis);
					
					this._BIC_ZASSG_NUM = readString(dis);
					
					this.MOVETYPE = readString(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.DEB_CRE_L2 = null;
           				} else {
           			    	this.DEB_CRE_L2 = dis.readDouble();
           				}
					
					this.LOC_CURRC2 = readString(dis);
					
					this.REGION = readString(dis);
					
					this._BIC_ZDATE = readDate(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// Integer
				
						writeInteger(this.OHREQUID,dos);
					
					// Integer
				
						writeInteger(this.DATAPAKID,dos);
					
					// Integer
				
						writeInteger(this.RECORD,dos);
					
					// String
				
						writeString(this.BILL_ITEM,dos);
					
					// String
				
						writeString(this.BILL_NUM,dos);
					
					// String
				
						writeString(this.DOC_NUMBER,dos);
					
					// String
				
						writeString(this.S_ORD_ITEM,dos);
					
					// String
				
						writeString(this.MATERIAL,dos);
					
					// String
				
						writeString(this.CHRT_ACCTS,dos);
					
					// String
				
						writeString(this.GL_ACCOUNT,dos);
					
					// java.util.Date
				
						writeDate(this.ACT_GI_DTE,dos);
					
					// String
				
						writeString(this.DELIV_ITEM,dos);
					
					// String
				
						writeString(this.DELIV_NUMB,dos);
					
					// String
				
						writeString(this.INCOTERMS,dos);
					
					// String
				
						writeString(this.INCOTERMS2,dos);
					
					// Double
				
						if(this.SALES == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this.SALES);
		            	}
					
					// String
				
						writeString(this.CURRENCY,dos);
					
					// String
				
						writeString(this.DOC_CURRCY,dos);
					
					// String
				
						writeString(this.FISCPER,dos);
					
					// String
				
						writeString(this.FISCVARNT,dos);
					
					// String
				
						writeString(this.COMP_CODE,dos);
					
					// String
				
						writeString(this.CO_AREA,dos);
					
					// String
				
						writeString(this.DIVISION,dos);
					
					// String
				
						writeString(this.PROFIT_CTR,dos);
					
					// String
				
						writeString(this.SHIP_TO,dos);
					
					// String
				
						writeString(this.LOC_CURRC3,dos);
					
					// String
				
						writeString(this.PAYER,dos);
					
					// String
				
						writeString(this.PLANT,dos);
					
					// java.util.Date
				
						writeDate(this.SERV_DATE,dos);
					
					// Double
				
						if(this._BIC_ZSALESLCY == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this._BIC_ZSALESLCY);
		            	}
					
					// String
				
						writeString(this.LOC_CURRCY,dos);
					
					// Double
				
						if(this._BIC_ZSALESDCY == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this._BIC_ZSALESDCY);
		            	}
					
					// Double
				
						if(this.DEB_CRE_LC == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this.DEB_CRE_LC);
		            	}
					
					// Double
				
						if(this.DEB_CRE_L3 == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this.DEB_CRE_L3);
		            	}
					
					// String
				
						writeString(this.COUNTRY,dos);
					
					// String
				
						writeString(this._BIC_ZSTREET,dos);
					
					// String
				
						writeString(this._BIC_ZCITY,dos);
					
					// String
				
						writeString(this._BIC_ZCMPCDET,dos);
					
					// String
				
						writeString(this.COMPANY,dos);
					
					// String
				
						writeString(this._BIC_ZPFTCTRT,dos);
					
					// String
				
						writeString(this._BIC_ZPAYERT,dos);
					
					// java.util.Date
				
						writeDate(this.PSTNG_DATE,dos);
					
					// java.util.Date
				
						writeDate(this.CREATEDON,dos);
					
					// String
				
						writeString(this._BIC_ZGLACCT,dos);
					
					// String
				
						writeString(this._BIC_ZSHIPT,dos);
					
					// String
				
						writeString(this._BIC_ZPLANTT,dos);
					
					// String
				
						writeString(this.POSTCD_GIS,dos);
					
					// String
				
						writeString(this._BIC_ZPLANTC,dos);
					
					// String
				
						writeString(this.REVERSEDOC,dos);
					
					// String
				
						writeString(this._BIC_ZMATNAME,dos);
					
					// String
				
						writeString(this._BIC_ZCOUNTRYT,dos);
					
					// String
				
						writeString(this._BIC_ZPLANTCT,dos);
					
					// String
				
						writeString(this._BIC_ZCOMPC,dos);
					
					// String
				
						writeString(this._BIC_ZCOMPCT,dos);
					
					// String
				
						writeString(this._BIC_ZDIVISIONT,dos);
					
					// String
				
						writeString(this._BIC_ZINCOTERMT,dos);
					
					// String
				
						writeString(this._BIC_ZASSG_NUM,dos);
					
					// String
				
						writeString(this.MOVETYPE,dos);
					
					// Double
				
						if(this.DEB_CRE_L2 == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this.DEB_CRE_L2);
		            	}
					
					// String
				
						writeString(this.LOC_CURRC2,dos);
					
					// String
				
						writeString(this.REGION,dos);
					
					// java.util.Date
				
						writeDate(this._BIC_ZDATE,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("OHREQUID="+String.valueOf(OHREQUID));
		sb.append(",DATAPAKID="+String.valueOf(DATAPAKID));
		sb.append(",RECORD="+String.valueOf(RECORD));
		sb.append(",BILL_ITEM="+BILL_ITEM);
		sb.append(",BILL_NUM="+BILL_NUM);
		sb.append(",DOC_NUMBER="+DOC_NUMBER);
		sb.append(",S_ORD_ITEM="+S_ORD_ITEM);
		sb.append(",MATERIAL="+MATERIAL);
		sb.append(",CHRT_ACCTS="+CHRT_ACCTS);
		sb.append(",GL_ACCOUNT="+GL_ACCOUNT);
		sb.append(",ACT_GI_DTE="+String.valueOf(ACT_GI_DTE));
		sb.append(",DELIV_ITEM="+DELIV_ITEM);
		sb.append(",DELIV_NUMB="+DELIV_NUMB);
		sb.append(",INCOTERMS="+INCOTERMS);
		sb.append(",INCOTERMS2="+INCOTERMS2);
		sb.append(",SALES="+String.valueOf(SALES));
		sb.append(",CURRENCY="+CURRENCY);
		sb.append(",DOC_CURRCY="+DOC_CURRCY);
		sb.append(",FISCPER="+FISCPER);
		sb.append(",FISCVARNT="+FISCVARNT);
		sb.append(",COMP_CODE="+COMP_CODE);
		sb.append(",CO_AREA="+CO_AREA);
		sb.append(",DIVISION="+DIVISION);
		sb.append(",PROFIT_CTR="+PROFIT_CTR);
		sb.append(",SHIP_TO="+SHIP_TO);
		sb.append(",LOC_CURRC3="+LOC_CURRC3);
		sb.append(",PAYER="+PAYER);
		sb.append(",PLANT="+PLANT);
		sb.append(",SERV_DATE="+String.valueOf(SERV_DATE));
		sb.append(",_BIC_ZSALESLCY="+String.valueOf(_BIC_ZSALESLCY));
		sb.append(",LOC_CURRCY="+LOC_CURRCY);
		sb.append(",_BIC_ZSALESDCY="+String.valueOf(_BIC_ZSALESDCY));
		sb.append(",DEB_CRE_LC="+String.valueOf(DEB_CRE_LC));
		sb.append(",DEB_CRE_L3="+String.valueOf(DEB_CRE_L3));
		sb.append(",COUNTRY="+COUNTRY);
		sb.append(",_BIC_ZSTREET="+_BIC_ZSTREET);
		sb.append(",_BIC_ZCITY="+_BIC_ZCITY);
		sb.append(",_BIC_ZCMPCDET="+_BIC_ZCMPCDET);
		sb.append(",COMPANY="+COMPANY);
		sb.append(",_BIC_ZPFTCTRT="+_BIC_ZPFTCTRT);
		sb.append(",_BIC_ZPAYERT="+_BIC_ZPAYERT);
		sb.append(",PSTNG_DATE="+String.valueOf(PSTNG_DATE));
		sb.append(",CREATEDON="+String.valueOf(CREATEDON));
		sb.append(",_BIC_ZGLACCT="+_BIC_ZGLACCT);
		sb.append(",_BIC_ZSHIPT="+_BIC_ZSHIPT);
		sb.append(",_BIC_ZPLANTT="+_BIC_ZPLANTT);
		sb.append(",POSTCD_GIS="+POSTCD_GIS);
		sb.append(",_BIC_ZPLANTC="+_BIC_ZPLANTC);
		sb.append(",REVERSEDOC="+REVERSEDOC);
		sb.append(",_BIC_ZMATNAME="+_BIC_ZMATNAME);
		sb.append(",_BIC_ZCOUNTRYT="+_BIC_ZCOUNTRYT);
		sb.append(",_BIC_ZPLANTCT="+_BIC_ZPLANTCT);
		sb.append(",_BIC_ZCOMPC="+_BIC_ZCOMPC);
		sb.append(",_BIC_ZCOMPCT="+_BIC_ZCOMPCT);
		sb.append(",_BIC_ZDIVISIONT="+_BIC_ZDIVISIONT);
		sb.append(",_BIC_ZINCOTERMT="+_BIC_ZINCOTERMT);
		sb.append(",_BIC_ZASSG_NUM="+_BIC_ZASSG_NUM);
		sb.append(",MOVETYPE="+MOVETYPE);
		sb.append(",DEB_CRE_L2="+String.valueOf(DEB_CRE_L2));
		sb.append(",LOC_CURRC2="+LOC_CURRC2);
		sb.append(",REGION="+REGION);
		sb.append(",_BIC_ZDATE="+String.valueOf(_BIC_ZDATE));
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				if(OHREQUID == null){
        					sb.append("<null>");
        				}else{
            				sb.append(OHREQUID);
            			}
            		
        			sb.append("|");
        		
        				if(DATAPAKID == null){
        					sb.append("<null>");
        				}else{
            				sb.append(DATAPAKID);
            			}
            		
        			sb.append("|");
        		
        				if(RECORD == null){
        					sb.append("<null>");
        				}else{
            				sb.append(RECORD);
            			}
            		
        			sb.append("|");
        		
        				if(BILL_ITEM == null){
        					sb.append("<null>");
        				}else{
            				sb.append(BILL_ITEM);
            			}
            		
        			sb.append("|");
        		
        				if(BILL_NUM == null){
        					sb.append("<null>");
        				}else{
            				sb.append(BILL_NUM);
            			}
            		
        			sb.append("|");
        		
        				if(DOC_NUMBER == null){
        					sb.append("<null>");
        				}else{
            				sb.append(DOC_NUMBER);
            			}
            		
        			sb.append("|");
        		
        				if(S_ORD_ITEM == null){
        					sb.append("<null>");
        				}else{
            				sb.append(S_ORD_ITEM);
            			}
            		
        			sb.append("|");
        		
        				if(MATERIAL == null){
        					sb.append("<null>");
        				}else{
            				sb.append(MATERIAL);
            			}
            		
        			sb.append("|");
        		
        				if(CHRT_ACCTS == null){
        					sb.append("<null>");
        				}else{
            				sb.append(CHRT_ACCTS);
            			}
            		
        			sb.append("|");
        		
        				if(GL_ACCOUNT == null){
        					sb.append("<null>");
        				}else{
            				sb.append(GL_ACCOUNT);
            			}
            		
        			sb.append("|");
        		
        				if(ACT_GI_DTE == null){
        					sb.append("<null>");
        				}else{
            				sb.append(ACT_GI_DTE);
            			}
            		
        			sb.append("|");
        		
        				if(DELIV_ITEM == null){
        					sb.append("<null>");
        				}else{
            				sb.append(DELIV_ITEM);
            			}
            		
        			sb.append("|");
        		
        				if(DELIV_NUMB == null){
        					sb.append("<null>");
        				}else{
            				sb.append(DELIV_NUMB);
            			}
            		
        			sb.append("|");
        		
        				if(INCOTERMS == null){
        					sb.append("<null>");
        				}else{
            				sb.append(INCOTERMS);
            			}
            		
        			sb.append("|");
        		
        				if(INCOTERMS2 == null){
        					sb.append("<null>");
        				}else{
            				sb.append(INCOTERMS2);
            			}
            		
        			sb.append("|");
        		
        				if(SALES == null){
        					sb.append("<null>");
        				}else{
            				sb.append(SALES);
            			}
            		
        			sb.append("|");
        		
        				if(CURRENCY == null){
        					sb.append("<null>");
        				}else{
            				sb.append(CURRENCY);
            			}
            		
        			sb.append("|");
        		
        				if(DOC_CURRCY == null){
        					sb.append("<null>");
        				}else{
            				sb.append(DOC_CURRCY);
            			}
            		
        			sb.append("|");
        		
        				if(FISCPER == null){
        					sb.append("<null>");
        				}else{
            				sb.append(FISCPER);
            			}
            		
        			sb.append("|");
        		
        				if(FISCVARNT == null){
        					sb.append("<null>");
        				}else{
            				sb.append(FISCVARNT);
            			}
            		
        			sb.append("|");
        		
        				if(COMP_CODE == null){
        					sb.append("<null>");
        				}else{
            				sb.append(COMP_CODE);
            			}
            		
        			sb.append("|");
        		
        				if(CO_AREA == null){
        					sb.append("<null>");
        				}else{
            				sb.append(CO_AREA);
            			}
            		
        			sb.append("|");
        		
        				if(DIVISION == null){
        					sb.append("<null>");
        				}else{
            				sb.append(DIVISION);
            			}
            		
        			sb.append("|");
        		
        				if(PROFIT_CTR == null){
        					sb.append("<null>");
        				}else{
            				sb.append(PROFIT_CTR);
            			}
            		
        			sb.append("|");
        		
        				if(SHIP_TO == null){
        					sb.append("<null>");
        				}else{
            				sb.append(SHIP_TO);
            			}
            		
        			sb.append("|");
        		
        				if(LOC_CURRC3 == null){
        					sb.append("<null>");
        				}else{
            				sb.append(LOC_CURRC3);
            			}
            		
        			sb.append("|");
        		
        				if(PAYER == null){
        					sb.append("<null>");
        				}else{
            				sb.append(PAYER);
            			}
            		
        			sb.append("|");
        		
        				if(PLANT == null){
        					sb.append("<null>");
        				}else{
            				sb.append(PLANT);
            			}
            		
        			sb.append("|");
        		
        				if(SERV_DATE == null){
        					sb.append("<null>");
        				}else{
            				sb.append(SERV_DATE);
            			}
            		
        			sb.append("|");
        		
        				if(_BIC_ZSALESLCY == null){
        					sb.append("<null>");
        				}else{
            				sb.append(_BIC_ZSALESLCY);
            			}
            		
        			sb.append("|");
        		
        				if(LOC_CURRCY == null){
        					sb.append("<null>");
        				}else{
            				sb.append(LOC_CURRCY);
            			}
            		
        			sb.append("|");
        		
        				if(_BIC_ZSALESDCY == null){
        					sb.append("<null>");
        				}else{
            				sb.append(_BIC_ZSALESDCY);
            			}
            		
        			sb.append("|");
        		
        				if(DEB_CRE_LC == null){
        					sb.append("<null>");
        				}else{
            				sb.append(DEB_CRE_LC);
            			}
            		
        			sb.append("|");
        		
        				if(DEB_CRE_L3 == null){
        					sb.append("<null>");
        				}else{
            				sb.append(DEB_CRE_L3);
            			}
            		
        			sb.append("|");
        		
        				if(COUNTRY == null){
        					sb.append("<null>");
        				}else{
            				sb.append(COUNTRY);
            			}
            		
        			sb.append("|");
        		
        				if(_BIC_ZSTREET == null){
        					sb.append("<null>");
        				}else{
            				sb.append(_BIC_ZSTREET);
            			}
            		
        			sb.append("|");
        		
        				if(_BIC_ZCITY == null){
        					sb.append("<null>");
        				}else{
            				sb.append(_BIC_ZCITY);
            			}
            		
        			sb.append("|");
        		
        				if(_BIC_ZCMPCDET == null){
        					sb.append("<null>");
        				}else{
            				sb.append(_BIC_ZCMPCDET);
            			}
            		
        			sb.append("|");
        		
        				if(COMPANY == null){
        					sb.append("<null>");
        				}else{
            				sb.append(COMPANY);
            			}
            		
        			sb.append("|");
        		
        				if(_BIC_ZPFTCTRT == null){
        					sb.append("<null>");
        				}else{
            				sb.append(_BIC_ZPFTCTRT);
            			}
            		
        			sb.append("|");
        		
        				if(_BIC_ZPAYERT == null){
        					sb.append("<null>");
        				}else{
            				sb.append(_BIC_ZPAYERT);
            			}
            		
        			sb.append("|");
        		
        				if(PSTNG_DATE == null){
        					sb.append("<null>");
        				}else{
            				sb.append(PSTNG_DATE);
            			}
            		
        			sb.append("|");
        		
        				if(CREATEDON == null){
        					sb.append("<null>");
        				}else{
            				sb.append(CREATEDON);
            			}
            		
        			sb.append("|");
        		
        				if(_BIC_ZGLACCT == null){
        					sb.append("<null>");
        				}else{
            				sb.append(_BIC_ZGLACCT);
            			}
            		
        			sb.append("|");
        		
        				if(_BIC_ZSHIPT == null){
        					sb.append("<null>");
        				}else{
            				sb.append(_BIC_ZSHIPT);
            			}
            		
        			sb.append("|");
        		
        				if(_BIC_ZPLANTT == null){
        					sb.append("<null>");
        				}else{
            				sb.append(_BIC_ZPLANTT);
            			}
            		
        			sb.append("|");
        		
        				if(POSTCD_GIS == null){
        					sb.append("<null>");
        				}else{
            				sb.append(POSTCD_GIS);
            			}
            		
        			sb.append("|");
        		
        				if(_BIC_ZPLANTC == null){
        					sb.append("<null>");
        				}else{
            				sb.append(_BIC_ZPLANTC);
            			}
            		
        			sb.append("|");
        		
        				if(REVERSEDOC == null){
        					sb.append("<null>");
        				}else{
            				sb.append(REVERSEDOC);
            			}
            		
        			sb.append("|");
        		
        				if(_BIC_ZMATNAME == null){
        					sb.append("<null>");
        				}else{
            				sb.append(_BIC_ZMATNAME);
            			}
            		
        			sb.append("|");
        		
        				if(_BIC_ZCOUNTRYT == null){
        					sb.append("<null>");
        				}else{
            				sb.append(_BIC_ZCOUNTRYT);
            			}
            		
        			sb.append("|");
        		
        				if(_BIC_ZPLANTCT == null){
        					sb.append("<null>");
        				}else{
            				sb.append(_BIC_ZPLANTCT);
            			}
            		
        			sb.append("|");
        		
        				if(_BIC_ZCOMPC == null){
        					sb.append("<null>");
        				}else{
            				sb.append(_BIC_ZCOMPC);
            			}
            		
        			sb.append("|");
        		
        				if(_BIC_ZCOMPCT == null){
        					sb.append("<null>");
        				}else{
            				sb.append(_BIC_ZCOMPCT);
            			}
            		
        			sb.append("|");
        		
        				if(_BIC_ZDIVISIONT == null){
        					sb.append("<null>");
        				}else{
            				sb.append(_BIC_ZDIVISIONT);
            			}
            		
        			sb.append("|");
        		
        				if(_BIC_ZINCOTERMT == null){
        					sb.append("<null>");
        				}else{
            				sb.append(_BIC_ZINCOTERMT);
            			}
            		
        			sb.append("|");
        		
        				if(_BIC_ZASSG_NUM == null){
        					sb.append("<null>");
        				}else{
            				sb.append(_BIC_ZASSG_NUM);
            			}
            		
        			sb.append("|");
        		
        				if(MOVETYPE == null){
        					sb.append("<null>");
        				}else{
            				sb.append(MOVETYPE);
            			}
            		
        			sb.append("|");
        		
        				if(DEB_CRE_L2 == null){
        					sb.append("<null>");
        				}else{
            				sb.append(DEB_CRE_L2);
            			}
            		
        			sb.append("|");
        		
        				if(LOC_CURRC2 == null){
        					sb.append("<null>");
        				}else{
            				sb.append(LOC_CURRC2);
            			}
            		
        			sb.append("|");
        		
        				if(REGION == null){
        					sb.append("<null>");
        				}else{
            				sb.append(REGION);
            			}
            		
        			sb.append("|");
        		
        				if(_BIC_ZDATE == null){
        					sb.append("<null>");
        				}else{
            				sb.append(_BIC_ZDATE);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(row2Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public static class row1Struct implements routines.system.IPersistableRow<row1Struct> {
    final static byte[] commonByteArrayLock_OG_APPLICATIONS_J_X_MAN_FINANCE_LAGTIME = new byte[0];
    static byte[] commonByteArray_OG_APPLICATIONS_J_X_MAN_FINANCE_LAGTIME = new byte[0];
	protected static final int DEFAULT_HASHCODE = 1;
    protected static final int PRIME = 31;
    protected int hashCode = DEFAULT_HASHCODE;
    public boolean hashCodeDirty = true;

    public String loopKey;



	
			    public Integer OHREQUID;

				public Integer getOHREQUID () {
					return this.OHREQUID;
				}
				
			    public Integer DATAPAKID;

				public Integer getDATAPAKID () {
					return this.DATAPAKID;
				}
				
			    public Integer RECORD;

				public Integer getRECORD () {
					return this.RECORD;
				}
				
			    public String BILL_ITEM;

				public String getBILL_ITEM () {
					return this.BILL_ITEM;
				}
				
			    public String BILL_NUM;

				public String getBILL_NUM () {
					return this.BILL_NUM;
				}
				
			    public String DOC_NUMBER;

				public String getDOC_NUMBER () {
					return this.DOC_NUMBER;
				}
				
			    public String S_ORD_ITEM;

				public String getS_ORD_ITEM () {
					return this.S_ORD_ITEM;
				}
				
			    public String MATERIAL;

				public String getMATERIAL () {
					return this.MATERIAL;
				}
				
			    public String CHRT_ACCTS;

				public String getCHRT_ACCTS () {
					return this.CHRT_ACCTS;
				}
				
			    public String GL_ACCOUNT;

				public String getGL_ACCOUNT () {
					return this.GL_ACCOUNT;
				}
				
			    public java.util.Date ACT_GI_DTE;

				public java.util.Date getACT_GI_DTE () {
					return this.ACT_GI_DTE;
				}
				
			    public String DELIV_ITEM;

				public String getDELIV_ITEM () {
					return this.DELIV_ITEM;
				}
				
			    public String DELIV_NUMB;

				public String getDELIV_NUMB () {
					return this.DELIV_NUMB;
				}
				
			    public String INCOTERMS;

				public String getINCOTERMS () {
					return this.INCOTERMS;
				}
				
			    public String INCOTERMS2;

				public String getINCOTERMS2 () {
					return this.INCOTERMS2;
				}
				
			    public Double SALES;

				public Double getSALES () {
					return this.SALES;
				}
				
			    public String CURRENCY;

				public String getCURRENCY () {
					return this.CURRENCY;
				}
				
			    public String DOC_CURRCY;

				public String getDOC_CURRCY () {
					return this.DOC_CURRCY;
				}
				
			    public String FISCPER;

				public String getFISCPER () {
					return this.FISCPER;
				}
				
			    public String FISCVARNT;

				public String getFISCVARNT () {
					return this.FISCVARNT;
				}
				
			    public String COMP_CODE;

				public String getCOMP_CODE () {
					return this.COMP_CODE;
				}
				
			    public String CO_AREA;

				public String getCO_AREA () {
					return this.CO_AREA;
				}
				
			    public String DIVISION;

				public String getDIVISION () {
					return this.DIVISION;
				}
				
			    public String PROFIT_CTR;

				public String getPROFIT_CTR () {
					return this.PROFIT_CTR;
				}
				
			    public String SHIP_TO;

				public String getSHIP_TO () {
					return this.SHIP_TO;
				}
				
			    public String LOC_CURRC3;

				public String getLOC_CURRC3 () {
					return this.LOC_CURRC3;
				}
				
			    public String PAYER;

				public String getPAYER () {
					return this.PAYER;
				}
				
			    public String PLANT;

				public String getPLANT () {
					return this.PLANT;
				}
				
			    public java.util.Date SERV_DATE;

				public java.util.Date getSERV_DATE () {
					return this.SERV_DATE;
				}
				
			    public Double _BIC_ZSALESLCY;

				public Double get_BIC_ZSALESLCY () {
					return this._BIC_ZSALESLCY;
				}
				
			    public String LOC_CURRCY;

				public String getLOC_CURRCY () {
					return this.LOC_CURRCY;
				}
				
			    public Double _BIC_ZSALESDCY;

				public Double get_BIC_ZSALESDCY () {
					return this._BIC_ZSALESDCY;
				}
				
			    public Double DEB_CRE_LC;

				public Double getDEB_CRE_LC () {
					return this.DEB_CRE_LC;
				}
				
			    public Double DEB_CRE_L3;

				public Double getDEB_CRE_L3 () {
					return this.DEB_CRE_L3;
				}
				
			    public String COUNTRY;

				public String getCOUNTRY () {
					return this.COUNTRY;
				}
				
			    public String _BIC_ZSTREET;

				public String get_BIC_ZSTREET () {
					return this._BIC_ZSTREET;
				}
				
			    public String _BIC_ZCITY;

				public String get_BIC_ZCITY () {
					return this._BIC_ZCITY;
				}
				
			    public String _BIC_ZCMPCDET;

				public String get_BIC_ZCMPCDET () {
					return this._BIC_ZCMPCDET;
				}
				
			    public String COMPANY;

				public String getCOMPANY () {
					return this.COMPANY;
				}
				
			    public String _BIC_ZPFTCTRT;

				public String get_BIC_ZPFTCTRT () {
					return this._BIC_ZPFTCTRT;
				}
				
			    public String _BIC_ZPAYERT;

				public String get_BIC_ZPAYERT () {
					return this._BIC_ZPAYERT;
				}
				
			    public java.util.Date PSTNG_DATE;

				public java.util.Date getPSTNG_DATE () {
					return this.PSTNG_DATE;
				}
				
			    public java.util.Date CREATEDON;

				public java.util.Date getCREATEDON () {
					return this.CREATEDON;
				}
				
			    public String _BIC_ZGLACCT;

				public String get_BIC_ZGLACCT () {
					return this._BIC_ZGLACCT;
				}
				
			    public String _BIC_ZSHIPT;

				public String get_BIC_ZSHIPT () {
					return this._BIC_ZSHIPT;
				}
				
			    public String _BIC_ZPLANTT;

				public String get_BIC_ZPLANTT () {
					return this._BIC_ZPLANTT;
				}
				
			    public String POSTCD_GIS;

				public String getPOSTCD_GIS () {
					return this.POSTCD_GIS;
				}
				
			    public String _BIC_ZPLANTC;

				public String get_BIC_ZPLANTC () {
					return this._BIC_ZPLANTC;
				}
				
			    public String REVERSEDOC;

				public String getREVERSEDOC () {
					return this.REVERSEDOC;
				}
				
			    public String _BIC_ZMATNAME;

				public String get_BIC_ZMATNAME () {
					return this._BIC_ZMATNAME;
				}
				
			    public String _BIC_ZCOUNTRYT;

				public String get_BIC_ZCOUNTRYT () {
					return this._BIC_ZCOUNTRYT;
				}
				
			    public String _BIC_ZPLANTCT;

				public String get_BIC_ZPLANTCT () {
					return this._BIC_ZPLANTCT;
				}
				
			    public String _BIC_ZCOMPC;

				public String get_BIC_ZCOMPC () {
					return this._BIC_ZCOMPC;
				}
				
			    public String _BIC_ZCOMPCT;

				public String get_BIC_ZCOMPCT () {
					return this._BIC_ZCOMPCT;
				}
				
			    public String _BIC_ZDIVISIONT;

				public String get_BIC_ZDIVISIONT () {
					return this._BIC_ZDIVISIONT;
				}
				
			    public String _BIC_ZINCOTERMT;

				public String get_BIC_ZINCOTERMT () {
					return this._BIC_ZINCOTERMT;
				}
				
			    public String _BIC_ZASSG_NUM;

				public String get_BIC_ZASSG_NUM () {
					return this._BIC_ZASSG_NUM;
				}
				
			    public String MOVETYPE;

				public String getMOVETYPE () {
					return this.MOVETYPE;
				}
				
			    public Double DEB_CRE_L2;

				public Double getDEB_CRE_L2 () {
					return this.DEB_CRE_L2;
				}
				
			    public String LOC_CURRC2;

				public String getLOC_CURRC2 () {
					return this.LOC_CURRC2;
				}
				
			    public String REGION;

				public String getREGION () {
					return this.REGION;
				}
				
			    public java.util.Date _BIC_ZDATE;

				public java.util.Date get_BIC_ZDATE () {
					return this._BIC_ZDATE;
				}
				


	@Override
	public int hashCode() {
		if (this.hashCodeDirty) {
			final int prime = PRIME;
			int result = DEFAULT_HASHCODE;
	
						result = prime * result + ((this.OHREQUID == null) ? 0 : this.OHREQUID.hashCode());
					
						result = prime * result + ((this.DATAPAKID == null) ? 0 : this.DATAPAKID.hashCode());
					
						result = prime * result + ((this.RECORD == null) ? 0 : this.RECORD.hashCode());
					
    		this.hashCode = result;
    		this.hashCodeDirty = false;
		}
		return this.hashCode;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) return true;
		if (obj == null) return false;
		if (getClass() != obj.getClass()) return false;
		final row1Struct other = (row1Struct) obj;
		
						if (this.OHREQUID == null) {
							if (other.OHREQUID != null)
								return false;
						
						} else if (!this.OHREQUID.equals(other.OHREQUID))
						
							return false;
					
						if (this.DATAPAKID == null) {
							if (other.DATAPAKID != null)
								return false;
						
						} else if (!this.DATAPAKID.equals(other.DATAPAKID))
						
							return false;
					
						if (this.RECORD == null) {
							if (other.RECORD != null)
								return false;
						
						} else if (!this.RECORD.equals(other.RECORD))
						
							return false;
					

		return true;
    }

	public void copyDataTo(row1Struct other) {

		other.OHREQUID = this.OHREQUID;
	            other.DATAPAKID = this.DATAPAKID;
	            other.RECORD = this.RECORD;
	            other.BILL_ITEM = this.BILL_ITEM;
	            other.BILL_NUM = this.BILL_NUM;
	            other.DOC_NUMBER = this.DOC_NUMBER;
	            other.S_ORD_ITEM = this.S_ORD_ITEM;
	            other.MATERIAL = this.MATERIAL;
	            other.CHRT_ACCTS = this.CHRT_ACCTS;
	            other.GL_ACCOUNT = this.GL_ACCOUNT;
	            other.ACT_GI_DTE = this.ACT_GI_DTE;
	            other.DELIV_ITEM = this.DELIV_ITEM;
	            other.DELIV_NUMB = this.DELIV_NUMB;
	            other.INCOTERMS = this.INCOTERMS;
	            other.INCOTERMS2 = this.INCOTERMS2;
	            other.SALES = this.SALES;
	            other.CURRENCY = this.CURRENCY;
	            other.DOC_CURRCY = this.DOC_CURRCY;
	            other.FISCPER = this.FISCPER;
	            other.FISCVARNT = this.FISCVARNT;
	            other.COMP_CODE = this.COMP_CODE;
	            other.CO_AREA = this.CO_AREA;
	            other.DIVISION = this.DIVISION;
	            other.PROFIT_CTR = this.PROFIT_CTR;
	            other.SHIP_TO = this.SHIP_TO;
	            other.LOC_CURRC3 = this.LOC_CURRC3;
	            other.PAYER = this.PAYER;
	            other.PLANT = this.PLANT;
	            other.SERV_DATE = this.SERV_DATE;
	            other._BIC_ZSALESLCY = this._BIC_ZSALESLCY;
	            other.LOC_CURRCY = this.LOC_CURRCY;
	            other._BIC_ZSALESDCY = this._BIC_ZSALESDCY;
	            other.DEB_CRE_LC = this.DEB_CRE_LC;
	            other.DEB_CRE_L3 = this.DEB_CRE_L3;
	            other.COUNTRY = this.COUNTRY;
	            other._BIC_ZSTREET = this._BIC_ZSTREET;
	            other._BIC_ZCITY = this._BIC_ZCITY;
	            other._BIC_ZCMPCDET = this._BIC_ZCMPCDET;
	            other.COMPANY = this.COMPANY;
	            other._BIC_ZPFTCTRT = this._BIC_ZPFTCTRT;
	            other._BIC_ZPAYERT = this._BIC_ZPAYERT;
	            other.PSTNG_DATE = this.PSTNG_DATE;
	            other.CREATEDON = this.CREATEDON;
	            other._BIC_ZGLACCT = this._BIC_ZGLACCT;
	            other._BIC_ZSHIPT = this._BIC_ZSHIPT;
	            other._BIC_ZPLANTT = this._BIC_ZPLANTT;
	            other.POSTCD_GIS = this.POSTCD_GIS;
	            other._BIC_ZPLANTC = this._BIC_ZPLANTC;
	            other.REVERSEDOC = this.REVERSEDOC;
	            other._BIC_ZMATNAME = this._BIC_ZMATNAME;
	            other._BIC_ZCOUNTRYT = this._BIC_ZCOUNTRYT;
	            other._BIC_ZPLANTCT = this._BIC_ZPLANTCT;
	            other._BIC_ZCOMPC = this._BIC_ZCOMPC;
	            other._BIC_ZCOMPCT = this._BIC_ZCOMPCT;
	            other._BIC_ZDIVISIONT = this._BIC_ZDIVISIONT;
	            other._BIC_ZINCOTERMT = this._BIC_ZINCOTERMT;
	            other._BIC_ZASSG_NUM = this._BIC_ZASSG_NUM;
	            other.MOVETYPE = this.MOVETYPE;
	            other.DEB_CRE_L2 = this.DEB_CRE_L2;
	            other.LOC_CURRC2 = this.LOC_CURRC2;
	            other.REGION = this.REGION;
	            other._BIC_ZDATE = this._BIC_ZDATE;
	            
	}

	public void copyKeysDataTo(row1Struct other) {

		other.OHREQUID = this.OHREQUID;
	            	other.DATAPAKID = this.DATAPAKID;
	            	other.RECORD = this.RECORD;
	            	
	}



	private Integer readInteger(ObjectInputStream dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}

	private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException{
		if(intNum == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeInt(intNum);
    	}
	}

	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_OG_APPLICATIONS_J_X_MAN_FINANCE_LAGTIME.length) {
				if(length < 1024 && commonByteArray_OG_APPLICATIONS_J_X_MAN_FINANCE_LAGTIME.length == 0) {
   					commonByteArray_OG_APPLICATIONS_J_X_MAN_FINANCE_LAGTIME = new byte[1024];
				} else {
   					commonByteArray_OG_APPLICATIONS_J_X_MAN_FINANCE_LAGTIME = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_OG_APPLICATIONS_J_X_MAN_FINANCE_LAGTIME, 0, length);
			strReturn = new String(commonByteArray_OG_APPLICATIONS_J_X_MAN_FINANCE_LAGTIME, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }

	private java.util.Date readDate(ObjectInputStream dis) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(dis.readLong());
		}
		return dateReturn;
	}

    private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException{
		if(date1 == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeLong(date1.getTime());
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_OG_APPLICATIONS_J_X_MAN_FINANCE_LAGTIME) {

        	try {

        		int length = 0;
		
						this.OHREQUID = readInteger(dis);
					
						this.DATAPAKID = readInteger(dis);
					
						this.RECORD = readInteger(dis);
					
					this.BILL_ITEM = readString(dis);
					
					this.BILL_NUM = readString(dis);
					
					this.DOC_NUMBER = readString(dis);
					
					this.S_ORD_ITEM = readString(dis);
					
					this.MATERIAL = readString(dis);
					
					this.CHRT_ACCTS = readString(dis);
					
					this.GL_ACCOUNT = readString(dis);
					
					this.ACT_GI_DTE = readDate(dis);
					
					this.DELIV_ITEM = readString(dis);
					
					this.DELIV_NUMB = readString(dis);
					
					this.INCOTERMS = readString(dis);
					
					this.INCOTERMS2 = readString(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.SALES = null;
           				} else {
           			    	this.SALES = dis.readDouble();
           				}
					
					this.CURRENCY = readString(dis);
					
					this.DOC_CURRCY = readString(dis);
					
					this.FISCPER = readString(dis);
					
					this.FISCVARNT = readString(dis);
					
					this.COMP_CODE = readString(dis);
					
					this.CO_AREA = readString(dis);
					
					this.DIVISION = readString(dis);
					
					this.PROFIT_CTR = readString(dis);
					
					this.SHIP_TO = readString(dis);
					
					this.LOC_CURRC3 = readString(dis);
					
					this.PAYER = readString(dis);
					
					this.PLANT = readString(dis);
					
					this.SERV_DATE = readDate(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this._BIC_ZSALESLCY = null;
           				} else {
           			    	this._BIC_ZSALESLCY = dis.readDouble();
           				}
					
					this.LOC_CURRCY = readString(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this._BIC_ZSALESDCY = null;
           				} else {
           			    	this._BIC_ZSALESDCY = dis.readDouble();
           				}
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.DEB_CRE_LC = null;
           				} else {
           			    	this.DEB_CRE_LC = dis.readDouble();
           				}
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.DEB_CRE_L3 = null;
           				} else {
           			    	this.DEB_CRE_L3 = dis.readDouble();
           				}
					
					this.COUNTRY = readString(dis);
					
					this._BIC_ZSTREET = readString(dis);
					
					this._BIC_ZCITY = readString(dis);
					
					this._BIC_ZCMPCDET = readString(dis);
					
					this.COMPANY = readString(dis);
					
					this._BIC_ZPFTCTRT = readString(dis);
					
					this._BIC_ZPAYERT = readString(dis);
					
					this.PSTNG_DATE = readDate(dis);
					
					this.CREATEDON = readDate(dis);
					
					this._BIC_ZGLACCT = readString(dis);
					
					this._BIC_ZSHIPT = readString(dis);
					
					this._BIC_ZPLANTT = readString(dis);
					
					this.POSTCD_GIS = readString(dis);
					
					this._BIC_ZPLANTC = readString(dis);
					
					this.REVERSEDOC = readString(dis);
					
					this._BIC_ZMATNAME = readString(dis);
					
					this._BIC_ZCOUNTRYT = readString(dis);
					
					this._BIC_ZPLANTCT = readString(dis);
					
					this._BIC_ZCOMPC = readString(dis);
					
					this._BIC_ZCOMPCT = readString(dis);
					
					this._BIC_ZDIVISIONT = readString(dis);
					
					this._BIC_ZINCOTERMT = readString(dis);
					
					this._BIC_ZASSG_NUM = readString(dis);
					
					this.MOVETYPE = readString(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.DEB_CRE_L2 = null;
           				} else {
           			    	this.DEB_CRE_L2 = dis.readDouble();
           				}
					
					this.LOC_CURRC2 = readString(dis);
					
					this.REGION = readString(dis);
					
					this._BIC_ZDATE = readDate(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// Integer
				
						writeInteger(this.OHREQUID,dos);
					
					// Integer
				
						writeInteger(this.DATAPAKID,dos);
					
					// Integer
				
						writeInteger(this.RECORD,dos);
					
					// String
				
						writeString(this.BILL_ITEM,dos);
					
					// String
				
						writeString(this.BILL_NUM,dos);
					
					// String
				
						writeString(this.DOC_NUMBER,dos);
					
					// String
				
						writeString(this.S_ORD_ITEM,dos);
					
					// String
				
						writeString(this.MATERIAL,dos);
					
					// String
				
						writeString(this.CHRT_ACCTS,dos);
					
					// String
				
						writeString(this.GL_ACCOUNT,dos);
					
					// java.util.Date
				
						writeDate(this.ACT_GI_DTE,dos);
					
					// String
				
						writeString(this.DELIV_ITEM,dos);
					
					// String
				
						writeString(this.DELIV_NUMB,dos);
					
					// String
				
						writeString(this.INCOTERMS,dos);
					
					// String
				
						writeString(this.INCOTERMS2,dos);
					
					// Double
				
						if(this.SALES == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this.SALES);
		            	}
					
					// String
				
						writeString(this.CURRENCY,dos);
					
					// String
				
						writeString(this.DOC_CURRCY,dos);
					
					// String
				
						writeString(this.FISCPER,dos);
					
					// String
				
						writeString(this.FISCVARNT,dos);
					
					// String
				
						writeString(this.COMP_CODE,dos);
					
					// String
				
						writeString(this.CO_AREA,dos);
					
					// String
				
						writeString(this.DIVISION,dos);
					
					// String
				
						writeString(this.PROFIT_CTR,dos);
					
					// String
				
						writeString(this.SHIP_TO,dos);
					
					// String
				
						writeString(this.LOC_CURRC3,dos);
					
					// String
				
						writeString(this.PAYER,dos);
					
					// String
				
						writeString(this.PLANT,dos);
					
					// java.util.Date
				
						writeDate(this.SERV_DATE,dos);
					
					// Double
				
						if(this._BIC_ZSALESLCY == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this._BIC_ZSALESLCY);
		            	}
					
					// String
				
						writeString(this.LOC_CURRCY,dos);
					
					// Double
				
						if(this._BIC_ZSALESDCY == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this._BIC_ZSALESDCY);
		            	}
					
					// Double
				
						if(this.DEB_CRE_LC == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this.DEB_CRE_LC);
		            	}
					
					// Double
				
						if(this.DEB_CRE_L3 == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this.DEB_CRE_L3);
		            	}
					
					// String
				
						writeString(this.COUNTRY,dos);
					
					// String
				
						writeString(this._BIC_ZSTREET,dos);
					
					// String
				
						writeString(this._BIC_ZCITY,dos);
					
					// String
				
						writeString(this._BIC_ZCMPCDET,dos);
					
					// String
				
						writeString(this.COMPANY,dos);
					
					// String
				
						writeString(this._BIC_ZPFTCTRT,dos);
					
					// String
				
						writeString(this._BIC_ZPAYERT,dos);
					
					// java.util.Date
				
						writeDate(this.PSTNG_DATE,dos);
					
					// java.util.Date
				
						writeDate(this.CREATEDON,dos);
					
					// String
				
						writeString(this._BIC_ZGLACCT,dos);
					
					// String
				
						writeString(this._BIC_ZSHIPT,dos);
					
					// String
				
						writeString(this._BIC_ZPLANTT,dos);
					
					// String
				
						writeString(this.POSTCD_GIS,dos);
					
					// String
				
						writeString(this._BIC_ZPLANTC,dos);
					
					// String
				
						writeString(this.REVERSEDOC,dos);
					
					// String
				
						writeString(this._BIC_ZMATNAME,dos);
					
					// String
				
						writeString(this._BIC_ZCOUNTRYT,dos);
					
					// String
				
						writeString(this._BIC_ZPLANTCT,dos);
					
					// String
				
						writeString(this._BIC_ZCOMPC,dos);
					
					// String
				
						writeString(this._BIC_ZCOMPCT,dos);
					
					// String
				
						writeString(this._BIC_ZDIVISIONT,dos);
					
					// String
				
						writeString(this._BIC_ZINCOTERMT,dos);
					
					// String
				
						writeString(this._BIC_ZASSG_NUM,dos);
					
					// String
				
						writeString(this.MOVETYPE,dos);
					
					// Double
				
						if(this.DEB_CRE_L2 == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeDouble(this.DEB_CRE_L2);
		            	}
					
					// String
				
						writeString(this.LOC_CURRC2,dos);
					
					// String
				
						writeString(this.REGION,dos);
					
					// java.util.Date
				
						writeDate(this._BIC_ZDATE,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("OHREQUID="+String.valueOf(OHREQUID));
		sb.append(",DATAPAKID="+String.valueOf(DATAPAKID));
		sb.append(",RECORD="+String.valueOf(RECORD));
		sb.append(",BILL_ITEM="+BILL_ITEM);
		sb.append(",BILL_NUM="+BILL_NUM);
		sb.append(",DOC_NUMBER="+DOC_NUMBER);
		sb.append(",S_ORD_ITEM="+S_ORD_ITEM);
		sb.append(",MATERIAL="+MATERIAL);
		sb.append(",CHRT_ACCTS="+CHRT_ACCTS);
		sb.append(",GL_ACCOUNT="+GL_ACCOUNT);
		sb.append(",ACT_GI_DTE="+String.valueOf(ACT_GI_DTE));
		sb.append(",DELIV_ITEM="+DELIV_ITEM);
		sb.append(",DELIV_NUMB="+DELIV_NUMB);
		sb.append(",INCOTERMS="+INCOTERMS);
		sb.append(",INCOTERMS2="+INCOTERMS2);
		sb.append(",SALES="+String.valueOf(SALES));
		sb.append(",CURRENCY="+CURRENCY);
		sb.append(",DOC_CURRCY="+DOC_CURRCY);
		sb.append(",FISCPER="+FISCPER);
		sb.append(",FISCVARNT="+FISCVARNT);
		sb.append(",COMP_CODE="+COMP_CODE);
		sb.append(",CO_AREA="+CO_AREA);
		sb.append(",DIVISION="+DIVISION);
		sb.append(",PROFIT_CTR="+PROFIT_CTR);
		sb.append(",SHIP_TO="+SHIP_TO);
		sb.append(",LOC_CURRC3="+LOC_CURRC3);
		sb.append(",PAYER="+PAYER);
		sb.append(",PLANT="+PLANT);
		sb.append(",SERV_DATE="+String.valueOf(SERV_DATE));
		sb.append(",_BIC_ZSALESLCY="+String.valueOf(_BIC_ZSALESLCY));
		sb.append(",LOC_CURRCY="+LOC_CURRCY);
		sb.append(",_BIC_ZSALESDCY="+String.valueOf(_BIC_ZSALESDCY));
		sb.append(",DEB_CRE_LC="+String.valueOf(DEB_CRE_LC));
		sb.append(",DEB_CRE_L3="+String.valueOf(DEB_CRE_L3));
		sb.append(",COUNTRY="+COUNTRY);
		sb.append(",_BIC_ZSTREET="+_BIC_ZSTREET);
		sb.append(",_BIC_ZCITY="+_BIC_ZCITY);
		sb.append(",_BIC_ZCMPCDET="+_BIC_ZCMPCDET);
		sb.append(",COMPANY="+COMPANY);
		sb.append(",_BIC_ZPFTCTRT="+_BIC_ZPFTCTRT);
		sb.append(",_BIC_ZPAYERT="+_BIC_ZPAYERT);
		sb.append(",PSTNG_DATE="+String.valueOf(PSTNG_DATE));
		sb.append(",CREATEDON="+String.valueOf(CREATEDON));
		sb.append(",_BIC_ZGLACCT="+_BIC_ZGLACCT);
		sb.append(",_BIC_ZSHIPT="+_BIC_ZSHIPT);
		sb.append(",_BIC_ZPLANTT="+_BIC_ZPLANTT);
		sb.append(",POSTCD_GIS="+POSTCD_GIS);
		sb.append(",_BIC_ZPLANTC="+_BIC_ZPLANTC);
		sb.append(",REVERSEDOC="+REVERSEDOC);
		sb.append(",_BIC_ZMATNAME="+_BIC_ZMATNAME);
		sb.append(",_BIC_ZCOUNTRYT="+_BIC_ZCOUNTRYT);
		sb.append(",_BIC_ZPLANTCT="+_BIC_ZPLANTCT);
		sb.append(",_BIC_ZCOMPC="+_BIC_ZCOMPC);
		sb.append(",_BIC_ZCOMPCT="+_BIC_ZCOMPCT);
		sb.append(",_BIC_ZDIVISIONT="+_BIC_ZDIVISIONT);
		sb.append(",_BIC_ZINCOTERMT="+_BIC_ZINCOTERMT);
		sb.append(",_BIC_ZASSG_NUM="+_BIC_ZASSG_NUM);
		sb.append(",MOVETYPE="+MOVETYPE);
		sb.append(",DEB_CRE_L2="+String.valueOf(DEB_CRE_L2));
		sb.append(",LOC_CURRC2="+LOC_CURRC2);
		sb.append(",REGION="+REGION);
		sb.append(",_BIC_ZDATE="+String.valueOf(_BIC_ZDATE));
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				if(OHREQUID == null){
        					sb.append("<null>");
        				}else{
            				sb.append(OHREQUID);
            			}
            		
        			sb.append("|");
        		
        				if(DATAPAKID == null){
        					sb.append("<null>");
        				}else{
            				sb.append(DATAPAKID);
            			}
            		
        			sb.append("|");
        		
        				if(RECORD == null){
        					sb.append("<null>");
        				}else{
            				sb.append(RECORD);
            			}
            		
        			sb.append("|");
        		
        				if(BILL_ITEM == null){
        					sb.append("<null>");
        				}else{
            				sb.append(BILL_ITEM);
            			}
            		
        			sb.append("|");
        		
        				if(BILL_NUM == null){
        					sb.append("<null>");
        				}else{
            				sb.append(BILL_NUM);
            			}
            		
        			sb.append("|");
        		
        				if(DOC_NUMBER == null){
        					sb.append("<null>");
        				}else{
            				sb.append(DOC_NUMBER);
            			}
            		
        			sb.append("|");
        		
        				if(S_ORD_ITEM == null){
        					sb.append("<null>");
        				}else{
            				sb.append(S_ORD_ITEM);
            			}
            		
        			sb.append("|");
        		
        				if(MATERIAL == null){
        					sb.append("<null>");
        				}else{
            				sb.append(MATERIAL);
            			}
            		
        			sb.append("|");
        		
        				if(CHRT_ACCTS == null){
        					sb.append("<null>");
        				}else{
            				sb.append(CHRT_ACCTS);
            			}
            		
        			sb.append("|");
        		
        				if(GL_ACCOUNT == null){
        					sb.append("<null>");
        				}else{
            				sb.append(GL_ACCOUNT);
            			}
            		
        			sb.append("|");
        		
        				if(ACT_GI_DTE == null){
        					sb.append("<null>");
        				}else{
            				sb.append(ACT_GI_DTE);
            			}
            		
        			sb.append("|");
        		
        				if(DELIV_ITEM == null){
        					sb.append("<null>");
        				}else{
            				sb.append(DELIV_ITEM);
            			}
            		
        			sb.append("|");
        		
        				if(DELIV_NUMB == null){
        					sb.append("<null>");
        				}else{
            				sb.append(DELIV_NUMB);
            			}
            		
        			sb.append("|");
        		
        				if(INCOTERMS == null){
        					sb.append("<null>");
        				}else{
            				sb.append(INCOTERMS);
            			}
            		
        			sb.append("|");
        		
        				if(INCOTERMS2 == null){
        					sb.append("<null>");
        				}else{
            				sb.append(INCOTERMS2);
            			}
            		
        			sb.append("|");
        		
        				if(SALES == null){
        					sb.append("<null>");
        				}else{
            				sb.append(SALES);
            			}
            		
        			sb.append("|");
        		
        				if(CURRENCY == null){
        					sb.append("<null>");
        				}else{
            				sb.append(CURRENCY);
            			}
            		
        			sb.append("|");
        		
        				if(DOC_CURRCY == null){
        					sb.append("<null>");
        				}else{
            				sb.append(DOC_CURRCY);
            			}
            		
        			sb.append("|");
        		
        				if(FISCPER == null){
        					sb.append("<null>");
        				}else{
            				sb.append(FISCPER);
            			}
            		
        			sb.append("|");
        		
        				if(FISCVARNT == null){
        					sb.append("<null>");
        				}else{
            				sb.append(FISCVARNT);
            			}
            		
        			sb.append("|");
        		
        				if(COMP_CODE == null){
        					sb.append("<null>");
        				}else{
            				sb.append(COMP_CODE);
            			}
            		
        			sb.append("|");
        		
        				if(CO_AREA == null){
        					sb.append("<null>");
        				}else{
            				sb.append(CO_AREA);
            			}
            		
        			sb.append("|");
        		
        				if(DIVISION == null){
        					sb.append("<null>");
        				}else{
            				sb.append(DIVISION);
            			}
            		
        			sb.append("|");
        		
        				if(PROFIT_CTR == null){
        					sb.append("<null>");
        				}else{
            				sb.append(PROFIT_CTR);
            			}
            		
        			sb.append("|");
        		
        				if(SHIP_TO == null){
        					sb.append("<null>");
        				}else{
            				sb.append(SHIP_TO);
            			}
            		
        			sb.append("|");
        		
        				if(LOC_CURRC3 == null){
        					sb.append("<null>");
        				}else{
            				sb.append(LOC_CURRC3);
            			}
            		
        			sb.append("|");
        		
        				if(PAYER == null){
        					sb.append("<null>");
        				}else{
            				sb.append(PAYER);
            			}
            		
        			sb.append("|");
        		
        				if(PLANT == null){
        					sb.append("<null>");
        				}else{
            				sb.append(PLANT);
            			}
            		
        			sb.append("|");
        		
        				if(SERV_DATE == null){
        					sb.append("<null>");
        				}else{
            				sb.append(SERV_DATE);
            			}
            		
        			sb.append("|");
        		
        				if(_BIC_ZSALESLCY == null){
        					sb.append("<null>");
        				}else{
            				sb.append(_BIC_ZSALESLCY);
            			}
            		
        			sb.append("|");
        		
        				if(LOC_CURRCY == null){
        					sb.append("<null>");
        				}else{
            				sb.append(LOC_CURRCY);
            			}
            		
        			sb.append("|");
        		
        				if(_BIC_ZSALESDCY == null){
        					sb.append("<null>");
        				}else{
            				sb.append(_BIC_ZSALESDCY);
            			}
            		
        			sb.append("|");
        		
        				if(DEB_CRE_LC == null){
        					sb.append("<null>");
        				}else{
            				sb.append(DEB_CRE_LC);
            			}
            		
        			sb.append("|");
        		
        				if(DEB_CRE_L3 == null){
        					sb.append("<null>");
        				}else{
            				sb.append(DEB_CRE_L3);
            			}
            		
        			sb.append("|");
        		
        				if(COUNTRY == null){
        					sb.append("<null>");
        				}else{
            				sb.append(COUNTRY);
            			}
            		
        			sb.append("|");
        		
        				if(_BIC_ZSTREET == null){
        					sb.append("<null>");
        				}else{
            				sb.append(_BIC_ZSTREET);
            			}
            		
        			sb.append("|");
        		
        				if(_BIC_ZCITY == null){
        					sb.append("<null>");
        				}else{
            				sb.append(_BIC_ZCITY);
            			}
            		
        			sb.append("|");
        		
        				if(_BIC_ZCMPCDET == null){
        					sb.append("<null>");
        				}else{
            				sb.append(_BIC_ZCMPCDET);
            			}
            		
        			sb.append("|");
        		
        				if(COMPANY == null){
        					sb.append("<null>");
        				}else{
            				sb.append(COMPANY);
            			}
            		
        			sb.append("|");
        		
        				if(_BIC_ZPFTCTRT == null){
        					sb.append("<null>");
        				}else{
            				sb.append(_BIC_ZPFTCTRT);
            			}
            		
        			sb.append("|");
        		
        				if(_BIC_ZPAYERT == null){
        					sb.append("<null>");
        				}else{
            				sb.append(_BIC_ZPAYERT);
            			}
            		
        			sb.append("|");
        		
        				if(PSTNG_DATE == null){
        					sb.append("<null>");
        				}else{
            				sb.append(PSTNG_DATE);
            			}
            		
        			sb.append("|");
        		
        				if(CREATEDON == null){
        					sb.append("<null>");
        				}else{
            				sb.append(CREATEDON);
            			}
            		
        			sb.append("|");
        		
        				if(_BIC_ZGLACCT == null){
        					sb.append("<null>");
        				}else{
            				sb.append(_BIC_ZGLACCT);
            			}
            		
        			sb.append("|");
        		
        				if(_BIC_ZSHIPT == null){
        					sb.append("<null>");
        				}else{
            				sb.append(_BIC_ZSHIPT);
            			}
            		
        			sb.append("|");
        		
        				if(_BIC_ZPLANTT == null){
        					sb.append("<null>");
        				}else{
            				sb.append(_BIC_ZPLANTT);
            			}
            		
        			sb.append("|");
        		
        				if(POSTCD_GIS == null){
        					sb.append("<null>");
        				}else{
            				sb.append(POSTCD_GIS);
            			}
            		
        			sb.append("|");
        		
        				if(_BIC_ZPLANTC == null){
        					sb.append("<null>");
        				}else{
            				sb.append(_BIC_ZPLANTC);
            			}
            		
        			sb.append("|");
        		
        				if(REVERSEDOC == null){
        					sb.append("<null>");
        				}else{
            				sb.append(REVERSEDOC);
            			}
            		
        			sb.append("|");
        		
        				if(_BIC_ZMATNAME == null){
        					sb.append("<null>");
        				}else{
            				sb.append(_BIC_ZMATNAME);
            			}
            		
        			sb.append("|");
        		
        				if(_BIC_ZCOUNTRYT == null){
        					sb.append("<null>");
        				}else{
            				sb.append(_BIC_ZCOUNTRYT);
            			}
            		
        			sb.append("|");
        		
        				if(_BIC_ZPLANTCT == null){
        					sb.append("<null>");
        				}else{
            				sb.append(_BIC_ZPLANTCT);
            			}
            		
        			sb.append("|");
        		
        				if(_BIC_ZCOMPC == null){
        					sb.append("<null>");
        				}else{
            				sb.append(_BIC_ZCOMPC);
            			}
            		
        			sb.append("|");
        		
        				if(_BIC_ZCOMPCT == null){
        					sb.append("<null>");
        				}else{
            				sb.append(_BIC_ZCOMPCT);
            			}
            		
        			sb.append("|");
        		
        				if(_BIC_ZDIVISIONT == null){
        					sb.append("<null>");
        				}else{
            				sb.append(_BIC_ZDIVISIONT);
            			}
            		
        			sb.append("|");
        		
        				if(_BIC_ZINCOTERMT == null){
        					sb.append("<null>");
        				}else{
            				sb.append(_BIC_ZINCOTERMT);
            			}
            		
        			sb.append("|");
        		
        				if(_BIC_ZASSG_NUM == null){
        					sb.append("<null>");
        				}else{
            				sb.append(_BIC_ZASSG_NUM);
            			}
            		
        			sb.append("|");
        		
        				if(MOVETYPE == null){
        					sb.append("<null>");
        				}else{
            				sb.append(MOVETYPE);
            			}
            		
        			sb.append("|");
        		
        				if(DEB_CRE_L2 == null){
        					sb.append("<null>");
        				}else{
            				sb.append(DEB_CRE_L2);
            			}
            		
        			sb.append("|");
        		
        				if(LOC_CURRC2 == null){
        					sb.append("<null>");
        				}else{
            				sb.append(LOC_CURRC2);
            			}
            		
        			sb.append("|");
        		
        				if(REGION == null){
        					sb.append("<null>");
        				}else{
            				sb.append(REGION);
            			}
            		
        			sb.append("|");
        		
        				if(_BIC_ZDATE == null){
        					sb.append("<null>");
        				}else{
            				sb.append(_BIC_ZDATE);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(row1Struct other) {

		int returnValue = -1;
		
						returnValue = checkNullsAndCompare(this.OHREQUID, other.OHREQUID);
						if(returnValue != 0) {
							return returnValue;
						}

					
						returnValue = checkNullsAndCompare(this.DATAPAKID, other.DATAPAKID);
						if(returnValue != 0) {
							return returnValue;
						}

					
						returnValue = checkNullsAndCompare(this.RECORD, other.RECORD);
						if(returnValue != 0) {
							return returnValue;
						}

					
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}
public void tSAPTableInput_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tSAPTableInput_1_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;



		row1Struct row1 = new row1Struct();
row1Struct row2 = row1;
AStruct A = new AStruct();






	
	/**
	 * [tPostgresqlOutput_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tPostgresqlOutput_1", false);
		start_Hash.put("tPostgresqlOutput_1", System.currentTimeMillis());
		
	
	currentComponent="tPostgresqlOutput_1";

	
			if (execStat) {
				if(resourceMap.get("inIterateVComp") == null){
					
						runStat.updateStatOnConnection("A" + iterateId, 0, 0);
					
				}
			} 

		
		int tos_count_tPostgresqlOutput_1 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tPostgresqlOutput_1 - "  + ("Start to work.") );
    	class BytesLimit65535_tPostgresqlOutput_1{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tPostgresqlOutput_1 = new StringBuilder();
            log4jParamters_tPostgresqlOutput_1.append("Parameters:");
                    log4jParamters_tPostgresqlOutput_1.append("USE_EXISTING_CONNECTION" + " = " + "false");
                log4jParamters_tPostgresqlOutput_1.append(" | ");
                    log4jParamters_tPostgresqlOutput_1.append("DB_VERSION" + " = " + "V9_X");
                log4jParamters_tPostgresqlOutput_1.append(" | ");
                    log4jParamters_tPostgresqlOutput_1.append("HOST" + " = " + "context.aws_gp_prof_Server");
                log4jParamters_tPostgresqlOutput_1.append(" | ");
                    log4jParamters_tPostgresqlOutput_1.append("PORT" + " = " + "context.aws_gp_prof_Port");
                log4jParamters_tPostgresqlOutput_1.append(" | ");
                    log4jParamters_tPostgresqlOutput_1.append("DBNAME" + " = " + "\"bhdl\"");
                log4jParamters_tPostgresqlOutput_1.append(" | ");
                    log4jParamters_tPostgresqlOutput_1.append("SCHEMA_DB" + " = " + "\"og_bhone_bw\"");
                log4jParamters_tPostgresqlOutput_1.append(" | ");
                    log4jParamters_tPostgresqlOutput_1.append("USER" + " = " + "context.aws_gp_prof_Login");
                log4jParamters_tPostgresqlOutput_1.append(" | ");
                    log4jParamters_tPostgresqlOutput_1.append("PASS" + " = " + String.valueOf(routines.system.PasswordEncryptUtil.encryptPassword(context.aws_gp_prof_Password)).substring(0, 4) + "...");     
                log4jParamters_tPostgresqlOutput_1.append(" | ");
                    log4jParamters_tPostgresqlOutput_1.append("TABLE" + " = " + "\"bh_bw_finance_lagtime\"");
                log4jParamters_tPostgresqlOutput_1.append(" | ");
                    log4jParamters_tPostgresqlOutput_1.append("TABLE_ACTION" + " = " + "NONE");
                log4jParamters_tPostgresqlOutput_1.append(" | ");
                    log4jParamters_tPostgresqlOutput_1.append("DATA_ACTION" + " = " + "INSERT");
                log4jParamters_tPostgresqlOutput_1.append(" | ");
                    log4jParamters_tPostgresqlOutput_1.append("SPECIFY_DATASOURCE_ALIAS" + " = " + "false");
                log4jParamters_tPostgresqlOutput_1.append(" | ");
                    log4jParamters_tPostgresqlOutput_1.append("DIE_ON_ERROR" + " = " + "false");
                log4jParamters_tPostgresqlOutput_1.append(" | ");
                    log4jParamters_tPostgresqlOutput_1.append("USE_SSL" + " = " + "true");
                log4jParamters_tPostgresqlOutput_1.append(" | ");
                    log4jParamters_tPostgresqlOutput_1.append("COMMIT_EVERY" + " = " + "10000");
                log4jParamters_tPostgresqlOutput_1.append(" | ");
                    log4jParamters_tPostgresqlOutput_1.append("ADD_COLS" + " = " + "[]");
                log4jParamters_tPostgresqlOutput_1.append(" | ");
                    log4jParamters_tPostgresqlOutput_1.append("USE_FIELD_OPTIONS" + " = " + "false");
                log4jParamters_tPostgresqlOutput_1.append(" | ");
                    log4jParamters_tPostgresqlOutput_1.append("ENABLE_DEBUG_MODE" + " = " + "false");
                log4jParamters_tPostgresqlOutput_1.append(" | ");
                    log4jParamters_tPostgresqlOutput_1.append("SUPPORT_NULL_WHERE" + " = " + "false");
                log4jParamters_tPostgresqlOutput_1.append(" | ");
                    log4jParamters_tPostgresqlOutput_1.append("USE_BATCH_SIZE" + " = " + "true");
                log4jParamters_tPostgresqlOutput_1.append(" | ");
                    log4jParamters_tPostgresqlOutput_1.append("BATCH_SIZE" + " = " + "10000");
                log4jParamters_tPostgresqlOutput_1.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tPostgresqlOutput_1 - "  + (log4jParamters_tPostgresqlOutput_1) );
    		}
    	}
    	
        new BytesLimit65535_tPostgresqlOutput_1().limitLog4jByte();





String dbschema_tPostgresqlOutput_1 = null;
	dbschema_tPostgresqlOutput_1 = "og_bhone_bw";
	

String tableName_tPostgresqlOutput_1 = null;
if(dbschema_tPostgresqlOutput_1 == null || dbschema_tPostgresqlOutput_1.trim().length() == 0) {
	tableName_tPostgresqlOutput_1 = "bh_bw_finance_lagtime";
} else {
	tableName_tPostgresqlOutput_1 = dbschema_tPostgresqlOutput_1 + "\".\"" + "bh_bw_finance_lagtime";
}

int nb_line_tPostgresqlOutput_1 = 0;
int nb_line_update_tPostgresqlOutput_1 = 0;
int nb_line_inserted_tPostgresqlOutput_1 = 0;
int nb_line_deleted_tPostgresqlOutput_1 = 0;
int nb_line_rejected_tPostgresqlOutput_1 = 0;

int deletedCount_tPostgresqlOutput_1=0;
int updatedCount_tPostgresqlOutput_1=0;
int insertedCount_tPostgresqlOutput_1=0;
int rejectedCount_tPostgresqlOutput_1=0;

boolean whetherReject_tPostgresqlOutput_1 = false;

java.sql.Connection conn_tPostgresqlOutput_1 = null;
String dbUser_tPostgresqlOutput_1 = null;

	
                if(log.isDebugEnabled())
            log.debug("tPostgresqlOutput_1 - "  + ("Driver ClassName: ")  + ("org.postgresql.Driver")  + (".") );
    java.lang.Class.forName("org.postgresql.Driver");
	
	
			String url_tPostgresqlOutput_1 = "jdbc:postgresql://"+context.aws_gp_prof_Server+":"+context.aws_gp_prof_Port+"/"+"bhdl"+"?ssl=true&sslfactory=org.postgresql.ssl.NonValidatingFactory";
	
    
    dbUser_tPostgresqlOutput_1 = context.aws_gp_prof_Login;

	final String decryptedPassword_tPostgresqlOutput_1 = context.aws_gp_prof_Password; 

    String dbPwd_tPostgresqlOutput_1 = decryptedPassword_tPostgresqlOutput_1;

                if(log.isDebugEnabled())
            log.debug("tPostgresqlOutput_1 - "  + ("Connection attempts to '")  + (url_tPostgresqlOutput_1)  + ("' with the username '")  + (dbUser_tPostgresqlOutput_1)  + ("'.") );
    conn_tPostgresqlOutput_1 = java.sql.DriverManager.getConnection(url_tPostgresqlOutput_1,dbUser_tPostgresqlOutput_1,dbPwd_tPostgresqlOutput_1);
                if(log.isDebugEnabled())
            log.debug("tPostgresqlOutput_1 - "  + ("Connection to '")  + (url_tPostgresqlOutput_1)  + ("' has succeeded.") );
	
	resourceMap.put("conn_tPostgresqlOutput_1", conn_tPostgresqlOutput_1);
        conn_tPostgresqlOutput_1.setAutoCommit(false);
        int commitEvery_tPostgresqlOutput_1 = 10000;
        int commitCounter_tPostgresqlOutput_1 = 0;
                if(log.isDebugEnabled())
            log.debug("tPostgresqlOutput_1 - "  + ("Connection is set auto commit to '")  + (conn_tPostgresqlOutput_1.getAutoCommit())  + ("'.") );


   int batchSize_tPostgresqlOutput_1 = 10000;
   int batchSizeCounter_tPostgresqlOutput_1=0;

int count_tPostgresqlOutput_1=0;
	    String insert_tPostgresqlOutput_1 = "INSERT INTO \"" + tableName_tPostgresqlOutput_1 + "\" (\"company_code_key\",\"company_code_text\",\"company_code_country_text\",\"profit_center_key\",\"profit_center_text\",\"to_division\",\"plant\",\"billing_document\",\"billing_document_item\",\"payer_key\",\"payer_text\",\"fiscal_year_period_key\",\"entry_date\",\"rta_date\",\"serv_rendered_date\",\"act_goods_issue_date\",\"sales_document\",\"sales_document_item\",\"delivery_number\",\"delivery_item\",\"gl_account_key\",\"gl_account_text\",\"material_key\",\"material_text\",\"ship_to_party_key\",\"ship_to_party_text\",\"street_name_key\",\"location_key\",\"country_key\",\"country_text\",\"plant_key\",\"plant_text\",\"plant_bas_pstcdegeorelkey\",\"plant_country_key\",\"plant_country_text\",\"incoterms\",\"incoterms_2\",\"cancellation_flag_key\",\"sales_in_document_currency\",\"document_currency_key\",\"amount_in_local_currency\",\"amount_in_usd\",\"currency_key\",\"lc1_for_cogs\",\"local_currency_key\",\"lc3_for_cogs\",\"third_local_currency_key\",\"movement_type\",\"group_currency_amount\",\"group_currency\",\"ship_to_state\",\"plant_state\",\"sales_assignment_number\",\"load_date\") VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
	    java.sql.PreparedStatement pstmt_tPostgresqlOutput_1 = conn_tPostgresqlOutput_1.prepareStatement(insert_tPostgresqlOutput_1);
	    

 



/**
 * [tPostgresqlOutput_1 begin ] stop
 */



	
	/**
	 * [tMap_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tMap_1", false);
		start_Hash.put("tMap_1", System.currentTimeMillis());
		
	
	currentComponent="tMap_1";

	
			if (execStat) {
				if(resourceMap.get("inIterateVComp") == null){
					
						runStat.updateStatOnConnection("row2" + iterateId, 0, 0);
					
				}
			} 

		
		int tos_count_tMap_1 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tMap_1 - "  + ("Start to work.") );
    	class BytesLimit65535_tMap_1{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tMap_1 = new StringBuilder();
            log4jParamters_tMap_1.append("Parameters:");
                    log4jParamters_tMap_1.append("LINK_STYLE" + " = " + "AUTO");
                log4jParamters_tMap_1.append(" | ");
                    log4jParamters_tMap_1.append("TEMPORARY_DATA_DIRECTORY" + " = " + "");
                log4jParamters_tMap_1.append(" | ");
                    log4jParamters_tMap_1.append("ROWS_BUFFER_SIZE" + " = " + "2000000");
                log4jParamters_tMap_1.append(" | ");
                    log4jParamters_tMap_1.append("CHANGE_HASH_AND_EQUALS_FOR_BIGDECIMAL" + " = " + "false");
                log4jParamters_tMap_1.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tMap_1 - "  + (log4jParamters_tMap_1) );
    		}
    	}
    	
        new BytesLimit65535_tMap_1().limitLog4jByte();




// ###############################
// # Lookup's keys initialization
		int count_row2_tMap_1 = 0;
		
// ###############################        

// ###############################
// # Vars initialization
class  Var__tMap_1__Struct  {
}
Var__tMap_1__Struct Var__tMap_1 = new Var__tMap_1__Struct();
// ###############################

// ###############################
// # Outputs initialization
				int count_A_tMap_1 = 0;
				
AStruct A_tmp = new AStruct();
// ###############################

        
        



        









 



/**
 * [tMap_1 begin ] stop
 */



	
	/**
	 * [tFlowMeter_16 begin ] start
	 */

	

	
		
		ok_Hash.put("tFlowMeter_16", false);
		start_Hash.put("tFlowMeter_16", System.currentTimeMillis());
		
	
	currentComponent="tFlowMeter_16";

	
			if (execStat) {
				if(resourceMap.get("inIterateVComp") == null){
					
						runStat.updateStatOnConnection("row1" + iterateId, 0, 0);
					
				}
			} 

		
		int tos_count_tFlowMeter_16 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tFlowMeter_16 - "  + ("Start to work.") );
    	class BytesLimit65535_tFlowMeter_16{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tFlowMeter_16 = new StringBuilder();
            log4jParamters_tFlowMeter_16.append("Parameters:");
                    log4jParamters_tFlowMeter_16.append("USEROWLABEL" + " = " + "true");
                log4jParamters_tFlowMeter_16.append(" | ");
                    log4jParamters_tFlowMeter_16.append("ABSOLUTE" + " = " + "Absolute");
                log4jParamters_tFlowMeter_16.append(" | ");
                    log4jParamters_tFlowMeter_16.append("THRESHLODS" + " = " + "[]");
                log4jParamters_tFlowMeter_16.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tFlowMeter_16 - "  + (log4jParamters_tFlowMeter_16) );
    		}
    	}
    	
        new BytesLimit65535_tFlowMeter_16().limitLog4jByte();

    int count_tFlowMeter_16 = 0; 
 



/**
 * [tFlowMeter_16 begin ] stop
 */



	
	/**
	 * [tSAPTableInput_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tSAPTableInput_1", false);
		start_Hash.put("tSAPTableInput_1", System.currentTimeMillis());
		
	
	currentComponent="tSAPTableInput_1";

	
		int tos_count_tSAPTableInput_1 = 0;
		
    	class BytesLimit65535_tSAPTableInput_1{
    		public void limitLog4jByte() throws Exception{
    			
    		}
    	}
    	
        new BytesLimit65535_tSAPTableInput_1().limitLog4jByte();

	

	
		org.talend.sap.ISAPConnection connection_tSAPTableInput_1 = null;
		
	final String decryptedPassword_tSAPTableInput_1 = context.SAP_QA1_Password; 
    	java.util.Properties properties_tSAPTableInput_1 = new java.util.Properties();
        properties_tSAPTableInput_1.put(org.talend.sap.ISAPConnection.PROP_CLIENT, context.SAP_QA1_Client);
        properties_tSAPTableInput_1.put(org.talend.sap.ISAPConnection.PROP_USER, context.SAP_QA1_UserName);
        properties_tSAPTableInput_1.put(org.talend.sap.ISAPConnection.PROP_PASSWORD, decryptedPassword_tSAPTableInput_1);
        properties_tSAPTableInput_1.put(org.talend.sap.ISAPConnection.PROP_LANGUAGE, context.SAP_QA1_Language);
        
        properties_tSAPTableInput_1.put("jco.client.mshost", context.SAP_QA1_Host);
        properties_tSAPTableInput_1.put("jco.client.r3name", "PW1");
        properties_tSAPTableInput_1.put("jco.client.group", "PW1RFC");
        
    	
    		properties_tSAPTableInput_1.put("api.use_z_talend_read_table" ,context.api_use_z_talend_read_table);
    		
        
    	connection_tSAPTableInput_1 = org.talend.sap.impl.SAPConnectionFactory.getInstance().createConnection(properties_tSAPTableInput_1);
	org.talend.sap.service.ISAPTableDataService dataService_tSAPTableInput_1 = connection_tSAPTableInput_1.getTableDataService();
	
	java.util.List<String> fieldNames_tSAPTableInput_1 = new java.util.LinkedList<String>();
		fieldNames_tSAPTableInput_1.add("OHREQUID");
		fieldNames_tSAPTableInput_1.add("DATAPAKID");
		fieldNames_tSAPTableInput_1.add("RECORD");
		fieldNames_tSAPTableInput_1.add("BILL_ITEM");
		fieldNames_tSAPTableInput_1.add("BILL_NUM");
		fieldNames_tSAPTableInput_1.add("DOC_NUMBER");
		fieldNames_tSAPTableInput_1.add("S_ORD_ITEM");
		fieldNames_tSAPTableInput_1.add("MATERIAL");
		fieldNames_tSAPTableInput_1.add("CHRT_ACCTS");
		fieldNames_tSAPTableInput_1.add("GL_ACCOUNT");
		fieldNames_tSAPTableInput_1.add("ACT_GI_DTE");
		fieldNames_tSAPTableInput_1.add("DELIV_ITEM");
		fieldNames_tSAPTableInput_1.add("DELIV_NUMB");
		fieldNames_tSAPTableInput_1.add("INCOTERMS");
		fieldNames_tSAPTableInput_1.add("INCOTERMS2");
		fieldNames_tSAPTableInput_1.add("SALES");
		fieldNames_tSAPTableInput_1.add("CURRENCY");
		fieldNames_tSAPTableInput_1.add("DOC_CURRCY");
		fieldNames_tSAPTableInput_1.add("FISCPER");
		fieldNames_tSAPTableInput_1.add("FISCVARNT");
		fieldNames_tSAPTableInput_1.add("COMP_CODE");
		fieldNames_tSAPTableInput_1.add("CO_AREA");
		fieldNames_tSAPTableInput_1.add("DIVISION");
		fieldNames_tSAPTableInput_1.add("PROFIT_CTR");
		fieldNames_tSAPTableInput_1.add("SHIP_TO");
		fieldNames_tSAPTableInput_1.add("LOC_CURRC3");
		fieldNames_tSAPTableInput_1.add("PAYER");
		fieldNames_tSAPTableInput_1.add("PLANT");
		fieldNames_tSAPTableInput_1.add("SERV_DATE");
		fieldNames_tSAPTableInput_1.add("/BIC/ZSALESLCY");
		fieldNames_tSAPTableInput_1.add("LOC_CURRCY");
		fieldNames_tSAPTableInput_1.add("/BIC/ZSALESDCY");
		fieldNames_tSAPTableInput_1.add("DEB_CRE_LC");
		fieldNames_tSAPTableInput_1.add("DEB_CRE_L3");
		fieldNames_tSAPTableInput_1.add("COUNTRY");
		fieldNames_tSAPTableInput_1.add("/BIC/ZSTREET");
		fieldNames_tSAPTableInput_1.add("/BIC/ZCITY");
		fieldNames_tSAPTableInput_1.add("/BIC/ZCMPCDET");
		fieldNames_tSAPTableInput_1.add("COMPANY");
		fieldNames_tSAPTableInput_1.add("/BIC/ZPFTCTRT");
		fieldNames_tSAPTableInput_1.add("/BIC/ZPAYERT");
		fieldNames_tSAPTableInput_1.add("PSTNG_DATE");
		fieldNames_tSAPTableInput_1.add("CREATEDON");
		fieldNames_tSAPTableInput_1.add("/BIC/ZGLACCT");
		fieldNames_tSAPTableInput_1.add("/BIC/ZSHIPT");
		fieldNames_tSAPTableInput_1.add("/BIC/ZPLANTT");
		fieldNames_tSAPTableInput_1.add("POSTCD_GIS");
		fieldNames_tSAPTableInput_1.add("/BIC/ZPLANTC");
		fieldNames_tSAPTableInput_1.add("REVERSEDOC");
		fieldNames_tSAPTableInput_1.add("/BIC/ZMATNAME");
		fieldNames_tSAPTableInput_1.add("/BIC/ZCOUNTRYT");
		fieldNames_tSAPTableInput_1.add("/BIC/ZPLANTCT");
		fieldNames_tSAPTableInput_1.add("/BIC/ZCOMPC");
		fieldNames_tSAPTableInput_1.add("/BIC/ZCOMPCT");
		fieldNames_tSAPTableInput_1.add("/BIC/ZDIVISIONT");
		fieldNames_tSAPTableInput_1.add("/BIC/ZINCOTERMT");
		fieldNames_tSAPTableInput_1.add("/BIC/ZASSG_NUM");
		fieldNames_tSAPTableInput_1.add("MOVETYPE");
		fieldNames_tSAPTableInput_1.add("DEB_CRE_L2");
		fieldNames_tSAPTableInput_1.add("LOC_CURRC2");
		fieldNames_tSAPTableInput_1.add("REGION");
		fieldNames_tSAPTableInput_1.add("/BIC/ZDATE");	
	try {
 		org.talend.sap.model.table.ISAPTableData data_tSAPTableInput_1 = dataService_tSAPTableInput_1.getTableData("/BIC/OHZCPP_OH12", fieldNames_tSAPTableInput_1, "", -1,-1);
 	
	 	boolean empty_tSAPTableInput_1 = data_tSAPTableInput_1.isEmpty();
	 	
	 	if(!empty_tSAPTableInput_1) {
	 		data_tSAPTableInput_1.firstRow();
	 	}
	 	
		do {
			if(empty_tSAPTableInput_1) {
				break;
			}
			
		
			row1.OHREQUID = data_tSAPTableInput_1.getInteger(0);
			row1.DATAPAKID = data_tSAPTableInput_1.getInteger(1);
			row1.RECORD = data_tSAPTableInput_1.getInteger(2);
			row1.BILL_ITEM = data_tSAPTableInput_1.getString(3);
			row1.BILL_NUM = data_tSAPTableInput_1.getString(4);
			row1.DOC_NUMBER = data_tSAPTableInput_1.getString(5);
			row1.S_ORD_ITEM = data_tSAPTableInput_1.getString(6);
			row1.MATERIAL = data_tSAPTableInput_1.getString(7);
			row1.CHRT_ACCTS = data_tSAPTableInput_1.getString(8);
			row1.GL_ACCOUNT = data_tSAPTableInput_1.getString(9);
			row1.ACT_GI_DTE = data_tSAPTableInput_1.getDate(10);
			row1.DELIV_ITEM = data_tSAPTableInput_1.getString(11);
			row1.DELIV_NUMB = data_tSAPTableInput_1.getString(12);
			row1.INCOTERMS = data_tSAPTableInput_1.getString(13);
			row1.INCOTERMS2 = data_tSAPTableInput_1.getString(14);
			row1.SALES = data_tSAPTableInput_1.getDouble(15);
			row1.CURRENCY = data_tSAPTableInput_1.getString(16);
			row1.DOC_CURRCY = data_tSAPTableInput_1.getString(17);
			row1.FISCPER = data_tSAPTableInput_1.getString(18);
			row1.FISCVARNT = data_tSAPTableInput_1.getString(19);
			row1.COMP_CODE = data_tSAPTableInput_1.getString(20);
			row1.CO_AREA = data_tSAPTableInput_1.getString(21);
			row1.DIVISION = data_tSAPTableInput_1.getString(22);
			row1.PROFIT_CTR = data_tSAPTableInput_1.getString(23);
			row1.SHIP_TO = data_tSAPTableInput_1.getString(24);
			row1.LOC_CURRC3 = data_tSAPTableInput_1.getString(25);
			row1.PAYER = data_tSAPTableInput_1.getString(26);
			row1.PLANT = data_tSAPTableInput_1.getString(27);
			row1.SERV_DATE = data_tSAPTableInput_1.getDate(28);
			row1._BIC_ZSALESLCY = data_tSAPTableInput_1.getDouble(29);
			row1.LOC_CURRCY = data_tSAPTableInput_1.getString(30);
			row1._BIC_ZSALESDCY = data_tSAPTableInput_1.getDouble(31);
			row1.DEB_CRE_LC = data_tSAPTableInput_1.getDouble(32);
			row1.DEB_CRE_L3 = data_tSAPTableInput_1.getDouble(33);
			row1.COUNTRY = data_tSAPTableInput_1.getString(34);
			row1._BIC_ZSTREET = data_tSAPTableInput_1.getString(35);
			row1._BIC_ZCITY = data_tSAPTableInput_1.getString(36);
			row1._BIC_ZCMPCDET = data_tSAPTableInput_1.getString(37);
			row1.COMPANY = data_tSAPTableInput_1.getString(38);
			row1._BIC_ZPFTCTRT = data_tSAPTableInput_1.getString(39);
			row1._BIC_ZPAYERT = data_tSAPTableInput_1.getString(40);
			row1.PSTNG_DATE = data_tSAPTableInput_1.getDate(41);
			row1.CREATEDON = data_tSAPTableInput_1.getDate(42);
			row1._BIC_ZGLACCT = data_tSAPTableInput_1.getString(43);
			row1._BIC_ZSHIPT = data_tSAPTableInput_1.getString(44);
			row1._BIC_ZPLANTT = data_tSAPTableInput_1.getString(45);
			row1.POSTCD_GIS = data_tSAPTableInput_1.getString(46);
			row1._BIC_ZPLANTC = data_tSAPTableInput_1.getString(47);
			row1.REVERSEDOC = data_tSAPTableInput_1.getString(48);
			row1._BIC_ZMATNAME = data_tSAPTableInput_1.getString(49);
			row1._BIC_ZCOUNTRYT = data_tSAPTableInput_1.getString(50);
			row1._BIC_ZPLANTCT = data_tSAPTableInput_1.getString(51);
			row1._BIC_ZCOMPC = data_tSAPTableInput_1.getString(52);
			row1._BIC_ZCOMPCT = data_tSAPTableInput_1.getString(53);
			row1._BIC_ZDIVISIONT = data_tSAPTableInput_1.getString(54);
			row1._BIC_ZINCOTERMT = data_tSAPTableInput_1.getString(55);
			row1._BIC_ZASSG_NUM = data_tSAPTableInput_1.getString(56);
			row1.MOVETYPE = data_tSAPTableInput_1.getString(57);
			row1.DEB_CRE_L2 = data_tSAPTableInput_1.getDouble(58);
			row1.LOC_CURRC2 = data_tSAPTableInput_1.getString(59);
			row1.REGION = data_tSAPTableInput_1.getString(60);
			row1._BIC_ZDATE = data_tSAPTableInput_1.getDate(61);
 



/**
 * [tSAPTableInput_1 begin ] stop
 */
	
	/**
	 * [tSAPTableInput_1 main ] start
	 */

	

	
	
	currentComponent="tSAPTableInput_1";

	

 


	tos_count_tSAPTableInput_1++;

/**
 * [tSAPTableInput_1 main ] stop
 */

	
	/**
	 * [tFlowMeter_16 main ] start
	 */

	

	
	
	currentComponent="tFlowMeter_16";

	

			//row1
			//row1


			
				if(execStat){
					runStat.updateStatOnConnection("row1"+iterateId,1, 1);
				} 
			

		
    			if(log.isTraceEnabled()){
    				log.trace("row1 - " + (row1==null? "": row1.toLogString()));
    			}
    		

    count_tFlowMeter_16++; 
 
     row2 = row1;


	tos_count_tFlowMeter_16++;

/**
 * [tFlowMeter_16 main ] stop
 */

	
	/**
	 * [tMap_1 main ] start
	 */

	

	
	
	currentComponent="tMap_1";

	

			//row2
			//row2


			
				if(execStat){
					runStat.updateStatOnConnection("row2"+iterateId,1, 1);
				} 
			

		
    			if(log.isTraceEnabled()){
    				log.trace("row2 - " + (row2==null? "": row2.toLogString()));
    			}
    		

		
		
		boolean hasCasePrimitiveKeyWithNull_tMap_1 = false;
		
        // ###############################
        // # Input tables (lookups)
		  boolean rejectedInnerJoin_tMap_1 = false;
		  boolean mainRowRejected_tMap_1 = false;
            				    								  
		// ###############################
        { // start of Var scope
        
	        // ###############################
        	// # Vars tables
        
Var__tMap_1__Struct Var = Var__tMap_1;// ###############################
        // ###############################
        // # Output tables

A = null;


// # Output table : 'A'
// # Filter conditions 
if( 

TalendDate.compareDate(row2._BIC_ZDATE,(Date)globalMap.get("load_date"))>0   

 ) {
count_A_tMap_1++;

A_tmp.company_code_key = row2.COMP_CODE ;
A_tmp.company_code_text = row2._BIC_ZCMPCDET ;
A_tmp.company_code_country_text = row2._BIC_ZCOMPCT ;
A_tmp.profit_center_key = row2.PROFIT_CTR ;
A_tmp.profit_center_text = row2._BIC_ZPFTCTRT ;
A_tmp.to_division = row2._BIC_ZDIVISIONT;
A_tmp.plant = row2.PLANT ;
A_tmp.billing_document = row2.BILL_NUM;
A_tmp.billing_document_item = row2.BILL_ITEM ;
A_tmp.payer_key = row2.PAYER;
A_tmp.payer_text = row2._BIC_ZPAYERT ;
A_tmp.fiscal_year_period_key = row2.FISCPER ;
A_tmp.entry_date = row2.CREATEDON ;
A_tmp.rta_date = row2.PSTNG_DATE ;
A_tmp.serv_rendered_date = row2.SERV_DATE ;
A_tmp.act_goods_issue_date = row2.ACT_GI_DTE ;
A_tmp.sales_document = row2.DOC_NUMBER ;
A_tmp.sales_document_item = row2.S_ORD_ITEM ;
A_tmp.delivery_number = row2.DELIV_NUMB;
A_tmp.delivery_item = row2.DELIV_ITEM ;
A_tmp.gl_account_key = row2.GL_ACCOUNT ;
A_tmp.gl_account_text = row2._BIC_ZGLACCT ;
A_tmp.material_key = row2.MATERIAL;
A_tmp.material_text = row2._BIC_ZMATNAME ;
A_tmp.ship_to_party_key = row2.SHIP_TO ;
A_tmp.ship_to_party_text = row2._BIC_ZSHIPT ;
A_tmp.street_name_key = row2._BIC_ZSTREET ;
A_tmp.location_key = row2._BIC_ZCITY ;
A_tmp.country_key = row2.COUNTRY ;
A_tmp.country_text = row2._BIC_ZCOUNTRYT ;
A_tmp.plant_key = row2.PLANT ;
A_tmp.plant_text = row2._BIC_ZPLANTT ;
A_tmp.plant_bas_pstcdegeorelkey = row2.POSTCD_GIS ;
A_tmp.plant_country_key = row2._BIC_ZPLANTC ;
A_tmp.plant_country_text = row2._BIC_ZPLANTCT ;
A_tmp.incoterms = row2._BIC_ZINCOTERMT ;
A_tmp.incoterms_2 = row2.INCOTERMS2 ;
A_tmp.cancellation_flag_key = row2.REVERSEDOC ;
A_tmp.sales_in_document_currency = row2._BIC_ZSALESDCY ;
A_tmp.document_currency_key = row2.DOC_CURRCY ;
A_tmp.amount_in_local_currency = row2._BIC_ZSALESLCY ;
A_tmp.amount_in_usd = row2.SALES ;
A_tmp.currency_key = row2.CURRENCY ;
A_tmp.lc1_for_cogs = row2.DEB_CRE_LC ;
A_tmp.local_currency_key = row2.LOC_CURRCY ;
A_tmp.lc3_for_cogs = row2.DEB_CRE_L3 ;
A_tmp.third_local_currency_key = row2.LOC_CURRC3 ;
A_tmp.movement_type = row2.MOVETYPE ;
A_tmp.group_currency_amount = row2.DEB_CRE_L2 ;
A_tmp.group_currency = row2.LOC_CURRC2 ;
A_tmp.ship_to_state = row2.REGION ;
A_tmp.plant_state = null;
A_tmp.sales_assignment_number = row2._BIC_ZASSG_NUM ;
A_tmp.load_date = row2._BIC_ZDATE ;
A = A_tmp;
log.debug("tMap_1 - Outputting the record " + count_A_tMap_1 + " of the output table 'A'.");

} // closing filter/reject
// ###############################

} // end of Var scope

rejectedInnerJoin_tMap_1 = false;










 


	tos_count_tMap_1++;

/**
 * [tMap_1 main ] stop
 */
// Start of branch "A"
if(A != null) { 



	
	/**
	 * [tPostgresqlOutput_1 main ] start
	 */

	

	
	
	currentComponent="tPostgresqlOutput_1";

	

			//A
			//A


			
				if(execStat){
					runStat.updateStatOnConnection("A"+iterateId,1, 1);
				} 
			

		
    			if(log.isTraceEnabled()){
    				log.trace("A - " + (A==null? "": A.toLogString()));
    			}
    		



        whetherReject_tPostgresqlOutput_1 = false;
                    if(A.company_code_key == null) {
pstmt_tPostgresqlOutput_1.setNull(1, java.sql.Types.VARCHAR);
} else {pstmt_tPostgresqlOutput_1.setString(1, A.company_code_key);
}

                    if(A.company_code_text == null) {
pstmt_tPostgresqlOutput_1.setNull(2, java.sql.Types.VARCHAR);
} else {pstmt_tPostgresqlOutput_1.setString(2, A.company_code_text);
}

                    if(A.company_code_country_text == null) {
pstmt_tPostgresqlOutput_1.setNull(3, java.sql.Types.VARCHAR);
} else {pstmt_tPostgresqlOutput_1.setString(3, A.company_code_country_text);
}

                    if(A.profit_center_key == null) {
pstmt_tPostgresqlOutput_1.setNull(4, java.sql.Types.VARCHAR);
} else {pstmt_tPostgresqlOutput_1.setString(4, A.profit_center_key);
}

                    if(A.profit_center_text == null) {
pstmt_tPostgresqlOutput_1.setNull(5, java.sql.Types.VARCHAR);
} else {pstmt_tPostgresqlOutput_1.setString(5, A.profit_center_text);
}

                    if(A.to_division == null) {
pstmt_tPostgresqlOutput_1.setNull(6, java.sql.Types.VARCHAR);
} else {pstmt_tPostgresqlOutput_1.setString(6, A.to_division);
}

                    if(A.plant == null) {
pstmt_tPostgresqlOutput_1.setNull(7, java.sql.Types.VARCHAR);
} else {pstmt_tPostgresqlOutput_1.setString(7, A.plant);
}

                    if(A.billing_document == null) {
pstmt_tPostgresqlOutput_1.setNull(8, java.sql.Types.VARCHAR);
} else {pstmt_tPostgresqlOutput_1.setString(8, A.billing_document);
}

                    if(A.billing_document_item == null) {
pstmt_tPostgresqlOutput_1.setNull(9, java.sql.Types.VARCHAR);
} else {pstmt_tPostgresqlOutput_1.setString(9, A.billing_document_item);
}

                    if(A.payer_key == null) {
pstmt_tPostgresqlOutput_1.setNull(10, java.sql.Types.VARCHAR);
} else {pstmt_tPostgresqlOutput_1.setString(10, A.payer_key);
}

                    if(A.payer_text == null) {
pstmt_tPostgresqlOutput_1.setNull(11, java.sql.Types.VARCHAR);
} else {pstmt_tPostgresqlOutput_1.setString(11, A.payer_text);
}

                    if(A.fiscal_year_period_key == null) {
pstmt_tPostgresqlOutput_1.setNull(12, java.sql.Types.VARCHAR);
} else {pstmt_tPostgresqlOutput_1.setString(12, A.fiscal_year_period_key);
}

                    if(A.entry_date != null) {
pstmt_tPostgresqlOutput_1.setTimestamp(13, new java.sql.Timestamp(A.entry_date.getTime()));
} else {
pstmt_tPostgresqlOutput_1.setNull(13, java.sql.Types.TIMESTAMP);
}

                    if(A.rta_date != null) {
pstmt_tPostgresqlOutput_1.setTimestamp(14, new java.sql.Timestamp(A.rta_date.getTime()));
} else {
pstmt_tPostgresqlOutput_1.setNull(14, java.sql.Types.TIMESTAMP);
}

                    if(A.serv_rendered_date != null) {
pstmt_tPostgresqlOutput_1.setTimestamp(15, new java.sql.Timestamp(A.serv_rendered_date.getTime()));
} else {
pstmt_tPostgresqlOutput_1.setNull(15, java.sql.Types.TIMESTAMP);
}

                    if(A.act_goods_issue_date != null) {
pstmt_tPostgresqlOutput_1.setTimestamp(16, new java.sql.Timestamp(A.act_goods_issue_date.getTime()));
} else {
pstmt_tPostgresqlOutput_1.setNull(16, java.sql.Types.TIMESTAMP);
}

                    if(A.sales_document == null) {
pstmt_tPostgresqlOutput_1.setNull(17, java.sql.Types.VARCHAR);
} else {pstmt_tPostgresqlOutput_1.setString(17, A.sales_document);
}

                    if(A.sales_document_item == null) {
pstmt_tPostgresqlOutput_1.setNull(18, java.sql.Types.VARCHAR);
} else {pstmt_tPostgresqlOutput_1.setString(18, A.sales_document_item);
}

                    if(A.delivery_number == null) {
pstmt_tPostgresqlOutput_1.setNull(19, java.sql.Types.VARCHAR);
} else {pstmt_tPostgresqlOutput_1.setString(19, A.delivery_number);
}

                    if(A.delivery_item == null) {
pstmt_tPostgresqlOutput_1.setNull(20, java.sql.Types.VARCHAR);
} else {pstmt_tPostgresqlOutput_1.setString(20, A.delivery_item);
}

                    if(A.gl_account_key == null) {
pstmt_tPostgresqlOutput_1.setNull(21, java.sql.Types.VARCHAR);
} else {pstmt_tPostgresqlOutput_1.setString(21, A.gl_account_key);
}

                    if(A.gl_account_text == null) {
pstmt_tPostgresqlOutput_1.setNull(22, java.sql.Types.VARCHAR);
} else {pstmt_tPostgresqlOutput_1.setString(22, A.gl_account_text);
}

                    if(A.material_key == null) {
pstmt_tPostgresqlOutput_1.setNull(23, java.sql.Types.VARCHAR);
} else {pstmt_tPostgresqlOutput_1.setString(23, A.material_key);
}

                    if(A.material_text == null) {
pstmt_tPostgresqlOutput_1.setNull(24, java.sql.Types.VARCHAR);
} else {pstmt_tPostgresqlOutput_1.setString(24, A.material_text);
}

                    if(A.ship_to_party_key == null) {
pstmt_tPostgresqlOutput_1.setNull(25, java.sql.Types.VARCHAR);
} else {pstmt_tPostgresqlOutput_1.setString(25, A.ship_to_party_key);
}

                    if(A.ship_to_party_text == null) {
pstmt_tPostgresqlOutput_1.setNull(26, java.sql.Types.VARCHAR);
} else {pstmt_tPostgresqlOutput_1.setString(26, A.ship_to_party_text);
}

                    if(A.street_name_key == null) {
pstmt_tPostgresqlOutput_1.setNull(27, java.sql.Types.VARCHAR);
} else {pstmt_tPostgresqlOutput_1.setString(27, A.street_name_key);
}

                    if(A.location_key == null) {
pstmt_tPostgresqlOutput_1.setNull(28, java.sql.Types.VARCHAR);
} else {pstmt_tPostgresqlOutput_1.setString(28, A.location_key);
}

                    if(A.country_key == null) {
pstmt_tPostgresqlOutput_1.setNull(29, java.sql.Types.VARCHAR);
} else {pstmt_tPostgresqlOutput_1.setString(29, A.country_key);
}

                    if(A.country_text == null) {
pstmt_tPostgresqlOutput_1.setNull(30, java.sql.Types.VARCHAR);
} else {pstmt_tPostgresqlOutput_1.setString(30, A.country_text);
}

                    if(A.plant_key == null) {
pstmt_tPostgresqlOutput_1.setNull(31, java.sql.Types.VARCHAR);
} else {pstmt_tPostgresqlOutput_1.setString(31, A.plant_key);
}

                    if(A.plant_text == null) {
pstmt_tPostgresqlOutput_1.setNull(32, java.sql.Types.VARCHAR);
} else {pstmt_tPostgresqlOutput_1.setString(32, A.plant_text);
}

                    if(A.plant_bas_pstcdegeorelkey == null) {
pstmt_tPostgresqlOutput_1.setNull(33, java.sql.Types.VARCHAR);
} else {pstmt_tPostgresqlOutput_1.setString(33, A.plant_bas_pstcdegeorelkey);
}

                    if(A.plant_country_key == null) {
pstmt_tPostgresqlOutput_1.setNull(34, java.sql.Types.VARCHAR);
} else {pstmt_tPostgresqlOutput_1.setString(34, A.plant_country_key);
}

                    if(A.plant_country_text == null) {
pstmt_tPostgresqlOutput_1.setNull(35, java.sql.Types.VARCHAR);
} else {pstmt_tPostgresqlOutput_1.setString(35, A.plant_country_text);
}

                    if(A.incoterms == null) {
pstmt_tPostgresqlOutput_1.setNull(36, java.sql.Types.VARCHAR);
} else {pstmt_tPostgresqlOutput_1.setString(36, A.incoterms);
}

                    if(A.incoterms_2 == null) {
pstmt_tPostgresqlOutput_1.setNull(37, java.sql.Types.VARCHAR);
} else {pstmt_tPostgresqlOutput_1.setString(37, A.incoterms_2);
}

                    if(A.cancellation_flag_key == null) {
pstmt_tPostgresqlOutput_1.setNull(38, java.sql.Types.VARCHAR);
} else {pstmt_tPostgresqlOutput_1.setString(38, A.cancellation_flag_key);
}

                    if(A.sales_in_document_currency == null) {
pstmt_tPostgresqlOutput_1.setNull(39, java.sql.Types.DOUBLE);
} else {pstmt_tPostgresqlOutput_1.setDouble(39, A.sales_in_document_currency);
}

                    if(A.document_currency_key == null) {
pstmt_tPostgresqlOutput_1.setNull(40, java.sql.Types.VARCHAR);
} else {pstmt_tPostgresqlOutput_1.setString(40, A.document_currency_key);
}

                    if(A.amount_in_local_currency == null) {
pstmt_tPostgresqlOutput_1.setNull(41, java.sql.Types.DOUBLE);
} else {pstmt_tPostgresqlOutput_1.setDouble(41, A.amount_in_local_currency);
}

                    if(A.amount_in_usd == null) {
pstmt_tPostgresqlOutput_1.setNull(42, java.sql.Types.DOUBLE);
} else {pstmt_tPostgresqlOutput_1.setDouble(42, A.amount_in_usd);
}

                    if(A.currency_key == null) {
pstmt_tPostgresqlOutput_1.setNull(43, java.sql.Types.VARCHAR);
} else {pstmt_tPostgresqlOutput_1.setString(43, A.currency_key);
}

                    if(A.lc1_for_cogs == null) {
pstmt_tPostgresqlOutput_1.setNull(44, java.sql.Types.DOUBLE);
} else {pstmt_tPostgresqlOutput_1.setDouble(44, A.lc1_for_cogs);
}

                    if(A.local_currency_key == null) {
pstmt_tPostgresqlOutput_1.setNull(45, java.sql.Types.VARCHAR);
} else {pstmt_tPostgresqlOutput_1.setString(45, A.local_currency_key);
}

                    if(A.lc3_for_cogs == null) {
pstmt_tPostgresqlOutput_1.setNull(46, java.sql.Types.DOUBLE);
} else {pstmt_tPostgresqlOutput_1.setDouble(46, A.lc3_for_cogs);
}

                    if(A.third_local_currency_key == null) {
pstmt_tPostgresqlOutput_1.setNull(47, java.sql.Types.VARCHAR);
} else {pstmt_tPostgresqlOutput_1.setString(47, A.third_local_currency_key);
}

                    if(A.movement_type == null) {
pstmt_tPostgresqlOutput_1.setNull(48, java.sql.Types.VARCHAR);
} else {pstmt_tPostgresqlOutput_1.setString(48, A.movement_type);
}

                    if(A.group_currency_amount == null) {
pstmt_tPostgresqlOutput_1.setNull(49, java.sql.Types.DOUBLE);
} else {pstmt_tPostgresqlOutput_1.setDouble(49, A.group_currency_amount);
}

                    if(A.group_currency == null) {
pstmt_tPostgresqlOutput_1.setNull(50, java.sql.Types.VARCHAR);
} else {pstmt_tPostgresqlOutput_1.setString(50, A.group_currency);
}

                    if(A.ship_to_state == null) {
pstmt_tPostgresqlOutput_1.setNull(51, java.sql.Types.VARCHAR);
} else {pstmt_tPostgresqlOutput_1.setString(51, A.ship_to_state);
}

                    if(A.plant_state == null) {
pstmt_tPostgresqlOutput_1.setNull(52, java.sql.Types.VARCHAR);
} else {pstmt_tPostgresqlOutput_1.setString(52, A.plant_state);
}

                    if(A.sales_assignment_number == null) {
pstmt_tPostgresqlOutput_1.setNull(53, java.sql.Types.VARCHAR);
} else {pstmt_tPostgresqlOutput_1.setString(53, A.sales_assignment_number);
}

                    if(A.load_date != null) {
pstmt_tPostgresqlOutput_1.setTimestamp(54, new java.sql.Timestamp(A.load_date.getTime()));
} else {
pstmt_tPostgresqlOutput_1.setNull(54, java.sql.Types.TIMESTAMP);
}

			
    		pstmt_tPostgresqlOutput_1.addBatch();
    		nb_line_tPostgresqlOutput_1++;
    		  
                if(log.isDebugEnabled())
            log.debug("tPostgresqlOutput_1 - "  + ("Adding the record ")  + (nb_line_tPostgresqlOutput_1)  + (" to the ")  + ("INSERT")  + (" batch.") );
    		  batchSizeCounter_tPostgresqlOutput_1++;
    		  
    			if ((batchSize_tPostgresqlOutput_1 > 0) && (batchSize_tPostgresqlOutput_1 <= batchSizeCounter_tPostgresqlOutput_1)) {
                try {
						int countSum_tPostgresqlOutput_1 = 0;
						    
                if(log.isDebugEnabled())
            log.debug("tPostgresqlOutput_1 - "  + ("Executing the ")  + ("INSERT")  + (" batch.") );
						for(int countEach_tPostgresqlOutput_1: pstmt_tPostgresqlOutput_1.executeBatch()) {
							countSum_tPostgresqlOutput_1 += (countEach_tPostgresqlOutput_1 < 0 ? 0 : countEach_tPostgresqlOutput_1);
						}
                if(log.isDebugEnabled())
            log.debug("tPostgresqlOutput_1 - "  + ("The ")  + ("INSERT")  + (" batch execution has succeeded.") );
				    	
				    		insertedCount_tPostgresqlOutput_1 += countSum_tPostgresqlOutput_1;
				    	
            	    	batchSizeCounter_tPostgresqlOutput_1 = 0;
                }catch (java.sql.BatchUpdateException e){
                	
                	int countSum_tPostgresqlOutput_1 = 0;
					for(int countEach_tPostgresqlOutput_1: e.getUpdateCounts()) {
						countSum_tPostgresqlOutput_1 += (countEach_tPostgresqlOutput_1 < 0 ? 0 : countEach_tPostgresqlOutput_1);
					}
					
			    		insertedCount_tPostgresqlOutput_1 += countSum_tPostgresqlOutput_1;
			    	
            log.error("tPostgresqlOutput_1 - "  + (e.getMessage()) );
                	System.err.println(e.getMessage());
                	
                }
    			}
    		
    		    commitCounter_tPostgresqlOutput_1++;
                if(commitEvery_tPostgresqlOutput_1 <= commitCounter_tPostgresqlOutput_1) {
                if ((batchSize_tPostgresqlOutput_1 > 0) && (batchSizeCounter_tPostgresqlOutput_1 > 0)) {
                try {
                		int countSum_tPostgresqlOutput_1 = 0;
                		    
                if(log.isDebugEnabled())
            log.debug("tPostgresqlOutput_1 - "  + ("Executing the ")  + ("INSERT")  + (" batch.") );
						for(int countEach_tPostgresqlOutput_1: pstmt_tPostgresqlOutput_1.executeBatch()) {
							countSum_tPostgresqlOutput_1 += (countEach_tPostgresqlOutput_1 < 0 ? 0 : countEach_tPostgresqlOutput_1);
						}
                if(log.isDebugEnabled())
            log.debug("tPostgresqlOutput_1 - "  + ("The ")  + ("INSERT")  + (" batch execution has succeeded.") );
            	    	
            	    		insertedCount_tPostgresqlOutput_1 += countSum_tPostgresqlOutput_1;
            	    	
                batchSizeCounter_tPostgresqlOutput_1 = 0;
                }catch (java.sql.BatchUpdateException e){
                	
                		int countSum_tPostgresqlOutput_1 = 0;
						for(int countEach_tPostgresqlOutput_1: e.getUpdateCounts()) {
							countSum_tPostgresqlOutput_1 += (countEach_tPostgresqlOutput_1 < 0 ? 0 : countEach_tPostgresqlOutput_1);
						}
						
				    		insertedCount_tPostgresqlOutput_1 += countSum_tPostgresqlOutput_1;
				    	
            log.error("tPostgresqlOutput_1 - "  + (e.getMessage()) );
                        System.err.println(e.getMessage());
                	
                }
            }
                if(log.isDebugEnabled())
            log.debug("tPostgresqlOutput_1 - "  + ("Connection starting to commit ")  + (commitCounter_tPostgresqlOutput_1)  + (" record(s).") );
                	conn_tPostgresqlOutput_1.commit();
                	
                if(log.isDebugEnabled())
            log.debug("tPostgresqlOutput_1 - "  + ("Connection commit has succeeded.") );
                	commitCounter_tPostgresqlOutput_1=0;
                }

 


	tos_count_tPostgresqlOutput_1++;

/**
 * [tPostgresqlOutput_1 main ] stop
 */

} // End of branch "A"










	
	/**
	 * [tSAPTableInput_1 end ] start
	 */

	

	
	
	currentComponent="tSAPTableInput_1";

	


	} while(data_tSAPTableInput_1.nextRow());
} finally {
	
	if(connection_tSAPTableInput_1!=null && connection_tSAPTableInput_1.isAlive()) {
		connection_tSAPTableInput_1.close();
	}
	
}

 

ok_Hash.put("tSAPTableInput_1", true);
end_Hash.put("tSAPTableInput_1", System.currentTimeMillis());




/**
 * [tSAPTableInput_1 end ] stop
 */

	
	/**
	 * [tFlowMeter_16 end ] start
	 */

	

	
	
	currentComponent="tFlowMeter_16";

	

                if(log.isDebugEnabled())
            log.debug("tFlowMeter_16 - "  + ("Sending message to tFlowMeterCatcher_1.") );
	tFlowMeterCatcher_1.addMessage("row1", new Integer(count_tFlowMeter_16), "null", "", "tFlowMeter_16");

			if(execStat){
				if(resourceMap.get("inIterateVComp") == null || !((Boolean)resourceMap.get("inIterateVComp"))){
			 		runStat.updateStatOnConnection("row1"+iterateId,2, 0); 
			 	}
			}
		
 
                if(log.isDebugEnabled())
            log.debug("tFlowMeter_16 - "  + ("Done.") );

ok_Hash.put("tFlowMeter_16", true);
end_Hash.put("tFlowMeter_16", System.currentTimeMillis());




/**
 * [tFlowMeter_16 end ] stop
 */

	
	/**
	 * [tMap_1 end ] start
	 */

	

	
	
	currentComponent="tMap_1";

	


// ###############################
// # Lookup hashes releasing
// ###############################      
				log.debug("tMap_1 - Written records count in the table 'A': " + count_A_tMap_1 + ".");





			if(execStat){
				if(resourceMap.get("inIterateVComp") == null || !((Boolean)resourceMap.get("inIterateVComp"))){
			 		runStat.updateStatOnConnection("row2"+iterateId,2, 0); 
			 	}
			}
		
 
                if(log.isDebugEnabled())
            log.debug("tMap_1 - "  + ("Done.") );

ok_Hash.put("tMap_1", true);
end_Hash.put("tMap_1", System.currentTimeMillis());




/**
 * [tMap_1 end ] stop
 */

	
	/**
	 * [tPostgresqlOutput_1 end ] start
	 */

	

	
	
	currentComponent="tPostgresqlOutput_1";

	



	    try {
				int countSum_tPostgresqlOutput_1 = 0;
				if (pstmt_tPostgresqlOutput_1 != null && batchSizeCounter_tPostgresqlOutput_1 > 0) {
						
                if(log.isDebugEnabled())
            log.debug("tPostgresqlOutput_1 - "  + ("Executing the ")  + ("INSERT")  + (" batch.") );
					for(int countEach_tPostgresqlOutput_1: pstmt_tPostgresqlOutput_1.executeBatch()) {
						countSum_tPostgresqlOutput_1 += (countEach_tPostgresqlOutput_1 < 0 ? 0 : countEach_tPostgresqlOutput_1);
					}
						
                if(log.isDebugEnabled())
            log.debug("tPostgresqlOutput_1 - "  + ("The ")  + ("INSERT")  + (" batch execution has succeeded.") );
				}
		    	
		    		insertedCount_tPostgresqlOutput_1 += countSum_tPostgresqlOutput_1;
		    	
	    }catch (java.sql.BatchUpdateException e){
	    	
	    	int countSum_tPostgresqlOutput_1 = 0;
			for(int countEach_tPostgresqlOutput_1: e.getUpdateCounts()) {
				countSum_tPostgresqlOutput_1 += (countEach_tPostgresqlOutput_1 < 0 ? 0 : countEach_tPostgresqlOutput_1);
			}
			
	    		insertedCount_tPostgresqlOutput_1 += countSum_tPostgresqlOutput_1;
	    	
            log.error("tPostgresqlOutput_1 - "  + (e.getMessage()) );
	    	System.err.println(e.getMessage());
	    	
		}
	    
        if(pstmt_tPostgresqlOutput_1 != null) {
            pstmt_tPostgresqlOutput_1.close();
        }

			
                if(log.isDebugEnabled())
            log.debug("tPostgresqlOutput_1 - "  + ("Connection starting to commit ")  + (commitCounter_tPostgresqlOutput_1)  + (" record(s).") );
			conn_tPostgresqlOutput_1.commit();
			
                if(log.isDebugEnabled())
            log.debug("tPostgresqlOutput_1 - "  + ("Connection commit has succeeded.") );
		
                if(log.isDebugEnabled())
            log.debug("tPostgresqlOutput_1 - "  + ("Closing the connection to the database.") );
    	conn_tPostgresqlOutput_1 .close();
    	
                if(log.isDebugEnabled())
            log.debug("tPostgresqlOutput_1 - "  + ("Connection to the database has closed.") );
    	resourceMap.put("finish_tPostgresqlOutput_1", true);
    	

	nb_line_deleted_tPostgresqlOutput_1=nb_line_deleted_tPostgresqlOutput_1+ deletedCount_tPostgresqlOutput_1;
	nb_line_update_tPostgresqlOutput_1=nb_line_update_tPostgresqlOutput_1 + updatedCount_tPostgresqlOutput_1;
	nb_line_inserted_tPostgresqlOutput_1=nb_line_inserted_tPostgresqlOutput_1 + insertedCount_tPostgresqlOutput_1;
	nb_line_rejected_tPostgresqlOutput_1=nb_line_rejected_tPostgresqlOutput_1 + rejectedCount_tPostgresqlOutput_1;
	
        globalMap.put("tPostgresqlOutput_1_NB_LINE",nb_line_tPostgresqlOutput_1);
        globalMap.put("tPostgresqlOutput_1_NB_LINE_UPDATED",nb_line_update_tPostgresqlOutput_1);
        globalMap.put("tPostgresqlOutput_1_NB_LINE_INSERTED",nb_line_inserted_tPostgresqlOutput_1);
        globalMap.put("tPostgresqlOutput_1_NB_LINE_DELETED",nb_line_deleted_tPostgresqlOutput_1);
        globalMap.put("tPostgresqlOutput_1_NB_LINE_REJECTED", nb_line_rejected_tPostgresqlOutput_1);
    
	
                if(log.isDebugEnabled())
            log.debug("tPostgresqlOutput_1 - "  + ("Has ")  + ("inserted")  + (" ")  + (nb_line_inserted_tPostgresqlOutput_1)  + (" record(s).") );


			if(execStat){
				if(resourceMap.get("inIterateVComp") == null || !((Boolean)resourceMap.get("inIterateVComp"))){
			 		runStat.updateStatOnConnection("A"+iterateId,2, 0); 
			 	}
			}
		
 
                if(log.isDebugEnabled())
            log.debug("tPostgresqlOutput_1 - "  + ("Done.") );

ok_Hash.put("tPostgresqlOutput_1", true);
end_Hash.put("tPostgresqlOutput_1", System.currentTimeMillis());




/**
 * [tPostgresqlOutput_1 end ] stop
 */









				}//end the resume

				
							tFlowMeterCatcher_1Process(globalMap);
						



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage());
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tSAPTableInput_1 finally ] start
	 */

	

	
	
	currentComponent="tSAPTableInput_1";

	

 



/**
 * [tSAPTableInput_1 finally ] stop
 */

	
	/**
	 * [tFlowMeter_16 finally ] start
	 */

	

	
	
	currentComponent="tFlowMeter_16";

	

 



/**
 * [tFlowMeter_16 finally ] stop
 */

	
	/**
	 * [tMap_1 finally ] start
	 */

	

	
	
	currentComponent="tMap_1";

	

 



/**
 * [tMap_1 finally ] stop
 */

	
	/**
	 * [tPostgresqlOutput_1 finally ] start
	 */

	

	
	
	currentComponent="tPostgresqlOutput_1";

	



	
		if(resourceMap.get("finish_tPostgresqlOutput_1")==null){
			if(resourceMap.get("conn_tPostgresqlOutput_1")!=null){
				try {
					
                if(log.isDebugEnabled())
            log.debug("tPostgresqlOutput_1 - "  + ("Closing the connection to the database.") );
					((java.sql.Connection)resourceMap.get("conn_tPostgresqlOutput_1")).close();
					
                if(log.isDebugEnabled())
            log.debug("tPostgresqlOutput_1 - "  + ("Connection to the database has closed.") );
				} catch (java.sql.SQLException sqlEx_tPostgresqlOutput_1) {
					String errorMessage_tPostgresqlOutput_1 = "failed to close the connection in tPostgresqlOutput_1 :" + sqlEx_tPostgresqlOutput_1.getMessage();
					
            log.error("tPostgresqlOutput_1 - "  + (errorMessage_tPostgresqlOutput_1) );
					System.err.println(errorMessage_tPostgresqlOutput_1);
				}
			}
		}
	

 



/**
 * [tPostgresqlOutput_1 finally ] stop
 */









				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tSAPTableInput_1_SUBPROCESS_STATE", 1);
	}
	

public void tPrejob_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tPrejob_1_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tPrejob_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tPrejob_1", false);
		start_Hash.put("tPrejob_1", System.currentTimeMillis());
		
	
	currentComponent="tPrejob_1";

	
		int tos_count_tPrejob_1 = 0;
		
    	class BytesLimit65535_tPrejob_1{
    		public void limitLog4jByte() throws Exception{
    			
    		}
    	}
    	
        new BytesLimit65535_tPrejob_1().limitLog4jByte();

 



/**
 * [tPrejob_1 begin ] stop
 */
	
	/**
	 * [tPrejob_1 main ] start
	 */

	

	
	
	currentComponent="tPrejob_1";

	

 


	tos_count_tPrejob_1++;

/**
 * [tPrejob_1 main ] stop
 */
	
	/**
	 * [tPrejob_1 end ] start
	 */

	

	
	
	currentComponent="tPrejob_1";

	

 

ok_Hash.put("tPrejob_1", true);
end_Hash.put("tPrejob_1", System.currentTimeMillis());

				if(execStat){   
   	 				runStat.updateStatOnConnection("OnComponentOk1", 0, "ok");
				}
				tPostgresqlInput_1Process(globalMap);



/**
 * [tPrejob_1 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage());
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tPrejob_1 finally ] start
	 */

	

	
	
	currentComponent="tPrejob_1";

	

 



/**
 * [tPrejob_1 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tPrejob_1_SUBPROCESS_STATE", 1);
	}
	


public static class row12Struct implements routines.system.IPersistableRow<row12Struct> {
    final static byte[] commonByteArrayLock_OG_APPLICATIONS_J_X_MAN_FINANCE_LAGTIME = new byte[0];
    static byte[] commonByteArray_OG_APPLICATIONS_J_X_MAN_FINANCE_LAGTIME = new byte[0];

	
			    public java.util.Date load_date;

				public java.util.Date getLoad_date () {
					return this.load_date;
				}
				



	private java.util.Date readDate(ObjectInputStream dis) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(dis.readLong());
		}
		return dateReturn;
	}

    private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException{
		if(date1 == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeLong(date1.getTime());
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_OG_APPLICATIONS_J_X_MAN_FINANCE_LAGTIME) {

        	try {

        		int length = 0;
		
					this.load_date = readDate(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// java.util.Date
				
						writeDate(this.load_date,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("load_date="+String.valueOf(load_date));
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				if(load_date == null){
        					sb.append("<null>");
        				}else{
            				sb.append(load_date);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(row12Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}
public void tPostgresqlInput_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tPostgresqlInput_1_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;



		row12Struct row12 = new row12Struct();




	
	/**
	 * [tSetGlobalVar_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tSetGlobalVar_1", false);
		start_Hash.put("tSetGlobalVar_1", System.currentTimeMillis());
		
	
	currentComponent="tSetGlobalVar_1";

	
			if (execStat) {
				if(resourceMap.get("inIterateVComp") == null){
					
						runStat.updateStatOnConnection("row12" + iterateId, 0, 0);
					
				}
			} 

		
		int tos_count_tSetGlobalVar_1 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tSetGlobalVar_1 - "  + ("Start to work.") );
    	class BytesLimit65535_tSetGlobalVar_1{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tSetGlobalVar_1 = new StringBuilder();
            log4jParamters_tSetGlobalVar_1.append("Parameters:");
                    log4jParamters_tSetGlobalVar_1.append("VARIABLES" + " = " + "[{VALUE="+("row12.load_date")+", KEY="+("\"load_date\"")+"}]");
                log4jParamters_tSetGlobalVar_1.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tSetGlobalVar_1 - "  + (log4jParamters_tSetGlobalVar_1) );
    		}
    	}
    	
        new BytesLimit65535_tSetGlobalVar_1().limitLog4jByte();

 



/**
 * [tSetGlobalVar_1 begin ] stop
 */



	
	/**
	 * [tPostgresqlInput_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tPostgresqlInput_1", false);
		start_Hash.put("tPostgresqlInput_1", System.currentTimeMillis());
		
	
	currentComponent="tPostgresqlInput_1";

	
		int tos_count_tPostgresqlInput_1 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tPostgresqlInput_1 - "  + ("Start to work.") );
    	class BytesLimit65535_tPostgresqlInput_1{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tPostgresqlInput_1 = new StringBuilder();
            log4jParamters_tPostgresqlInput_1.append("Parameters:");
                    log4jParamters_tPostgresqlInput_1.append("USE_EXISTING_CONNECTION" + " = " + "false");
                log4jParamters_tPostgresqlInput_1.append(" | ");
                    log4jParamters_tPostgresqlInput_1.append("DB_VERSION" + " = " + "V9_X");
                log4jParamters_tPostgresqlInput_1.append(" | ");
                    log4jParamters_tPostgresqlInput_1.append("HOST" + " = " + "context.aws_gp_prof_Server");
                log4jParamters_tPostgresqlInput_1.append(" | ");
                    log4jParamters_tPostgresqlInput_1.append("PORT" + " = " + "context.aws_gp_prof_Port");
                log4jParamters_tPostgresqlInput_1.append(" | ");
                    log4jParamters_tPostgresqlInput_1.append("DBNAME" + " = " + "\"bhdl\"");
                log4jParamters_tPostgresqlInput_1.append(" | ");
                    log4jParamters_tPostgresqlInput_1.append("SCHEMA_DB" + " = " + "\"og_bhone_bw\"");
                log4jParamters_tPostgresqlInput_1.append(" | ");
                    log4jParamters_tPostgresqlInput_1.append("USER" + " = " + "context.aws_gp_prof_Login");
                log4jParamters_tPostgresqlInput_1.append(" | ");
                    log4jParamters_tPostgresqlInput_1.append("PASS" + " = " + String.valueOf(routines.system.PasswordEncryptUtil.encryptPassword(context.aws_gp_prof_Password)).substring(0, 4) + "...");     
                log4jParamters_tPostgresqlInput_1.append(" | ");
                    log4jParamters_tPostgresqlInput_1.append("QUERYSTORE" + " = " + "\"\"");
                log4jParamters_tPostgresqlInput_1.append(" | ");
                    log4jParamters_tPostgresqlInput_1.append("QUERY" + " = " + "\"SELECT MAX(LOAD_DATE) LOAD_DATE FROM OG_BHONE_BW.BH_BW_FINANCE_LAGTIME\"");
                log4jParamters_tPostgresqlInput_1.append(" | ");
                    log4jParamters_tPostgresqlInput_1.append("SPECIFY_DATASOURCE_ALIAS" + " = " + "false");
                log4jParamters_tPostgresqlInput_1.append(" | ");
                    log4jParamters_tPostgresqlInput_1.append("USE_SSL" + " = " + "true");
                log4jParamters_tPostgresqlInput_1.append(" | ");
                    log4jParamters_tPostgresqlInput_1.append("USE_CURSOR" + " = " + "false");
                log4jParamters_tPostgresqlInput_1.append(" | ");
                    log4jParamters_tPostgresqlInput_1.append("TRIM_ALL_COLUMN" + " = " + "false");
                log4jParamters_tPostgresqlInput_1.append(" | ");
                    log4jParamters_tPostgresqlInput_1.append("TRIM_COLUMN" + " = " + "[{TRIM="+("false")+", SCHEMA_COLUMN="+("load_date")+"}]");
                log4jParamters_tPostgresqlInput_1.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tPostgresqlInput_1 - "  + (log4jParamters_tPostgresqlInput_1) );
    		}
    	}
    	
        new BytesLimit65535_tPostgresqlInput_1().limitLog4jByte();
	
    
	
		    int nb_line_tPostgresqlInput_1 = 0;
		    java.sql.Connection conn_tPostgresqlInput_1 = null;
				String driverClass_tPostgresqlInput_1 = "org.postgresql.Driver";
			    java.lang.Class.forName(driverClass_tPostgresqlInput_1);
			   	String dbUser_tPostgresqlInput_1 = context.aws_gp_prof_Login;
			   	
        		
        		
        		
	final String decryptedPassword_tPostgresqlInput_1 = context.aws_gp_prof_Password; 
			   	
		        String dbPwd_tPostgresqlInput_1 = decryptedPassword_tPostgresqlInput_1;
		        
				
				String url_tPostgresqlInput_1 = "jdbc:postgresql://"+context.aws_gp_prof_Server+":"+context.aws_gp_prof_Port+"/"+"bhdl"+"?ssl=true&sslfactory=org.postgresql.ssl.NonValidatingFactory";
			
				
	    		log.debug("tPostgresqlInput_1 - Driver ClassName: "+driverClass_tPostgresqlInput_1+".");
			
	    		log.debug("tPostgresqlInput_1 - Connection attempt to '" + url_tPostgresqlInput_1 + "' with the username '" + dbUser_tPostgresqlInput_1 + "'.");
			
				conn_tPostgresqlInput_1 = java.sql.DriverManager.getConnection(url_tPostgresqlInput_1,dbUser_tPostgresqlInput_1,dbPwd_tPostgresqlInput_1);
	    		log.debug("tPostgresqlInput_1 - Connection to '" + url_tPostgresqlInput_1 + "' has succeeded.");
			
		        
	    		log.debug("tPostgresqlInput_1 - Connection is set auto commit to 'false'.");
			
				conn_tPostgresqlInput_1.setAutoCommit(false);
			
		    
			java.sql.Statement stmt_tPostgresqlInput_1 = conn_tPostgresqlInput_1.createStatement();

		    String dbquery_tPostgresqlInput_1 = "SELECT MAX(LOAD_DATE) LOAD_DATE FROM OG_BHONE_BW.BH_BW_FINANCE_LAGTIME";
			
                log.debug("tPostgresqlInput_1 - Executing the query: '"+dbquery_tPostgresqlInput_1+"'.");
			

                       globalMap.put("tPostgresqlInput_1_QUERY",dbquery_tPostgresqlInput_1);

		    java.sql.ResultSet rs_tPostgresqlInput_1 = null;
		try{
		    rs_tPostgresqlInput_1 = stmt_tPostgresqlInput_1.executeQuery(dbquery_tPostgresqlInput_1);
		    java.sql.ResultSetMetaData rsmd_tPostgresqlInput_1 = rs_tPostgresqlInput_1.getMetaData();
		    int colQtyInRs_tPostgresqlInput_1 = rsmd_tPostgresqlInput_1.getColumnCount();

		    String tmpContent_tPostgresqlInput_1 = null;
		    
		    
		    	log.debug("tPostgresqlInput_1 - Retrieving records from the database.");
		    
		    while (rs_tPostgresqlInput_1.next()) {
		        nb_line_tPostgresqlInput_1++;
		        
							if(colQtyInRs_tPostgresqlInput_1 < 1) {
								row12.load_date = null;
							} else {
										
			row12.load_date = routines.system.JDBCUtil.getDate(rs_tPostgresqlInput_1, 1);
		                    }
					
						log.debug("tPostgresqlInput_1 - Retrieving the record " + nb_line_tPostgresqlInput_1 + ".");
					


 



/**
 * [tPostgresqlInput_1 begin ] stop
 */
	
	/**
	 * [tPostgresqlInput_1 main ] start
	 */

	

	
	
	currentComponent="tPostgresqlInput_1";

	

 


	tos_count_tPostgresqlInput_1++;

/**
 * [tPostgresqlInput_1 main ] stop
 */

	
	/**
	 * [tSetGlobalVar_1 main ] start
	 */

	

	
	
	currentComponent="tSetGlobalVar_1";

	

			//row12
			//row12


			
				if(execStat){
					runStat.updateStatOnConnection("row12"+iterateId,1, 1);
				} 
			

		
    			if(log.isTraceEnabled()){
    				log.trace("row12 - " + (row12==null? "": row12.toLogString()));
    			}
    		

globalMap.put("load_date", row12.load_date);

 


	tos_count_tSetGlobalVar_1++;

/**
 * [tSetGlobalVar_1 main ] stop
 */



	
	/**
	 * [tPostgresqlInput_1 end ] start
	 */

	

	
	
	currentComponent="tPostgresqlInput_1";

	

	}
}finally{
	stmt_tPostgresqlInput_1.close();

	if(conn_tPostgresqlInput_1 != null && !conn_tPostgresqlInput_1.isClosed()) {
		
	    		log.debug("tPostgresqlInput_1 - Connection starting to commit.");
			
			conn_tPostgresqlInput_1.commit();
			
	    		log.debug("tPostgresqlInput_1 - Connection commit has succeeded.");
			
		
	    		log.debug("tPostgresqlInput_1 - Closing the connection to the database.");
			
			conn_tPostgresqlInput_1.close();
			
	    		log.debug("tPostgresqlInput_1 - Connection to the database closed.");
			
	}
	
}
globalMap.put("tPostgresqlInput_1_NB_LINE",nb_line_tPostgresqlInput_1);
	    		log.debug("tPostgresqlInput_1 - Retrieved records count: "+nb_line_tPostgresqlInput_1 + " .");
			
 
                if(log.isDebugEnabled())
            log.debug("tPostgresqlInput_1 - "  + ("Done.") );

ok_Hash.put("tPostgresqlInput_1", true);
end_Hash.put("tPostgresqlInput_1", System.currentTimeMillis());




/**
 * [tPostgresqlInput_1 end ] stop
 */

	
	/**
	 * [tSetGlobalVar_1 end ] start
	 */

	

	
	
	currentComponent="tSetGlobalVar_1";

	

			if(execStat){
				if(resourceMap.get("inIterateVComp") == null || !((Boolean)resourceMap.get("inIterateVComp"))){
			 		runStat.updateStatOnConnection("row12"+iterateId,2, 0); 
			 	}
			}
		
 
                if(log.isDebugEnabled())
            log.debug("tSetGlobalVar_1 - "  + ("Done.") );

ok_Hash.put("tSetGlobalVar_1", true);
end_Hash.put("tSetGlobalVar_1", System.currentTimeMillis());




/**
 * [tSetGlobalVar_1 end ] stop
 */



				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage());
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tPostgresqlInput_1 finally ] start
	 */

	

	
	
	currentComponent="tPostgresqlInput_1";

	

 



/**
 * [tPostgresqlInput_1 finally ] stop
 */

	
	/**
	 * [tSetGlobalVar_1 finally ] start
	 */

	

	
	
	currentComponent="tSetGlobalVar_1";

	

 



/**
 * [tSetGlobalVar_1 finally ] stop
 */



				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tPostgresqlInput_1_SUBPROCESS_STATE", 1);
	}
	
    public String resuming_logs_dir_path = null;
    public String resuming_checkpoint_path = null;
    public String parent_part_launcher = null;
    private String resumeEntryMethodName = null;
    private boolean globalResumeTicket = false;

    public boolean watch = false;
    // portStats is null, it means don't execute the statistics
    public Integer portStats = null;
    public int portTraces = 4334;
    public String clientHost;
    public String defaultClientHost = "localhost";
    public String contextStr = "Dev";
    public boolean isDefaultContext = true;
    public String pid = "0";
    public String rootPid = null;
    public String fatherPid = null;
    public String fatherNode = null;
    public long startTime = 0;
    public boolean isChildJob = false;
    public String log4jLevel = "";

    private boolean execStat = true;

    private ThreadLocal<java.util.Map<String, String>> threadLocal = new ThreadLocal<java.util.Map<String, String>>() {
        protected java.util.Map<String, String> initialValue() {
            java.util.Map<String,String> threadRunResultMap = new java.util.HashMap<String, String>();
            threadRunResultMap.put("errorCode", null);
            threadRunResultMap.put("status", "");
            return threadRunResultMap;
        };
    };



    private java.util.Properties context_param = new java.util.Properties();
    public java.util.Map<String, Object> parentContextMap = new java.util.HashMap<String, Object>();

    public String status= "";

    public static void main(String[] args){
        final J_X_MAN_FINANCE_LAGTIME J_X_MAN_FINANCE_LAGTIMEClass = new J_X_MAN_FINANCE_LAGTIME();

        int exitCode = J_X_MAN_FINANCE_LAGTIMEClass.runJobInTOS(args);
	        if(exitCode==0){
		        log.info("TalendJob: 'J_X_MAN_FINANCE_LAGTIME' - Done.");
	        }

        System.exit(exitCode);
    }


    public String[][] runJob(String[] args) {

        int exitCode = runJobInTOS(args);
        String[][] bufferValue = new String[][] { { Integer.toString(exitCode) } };

        return bufferValue;
    }

    public boolean hastBufferOutputComponent() {
		boolean hastBufferOutput = false;
    	
        return hastBufferOutput;
    }

    public int runJobInTOS(String[] args) {
	   	// reset status
	   	status = "";

        String lastStr = "";
        for (String arg : args) {
            if (arg.equalsIgnoreCase("--context_param")) {
                lastStr = arg;
            } else if (lastStr.equals("")) {
                evalParam(arg);
            } else {
                evalParam(lastStr + " " + arg);
                lastStr = "";
            }
        }

	        if(!"".equals(log4jLevel)){
				if("trace".equalsIgnoreCase(log4jLevel)){
					log.setLevel(org.apache.log4j.Level.TRACE);
				}else if("debug".equalsIgnoreCase(log4jLevel)){
					log.setLevel(org.apache.log4j.Level.DEBUG);
				}else if("info".equalsIgnoreCase(log4jLevel)){
					log.setLevel(org.apache.log4j.Level.INFO);
				}else if("warn".equalsIgnoreCase(log4jLevel)){
					log.setLevel(org.apache.log4j.Level.WARN);
				}else if("error".equalsIgnoreCase(log4jLevel)){
					log.setLevel(org.apache.log4j.Level.ERROR);
				}else if("fatal".equalsIgnoreCase(log4jLevel)){
					log.setLevel(org.apache.log4j.Level.FATAL);
				}else if ("off".equalsIgnoreCase(log4jLevel)){
					log.setLevel(org.apache.log4j.Level.OFF);
				}
				org.apache.log4j.Logger.getRootLogger().setLevel(log.getLevel());
    	    }
        	log.info("TalendJob: 'J_X_MAN_FINANCE_LAGTIME' - Start.");
    	

        if(clientHost == null) {
            clientHost = defaultClientHost;
        }

        if(pid == null || "0".equals(pid)) {
            pid = TalendString.getAsciiRandomString(6);
        }

        if (rootPid==null) {
            rootPid = pid;
        }
        if (fatherPid==null) {
            fatherPid = pid;
        }else{
            isChildJob = true;
        }

        if (portStats != null) {
            // portStats = -1; //for testing
            if (portStats < 0 || portStats > 65535) {
                // issue:10869, the portStats is invalid, so this client socket can't open
                System.err.println("The statistics socket port " + portStats + " is invalid.");
                execStat = false;
            }
        } else {
            execStat = false;
        }

        try {
            //call job/subjob with an existing context, like: --context=production. if without this parameter, there will use the default context instead.
            java.io.InputStream inContext = J_X_MAN_FINANCE_LAGTIME.class.getClassLoader().getResourceAsStream("og_applications/j_x_man_finance_lagtime_0_1/contexts/"+contextStr+".properties");
            if(isDefaultContext && inContext ==null) {

            } else {
                if (inContext!=null) {
                    //defaultProps is in order to keep the original context value
                    defaultProps.load(inContext);
                    inContext.close();
                    context = new ContextProperties(defaultProps);
                }else{
                    //print info and job continue to run, for case: context_param is not empty.
                    System.err.println("Could not find the context " + contextStr);
                }
            }

            if(!context_param.isEmpty()) {
                context.putAll(context_param);
            }
                context.aws_gp_prof_Login=(String) context.getProperty("aws_gp_prof_Login");
            		String pwd_aws_gp_prof_Password_value = context.getProperty("aws_gp_prof_Password");
            		context.aws_gp_prof_Password = null;
            		if(pwd_aws_gp_prof_Password_value!=null) {
            			if(context_param.containsKey("aws_gp_prof_Password")) {//no need to decrypt if it come from program argument or parent job runtime
            				context.aws_gp_prof_Password = pwd_aws_gp_prof_Password_value;
            			} else if (!pwd_aws_gp_prof_Password_value.isEmpty()) {
            				try {
            					context.aws_gp_prof_Password = routines.system.PasswordEncryptUtil.decryptPassword(pwd_aws_gp_prof_Password_value);
            					context.put("aws_gp_prof_Password",context.aws_gp_prof_Password);
            				} catch (java.lang.RuntimeException e) {
            					//do nothing
            				}
            			}
            		}
                context.aws_gp_prof_Schema=(String) context.getProperty("aws_gp_prof_Schema");
                context.aws_gp_prof_Server=(String) context.getProperty("aws_gp_prof_Server");
                context.aws_gp_prof_Database=(String) context.getProperty("aws_gp_prof_Database");
                context.aws_gp_prof_Port=(String) context.getProperty("aws_gp_prof_Port");
                context.mail=(String) context.getProperty("mail");
                context.master_job=(String) context.getProperty("master_job");
                context.TABLE=(String) context.getProperty("TABLE");
                context.Table2=(String) context.getProperty("Table2");
                context.SAP_QA1_Host=(String) context.getProperty("SAP_QA1_Host");
                context.SAP_QA1_Language=(String) context.getProperty("SAP_QA1_Language");
            		String pwd_SAP_QA1_Password_value = context.getProperty("SAP_QA1_Password");
            		context.SAP_QA1_Password = null;
            		if(pwd_SAP_QA1_Password_value!=null) {
            			if(context_param.containsKey("SAP_QA1_Password")) {//no need to decrypt if it come from program argument or parent job runtime
            				context.SAP_QA1_Password = pwd_SAP_QA1_Password_value;
            			} else if (!pwd_SAP_QA1_Password_value.isEmpty()) {
            				try {
            					context.SAP_QA1_Password = routines.system.PasswordEncryptUtil.decryptPassword(pwd_SAP_QA1_Password_value);
            					context.put("SAP_QA1_Password",context.SAP_QA1_Password);
            				} catch (java.lang.RuntimeException e) {
            					//do nothing
            				}
            			}
            		}
                context.SAP_QA1_Client=(String) context.getProperty("SAP_QA1_Client");
                context.SAP_QA1_SystemNumber=(String) context.getProperty("SAP_QA1_SystemNumber");
                context.SAP_QA1_UserName=(String) context.getProperty("SAP_QA1_UserName");
                context.api_use_z_talend_read_table=(String) context.getProperty("api_use_z_talend_read_table");
        } catch (java.io.IOException ie) {
            System.err.println("Could not load context "+contextStr);
            ie.printStackTrace();
        }


        // get context value from parent directly
        if (parentContextMap != null && !parentContextMap.isEmpty()) {if (parentContextMap.containsKey("aws_gp_prof_Login")) {
                context.aws_gp_prof_Login = (String) parentContextMap.get("aws_gp_prof_Login");
            }if (parentContextMap.containsKey("aws_gp_prof_Password")) {
                context.aws_gp_prof_Password = (java.lang.String) parentContextMap.get("aws_gp_prof_Password");
            }if (parentContextMap.containsKey("aws_gp_prof_Schema")) {
                context.aws_gp_prof_Schema = (String) parentContextMap.get("aws_gp_prof_Schema");
            }if (parentContextMap.containsKey("aws_gp_prof_Server")) {
                context.aws_gp_prof_Server = (String) parentContextMap.get("aws_gp_prof_Server");
            }if (parentContextMap.containsKey("aws_gp_prof_Database")) {
                context.aws_gp_prof_Database = (String) parentContextMap.get("aws_gp_prof_Database");
            }if (parentContextMap.containsKey("aws_gp_prof_Port")) {
                context.aws_gp_prof_Port = (String) parentContextMap.get("aws_gp_prof_Port");
            }if (parentContextMap.containsKey("mail")) {
                context.mail = (String) parentContextMap.get("mail");
            }if (parentContextMap.containsKey("master_job")) {
                context.master_job = (String) parentContextMap.get("master_job");
            }if (parentContextMap.containsKey("TABLE")) {
                context.TABLE = (String) parentContextMap.get("TABLE");
            }if (parentContextMap.containsKey("Table2")) {
                context.Table2 = (String) parentContextMap.get("Table2");
            }if (parentContextMap.containsKey("SAP_QA1_Host")) {
                context.SAP_QA1_Host = (String) parentContextMap.get("SAP_QA1_Host");
            }if (parentContextMap.containsKey("SAP_QA1_Language")) {
                context.SAP_QA1_Language = (String) parentContextMap.get("SAP_QA1_Language");
            }if (parentContextMap.containsKey("SAP_QA1_Password")) {
                context.SAP_QA1_Password = (java.lang.String) parentContextMap.get("SAP_QA1_Password");
            }if (parentContextMap.containsKey("SAP_QA1_Client")) {
                context.SAP_QA1_Client = (String) parentContextMap.get("SAP_QA1_Client");
            }if (parentContextMap.containsKey("SAP_QA1_SystemNumber")) {
                context.SAP_QA1_SystemNumber = (String) parentContextMap.get("SAP_QA1_SystemNumber");
            }if (parentContextMap.containsKey("SAP_QA1_UserName")) {
                context.SAP_QA1_UserName = (String) parentContextMap.get("SAP_QA1_UserName");
            }if (parentContextMap.containsKey("api_use_z_talend_read_table")) {
                context.api_use_z_talend_read_table = (String) parentContextMap.get("api_use_z_talend_read_table");
            }
        }

        //Resume: init the resumeUtil
        resumeEntryMethodName = ResumeUtil.getResumeEntryMethodName(resuming_checkpoint_path);
        resumeUtil = new ResumeUtil(resuming_logs_dir_path, isChildJob, rootPid);
        resumeUtil.initCommonInfo(pid, rootPid, fatherPid, projectName, jobName, contextStr, jobVersion);

		List<String> parametersToEncrypt = new java.util.ArrayList<String>();
			parametersToEncrypt.add("aws_gp_prof_Password");
			parametersToEncrypt.add("SAP_QA1_Password");
        //Resume: jobStart
        resumeUtil.addLog("JOB_STARTED", "JOB:" + jobName, parent_part_launcher, Thread.currentThread().getId() + "", "","","","",resumeUtil.convertToJsonText(context,parametersToEncrypt));

if(execStat) {
    try {
        runStat.openSocket(!isChildJob);
        runStat.setAllPID(rootPid, fatherPid, pid, jobName);
        runStat.startThreadStat(clientHost, portStats);
        runStat.updateStatOnJob(RunStat.JOBSTART, fatherNode);
    } catch (java.io.IOException ioException) {
        ioException.printStackTrace();
    }
}



	
	    java.util.concurrent.ConcurrentHashMap<Object, Object> concurrentHashMap = new java.util.concurrent.ConcurrentHashMap<Object, Object>();
	    globalMap.put("concurrentHashMap", concurrentHashMap);
	

    long startUsedMemory = Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory();
    long endUsedMemory = 0;
    long end = 0;

    startTime = System.currentTimeMillis();


this.globalResumeTicket = true;//to run tPreJob

try {
errorCode = null;tPrejob_1Process(globalMap);
if(!"failure".equals(status)) { status = "end"; }
}catch (TalendException e_tPrejob_1) {
globalMap.put("tPrejob_1_SUBPROCESS_STATE", -1);

e_tPrejob_1.printStackTrace();

}



this.globalResumeTicket = false;//to run others jobs

try {
errorCode = null;tSAPTableInput_1Process(globalMap);
if(!"failure".equals(status)) { status = "end"; }
}catch (TalendException e_tSAPTableInput_1) {
globalMap.put("tSAPTableInput_1_SUBPROCESS_STATE", -1);

e_tSAPTableInput_1.printStackTrace();

}

this.globalResumeTicket = true;//to run tPostJob




        end = System.currentTimeMillis();

        if (watch) {
            System.out.println((end-startTime)+" milliseconds");
        }

        endUsedMemory = Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory();
        if (false) {
            System.out.println((endUsedMemory - startUsedMemory) + " bytes memory increase when running : J_X_MAN_FINANCE_LAGTIME");
        }





if (execStat) {
    runStat.updateStatOnJob(RunStat.JOBEND, fatherNode);
    runStat.stopThreadStat();
}
    int returnCode = 0;
    if(errorCode == null) {
         returnCode = status != null && status.equals("failure") ? 1 : 0;
    } else {
         returnCode = errorCode.intValue();
    }
    resumeUtil.addLog("JOB_ENDED", "JOB:" + jobName, parent_part_launcher, Thread.currentThread().getId() + "", "","" + returnCode,"","","");

    return returnCode;

  }

    // only for OSGi env
    public void destroy() {


    }




		









    private java.util.Map<String, Object> getSharedConnections4REST() {
        java.util.Map<String, Object> connections = new java.util.HashMap<String, Object>();






        return connections;
    }

    private void evalParam(String arg) {
        if (arg.startsWith("--resuming_logs_dir_path")) {
            resuming_logs_dir_path = arg.substring(25);
        } else if (arg.startsWith("--resuming_checkpoint_path")) {
            resuming_checkpoint_path = arg.substring(27);
        } else if (arg.startsWith("--parent_part_launcher")) {
            parent_part_launcher = arg.substring(23);
        } else if (arg.startsWith("--watch")) {
            watch = true;
        } else if (arg.startsWith("--stat_port=")) {
            String portStatsStr = arg.substring(12);
            if (portStatsStr != null && !portStatsStr.equals("null")) {
                portStats = Integer.parseInt(portStatsStr);
            }
        } else if (arg.startsWith("--trace_port=")) {
            portTraces = Integer.parseInt(arg.substring(13));
        } else if (arg.startsWith("--client_host=")) {
            clientHost = arg.substring(14);
        } else if (arg.startsWith("--context=")) {
            contextStr = arg.substring(10);
            isDefaultContext = false;
        } else if (arg.startsWith("--father_pid=")) {
            fatherPid = arg.substring(13);
        } else if (arg.startsWith("--root_pid=")) {
            rootPid = arg.substring(11);
        } else if (arg.startsWith("--father_node=")) {
            fatherNode = arg.substring(14);
        } else if (arg.startsWith("--pid=")) {
            pid = arg.substring(6);
        } else if (arg.startsWith("--context_param")) {
            String keyValue = arg.substring(16);
            int index = -1;
            if (keyValue != null && (index = keyValue.indexOf('=')) > -1) {
                if (fatherPid==null) {
                    context_param.put(keyValue.substring(0, index), replaceEscapeChars(keyValue.substring(index + 1)));
                } else { // the subjob won't escape the especial chars
                    context_param.put(keyValue.substring(0, index), keyValue.substring(index + 1) );
                }
            }
        }else if (arg.startsWith("--log4jLevel=")) {
            log4jLevel = arg.substring(13);
		}

    }

    private final String[][] escapeChars = {
        {"\\\\","\\"},{"\\n","\n"},{"\\'","\'"},{"\\r","\r"},
        {"\\f","\f"},{"\\b","\b"},{"\\t","\t"}
        };
    private String replaceEscapeChars (String keyValue) {

		if (keyValue == null || ("").equals(keyValue.trim())) {
			return keyValue;
		}

		StringBuilder result = new StringBuilder();
		int currIndex = 0;
		while (currIndex < keyValue.length()) {
			int index = -1;
			// judege if the left string includes escape chars
			for (String[] strArray : escapeChars) {
				index = keyValue.indexOf(strArray[0],currIndex);
				if (index>=0) {

					result.append(keyValue.substring(currIndex, index + strArray[0].length()).replace(strArray[0], strArray[1]));
					currIndex = index + strArray[0].length();
					break;
				}
			}
			// if the left string doesn't include escape chars, append the left into the result
			if (index < 0) {
				result.append(keyValue.substring(currIndex));
				currIndex = currIndex + keyValue.length();
			}
		}

		return result.toString();
    }

    public Integer getErrorCode() {
        return errorCode;
    }


    public String getStatus() {
        return status;
    }

    ResumeUtil resumeUtil = null;
}
/************************************************************************************************
 *     450673 characters generated by Talend Real-time Big Data Platform 
 *     on the November 5, 2018 8:53:21 AM CST
 ************************************************************************************************/