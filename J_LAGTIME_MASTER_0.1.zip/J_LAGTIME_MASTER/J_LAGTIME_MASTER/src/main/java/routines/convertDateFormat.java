package routines;
import java.text.SimpleDateFormat;
import java.text.ParseException;

public class convertDateFormat {

	public static String convertDateFormatGeneric(String dateString,String sourceDateFormat,String targetDateFormat)

	 {

	  SimpleDateFormat sdf_source = new SimpleDateFormat(sourceDateFormat); // Define instance of Source format

	 

	  SimpleDateFormat sdf_target = new SimpleDateFormat(targetDateFormat); // Define instance of Target format

	  

	  String var_Date = "";

	 

	  try

	  {

	   var_Date = sdf_target.format(sdf_source.parse(dateString));  

	  }

	  catch(ParseException e)

	  {

	   System.out.println("Source Format not correct");

	  }

	 

	  return var_Date;

	  

	 }
}