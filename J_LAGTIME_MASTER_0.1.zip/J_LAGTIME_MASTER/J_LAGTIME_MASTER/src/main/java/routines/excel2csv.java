package routines;
import java.io.Closeable;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.PrintStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.PrintWriter;
import java.io.Writer;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.lang.IllegalStateException;

import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.apache.poi.xssf.streaming.SXSSFWorkbook;
import org.apache.poi.ss.formula.FormulaParseException;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.FormulaEvaluator;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFFormulaEvaluator;
import com.talend.csv.CSVWriter;




/*
 * user specification: the function's comment should contain keys as follows: 1. write about the function's comment.but
 * it must be before the "{talendTypes}" key.
 * 
 * 2. {talendTypes} 's value must be talend Type, it is required . its value should be one of: String, char | Character,
 * long | Long, int | Integer, boolean | Boolean, byte | Byte, Date, double | Double, float | Float, Object, short |
 * Short
 * 
 * 3. {Category} define a category for the Function. it is required. its value is user-defined .
 * 
 * 4. {param} 's format is: {param} <type>[(<default value or closed list values>)] <name>[ : <comment>]
 * 
 * <type> 's value should be one of: string, int, list, double, object, boolean, long, char, date. <name>'s value is the
 * Function's parameter name. the {param} is optional. so if you the Function without the parameters. the {param} don't
 * added. you can have many parameters for the Function.
 * 
 * 5. {example} gives a example for the Function. it is optional.
 */
public class excel2csv {
	
    
    public static void saveCSV(String fileName,List<String[]> lines) throws IOException {
		try {
		
		java.io.Writer outFile = null;
		outFile = new java.io.BufferedWriter(new java.io.OutputStreamWriter(new java.io.FileOutputStream(fileName, false)));
		
		CSVWriter writerCsv = new CSVWriter(outFile);
		
		writerCsv.setSeparator("|".toCharArray()[0]);
		writerCsv.setLineEnd("\n");
		writerCsv.setEscapeChar("\\".toCharArray()[0]);
		writerCsv.setQuoteChar("\"".toCharArray()[0]);
		writerCsv.setQuoteStatus(CSVWriter.QuoteStatus.AUTO);
		writerCsv.writeAll(lines);
		writerCsv.close();
		
		} catch (FileNotFoundException  e) {
			System.out.println("File not found.");
			e.printStackTrace();
		}
	}
    
public static void exceltocsv(String talendPath,String sourceFilename,String sheetName,int headerRow,String outFile) {
    	
    	try {
    		
    	if (talendPath.substring(talendPath.length()-1)!="/") { talendPath=talendPath+"/"; };
    	String sourceFile=talendPath+sourceFilename;
		outFile=talendPath+outFile+".pyout";
		System.out.println("Outfile: "+outFile);
		//InputStream inputFile = new FileInputStream(sourceFile);
		
    	Workbook wb = new XSSFWorkbook(sourceFile);
   
    	Sheet sheet = wb.getSheet(sheetName);
    	if (sheet==null){
    		throw new java.lang.NullPointerException("Sheet Not Found");
    	}
    	List<String[]> lines=new ArrayList<String[]>();
    	
    	int maxwidth=0;
    	
    	for (int r = headerRow, rn = sheet.getLastRowNum() ; r <= rn ; r++) {
    	        Row row = sheet.getRow(r);
    	        
    	        //handle empty line
    	        if ( row == null ) { continue; }
    	        String[] cells=new String[row.getLastCellNum()];
    	        boolean firstCell = true;
    	        
    	        for (int c = 0, cn = row.getLastCellNum() ; c < cn ; c++) {
    	        	if (maxwidth < row.getLastCellNum()){
    	        		maxwidth = row.getLastCellNum();
    	        	}
    	            Cell cell = row.getCell(c, Row.RETURN_BLANK_AS_NULL);
    	            
    	            if ( cell != null ) {
    	            	//convert to string to avoid unknown function error
    	            	cell.setCellType(Cell.CELL_TYPE_STRING);
    	                cells[c]=cell.getStringCellValue();
    	            }
    	            firstCell = false;
    	        }
    	        
    	        lines.add(cells);
    	    }  
    	
    	fillHeader(lines,maxwidth);
	    saveCSV(outFile,lines);
    	
    	} catch (IOException e) {
    		e.printStackTrace();
    	}
    }

public static void fillHeader(List<String[]> lines,int maxwidth){
	if (lines.get(0).length<maxwidth){
    	String[] header=new String[maxwidth];
    	
    	//copying the cells from the shorter header to the full header
    	for (int j=0;j<lines.get(0).length;j++){
    		header[j]=lines.get(0)[j];
    	}
    	
    	//adding the missing header cells
    	
    	for (int i=0;i<maxwidth-lines.get(0).length;i++){
    		header[lines.get(0).length+i]="additionalcol"+i;	
    	}
    	
    	//replace the old header
    	lines.set(0, header);
    }
}

public static void exceltocsvold(String sourceFile,String sheetName,int headerRow,String outFile) {
	
	try {
	String path = new File(sourceFile).getParent();
	outFile=path+"\\"+outFile+".pyout";
	System.out.println("Outfile: "+outFile);
	XSSFWorkbook xssfwb = new XSSFWorkbook(sourceFile);
	FormulaEvaluator fe = null;
	XSSFFormulaEvaluator.evaluateAllFormulaCells(xssfwb);
	Workbook wb=xssfwb;
	
	fe = wb.getCreationHelper().createFormulaEvaluator();
	DataFormatter formatter = new DataFormatter();
	//PrintStream out = new PrintStream(new FileOutputStream(outFile+".csv"),true, "UTF-8");
	
	
	Sheet sheet = wb.getSheet(sheetName);
	if (sheet==null){
		throw new java.lang.NullPointerException("Sheet Not Found");
	}
	List<String[]> lines=new ArrayList<String[]>();
	
	int maxwidth=0;
	for (int r = headerRow, rn = sheet.getLastRowNum() ; r <= rn ; r++) {
	    	
	    	
	        Row row = sheet.getRow(r);
	        String[] cells=new String[row.getLastCellNum()];
	        
	        if ( row == null ) { continue; }
	        boolean firstCell = true;
	        for (int c = 0, cn = row.getLastCellNum() ; c < cn ; c++) {
	        	if (maxwidth < row.getLastCellNum()){
	        		maxwidth = row.getLastCellNum();
	        	}
	            Cell cell = row.getCell(c, Row.RETURN_BLANK_AS_NULL);
	            
	            if ( cell != null ) {
	                if ( fe != null ) cell = fe.evaluateInCell(cell);
	                String value = formatter.formatCellValue(cell);
	                if ( cell.getCellType() == Cell.CELL_TYPE_FORMULA ) {
	                    value = "=" + value;
	                }
	                //out.print(encodeValue(value));
	                cells[c]=value.replaceAll("\n", "\\n");
	            }
	            firstCell = false;
	        }
	        
	        lines.add(cells);
	    }    
		
		
	    if (lines.get(0).length<maxwidth){
	    	String[] header=new String[maxwidth];
	    	
	    	//copying the cells from the shorter header to the full header
	    	for (int j=0;j<lines.get(0).length;j++){
	    		header[j]=lines.get(0)[j];
	    	}
	    	
	    	//adding the missing header cells
	    	
	    	for (int i=0;i<maxwidth-lines.get(0).length;i++){
	    		header[lines.get(0).length+i]="additionalcol"+i;	
	    	}
	    	
	    	//replace the old header
	    	lines.set(0, header);
	    }
	    saveCSV(outFile,lines);
	
	} catch (IOException e) {
		e.printStackTrace();
	}
}
    
}
