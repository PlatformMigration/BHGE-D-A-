#!/bin/sh
cd `dirname $0`
ROOT_PATH=`pwd`
java -Xms256M -Xmx1024M -cp classpath.jar: og_applications.j_lagtime_master_0_1.J_LAGTIME_MASTER --context=Default "$@" 