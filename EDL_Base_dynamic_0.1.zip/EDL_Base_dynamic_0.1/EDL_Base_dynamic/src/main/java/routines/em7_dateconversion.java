package routines;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.TimeZone;

public class em7_dateconversion {

	public static Date convertToDateFromUnix(String unixFormat,String timezone){
		

		final DateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss Z");
		java.util.Date dateObj = null;
		String aRevisedDate=null;
		try {
			if(unixFormat!=null && unixFormat.trim().length()>0)
			{
			String dataStr = sdf.format(new Date((Long.parseLong(unixFormat)*1000L)));
		//	System.out.println("Local : " + dataStr);
			dateObj = sdf.parse(dataStr);
			sdf.setTimeZone(TimeZone.getTimeZone(timezone));   // This line converts the given date into UTC time zone
			sdf.format(dateObj);
			aRevisedDate = sdf.format(dateObj);
			
			//System.out.println(aRevisedDate);
			
			}
		} catch (ParseException e) {
			
			e.printStackTrace();			
		} catch (Exception e){
			e.printStackTrace();
		}
		return dateObj;
	//	return aRevisedDate;
	} 
}
