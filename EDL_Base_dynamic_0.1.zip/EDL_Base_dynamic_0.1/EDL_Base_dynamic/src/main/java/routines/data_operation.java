package routines;

/*
 * user specification: the function's comment should contain keys as follows: 1. write about the function's comment.but
 * it must be before the "{talendTypes}" key.
 * 
 * 2. {talendTypes} 's value must be talend Type, it is required . its value should be one of: String, char | Character,
 * long | Long, int | Integer, boolean | Boolean, byte | Byte, Date, double | Double, float | Float, Object, short |
 * Short
 * 
 * 3. {Category} define a category for the Function. it is required. its value is user-defined .
 * 
 * 4. {param} 's format is: {param} <type>[(<default value or closed list values>)] <name>[ : <comment>]
 * 
 * <type> 's value should be one of: string, int, list, double, object, boolean, long, char, date. <name>'s value is the
 * Function's parameter name. the {param} is optional. so if you the Function without the parameters. the {param} don't
 * added. you can have many parameters for the Function.
 * 
 * 5. {example} gives a example for the Function. it is optional.
 */
public class data_operation {
	 /**
     * round:  return rounded numeric value.
     * 
     * 
     * {talendTypes} String|Integer
     * 
     * {Category} User Defined
     * 
     * {param} String(-12.876543) a :String
     * 
     * {param} int(2) b :integer
     * 
     * {example} round("-12.876543",2) # -12.88.
     */
     
	 public static Double round(String a, int b) {
	      // double  i = 12.876543;
	     // Double d = 2.23694;
		// if (a == null || a.isEmpty()|| a.equals("") || a.equals("null") || a.trim().equals(""))
		// {      d = null;
		//        return d;
		//    }
	       double value = Double.parseDouble(a);
	       double val = Math.pow(10, b);
	       double   d = (double)(Math.round(value*val))/val;
	       return d;
		 
	    }
	 
	 /**
	     * round:  return rounded numeric value.
	     * 
	     * 
	     * {talendTypes} Double|Integer
	     * 
	     * {Category} User Defined
	     * 
	     * {param} Double(12.876543) a :Double
	     * 
	     * {param} int(2) b :integer
	     * 
	     * {example} round("12.876543",2) # -12.88.
	     */
	     
		 public static double round(double a, int b) {
		      // double  i = 12.876543;
		     // Double d = 2.23694;
			// if (a == null || a.isEmpty()|| a.equals("") || a.equals("null") || a.trim().equals(""))
			// {      d = null;
			//        return d;
			//    }
		       double val = Math.pow(10, b);
		       double   d = (double)(Math.round(a*val))/val;
		       return d;
			 
		    }
		    /**
		     * round:  return rounded numeric value.
		     * 
		     * 
		     * {talendTypes} String
		     * 
		     * {Category} User Defined
		     * 
		     * {param} String(-12.876543) a :String
		     * 
		     * 
		     * {example} round("-12.876543") # -13
		     */
		 public static long round(String a) {
			     double value = Double.parseDouble(a);
		           return Math.round(value);
			 
		    }
		    /**
		     * round:  return rounded long value.
		     * 
		     * 
		     * {talendTypes} Numeric
		     * 
		     * {Category} User Defined
		     * 
		     * {param} Double(-12.876543) a :Numeric
		     * 
		     * 
		     * {example} round("-12.876543") # -13
		     */
		 
		 public static long round(double a) {
		          return Math.round(a);
		 
	    }
		 
		    /**
		     * chkNumeric:  return Boolean.
		     * 
		     * 
		     * {talendTypes} boolean | Boolean
		     * 
		     * {Category} User Defined
		     * 
		     * {param} String("-12.876543") a :String
		     * 
		     * 
		     * {example} chkNumeric("-12.876543") # True
		     */
		 
		 
		 public static boolean chkNumeric(String s) {
			 if (s == null || s.isEmpty()) {
			        return false;
			    } 
			    return s.matches("[-+]?\\d*\\.?\\d+");
			}

}
