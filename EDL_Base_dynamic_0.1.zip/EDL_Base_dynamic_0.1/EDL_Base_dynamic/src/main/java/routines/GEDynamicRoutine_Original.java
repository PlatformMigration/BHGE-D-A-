
package routines; 

import java.io.IOException; 
import java.io.Writer; 
import java.sql.Date; 

import routines.system.DBMSConstants; 
import routines.system.Dynamic; 
import routines.system.DynamicMetadata; 
import routines.system.FormatterUtils; 

import java.text.DateFormat; 
import java.text.SimpleDateFormat; 
import java.util.TimeZone; 

public class GEDynamicRoutine_Original { 

/** 
* returnDataAsString: return the Dynamic Data as a String with the expected Delimiter 
* {talendTypes} String 
* {Category} User Defined 
* {param} string("world") input: The string need to be printed. 
* {example} helloExemple("world") # hello world !. 
*/ 
	
	public static String returnDataAsString(Dynamic column, String delimiter) throws IOException {
	       
	       StringBuilder sb = new StringBuilder();
	       if (column != null) {
	         for (int i = 0; i < column.getColumnCount(); i++) {
	           if(column.getColumnValue(i)==null) {
	             sb.append("\\N");
	           } else {
	             if(column.getColumnMetadata(i).getType().equals("id_byte[]")){
	                 byte[] bytearray = (byte[])column.getColumnValue(i);
	                 for(int bi = 0; bi < bytearray.length; bi++){
	                     sb.append("\\\\");
	                          String octalValue = Integer.toOctalString(bytearray[bi]);
	                          if(octalValue.length() > 3) {
	                              sb.append(Integer.parseInt(octalValue.substring(8,11))-400);
	                          } else {
	                              if(octalValue.length() ==  2) sb.append("0");
	                              if(octalValue.length() ==  1) sb.append("00");
	                              sb.append(octalValue);
	                          }
	                 }
	             } /*else if(column.getColumnMetadata(i).getType().equals("id_byte")){
	                 sb.append("\\\\");
	                 sb.append(Integer.toOctalString(Byte.parseByte(column.getColumnValue(i).toString())).substring(0,1) );
	                 sb.append(Integer.toOctalString(Byte.parseByte(column.getColumnValue(i).toString())).substring(9,11) );
	             } */
	              else
	               sb.append(String.valueOf(column.getColumnValue(i)).replace("\\","\\\\").replace(delimiter,"\\" + delimiter));
	           }
	           if(i!=column.getColumnCount()-1){
	             sb.append(delimiter);
	           }
	         }
	         return sb.toString().replaceAll("\\\n", "\\\\012").replaceAll("\\u0000","").replaceAll("\\x00", "").replaceAll("\\\r","\\\\015");
	         }
	       else
	        return null;


	   }	
	
public static String returnDataAsString_old(Dynamic data, String delimiter) { 

StringBuilder sb = new StringBuilder(); 
if (data != null) { 
try { 
routines.system.DynamicUtils 
.writeValuesToStringBuilder(data, 
sb, 
delimiter); 
} catch (IOException e) { 
e.printStackTrace(); 
} 
} 
return sb.toString().replace("\\","\\\\").replaceAll("\\\n", "").replaceAll("null","").replaceAll("\\u0000","") 
.replaceAll("\\x00", "").replaceAll("\\\r","") 
.replace("\u000B","\\\u000B"); 
} 

public static String returnHeaderAsString(Dynamic column, String delimiter) throws IOException { 
StringBuilder sb = new StringBuilder(); 
if (column != null) { 
for (int i = 0; i < column.getColumnCount(); i++) { 
sb.append(column.getColumnMetadata(i).getDbName()); 
if(i!=column.getColumnCount()-1){ 
sb.append(delimiter); 
} 
} 
return sb.toString().replaceAll("\\\n", "\\\\012").replaceAll("\\u0000","").replaceAll("\\x00", "").replaceAll("\\\r","\\\\015"); 
} 
else 
return null; 
} 


/** 
* returnDataAsString: return the Dynamic Data as a String with the expected Delimiter 
* {talendTypes} String 
* {Category} User Defined 
* {param} string("world") input: The string need to be printed. 
* {example} helloExemple("world") # hello world !. 
*/ 
public static String returnDataAsString_0314(Dynamic column, String delimiter) throws IOException { 

StringBuilder sb = new StringBuilder(); 
if (column != null) { 
for (int i = 0; i < column.getColumnCount(); i++) { 
DynamicMetadata metadata = column.getColumnMetadata(i); 
if ("id_Date".equals(metadata.getType()) ) { 
sb.append(FormatterUtils.format_Date((java.util.Date) column.getColumnValue(i),"MM-dd-YYYY")); 
} else { 
sb.append(String.valueOf(column.getColumnValue(i)).replace(delimiter,"\\" + delimiter) ); 
} 
if (i != (column.getColumnCount() - 1)) 
sb.append(delimiter); 
} 
return sb.toString().replace("\\","\\\\").replaceAll("\\\n", "").replaceAll("null","") 
.replaceAll("\\u0000","").replaceAll("\\x00", "").replaceAll("\\\r","").replace("\u000B","\\\u000B"); 
} 
else 
return null; 
} 

public static String returnColumnNames(Dynamic column, String delimiter) throws IOException { 

StringBuilder sb = new StringBuilder(); 
if (column != null) { 
for (int i = 0; i < column.getColumnCount(); i++) { 
DynamicMetadata metadata = column.getColumnMetadata(i); 

sb.append(String.valueOf(metadata.getName())); 
sb.append(" "); 
sb.append(String.valueOf(metadata.getType())); 

if (i != (column.getColumnCount() - 1)) 
sb.append(delimiter); 
} 
return sb.toString().replace("\\","\\\\").replaceAll("\\\n", "").replaceAll("null","").replaceAll("\\u0000","").replaceAll("\\x00", "").replaceAll("\\\r","").replace("\u000B","\\\u000B"); 
} 
else 
return null; 
} 


public static String getCurrentDate() { 

java.util.Date date = new java.util.Date(); 

DateFormat formatter = new SimpleDateFormat("MMddyyyy_HHmmss z"); 
formatter.setTimeZone(TimeZone.getTimeZone("UTC")); 

// Prints the date in the CET timezone 
//System.out.println(formatter.format(date)); 
return formatter.format(date); 
} 

public static java.util.Date getCurrentDateforEST() throws Exception{ 

java.util.Date date = new java.util.Date(); 

DateFormat formatter = new SimpleDateFormat("MMddyyyy_HHmmss z"); 
formatter.setTimeZone(TimeZone.getTimeZone("UTC")); 
SimpleDateFormat format = new SimpleDateFormat("MMddyyyy_HHmmss z"); 
// Prints the date in the CET timezone 
//System.out.println(formatter.format(date)); 
java.util.Date d =format.parse(formatter.format(date)); 
return d; 
} 


} 
