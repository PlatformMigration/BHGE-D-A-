package routines;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class BuildQuery {

    public static String  test_query(String fn) throws IOException {
     String filePath=new String("C:\\Project Folder\\Yuan Files\\Data1\\"+fn);
     BufferedReader in = new BufferedReader(new FileReader(filePath));
     String str;
     String fileName=filePath.substring((filePath.lastIndexOf('\\')+1), filePath.lastIndexOf('.'));
     
     while ((str = in.readLine()) != null) {
       break;
     }
        String Col[]=str.split("\\t");

        StringBuilder sb = new StringBuilder("create table "+ fileName+"(");
     for(int i = 0 ; i< Col.length  ; i++){
      sb.append(Col[i]);
      sb.append(" ");
      sb.append("varchar(100)");
      sb.append(",");
     }
     sb.delete(sb.lastIndexOf(","),sb.lastIndexOf(",")+1 );
     sb.append("); ");
        
     BufferedWriter out = new BufferedWriter(new FileWriter("C:\\Project Folder\\Yuan Files\\Data2\\query.txt"));
     out.write(sb.toString());
     out.close();
     
     return sb.toString() ;
          
    }
    
    public static void main(String[] args) throws IOException {
        
      }
}


