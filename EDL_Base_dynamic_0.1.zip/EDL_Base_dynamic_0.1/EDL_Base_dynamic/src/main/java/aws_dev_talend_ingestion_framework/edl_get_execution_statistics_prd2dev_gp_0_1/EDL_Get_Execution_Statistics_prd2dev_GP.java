
package aws_dev_talend_ingestion_framework.edl_get_execution_statistics_prd2dev_gp_0_1;

import routines.DataOperation;
import routines.TalendDataGenerator;
import routines.DataQuality;
import routines.Relational;
import routines.Mathematical;
import routines.DataQualityDependencies;
import routines.SQLike;
import routines.Numeric;
import routines.TalendString;
import routines.DQTechnical;
import routines.StringHandling;
import routines.TalendDate;
import routines.DataMasking;
import routines.DqStringHandling;
import routines.system.*;
import routines.system.api.*;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.math.BigDecimal;
import java.io.ByteArrayOutputStream;
import java.io.ByteArrayInputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.ObjectOutputStream;
import java.io.ObjectInputStream;
import java.io.IOException;
import java.util.Comparator;
 




	//the import part of tJava_1
	//import java.util.List;

	//the import part of tJavaRow_4
	//import java.util.List;

	//the import part of tJavaRow_1
	//import java.util.List;


@SuppressWarnings("unused")

/**
 * Job: EDL_Get_Execution_Statistics_prd2dev_GP Purpose: EDL_Get_Execution_Statistics_prd2dev_GP<br>
 * Description: Sends out a mail based on the v_talend_full_statistics table data. <br>
 * @author Talend, admin
 * @version 6.3.1.20161216_1026
 * @status 
 */
public class EDL_Get_Execution_Statistics_prd2dev_GP implements TalendJob {
	static {System.setProperty("TalendJob.log", "EDL_Get_Execution_Statistics_prd2dev_GP.log");}
	private static org.apache.log4j.Logger log = org.apache.log4j.Logger.getLogger(EDL_Get_Execution_Statistics_prd2dev_GP.class);



	public final Object obj = new Object();

	// for transmiting parameters purpose
	private Object valueObject = null;

	public Object getValueObject() {
		return this.valueObject;
	}

	public void setValueObject(Object valueObject) {
		this.valueObject = valueObject;
	}
	
	private final static String defaultCharset = java.nio.charset.Charset.defaultCharset().name();

	
	private final static String utf8Charset = "UTF-8";

	// create and load default properties
	private java.util.Properties defaultProps = new java.util.Properties();
	// create application properties with default
	public class ContextProperties extends java.util.Properties {

		private static final long serialVersionUID = 1L;

		public ContextProperties(java.util.Properties properties){
			super(properties);
		}
		public ContextProperties(){
			super();
		}

		public void synchronizeContext(){
			
			if(RUN_ID != null){
				
					this.setProperty("RUN_ID", RUN_ID.toString());
				
			}
			
			if(mail_bcc != null){
				
					this.setProperty("mail_bcc", mail_bcc.toString());
				
			}
			
			if(mail_body_text != null){
				
					this.setProperty("mail_body_text", mail_body_text.toString());
				
			}
			
			if(mail_cc != null){
				
					this.setProperty("mail_cc", mail_cc.toString());
				
			}
			
			if(GP_SOURCE_NAME != null){
				
					this.setProperty("GP_SOURCE_NAME", GP_SOURCE_NAME.toString());
				
			}
			
			if(PUBLIC != null){
				
					this.setProperty("PUBLIC", PUBLIC.toString());
				
			}
			
			if(mail_to_public != null){
				
					this.setProperty("mail_to_public", mail_to_public.toString());
				
			}
			
			if(JOB_LABEL_NAME != null){
				
					this.setProperty("JOB_LABEL_NAME", JOB_LABEL_NAME.toString());
				
			}
			
			if(mail_from != null){
				
					this.setProperty("mail_from", mail_from.toString());
				
			}
			
			if(mail_sender_name != null){
				
					this.setProperty("mail_sender_name", mail_sender_name.toString());
				
			}
			
			if(MAIL_TO != null){
				
					this.setProperty("MAIL_TO", MAIL_TO.toString());
				
			}
			
			if(SOURCE_DATABASE != null){
				
					this.setProperty("SOURCE_DATABASE", SOURCE_DATABASE.toString());
				
			}
			
			if(SOURCE_HOST != null){
				
					this.setProperty("SOURCE_HOST", SOURCE_HOST.toString());
				
			}
			
			if(SOURCE_PASSWORD != null){
				
					this.setProperty("SOURCE_PASSWORD", SOURCE_PASSWORD.toString());
				
			}
			
			if(SOURCE_PORT != null){
				
					this.setProperty("SOURCE_PORT", SOURCE_PORT.toString());
				
			}
			
			if(SOURCE_USER != null){
				
					this.setProperty("SOURCE_USER", SOURCE_USER.toString());
				
			}
			
			if(smtp != null){
				
					this.setProperty("smtp", smtp.toString());
				
			}
			
			if(smtp_port != null){
				
					this.setProperty("smtp_port", smtp_port.toString());
				
			}
			
			if(SOURCING_Database != null){
				
					this.setProperty("SOURCING_Database", SOURCING_Database.toString());
				
			}
			
			if(SOURCING_Login != null){
				
					this.setProperty("SOURCING_Login", SOURCING_Login.toString());
				
			}
			
			if(SOURCING_Password != null){
				
					this.setProperty("SOURCING_Password", SOURCING_Password.toString());
				
			}
			
			if(SOURCING_Port != null){
				
					this.setProperty("SOURCING_Port", SOURCING_Port.toString());
				
			}
			
			if(SOURCING_Schema != null){
				
					this.setProperty("SOURCING_Schema", SOURCING_Schema.toString());
				
			}
			
			if(SOURCING_Server != null){
				
					this.setProperty("SOURCING_Server", SOURCING_Server.toString());
				
			}
			
		}

public Integer RUN_ID;
public Integer getRUN_ID(){
	return this.RUN_ID;
}
public String mail_bcc;
public String getMail_bcc(){
	return this.mail_bcc;
}
public String mail_body_text;
public String getMail_body_text(){
	return this.mail_body_text;
}
public String mail_cc;
public String getMail_cc(){
	return this.mail_cc;
}
public String GP_SOURCE_NAME;
public String getGP_SOURCE_NAME(){
	return this.GP_SOURCE_NAME;
}
public String PUBLIC;
public String getPUBLIC(){
	return this.PUBLIC;
}
public String mail_to_public;
public String getMail_to_public(){
	return this.mail_to_public;
}
public String JOB_LABEL_NAME;
public String getJOB_LABEL_NAME(){
	return this.JOB_LABEL_NAME;
}
public String mail_from;
public String getMail_from(){
	return this.mail_from;
}
public String mail_sender_name;
public String getMail_sender_name(){
	return this.mail_sender_name;
}
public String MAIL_TO;
public String getMAIL_TO(){
	return this.MAIL_TO;
}
public String SOURCE_DATABASE;
public String getSOURCE_DATABASE(){
	return this.SOURCE_DATABASE;
}
public String SOURCE_HOST;
public String getSOURCE_HOST(){
	return this.SOURCE_HOST;
}
public java.lang.String SOURCE_PASSWORD;
public java.lang.String getSOURCE_PASSWORD(){
	return this.SOURCE_PASSWORD;
}
public Integer SOURCE_PORT;
public Integer getSOURCE_PORT(){
	return this.SOURCE_PORT;
}
public String SOURCE_USER;
public String getSOURCE_USER(){
	return this.SOURCE_USER;
}
public String smtp;
public String getSmtp(){
	return this.smtp;
}
public Integer smtp_port;
public Integer getSmtp_port(){
	return this.smtp_port;
}
public String SOURCING_Database;
public String getSOURCING_Database(){
	return this.SOURCING_Database;
}
public String SOURCING_Login;
public String getSOURCING_Login(){
	return this.SOURCING_Login;
}
public java.lang.String SOURCING_Password;
public java.lang.String getSOURCING_Password(){
	return this.SOURCING_Password;
}
public String SOURCING_Port;
public String getSOURCING_Port(){
	return this.SOURCING_Port;
}
public String SOURCING_Schema;
public String getSOURCING_Schema(){
	return this.SOURCING_Schema;
}
public String SOURCING_Server;
public String getSOURCING_Server(){
	return this.SOURCING_Server;
}
	}
	private ContextProperties context = new ContextProperties();
	public ContextProperties getContext() {
		return this.context;
	}
	private final String jobVersion = "0.1";
	private final String jobName = "EDL_Get_Execution_Statistics_prd2dev_GP";
	private final String projectName = "AWS_DEV_TALEND_INGESTION_FRAMEWORK";
	public Integer errorCode = null;
	private String currentComponent = "";
	
		private final java.util.Map<String, Object> globalMap = new java.util.HashMap<String, Object>();
        private final static java.util.Map<String, Object> junitGlobalMap = new java.util.HashMap<String, Object>();
	
		private final java.util.Map<String, Long> start_Hash = new java.util.HashMap<String, Long>();
		private final java.util.Map<String, Long> end_Hash = new java.util.HashMap<String, Long>();
		private final java.util.Map<String, Boolean> ok_Hash = new java.util.HashMap<String, Boolean>();
		public  final java.util.List<String[]> globalBuffer = new java.util.ArrayList<String[]>();
	

private RunStat runStat = new RunStat();

	// OSGi DataSource
	private final static String KEY_DB_DATASOURCES = "KEY_DB_DATASOURCES";

	public void setDataSources(java.util.Map<String, javax.sql.DataSource> dataSources) {
		java.util.Map<String, routines.system.TalendDataSource> talendDataSources = new java.util.HashMap<String, routines.system.TalendDataSource>();
		for (java.util.Map.Entry<String, javax.sql.DataSource> dataSourceEntry : dataSources.entrySet()) {
			talendDataSources.put(dataSourceEntry.getKey(), new routines.system.TalendDataSource(dataSourceEntry.getValue()));
		}
		globalMap.put(KEY_DB_DATASOURCES, talendDataSources);
	}

	LogCatcherUtils talendLogs_LOGS = new LogCatcherUtils();
	StatCatcherUtils talendStats_STATS = new StatCatcherUtils("_9eFYoMRCEeWiTLZH818aYA", "0.1");
	MetterCatcherUtils talendMeter_METTER = new MetterCatcherUtils("_9eFYoMRCEeWiTLZH818aYA", "0.1");

private final java.io.ByteArrayOutputStream baos = new java.io.ByteArrayOutputStream();
private final java.io.PrintStream errorMessagePS = new java.io.PrintStream(new java.io.BufferedOutputStream(baos));

public String getExceptionStackTrace() {
	if ("failure".equals(this.getStatus())) {
		errorMessagePS.flush();
		return baos.toString();
	}
	return null;
}

private Exception exception;

public Exception getException() {
	if ("failure".equals(this.getStatus())) {
		return this.exception;
	}
	return null;
}

private class TalendException extends Exception {

	private static final long serialVersionUID = 1L;

	private java.util.Map<String, Object> globalMap = null;
	private Exception e = null;
	private String currentComponent = null;
	private String virtualComponentName = null;
	
	public void setVirtualComponentName (String virtualComponentName){
		this.virtualComponentName = virtualComponentName;
	}

	private TalendException(Exception e, String errorComponent, final java.util.Map<String, Object> globalMap) {
		this.currentComponent= errorComponent;
		this.globalMap = globalMap;
		this.e = e;
	}

	public Exception getException() {
		return this.e;
	}

	public String getCurrentComponent() {
		return this.currentComponent;
	}

	
    public String getExceptionCauseMessage(Exception e){
        Throwable cause = e;
        String message = null;
        int i = 10;
        while (null != cause && 0 < i--) {
            message = cause.getMessage();
            if (null == message) {
                cause = cause.getCause();
            } else {
                break;          
            }
        }
        if (null == message) {
            message = e.getClass().getName();
        }   
        return message;
    }

	@Override
	public void printStackTrace() {
		if (!(e instanceof TalendException || e instanceof TDieException)) {
			if(virtualComponentName!=null && currentComponent.indexOf(virtualComponentName+"_")==0){
				globalMap.put(virtualComponentName+"_ERROR_MESSAGE",getExceptionCauseMessage(e));
			}
			 globalMap.put(currentComponent+"_ERROR_MESSAGE",getExceptionCauseMessage(e));
			System.err.println("Exception in component " + currentComponent);
		}
		if (!(e instanceof TDieException)) {
			if(e instanceof TalendException){
				e.printStackTrace();
			} else {
				e.printStackTrace();
				e.printStackTrace(errorMessagePS);
				EDL_Get_Execution_Statistics_prd2dev_GP.this.exception = e;
			}
		}
		if (!(e instanceof TalendException)) {
		try {
			for (java.lang.reflect.Method m : this.getClass().getEnclosingClass().getMethods()) {
				if (m.getName().compareTo(currentComponent + "_error") == 0) {
					m.invoke(EDL_Get_Execution_Statistics_prd2dev_GP.this, new Object[] { e , currentComponent, globalMap});
					break;
				}
			}

			if(!(e instanceof TDieException)){
				talendLogs_LOGS.addMessage("Java Exception", currentComponent, 6, e.getClass().getName() + ":" + e.getMessage(), 1);
				talendLogs_LOGSProcess(globalMap);
			}
				} catch (TalendException e) {
					// do nothing
				
		} catch (Exception e) {
			this.e.printStackTrace();
		}
		}
	}
}

			public void tSendMail_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tSendMail_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tSetGlobalVar_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tSetGlobalVar_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tGreenplumConnection_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tGreenplumConnection_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tJava_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tJava_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tGreenplumInput_2_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tGreenplumInput_2_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tJavaRow_4_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tGreenplumInput_2_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tJavaRow_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tGreenplumInput_2_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tGreenplumClose_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tGreenplumClose_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tSendMail_2_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tSendMail_2_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tXMLMap_1_TXMLMAP_OUT_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
							tXMLMap_1_TXMLMAP_IN_error(exception, errorComponent, globalMap);
						
						}
					
			public void tXMLMap_1_TXMLMAP_IN_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tGreenplumInput_2_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void talendLogs_LOGS_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
							talendLogs_CONSOLE_error(exception, errorComponent, globalMap);
						
						}
					
			public void talendLogs_CONSOLE_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					talendLogs_LOGS_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void talendStats_STATS_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
							talendStats_CONSOLE_error(exception, errorComponent, globalMap);
						
						}
					
			public void talendStats_CONSOLE_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					talendStats_STATS_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void talendMeter_METTER_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
							talendMeter_CONSOLE_error(exception, errorComponent, globalMap);
						
						}
					
			public void talendMeter_CONSOLE_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					talendMeter_METTER_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tSendMail_1_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tSetGlobalVar_1_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tGreenplumConnection_1_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tJava_1_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tGreenplumInput_2_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tGreenplumClose_1_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tSendMail_2_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void talendLogs_LOGS_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void talendStats_STATS_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void talendMeter_METTER_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			








public void tSendMail_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tSendMail_1_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;





	
	/**
	 * [tSendMail_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tSendMail_1", false);
		start_Hash.put("tSendMail_1", System.currentTimeMillis());
		
	
	currentComponent="tSendMail_1";

	
		int tos_count_tSendMail_1 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tSendMail_1 - "  + ("Start to work.") );
    	class BytesLimit65535_tSendMail_1{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tSendMail_1 = new StringBuilder();
            log4jParamters_tSendMail_1.append("Parameters:");
                    log4jParamters_tSendMail_1.append("TO" + " = " + "context.MAIL_TO");
                log4jParamters_tSendMail_1.append(" | ");
                    log4jParamters_tSendMail_1.append("FROM" + " = " + "context.mail_from");
                log4jParamters_tSendMail_1.append(" | ");
                    log4jParamters_tSendMail_1.append("NEED_PERSONAL_NAME" + " = " + "true");
                log4jParamters_tSendMail_1.append(" | ");
                    log4jParamters_tSendMail_1.append("PERSONAL_NAME" + " = " + "context.mail_sender_name");
                log4jParamters_tSendMail_1.append(" | ");
                    log4jParamters_tSendMail_1.append("CC" + " = " + "context.mail_cc");
                log4jParamters_tSendMail_1.append(" | ");
                    log4jParamters_tSendMail_1.append("BCC" + " = " + "context.mail_bcc");
                log4jParamters_tSendMail_1.append(" | ");
                    log4jParamters_tSendMail_1.append("SUBJECT" + " = " + "globalMap.get(\"mailSubject\") +\"  \" + ((String)globalMap.get(\"status\"))");
                log4jParamters_tSendMail_1.append(" | ");
                    log4jParamters_tSendMail_1.append("MESSAGE" + " = " + "\"<font color=\\\"#1E4191\\\" face=\\\"GE Inspira\\\">Dear Colleagues,</font >  <br /><br />  <font color=\\\"#1E4191\\\" face=\\\"GE Inspira\\\">\"+context.mail_body_text+\"</font >  <br />  \" +  globalMap.get(\"mailTable\") + \"  <br />  <font color=\\\"#1E4191\\\" face=\\\"GE Inspira\\\">  Thank you & Kind Regards, <br />  <strong>\"+ context.mail_sender_name +\"</strong>   </font >  .\"");
                log4jParamters_tSendMail_1.append(" | ");
                    log4jParamters_tSendMail_1.append("CHECK_ATTACHMENT" + " = " + "false");
                log4jParamters_tSendMail_1.append(" | ");
                    log4jParamters_tSendMail_1.append("ATTACHMENTS" + " = " + "[]");
                log4jParamters_tSendMail_1.append(" | ");
                    log4jParamters_tSendMail_1.append("HEADERS" + " = " + "[]");
                log4jParamters_tSendMail_1.append(" | ");
                    log4jParamters_tSendMail_1.append("SMTP_HOST" + " = " + "context.smtp");
                log4jParamters_tSendMail_1.append(" | ");
                    log4jParamters_tSendMail_1.append("SMTP_PORT" + " = " + "25");
                log4jParamters_tSendMail_1.append(" | ");
                    log4jParamters_tSendMail_1.append("SSL" + " = " + "false");
                log4jParamters_tSendMail_1.append(" | ");
                    log4jParamters_tSendMail_1.append("STARTTLS" + " = " + "false");
                log4jParamters_tSendMail_1.append(" | ");
                    log4jParamters_tSendMail_1.append("IMPORTANCE" + " = " + "Low");
                log4jParamters_tSendMail_1.append(" | ");
                    log4jParamters_tSendMail_1.append("NEED_AUTH" + " = " + "false");
                log4jParamters_tSendMail_1.append(" | ");
                    log4jParamters_tSendMail_1.append("DIE_ON_ERROR" + " = " + "false");
                log4jParamters_tSendMail_1.append(" | ");
                    log4jParamters_tSendMail_1.append("TEXT_SUBTYPE" + " = " + "html");
                log4jParamters_tSendMail_1.append(" | ");
                    log4jParamters_tSendMail_1.append("ENCODING" + " = " + "\"ISO-8859-15\"");
                log4jParamters_tSendMail_1.append(" | ");
                    log4jParamters_tSendMail_1.append("SET_LOCALHOST" + " = " + "false");
                log4jParamters_tSendMail_1.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tSendMail_1 - "  + (log4jParamters_tSendMail_1) );
    		}
    	}
    	
        new BytesLimit65535_tSendMail_1().limitLog4jByte();

 



/**
 * [tSendMail_1 begin ] stop
 */
	
	/**
	 * [tSendMail_1 main ] start
	 */

	

	
	
	currentComponent="tSendMail_1";

	

 

	String smtpHost_tSendMail_1 = context.smtp;
        String smtpPort_tSendMail_1 = "25";
	String from_tSendMail_1 = (context.mail_from);
    String to_tSendMail_1 = (context.MAIL_TO).replace(";",",");
    String cc_tSendMail_1 = ((context.mail_cc)==null || "".equals(context.mail_cc))?null:(context.mail_cc).replace(";",",");
    String bcc_tSendMail_1 = ((context.mail_bcc)==null || "".equals(context.mail_bcc))?null:(context.mail_bcc).replace(";",",");
    String subject_tSendMail_1 = (globalMap.get("mailSubject") +"  " + ((String)globalMap.get("status")));
    
	java.util.List<java.util.Map<String, String>> headers_tSendMail_1 = new java.util.ArrayList<java.util.Map<String,String>>();
	java.util.List<String> attachments_tSendMail_1 = new java.util.ArrayList<String>();
	java.util.List<String> contentTransferEncoding_tSendMail_1 = new java.util.ArrayList<String>();

	String message_tSendMail_1 = (("<font color=\"#1E4191\" face=\"GE Inspira\">Dear Colleagues,</font >\n<br /><br />\n<font color=\"#1E4191\" face=\"GE Inspira\">"+context.mail_body_text+"</font >\n<br />\n" +  globalMap.get("mailTable") + "\n<br />\n<font color=\"#1E4191\" face=\"GE Inspira\">\nThank you & Kind Regards, <br />\n<strong>"+ context.mail_sender_name +"</strong>\n </font >\n.") == null || "".equals("<font color=\"#1E4191\" face=\"GE Inspira\">Dear Colleagues,</font >\n<br /><br />\n<font color=\"#1E4191\" face=\"GE Inspira\">"+context.mail_body_text+"</font >\n<br />\n" +  globalMap.get("mailTable") + "\n<br />\n<font color=\"#1E4191\" face=\"GE Inspira\">\nThank you & Kind Regards, <br />\n<strong>"+ context.mail_sender_name +"</strong>\n </font >\n.")) ? "\"\"" : ("<font color=\"#1E4191\" face=\"GE Inspira\">Dear Colleagues,</font >\n<br /><br />\n<font color=\"#1E4191\" face=\"GE Inspira\">"+context.mail_body_text+"</font >\n<br />\n" +  globalMap.get("mailTable") + "\n<br />\n<font color=\"#1E4191\" face=\"GE Inspira\">\nThank you & Kind Regards, <br />\n<strong>"+ context.mail_sender_name +"</strong>\n </font >\n.") ;
	java.util.Properties props_tSendMail_1 = System.getProperties();     
	props_tSendMail_1.put("mail.smtp.host", smtpHost_tSendMail_1);
	props_tSendMail_1.put("mail.smtp.port", smtpPort_tSendMail_1);
		props_tSendMail_1.put("mail.mime.encodefilename", "true");     
	try {
		
			log.info("tSendMail_1 - Connection attempt to '" + smtpHost_tSendMail_1 +"'.");
		
		  
			props_tSendMail_1.put("mail.smtp.auth", "false");
			javax.mail.Session session_tSendMail_1 = javax.mail.Session.getInstance(props_tSendMail_1, null);    
		
		
			log.info("tSendMail_1 - Connection to '" + smtpHost_tSendMail_1 + "' has succeeded.");
		
		javax.mail.Message msg_tSendMail_1 = new javax.mail.internet.MimeMessage(session_tSendMail_1);
		msg_tSendMail_1.setFrom(new javax.mail.internet.InternetAddress(from_tSendMail_1, context.mail_sender_name));
		msg_tSendMail_1.setRecipients(javax.mail.Message.RecipientType.TO,javax.mail.internet.InternetAddress.parse(to_tSendMail_1, false));
		if (cc_tSendMail_1 != null) msg_tSendMail_1.setRecipients(javax.mail.Message.RecipientType.CC, javax.mail.internet.InternetAddress.parse(cc_tSendMail_1, false));
		if (bcc_tSendMail_1 != null) msg_tSendMail_1.setRecipients(javax.mail.Message.RecipientType.BCC, javax.mail.internet.InternetAddress.parse(bcc_tSendMail_1, false));
		msg_tSendMail_1.setSubject(subject_tSendMail_1);

		for (int i_tSendMail_1 = 0; i_tSendMail_1 < headers_tSendMail_1.size(); i_tSendMail_1++) {
			java.util.Map<String, String> header_tSendMail_1 = headers_tSendMail_1.get(i_tSendMail_1);
			msg_tSendMail_1.setHeader(header_tSendMail_1.get("KEY"), header_tSendMail_1.get("VALUE"));    
		}  
		msg_tSendMail_1.setSentDate(new Date());
		msg_tSendMail_1.setHeader("X-Priority", "5"); //High->1 Normal->3 Low->5
		javax.mail.Multipart mp_tSendMail_1 = new javax.mail.internet.MimeMultipart();
		javax.mail.internet.MimeBodyPart mbpText_tSendMail_1 = new javax.mail.internet.MimeBodyPart();
		mbpText_tSendMail_1.setText(message_tSendMail_1,"ISO-8859-15", "html");
		mp_tSendMail_1.addBodyPart(mbpText_tSendMail_1);
  
		javax.mail.internet.MimeBodyPart mbpFile_tSendMail_1 = null;

		for (int i_tSendMail_1 = 0; i_tSendMail_1 < attachments_tSendMail_1.size(); i_tSendMail_1++){
			String filename_tSendMail_1 = attachments_tSendMail_1.get(i_tSendMail_1);
			javax.activation.FileDataSource fds_tSendMail_1 = null;
			java.io.File file_tSendMail_1 = new java.io.File(filename_tSendMail_1);
			
				if (!file_tSendMail_1.exists()){
					continue;
				}
			
    		if (file_tSendMail_1.isDirectory()){
				java.io.File[] subFiles_tSendMail_1 = file_tSendMail_1.listFiles();
				for(java.io.File subFile_tSendMail_1 : subFiles_tSendMail_1){
					if (subFile_tSendMail_1.isFile()){
						fds_tSendMail_1 = new javax.activation.FileDataSource(subFile_tSendMail_1.getAbsolutePath());
						mbpFile_tSendMail_1 = new javax.mail.internet.MimeBodyPart();
						mbpFile_tSendMail_1.setDataHandler(new javax.activation.DataHandler(fds_tSendMail_1));
						mbpFile_tSendMail_1.setFileName(javax.mail.internet.MimeUtility.encodeText(fds_tSendMail_1.getName()));
						if(contentTransferEncoding_tSendMail_1.get(i_tSendMail_1).equalsIgnoreCase("base64")){
							mbpFile_tSendMail_1.setHeader("Content-Transfer-Encoding", "base64");
						}
						mp_tSendMail_1.addBodyPart(mbpFile_tSendMail_1);
					}
				}
    		}else{
				mbpFile_tSendMail_1 = new javax.mail.internet.MimeBodyPart();
				fds_tSendMail_1 = new javax.activation.FileDataSource(filename_tSendMail_1);
				mbpFile_tSendMail_1.setDataHandler(new javax.activation.DataHandler(fds_tSendMail_1)); 
				mbpFile_tSendMail_1.setFileName(javax.mail.internet.MimeUtility.encodeText(fds_tSendMail_1.getName()));
				if(contentTransferEncoding_tSendMail_1.get(i_tSendMail_1).equalsIgnoreCase("base64")){
					mbpFile_tSendMail_1.setHeader("Content-Transfer-Encoding", "base64");
				}
				mp_tSendMail_1.addBodyPart(mbpFile_tSendMail_1);
			}
		}
		// -- set the content --
		msg_tSendMail_1.setContent(mp_tSendMail_1);
		// add handlers for main MIME types
		javax.activation.MailcapCommandMap mc_tSendMail_1 = ( javax.activation.MailcapCommandMap)javax.activation.CommandMap.getDefaultCommandMap();
		mc_tSendMail_1.addMailcap("text/html;; x-java-content-handler=com.sun.mail.handlers.text_html");
		mc_tSendMail_1.addMailcap("text/xml;; x-java-content-handler=com.sun.mail.handlers.text_xml");
		mc_tSendMail_1.addMailcap("text/plain;; x-java-content-handler=com.sun.mail.handlers.text_plain");
		mc_tSendMail_1.addMailcap("multipart/*;; x-java-content-handler=com.sun.mail.handlers.multipart_mixed");
		mc_tSendMail_1.addMailcap("message/rfc822;; x-java-content-handler=com.sun.mail.handlers.message_rfc822");
		javax.activation.CommandMap.setDefaultCommandMap(mc_tSendMail_1);
		// -- Send the message --
		javax.mail.Transport.send(msg_tSendMail_1);
	} catch(java.lang.Exception e){
  		
			
				log.error("tSendMail_1 - " + e.toString());
			
  			System.err.println(e.toString());
		
	}finally{
		props_tSendMail_1.remove("mail.smtp.host");
		props_tSendMail_1.remove("mail.smtp.port");
		
		props_tSendMail_1.remove("mail.mime.encodefilename");
		
		props_tSendMail_1.remove("mail.smtp.auth");     
	}

 


	tos_count_tSendMail_1++;

/**
 * [tSendMail_1 main ] stop
 */
	
	/**
	 * [tSendMail_1 end ] start
	 */

	

	
	
	currentComponent="tSendMail_1";

	

 
                if(log.isDebugEnabled())
            log.debug("tSendMail_1 - "  + ("Done.") );

ok_Hash.put("tSendMail_1", true);
end_Hash.put("tSendMail_1", System.currentTimeMillis());




/**
 * [tSendMail_1 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage());
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tSendMail_1 finally ] start
	 */

	

	
	
	currentComponent="tSendMail_1";

	

 



/**
 * [tSendMail_1 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tSendMail_1_SUBPROCESS_STATE", 1);
	}
	

public void tSetGlobalVar_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tSetGlobalVar_1_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tSetGlobalVar_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tSetGlobalVar_1", false);
		start_Hash.put("tSetGlobalVar_1", System.currentTimeMillis());
		
	
	currentComponent="tSetGlobalVar_1";

	
		int tos_count_tSetGlobalVar_1 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tSetGlobalVar_1 - "  + ("Start to work.") );
    	class BytesLimit65535_tSetGlobalVar_1{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tSetGlobalVar_1 = new StringBuilder();
            log4jParamters_tSetGlobalVar_1.append("Parameters:");
                    log4jParamters_tSetGlobalVar_1.append("VARIABLES" + " = " + "[{VALUE="+("\"low\"")+", KEY="+("\"importance\"")+"}, {VALUE="+("\"success\"")+", KEY="+("\"status\"")+"}, {VALUE="+("context.JOB_LABEL_NAME")+", KEY="+("\"mailSubject\"")+"}]");
                log4jParamters_tSetGlobalVar_1.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tSetGlobalVar_1 - "  + (log4jParamters_tSetGlobalVar_1) );
    		}
    	}
    	
        new BytesLimit65535_tSetGlobalVar_1().limitLog4jByte();

 



/**
 * [tSetGlobalVar_1 begin ] stop
 */
	
	/**
	 * [tSetGlobalVar_1 main ] start
	 */

	

	
	
	currentComponent="tSetGlobalVar_1";

	

globalMap.put("importance", "low");
globalMap.put("status", "success");
globalMap.put("mailSubject", context.JOB_LABEL_NAME);

 


	tos_count_tSetGlobalVar_1++;

/**
 * [tSetGlobalVar_1 main ] stop
 */
	
	/**
	 * [tSetGlobalVar_1 end ] start
	 */

	

	
	
	currentComponent="tSetGlobalVar_1";

	

 
                if(log.isDebugEnabled())
            log.debug("tSetGlobalVar_1 - "  + ("Done.") );

ok_Hash.put("tSetGlobalVar_1", true);
end_Hash.put("tSetGlobalVar_1", System.currentTimeMillis());




/**
 * [tSetGlobalVar_1 end ] stop
 */
				}//end the resume

				
				    			if(resumeEntryMethodName == null || globalResumeTicket){
				    				resumeUtil.addLog("CHECKPOINT", "CONNECTION:SUBJOB_OK:tSetGlobalVar_1:OnSubjobOk", "", Thread.currentThread().getId() + "", "", "", "", "", "");
								}	    				    			
					    	
								if(execStat){    	
									runStat.updateStatOnConnection("OnSubjobOk3", 0, "ok");
								} 
							
							tGreenplumConnection_1Process(globalMap); 
						



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage());
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tSetGlobalVar_1 finally ] start
	 */

	

	
	
	currentComponent="tSetGlobalVar_1";

	

 



/**
 * [tSetGlobalVar_1 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tSetGlobalVar_1_SUBPROCESS_STATE", 1);
	}
	

public void tGreenplumConnection_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tGreenplumConnection_1_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tGreenplumConnection_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tGreenplumConnection_1", false);
		start_Hash.put("tGreenplumConnection_1", System.currentTimeMillis());
		
	
	currentComponent="tGreenplumConnection_1";

	
		int tos_count_tGreenplumConnection_1 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tGreenplumConnection_1 - "  + ("Start to work.") );
    	class BytesLimit65535_tGreenplumConnection_1{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tGreenplumConnection_1 = new StringBuilder();
            log4jParamters_tGreenplumConnection_1.append("Parameters:");
                    log4jParamters_tGreenplumConnection_1.append("HOST" + " = " + "context.SOURCE_HOST");
                log4jParamters_tGreenplumConnection_1.append(" | ");
                    log4jParamters_tGreenplumConnection_1.append("PORT" + " = " + "context.SOURCE_PORT");
                log4jParamters_tGreenplumConnection_1.append(" | ");
                    log4jParamters_tGreenplumConnection_1.append("DBNAME" + " = " + "context.SOURCE_DATABASE");
                log4jParamters_tGreenplumConnection_1.append(" | ");
                    log4jParamters_tGreenplumConnection_1.append("SCHEMA_DB" + " = " + "context.SOURCING_Schema");
                log4jParamters_tGreenplumConnection_1.append(" | ");
                    log4jParamters_tGreenplumConnection_1.append("USER" + " = " + "context.SOURCE_USER");
                log4jParamters_tGreenplumConnection_1.append(" | ");
                    log4jParamters_tGreenplumConnection_1.append("PASS" + " = " + String.valueOf(routines.system.PasswordEncryptUtil.encryptPassword(context.SOURCE_PASSWORD)).substring(0, 4) + "...");     
                log4jParamters_tGreenplumConnection_1.append(" | ");
                    log4jParamters_tGreenplumConnection_1.append("USE_SHARED_CONNECTION" + " = " + "false");
                log4jParamters_tGreenplumConnection_1.append(" | ");
                    log4jParamters_tGreenplumConnection_1.append("USE_SSL" + " = " + "true");
                log4jParamters_tGreenplumConnection_1.append(" | ");
                    log4jParamters_tGreenplumConnection_1.append("AUTO_COMMIT" + " = " + "false");
                log4jParamters_tGreenplumConnection_1.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tGreenplumConnection_1 - "  + (log4jParamters_tGreenplumConnection_1) );
    		}
    	}
    	
        new BytesLimit65535_tGreenplumConnection_1().limitLog4jByte();
	

	
				String url_tGreenplumConnection_1 = "jdbc:postgresql://"+context.SOURCE_HOST+":"+context.SOURCE_PORT+"/"+context.SOURCE_DATABASE+"?ssl=true&sslfactory=org.postgresql.ssl.NonValidatingFactory";

	String dbUser_tGreenplumConnection_1 = context.SOURCE_USER;
	
	
		
	final String decryptedPassword_tGreenplumConnection_1 = context.SOURCE_PASSWORD; 
		String dbPwd_tGreenplumConnection_1 = decryptedPassword_tGreenplumConnection_1;
	

	java.sql.Connection conn_tGreenplumConnection_1 = null;
	
		
			String driverClass_tGreenplumConnection_1 = "org.postgresql.Driver";
			java.lang.Class.forName(driverClass_tGreenplumConnection_1);
		
	    		log.debug("tGreenplumConnection_1 - Driver ClassName: "+driverClass_tGreenplumConnection_1+".");
			
	    		log.debug("tGreenplumConnection_1 - Connection attempt to '" + url_tGreenplumConnection_1 + "' with the username '" + dbUser_tGreenplumConnection_1 + "'.");
			
		conn_tGreenplumConnection_1 = java.sql.DriverManager.getConnection(url_tGreenplumConnection_1,dbUser_tGreenplumConnection_1,dbPwd_tGreenplumConnection_1);
	    		log.debug("tGreenplumConnection_1 - Connection to '" + url_tGreenplumConnection_1 + "' has succeeded.");
			

		globalMap.put("conn_tGreenplumConnection_1", conn_tGreenplumConnection_1);
	if (null != conn_tGreenplumConnection_1) {
		
			log.debug("tGreenplumConnection_1 - Connection is set auto commit to 'false'.");
			conn_tGreenplumConnection_1.setAutoCommit(false);
	}

	globalMap.put("schema_" + "tGreenplumConnection_1",context.SOURCING_Schema);

	globalMap.put("conn_" + "tGreenplumConnection_1",conn_tGreenplumConnection_1);
 



/**
 * [tGreenplumConnection_1 begin ] stop
 */
	
	/**
	 * [tGreenplumConnection_1 main ] start
	 */

	

	
	
	currentComponent="tGreenplumConnection_1";

	

 


	tos_count_tGreenplumConnection_1++;

/**
 * [tGreenplumConnection_1 main ] stop
 */
	
	/**
	 * [tGreenplumConnection_1 end ] start
	 */

	

	
	
	currentComponent="tGreenplumConnection_1";

	

 
                if(log.isDebugEnabled())
            log.debug("tGreenplumConnection_1 - "  + ("Done.") );

ok_Hash.put("tGreenplumConnection_1", true);
end_Hash.put("tGreenplumConnection_1", System.currentTimeMillis());




/**
 * [tGreenplumConnection_1 end ] stop
 */
				}//end the resume

				
				    			if(resumeEntryMethodName == null || globalResumeTicket){
				    				resumeUtil.addLog("CHECKPOINT", "CONNECTION:SUBJOB_OK:tGreenplumConnection_1:OnSubjobOk", "", Thread.currentThread().getId() + "", "", "", "", "", "");
								}	    				    			
					    	
								if(execStat){    	
									runStat.updateStatOnConnection("OnSubjobOk1", 0, "ok");
								} 
							
							tJava_1Process(globalMap); 
						



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage());
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tGreenplumConnection_1 finally ] start
	 */

	

	
	
	currentComponent="tGreenplumConnection_1";

	

 



/**
 * [tGreenplumConnection_1 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tGreenplumConnection_1_SUBPROCESS_STATE", 1);
	}
	

public void tJava_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tJava_1_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tJava_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tJava_1", false);
		start_Hash.put("tJava_1", System.currentTimeMillis());
		
	
	currentComponent="tJava_1";

	
		int tos_count_tJava_1 = 0;
		
    	class BytesLimit65535_tJava_1{
    		public void limitLog4jByte() throws Exception{
    			
    		}
    	}
    	
        new BytesLimit65535_tJava_1().limitLog4jByte();



if(((String)context.PUBLIC).equals("Y"))
{
context.MAIL_TO=context.mail_to_public + ";" + context.MAIL_TO;
}

System.out.println(context.MAIL_TO);
 



/**
 * [tJava_1 begin ] stop
 */
	
	/**
	 * [tJava_1 main ] start
	 */

	

	
	
	currentComponent="tJava_1";

	

 


	tos_count_tJava_1++;

/**
 * [tJava_1 main ] stop
 */
	
	/**
	 * [tJava_1 end ] start
	 */

	

	
	
	currentComponent="tJava_1";

	

 

ok_Hash.put("tJava_1", true);
end_Hash.put("tJava_1", System.currentTimeMillis());




/**
 * [tJava_1 end ] stop
 */
				}//end the resume

				
				    			if(resumeEntryMethodName == null || globalResumeTicket){
				    				resumeUtil.addLog("CHECKPOINT", "CONNECTION:SUBJOB_OK:tJava_1:OnSubjobOk", "", Thread.currentThread().getId() + "", "", "", "", "", "");
								}	    				    			
					    	
								if(execStat){    	
									runStat.updateStatOnConnection("OnSubjobOk5", 0, "ok");
								} 
							
							tGreenplumInput_2Process(globalMap); 
						



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage());
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tJava_1 finally ] start
	 */

	

	
	
	currentComponent="tJava_1";

	

 



/**
 * [tJava_1 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tJava_1_SUBPROCESS_STATE", 1);
	}
	


public static class copyOfmail_bodyStruct implements routines.system.IPersistableRow<copyOfmail_bodyStruct> {
    final static byte[] commonByteArrayLock_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Get_Execution_Statistics_prd2dev_GP = new byte[0];
    static byte[] commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Get_Execution_Statistics_prd2dev_GP = new byte[0];

	
			    public routines.system.Document htmlContent;

				public routines.system.Document getHtmlContent () {
					return this.htmlContent;
				}
				



    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Get_Execution_Statistics_prd2dev_GP) {

        	try {

        		int length = 0;
		
						this.htmlContent = (routines.system.Document) dis.readObject();
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		
			} catch(ClassNotFoundException eCNFE) {
				 throw new RuntimeException(eCNFE);
		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// Document
				
       			    	dos.writeObject(this.htmlContent);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("htmlContent="+String.valueOf(htmlContent));
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				if(htmlContent == null){
        					sb.append("<null>");
        				}else{
            				sb.append(htmlContent);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(copyOfmail_bodyStruct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public static class row1Struct implements routines.system.IPersistableRow<row1Struct> {
    final static byte[] commonByteArrayLock_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Get_Execution_Statistics_prd2dev_GP = new byte[0];
    static byte[] commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Get_Execution_Statistics_prd2dev_GP = new byte[0];

	
			    public String table_name;

				public String getTable_name () {
					return this.table_name;
				}
				
			    public String source_name;

				public String getSource_name () {
					return this.source_name;
				}
				
			    public String status_source2target;

				public String getStatus_source2target () {
					return this.status_source2target;
				}
				
			    public Integer source_count;

				public Integer getSource_count () {
					return this.source_count;
				}
				
			    public Integer extracted_count;

				public Integer getExtracted_count () {
					return this.extracted_count;
				}
				
			    public String target_count;

				public String getTarget_count () {
					return this.target_count;
				}
				
			    public String messages_source2target;

				public String getMessages_source2target () {
					return this.messages_source2target;
				}
				
			    public String status;

				public String getStatus () {
					return this.status;
				}
				
			    public Integer run_id;

				public Integer getRun_id () {
					return this.run_id;
				}
				
			    public String update_type;

				public String getUpdate_type () {
					return this.update_type;
				}
				



	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Get_Execution_Statistics_prd2dev_GP.length) {
				if(length < 1024 && commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Get_Execution_Statistics_prd2dev_GP.length == 0) {
   					commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Get_Execution_Statistics_prd2dev_GP = new byte[1024];
				} else {
   					commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Get_Execution_Statistics_prd2dev_GP = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Get_Execution_Statistics_prd2dev_GP, 0, length);
			strReturn = new String(commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Get_Execution_Statistics_prd2dev_GP, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
	private Integer readInteger(ObjectInputStream dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}

	private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException{
		if(intNum == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeInt(intNum);
    	}
	}

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Get_Execution_Statistics_prd2dev_GP) {

        	try {

        		int length = 0;
		
					this.table_name = readString(dis);
					
					this.source_name = readString(dis);
					
					this.status_source2target = readString(dis);
					
						this.source_count = readInteger(dis);
					
						this.extracted_count = readInteger(dis);
					
					this.target_count = readString(dis);
					
					this.messages_source2target = readString(dis);
					
					this.status = readString(dis);
					
						this.run_id = readInteger(dis);
					
					this.update_type = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// String
				
						writeString(this.table_name,dos);
					
					// String
				
						writeString(this.source_name,dos);
					
					// String
				
						writeString(this.status_source2target,dos);
					
					// Integer
				
						writeInteger(this.source_count,dos);
					
					// Integer
				
						writeInteger(this.extracted_count,dos);
					
					// String
				
						writeString(this.target_count,dos);
					
					// String
				
						writeString(this.messages_source2target,dos);
					
					// String
				
						writeString(this.status,dos);
					
					// Integer
				
						writeInteger(this.run_id,dos);
					
					// String
				
						writeString(this.update_type,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("table_name="+table_name);
		sb.append(",source_name="+source_name);
		sb.append(",status_source2target="+status_source2target);
		sb.append(",source_count="+String.valueOf(source_count));
		sb.append(",extracted_count="+String.valueOf(extracted_count));
		sb.append(",target_count="+target_count);
		sb.append(",messages_source2target="+messages_source2target);
		sb.append(",status="+status);
		sb.append(",run_id="+String.valueOf(run_id));
		sb.append(",update_type="+update_type);
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				if(table_name == null){
        					sb.append("<null>");
        				}else{
            				sb.append(table_name);
            			}
            		
        			sb.append("|");
        		
        				if(source_name == null){
        					sb.append("<null>");
        				}else{
            				sb.append(source_name);
            			}
            		
        			sb.append("|");
        		
        				if(status_source2target == null){
        					sb.append("<null>");
        				}else{
            				sb.append(status_source2target);
            			}
            		
        			sb.append("|");
        		
        				if(source_count == null){
        					sb.append("<null>");
        				}else{
            				sb.append(source_count);
            			}
            		
        			sb.append("|");
        		
        				if(extracted_count == null){
        					sb.append("<null>");
        				}else{
            				sb.append(extracted_count);
            			}
            		
        			sb.append("|");
        		
        				if(target_count == null){
        					sb.append("<null>");
        				}else{
            				sb.append(target_count);
            			}
            		
        			sb.append("|");
        		
        				if(messages_source2target == null){
        					sb.append("<null>");
        				}else{
            				sb.append(messages_source2target);
            			}
            		
        			sb.append("|");
        		
        				if(status == null){
        					sb.append("<null>");
        				}else{
            				sb.append(status);
            			}
            		
        			sb.append("|");
        		
        				if(run_id == null){
        					sb.append("<null>");
        				}else{
            				sb.append(run_id);
            			}
            		
        			sb.append("|");
        		
        				if(update_type == null){
        					sb.append("<null>");
        				}else{
            				sb.append(update_type);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(row1Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public static class row4Struct implements routines.system.IPersistableRow<row4Struct> {
    final static byte[] commonByteArrayLock_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Get_Execution_Statistics_prd2dev_GP = new byte[0];
    static byte[] commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Get_Execution_Statistics_prd2dev_GP = new byte[0];

	
			    public String table_name;

				public String getTable_name () {
					return this.table_name;
				}
				
			    public String source_name;

				public String getSource_name () {
					return this.source_name;
				}
				
			    public String status_source2target;

				public String getStatus_source2target () {
					return this.status_source2target;
				}
				
			    public Integer source_count;

				public Integer getSource_count () {
					return this.source_count;
				}
				
			    public Integer extracted_count;

				public Integer getExtracted_count () {
					return this.extracted_count;
				}
				
			    public String target_count;

				public String getTarget_count () {
					return this.target_count;
				}
				
			    public String messages_source2target;

				public String getMessages_source2target () {
					return this.messages_source2target;
				}
				
			    public String status;

				public String getStatus () {
					return this.status;
				}
				
			    public Integer run_id;

				public Integer getRun_id () {
					return this.run_id;
				}
				
			    public String update_type;

				public String getUpdate_type () {
					return this.update_type;
				}
				



	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Get_Execution_Statistics_prd2dev_GP.length) {
				if(length < 1024 && commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Get_Execution_Statistics_prd2dev_GP.length == 0) {
   					commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Get_Execution_Statistics_prd2dev_GP = new byte[1024];
				} else {
   					commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Get_Execution_Statistics_prd2dev_GP = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Get_Execution_Statistics_prd2dev_GP, 0, length);
			strReturn = new String(commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Get_Execution_Statistics_prd2dev_GP, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
	private Integer readInteger(ObjectInputStream dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}

	private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException{
		if(intNum == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeInt(intNum);
    	}
	}

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Get_Execution_Statistics_prd2dev_GP) {

        	try {

        		int length = 0;
		
					this.table_name = readString(dis);
					
					this.source_name = readString(dis);
					
					this.status_source2target = readString(dis);
					
						this.source_count = readInteger(dis);
					
						this.extracted_count = readInteger(dis);
					
					this.target_count = readString(dis);
					
					this.messages_source2target = readString(dis);
					
					this.status = readString(dis);
					
						this.run_id = readInteger(dis);
					
					this.update_type = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// String
				
						writeString(this.table_name,dos);
					
					// String
				
						writeString(this.source_name,dos);
					
					// String
				
						writeString(this.status_source2target,dos);
					
					// Integer
				
						writeInteger(this.source_count,dos);
					
					// Integer
				
						writeInteger(this.extracted_count,dos);
					
					// String
				
						writeString(this.target_count,dos);
					
					// String
				
						writeString(this.messages_source2target,dos);
					
					// String
				
						writeString(this.status,dos);
					
					// Integer
				
						writeInteger(this.run_id,dos);
					
					// String
				
						writeString(this.update_type,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("table_name="+table_name);
		sb.append(",source_name="+source_name);
		sb.append(",status_source2target="+status_source2target);
		sb.append(",source_count="+String.valueOf(source_count));
		sb.append(",extracted_count="+String.valueOf(extracted_count));
		sb.append(",target_count="+target_count);
		sb.append(",messages_source2target="+messages_source2target);
		sb.append(",status="+status);
		sb.append(",run_id="+String.valueOf(run_id));
		sb.append(",update_type="+update_type);
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				if(table_name == null){
        					sb.append("<null>");
        				}else{
            				sb.append(table_name);
            			}
            		
        			sb.append("|");
        		
        				if(source_name == null){
        					sb.append("<null>");
        				}else{
            				sb.append(source_name);
            			}
            		
        			sb.append("|");
        		
        				if(status_source2target == null){
        					sb.append("<null>");
        				}else{
            				sb.append(status_source2target);
            			}
            		
        			sb.append("|");
        		
        				if(source_count == null){
        					sb.append("<null>");
        				}else{
            				sb.append(source_count);
            			}
            		
        			sb.append("|");
        		
        				if(extracted_count == null){
        					sb.append("<null>");
        				}else{
            				sb.append(extracted_count);
            			}
            		
        			sb.append("|");
        		
        				if(target_count == null){
        					sb.append("<null>");
        				}else{
            				sb.append(target_count);
            			}
            		
        			sb.append("|");
        		
        				if(messages_source2target == null){
        					sb.append("<null>");
        				}else{
            				sb.append(messages_source2target);
            			}
            		
        			sb.append("|");
        		
        				if(status == null){
        					sb.append("<null>");
        				}else{
            				sb.append(status);
            			}
            		
        			sb.append("|");
        		
        				if(run_id == null){
        					sb.append("<null>");
        				}else{
            				sb.append(run_id);
            			}
            		
        			sb.append("|");
        		
        				if(update_type == null){
        					sb.append("<null>");
        				}else{
            				sb.append(update_type);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(row4Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}
public void tGreenplumInput_2Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tGreenplumInput_2_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
		String currentVirtualComponent = null;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;



		row4Struct row4 = new row4Struct();
row1Struct row1 = new row1Struct();
copyOfmail_bodyStruct copyOfmail_body = new copyOfmail_bodyStruct();





	
	/**
	 * [tXMLMap_1_TXMLMAP_OUT begin ] start
	 */

	

	
		
		ok_Hash.put("tXMLMap_1_TXMLMAP_OUT", false);
		start_Hash.put("tXMLMap_1_TXMLMAP_OUT", System.currentTimeMillis());
		
	
		currentVirtualComponent = "tXMLMap_1";
	
	currentComponent="tXMLMap_1_TXMLMAP_OUT";

	
			if (execStat) {
				if(resourceMap.get("inIterateVComp") == null){
					
						runStat.updateStatOnConnection("row1" + iterateId, 0, 0);
					
				}
			} 

		
		int tos_count_tXMLMap_1_TXMLMAP_OUT = 0;
		
                if(log.isDebugEnabled())
            log.debug("tXMLMap_1_TXMLMAP_OUT - "  + ("Start to work.") );
    	class BytesLimit65535_tXMLMap_1_TXMLMAP_OUT{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tXMLMap_1_TXMLMAP_OUT = new StringBuilder();
            log4jParamters_tXMLMap_1_TXMLMAP_OUT.append("Parameters:");
                    log4jParamters_tXMLMap_1_TXMLMAP_OUT.append("KEEP_ORDER_FOR_DOCUMENT" + " = " + "false");
                log4jParamters_tXMLMap_1_TXMLMAP_OUT.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tXMLMap_1_TXMLMAP_OUT - "  + (log4jParamters_tXMLMap_1_TXMLMAP_OUT) );
    		}
    	}
    	
        new BytesLimit65535_tXMLMap_1_TXMLMAP_OUT().limitLog4jByte();

	
	
//===============================input xml init part===============================
class XML_API_tXMLMap_1_TXMLMAP_OUT{
	public boolean isDefNull(org.dom4j.Node node) throws javax.xml.transform.TransformerException {
        if (node != null && node instanceof org.dom4j.Element) {
        	org.dom4j.Attribute attri = ((org.dom4j.Element)node).attribute("nil");
        	if(attri != null && ("true").equals(attri.getText())){
            	return true;
            }
        }
        return false;
    }

    public boolean isMissing(org.dom4j.Node node) throws javax.xml.transform.TransformerException {
        return node == null ? true : false;
    }

    public boolean isEmpty(org.dom4j.Node node) throws javax.xml.transform.TransformerException {
        if (node != null) {
            return node.getText().length() == 0;
        }
        return false;
    }
}
	class Var__tXMLMap_1_TXMLMAP_OUT__Struct {	String header_color;	String hfont_color;	String hfont_face;	String body_color;	String bfont_color;	String bfont_face;
	}
	Var__tXMLMap_1_TXMLMAP_OUT__Struct Var__tXMLMap_1_TXMLMAP_OUT = new Var__tXMLMap_1_TXMLMAP_OUT__Struct();
// ###############################
// # Outputs initialization
copyOfmail_bodyStruct copyOfmail_body_tmp = new copyOfmail_bodyStruct();
copyOfmail_bodyStruct copyOfmail_body_save = null;
//the aggregate variable
copyOfmail_bodyStruct copyOfmail_body_aggregate = null;
int count_copyOfmail_body_tXMLMap_1_TXMLMAP_OUT = 0;
//init the resultset for aggregate
java.util.List<Object> allOutsForAggregate_tXMLMap_1 = new java.util.ArrayList<Object>();
globalMap.put("allOutsForAggregate_tXMLMap_1",allOutsForAggregate_tXMLMap_1);
// ###############################
		int nb_line_tXMLMap_1_TXMLMAP_OUT = 0; 
	
    XML_API_tXMLMap_1_TXMLMAP_OUT xml_api_tXMLMap_1_TXMLMAP_OUT = new XML_API_tXMLMap_1_TXMLMAP_OUT();

	//the map store the previous value of aggregate columns
	java.util.Map<String,Object> aggregateCacheMap_tXMLMap_1_TXMLMAP_OUT = new java.util.HashMap<String,Object>();

class GenerateDocument_copyOfmail_body {

	java.util.Map<String,Object> valueMap = null;
	
	routines.system.DocumentGenerateOrderHelper orderHelper = new routines.system.DocumentGenerateOrderHelper(1);
	
	org.dom4j.Document doc = null;
	
	org.dom4j.Element root4Group = null;
	
	org.dom4j.io.OutputFormat format = null;
	
	java.util.List<java.util.List<String>> groupbyList = null;
	java.util.List<org.dom4j.Element> groupElementList = null;
	int order = 0;
	
	boolean isFirst = true;
	
	boolean	needRoot = true;
	
	String currentValue = null;

		org.dom4j.Element subTreeLoopParent0 = null;
		public boolean  subTreeLoop0 = false;
	
    public GenerateDocument_copyOfmail_body() {
//    	this.treeNodeAPI = treeNodeAPI;
    	
    	valueMap = new java.util.HashMap<String,Object>();
    	
    	groupbyList =  new java.util.ArrayList<java.util.List<String>>();
		groupElementList = new java.util.ArrayList<org.dom4j.Element>();
    	
    	doc = org.dom4j.DocumentHelper.createDocument();
    	format = org.dom4j.io.OutputFormat.createPrettyPrint();
    	format.setTrimText(false);
    }
    
    public org.dom4j.Document getDocument(){
    	return this.doc;
    }
    
	//We generate the TreeNode_API object only if there is a document in the main input table.
    void generateElements(boolean isInnerJoin, row1Struct row1, Var__tXMLMap_1_TXMLMAP_OUT__Struct Var
	) {
	
	
	/*if(this.treeNodeAPI==null) {
		this.treeNodeAPI = treeNodeAPI;
	}*/
	
	org.dom4j.Element subTreeRootParent = null;
// build root xml tree 
if (needRoot) {
	needRoot=false;
		org.dom4j.Element root = null;
				root = doc.addElement("table");
		subTreeRootParent = root;
		org.dom4j.Element root_0 = null;
				root_0 = root.addElement("tr");
				currentValue = null;
    			valueMap.put("root_0", Var.header_color);
    			if(valueMap.get("root_0")!=null) {
    				currentValue = FormatterUtils.format( Var.header_color,null);
    			} else {
    				currentValue = "";
    			}
				
    			routines.system.DocumentHelper.applyNamespace2Attribute(root_0,  null , "bgcolor", currentValue);
		org.dom4j.Element root_0_2 = null;
				root_0_2 = root_0.addElement("td");
		org.dom4j.Element root_0_2_3 = null;
				root_0_2_3 = root_0_2.addElement("font");
		valueMap.put("root_0_2_3","Table name");
		if(valueMap.get("root_0_2_3")!=null) {
			routines.system.NestXMLTool.setText(root_0_2_3, FormatterUtils.format("Table name",null));
		}
				currentValue = null;
    			valueMap.put("root_0_2_3", Var.hfont_color);
    			if(valueMap.get("root_0_2_3")!=null) {
    				currentValue = FormatterUtils.format( Var.hfont_color,null);
    			} else {
    				currentValue = "";
    			}
				
    			routines.system.DocumentHelper.applyNamespace2Attribute(root_0_2_3,  null , "color", currentValue);
				currentValue = null;
    			valueMap.put("root_0_2_3", Var.hfont_face);
    			if(valueMap.get("root_0_2_3")!=null) {
    				currentValue = FormatterUtils.format( Var.hfont_face,null);
    			} else {
    				currentValue = "";
    			}
				
    			routines.system.DocumentHelper.applyNamespace2Attribute(root_0_2_3,  null , "face", currentValue);
		org.dom4j.Element root_0_6 = null;
				root_0_6 = root_0.addElement("td");
		org.dom4j.Element root_0_6_7 = null;
				root_0_6_7 = root_0_6.addElement("font");
		valueMap.put("root_0_6_7","System name");
		if(valueMap.get("root_0_6_7")!=null) {
			routines.system.NestXMLTool.setText(root_0_6_7, FormatterUtils.format("System name",null));
		}
				currentValue = null;
    			valueMap.put("root_0_6_7", Var.hfont_color);
    			if(valueMap.get("root_0_6_7")!=null) {
    				currentValue = FormatterUtils.format( Var.hfont_color,null);
    			} else {
    				currentValue = "";
    			}
				
    			routines.system.DocumentHelper.applyNamespace2Attribute(root_0_6_7,  null , "color", currentValue);
				currentValue = null;
    			valueMap.put("root_0_6_7", Var.hfont_face);
    			if(valueMap.get("root_0_6_7")!=null) {
    				currentValue = FormatterUtils.format( Var.hfont_face,null);
    			} else {
    				currentValue = "";
    			}
				
    			routines.system.DocumentHelper.applyNamespace2Attribute(root_0_6_7,  null , "face", currentValue);
		org.dom4j.Element root_0_10 = null;
				root_0_10 = root_0.addElement("td");
		org.dom4j.Element root_0_10_11 = null;
				root_0_10_11 = root_0_10.addElement("font");
		valueMap.put("root_0_10_11","Prod2Dev");
		if(valueMap.get("root_0_10_11")!=null) {
			routines.system.NestXMLTool.setText(root_0_10_11, FormatterUtils.format("Prod2Dev",null));
		}
				currentValue = null;
    			valueMap.put("root_0_10_11", Var.hfont_color);
    			if(valueMap.get("root_0_10_11")!=null) {
    				currentValue = FormatterUtils.format( Var.hfont_color,null);
    			} else {
    				currentValue = "";
    			}
				
    			routines.system.DocumentHelper.applyNamespace2Attribute(root_0_10_11,  null , "color", currentValue);
				currentValue = null;
    			valueMap.put("root_0_10_11", Var.hfont_face);
    			if(valueMap.get("root_0_10_11")!=null) {
    				currentValue = FormatterUtils.format( Var.hfont_face,null);
    			} else {
    				currentValue = "";
    			}
				
    			routines.system.DocumentHelper.applyNamespace2Attribute(root_0_10_11,  null , "face", currentValue);
		org.dom4j.Element root_0_14 = null;
				root_0_14 = root_0.addElement("td");
		org.dom4j.Element root_0_14_15 = null;
				root_0_14_15 = root_0_14.addElement("font");
		valueMap.put("root_0_14_15","Prod count");
		if(valueMap.get("root_0_14_15")!=null) {
			routines.system.NestXMLTool.setText(root_0_14_15, FormatterUtils.format("Prod count",null));
		}
				currentValue = null;
    			valueMap.put("root_0_14_15", Var.hfont_color);
    			if(valueMap.get("root_0_14_15")!=null) {
    				currentValue = FormatterUtils.format( Var.hfont_color,null);
    			} else {
    				currentValue = "";
    			}
				
    			routines.system.DocumentHelper.applyNamespace2Attribute(root_0_14_15,  null , "color", currentValue);
				currentValue = null;
    			valueMap.put("root_0_14_15", Var.hfont_face);
    			if(valueMap.get("root_0_14_15")!=null) {
    				currentValue = FormatterUtils.format( Var.hfont_face,null);
    			} else {
    				currentValue = "";
    			}
				
    			routines.system.DocumentHelper.applyNamespace2Attribute(root_0_14_15,  null , "face", currentValue);
		org.dom4j.Element root_0_18 = null;
				root_0_18 = root_0.addElement("td");
		org.dom4j.Element root_0_18_19 = null;
				root_0_18_19 = root_0_18.addElement("font");
		valueMap.put("root_0_18_19","Extracted count");
		if(valueMap.get("root_0_18_19")!=null) {
			routines.system.NestXMLTool.setText(root_0_18_19, FormatterUtils.format("Extracted count",null));
		}
				currentValue = null;
    			valueMap.put("root_0_18_19", Var.hfont_color);
    			if(valueMap.get("root_0_18_19")!=null) {
    				currentValue = FormatterUtils.format( Var.hfont_color,null);
    			} else {
    				currentValue = "";
    			}
				
    			routines.system.DocumentHelper.applyNamespace2Attribute(root_0_18_19,  null , "color", currentValue);
				currentValue = null;
    			valueMap.put("root_0_18_19", Var.hfont_face);
    			if(valueMap.get("root_0_18_19")!=null) {
    				currentValue = FormatterUtils.format( Var.hfont_face,null);
    			} else {
    				currentValue = "";
    			}
				
    			routines.system.DocumentHelper.applyNamespace2Attribute(root_0_18_19,  null , "face", currentValue);
		org.dom4j.Element root_0_22 = null;
				root_0_22 = root_0.addElement("td");
		org.dom4j.Element root_0_22_23 = null;
				root_0_22_23 = root_0_22.addElement("font");
		valueMap.put("root_0_22_23","Dev count");
		if(valueMap.get("root_0_22_23")!=null) {
			routines.system.NestXMLTool.setText(root_0_22_23, FormatterUtils.format("Dev count",null));
		}
				currentValue = null;
    			valueMap.put("root_0_22_23", Var.hfont_color);
    			if(valueMap.get("root_0_22_23")!=null) {
    				currentValue = FormatterUtils.format( Var.hfont_color,null);
    			} else {
    				currentValue = "";
    			}
				
    			routines.system.DocumentHelper.applyNamespace2Attribute(root_0_22_23,  null , "color", currentValue);
				currentValue = null;
    			valueMap.put("root_0_22_23", Var.hfont_face);
    			if(valueMap.get("root_0_22_23")!=null) {
    				currentValue = FormatterUtils.format( Var.hfont_face,null);
    			} else {
    				currentValue = "";
    			}
				
    			routines.system.DocumentHelper.applyNamespace2Attribute(root_0_22_23,  null , "face", currentValue);
		org.dom4j.Element root_0_26 = null;
				root_0_26 = root_0.addElement("td");
		org.dom4j.Element root_0_26_27 = null;
				root_0_26_27 = root_0_26.addElement("font");
		valueMap.put("root_0_26_27","Prod2Dev message");
		if(valueMap.get("root_0_26_27")!=null) {
			routines.system.NestXMLTool.setText(root_0_26_27, FormatterUtils.format("Prod2Dev message",null));
		}
				currentValue = null;
    			valueMap.put("root_0_26_27", Var.hfont_color);
    			if(valueMap.get("root_0_26_27")!=null) {
    				currentValue = FormatterUtils.format( Var.hfont_color,null);
    			} else {
    				currentValue = "";
    			}
				
    			routines.system.DocumentHelper.applyNamespace2Attribute(root_0_26_27,  null , "color", currentValue);
				currentValue = null;
    			valueMap.put("root_0_26_27", Var.hfont_face);
    			if(valueMap.get("root_0_26_27")!=null) {
    				currentValue = FormatterUtils.format( Var.hfont_face,null);
    			} else {
    				currentValue = "";
    			}
				
    			routines.system.DocumentHelper.applyNamespace2Attribute(root_0_26_27,  null , "face", currentValue);
		org.dom4j.Element root_0_30 = null;
				root_0_30 = root_0.addElement("td");
		org.dom4j.Element root_0_30_31 = null;
				root_0_30_31 = root_0_30.addElement("font");
		valueMap.put("root_0_30_31","Status");
		if(valueMap.get("root_0_30_31")!=null) {
			routines.system.NestXMLTool.setText(root_0_30_31, FormatterUtils.format("Status",null));
		}
				currentValue = null;
    			valueMap.put("root_0_30_31", Var.hfont_color);
    			if(valueMap.get("root_0_30_31")!=null) {
    				currentValue = FormatterUtils.format( Var.hfont_color,null);
    			} else {
    				currentValue = "";
    			}
				
    			routines.system.DocumentHelper.applyNamespace2Attribute(root_0_30_31,  null , "color", currentValue);
				currentValue = null;
    			valueMap.put("root_0_30_31", Var.hfont_face);
    			if(valueMap.get("root_0_30_31")!=null) {
    				currentValue = FormatterUtils.format( Var.hfont_face,null);
    			} else {
    				currentValue = "";
    			}
				
    			routines.system.DocumentHelper.applyNamespace2Attribute(root_0_30_31,  null , "face", currentValue);
		org.dom4j.Element root_0_34 = null;
				root_0_34 = root_0.addElement("td");
		org.dom4j.Element root_0_34_35 = null;
				root_0_34_35 = root_0_34.addElement("font");
		valueMap.put("root_0_34_35","Run id");
		if(valueMap.get("root_0_34_35")!=null) {
			routines.system.NestXMLTool.setText(root_0_34_35, FormatterUtils.format("Run id",null));
		}
				currentValue = null;
    			valueMap.put("root_0_34_35", Var.hfont_color);
    			if(valueMap.get("root_0_34_35")!=null) {
    				currentValue = FormatterUtils.format( Var.hfont_color,null);
    			} else {
    				currentValue = "";
    			}
				
    			routines.system.DocumentHelper.applyNamespace2Attribute(root_0_34_35,  null , "color", currentValue);
				currentValue = null;
    			valueMap.put("root_0_34_35", Var.hfont_face);
    			if(valueMap.get("root_0_34_35")!=null) {
    				currentValue = FormatterUtils.format( Var.hfont_face,null);
    			} else {
    				currentValue = "";
    			}
				
    			routines.system.DocumentHelper.applyNamespace2Attribute(root_0_34_35,  null , "face", currentValue);
		org.dom4j.Element root_0_38 = null;
				root_0_38 = root_0.addElement("td");
		org.dom4j.Element root_0_38_39 = null;
				root_0_38_39 = root_0_38.addElement("font");
		valueMap.put("root_0_38_39","Update type");
		if(valueMap.get("root_0_38_39")!=null) {
			routines.system.NestXMLTool.setText(root_0_38_39, FormatterUtils.format("Update type",null));
		}
				currentValue = null;
    			valueMap.put("root_0_38_39", Var.hfont_color);
    			if(valueMap.get("root_0_38_39")!=null) {
    				currentValue = FormatterUtils.format( Var.hfont_color,null);
    			} else {
    				currentValue = "";
    			}
				
    			routines.system.DocumentHelper.applyNamespace2Attribute(root_0_38_39,  null , "color", currentValue);
				currentValue = null;
    			valueMap.put("root_0_38_39", Var.hfont_face);
    			if(valueMap.get("root_0_38_39")!=null) {
    				currentValue = FormatterUtils.format( Var.hfont_face,null);
    			} else {
    				currentValue = "";
    			}
				
    			routines.system.DocumentHelper.applyNamespace2Attribute(root_0_38_39,  null , "face", currentValue);
					subTreeLoopParent0 = root;
		root4Group = subTreeRootParent;
	}else{
		subTreeRootParent=root4Group;
	}
	/* build group xml tree */
	boolean isNewElement = false;
		isNewElement = false;
		org.dom4j.Element loop = null;
				loop = org.dom4j.DocumentHelper.createElement("tr");
				subTreeRootParent.elements().add(orderHelper.getInsertLocation(0,1),loop);
		subTreeRootParent = loop;
				currentValue = null;
    			valueMap.put("loop", Var.body_color);
    			if(valueMap.get("loop")!=null) {
    				currentValue = FormatterUtils.format( Var.body_color,null);
    			} else {
    				currentValue = "";
    			}
				
    			routines.system.DocumentHelper.applyNamespace2Attribute(loop,  null , "bgcolor", currentValue);
		org.dom4j.Element loop_43 = null;
				loop_43 = loop.addElement("td");
		org.dom4j.Element loop_43_44 = null;
				loop_43_44 = loop_43.addElement("font");
		valueMap.put("loop_43_44", row1.table_name);
		if(valueMap.get("loop_43_44")!=null) {
			routines.system.NestXMLTool.setText(loop_43_44, FormatterUtils.format( row1.table_name,null));
		}
				currentValue = null;
    			valueMap.put("loop_43_44",Var.bfont_color );
    			if(valueMap.get("loop_43_44")!=null) {
    				currentValue = FormatterUtils.format(Var.bfont_color ,null);
    			} else {
    				currentValue = "";
    			}
				
    			routines.system.DocumentHelper.applyNamespace2Attribute(loop_43_44,  null , "color", currentValue);
				currentValue = null;
    			valueMap.put("loop_43_44",Var.bfont_face);
    			if(valueMap.get("loop_43_44")!=null) {
    				currentValue = FormatterUtils.format(Var.bfont_face,null);
    			} else {
    				currentValue = "";
    			}
				
    			routines.system.DocumentHelper.applyNamespace2Attribute(loop_43_44,  null , "face", currentValue);
		org.dom4j.Element loop_47 = null;
				loop_47 = loop.addElement("td");
		org.dom4j.Element loop_47_48 = null;
				loop_47_48 = loop_47.addElement("font");
		valueMap.put("loop_47_48", row1.source_name);
		if(valueMap.get("loop_47_48")!=null) {
			routines.system.NestXMLTool.setText(loop_47_48, FormatterUtils.format( row1.source_name,null));
		}
				currentValue = null;
    			valueMap.put("loop_47_48",Var.bfont_color );
    			if(valueMap.get("loop_47_48")!=null) {
    				currentValue = FormatterUtils.format(Var.bfont_color ,null);
    			} else {
    				currentValue = "";
    			}
				
    			routines.system.DocumentHelper.applyNamespace2Attribute(loop_47_48,  null , "color", currentValue);
				currentValue = null;
    			valueMap.put("loop_47_48",Var.bfont_face);
    			if(valueMap.get("loop_47_48")!=null) {
    				currentValue = FormatterUtils.format(Var.bfont_face,null);
    			} else {
    				currentValue = "";
    			}
				
    			routines.system.DocumentHelper.applyNamespace2Attribute(loop_47_48,  null , "face", currentValue);
		org.dom4j.Element loop_51 = null;
				loop_51 = loop.addElement("td");
		org.dom4j.Element loop_51_52 = null;
				loop_51_52 = loop_51.addElement("font");
		valueMap.put("loop_51_52", row1.status_source2target);
		if(valueMap.get("loop_51_52")!=null) {
			routines.system.NestXMLTool.setText(loop_51_52, FormatterUtils.format( row1.status_source2target,null));
		}
				currentValue = null;
    			valueMap.put("loop_51_52",Var.bfont_color );
    			if(valueMap.get("loop_51_52")!=null) {
    				currentValue = FormatterUtils.format(Var.bfont_color ,null);
    			} else {
    				currentValue = "";
    			}
				
    			routines.system.DocumentHelper.applyNamespace2Attribute(loop_51_52,  null , "color", currentValue);
				currentValue = null;
    			valueMap.put("loop_51_52",Var.bfont_face);
    			if(valueMap.get("loop_51_52")!=null) {
    				currentValue = FormatterUtils.format(Var.bfont_face,null);
    			} else {
    				currentValue = "";
    			}
				
    			routines.system.DocumentHelper.applyNamespace2Attribute(loop_51_52,  null , "face", currentValue);
		org.dom4j.Element loop_55 = null;
				loop_55 = loop.addElement("td");
		org.dom4j.Element loop_55_56 = null;
				loop_55_56 = loop_55.addElement("font");
		valueMap.put("loop_55_56", row1.source_count);
		if(valueMap.get("loop_55_56")!=null) {
			routines.system.NestXMLTool.setText(loop_55_56, FormatterUtils.format( row1.source_count,null));
		}
				currentValue = null;
    			valueMap.put("loop_55_56",Var.bfont_color );
    			if(valueMap.get("loop_55_56")!=null) {
    				currentValue = FormatterUtils.format(Var.bfont_color ,null);
    			} else {
    				currentValue = "";
    			}
				
    			routines.system.DocumentHelper.applyNamespace2Attribute(loop_55_56,  null , "color", currentValue);
				currentValue = null;
    			valueMap.put("loop_55_56",Var.bfont_face);
    			if(valueMap.get("loop_55_56")!=null) {
    				currentValue = FormatterUtils.format(Var.bfont_face,null);
    			} else {
    				currentValue = "";
    			}
				
    			routines.system.DocumentHelper.applyNamespace2Attribute(loop_55_56,  null , "face", currentValue);
		org.dom4j.Element loop_59 = null;
				loop_59 = loop.addElement("td");
		org.dom4j.Element loop_59_60 = null;
				loop_59_60 = loop_59.addElement("font");
		valueMap.put("loop_59_60",row1.extracted_count );
		if(valueMap.get("loop_59_60")!=null) {
			routines.system.NestXMLTool.setText(loop_59_60, FormatterUtils.format(row1.extracted_count ,null));
		}
				currentValue = null;
    			valueMap.put("loop_59_60",Var.bfont_color );
    			if(valueMap.get("loop_59_60")!=null) {
    				currentValue = FormatterUtils.format(Var.bfont_color ,null);
    			} else {
    				currentValue = "";
    			}
				
    			routines.system.DocumentHelper.applyNamespace2Attribute(loop_59_60,  null , "color", currentValue);
				currentValue = null;
    			valueMap.put("loop_59_60",Var.bfont_face);
    			if(valueMap.get("loop_59_60")!=null) {
    				currentValue = FormatterUtils.format(Var.bfont_face,null);
    			} else {
    				currentValue = "";
    			}
				
    			routines.system.DocumentHelper.applyNamespace2Attribute(loop_59_60,  null , "face", currentValue);
		org.dom4j.Element loop_63 = null;
				loop_63 = loop.addElement("td");
		org.dom4j.Element loop_63_64 = null;
				loop_63_64 = loop_63.addElement("font");
		valueMap.put("loop_63_64",row1.target_count);
		if(valueMap.get("loop_63_64")!=null) {
			routines.system.NestXMLTool.setText(loop_63_64, FormatterUtils.format(row1.target_count,null));
		}
				currentValue = null;
    			valueMap.put("loop_63_64",Var.bfont_color );
    			if(valueMap.get("loop_63_64")!=null) {
    				currentValue = FormatterUtils.format(Var.bfont_color ,null);
    			} else {
    				currentValue = "";
    			}
				
    			routines.system.DocumentHelper.applyNamespace2Attribute(loop_63_64,  null , "color", currentValue);
				currentValue = null;
    			valueMap.put("loop_63_64",Var.bfont_face);
    			if(valueMap.get("loop_63_64")!=null) {
    				currentValue = FormatterUtils.format(Var.bfont_face,null);
    			} else {
    				currentValue = "";
    			}
				
    			routines.system.DocumentHelper.applyNamespace2Attribute(loop_63_64,  null , "face", currentValue);
		org.dom4j.Element loop_67 = null;
				loop_67 = loop.addElement("td");
		org.dom4j.Element loop_67_68 = null;
				loop_67_68 = loop_67.addElement("font");
		valueMap.put("loop_67_68",row1.messages_source2target );
		if(valueMap.get("loop_67_68")!=null) {
			routines.system.NestXMLTool.setText(loop_67_68, FormatterUtils.format(row1.messages_source2target ,null));
		}
				currentValue = null;
    			valueMap.put("loop_67_68",Var.bfont_color );
    			if(valueMap.get("loop_67_68")!=null) {
    				currentValue = FormatterUtils.format(Var.bfont_color ,null);
    			} else {
    				currentValue = "";
    			}
				
    			routines.system.DocumentHelper.applyNamespace2Attribute(loop_67_68,  null , "color", currentValue);
				currentValue = null;
    			valueMap.put("loop_67_68",Var.bfont_face);
    			if(valueMap.get("loop_67_68")!=null) {
    				currentValue = FormatterUtils.format(Var.bfont_face,null);
    			} else {
    				currentValue = "";
    			}
				
    			routines.system.DocumentHelper.applyNamespace2Attribute(loop_67_68,  null , "face", currentValue);
		org.dom4j.Element loop_71 = null;
				loop_71 = loop.addElement("td");
		org.dom4j.Element loop_71_72 = null;
				loop_71_72 = loop_71.addElement("font");
		valueMap.put("loop_71_72", row1.status);
		if(valueMap.get("loop_71_72")!=null) {
			routines.system.NestXMLTool.setText(loop_71_72, FormatterUtils.format( row1.status,null));
		}
				currentValue = null;
    			valueMap.put("loop_71_72",Var.bfont_color );
    			if(valueMap.get("loop_71_72")!=null) {
    				currentValue = FormatterUtils.format(Var.bfont_color ,null);
    			} else {
    				currentValue = "";
    			}
				
    			routines.system.DocumentHelper.applyNamespace2Attribute(loop_71_72,  null , "color", currentValue);
				currentValue = null;
    			valueMap.put("loop_71_72",Var.bfont_face);
    			if(valueMap.get("loop_71_72")!=null) {
    				currentValue = FormatterUtils.format(Var.bfont_face,null);
    			} else {
    				currentValue = "";
    			}
				
    			routines.system.DocumentHelper.applyNamespace2Attribute(loop_71_72,  null , "face", currentValue);
		org.dom4j.Element loop_75 = null;
				loop_75 = loop.addElement("td");
		org.dom4j.Element loop_75_76 = null;
				loop_75_76 = loop_75.addElement("font");
		valueMap.put("loop_75_76", row1.run_id);
		if(valueMap.get("loop_75_76")!=null) {
			routines.system.NestXMLTool.setText(loop_75_76, FormatterUtils.format( row1.run_id,null));
		}
				currentValue = null;
    			valueMap.put("loop_75_76",Var.bfont_color );
    			if(valueMap.get("loop_75_76")!=null) {
    				currentValue = FormatterUtils.format(Var.bfont_color ,null);
    			} else {
    				currentValue = "";
    			}
				
    			routines.system.DocumentHelper.applyNamespace2Attribute(loop_75_76,  null , "color", currentValue);
				currentValue = null;
    			valueMap.put("loop_75_76",Var.bfont_face);
    			if(valueMap.get("loop_75_76")!=null) {
    				currentValue = FormatterUtils.format(Var.bfont_face,null);
    			} else {
    				currentValue = "";
    			}
				
    			routines.system.DocumentHelper.applyNamespace2Attribute(loop_75_76,  null , "face", currentValue);
		org.dom4j.Element loop_79 = null;
				loop_79 = loop.addElement("td");
		org.dom4j.Element loop_79_80 = null;
				loop_79_80 = loop_79.addElement("font");
		valueMap.put("loop_79_80", row1.update_type);
		if(valueMap.get("loop_79_80")!=null) {
			routines.system.NestXMLTool.setText(loop_79_80, FormatterUtils.format( row1.update_type,null));
		}
				currentValue = null;
    			valueMap.put("loop_79_80",Var.bfont_color );
    			if(valueMap.get("loop_79_80")!=null) {
    				currentValue = FormatterUtils.format(Var.bfont_color ,null);
    			} else {
    				currentValue = "";
    			}
				
    			routines.system.DocumentHelper.applyNamespace2Attribute(loop_79_80,  null , "color", currentValue);
				currentValue = null;
    			valueMap.put("loop_79_80",Var.bfont_face);
    			if(valueMap.get("loop_79_80")!=null) {
    				currentValue = FormatterUtils.format(Var.bfont_face,null);
    			} else {
    				currentValue = "";
    			}
				
    			routines.system.DocumentHelper.applyNamespace2Attribute(loop_79_80,  null , "face", currentValue);
		}
    }

	GenerateDocument_copyOfmail_body gen_Doc_copyOfmail_body_tXMLMap_1_TXMLMAP_OUT = new GenerateDocument_copyOfmail_body();
	boolean docAlreadyInstanciate_copyOfmail_body = false;

	            
 



/**
 * [tXMLMap_1_TXMLMAP_OUT begin ] stop
 */



	
	/**
	 * [tJavaRow_4 begin ] start
	 */

	

	
		
		ok_Hash.put("tJavaRow_4", false);
		start_Hash.put("tJavaRow_4", System.currentTimeMillis());
		
	
	currentComponent="tJavaRow_4";

	
			if (execStat) {
				if(resourceMap.get("inIterateVComp") == null){
					
						runStat.updateStatOnConnection("row4" + iterateId, 0, 0);
					
				}
			} 

		
		int tos_count_tJavaRow_4 = 0;
		
    	class BytesLimit65535_tJavaRow_4{
    		public void limitLog4jByte() throws Exception{
    			
    		}
    	}
    	
        new BytesLimit65535_tJavaRow_4().limitLog4jByte();

int nb_line_tJavaRow_4 = 0;

 



/**
 * [tJavaRow_4 begin ] stop
 */



	
	/**
	 * [tGreenplumInput_2 begin ] start
	 */

	

	
		
		ok_Hash.put("tGreenplumInput_2", false);
		start_Hash.put("tGreenplumInput_2", System.currentTimeMillis());
		
	
	currentComponent="tGreenplumInput_2";

	
		int tos_count_tGreenplumInput_2 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tGreenplumInput_2 - "  + ("Start to work.") );
    	class BytesLimit65535_tGreenplumInput_2{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tGreenplumInput_2 = new StringBuilder();
            log4jParamters_tGreenplumInput_2.append("Parameters:");
                    log4jParamters_tGreenplumInput_2.append("USE_EXISTING_CONNECTION" + " = " + "true");
                log4jParamters_tGreenplumInput_2.append(" | ");
                    log4jParamters_tGreenplumInput_2.append("CONNECTION" + " = " + "tGreenplumConnection_1");
                log4jParamters_tGreenplumInput_2.append(" | ");
                    log4jParamters_tGreenplumInput_2.append("TABLE" + " = " + "\"daily_log\"");
                log4jParamters_tGreenplumInput_2.append(" | ");
                    log4jParamters_tGreenplumInput_2.append("QUERYSTORE" + " = " + "\"\"");
                log4jParamters_tGreenplumInput_2.append(" | ");
                    log4jParamters_tGreenplumInput_2.append("QUERY" + " = " + "\"select * from sbdt.edl_daily_log_prd2dev  WHERE run_id= \"+context.RUN_ID");
                log4jParamters_tGreenplumInput_2.append(" | ");
                    log4jParamters_tGreenplumInput_2.append("USE_CURSOR" + " = " + "false");
                log4jParamters_tGreenplumInput_2.append(" | ");
                    log4jParamters_tGreenplumInput_2.append("TRIM_ALL_COLUMN" + " = " + "false");
                log4jParamters_tGreenplumInput_2.append(" | ");
                    log4jParamters_tGreenplumInput_2.append("TRIM_COLUMN" + " = " + "[{TRIM="+("false")+", SCHEMA_COLUMN="+("table_name")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("source_name")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("status_source2target")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("source_count")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("extracted_count")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("target_count")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("messages_source2target")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("status")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("run_id")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("update_type")+"}]");
                log4jParamters_tGreenplumInput_2.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tGreenplumInput_2 - "  + (log4jParamters_tGreenplumInput_2) );
    		}
    	}
    	
        new BytesLimit65535_tGreenplumInput_2().limitLog4jByte();
	
    
	
		    int nb_line_tGreenplumInput_2 = 0;
		    java.sql.Connection conn_tGreenplumInput_2 = null;
		        conn_tGreenplumInput_2 = (java.sql.Connection)globalMap.get("conn_tGreenplumConnection_1");
				
				if(conn_tGreenplumInput_2 != null) {
					if(conn_tGreenplumInput_2.getMetaData() != null) {
						
						log.debug("tGreenplumInput_2 - Uses an existing connection with username '" + conn_tGreenplumInput_2.getMetaData().getUserName() + "'. Connection URL: " + conn_tGreenplumInput_2.getMetaData().getURL() + ".");
						
					}
				}
			
		    
			java.sql.Statement stmt_tGreenplumInput_2 = conn_tGreenplumInput_2.createStatement();

		    String dbquery_tGreenplumInput_2 = "select * from sbdt.edl_daily_log_prd2dev  WHERE run_id= "+context.RUN_ID;
			
                log.debug("tGreenplumInput_2 - Executing the query: '"+dbquery_tGreenplumInput_2+"'.");
			

                       globalMap.put("tGreenplumInput_2_QUERY",dbquery_tGreenplumInput_2);

		    java.sql.ResultSet rs_tGreenplumInput_2 = null;
		try{
		    rs_tGreenplumInput_2 = stmt_tGreenplumInput_2.executeQuery(dbquery_tGreenplumInput_2);
		    java.sql.ResultSetMetaData rsmd_tGreenplumInput_2 = rs_tGreenplumInput_2.getMetaData();
		    int colQtyInRs_tGreenplumInput_2 = rsmd_tGreenplumInput_2.getColumnCount();

		    String tmpContent_tGreenplumInput_2 = null;
		    
		    
		    	log.debug("tGreenplumInput_2 - Retrieving records from the database.");
		    
		    while (rs_tGreenplumInput_2.next()) {
		        nb_line_tGreenplumInput_2++;
		        
							if(colQtyInRs_tGreenplumInput_2 < 1) {
								row4.table_name = null;
							} else {
	                         		
        	row4.table_name = routines.system.JDBCUtil.getString(rs_tGreenplumInput_2, 1, false);
		                    }
							if(colQtyInRs_tGreenplumInput_2 < 2) {
								row4.source_name = null;
							} else {
	                         		
        	row4.source_name = routines.system.JDBCUtil.getString(rs_tGreenplumInput_2, 2, false);
		                    }
							if(colQtyInRs_tGreenplumInput_2 < 3) {
								row4.status_source2target = null;
							} else {
	                         		
        	row4.status_source2target = routines.system.JDBCUtil.getString(rs_tGreenplumInput_2, 3, false);
		                    }
							if(colQtyInRs_tGreenplumInput_2 < 4) {
								row4.source_count = null;
							} else {
		                          
            if(rs_tGreenplumInput_2.getObject(4) != null) {
                row4.source_count = rs_tGreenplumInput_2.getInt(4);
            } else {
                    row4.source_count = null;
            }
		                    }
							if(colQtyInRs_tGreenplumInput_2 < 5) {
								row4.extracted_count = null;
							} else {
		                          
            if(rs_tGreenplumInput_2.getObject(5) != null) {
                row4.extracted_count = rs_tGreenplumInput_2.getInt(5);
            } else {
                    row4.extracted_count = null;
            }
		                    }
							if(colQtyInRs_tGreenplumInput_2 < 6) {
								row4.target_count = null;
							} else {
	                         		
        	row4.target_count = routines.system.JDBCUtil.getString(rs_tGreenplumInput_2, 6, false);
		                    }
							if(colQtyInRs_tGreenplumInput_2 < 7) {
								row4.messages_source2target = null;
							} else {
	                         		
        	row4.messages_source2target = routines.system.JDBCUtil.getString(rs_tGreenplumInput_2, 7, false);
		                    }
							if(colQtyInRs_tGreenplumInput_2 < 8) {
								row4.status = null;
							} else {
	                         		
        	row4.status = routines.system.JDBCUtil.getString(rs_tGreenplumInput_2, 8, false);
		                    }
							if(colQtyInRs_tGreenplumInput_2 < 9) {
								row4.run_id = null;
							} else {
		                          
            if(rs_tGreenplumInput_2.getObject(9) != null) {
                row4.run_id = rs_tGreenplumInput_2.getInt(9);
            } else {
                    row4.run_id = null;
            }
		                    }
							if(colQtyInRs_tGreenplumInput_2 < 10) {
								row4.update_type = null;
							} else {
	                         		
        	row4.update_type = routines.system.JDBCUtil.getString(rs_tGreenplumInput_2, 10, false);
		                    }
					
						log.debug("tGreenplumInput_2 - Retrieving the record " + nb_line_tGreenplumInput_2 + ".");
					


 



/**
 * [tGreenplumInput_2 begin ] stop
 */
	
	/**
	 * [tGreenplumInput_2 main ] start
	 */

	

	
	
	currentComponent="tGreenplumInput_2";

	

 


	tos_count_tGreenplumInput_2++;

/**
 * [tGreenplumInput_2 main ] stop
 */

	
	/**
	 * [tJavaRow_4 main ] start
	 */

	

	
	
	currentComponent="tJavaRow_4";

	

			//row4
			//row4


			
				if(execStat){
					runStat.updateStatOnConnection("row4"+iterateId,1, 1);
				} 
			

		
    			if(log.isTraceEnabled()){
    				log.trace("row4 - " + (row4==null? "": row4.toLogString()));
    			}
    		

    //Code generated according to input schema and output schema
row1.table_name = row4.table_name;
row1.source_name = row4.source_name;
row1.status_source2target = row4.status_source2target;
row1.source_count = row4.source_count;
row1.extracted_count = row4.extracted_count;
row1.target_count = row4.target_count;
row1.messages_source2target = row4.messages_source2target;
row1.status = row4.status;
row1.run_id = row4.run_id;
row1.update_type = row4.update_type;
/*row1.source_component = row4.source_component;
row1.log_priority = row4.log_priority;
row1.log_type = row4.log_type;
row1.log_origin = row4.log_origin;
row1.log_message = row4.log_message;
row1.log_code = row4.log_code;
row1.flow_origin = row4.flow_origin;
row1.flow_label = row4.flow_label;
row1.flow_count = row4.flow_count;
row1.flow_reference = row4.flow_reference;
row1.flow_tresholds = row4.flow_tresholds;*/

if ( row4.status.equals("failure") ) {
globalMap.put("importance", "high");
globalMap.put("status", "FAILED!");
}
    nb_line_tJavaRow_4++;   

 


	tos_count_tJavaRow_4++;

/**
 * [tJavaRow_4 main ] stop
 */

	
	/**
	 * [tXMLMap_1_TXMLMAP_OUT main ] start
	 */

	

	
	
		currentVirtualComponent = "tXMLMap_1";
	
	currentComponent="tXMLMap_1_TXMLMAP_OUT";

	

			//row1
			//row1


			
				if(execStat){
					runStat.updateStatOnConnection("row1"+iterateId,1, 1);
				} 
			

		
    			if(log.isTraceEnabled()){
    				log.trace("row1 - " + (row1==null? "": row1.toLogString()));
    			}
    		

	boolean rejectedInnerJoin_tXMLMap_1_TXMLMAP_OUT = false;
	boolean rejectedDocInnerJoin_tXMLMap_1_TXMLMAP_OUT = false;
	boolean mainRowRejected_tXMLMap_1_TXMLMAP_OUT = false;
	boolean isMatchDocRowtXMLMap_1_TXMLMAP_OUT = false;
	  
	
			
   
					copyOfmail_body_tmp.htmlContent = null;
					
		
		


			
{ // start of Var scope

	// ###############################
	// # Vars tables

Var__tXMLMap_1_TXMLMAP_OUT__Struct Var = Var__tXMLMap_1_TXMLMAP_OUT;

			
Var.header_color = "#1E4191";

			
Var.hfont_color = "#FFFFFF";

			
Var.hfont_face = "GE Inspira";

			
Var.body_color = row1.status.equals("success") ? "#76B900" :
row1.status.equals("failure") ? "#EE3324" :
row1.status.equals("running") ?  "#FF6600"  : "#FAFAFA"   ;

			
Var.bfont_color = "#FFFFFF";

			
Var.bfont_face = "GE Inspira";
		// ###############################
		// # Output tables

copyOfmail_body = null;


// # Output table : 'copyOfmail_body'
count_copyOfmail_body_tXMLMap_1_TXMLMAP_OUT++;


if(!docAlreadyInstanciate_copyOfmail_body) {
docAlreadyInstanciate_copyOfmail_body = true;gen_Doc_copyOfmail_body_tXMLMap_1_TXMLMAP_OUT = new GenerateDocument_copyOfmail_body();
//init one new out struct for cache the result.
copyOfmail_body_aggregate = new copyOfmail_bodyStruct();
copyOfmail_body_aggregate.htmlContent = new routines.system.Document();
copyOfmail_body_aggregate.htmlContent.setDocument(gen_Doc_copyOfmail_body_tXMLMap_1_TXMLMAP_OUT.getDocument());

//construct the resultset
allOutsForAggregate_tXMLMap_1.add(copyOfmail_body_aggregate);
}


gen_Doc_copyOfmail_body_tXMLMap_1_TXMLMAP_OUT.generateElements(rejectedDocInnerJoin_tXMLMap_1_TXMLMAP_OUT,row1,Var);


log.debug("tXMLMap_1 - Outputting the record " + count_copyOfmail_body_tXMLMap_1_TXMLMAP_OUT + " of the output table 'copyOfmail_body'.");

// ###############################

} // end of Var scope

rejectedInnerJoin_tXMLMap_1_TXMLMAP_OUT = false;



 


	tos_count_tXMLMap_1_TXMLMAP_OUT++;

/**
 * [tXMLMap_1_TXMLMAP_OUT main ] stop
 */






	
	/**
	 * [tGreenplumInput_2 end ] start
	 */

	

	
	
	currentComponent="tGreenplumInput_2";

	

	}
}finally{
	stmt_tGreenplumInput_2.close();

}
globalMap.put("tGreenplumInput_2_NB_LINE",nb_line_tGreenplumInput_2);
	    		log.debug("tGreenplumInput_2 - Retrieved records count: "+nb_line_tGreenplumInput_2 + " .");
			

 
                if(log.isDebugEnabled())
            log.debug("tGreenplumInput_2 - "  + ("Done.") );

ok_Hash.put("tGreenplumInput_2", true);
end_Hash.put("tGreenplumInput_2", System.currentTimeMillis());




/**
 * [tGreenplumInput_2 end ] stop
 */

	
	/**
	 * [tJavaRow_4 end ] start
	 */

	

	
	
	currentComponent="tJavaRow_4";

	

globalMap.put("tJavaRow_4_NB_LINE",nb_line_tJavaRow_4);
			if(execStat){
				if(resourceMap.get("inIterateVComp") == null || !((Boolean)resourceMap.get("inIterateVComp"))){
			 		runStat.updateStatOnConnection("row4"+iterateId,2, 0); 
			 	}
			}
		
 

ok_Hash.put("tJavaRow_4", true);
end_Hash.put("tJavaRow_4", System.currentTimeMillis());




/**
 * [tJavaRow_4 end ] stop
 */

	
	/**
	 * [tXMLMap_1_TXMLMAP_OUT end ] start
	 */

	

	
	
		currentVirtualComponent = "tXMLMap_1";
	
	currentComponent="tXMLMap_1_TXMLMAP_OUT";

	
		log.debug("tXMLMap_1 - Written records count in the table 'copyOfmail_body': " + count_copyOfmail_body_tXMLMap_1_TXMLMAP_OUT + ".");



			if(execStat){
				if(resourceMap.get("inIterateVComp") == null || !((Boolean)resourceMap.get("inIterateVComp"))){
			 		runStat.updateStatOnConnection("row1"+iterateId,2, 0); 
			 	}
			}
		
 
                if(log.isDebugEnabled())
            log.debug("tXMLMap_1_TXMLMAP_OUT - "  + ("Done.") );

ok_Hash.put("tXMLMap_1_TXMLMAP_OUT", true);
end_Hash.put("tXMLMap_1_TXMLMAP_OUT", System.currentTimeMillis());




/**
 * [tXMLMap_1_TXMLMAP_OUT end ] stop
 */


	
	/**
	 * [tJavaRow_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tJavaRow_1", false);
		start_Hash.put("tJavaRow_1", System.currentTimeMillis());
		
	
	currentComponent="tJavaRow_1";

	
			if (execStat) {
				if(resourceMap.get("inIterateVComp") == null){
					
						runStat.updateStatOnConnection("copyOfmail_body" + iterateId, 0, 0);
					
				}
			} 

		
		int tos_count_tJavaRow_1 = 0;
		
    	class BytesLimit65535_tJavaRow_1{
    		public void limitLog4jByte() throws Exception{
    			
    		}
    	}
    	
        new BytesLimit65535_tJavaRow_1().limitLog4jByte();

int nb_line_tJavaRow_1 = 0;

 



/**
 * [tJavaRow_1 begin ] stop
 */



	
	/**
	 * [tXMLMap_1_TXMLMAP_IN begin ] start
	 */

	

	
		
		ok_Hash.put("tXMLMap_1_TXMLMAP_IN", false);
		start_Hash.put("tXMLMap_1_TXMLMAP_IN", System.currentTimeMillis());
		
	
		currentVirtualComponent = "tXMLMap_1";
	
	currentComponent="tXMLMap_1_TXMLMAP_IN";

	
		int tos_count_tXMLMap_1_TXMLMAP_IN = 0;
		
                if(log.isDebugEnabled())
            log.debug("tXMLMap_1_TXMLMAP_IN - "  + ("Start to work.") );
    	class BytesLimit65535_tXMLMap_1_TXMLMAP_IN{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tXMLMap_1_TXMLMAP_IN = new StringBuilder();
            log4jParamters_tXMLMap_1_TXMLMAP_IN.append("Parameters:");
                    log4jParamters_tXMLMap_1_TXMLMAP_IN.append("KEEP_ORDER_FOR_DOCUMENT" + " = " + "false");
                log4jParamters_tXMLMap_1_TXMLMAP_IN.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tXMLMap_1_TXMLMAP_IN - "  + (log4jParamters_tXMLMap_1_TXMLMAP_IN) );
    		}
    	}
    	
        new BytesLimit65535_tXMLMap_1_TXMLMAP_IN().limitLog4jByte();
java.util.List<Object> outs_tXMLMap_1 = (java.util.List<Object>)globalMap.get("allOutsForAggregate_tXMLMap_1");
for(Object  row_out_tXMLMap_1_TXMLMAP_IN : outs_tXMLMap_1) {//TD512
 



/**
 * [tXMLMap_1_TXMLMAP_IN begin ] stop
 */
	
	/**
	 * [tXMLMap_1_TXMLMAP_IN main ] start
	 */

	

	
	
		currentVirtualComponent = "tXMLMap_1";
	
	currentComponent="tXMLMap_1_TXMLMAP_IN";

	

	copyOfmail_body = null;
	if(row_out_tXMLMap_1_TXMLMAP_IN!=null && row_out_tXMLMap_1_TXMLMAP_IN instanceof copyOfmail_bodyStruct) {
		copyOfmail_body = (copyOfmail_bodyStruct)row_out_tXMLMap_1_TXMLMAP_IN;
			routines.system.NestXMLTool.generateOk(copyOfmail_body.htmlContent, false);		
	}
 


	tos_count_tXMLMap_1_TXMLMAP_IN++;

/**
 * [tXMLMap_1_TXMLMAP_IN main ] stop
 */
// Start of branch "copyOfmail_body"
if(copyOfmail_body != null) { 



	
	/**
	 * [tJavaRow_1 main ] start
	 */

	

	
	
	currentComponent="tJavaRow_1";

	

			//copyOfmail_body
			//copyOfmail_body


			
				if(execStat){
					runStat.updateStatOnConnection("copyOfmail_body"+iterateId,1, 1);
				} 
			

		
    			if(log.isTraceEnabled()){
    				log.trace("copyOfmail_body - " + (copyOfmail_body==null? "": copyOfmail_body.toLogString()));
    			}
    		

    globalMap.put("mailTable",copyOfmail_body.htmlContent);

    nb_line_tJavaRow_1++;   

 


	tos_count_tJavaRow_1++;

/**
 * [tJavaRow_1 main ] stop
 */

} // End of branch "copyOfmail_body"




	
	/**
	 * [tXMLMap_1_TXMLMAP_IN end ] start
	 */

	

	
	
		currentVirtualComponent = "tXMLMap_1";
	
	currentComponent="tXMLMap_1_TXMLMAP_IN";

	

}//TD512
 
                if(log.isDebugEnabled())
            log.debug("tXMLMap_1_TXMLMAP_IN - "  + ("Done.") );

ok_Hash.put("tXMLMap_1_TXMLMAP_IN", true);
end_Hash.put("tXMLMap_1_TXMLMAP_IN", System.currentTimeMillis());




/**
 * [tXMLMap_1_TXMLMAP_IN end ] stop
 */

	
	/**
	 * [tJavaRow_1 end ] start
	 */

	

	
	
	currentComponent="tJavaRow_1";

	

globalMap.put("tJavaRow_1_NB_LINE",nb_line_tJavaRow_1);
			if(execStat){
				if(resourceMap.get("inIterateVComp") == null || !((Boolean)resourceMap.get("inIterateVComp"))){
			 		runStat.updateStatOnConnection("copyOfmail_body"+iterateId,2, 0); 
			 	}
			}
		
 

ok_Hash.put("tJavaRow_1", true);
end_Hash.put("tJavaRow_1", System.currentTimeMillis());




/**
 * [tJavaRow_1 end ] stop
 */












				}//end the resume

				
				    			if(resumeEntryMethodName == null || globalResumeTicket){
				    				resumeUtil.addLog("CHECKPOINT", "CONNECTION:SUBJOB_OK:tGreenplumInput_2:OnSubjobOk", "", Thread.currentThread().getId() + "", "", "", "", "", "");
								}	    				    			
					    	
								if(execStat){    	
									runStat.updateStatOnConnection("OnSubjobOk4", 0, "ok");
								} 
							
							tGreenplumClose_1Process(globalMap); 
						



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage());
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
					te.setVirtualComponentName(currentVirtualComponent);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tGreenplumInput_2 finally ] start
	 */

	

	
	
	currentComponent="tGreenplumInput_2";

	

 



/**
 * [tGreenplumInput_2 finally ] stop
 */

	
	/**
	 * [tJavaRow_4 finally ] start
	 */

	

	
	
	currentComponent="tJavaRow_4";

	

 



/**
 * [tJavaRow_4 finally ] stop
 */

	
	/**
	 * [tXMLMap_1_TXMLMAP_OUT finally ] start
	 */

	

	
	
		currentVirtualComponent = "tXMLMap_1";
	
	currentComponent="tXMLMap_1_TXMLMAP_OUT";

	

 



/**
 * [tXMLMap_1_TXMLMAP_OUT finally ] stop
 */

	
	/**
	 * [tXMLMap_1_TXMLMAP_IN finally ] start
	 */

	

	
	
		currentVirtualComponent = "tXMLMap_1";
	
	currentComponent="tXMLMap_1_TXMLMAP_IN";

	

 



/**
 * [tXMLMap_1_TXMLMAP_IN finally ] stop
 */

	
	/**
	 * [tJavaRow_1 finally ] start
	 */

	

	
	
	currentComponent="tJavaRow_1";

	

 



/**
 * [tJavaRow_1 finally ] stop
 */












				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tGreenplumInput_2_SUBPROCESS_STATE", 1);
	}
	

public void tGreenplumClose_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tGreenplumClose_1_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tGreenplumClose_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tGreenplumClose_1", false);
		start_Hash.put("tGreenplumClose_1", System.currentTimeMillis());
		
	
	currentComponent="tGreenplumClose_1";

	
		int tos_count_tGreenplumClose_1 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tGreenplumClose_1 - "  + ("Start to work.") );
    	class BytesLimit65535_tGreenplumClose_1{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tGreenplumClose_1 = new StringBuilder();
            log4jParamters_tGreenplumClose_1.append("Parameters:");
                    log4jParamters_tGreenplumClose_1.append("CONNECTION" + " = " + "tGreenplumConnection_1");
                log4jParamters_tGreenplumClose_1.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tGreenplumClose_1 - "  + (log4jParamters_tGreenplumClose_1) );
    		}
    	}
    	
        new BytesLimit65535_tGreenplumClose_1().limitLog4jByte();

 



/**
 * [tGreenplumClose_1 begin ] stop
 */
	
	/**
	 * [tGreenplumClose_1 main ] start
	 */

	

	
	
	currentComponent="tGreenplumClose_1";

	



	java.sql.Connection conn_tGreenplumClose_1 = (java.sql.Connection)globalMap.get("conn_tGreenplumConnection_1");
	if(conn_tGreenplumClose_1 != null && !conn_tGreenplumClose_1.isClosed())
	{
                if(log.isDebugEnabled())
            log.debug("tGreenplumClose_1 - "  + ("Closing the connection ")  + ("conn_tGreenplumConnection_1")  + (" to the database.") );
        conn_tGreenplumClose_1.close();
                if(log.isDebugEnabled())
            log.debug("tGreenplumClose_1 - "  + ("Connection ")  + ("conn_tGreenplumConnection_1")  + (" to the database has closed.") );
	}

 


	tos_count_tGreenplumClose_1++;

/**
 * [tGreenplumClose_1 main ] stop
 */
	
	/**
	 * [tGreenplumClose_1 end ] start
	 */

	

	
	
	currentComponent="tGreenplumClose_1";

	

 
                if(log.isDebugEnabled())
            log.debug("tGreenplumClose_1 - "  + ("Done.") );

ok_Hash.put("tGreenplumClose_1", true);
end_Hash.put("tGreenplumClose_1", System.currentTimeMillis());

   			if (!((String)globalMap.get("importance")).equals("low")) {
   				
					if(execStat){   
   	 					runStat.updateStatOnConnection("failure_priority_high", 0, "true");
					}
				
    			tSendMail_2Process(globalMap);
   			}

			   
   				else{
					if(execStat){   
   	 					runStat.updateStatOnConnection("failure_priority_high", 0, "false");
					}   	 
   				}
   			if (((String)globalMap.get("importance")).equals("low")) {
   				
					if(execStat){   
   	 					runStat.updateStatOnConnection("success_priority_low", 0, "true");
					}
				
    			tSendMail_1Process(globalMap);
   			}

			   
   				else{
					if(execStat){   
   	 					runStat.updateStatOnConnection("success_priority_low", 0, "false");
					}   	 
   				}



/**
 * [tGreenplumClose_1 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage());
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tGreenplumClose_1 finally ] start
	 */

	

	
	
	currentComponent="tGreenplumClose_1";

	

 



/**
 * [tGreenplumClose_1 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tGreenplumClose_1_SUBPROCESS_STATE", 1);
	}
	

public void tSendMail_2Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tSendMail_2_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;





	
	/**
	 * [tSendMail_2 begin ] start
	 */

	

	
		
		ok_Hash.put("tSendMail_2", false);
		start_Hash.put("tSendMail_2", System.currentTimeMillis());
		
	
	currentComponent="tSendMail_2";

	
		int tos_count_tSendMail_2 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tSendMail_2 - "  + ("Start to work.") );
    	class BytesLimit65535_tSendMail_2{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tSendMail_2 = new StringBuilder();
            log4jParamters_tSendMail_2.append("Parameters:");
                    log4jParamters_tSendMail_2.append("TO" + " = " + "context.MAIL_TO");
                log4jParamters_tSendMail_2.append(" | ");
                    log4jParamters_tSendMail_2.append("FROM" + " = " + "context.mail_from");
                log4jParamters_tSendMail_2.append(" | ");
                    log4jParamters_tSendMail_2.append("NEED_PERSONAL_NAME" + " = " + "true");
                log4jParamters_tSendMail_2.append(" | ");
                    log4jParamters_tSendMail_2.append("PERSONAL_NAME" + " = " + "context.mail_sender_name");
                log4jParamters_tSendMail_2.append(" | ");
                    log4jParamters_tSendMail_2.append("CC" + " = " + "context.mail_cc");
                log4jParamters_tSendMail_2.append(" | ");
                    log4jParamters_tSendMail_2.append("BCC" + " = " + "context.mail_bcc");
                log4jParamters_tSendMail_2.append(" | ");
                    log4jParamters_tSendMail_2.append("SUBJECT" + " = " + "globalMap.get(\"mailSubject\") +\"  \" +((String)globalMap.get(\"status\"))");
                log4jParamters_tSendMail_2.append(" | ");
                    log4jParamters_tSendMail_2.append("MESSAGE" + " = " + "\"<font color=\\\"#1E4191\\\" face=\\\"GE Inspira\\\">Dear Colleagues,</font >  <br /><br />  <font color=\\\"#1E4191\\\" face=\\\"GE Inspira\\\">\"+context.mail_body_text+\"</font >  <br />  \" +  ((Document)globalMap.get(\"mailTable\")) + \"  <br />  <font color=\\\"#1E4191\\\" face=\\\"GE Inspira\\\">  Thank you & Kind Regards, <br />  <strong>\"+ context.mail_sender_name +\"</strong>   </font >  .\"");
                log4jParamters_tSendMail_2.append(" | ");
                    log4jParamters_tSendMail_2.append("CHECK_ATTACHMENT" + " = " + "false");
                log4jParamters_tSendMail_2.append(" | ");
                    log4jParamters_tSendMail_2.append("ATTACHMENTS" + " = " + "[]");
                log4jParamters_tSendMail_2.append(" | ");
                    log4jParamters_tSendMail_2.append("HEADERS" + " = " + "[]");
                log4jParamters_tSendMail_2.append(" | ");
                    log4jParamters_tSendMail_2.append("SMTP_HOST" + " = " + "context.smtp");
                log4jParamters_tSendMail_2.append(" | ");
                    log4jParamters_tSendMail_2.append("SMTP_PORT" + " = " + "25");
                log4jParamters_tSendMail_2.append(" | ");
                    log4jParamters_tSendMail_2.append("SSL" + " = " + "false");
                log4jParamters_tSendMail_2.append(" | ");
                    log4jParamters_tSendMail_2.append("STARTTLS" + " = " + "false");
                log4jParamters_tSendMail_2.append(" | ");
                    log4jParamters_tSendMail_2.append("IMPORTANCE" + " = " + "High");
                log4jParamters_tSendMail_2.append(" | ");
                    log4jParamters_tSendMail_2.append("NEED_AUTH" + " = " + "false");
                log4jParamters_tSendMail_2.append(" | ");
                    log4jParamters_tSendMail_2.append("DIE_ON_ERROR" + " = " + "false");
                log4jParamters_tSendMail_2.append(" | ");
                    log4jParamters_tSendMail_2.append("TEXT_SUBTYPE" + " = " + "html");
                log4jParamters_tSendMail_2.append(" | ");
                    log4jParamters_tSendMail_2.append("ENCODING" + " = " + "\"ISO-8859-15\"");
                log4jParamters_tSendMail_2.append(" | ");
                    log4jParamters_tSendMail_2.append("SET_LOCALHOST" + " = " + "false");
                log4jParamters_tSendMail_2.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tSendMail_2 - "  + (log4jParamters_tSendMail_2) );
    		}
    	}
    	
        new BytesLimit65535_tSendMail_2().limitLog4jByte();

 



/**
 * [tSendMail_2 begin ] stop
 */
	
	/**
	 * [tSendMail_2 main ] start
	 */

	

	
	
	currentComponent="tSendMail_2";

	

 

	String smtpHost_tSendMail_2 = context.smtp;
        String smtpPort_tSendMail_2 = "25";
	String from_tSendMail_2 = (context.mail_from);
    String to_tSendMail_2 = (context.MAIL_TO).replace(";",",");
    String cc_tSendMail_2 = ((context.mail_cc)==null || "".equals(context.mail_cc))?null:(context.mail_cc).replace(";",",");
    String bcc_tSendMail_2 = ((context.mail_bcc)==null || "".equals(context.mail_bcc))?null:(context.mail_bcc).replace(";",",");
    String subject_tSendMail_2 = (globalMap.get("mailSubject") +"  " +((String)globalMap.get("status")));
    
	java.util.List<java.util.Map<String, String>> headers_tSendMail_2 = new java.util.ArrayList<java.util.Map<String,String>>();
	java.util.List<String> attachments_tSendMail_2 = new java.util.ArrayList<String>();
	java.util.List<String> contentTransferEncoding_tSendMail_2 = new java.util.ArrayList<String>();

	String message_tSendMail_2 = (("<font color=\"#1E4191\" face=\"GE Inspira\">Dear Colleagues,</font >\n<br /><br />\n<font color=\"#1E4191\" face=\"GE Inspira\">"+context.mail_body_text+"</font >\n<br />\n" +  ((Document)globalMap.get("mailTable")) + "\n<br />\n<font color=\"#1E4191\" face=\"GE Inspira\">\nThank you & Kind Regards, <br />\n<strong>"+ context.mail_sender_name +"</strong>\n </font >\n.") == null || "".equals("<font color=\"#1E4191\" face=\"GE Inspira\">Dear Colleagues,</font >\n<br /><br />\n<font color=\"#1E4191\" face=\"GE Inspira\">"+context.mail_body_text+"</font >\n<br />\n" +  ((Document)globalMap.get("mailTable")) + "\n<br />\n<font color=\"#1E4191\" face=\"GE Inspira\">\nThank you & Kind Regards, <br />\n<strong>"+ context.mail_sender_name +"</strong>\n </font >\n.")) ? "\"\"" : ("<font color=\"#1E4191\" face=\"GE Inspira\">Dear Colleagues,</font >\n<br /><br />\n<font color=\"#1E4191\" face=\"GE Inspira\">"+context.mail_body_text+"</font >\n<br />\n" +  ((Document)globalMap.get("mailTable")) + "\n<br />\n<font color=\"#1E4191\" face=\"GE Inspira\">\nThank you & Kind Regards, <br />\n<strong>"+ context.mail_sender_name +"</strong>\n </font >\n.") ;
	java.util.Properties props_tSendMail_2 = System.getProperties();     
	props_tSendMail_2.put("mail.smtp.host", smtpHost_tSendMail_2);
	props_tSendMail_2.put("mail.smtp.port", smtpPort_tSendMail_2);
		props_tSendMail_2.put("mail.mime.encodefilename", "true");     
	try {
		
			log.info("tSendMail_2 - Connection attempt to '" + smtpHost_tSendMail_2 +"'.");
		
		  
			props_tSendMail_2.put("mail.smtp.auth", "false");
			javax.mail.Session session_tSendMail_2 = javax.mail.Session.getInstance(props_tSendMail_2, null);    
		
		
			log.info("tSendMail_2 - Connection to '" + smtpHost_tSendMail_2 + "' has succeeded.");
		
		javax.mail.Message msg_tSendMail_2 = new javax.mail.internet.MimeMessage(session_tSendMail_2);
		msg_tSendMail_2.setFrom(new javax.mail.internet.InternetAddress(from_tSendMail_2, context.mail_sender_name));
		msg_tSendMail_2.setRecipients(javax.mail.Message.RecipientType.TO,javax.mail.internet.InternetAddress.parse(to_tSendMail_2, false));
		if (cc_tSendMail_2 != null) msg_tSendMail_2.setRecipients(javax.mail.Message.RecipientType.CC, javax.mail.internet.InternetAddress.parse(cc_tSendMail_2, false));
		if (bcc_tSendMail_2 != null) msg_tSendMail_2.setRecipients(javax.mail.Message.RecipientType.BCC, javax.mail.internet.InternetAddress.parse(bcc_tSendMail_2, false));
		msg_tSendMail_2.setSubject(subject_tSendMail_2);

		for (int i_tSendMail_2 = 0; i_tSendMail_2 < headers_tSendMail_2.size(); i_tSendMail_2++) {
			java.util.Map<String, String> header_tSendMail_2 = headers_tSendMail_2.get(i_tSendMail_2);
			msg_tSendMail_2.setHeader(header_tSendMail_2.get("KEY"), header_tSendMail_2.get("VALUE"));    
		}  
		msg_tSendMail_2.setSentDate(new Date());
		msg_tSendMail_2.setHeader("X-Priority", "1"); //High->1 Normal->3 Low->5
		javax.mail.Multipart mp_tSendMail_2 = new javax.mail.internet.MimeMultipart();
		javax.mail.internet.MimeBodyPart mbpText_tSendMail_2 = new javax.mail.internet.MimeBodyPart();
		mbpText_tSendMail_2.setText(message_tSendMail_2,"ISO-8859-15", "html");
		mp_tSendMail_2.addBodyPart(mbpText_tSendMail_2);
  
		javax.mail.internet.MimeBodyPart mbpFile_tSendMail_2 = null;

		for (int i_tSendMail_2 = 0; i_tSendMail_2 < attachments_tSendMail_2.size(); i_tSendMail_2++){
			String filename_tSendMail_2 = attachments_tSendMail_2.get(i_tSendMail_2);
			javax.activation.FileDataSource fds_tSendMail_2 = null;
			java.io.File file_tSendMail_2 = new java.io.File(filename_tSendMail_2);
			
				if (!file_tSendMail_2.exists()){
					continue;
				}
			
    		if (file_tSendMail_2.isDirectory()){
				java.io.File[] subFiles_tSendMail_2 = file_tSendMail_2.listFiles();
				for(java.io.File subFile_tSendMail_2 : subFiles_tSendMail_2){
					if (subFile_tSendMail_2.isFile()){
						fds_tSendMail_2 = new javax.activation.FileDataSource(subFile_tSendMail_2.getAbsolutePath());
						mbpFile_tSendMail_2 = new javax.mail.internet.MimeBodyPart();
						mbpFile_tSendMail_2.setDataHandler(new javax.activation.DataHandler(fds_tSendMail_2));
						mbpFile_tSendMail_2.setFileName(javax.mail.internet.MimeUtility.encodeText(fds_tSendMail_2.getName()));
						if(contentTransferEncoding_tSendMail_2.get(i_tSendMail_2).equalsIgnoreCase("base64")){
							mbpFile_tSendMail_2.setHeader("Content-Transfer-Encoding", "base64");
						}
						mp_tSendMail_2.addBodyPart(mbpFile_tSendMail_2);
					}
				}
    		}else{
				mbpFile_tSendMail_2 = new javax.mail.internet.MimeBodyPart();
				fds_tSendMail_2 = new javax.activation.FileDataSource(filename_tSendMail_2);
				mbpFile_tSendMail_2.setDataHandler(new javax.activation.DataHandler(fds_tSendMail_2)); 
				mbpFile_tSendMail_2.setFileName(javax.mail.internet.MimeUtility.encodeText(fds_tSendMail_2.getName()));
				if(contentTransferEncoding_tSendMail_2.get(i_tSendMail_2).equalsIgnoreCase("base64")){
					mbpFile_tSendMail_2.setHeader("Content-Transfer-Encoding", "base64");
				}
				mp_tSendMail_2.addBodyPart(mbpFile_tSendMail_2);
			}
		}
		// -- set the content --
		msg_tSendMail_2.setContent(mp_tSendMail_2);
		// add handlers for main MIME types
		javax.activation.MailcapCommandMap mc_tSendMail_2 = ( javax.activation.MailcapCommandMap)javax.activation.CommandMap.getDefaultCommandMap();
		mc_tSendMail_2.addMailcap("text/html;; x-java-content-handler=com.sun.mail.handlers.text_html");
		mc_tSendMail_2.addMailcap("text/xml;; x-java-content-handler=com.sun.mail.handlers.text_xml");
		mc_tSendMail_2.addMailcap("text/plain;; x-java-content-handler=com.sun.mail.handlers.text_plain");
		mc_tSendMail_2.addMailcap("multipart/*;; x-java-content-handler=com.sun.mail.handlers.multipart_mixed");
		mc_tSendMail_2.addMailcap("message/rfc822;; x-java-content-handler=com.sun.mail.handlers.message_rfc822");
		javax.activation.CommandMap.setDefaultCommandMap(mc_tSendMail_2);
		// -- Send the message --
		javax.mail.Transport.send(msg_tSendMail_2);
	} catch(java.lang.Exception e){
  		
			
				log.error("tSendMail_2 - " + e.toString());
			
  			System.err.println(e.toString());
		
	}finally{
		props_tSendMail_2.remove("mail.smtp.host");
		props_tSendMail_2.remove("mail.smtp.port");
		
		props_tSendMail_2.remove("mail.mime.encodefilename");
		
		props_tSendMail_2.remove("mail.smtp.auth");     
	}

 


	tos_count_tSendMail_2++;

/**
 * [tSendMail_2 main ] stop
 */
	
	/**
	 * [tSendMail_2 end ] start
	 */

	

	
	
	currentComponent="tSendMail_2";

	

 
                if(log.isDebugEnabled())
            log.debug("tSendMail_2 - "  + ("Done.") );

ok_Hash.put("tSendMail_2", true);
end_Hash.put("tSendMail_2", System.currentTimeMillis());




/**
 * [tSendMail_2 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage());
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tSendMail_2 finally ] start
	 */

	

	
	
	currentComponent="tSendMail_2";

	

 



/**
 * [tSendMail_2 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tSendMail_2_SUBPROCESS_STATE", 1);
	}
	


public static class row_talendLogs_LOGSStruct implements routines.system.IPersistableRow<row_talendLogs_LOGSStruct> {
    final static byte[] commonByteArrayLock_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Get_Execution_Statistics_prd2dev_GP = new byte[0];
    static byte[] commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Get_Execution_Statistics_prd2dev_GP = new byte[0];

	
			    public java.util.Date moment;

				public java.util.Date getMoment () {
					return this.moment;
				}
				
			    public String pid;

				public String getPid () {
					return this.pid;
				}
				
			    public String root_pid;

				public String getRoot_pid () {
					return this.root_pid;
				}
				
			    public String father_pid;

				public String getFather_pid () {
					return this.father_pid;
				}
				
			    public String project;

				public String getProject () {
					return this.project;
				}
				
			    public String job;

				public String getJob () {
					return this.job;
				}
				
			    public String context;

				public String getContext () {
					return this.context;
				}
				
			    public Integer priority;

				public Integer getPriority () {
					return this.priority;
				}
				
			    public String type;

				public String getType () {
					return this.type;
				}
				
			    public String origin;

				public String getOrigin () {
					return this.origin;
				}
				
			    public String message;

				public String getMessage () {
					return this.message;
				}
				
			    public Integer code;

				public Integer getCode () {
					return this.code;
				}
				



	private java.util.Date readDate(ObjectInputStream dis) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(dis.readLong());
		}
		return dateReturn;
	}

    private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException{
		if(date1 == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeLong(date1.getTime());
    	}
    }

	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Get_Execution_Statistics_prd2dev_GP.length) {
				if(length < 1024 && commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Get_Execution_Statistics_prd2dev_GP.length == 0) {
   					commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Get_Execution_Statistics_prd2dev_GP = new byte[1024];
				} else {
   					commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Get_Execution_Statistics_prd2dev_GP = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Get_Execution_Statistics_prd2dev_GP, 0, length);
			strReturn = new String(commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Get_Execution_Statistics_prd2dev_GP, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
	private Integer readInteger(ObjectInputStream dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}

	private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException{
		if(intNum == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeInt(intNum);
    	}
	}

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Get_Execution_Statistics_prd2dev_GP) {

        	try {

        		int length = 0;
		
					this.moment = readDate(dis);
					
					this.pid = readString(dis);
					
					this.root_pid = readString(dis);
					
					this.father_pid = readString(dis);
					
					this.project = readString(dis);
					
					this.job = readString(dis);
					
					this.context = readString(dis);
					
						this.priority = readInteger(dis);
					
					this.type = readString(dis);
					
					this.origin = readString(dis);
					
					this.message = readString(dis);
					
						this.code = readInteger(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// java.util.Date
				
						writeDate(this.moment,dos);
					
					// String
				
						writeString(this.pid,dos);
					
					// String
				
						writeString(this.root_pid,dos);
					
					// String
				
						writeString(this.father_pid,dos);
					
					// String
				
						writeString(this.project,dos);
					
					// String
				
						writeString(this.job,dos);
					
					// String
				
						writeString(this.context,dos);
					
					// Integer
				
						writeInteger(this.priority,dos);
					
					// String
				
						writeString(this.type,dos);
					
					// String
				
						writeString(this.origin,dos);
					
					// String
				
						writeString(this.message,dos);
					
					// Integer
				
						writeInteger(this.code,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("moment="+String.valueOf(moment));
		sb.append(",pid="+pid);
		sb.append(",root_pid="+root_pid);
		sb.append(",father_pid="+father_pid);
		sb.append(",project="+project);
		sb.append(",job="+job);
		sb.append(",context="+context);
		sb.append(",priority="+String.valueOf(priority));
		sb.append(",type="+type);
		sb.append(",origin="+origin);
		sb.append(",message="+message);
		sb.append(",code="+String.valueOf(code));
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				if(moment == null){
        					sb.append("<null>");
        				}else{
            				sb.append(moment);
            			}
            		
        			sb.append("|");
        		
        				if(pid == null){
        					sb.append("<null>");
        				}else{
            				sb.append(pid);
            			}
            		
        			sb.append("|");
        		
        				if(root_pid == null){
        					sb.append("<null>");
        				}else{
            				sb.append(root_pid);
            			}
            		
        			sb.append("|");
        		
        				if(father_pid == null){
        					sb.append("<null>");
        				}else{
            				sb.append(father_pid);
            			}
            		
        			sb.append("|");
        		
        				if(project == null){
        					sb.append("<null>");
        				}else{
            				sb.append(project);
            			}
            		
        			sb.append("|");
        		
        				if(job == null){
        					sb.append("<null>");
        				}else{
            				sb.append(job);
            			}
            		
        			sb.append("|");
        		
        				if(context == null){
        					sb.append("<null>");
        				}else{
            				sb.append(context);
            			}
            		
        			sb.append("|");
        		
        				if(priority == null){
        					sb.append("<null>");
        				}else{
            				sb.append(priority);
            			}
            		
        			sb.append("|");
        		
        				if(type == null){
        					sb.append("<null>");
        				}else{
            				sb.append(type);
            			}
            		
        			sb.append("|");
        		
        				if(origin == null){
        					sb.append("<null>");
        				}else{
            				sb.append(origin);
            			}
            		
        			sb.append("|");
        		
        				if(message == null){
        					sb.append("<null>");
        				}else{
            				sb.append(message);
            			}
            		
        			sb.append("|");
        		
        				if(code == null){
        					sb.append("<null>");
        				}else{
            				sb.append(code);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(row_talendLogs_LOGSStruct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}
public void talendLogs_LOGSProcess(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("talendLogs_LOGS_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
		String currentVirtualComponent = null;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;



		row_talendLogs_LOGSStruct row_talendLogs_LOGS = new row_talendLogs_LOGSStruct();




	
	/**
	 * [talendLogs_CONSOLE begin ] start
	 */

	

	
		
		ok_Hash.put("talendLogs_CONSOLE", false);
		start_Hash.put("talendLogs_CONSOLE", System.currentTimeMillis());
		
	
		currentVirtualComponent = "talendLogs_CONSOLE";
	
	currentComponent="talendLogs_CONSOLE";

	
			if (execStat) {
				if(resourceMap.get("inIterateVComp") == null){
					
						runStat.updateStatOnConnection("Main" + iterateId, 0, 0);
					
				}
			} 

		
		int tos_count_talendLogs_CONSOLE = 0;
		
                if(log.isDebugEnabled())
            log.debug("talendLogs_CONSOLE - "  + ("Start to work.") );
    	class BytesLimit65535_talendLogs_CONSOLE{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_talendLogs_CONSOLE = new StringBuilder();
            log4jParamters_talendLogs_CONSOLE.append("Parameters:");
                    log4jParamters_talendLogs_CONSOLE.append("BASIC_MODE" + " = " + "true");
                log4jParamters_talendLogs_CONSOLE.append(" | ");
                    log4jParamters_talendLogs_CONSOLE.append("TABLE_PRINT" + " = " + "false");
                log4jParamters_talendLogs_CONSOLE.append(" | ");
                    log4jParamters_talendLogs_CONSOLE.append("VERTICAL" + " = " + "false");
                log4jParamters_talendLogs_CONSOLE.append(" | ");
                    log4jParamters_talendLogs_CONSOLE.append("FIELDSEPARATOR" + " = " + "\"|\"");
                log4jParamters_talendLogs_CONSOLE.append(" | ");
                    log4jParamters_talendLogs_CONSOLE.append("PRINT_HEADER" + " = " + "false");
                log4jParamters_talendLogs_CONSOLE.append(" | ");
                    log4jParamters_talendLogs_CONSOLE.append("PRINT_UNIQUE_NAME" + " = " + "false");
                log4jParamters_talendLogs_CONSOLE.append(" | ");
                    log4jParamters_talendLogs_CONSOLE.append("PRINT_COLNAMES" + " = " + "false");
                log4jParamters_talendLogs_CONSOLE.append(" | ");
                    log4jParamters_talendLogs_CONSOLE.append("USE_FIXED_LENGTH" + " = " + "false");
                log4jParamters_talendLogs_CONSOLE.append(" | ");
                    log4jParamters_talendLogs_CONSOLE.append("PRINT_CONTENT_WITH_LOG4J" + " = " + "true");
                log4jParamters_talendLogs_CONSOLE.append(" | ");
                if(log.isDebugEnabled())
            log.debug("talendLogs_CONSOLE - "  + (log4jParamters_talendLogs_CONSOLE) );
    		}
    	}
    	
        new BytesLimit65535_talendLogs_CONSOLE().limitLog4jByte();

	///////////////////////
	
		final String OUTPUT_FIELD_SEPARATOR_talendLogs_CONSOLE = "|";
		java.io.PrintStream consoleOut_talendLogs_CONSOLE = null;	

 		StringBuilder strBuffer_talendLogs_CONSOLE = null;
		int nb_line_talendLogs_CONSOLE = 0;
///////////////////////    			



 



/**
 * [talendLogs_CONSOLE begin ] stop
 */



	
	/**
	 * [talendLogs_LOGS begin ] start
	 */

	

	
		
		ok_Hash.put("talendLogs_LOGS", false);
		start_Hash.put("talendLogs_LOGS", System.currentTimeMillis());
		
	
		currentVirtualComponent = "talendLogs_LOGS";
	
	currentComponent="talendLogs_LOGS";

	
		int tos_count_talendLogs_LOGS = 0;
		
                if(log.isDebugEnabled())
            log.debug("talendLogs_LOGS - "  + ("Start to work.") );
    	class BytesLimit65535_talendLogs_LOGS{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_talendLogs_LOGS = new StringBuilder();
            log4jParamters_talendLogs_LOGS.append("Parameters:");
                    log4jParamters_talendLogs_LOGS.append("CATCH_JAVA_EXCEPTION" + " = " + "true");
                log4jParamters_talendLogs_LOGS.append(" | ");
                    log4jParamters_talendLogs_LOGS.append("CATCH_TDIE" + " = " + "true");
                log4jParamters_talendLogs_LOGS.append(" | ");
                    log4jParamters_talendLogs_LOGS.append("CATCH_TWARN" + " = " + "true");
                log4jParamters_talendLogs_LOGS.append(" | ");
                    log4jParamters_talendLogs_LOGS.append("CATCH_TACTIONFAILURE" + " = " + "true");
                log4jParamters_talendLogs_LOGS.append(" | ");
                if(log.isDebugEnabled())
            log.debug("talendLogs_LOGS - "  + (log4jParamters_talendLogs_LOGS) );
    		}
    	}
    	
        new BytesLimit65535_talendLogs_LOGS().limitLog4jByte();

	for (LogCatcherUtils.LogCatcherMessage lcm : talendLogs_LOGS.getMessages()) {
		row_talendLogs_LOGS.type = lcm.getType();
		row_talendLogs_LOGS.origin = (lcm.getOrigin()==null || lcm.getOrigin().length()<1 ? null : lcm.getOrigin());
		row_talendLogs_LOGS.priority = lcm.getPriority();
		row_talendLogs_LOGS.message = lcm.getMessage();
		row_talendLogs_LOGS.code = lcm.getCode();
		
		row_talendLogs_LOGS.moment = java.util.Calendar.getInstance().getTime();
	
    	row_talendLogs_LOGS.pid = pid;
		row_talendLogs_LOGS.root_pid = rootPid;
		row_talendLogs_LOGS.father_pid = fatherPid;
	
    	row_talendLogs_LOGS.project = projectName;
    	row_talendLogs_LOGS.job = jobName;
    	row_talendLogs_LOGS.context = contextStr;
    		
 



/**
 * [talendLogs_LOGS begin ] stop
 */
	
	/**
	 * [talendLogs_LOGS main ] start
	 */

	

	
	
		currentVirtualComponent = "talendLogs_LOGS";
	
	currentComponent="talendLogs_LOGS";

	

 


	tos_count_talendLogs_LOGS++;

/**
 * [talendLogs_LOGS main ] stop
 */

	
	/**
	 * [talendLogs_CONSOLE main ] start
	 */

	

	
	
		currentVirtualComponent = "talendLogs_CONSOLE";
	
	currentComponent="talendLogs_CONSOLE";

	

			//Main
			//row_talendLogs_LOGS


			
				if(execStat){
					runStat.updateStatOnConnection("Main"+iterateId,1, 1);
				} 
			

		
///////////////////////		
						



				strBuffer_talendLogs_CONSOLE = new StringBuilder();




   				
	    		if(row_talendLogs_LOGS.moment != null) { //              
                    							
       
				strBuffer_talendLogs_CONSOLE.append(
								FormatterUtils.format_Date(row_talendLogs_LOGS.moment, "yyyy-MM-dd HH:mm:ss")				
				);


							
	    		} //  			

    			strBuffer_talendLogs_CONSOLE.append("|");
    			


   				
	    		if(row_talendLogs_LOGS.pid != null) { //              
                    							
       
				strBuffer_talendLogs_CONSOLE.append(
				                String.valueOf(row_talendLogs_LOGS.pid)							
				);


							
	    		} //  			

    			strBuffer_talendLogs_CONSOLE.append("|");
    			


   				
	    		if(row_talendLogs_LOGS.root_pid != null) { //              
                    							
       
				strBuffer_talendLogs_CONSOLE.append(
				                String.valueOf(row_talendLogs_LOGS.root_pid)							
				);


							
	    		} //  			

    			strBuffer_talendLogs_CONSOLE.append("|");
    			


   				
	    		if(row_talendLogs_LOGS.father_pid != null) { //              
                    							
       
				strBuffer_talendLogs_CONSOLE.append(
				                String.valueOf(row_talendLogs_LOGS.father_pid)							
				);


							
	    		} //  			

    			strBuffer_talendLogs_CONSOLE.append("|");
    			


   				
	    		if(row_talendLogs_LOGS.project != null) { //              
                    							
       
				strBuffer_talendLogs_CONSOLE.append(
				                String.valueOf(row_talendLogs_LOGS.project)							
				);


							
	    		} //  			

    			strBuffer_talendLogs_CONSOLE.append("|");
    			


   				
	    		if(row_talendLogs_LOGS.job != null) { //              
                    							
       
				strBuffer_talendLogs_CONSOLE.append(
				                String.valueOf(row_talendLogs_LOGS.job)							
				);


							
	    		} //  			

    			strBuffer_talendLogs_CONSOLE.append("|");
    			


   				
	    		if(row_talendLogs_LOGS.context != null) { //              
                    							
       
				strBuffer_talendLogs_CONSOLE.append(
				                String.valueOf(row_talendLogs_LOGS.context)							
				);


							
	    		} //  			

    			strBuffer_talendLogs_CONSOLE.append("|");
    			


   				
	    		if(row_talendLogs_LOGS.priority != null) { //              
                    							
       
				strBuffer_talendLogs_CONSOLE.append(
				                String.valueOf(row_talendLogs_LOGS.priority)							
				);


							
	    		} //  			

    			strBuffer_talendLogs_CONSOLE.append("|");
    			


   				
	    		if(row_talendLogs_LOGS.type != null) { //              
                    							
       
				strBuffer_talendLogs_CONSOLE.append(
				                String.valueOf(row_talendLogs_LOGS.type)							
				);


							
	    		} //  			

    			strBuffer_talendLogs_CONSOLE.append("|");
    			


   				
	    		if(row_talendLogs_LOGS.origin != null) { //              
                    							
       
				strBuffer_talendLogs_CONSOLE.append(
				                String.valueOf(row_talendLogs_LOGS.origin)							
				);


							
	    		} //  			

    			strBuffer_talendLogs_CONSOLE.append("|");
    			


   				
	    		if(row_talendLogs_LOGS.message != null) { //              
                    							
       
				strBuffer_talendLogs_CONSOLE.append(
				                String.valueOf(row_talendLogs_LOGS.message)							
				);


							
	    		} //  			

    			strBuffer_talendLogs_CONSOLE.append("|");
    			


   				
	    		if(row_talendLogs_LOGS.code != null) { //              
                    							
       
				strBuffer_talendLogs_CONSOLE.append(
				                String.valueOf(row_talendLogs_LOGS.code)							
				);


							
	    		} //  			
 

                    if (globalMap.get("tLogRow_CONSOLE")!=null)
                    {
                    	consoleOut_talendLogs_CONSOLE = (java.io.PrintStream) globalMap.get("tLogRow_CONSOLE");
                    }
                    else
                    {
                    	consoleOut_talendLogs_CONSOLE = new java.io.PrintStream(new java.io.BufferedOutputStream(System.out));
                    	globalMap.put("tLogRow_CONSOLE",consoleOut_talendLogs_CONSOLE);
                    }
                    	log.info("talendLogs_CONSOLE - Content of row "+(nb_line_talendLogs_CONSOLE+1)+": " + strBuffer_talendLogs_CONSOLE.toString());
                    consoleOut_talendLogs_CONSOLE.println(strBuffer_talendLogs_CONSOLE.toString());
                    consoleOut_talendLogs_CONSOLE.flush();
                    nb_line_talendLogs_CONSOLE++;
//////

//////                    
                    
///////////////////////    			

 


	tos_count_talendLogs_CONSOLE++;

/**
 * [talendLogs_CONSOLE main ] stop
 */



	
	/**
	 * [talendLogs_LOGS end ] start
	 */

	

	
	
		currentVirtualComponent = "talendLogs_LOGS";
	
	currentComponent="talendLogs_LOGS";

	
	}
 
                if(log.isDebugEnabled())
            log.debug("talendLogs_LOGS - "  + ("Done.") );

ok_Hash.put("talendLogs_LOGS", true);
end_Hash.put("talendLogs_LOGS", System.currentTimeMillis());




/**
 * [talendLogs_LOGS end ] stop
 */

	
	/**
	 * [talendLogs_CONSOLE end ] start
	 */

	

	
	
		currentVirtualComponent = "talendLogs_CONSOLE";
	
	currentComponent="talendLogs_CONSOLE";

	


//////
//////
globalMap.put("talendLogs_CONSOLE_NB_LINE",nb_line_talendLogs_CONSOLE);
                if(log.isInfoEnabled())
            log.info("talendLogs_CONSOLE - "  + ("Printed row count: ")  + (nb_line_talendLogs_CONSOLE)  + (".") );

///////////////////////    			

			if(execStat){
				if(resourceMap.get("inIterateVComp") == null || !((Boolean)resourceMap.get("inIterateVComp"))){
			 		runStat.updateStatOnConnection("Main"+iterateId,2, 0); 
			 	}
			}
		
 
                if(log.isDebugEnabled())
            log.debug("talendLogs_CONSOLE - "  + ("Done.") );

ok_Hash.put("talendLogs_CONSOLE", true);
end_Hash.put("talendLogs_CONSOLE", System.currentTimeMillis());




/**
 * [talendLogs_CONSOLE end ] stop
 */



				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage());
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
					te.setVirtualComponentName(currentVirtualComponent);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [talendLogs_LOGS finally ] start
	 */

	

	
	
		currentVirtualComponent = "talendLogs_LOGS";
	
	currentComponent="talendLogs_LOGS";

	

 



/**
 * [talendLogs_LOGS finally ] stop
 */

	
	/**
	 * [talendLogs_CONSOLE finally ] start
	 */

	

	
	
		currentVirtualComponent = "talendLogs_CONSOLE";
	
	currentComponent="talendLogs_CONSOLE";

	

 



/**
 * [talendLogs_CONSOLE finally ] stop
 */



				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("talendLogs_LOGS_SUBPROCESS_STATE", 1);
	}
	


public static class row_talendStats_STATSStruct implements routines.system.IPersistableRow<row_talendStats_STATSStruct> {
    final static byte[] commonByteArrayLock_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Get_Execution_Statistics_prd2dev_GP = new byte[0];
    static byte[] commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Get_Execution_Statistics_prd2dev_GP = new byte[0];

	
			    public java.util.Date moment;

				public java.util.Date getMoment () {
					return this.moment;
				}
				
			    public String pid;

				public String getPid () {
					return this.pid;
				}
				
			    public String father_pid;

				public String getFather_pid () {
					return this.father_pid;
				}
				
			    public String root_pid;

				public String getRoot_pid () {
					return this.root_pid;
				}
				
			    public Long system_pid;

				public Long getSystem_pid () {
					return this.system_pid;
				}
				
			    public String project;

				public String getProject () {
					return this.project;
				}
				
			    public String job;

				public String getJob () {
					return this.job;
				}
				
			    public String job_repository_id;

				public String getJob_repository_id () {
					return this.job_repository_id;
				}
				
			    public String job_version;

				public String getJob_version () {
					return this.job_version;
				}
				
			    public String context;

				public String getContext () {
					return this.context;
				}
				
			    public String origin;

				public String getOrigin () {
					return this.origin;
				}
				
			    public String message_type;

				public String getMessage_type () {
					return this.message_type;
				}
				
			    public String message;

				public String getMessage () {
					return this.message;
				}
				
			    public Long duration;

				public Long getDuration () {
					return this.duration;
				}
				



	private java.util.Date readDate(ObjectInputStream dis) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(dis.readLong());
		}
		return dateReturn;
	}

    private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException{
		if(date1 == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeLong(date1.getTime());
    	}
    }

	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Get_Execution_Statistics_prd2dev_GP.length) {
				if(length < 1024 && commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Get_Execution_Statistics_prd2dev_GP.length == 0) {
   					commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Get_Execution_Statistics_prd2dev_GP = new byte[1024];
				} else {
   					commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Get_Execution_Statistics_prd2dev_GP = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Get_Execution_Statistics_prd2dev_GP, 0, length);
			strReturn = new String(commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Get_Execution_Statistics_prd2dev_GP, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Get_Execution_Statistics_prd2dev_GP) {

        	try {

        		int length = 0;
		
					this.moment = readDate(dis);
					
					this.pid = readString(dis);
					
					this.father_pid = readString(dis);
					
					this.root_pid = readString(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.system_pid = null;
           				} else {
           			    	this.system_pid = dis.readLong();
           				}
					
					this.project = readString(dis);
					
					this.job = readString(dis);
					
					this.job_repository_id = readString(dis);
					
					this.job_version = readString(dis);
					
					this.context = readString(dis);
					
					this.origin = readString(dis);
					
					this.message_type = readString(dis);
					
					this.message = readString(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.duration = null;
           				} else {
           			    	this.duration = dis.readLong();
           				}
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// java.util.Date
				
						writeDate(this.moment,dos);
					
					// String
				
						writeString(this.pid,dos);
					
					// String
				
						writeString(this.father_pid,dos);
					
					// String
				
						writeString(this.root_pid,dos);
					
					// Long
				
						if(this.system_pid == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeLong(this.system_pid);
		            	}
					
					// String
				
						writeString(this.project,dos);
					
					// String
				
						writeString(this.job,dos);
					
					// String
				
						writeString(this.job_repository_id,dos);
					
					// String
				
						writeString(this.job_version,dos);
					
					// String
				
						writeString(this.context,dos);
					
					// String
				
						writeString(this.origin,dos);
					
					// String
				
						writeString(this.message_type,dos);
					
					// String
				
						writeString(this.message,dos);
					
					// Long
				
						if(this.duration == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeLong(this.duration);
		            	}
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("moment="+String.valueOf(moment));
		sb.append(",pid="+pid);
		sb.append(",father_pid="+father_pid);
		sb.append(",root_pid="+root_pid);
		sb.append(",system_pid="+String.valueOf(system_pid));
		sb.append(",project="+project);
		sb.append(",job="+job);
		sb.append(",job_repository_id="+job_repository_id);
		sb.append(",job_version="+job_version);
		sb.append(",context="+context);
		sb.append(",origin="+origin);
		sb.append(",message_type="+message_type);
		sb.append(",message="+message);
		sb.append(",duration="+String.valueOf(duration));
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				if(moment == null){
        					sb.append("<null>");
        				}else{
            				sb.append(moment);
            			}
            		
        			sb.append("|");
        		
        				if(pid == null){
        					sb.append("<null>");
        				}else{
            				sb.append(pid);
            			}
            		
        			sb.append("|");
        		
        				if(father_pid == null){
        					sb.append("<null>");
        				}else{
            				sb.append(father_pid);
            			}
            		
        			sb.append("|");
        		
        				if(root_pid == null){
        					sb.append("<null>");
        				}else{
            				sb.append(root_pid);
            			}
            		
        			sb.append("|");
        		
        				if(system_pid == null){
        					sb.append("<null>");
        				}else{
            				sb.append(system_pid);
            			}
            		
        			sb.append("|");
        		
        				if(project == null){
        					sb.append("<null>");
        				}else{
            				sb.append(project);
            			}
            		
        			sb.append("|");
        		
        				if(job == null){
        					sb.append("<null>");
        				}else{
            				sb.append(job);
            			}
            		
        			sb.append("|");
        		
        				if(job_repository_id == null){
        					sb.append("<null>");
        				}else{
            				sb.append(job_repository_id);
            			}
            		
        			sb.append("|");
        		
        				if(job_version == null){
        					sb.append("<null>");
        				}else{
            				sb.append(job_version);
            			}
            		
        			sb.append("|");
        		
        				if(context == null){
        					sb.append("<null>");
        				}else{
            				sb.append(context);
            			}
            		
        			sb.append("|");
        		
        				if(origin == null){
        					sb.append("<null>");
        				}else{
            				sb.append(origin);
            			}
            		
        			sb.append("|");
        		
        				if(message_type == null){
        					sb.append("<null>");
        				}else{
            				sb.append(message_type);
            			}
            		
        			sb.append("|");
        		
        				if(message == null){
        					sb.append("<null>");
        				}else{
            				sb.append(message);
            			}
            		
        			sb.append("|");
        		
        				if(duration == null){
        					sb.append("<null>");
        				}else{
            				sb.append(duration);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(row_talendStats_STATSStruct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}
public void talendStats_STATSProcess(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("talendStats_STATS_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
		String currentVirtualComponent = null;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;



		row_talendStats_STATSStruct row_talendStats_STATS = new row_talendStats_STATSStruct();




	
	/**
	 * [talendStats_CONSOLE begin ] start
	 */

	

	
		
		ok_Hash.put("talendStats_CONSOLE", false);
		start_Hash.put("talendStats_CONSOLE", System.currentTimeMillis());
		
	
		currentVirtualComponent = "talendStats_CONSOLE";
	
	currentComponent="talendStats_CONSOLE";

	
			if (execStat) {
				if(resourceMap.get("inIterateVComp") == null){
					
						runStat.updateStatOnConnection("Main" + iterateId, 0, 0);
					
				}
			} 

		
		int tos_count_talendStats_CONSOLE = 0;
		
                if(log.isDebugEnabled())
            log.debug("talendStats_CONSOLE - "  + ("Start to work.") );
    	class BytesLimit65535_talendStats_CONSOLE{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_talendStats_CONSOLE = new StringBuilder();
            log4jParamters_talendStats_CONSOLE.append("Parameters:");
                    log4jParamters_talendStats_CONSOLE.append("BASIC_MODE" + " = " + "true");
                log4jParamters_talendStats_CONSOLE.append(" | ");
                    log4jParamters_talendStats_CONSOLE.append("TABLE_PRINT" + " = " + "false");
                log4jParamters_talendStats_CONSOLE.append(" | ");
                    log4jParamters_talendStats_CONSOLE.append("VERTICAL" + " = " + "false");
                log4jParamters_talendStats_CONSOLE.append(" | ");
                    log4jParamters_talendStats_CONSOLE.append("FIELDSEPARATOR" + " = " + "\"|\"");
                log4jParamters_talendStats_CONSOLE.append(" | ");
                    log4jParamters_talendStats_CONSOLE.append("PRINT_HEADER" + " = " + "false");
                log4jParamters_talendStats_CONSOLE.append(" | ");
                    log4jParamters_talendStats_CONSOLE.append("PRINT_UNIQUE_NAME" + " = " + "false");
                log4jParamters_talendStats_CONSOLE.append(" | ");
                    log4jParamters_talendStats_CONSOLE.append("PRINT_COLNAMES" + " = " + "false");
                log4jParamters_talendStats_CONSOLE.append(" | ");
                    log4jParamters_talendStats_CONSOLE.append("USE_FIXED_LENGTH" + " = " + "false");
                log4jParamters_talendStats_CONSOLE.append(" | ");
                    log4jParamters_talendStats_CONSOLE.append("PRINT_CONTENT_WITH_LOG4J" + " = " + "true");
                log4jParamters_talendStats_CONSOLE.append(" | ");
                if(log.isDebugEnabled())
            log.debug("talendStats_CONSOLE - "  + (log4jParamters_talendStats_CONSOLE) );
    		}
    	}
    	
        new BytesLimit65535_talendStats_CONSOLE().limitLog4jByte();

	///////////////////////
	
		final String OUTPUT_FIELD_SEPARATOR_talendStats_CONSOLE = "|";
		java.io.PrintStream consoleOut_talendStats_CONSOLE = null;	

 		StringBuilder strBuffer_talendStats_CONSOLE = null;
		int nb_line_talendStats_CONSOLE = 0;
///////////////////////    			



 



/**
 * [talendStats_CONSOLE begin ] stop
 */



	
	/**
	 * [talendStats_STATS begin ] start
	 */

	

	
		
		ok_Hash.put("talendStats_STATS", false);
		start_Hash.put("talendStats_STATS", System.currentTimeMillis());
		
	
		currentVirtualComponent = "talendStats_STATS";
	
	currentComponent="talendStats_STATS";

	
		int tos_count_talendStats_STATS = 0;
		
                if(log.isDebugEnabled())
            log.debug("talendStats_STATS - "  + ("Start to work.") );
    	class BytesLimit65535_talendStats_STATS{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_talendStats_STATS = new StringBuilder();
            log4jParamters_talendStats_STATS.append("Parameters:");
                if(log.isDebugEnabled())
            log.debug("talendStats_STATS - "  + (log4jParamters_talendStats_STATS) );
    		}
    	}
    	
        new BytesLimit65535_talendStats_STATS().limitLog4jByte();

	for (StatCatcherUtils.StatCatcherMessage scm : talendStats_STATS.getMessages()) {
		row_talendStats_STATS.pid = pid;
		row_talendStats_STATS.root_pid = rootPid;
		row_talendStats_STATS.father_pid = fatherPid;	
    	row_talendStats_STATS.project = projectName;
    	row_talendStats_STATS.job = jobName;
    	row_talendStats_STATS.context = contextStr;
		row_talendStats_STATS.origin = (scm.getOrigin()==null || scm.getOrigin().length()<1 ? null : scm.getOrigin());
		row_talendStats_STATS.message = scm.getMessage();
		row_talendStats_STATS.duration = scm.getDuration();
		row_talendStats_STATS.moment = scm.getMoment();
		row_talendStats_STATS.message_type = scm.getMessageType();
		row_talendStats_STATS.job_version = scm.getJobVersion();
		row_talendStats_STATS.job_repository_id = scm.getJobId();
		row_talendStats_STATS.system_pid = scm.getSystemPid();

 



/**
 * [talendStats_STATS begin ] stop
 */
	
	/**
	 * [talendStats_STATS main ] start
	 */

	

	
	
		currentVirtualComponent = "talendStats_STATS";
	
	currentComponent="talendStats_STATS";

	

 


	tos_count_talendStats_STATS++;

/**
 * [talendStats_STATS main ] stop
 */

	
	/**
	 * [talendStats_CONSOLE main ] start
	 */

	

	
	
		currentVirtualComponent = "talendStats_CONSOLE";
	
	currentComponent="talendStats_CONSOLE";

	

			//Main
			//row_talendStats_STATS


			
				if(execStat){
					runStat.updateStatOnConnection("Main"+iterateId,1, 1);
				} 
			

		
///////////////////////		
						



				strBuffer_talendStats_CONSOLE = new StringBuilder();




   				
	    		if(row_talendStats_STATS.moment != null) { //              
                    							
       
				strBuffer_talendStats_CONSOLE.append(
								FormatterUtils.format_Date(row_talendStats_STATS.moment, "yyyy-MM-dd HH:mm:ss")				
				);


							
	    		} //  			

    			strBuffer_talendStats_CONSOLE.append("|");
    			


   				
	    		if(row_talendStats_STATS.pid != null) { //              
                    							
       
				strBuffer_talendStats_CONSOLE.append(
				                String.valueOf(row_talendStats_STATS.pid)							
				);


							
	    		} //  			

    			strBuffer_talendStats_CONSOLE.append("|");
    			


   				
	    		if(row_talendStats_STATS.father_pid != null) { //              
                    							
       
				strBuffer_talendStats_CONSOLE.append(
				                String.valueOf(row_talendStats_STATS.father_pid)							
				);


							
	    		} //  			

    			strBuffer_talendStats_CONSOLE.append("|");
    			


   				
	    		if(row_talendStats_STATS.root_pid != null) { //              
                    							
       
				strBuffer_talendStats_CONSOLE.append(
				                String.valueOf(row_talendStats_STATS.root_pid)							
				);


							
	    		} //  			

    			strBuffer_talendStats_CONSOLE.append("|");
    			


   				
	    		if(row_talendStats_STATS.system_pid != null) { //              
                    							
       
				strBuffer_talendStats_CONSOLE.append(
				                String.valueOf(row_talendStats_STATS.system_pid)							
				);


							
	    		} //  			

    			strBuffer_talendStats_CONSOLE.append("|");
    			


   				
	    		if(row_talendStats_STATS.project != null) { //              
                    							
       
				strBuffer_talendStats_CONSOLE.append(
				                String.valueOf(row_talendStats_STATS.project)							
				);


							
	    		} //  			

    			strBuffer_talendStats_CONSOLE.append("|");
    			


   				
	    		if(row_talendStats_STATS.job != null) { //              
                    							
       
				strBuffer_talendStats_CONSOLE.append(
				                String.valueOf(row_talendStats_STATS.job)							
				);


							
	    		} //  			

    			strBuffer_talendStats_CONSOLE.append("|");
    			


   				
	    		if(row_talendStats_STATS.job_repository_id != null) { //              
                    							
       
				strBuffer_talendStats_CONSOLE.append(
				                String.valueOf(row_talendStats_STATS.job_repository_id)							
				);


							
	    		} //  			

    			strBuffer_talendStats_CONSOLE.append("|");
    			


   				
	    		if(row_talendStats_STATS.job_version != null) { //              
                    							
       
				strBuffer_talendStats_CONSOLE.append(
				                String.valueOf(row_talendStats_STATS.job_version)							
				);


							
	    		} //  			

    			strBuffer_talendStats_CONSOLE.append("|");
    			


   				
	    		if(row_talendStats_STATS.context != null) { //              
                    							
       
				strBuffer_talendStats_CONSOLE.append(
				                String.valueOf(row_talendStats_STATS.context)							
				);


							
	    		} //  			

    			strBuffer_talendStats_CONSOLE.append("|");
    			


   				
	    		if(row_talendStats_STATS.origin != null) { //              
                    							
       
				strBuffer_talendStats_CONSOLE.append(
				                String.valueOf(row_talendStats_STATS.origin)							
				);


							
	    		} //  			

    			strBuffer_talendStats_CONSOLE.append("|");
    			


   				
	    		if(row_talendStats_STATS.message_type != null) { //              
                    							
       
				strBuffer_talendStats_CONSOLE.append(
				                String.valueOf(row_talendStats_STATS.message_type)							
				);


							
	    		} //  			

    			strBuffer_talendStats_CONSOLE.append("|");
    			


   				
	    		if(row_talendStats_STATS.message != null) { //              
                    							
       
				strBuffer_talendStats_CONSOLE.append(
				                String.valueOf(row_talendStats_STATS.message)							
				);


							
	    		} //  			

    			strBuffer_talendStats_CONSOLE.append("|");
    			


   				
	    		if(row_talendStats_STATS.duration != null) { //              
                    							
       
				strBuffer_talendStats_CONSOLE.append(
				                String.valueOf(row_talendStats_STATS.duration)							
				);


							
	    		} //  			
 

                    if (globalMap.get("tLogRow_CONSOLE")!=null)
                    {
                    	consoleOut_talendStats_CONSOLE = (java.io.PrintStream) globalMap.get("tLogRow_CONSOLE");
                    }
                    else
                    {
                    	consoleOut_talendStats_CONSOLE = new java.io.PrintStream(new java.io.BufferedOutputStream(System.out));
                    	globalMap.put("tLogRow_CONSOLE",consoleOut_talendStats_CONSOLE);
                    }
                    	log.info("talendStats_CONSOLE - Content of row "+(nb_line_talendStats_CONSOLE+1)+": " + strBuffer_talendStats_CONSOLE.toString());
                    consoleOut_talendStats_CONSOLE.println(strBuffer_talendStats_CONSOLE.toString());
                    consoleOut_talendStats_CONSOLE.flush();
                    nb_line_talendStats_CONSOLE++;
//////

//////                    
                    
///////////////////////    			

 


	tos_count_talendStats_CONSOLE++;

/**
 * [talendStats_CONSOLE main ] stop
 */



	
	/**
	 * [talendStats_STATS end ] start
	 */

	

	
	
		currentVirtualComponent = "talendStats_STATS";
	
	currentComponent="talendStats_STATS";

	

	}


 
                if(log.isDebugEnabled())
            log.debug("talendStats_STATS - "  + ("Done.") );

ok_Hash.put("talendStats_STATS", true);
end_Hash.put("talendStats_STATS", System.currentTimeMillis());




/**
 * [talendStats_STATS end ] stop
 */

	
	/**
	 * [talendStats_CONSOLE end ] start
	 */

	

	
	
		currentVirtualComponent = "talendStats_CONSOLE";
	
	currentComponent="talendStats_CONSOLE";

	


//////
//////
globalMap.put("talendStats_CONSOLE_NB_LINE",nb_line_talendStats_CONSOLE);
                if(log.isInfoEnabled())
            log.info("talendStats_CONSOLE - "  + ("Printed row count: ")  + (nb_line_talendStats_CONSOLE)  + (".") );

///////////////////////    			

			if(execStat){
				if(resourceMap.get("inIterateVComp") == null || !((Boolean)resourceMap.get("inIterateVComp"))){
			 		runStat.updateStatOnConnection("Main"+iterateId,2, 0); 
			 	}
			}
		
 
                if(log.isDebugEnabled())
            log.debug("talendStats_CONSOLE - "  + ("Done.") );

ok_Hash.put("talendStats_CONSOLE", true);
end_Hash.put("talendStats_CONSOLE", System.currentTimeMillis());




/**
 * [talendStats_CONSOLE end ] stop
 */



				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage());
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
					te.setVirtualComponentName(currentVirtualComponent);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [talendStats_STATS finally ] start
	 */

	

	
	
		currentVirtualComponent = "talendStats_STATS";
	
	currentComponent="talendStats_STATS";

	

 



/**
 * [talendStats_STATS finally ] stop
 */

	
	/**
	 * [talendStats_CONSOLE finally ] start
	 */

	

	
	
		currentVirtualComponent = "talendStats_CONSOLE";
	
	currentComponent="talendStats_CONSOLE";

	

 



/**
 * [talendStats_CONSOLE finally ] stop
 */



				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("talendStats_STATS_SUBPROCESS_STATE", 1);
	}
	


public static class row_talendMeter_METTERStruct implements routines.system.IPersistableRow<row_talendMeter_METTERStruct> {
    final static byte[] commonByteArrayLock_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Get_Execution_Statistics_prd2dev_GP = new byte[0];
    static byte[] commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Get_Execution_Statistics_prd2dev_GP = new byte[0];

	
			    public java.util.Date moment;

				public java.util.Date getMoment () {
					return this.moment;
				}
				
			    public String pid;

				public String getPid () {
					return this.pid;
				}
				
			    public String father_pid;

				public String getFather_pid () {
					return this.father_pid;
				}
				
			    public String root_pid;

				public String getRoot_pid () {
					return this.root_pid;
				}
				
			    public Long system_pid;

				public Long getSystem_pid () {
					return this.system_pid;
				}
				
			    public String project;

				public String getProject () {
					return this.project;
				}
				
			    public String job;

				public String getJob () {
					return this.job;
				}
				
			    public String job_repository_id;

				public String getJob_repository_id () {
					return this.job_repository_id;
				}
				
			    public String job_version;

				public String getJob_version () {
					return this.job_version;
				}
				
			    public String context;

				public String getContext () {
					return this.context;
				}
				
			    public String origin;

				public String getOrigin () {
					return this.origin;
				}
				
			    public String label;

				public String getLabel () {
					return this.label;
				}
				
			    public Integer count;

				public Integer getCount () {
					return this.count;
				}
				
			    public Integer reference;

				public Integer getReference () {
					return this.reference;
				}
				
			    public String thresholds;

				public String getThresholds () {
					return this.thresholds;
				}
				



	private java.util.Date readDate(ObjectInputStream dis) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(dis.readLong());
		}
		return dateReturn;
	}

    private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException{
		if(date1 == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeLong(date1.getTime());
    	}
    }

	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Get_Execution_Statistics_prd2dev_GP.length) {
				if(length < 1024 && commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Get_Execution_Statistics_prd2dev_GP.length == 0) {
   					commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Get_Execution_Statistics_prd2dev_GP = new byte[1024];
				} else {
   					commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Get_Execution_Statistics_prd2dev_GP = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Get_Execution_Statistics_prd2dev_GP, 0, length);
			strReturn = new String(commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Get_Execution_Statistics_prd2dev_GP, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
	private Integer readInteger(ObjectInputStream dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}

	private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException{
		if(intNum == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeInt(intNum);
    	}
	}

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Get_Execution_Statistics_prd2dev_GP) {

        	try {

        		int length = 0;
		
					this.moment = readDate(dis);
					
					this.pid = readString(dis);
					
					this.father_pid = readString(dis);
					
					this.root_pid = readString(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.system_pid = null;
           				} else {
           			    	this.system_pid = dis.readLong();
           				}
					
					this.project = readString(dis);
					
					this.job = readString(dis);
					
					this.job_repository_id = readString(dis);
					
					this.job_version = readString(dis);
					
					this.context = readString(dis);
					
					this.origin = readString(dis);
					
					this.label = readString(dis);
					
						this.count = readInteger(dis);
					
						this.reference = readInteger(dis);
					
					this.thresholds = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// java.util.Date
				
						writeDate(this.moment,dos);
					
					// String
				
						writeString(this.pid,dos);
					
					// String
				
						writeString(this.father_pid,dos);
					
					// String
				
						writeString(this.root_pid,dos);
					
					// Long
				
						if(this.system_pid == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeLong(this.system_pid);
		            	}
					
					// String
				
						writeString(this.project,dos);
					
					// String
				
						writeString(this.job,dos);
					
					// String
				
						writeString(this.job_repository_id,dos);
					
					// String
				
						writeString(this.job_version,dos);
					
					// String
				
						writeString(this.context,dos);
					
					// String
				
						writeString(this.origin,dos);
					
					// String
				
						writeString(this.label,dos);
					
					// Integer
				
						writeInteger(this.count,dos);
					
					// Integer
				
						writeInteger(this.reference,dos);
					
					// String
				
						writeString(this.thresholds,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("moment="+String.valueOf(moment));
		sb.append(",pid="+pid);
		sb.append(",father_pid="+father_pid);
		sb.append(",root_pid="+root_pid);
		sb.append(",system_pid="+String.valueOf(system_pid));
		sb.append(",project="+project);
		sb.append(",job="+job);
		sb.append(",job_repository_id="+job_repository_id);
		sb.append(",job_version="+job_version);
		sb.append(",context="+context);
		sb.append(",origin="+origin);
		sb.append(",label="+label);
		sb.append(",count="+String.valueOf(count));
		sb.append(",reference="+String.valueOf(reference));
		sb.append(",thresholds="+thresholds);
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				if(moment == null){
        					sb.append("<null>");
        				}else{
            				sb.append(moment);
            			}
            		
        			sb.append("|");
        		
        				if(pid == null){
        					sb.append("<null>");
        				}else{
            				sb.append(pid);
            			}
            		
        			sb.append("|");
        		
        				if(father_pid == null){
        					sb.append("<null>");
        				}else{
            				sb.append(father_pid);
            			}
            		
        			sb.append("|");
        		
        				if(root_pid == null){
        					sb.append("<null>");
        				}else{
            				sb.append(root_pid);
            			}
            		
        			sb.append("|");
        		
        				if(system_pid == null){
        					sb.append("<null>");
        				}else{
            				sb.append(system_pid);
            			}
            		
        			sb.append("|");
        		
        				if(project == null){
        					sb.append("<null>");
        				}else{
            				sb.append(project);
            			}
            		
        			sb.append("|");
        		
        				if(job == null){
        					sb.append("<null>");
        				}else{
            				sb.append(job);
            			}
            		
        			sb.append("|");
        		
        				if(job_repository_id == null){
        					sb.append("<null>");
        				}else{
            				sb.append(job_repository_id);
            			}
            		
        			sb.append("|");
        		
        				if(job_version == null){
        					sb.append("<null>");
        				}else{
            				sb.append(job_version);
            			}
            		
        			sb.append("|");
        		
        				if(context == null){
        					sb.append("<null>");
        				}else{
            				sb.append(context);
            			}
            		
        			sb.append("|");
        		
        				if(origin == null){
        					sb.append("<null>");
        				}else{
            				sb.append(origin);
            			}
            		
        			sb.append("|");
        		
        				if(label == null){
        					sb.append("<null>");
        				}else{
            				sb.append(label);
            			}
            		
        			sb.append("|");
        		
        				if(count == null){
        					sb.append("<null>");
        				}else{
            				sb.append(count);
            			}
            		
        			sb.append("|");
        		
        				if(reference == null){
        					sb.append("<null>");
        				}else{
            				sb.append(reference);
            			}
            		
        			sb.append("|");
        		
        				if(thresholds == null){
        					sb.append("<null>");
        				}else{
            				sb.append(thresholds);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(row_talendMeter_METTERStruct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}
public void talendMeter_METTERProcess(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("talendMeter_METTER_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
		String currentVirtualComponent = null;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;



		row_talendMeter_METTERStruct row_talendMeter_METTER = new row_talendMeter_METTERStruct();




	
	/**
	 * [talendMeter_CONSOLE begin ] start
	 */

	

	
		
		ok_Hash.put("talendMeter_CONSOLE", false);
		start_Hash.put("talendMeter_CONSOLE", System.currentTimeMillis());
		
	
		currentVirtualComponent = "talendMeter_CONSOLE";
	
	currentComponent="talendMeter_CONSOLE";

	
			if (execStat) {
				if(resourceMap.get("inIterateVComp") == null){
					
						runStat.updateStatOnConnection("Main" + iterateId, 0, 0);
					
				}
			} 

		
		int tos_count_talendMeter_CONSOLE = 0;
		
                if(log.isDebugEnabled())
            log.debug("talendMeter_CONSOLE - "  + ("Start to work.") );
    	class BytesLimit65535_talendMeter_CONSOLE{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_talendMeter_CONSOLE = new StringBuilder();
            log4jParamters_talendMeter_CONSOLE.append("Parameters:");
                    log4jParamters_talendMeter_CONSOLE.append("BASIC_MODE" + " = " + "true");
                log4jParamters_talendMeter_CONSOLE.append(" | ");
                    log4jParamters_talendMeter_CONSOLE.append("TABLE_PRINT" + " = " + "false");
                log4jParamters_talendMeter_CONSOLE.append(" | ");
                    log4jParamters_talendMeter_CONSOLE.append("VERTICAL" + " = " + "false");
                log4jParamters_talendMeter_CONSOLE.append(" | ");
                    log4jParamters_talendMeter_CONSOLE.append("FIELDSEPARATOR" + " = " + "\"|\"");
                log4jParamters_talendMeter_CONSOLE.append(" | ");
                    log4jParamters_talendMeter_CONSOLE.append("PRINT_HEADER" + " = " + "false");
                log4jParamters_talendMeter_CONSOLE.append(" | ");
                    log4jParamters_talendMeter_CONSOLE.append("PRINT_UNIQUE_NAME" + " = " + "false");
                log4jParamters_talendMeter_CONSOLE.append(" | ");
                    log4jParamters_talendMeter_CONSOLE.append("PRINT_COLNAMES" + " = " + "false");
                log4jParamters_talendMeter_CONSOLE.append(" | ");
                    log4jParamters_talendMeter_CONSOLE.append("USE_FIXED_LENGTH" + " = " + "false");
                log4jParamters_talendMeter_CONSOLE.append(" | ");
                    log4jParamters_talendMeter_CONSOLE.append("PRINT_CONTENT_WITH_LOG4J" + " = " + "true");
                log4jParamters_talendMeter_CONSOLE.append(" | ");
                if(log.isDebugEnabled())
            log.debug("talendMeter_CONSOLE - "  + (log4jParamters_talendMeter_CONSOLE) );
    		}
    	}
    	
        new BytesLimit65535_talendMeter_CONSOLE().limitLog4jByte();

	///////////////////////
	
		final String OUTPUT_FIELD_SEPARATOR_talendMeter_CONSOLE = "|";
		java.io.PrintStream consoleOut_talendMeter_CONSOLE = null;	

 		StringBuilder strBuffer_talendMeter_CONSOLE = null;
		int nb_line_talendMeter_CONSOLE = 0;
///////////////////////    			



 



/**
 * [talendMeter_CONSOLE begin ] stop
 */



	
	/**
	 * [talendMeter_METTER begin ] start
	 */

	

	
		
		ok_Hash.put("talendMeter_METTER", false);
		start_Hash.put("talendMeter_METTER", System.currentTimeMillis());
		
	
		currentVirtualComponent = "talendMeter_METTER";
	
	currentComponent="talendMeter_METTER";

	
		int tos_count_talendMeter_METTER = 0;
		
                if(log.isDebugEnabled())
            log.debug("talendMeter_METTER - "  + ("Start to work.") );
    	class BytesLimit65535_talendMeter_METTER{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_talendMeter_METTER = new StringBuilder();
            log4jParamters_talendMeter_METTER.append("Parameters:");
                if(log.isDebugEnabled())
            log.debug("talendMeter_METTER - "  + (log4jParamters_talendMeter_METTER) );
    		}
    	}
    	
        new BytesLimit65535_talendMeter_METTER().limitLog4jByte();

	for (MetterCatcherUtils.MetterCatcherMessage mcm : talendMeter_METTER.getMessages()) {
		row_talendMeter_METTER.pid = pid;
		row_talendMeter_METTER.root_pid = rootPid;
		row_talendMeter_METTER.father_pid = fatherPid;	
        row_talendMeter_METTER.project = projectName;
        row_talendMeter_METTER.job = jobName;
        row_talendMeter_METTER.context = contextStr;
		row_talendMeter_METTER.origin = (mcm.getOrigin()==null || mcm.getOrigin().length()<1 ? null : mcm.getOrigin());
		row_talendMeter_METTER.moment = mcm.getMoment();
		row_talendMeter_METTER.job_version = mcm.getJobVersion();
		row_talendMeter_METTER.job_repository_id = mcm.getJobId();
		row_talendMeter_METTER.system_pid = mcm.getSystemPid();
		row_talendMeter_METTER.label = mcm.getLabel();
		row_talendMeter_METTER.count = mcm.getCount();
		row_talendMeter_METTER.reference = talendMeter_METTER.getConnLinesCount(mcm.getReferense()+"_count");
		row_talendMeter_METTER.thresholds = mcm.getThresholds();
		

 



/**
 * [talendMeter_METTER begin ] stop
 */
	
	/**
	 * [talendMeter_METTER main ] start
	 */

	

	
	
		currentVirtualComponent = "talendMeter_METTER";
	
	currentComponent="talendMeter_METTER";

	

 


	tos_count_talendMeter_METTER++;

/**
 * [talendMeter_METTER main ] stop
 */

	
	/**
	 * [talendMeter_CONSOLE main ] start
	 */

	

	
	
		currentVirtualComponent = "talendMeter_CONSOLE";
	
	currentComponent="talendMeter_CONSOLE";

	

			//Main
			//row_talendMeter_METTER


			
				if(execStat){
					runStat.updateStatOnConnection("Main"+iterateId,1, 1);
				} 
			

		
///////////////////////		
						



				strBuffer_talendMeter_CONSOLE = new StringBuilder();




   				
	    		if(row_talendMeter_METTER.moment != null) { //              
                    							
       
				strBuffer_talendMeter_CONSOLE.append(
								FormatterUtils.format_Date(row_talendMeter_METTER.moment, "yyyy-MM-dd HH:mm:ss")				
				);


							
	    		} //  			

    			strBuffer_talendMeter_CONSOLE.append("|");
    			


   				
	    		if(row_talendMeter_METTER.pid != null) { //              
                    							
       
				strBuffer_talendMeter_CONSOLE.append(
				                String.valueOf(row_talendMeter_METTER.pid)							
				);


							
	    		} //  			

    			strBuffer_talendMeter_CONSOLE.append("|");
    			


   				
	    		if(row_talendMeter_METTER.father_pid != null) { //              
                    							
       
				strBuffer_talendMeter_CONSOLE.append(
				                String.valueOf(row_talendMeter_METTER.father_pid)							
				);


							
	    		} //  			

    			strBuffer_talendMeter_CONSOLE.append("|");
    			


   				
	    		if(row_talendMeter_METTER.root_pid != null) { //              
                    							
       
				strBuffer_talendMeter_CONSOLE.append(
				                String.valueOf(row_talendMeter_METTER.root_pid)							
				);


							
	    		} //  			

    			strBuffer_talendMeter_CONSOLE.append("|");
    			


   				
	    		if(row_talendMeter_METTER.system_pid != null) { //              
                    							
       
				strBuffer_talendMeter_CONSOLE.append(
				                String.valueOf(row_talendMeter_METTER.system_pid)							
				);


							
	    		} //  			

    			strBuffer_talendMeter_CONSOLE.append("|");
    			


   				
	    		if(row_talendMeter_METTER.project != null) { //              
                    							
       
				strBuffer_talendMeter_CONSOLE.append(
				                String.valueOf(row_talendMeter_METTER.project)							
				);


							
	    		} //  			

    			strBuffer_talendMeter_CONSOLE.append("|");
    			


   				
	    		if(row_talendMeter_METTER.job != null) { //              
                    							
       
				strBuffer_talendMeter_CONSOLE.append(
				                String.valueOf(row_talendMeter_METTER.job)							
				);


							
	    		} //  			

    			strBuffer_talendMeter_CONSOLE.append("|");
    			


   				
	    		if(row_talendMeter_METTER.job_repository_id != null) { //              
                    							
       
				strBuffer_talendMeter_CONSOLE.append(
				                String.valueOf(row_talendMeter_METTER.job_repository_id)							
				);


							
	    		} //  			

    			strBuffer_talendMeter_CONSOLE.append("|");
    			


   				
	    		if(row_talendMeter_METTER.job_version != null) { //              
                    							
       
				strBuffer_talendMeter_CONSOLE.append(
				                String.valueOf(row_talendMeter_METTER.job_version)							
				);


							
	    		} //  			

    			strBuffer_talendMeter_CONSOLE.append("|");
    			


   				
	    		if(row_talendMeter_METTER.context != null) { //              
                    							
       
				strBuffer_talendMeter_CONSOLE.append(
				                String.valueOf(row_talendMeter_METTER.context)							
				);


							
	    		} //  			

    			strBuffer_talendMeter_CONSOLE.append("|");
    			


   				
	    		if(row_talendMeter_METTER.origin != null) { //              
                    							
       
				strBuffer_talendMeter_CONSOLE.append(
				                String.valueOf(row_talendMeter_METTER.origin)							
				);


							
	    		} //  			

    			strBuffer_talendMeter_CONSOLE.append("|");
    			


   				
	    		if(row_talendMeter_METTER.label != null) { //              
                    							
       
				strBuffer_talendMeter_CONSOLE.append(
				                String.valueOf(row_talendMeter_METTER.label)							
				);


							
	    		} //  			

    			strBuffer_talendMeter_CONSOLE.append("|");
    			


   				
	    		if(row_talendMeter_METTER.count != null) { //              
                    							
       
				strBuffer_talendMeter_CONSOLE.append(
				                String.valueOf(row_talendMeter_METTER.count)							
				);


							
	    		} //  			

    			strBuffer_talendMeter_CONSOLE.append("|");
    			


   				
	    		if(row_talendMeter_METTER.reference != null) { //              
                    							
       
				strBuffer_talendMeter_CONSOLE.append(
				                String.valueOf(row_talendMeter_METTER.reference)							
				);


							
	    		} //  			

    			strBuffer_talendMeter_CONSOLE.append("|");
    			


   				
	    		if(row_talendMeter_METTER.thresholds != null) { //              
                    							
       
				strBuffer_talendMeter_CONSOLE.append(
				                String.valueOf(row_talendMeter_METTER.thresholds)							
				);


							
	    		} //  			
 

                    if (globalMap.get("tLogRow_CONSOLE")!=null)
                    {
                    	consoleOut_talendMeter_CONSOLE = (java.io.PrintStream) globalMap.get("tLogRow_CONSOLE");
                    }
                    else
                    {
                    	consoleOut_talendMeter_CONSOLE = new java.io.PrintStream(new java.io.BufferedOutputStream(System.out));
                    	globalMap.put("tLogRow_CONSOLE",consoleOut_talendMeter_CONSOLE);
                    }
                    	log.info("talendMeter_CONSOLE - Content of row "+(nb_line_talendMeter_CONSOLE+1)+": " + strBuffer_talendMeter_CONSOLE.toString());
                    consoleOut_talendMeter_CONSOLE.println(strBuffer_talendMeter_CONSOLE.toString());
                    consoleOut_talendMeter_CONSOLE.flush();
                    nb_line_talendMeter_CONSOLE++;
//////

//////                    
                    
///////////////////////    			

 


	tos_count_talendMeter_CONSOLE++;

/**
 * [talendMeter_CONSOLE main ] stop
 */



	
	/**
	 * [talendMeter_METTER end ] start
	 */

	

	
	
		currentVirtualComponent = "talendMeter_METTER";
	
	currentComponent="talendMeter_METTER";

	

	}


 
                if(log.isDebugEnabled())
            log.debug("talendMeter_METTER - "  + ("Done.") );

ok_Hash.put("talendMeter_METTER", true);
end_Hash.put("talendMeter_METTER", System.currentTimeMillis());




/**
 * [talendMeter_METTER end ] stop
 */

	
	/**
	 * [talendMeter_CONSOLE end ] start
	 */

	

	
	
		currentVirtualComponent = "talendMeter_CONSOLE";
	
	currentComponent="talendMeter_CONSOLE";

	


//////
//////
globalMap.put("talendMeter_CONSOLE_NB_LINE",nb_line_talendMeter_CONSOLE);
                if(log.isInfoEnabled())
            log.info("talendMeter_CONSOLE - "  + ("Printed row count: ")  + (nb_line_talendMeter_CONSOLE)  + (".") );

///////////////////////    			

			if(execStat){
				if(resourceMap.get("inIterateVComp") == null || !((Boolean)resourceMap.get("inIterateVComp"))){
			 		runStat.updateStatOnConnection("Main"+iterateId,2, 0); 
			 	}
			}
		
 
                if(log.isDebugEnabled())
            log.debug("talendMeter_CONSOLE - "  + ("Done.") );

ok_Hash.put("talendMeter_CONSOLE", true);
end_Hash.put("talendMeter_CONSOLE", System.currentTimeMillis());




/**
 * [talendMeter_CONSOLE end ] stop
 */



				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage());
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
					te.setVirtualComponentName(currentVirtualComponent);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [talendMeter_METTER finally ] start
	 */

	

	
	
		currentVirtualComponent = "talendMeter_METTER";
	
	currentComponent="talendMeter_METTER";

	

 



/**
 * [talendMeter_METTER finally ] stop
 */

	
	/**
	 * [talendMeter_CONSOLE finally ] start
	 */

	

	
	
		currentVirtualComponent = "talendMeter_CONSOLE";
	
	currentComponent="talendMeter_CONSOLE";

	

 



/**
 * [talendMeter_CONSOLE finally ] stop
 */



				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("talendMeter_METTER_SUBPROCESS_STATE", 1);
	}
	
    public String resuming_logs_dir_path = null;
    public String resuming_checkpoint_path = null;
    public String parent_part_launcher = null;
    private String resumeEntryMethodName = null;
    private boolean globalResumeTicket = false;

    public boolean watch = false;
    // portStats is null, it means don't execute the statistics
    public Integer portStats = null;
    public int portTraces = 4334;
    public String clientHost;
    public String defaultClientHost = "localhost";
    public String contextStr = "SOURCING_PROD";
    public boolean isDefaultContext = true;
    public String pid = "0";
    public String rootPid = null;
    public String fatherPid = null;
    public String fatherNode = null;
    public long startTime = 0;
    public boolean isChildJob = false;
    public String log4jLevel = "";

    private boolean execStat = true;

    private ThreadLocal<java.util.Map<String, String>> threadLocal = new ThreadLocal<java.util.Map<String, String>>() {
        protected java.util.Map<String, String> initialValue() {
            java.util.Map<String,String> threadRunResultMap = new java.util.HashMap<String, String>();
            threadRunResultMap.put("errorCode", null);
            threadRunResultMap.put("status", "");
            return threadRunResultMap;
        };
    };



    private java.util.Properties context_param = new java.util.Properties();
    public java.util.Map<String, Object> parentContextMap = new java.util.HashMap<String, Object>();

    public String status= "";

    public static void main(String[] args){
        final EDL_Get_Execution_Statistics_prd2dev_GP EDL_Get_Execution_Statistics_prd2dev_GPClass = new EDL_Get_Execution_Statistics_prd2dev_GP();

        int exitCode = EDL_Get_Execution_Statistics_prd2dev_GPClass.runJobInTOS(args);
	        if(exitCode==0){
		        log.info("TalendJob: 'EDL_Get_Execution_Statistics_prd2dev_GP' - Done.");
	        }

        System.exit(exitCode);
    }


    public String[][] runJob(String[] args) {

        int exitCode = runJobInTOS(args);
        String[][] bufferValue = new String[][] { { Integer.toString(exitCode) } };

        return bufferValue;
    }

    public boolean hastBufferOutputComponent() {
		boolean hastBufferOutput = false;
    	
        return hastBufferOutput;
    }

    public int runJobInTOS(String[] args) {
	   	// reset status
	   	status = "";

        String lastStr = "";
        for (String arg : args) {
            if (arg.equalsIgnoreCase("--context_param")) {
                lastStr = arg;
            } else if (lastStr.equals("")) {
                evalParam(arg);
            } else {
                evalParam(lastStr + " " + arg);
                lastStr = "";
            }
        }

	        if(!"".equals(log4jLevel)){
				if("trace".equalsIgnoreCase(log4jLevel)){
					log.setLevel(org.apache.log4j.Level.TRACE);
				}else if("debug".equalsIgnoreCase(log4jLevel)){
					log.setLevel(org.apache.log4j.Level.DEBUG);
				}else if("info".equalsIgnoreCase(log4jLevel)){
					log.setLevel(org.apache.log4j.Level.INFO);
				}else if("warn".equalsIgnoreCase(log4jLevel)){
					log.setLevel(org.apache.log4j.Level.WARN);
				}else if("error".equalsIgnoreCase(log4jLevel)){
					log.setLevel(org.apache.log4j.Level.ERROR);
				}else if("fatal".equalsIgnoreCase(log4jLevel)){
					log.setLevel(org.apache.log4j.Level.FATAL);
				}else if ("off".equalsIgnoreCase(log4jLevel)){
					log.setLevel(org.apache.log4j.Level.OFF);
				}
				org.apache.log4j.Logger.getRootLogger().setLevel(log.getLevel());
    	    }
        	log.info("TalendJob: 'EDL_Get_Execution_Statistics_prd2dev_GP' - Start.");
    	

        if(clientHost == null) {
            clientHost = defaultClientHost;
        }

        if(pid == null || "0".equals(pid)) {
            pid = TalendString.getAsciiRandomString(6);
        }

        if (rootPid==null) {
            rootPid = pid;
        }
        if (fatherPid==null) {
            fatherPid = pid;
        }else{
            isChildJob = true;
        }

        if (portStats != null) {
            // portStats = -1; //for testing
            if (portStats < 0 || portStats > 65535) {
                // issue:10869, the portStats is invalid, so this client socket can't open
                System.err.println("The statistics socket port " + portStats + " is invalid.");
                execStat = false;
            }
        } else {
            execStat = false;
        }

        try {
            //call job/subjob with an existing context, like: --context=production. if without this parameter, there will use the default context instead.
            java.io.InputStream inContext = EDL_Get_Execution_Statistics_prd2dev_GP.class.getClassLoader().getResourceAsStream("aws_dev_talend_ingestion_framework/edl_get_execution_statistics_prd2dev_gp_0_1/contexts/"+contextStr+".properties");
            if(isDefaultContext && inContext ==null) {

            } else {
                if (inContext!=null) {
                    //defaultProps is in order to keep the original context value
                    defaultProps.load(inContext);
                    inContext.close();
                    context = new ContextProperties(defaultProps);
                }else{
                    //print info and job continue to run, for case: context_param is not empty.
                    System.err.println("Could not find the context " + contextStr);
                }
            }

            if(!context_param.isEmpty()) {
                context.putAll(context_param);
            }
             try{
                 context.RUN_ID=routines.system.ParserUtils.parseTo_Integer (context.getProperty("RUN_ID"));
             }catch(NumberFormatException e){
                 context.RUN_ID=null;
              }
                context.mail_bcc=(String) context.getProperty("mail_bcc");
                context.mail_body_text=(String) context.getProperty("mail_body_text");
                context.mail_cc=(String) context.getProperty("mail_cc");
                context.GP_SOURCE_NAME=(String) context.getProperty("GP_SOURCE_NAME");
                context.PUBLIC=(String) context.getProperty("PUBLIC");
                context.mail_to_public=(String) context.getProperty("mail_to_public");
                context.JOB_LABEL_NAME=(String) context.getProperty("JOB_LABEL_NAME");
                context.mail_from=(String) context.getProperty("mail_from");
                context.mail_sender_name=(String) context.getProperty("mail_sender_name");
                context.MAIL_TO=(String) context.getProperty("MAIL_TO");
                context.SOURCE_DATABASE=(String) context.getProperty("SOURCE_DATABASE");
                context.SOURCE_HOST=(String) context.getProperty("SOURCE_HOST");
            		String pwd_SOURCE_PASSWORD_value = context.getProperty("SOURCE_PASSWORD");
            		context.SOURCE_PASSWORD = null;
            		if(pwd_SOURCE_PASSWORD_value!=null) {
            			if(context_param.containsKey("SOURCE_PASSWORD")) {//no need to decrypt if it come from program argument or parent job runtime
            				context.SOURCE_PASSWORD = pwd_SOURCE_PASSWORD_value;
            			} else if (!pwd_SOURCE_PASSWORD_value.isEmpty()) {
            				try {
            					context.SOURCE_PASSWORD = routines.system.PasswordEncryptUtil.decryptPassword(pwd_SOURCE_PASSWORD_value);
            					context.put("SOURCE_PASSWORD",context.SOURCE_PASSWORD);
            				} catch (java.lang.RuntimeException e) {
            					//do nothing
            				}
            			}
            		}
             try{
                 context.SOURCE_PORT=routines.system.ParserUtils.parseTo_Integer (context.getProperty("SOURCE_PORT"));
             }catch(NumberFormatException e){
                 context.SOURCE_PORT=null;
              }
                context.SOURCE_USER=(String) context.getProperty("SOURCE_USER");
                context.smtp=(String) context.getProperty("smtp");
             try{
                 context.smtp_port=routines.system.ParserUtils.parseTo_Integer (context.getProperty("smtp_port"));
             }catch(NumberFormatException e){
                 context.smtp_port=null;
              }
                context.SOURCING_Database=(String) context.getProperty("SOURCING_Database");
                context.SOURCING_Login=(String) context.getProperty("SOURCING_Login");
            		String pwd_SOURCING_Password_value = context.getProperty("SOURCING_Password");
            		context.SOURCING_Password = null;
            		if(pwd_SOURCING_Password_value!=null) {
            			if(context_param.containsKey("SOURCING_Password")) {//no need to decrypt if it come from program argument or parent job runtime
            				context.SOURCING_Password = pwd_SOURCING_Password_value;
            			} else if (!pwd_SOURCING_Password_value.isEmpty()) {
            				try {
            					context.SOURCING_Password = routines.system.PasswordEncryptUtil.decryptPassword(pwd_SOURCING_Password_value);
            					context.put("SOURCING_Password",context.SOURCING_Password);
            				} catch (java.lang.RuntimeException e) {
            					//do nothing
            				}
            			}
            		}
                context.SOURCING_Port=(String) context.getProperty("SOURCING_Port");
                context.SOURCING_Schema=(String) context.getProperty("SOURCING_Schema");
                context.SOURCING_Server=(String) context.getProperty("SOURCING_Server");
        } catch (java.io.IOException ie) {
            System.err.println("Could not load context "+contextStr);
            ie.printStackTrace();
        }


        // get context value from parent directly
        if (parentContextMap != null && !parentContextMap.isEmpty()) {if (parentContextMap.containsKey("RUN_ID")) {
                context.RUN_ID = (Integer) parentContextMap.get("RUN_ID");
            }if (parentContextMap.containsKey("mail_bcc")) {
                context.mail_bcc = (String) parentContextMap.get("mail_bcc");
            }if (parentContextMap.containsKey("mail_body_text")) {
                context.mail_body_text = (String) parentContextMap.get("mail_body_text");
            }if (parentContextMap.containsKey("mail_cc")) {
                context.mail_cc = (String) parentContextMap.get("mail_cc");
            }if (parentContextMap.containsKey("GP_SOURCE_NAME")) {
                context.GP_SOURCE_NAME = (String) parentContextMap.get("GP_SOURCE_NAME");
            }if (parentContextMap.containsKey("PUBLIC")) {
                context.PUBLIC = (String) parentContextMap.get("PUBLIC");
            }if (parentContextMap.containsKey("mail_to_public")) {
                context.mail_to_public = (String) parentContextMap.get("mail_to_public");
            }if (parentContextMap.containsKey("JOB_LABEL_NAME")) {
                context.JOB_LABEL_NAME = (String) parentContextMap.get("JOB_LABEL_NAME");
            }if (parentContextMap.containsKey("mail_from")) {
                context.mail_from = (String) parentContextMap.get("mail_from");
            }if (parentContextMap.containsKey("mail_sender_name")) {
                context.mail_sender_name = (String) parentContextMap.get("mail_sender_name");
            }if (parentContextMap.containsKey("MAIL_TO")) {
                context.MAIL_TO = (String) parentContextMap.get("MAIL_TO");
            }if (parentContextMap.containsKey("SOURCE_DATABASE")) {
                context.SOURCE_DATABASE = (String) parentContextMap.get("SOURCE_DATABASE");
            }if (parentContextMap.containsKey("SOURCE_HOST")) {
                context.SOURCE_HOST = (String) parentContextMap.get("SOURCE_HOST");
            }if (parentContextMap.containsKey("SOURCE_PASSWORD")) {
                context.SOURCE_PASSWORD = (java.lang.String) parentContextMap.get("SOURCE_PASSWORD");
            }if (parentContextMap.containsKey("SOURCE_PORT")) {
                context.SOURCE_PORT = (Integer) parentContextMap.get("SOURCE_PORT");
            }if (parentContextMap.containsKey("SOURCE_USER")) {
                context.SOURCE_USER = (String) parentContextMap.get("SOURCE_USER");
            }if (parentContextMap.containsKey("smtp")) {
                context.smtp = (String) parentContextMap.get("smtp");
            }if (parentContextMap.containsKey("smtp_port")) {
                context.smtp_port = (Integer) parentContextMap.get("smtp_port");
            }if (parentContextMap.containsKey("SOURCING_Database")) {
                context.SOURCING_Database = (String) parentContextMap.get("SOURCING_Database");
            }if (parentContextMap.containsKey("SOURCING_Login")) {
                context.SOURCING_Login = (String) parentContextMap.get("SOURCING_Login");
            }if (parentContextMap.containsKey("SOURCING_Password")) {
                context.SOURCING_Password = (java.lang.String) parentContextMap.get("SOURCING_Password");
            }if (parentContextMap.containsKey("SOURCING_Port")) {
                context.SOURCING_Port = (String) parentContextMap.get("SOURCING_Port");
            }if (parentContextMap.containsKey("SOURCING_Schema")) {
                context.SOURCING_Schema = (String) parentContextMap.get("SOURCING_Schema");
            }if (parentContextMap.containsKey("SOURCING_Server")) {
                context.SOURCING_Server = (String) parentContextMap.get("SOURCING_Server");
            }
        }

        //Resume: init the resumeUtil
        resumeEntryMethodName = ResumeUtil.getResumeEntryMethodName(resuming_checkpoint_path);
        resumeUtil = new ResumeUtil(resuming_logs_dir_path, isChildJob, rootPid);
        resumeUtil.initCommonInfo(pid, rootPid, fatherPid, projectName, jobName, contextStr, jobVersion);

		List<String> parametersToEncrypt = new java.util.ArrayList<String>();
			parametersToEncrypt.add("SOURCE_PASSWORD");
			parametersToEncrypt.add("SOURCING_Password");
        //Resume: jobStart
        resumeUtil.addLog("JOB_STARTED", "JOB:" + jobName, parent_part_launcher, Thread.currentThread().getId() + "", "","","","",resumeUtil.convertToJsonText(context,parametersToEncrypt));

if(execStat) {
    try {
        runStat.openSocket(!isChildJob);
        runStat.setAllPID(rootPid, fatherPid, pid, jobName);
        runStat.startThreadStat(clientHost, portStats);
        runStat.updateStatOnJob(RunStat.JOBSTART, fatherNode);
    } catch (java.io.IOException ioException) {
        ioException.printStackTrace();
    }
}



	
	    java.util.concurrent.ConcurrentHashMap<Object, Object> concurrentHashMap = new java.util.concurrent.ConcurrentHashMap<Object, Object>();
	    globalMap.put("concurrentHashMap", concurrentHashMap);
	

    long startUsedMemory = Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory();
    long endUsedMemory = 0;
    long end = 0;

    startTime = System.currentTimeMillis();
        talendStats_STATS.addMessage("begin");


this.globalResumeTicket = true;//to run tPreJob



        try {
            talendStats_STATSProcess(globalMap);
        } catch (java.lang.Exception e) {
            e.printStackTrace();
        }

this.globalResumeTicket = false;//to run others jobs

try {
errorCode = null;tSetGlobalVar_1Process(globalMap);
if(!"failure".equals(status)) { status = "end"; }
}catch (TalendException e_tSetGlobalVar_1) {
globalMap.put("tSetGlobalVar_1_SUBPROCESS_STATE", -1);

e_tSetGlobalVar_1.printStackTrace();

}

this.globalResumeTicket = true;//to run tPostJob




        end = System.currentTimeMillis();

        if (watch) {
            System.out.println((end-startTime)+" milliseconds");
        }

        endUsedMemory = Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory();
        if (false) {
            System.out.println((endUsedMemory - startUsedMemory) + " bytes memory increase when running : EDL_Get_Execution_Statistics_prd2dev_GP");
        }
        talendStats_STATS.addMessage(status==""?"end":status, (end-startTime));
        try {
            talendStats_STATSProcess(globalMap);
        } catch (java.lang.Exception e) {
            e.printStackTrace();
        }





if (execStat) {
    runStat.updateStatOnJob(RunStat.JOBEND, fatherNode);
    runStat.stopThreadStat();
}
    int returnCode = 0;
    if(errorCode == null) {
         returnCode = status != null && status.equals("failure") ? 1 : 0;
    } else {
         returnCode = errorCode.intValue();
    }
    resumeUtil.addLog("JOB_ENDED", "JOB:" + jobName, parent_part_launcher, Thread.currentThread().getId() + "", "","" + returnCode,"","","");

    return returnCode;

  }

    // only for OSGi env
    public void destroy() {
    closeSqlDbConnections();


    }



    private void closeSqlDbConnections() {
        try {
            Object obj_conn;
            obj_conn = globalMap.remove("conn_tGreenplumConnection_1");
            if (null != obj_conn) {
                ((java.sql.Connection) obj_conn).close();
            }
        } catch (java.lang.Exception e) {
        }
    }

		









    private java.util.Map<String, Object> getSharedConnections4REST() {
        java.util.Map<String, Object> connections = new java.util.HashMap<String, Object>();
            connections.put("conn_tGreenplumConnection_1", globalMap.get("conn_tGreenplumConnection_1"));






        return connections;
    }

    private void evalParam(String arg) {
        if (arg.startsWith("--resuming_logs_dir_path")) {
            resuming_logs_dir_path = arg.substring(25);
        } else if (arg.startsWith("--resuming_checkpoint_path")) {
            resuming_checkpoint_path = arg.substring(27);
        } else if (arg.startsWith("--parent_part_launcher")) {
            parent_part_launcher = arg.substring(23);
        } else if (arg.startsWith("--watch")) {
            watch = true;
        } else if (arg.startsWith("--stat_port=")) {
            String portStatsStr = arg.substring(12);
            if (portStatsStr != null && !portStatsStr.equals("null")) {
                portStats = Integer.parseInt(portStatsStr);
            }
        } else if (arg.startsWith("--trace_port=")) {
            portTraces = Integer.parseInt(arg.substring(13));
        } else if (arg.startsWith("--client_host=")) {
            clientHost = arg.substring(14);
        } else if (arg.startsWith("--context=")) {
            contextStr = arg.substring(10);
            isDefaultContext = false;
        } else if (arg.startsWith("--father_pid=")) {
            fatherPid = arg.substring(13);
        } else if (arg.startsWith("--root_pid=")) {
            rootPid = arg.substring(11);
        } else if (arg.startsWith("--father_node=")) {
            fatherNode = arg.substring(14);
        } else if (arg.startsWith("--pid=")) {
            pid = arg.substring(6);
        } else if (arg.startsWith("--context_param")) {
            String keyValue = arg.substring(16);
            int index = -1;
            if (keyValue != null && (index = keyValue.indexOf('=')) > -1) {
                if (fatherPid==null) {
                    context_param.put(keyValue.substring(0, index), replaceEscapeChars(keyValue.substring(index + 1)));
                } else { // the subjob won't escape the especial chars
                    context_param.put(keyValue.substring(0, index), keyValue.substring(index + 1) );
                }
            }
        }else if (arg.startsWith("--log4jLevel=")) {
            log4jLevel = arg.substring(13);
		}

    }

    private final String[][] escapeChars = {
        {"\\\\","\\"},{"\\n","\n"},{"\\'","\'"},{"\\r","\r"},
        {"\\f","\f"},{"\\b","\b"},{"\\t","\t"}
        };
    private String replaceEscapeChars (String keyValue) {

		if (keyValue == null || ("").equals(keyValue.trim())) {
			return keyValue;
		}

		StringBuilder result = new StringBuilder();
		int currIndex = 0;
		while (currIndex < keyValue.length()) {
			int index = -1;
			// judege if the left string includes escape chars
			for (String[] strArray : escapeChars) {
				index = keyValue.indexOf(strArray[0],currIndex);
				if (index>=0) {

					result.append(keyValue.substring(currIndex, index + strArray[0].length()).replace(strArray[0], strArray[1]));
					currIndex = index + strArray[0].length();
					break;
				}
			}
			// if the left string doesn't include escape chars, append the left into the result
			if (index < 0) {
				result.append(keyValue.substring(currIndex));
				currIndex = currIndex + keyValue.length();
			}
		}

		return result.toString();
    }

    public Integer getErrorCode() {
        return errorCode;
    }


    public String getStatus() {
        return status;
    }

    ResumeUtil resumeUtil = null;
}
/************************************************************************************************
 *     237359 characters generated by Talend Real-time Big Data Platform 
 *     on the October 19, 2018 3:30:22 PM CDT
 ************************************************************************************************/