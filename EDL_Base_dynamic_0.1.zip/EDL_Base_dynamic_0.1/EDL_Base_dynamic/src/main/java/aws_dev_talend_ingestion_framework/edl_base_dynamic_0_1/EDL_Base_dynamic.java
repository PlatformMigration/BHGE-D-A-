
package aws_dev_talend_ingestion_framework.edl_base_dynamic_0_1;

import routines.GEPostgreSQLViewConverter;
import routines.DataOperation;
import routines.TalendDataGenerator;
import routines.GEDynamicRoutine;
import routines.DataQuality;
import routines.GEDynamicRoutine_masking;
import routines.Relational;
import routines.GEroutines;
import routines.Mathematical;
import routines.DataQualityDependencies;
import routines.SQLike;
import routines.DataTypeMaps;
import routines.Numeric;
import routines.TalendString;
import routines.TransformMetadata;
import routines.DQTechnical;
import routines.MDM;
import routines.StringHandling;
import routines.TalendDate;
import routines.DataMasking;
import routines.DqStringHandling;
import routines.PopulateFromDynamic;
import routines.GPLoadRoutine;
import routines.system.*;
import routines.system.api.*;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.math.BigDecimal;
import java.io.ByteArrayOutputStream;
import java.io.ByteArrayInputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.ObjectOutputStream;
import java.io.ObjectInputStream;
import java.io.IOException;
import java.util.Comparator;
 




	//the import part of tJava_1
	//import java.util.List;

	//the import part of tJava_2
	//import java.util.List;

	//the import part of tJavaRow_3
	//import java.util.List;

	//the import part of tJava_6
	//import java.util.List;

	//the import part of tJavaRow_2
	//import java.util.List;

	//the import part of tJava_13
	//import java.util.List;

	//the import part of tJava_7
	//import java.util.List;

	//the import part of tJavaRow_4
	//import java.util.List;

	//the import part of tJava_8
	//import java.util.List;

	//the import part of tJava_10
	//import java.util.List;

	//the import part of tJava_9
	//import java.util.List;

	//the import part of tJava_14
	//import java.util.List;

	//the import part of tJava_15
	//import java.util.List;


@SuppressWarnings("unused")

/**
 * Job: EDL_Base_dynamic Purpose: <br>
 * Description:  <br>
 * @author Talend, admin
 * @version 6.3.1.20161216_1026
 * @status 
 */
public class EDL_Base_dynamic implements TalendJob {
	static {System.setProperty("TalendJob.log", "EDL_Base_dynamic.log");}
	private static org.apache.log4j.Logger log = org.apache.log4j.Logger.getLogger(EDL_Base_dynamic.class);



	public final Object obj = new Object();

	// for transmiting parameters purpose
	private Object valueObject = null;

	public Object getValueObject() {
		return this.valueObject;
	}

	public void setValueObject(Object valueObject) {
		this.valueObject = valueObject;
	}
	private Object[] multiThreadLockWrite = new Object[0];
	
	private final static String defaultCharset = java.nio.charset.Charset.defaultCharset().name();

	
	private final static String utf8Charset = "UTF-8";

	// create and load default properties
	private java.util.Properties defaultProps = new java.util.Properties();
	// create application properties with default
	public class ContextProperties extends java.util.Properties {

		private static final long serialVersionUID = 1L;

		public ContextProperties(java.util.Properties properties){
			super(properties);
		}
		public ContextProperties(){
			super();
		}

		public void synchronizeContext(){
			
			if(GP_SOURCE_NAME != null){
				
					this.setProperty("GP_SOURCE_NAME", GP_SOURCE_NAME.toString());
				
			}
			
			if(TABLE_NAME != null){
				
					this.setProperty("TABLE_NAME", TABLE_NAME.toString());
				
			}
			
			if(FORCE_DROP != null){
				
					this.setProperty("FORCE_DROP", FORCE_DROP.toString());
				
			}
			
			if(FORCE_BATCH != null){
				
					this.setProperty("FORCE_BATCH", FORCE_BATCH.toString());
				
			}
			
			if(LOAD2HDFS != null){
				
					this.setProperty("LOAD2HDFS", LOAD2HDFS.toString());
				
			}
			
			if(SOURCE_HOST != null){
				
					this.setProperty("SOURCE_HOST", SOURCE_HOST.toString());
				
			}
			
			if(SOURCE_DATABASE != null){
				
					this.setProperty("SOURCE_DATABASE", SOURCE_DATABASE.toString());
				
			}
			
			if(SOURCE_USER != null){
				
					this.setProperty("SOURCE_USER", SOURCE_USER.toString());
				
			}
			
			if(SOURCE_PORT != null){
				
					this.setProperty("SOURCE_PORT", SOURCE_PORT.toString());
				
			}
			
			if(SOURCE_PASSWORD != null){
				
					this.setProperty("SOURCE_PASSWORD", SOURCE_PASSWORD.toString());
				
			}
			
			if(TOP_N_ROWS != null){
				
					this.setProperty("TOP_N_ROWS", TOP_N_ROWS.toString());
				
			}
			
			if(THREAD != null){
				
					this.setProperty("THREAD", THREAD.toString());
				
			}
			
			if(RUN_ID != null){
				
					this.setProperty("RUN_ID", RUN_ID.toString());
				
			}
			
			if(PROD2DEV != null){
				
					this.setProperty("PROD2DEV", PROD2DEV.toString());
				
			}
			
			if(SEND_MAIL != null){
				
					this.setProperty("SEND_MAIL", SEND_MAIL.toString());
				
			}
			
			if(PUBLIC != null){
				
					this.setProperty("PUBLIC", PUBLIC.toString());
				
			}
			
			if(PYTHON_NEEDED != null){
				
					this.setProperty("PYTHON_NEEDED", PYTHON_NEEDED.toString());
				
			}
			
			if(mail_to_error != null){
				
					this.setProperty("mail_to_error", mail_to_error.toString());
				
			}
			
			if(JOB_LABEL_NAME != null){
				
					this.setProperty("JOB_LABEL_NAME", JOB_LABEL_NAME.toString());
				
			}
			
			if(PLANT_NAME != null){
				
					this.setProperty("PLANT_NAME", PLANT_NAME.toString());
				
			}
			
			if(LOG_NO_OF_ERRORS != null){
				
					this.setProperty("LOG_NO_OF_ERRORS", LOG_NO_OF_ERRORS.toString());
				
			}
			
			if(LOG_PLANT_NAME != null){
				
					this.setProperty("LOG_PLANT_NAME", LOG_PLANT_NAME.toString());
				
			}
			
			if(LOG_NO_OF_UPDATES != null){
				
					this.setProperty("LOG_NO_OF_UPDATES", LOG_NO_OF_UPDATES.toString());
				
			}
			
			if(LOG_SOURCE_ROW_COUNT != null){
				
					this.setProperty("LOG_SOURCE_ROW_COUNT", LOG_SOURCE_ROW_COUNT.toString());
				
			}
			
			if(LOG_TECHNOLOGY != null){
				
					this.setProperty("LOG_TECHNOLOGY", LOG_TECHNOLOGY.toString());
				
			}
			
			if(LOG_TABLE_NAME != null){
				
					this.setProperty("LOG_TABLE_NAME", LOG_TABLE_NAME.toString());
				
			}
			
			if(LOG_NO_OF_INSERTS != null){
				
					this.setProperty("LOG_NO_OF_INSERTS", LOG_NO_OF_INSERTS.toString());
				
			}
			
			if(LOG_DATA_PATH != null){
				
					this.setProperty("LOG_DATA_PATH", LOG_DATA_PATH.toString());
				
			}
			
			if(LOG_NO_OF_DELETES != null){
				
					this.setProperty("LOG_NO_OF_DELETES", LOG_NO_OF_DELETES.toString());
				
			}
			
			if(LOG_RUN_ID != null){
				
					this.setProperty("LOG_RUN_ID", LOG_RUN_ID.toString());
				
			}
			
			if(LOG_ERROR_CATEGORY != null){
				
					this.setProperty("LOG_ERROR_CATEGORY", LOG_ERROR_CATEGORY.toString());
				
			}
			
			if(LOG_JOB_NAME != null){
				
					this.setProperty("LOG_JOB_NAME", LOG_JOB_NAME.toString());
				
			}
			
			if(LOG_SYSTEM_NAME != null){
				
					this.setProperty("LOG_SYSTEM_NAME", LOG_SYSTEM_NAME.toString());
				
			}
			
			if(LOG_MESSAGE != null){
				
					this.setProperty("LOG_MESSAGE", LOG_MESSAGE.toString());
				
			}
			
			if(LOG_TARGET_ROW_COUNT != null){
				
					this.setProperty("LOG_TARGET_ROW_COUNT", LOG_TARGET_ROW_COUNT.toString());
				
			}
			
			if(LOG_STATUS != null){
				
					this.setProperty("LOG_STATUS", LOG_STATUS.toString());
				
			}
			
			if(PRIVATE_KEY != null){
				
					this.setProperty("PRIVATE_KEY", PRIVATE_KEY.toString());
				
			}
			
			if(CURSOR_SIZE != null){
				
					this.setProperty("CURSOR_SIZE", CURSOR_SIZE.toString());
				
			}
			
			if(PROD2DEV_THREADS != null){
				
					this.setProperty("PROD2DEV_THREADS", PROD2DEV_THREADS.toString());
				
			}
			
			if(MAIL_TO != null){
				
					this.setProperty("MAIL_TO", MAIL_TO.toString());
				
			}
			
			if(IGNORE_TIMEZONE != null){
				
					this.setProperty("IGNORE_TIMEZONE", IGNORE_TIMEZONE.toString());
				
			}
			
			if(RECREATE_SCHEMA != null){
				
					this.setProperty("RECREATE_SCHEMA", RECREATE_SCHEMA.toString());
				
			}
			
			if(DB_VERSION != null){
				
					this.setProperty("DB_VERSION", DB_VERSION.toString());
				
			}
			
			if(IS_MULTITHREAD_BY_TABLE != null){
				
					this.setProperty("IS_MULTITHREAD_BY_TABLE", IS_MULTITHREAD_BY_TABLE.toString());
				
			}
			
			if(OSPASSWORD != null){
				
					this.setProperty("OSPASSWORD", OSPASSWORD.toString());
				
			}
			
			if(OSUSER != null){
				
					this.setProperty("OSUSER", OSUSER.toString());
				
			}
			
			if(PYTHON_HOST != null){
				
					this.setProperty("PYTHON_HOST", PYTHON_HOST.toString());
				
			}
			
			if(PYTHON_PATH != null){
				
					this.setProperty("PYTHON_PATH", PYTHON_PATH.toString());
				
			}
			
			if(ETL_LOCALHOSTNAME != null){
				
					this.setProperty("ETL_LOCALHOSTNAME", ETL_LOCALHOSTNAME.toString());
				
			}
			
			if(ETL_STORAGE_PATH != null){
				
					this.setProperty("ETL_STORAGE_PATH", ETL_STORAGE_PATH.toString());
				
			}
			
			if(HAWQ_Source_Ports != null){
				
					this.setProperty("HAWQ_Source_Ports", HAWQ_Source_Ports.toString());
				
			}
			
			if(SOURCING_Database != null){
				
					this.setProperty("SOURCING_Database", SOURCING_Database.toString());
				
			}
			
			if(SOURCING_Login != null){
				
					this.setProperty("SOURCING_Login", SOURCING_Login.toString());
				
			}
			
			if(SOURCING_Password != null){
				
					this.setProperty("SOURCING_Password", SOURCING_Password.toString());
				
			}
			
			if(SOURCING_Port != null){
				
					this.setProperty("SOURCING_Port", SOURCING_Port.toString());
				
			}
			
			if(SOURCING_Schema != null){
				
					this.setProperty("SOURCING_Schema", SOURCING_Schema.toString());
				
			}
			
			if(SOURCING_Server != null){
				
					this.setProperty("SOURCING_Server", SOURCING_Server.toString());
				
			}
			
		}

public String GP_SOURCE_NAME;
public String getGP_SOURCE_NAME(){
	return this.GP_SOURCE_NAME;
}
public String TABLE_NAME;
public String getTABLE_NAME(){
	return this.TABLE_NAME;
}
public String FORCE_DROP;
public String getFORCE_DROP(){
	return this.FORCE_DROP;
}
public String FORCE_BATCH;
public String getFORCE_BATCH(){
	return this.FORCE_BATCH;
}
public String LOAD2HDFS;
public String getLOAD2HDFS(){
	return this.LOAD2HDFS;
}
public String SOURCE_HOST;
public String getSOURCE_HOST(){
	return this.SOURCE_HOST;
}
public String SOURCE_DATABASE;
public String getSOURCE_DATABASE(){
	return this.SOURCE_DATABASE;
}
public String SOURCE_USER;
public String getSOURCE_USER(){
	return this.SOURCE_USER;
}
public Integer SOURCE_PORT;
public Integer getSOURCE_PORT(){
	return this.SOURCE_PORT;
}
public String SOURCE_PASSWORD;
public String getSOURCE_PASSWORD(){
	return this.SOURCE_PASSWORD;
}
public Integer TOP_N_ROWS;
public Integer getTOP_N_ROWS(){
	return this.TOP_N_ROWS;
}
public Integer THREAD;
public Integer getTHREAD(){
	return this.THREAD;
}
public Integer RUN_ID;
public Integer getRUN_ID(){
	return this.RUN_ID;
}
public String PROD2DEV;
public String getPROD2DEV(){
	return this.PROD2DEV;
}
public String SEND_MAIL;
public String getSEND_MAIL(){
	return this.SEND_MAIL;
}
public String PUBLIC;
public String getPUBLIC(){
	return this.PUBLIC;
}
public String PYTHON_NEEDED;
public String getPYTHON_NEEDED(){
	return this.PYTHON_NEEDED;
}
public String mail_to_error;
public String getMail_to_error(){
	return this.mail_to_error;
}
public String JOB_LABEL_NAME;
public String getJOB_LABEL_NAME(){
	return this.JOB_LABEL_NAME;
}
public String PLANT_NAME;
public String getPLANT_NAME(){
	return this.PLANT_NAME;
}
public Integer LOG_NO_OF_ERRORS;
public Integer getLOG_NO_OF_ERRORS(){
	return this.LOG_NO_OF_ERRORS;
}
public String LOG_PLANT_NAME;
public String getLOG_PLANT_NAME(){
	return this.LOG_PLANT_NAME;
}
public Integer LOG_NO_OF_UPDATES;
public Integer getLOG_NO_OF_UPDATES(){
	return this.LOG_NO_OF_UPDATES;
}
public Integer LOG_SOURCE_ROW_COUNT;
public Integer getLOG_SOURCE_ROW_COUNT(){
	return this.LOG_SOURCE_ROW_COUNT;
}
public String LOG_TECHNOLOGY;
public String getLOG_TECHNOLOGY(){
	return this.LOG_TECHNOLOGY;
}
public String LOG_TABLE_NAME;
public String getLOG_TABLE_NAME(){
	return this.LOG_TABLE_NAME;
}
public Integer LOG_NO_OF_INSERTS;
public Integer getLOG_NO_OF_INSERTS(){
	return this.LOG_NO_OF_INSERTS;
}
public String LOG_DATA_PATH;
public String getLOG_DATA_PATH(){
	return this.LOG_DATA_PATH;
}
public Integer LOG_NO_OF_DELETES;
public Integer getLOG_NO_OF_DELETES(){
	return this.LOG_NO_OF_DELETES;
}
public Integer LOG_RUN_ID;
public Integer getLOG_RUN_ID(){
	return this.LOG_RUN_ID;
}
public String LOG_ERROR_CATEGORY;
public String getLOG_ERROR_CATEGORY(){
	return this.LOG_ERROR_CATEGORY;
}
public String LOG_JOB_NAME;
public String getLOG_JOB_NAME(){
	return this.LOG_JOB_NAME;
}
public String LOG_SYSTEM_NAME;
public String getLOG_SYSTEM_NAME(){
	return this.LOG_SYSTEM_NAME;
}
public String LOG_MESSAGE;
public String getLOG_MESSAGE(){
	return this.LOG_MESSAGE;
}
public Integer LOG_TARGET_ROW_COUNT;
public Integer getLOG_TARGET_ROW_COUNT(){
	return this.LOG_TARGET_ROW_COUNT;
}
public String LOG_STATUS;
public String getLOG_STATUS(){
	return this.LOG_STATUS;
}
public java.lang.String PRIVATE_KEY;
public java.lang.String getPRIVATE_KEY(){
	return this.PRIVATE_KEY;
}
public Integer CURSOR_SIZE;
public Integer getCURSOR_SIZE(){
	return this.CURSOR_SIZE;
}
public Integer PROD2DEV_THREADS;
public Integer getPROD2DEV_THREADS(){
	return this.PROD2DEV_THREADS;
}
public String MAIL_TO;
public String getMAIL_TO(){
	return this.MAIL_TO;
}
public String IGNORE_TIMEZONE;
public String getIGNORE_TIMEZONE(){
	return this.IGNORE_TIMEZONE;
}
public String RECREATE_SCHEMA;
public String getRECREATE_SCHEMA(){
	return this.RECREATE_SCHEMA;
}
public String DB_VERSION;
public String getDB_VERSION(){
	return this.DB_VERSION;
}
public String IS_MULTITHREAD_BY_TABLE;
public String getIS_MULTITHREAD_BY_TABLE(){
	return this.IS_MULTITHREAD_BY_TABLE;
}
public String OSPASSWORD;
public String getOSPASSWORD(){
	return this.OSPASSWORD;
}
public String OSUSER;
public String getOSUSER(){
	return this.OSUSER;
}
public String PYTHON_HOST;
public String getPYTHON_HOST(){
	return this.PYTHON_HOST;
}
public String PYTHON_PATH;
public String getPYTHON_PATH(){
	return this.PYTHON_PATH;
}
public String ETL_LOCALHOSTNAME;
public String getETL_LOCALHOSTNAME(){
	return this.ETL_LOCALHOSTNAME;
}
public String ETL_STORAGE_PATH;
public String getETL_STORAGE_PATH(){
	return this.ETL_STORAGE_PATH;
}
public String HAWQ_Source_Ports;
public String getHAWQ_Source_Ports(){
	return this.HAWQ_Source_Ports;
}
public String SOURCING_Database;
public String getSOURCING_Database(){
	return this.SOURCING_Database;
}
public String SOURCING_Login;
public String getSOURCING_Login(){
	return this.SOURCING_Login;
}
public java.lang.String SOURCING_Password;
public java.lang.String getSOURCING_Password(){
	return this.SOURCING_Password;
}
public String SOURCING_Port;
public String getSOURCING_Port(){
	return this.SOURCING_Port;
}
public String SOURCING_Schema;
public String getSOURCING_Schema(){
	return this.SOURCING_Schema;
}
public String SOURCING_Server;
public String getSOURCING_Server(){
	return this.SOURCING_Server;
}
	}
	private ContextProperties context = new ContextProperties();
	public ContextProperties getContext() {
		return this.context;
	}
	private final String jobVersion = "0.1";
	private final String jobName = "EDL_Base_dynamic";
	private final String projectName = "AWS_DEV_TALEND_INGESTION_FRAMEWORK";
	public Integer errorCode = null;
	private String currentComponent = "";
	
		private final java.util.Map<String, Object> globalMap = java.util.Collections.synchronizedMap(new java.util.HashMap<String, Object>());
	
		private final java.util.Map<String, Long> start_Hash = java.util.Collections.synchronizedMap(new java.util.HashMap<String, Long>());
		private final java.util.Map<String, Long> end_Hash = java.util.Collections.synchronizedMap(new java.util.HashMap<String, Long>());
		private final java.util.Map<String, Boolean> ok_Hash = java.util.Collections.synchronizedMap(new java.util.HashMap<String, Boolean>());
		public  final java.util.List<String[]> globalBuffer = java.util.Collections.synchronizedList(new java.util.ArrayList<String[]>());
	

private RunStat runStat = new RunStat();

	// OSGi DataSource
	private final static String KEY_DB_DATASOURCES = "KEY_DB_DATASOURCES";

	public void setDataSources(java.util.Map<String, javax.sql.DataSource> dataSources) {
		java.util.Map<String, routines.system.TalendDataSource> talendDataSources = new java.util.HashMap<String, routines.system.TalendDataSource>();
		for (java.util.Map.Entry<String, javax.sql.DataSource> dataSourceEntry : dataSources.entrySet()) {
			talendDataSources.put(dataSourceEntry.getKey(), new routines.system.TalendDataSource(dataSourceEntry.getValue()));
		}
		globalMap.put(KEY_DB_DATASOURCES, talendDataSources);
	}

	LogCatcherUtils talendLogs_LOGS = new LogCatcherUtils();
	StatCatcherUtils talendStats_STATS = new StatCatcherUtils("__b5w8Fb5EeWmbO_kkFDL3Q", "0.1");
	MetterCatcherUtils talendMeter_METTER = new MetterCatcherUtils("__b5w8Fb5EeWmbO_kkFDL3Q", "0.1");

private final java.io.ByteArrayOutputStream baos = new java.io.ByteArrayOutputStream();
private final java.io.PrintStream errorMessagePS = new java.io.PrintStream(new java.io.BufferedOutputStream(baos));

public String getExceptionStackTrace() {
	if ("failure".equals(this.getStatus())) {
		errorMessagePS.flush();
		return baos.toString();
	}
	return null;
}

private Exception exception;

public Exception getException() {
	if ("failure".equals(this.getStatus())) {
		return this.exception;
	}
	return null;
}

private class TalendException extends Exception {

	private static final long serialVersionUID = 1L;

	private java.util.Map<String, Object> globalMap = null;
	private Exception e = null;
	private String currentComponent = null;
	private String virtualComponentName = null;
	
	public void setVirtualComponentName (String virtualComponentName){
		this.virtualComponentName = virtualComponentName;
	}

	private TalendException(Exception e, String errorComponent, final java.util.Map<String, Object> globalMap) {
		this.currentComponent= errorComponent;
		this.globalMap = globalMap;
		this.e = e;
	}

	public Exception getException() {
		return this.e;
	}

	public String getCurrentComponent() {
		return this.currentComponent;
	}

	
    public String getExceptionCauseMessage(Exception e){
        Throwable cause = e;
        String message = null;
        int i = 10;
        while (null != cause && 0 < i--) {
            message = cause.getMessage();
            if (null == message) {
                cause = cause.getCause();
            } else {
                break;          
            }
        }
        if (null == message) {
            message = e.getClass().getName();
        }   
        return message;
    }

	@Override
	public void printStackTrace() {
		if (!(e instanceof TalendException || e instanceof TDieException)) {
			if(virtualComponentName!=null && currentComponent.indexOf(virtualComponentName+"_")==0){
				globalMap.put(virtualComponentName+"_ERROR_MESSAGE",getExceptionCauseMessage(e));
			}
			 globalMap.put(currentComponent+"_ERROR_MESSAGE",getExceptionCauseMessage(e));
			System.err.println("Exception in component " + currentComponent);
		}
		if (!(e instanceof TDieException)) {
			if(e instanceof TalendException){
				e.printStackTrace();
			} else {
				e.printStackTrace();
				e.printStackTrace(errorMessagePS);
				EDL_Base_dynamic.this.exception = e;
			}
		}
		if (!(e instanceof TalendException)) {
		try {
			for (java.lang.reflect.Method m : this.getClass().getEnclosingClass().getMethods()) {
				if (m.getName().compareTo(currentComponent + "_error") == 0) {
					m.invoke(EDL_Base_dynamic.this, new Object[] { e , currentComponent, globalMap});
					break;
				}
			}

			if(!(e instanceof TDieException)){
				talendLogs_LOGS.addMessage("Java Exception", currentComponent, 6, e.getClass().getName() + ":" + e.getMessage(), 1);
				talendLogs_LOGSProcess(globalMap);
			}
				} catch (TalendException e) {
					// do nothing
				
		} catch (Exception e) {
			this.e.printStackTrace();
		}
		}
	}
}

			public void tGreenplumConnection_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				((java.util.Map)threadLocal.get()).put("status", "failure");
				
					tGreenplumConnection_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tGreenplumInput_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				((java.util.Map)threadLocal.get()).put("status", "failure");
				
					tGreenplumInput_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tSetGlobalVar_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				((java.util.Map)threadLocal.get()).put("status", "failure");
				
					tGreenplumInput_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tGreenplumInput_4_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				((java.util.Map)threadLocal.get()).put("status", "failure");
				
					tGreenplumInput_4_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tSetGlobalVar_7_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				((java.util.Map)threadLocal.get()).put("status", "failure");
				
					tGreenplumInput_4_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tGreenplumInput_2_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				((java.util.Map)threadLocal.get()).put("status", "failure");
				
					tGreenplumInput_2_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tSetGlobalVar_2_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				((java.util.Map)threadLocal.get()).put("status", "failure");
				
					tGreenplumInput_2_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tJava_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				((java.util.Map)threadLocal.get()).put("status", "failure");
				
					tJava_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tGreenplumInput_3_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				((java.util.Map)threadLocal.get()).put("status", "failure");
				
					tGreenplumInput_3_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tMap_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				((java.util.Map)threadLocal.get()).put("status", "failure");
				
					tGreenplumInput_3_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tFileOutputDelimitedGE_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				((java.util.Map)threadLocal.get()).put("status", "failure");
				
					tGreenplumInput_3_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tGreenplumClose_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				((java.util.Map)threadLocal.get()).put("status", "failure");
				
					tGreenplumClose_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tJava_2_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				((java.util.Map)threadLocal.get()).put("status", "failure");
				
					tJava_2_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tGreenplumConnection_2_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				((java.util.Map)threadLocal.get()).put("status", "failure");
				
					tGreenplumConnection_2_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tGreenplumInput_5_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				((java.util.Map)threadLocal.get()).put("status", "failure");
				
					tGreenplumInput_5_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tJavaRow_3_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				((java.util.Map)threadLocal.get()).put("status", "failure");
				
					tGreenplumInput_5_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tJava_6_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				((java.util.Map)threadLocal.get()).put("status", "failure");
				
					tJava_6_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tGreenplumRow_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				((java.util.Map)threadLocal.get()).put("status", "failure");
				
					tGreenplumRow_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tGreenplumClose_2_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				((java.util.Map)threadLocal.get()).put("status", "failure");
				
					tGreenplumClose_2_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tFileInputDelimited_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				((java.util.Map)threadLocal.get()).put("status", "failure");
				
					tFileInputDelimited_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tJavaRow_2_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				((java.util.Map)threadLocal.get()).put("status", "failure");
				
					tFileInputDelimited_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tFlowToIterate_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				((java.util.Map)threadLocal.get()).put("status", "failure");
				
					tFileInputDelimited_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tRunJob_2_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				((java.util.Map)threadLocal.get()).put("status", "failure");
				
					tFileInputDelimited_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tFileDelete_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
							talendStats_STATS.addMessage("failure",errorComponent, end_Hash.get(errorComponent)-start_Hash.get(errorComponent));
							talendStats_STATSProcess(globalMap);
							
				((java.util.Map)threadLocal.get()).put("status", "failure");
				
					tFileDelete_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tJava_13_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				((java.util.Map)threadLocal.get()).put("status", "failure");
				
					tJava_13_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tRunJob_4_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				((java.util.Map)threadLocal.get()).put("status", "failure");
				
					tRunJob_4_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tGreenplumConnection_4_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				((java.util.Map)threadLocal.get()).put("status", "failure");
				
					tGreenplumConnection_4_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tGreenplumInput_8_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				((java.util.Map)threadLocal.get()).put("status", "failure");
				
					tGreenplumInput_8_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tSetGlobalVar_5_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				((java.util.Map)threadLocal.get()).put("status", "failure");
				
					tGreenplumInput_8_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tGreenplumInput_7_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				((java.util.Map)threadLocal.get()).put("status", "failure");
				
					tGreenplumInput_7_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tSetGlobalVar_4_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				((java.util.Map)threadLocal.get()).put("status", "failure");
				
					tGreenplumInput_7_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tJava_7_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				((java.util.Map)threadLocal.get()).put("status", "failure");
				
					tJava_7_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tGreenplumConnection_3_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				((java.util.Map)threadLocal.get()).put("status", "failure");
				
					tGreenplumConnection_3_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tGreenplumInput_6_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				((java.util.Map)threadLocal.get()).put("status", "failure");
				
					tGreenplumInput_6_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tJavaRow_4_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				((java.util.Map)threadLocal.get()).put("status", "failure");
				
					tGreenplumInput_6_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tJava_8_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				((java.util.Map)threadLocal.get()).put("status", "failure");
				
					tJava_8_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tGreenplumRow_2_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				((java.util.Map)threadLocal.get()).put("status", "failure");
				
					tGreenplumRow_2_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tGreenplumClose_3_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				((java.util.Map)threadLocal.get()).put("status", "failure");
				
					tGreenplumClose_3_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tJava_10_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				((java.util.Map)threadLocal.get()).put("status", "failure");
				
					tJava_10_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tJava_9_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				((java.util.Map)threadLocal.get()).put("status", "failure");
				
					tJava_9_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tGreenplumConnection_6_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				((java.util.Map)threadLocal.get()).put("status", "failure");
				
					tGreenplumConnection_6_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tGreenplumInput_10_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				((java.util.Map)threadLocal.get()).put("status", "failure");
				
					tGreenplumInput_10_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tFlowToIterate_2_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				((java.util.Map)threadLocal.get()).put("status", "failure");
				
					tGreenplumInput_10_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tGreenplumRow_4_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				((java.util.Map)threadLocal.get()).put("status", "failure");
				
					tGreenplumInput_10_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tGreenplumClose_4_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				((java.util.Map)threadLocal.get()).put("status", "failure");
				
					tGreenplumClose_4_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tJava_14_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				((java.util.Map)threadLocal.get()).put("status", "failure");
				
					tJava_14_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tRunJob_6_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				((java.util.Map)threadLocal.get()).put("status", "failure");
				
					tRunJob_6_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tJava_15_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				((java.util.Map)threadLocal.get()).put("status", "failure");
				
					tJava_15_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tSetGlobalVar_3_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				((java.util.Map)threadLocal.get()).put("status", "failure");
				
					tSetGlobalVar_3_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void talendLogs_LOGS_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
							talendLogs_CONSOLE_error(exception, errorComponent, globalMap);
						
						}
					
			public void talendLogs_CONSOLE_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				((java.util.Map)threadLocal.get()).put("status", "failure");
				
					talendLogs_LOGS_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void talendStats_STATS_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
							talendStats_CONSOLE_error(exception, errorComponent, globalMap);
						
						}
					
			public void talendStats_CONSOLE_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				((java.util.Map)threadLocal.get()).put("status", "failure");
				
					talendStats_STATS_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void talendMeter_METTER_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
							talendMeter_CONSOLE_error(exception, errorComponent, globalMap);
						
						}
					
			public void talendMeter_CONSOLE_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				((java.util.Map)threadLocal.get()).put("status", "failure");
				
					talendMeter_METTER_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tGreenplumConnection_1_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tGreenplumInput_1_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tGreenplumInput_4_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tGreenplumInput_2_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tJava_1_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tGreenplumInput_3_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tGreenplumClose_1_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tJava_2_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tGreenplumConnection_2_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tGreenplumInput_5_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tJava_6_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tGreenplumRow_1_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tGreenplumClose_2_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tFileInputDelimited_1_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tFileDelete_1_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tJava_13_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tRunJob_4_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tGreenplumConnection_4_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tGreenplumInput_8_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tGreenplumInput_7_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tJava_7_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tGreenplumConnection_3_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tGreenplumInput_6_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tJava_8_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tGreenplumRow_2_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tGreenplumClose_3_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tJava_10_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tJava_9_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tGreenplumConnection_6_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tGreenplumInput_10_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tGreenplumClose_4_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tJava_14_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tRunJob_6_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tJava_15_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tSetGlobalVar_3_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void talendLogs_LOGS_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void talendStats_STATS_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void talendMeter_METTER_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			








public void tGreenplumConnection_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tGreenplumConnection_1_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tGreenplumConnection_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tGreenplumConnection_1", false);
		start_Hash.put("tGreenplumConnection_1", System.currentTimeMillis());
		
	
	currentComponent="tGreenplumConnection_1";

	
		int tos_count_tGreenplumConnection_1 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tGreenplumConnection_1 - "  + ("Start to work.") );
    	class BytesLimit65535_tGreenplumConnection_1{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tGreenplumConnection_1 = new StringBuilder();
            log4jParamters_tGreenplumConnection_1.append("Parameters:");
                    log4jParamters_tGreenplumConnection_1.append("HOST" + " = " + "context.SOURCING_Server");
                log4jParamters_tGreenplumConnection_1.append(" | ");
                    log4jParamters_tGreenplumConnection_1.append("PORT" + " = " + "context.SOURCING_Port");
                log4jParamters_tGreenplumConnection_1.append(" | ");
                    log4jParamters_tGreenplumConnection_1.append("DBNAME" + " = " + "context.SOURCING_Database");
                log4jParamters_tGreenplumConnection_1.append(" | ");
                    log4jParamters_tGreenplumConnection_1.append("SCHEMA_DB" + " = " + "context.SOURCING_Schema");
                log4jParamters_tGreenplumConnection_1.append(" | ");
                    log4jParamters_tGreenplumConnection_1.append("USER" + " = " + "context.SOURCING_Login");
                log4jParamters_tGreenplumConnection_1.append(" | ");
                    log4jParamters_tGreenplumConnection_1.append("PASS" + " = " + String.valueOf(routines.system.PasswordEncryptUtil.encryptPassword(context.SOURCING_Password)).substring(0, 4) + "...");     
                log4jParamters_tGreenplumConnection_1.append(" | ");
                    log4jParamters_tGreenplumConnection_1.append("USE_SHARED_CONNECTION" + " = " + "true");
                log4jParamters_tGreenplumConnection_1.append(" | ");
                    log4jParamters_tGreenplumConnection_1.append("SHARED_CONNECTION_NAME" + " = " + "\"base_dynamic\"+((String)globalMap.get(\"timestamp\"))");
                log4jParamters_tGreenplumConnection_1.append(" | ");
                    log4jParamters_tGreenplumConnection_1.append("USE_SSL" + " = " + "true");
                log4jParamters_tGreenplumConnection_1.append(" | ");
                    log4jParamters_tGreenplumConnection_1.append("AUTO_COMMIT" + " = " + "true");
                log4jParamters_tGreenplumConnection_1.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tGreenplumConnection_1 - "  + (log4jParamters_tGreenplumConnection_1) );
    		}
    	}
    	
        new BytesLimit65535_tGreenplumConnection_1().limitLog4jByte();
	

	
				String url_tGreenplumConnection_1 = "jdbc:postgresql://"+context.SOURCING_Server+":"+context.SOURCING_Port+"/"+context.SOURCING_Database+"?ssl=true&sslfactory=org.postgresql.ssl.NonValidatingFactory";

	String dbUser_tGreenplumConnection_1 = context.SOURCING_Login;
	
	
		
	final String decryptedPassword_tGreenplumConnection_1 = context.SOURCING_Password; 
		String dbPwd_tGreenplumConnection_1 = decryptedPassword_tGreenplumConnection_1;
	

	java.sql.Connection conn_tGreenplumConnection_1 = null;
	
	
			SharedDBConnectionLog4j.initLogger(log,"tGreenplumConnection_1");
			String sharedConnectionName_tGreenplumConnection_1 = "base_dynamic"+((String)globalMap.get("timestamp"));
			conn_tGreenplumConnection_1 = SharedDBConnectionLog4j.getDBConnection("org.postgresql.Driver",url_tGreenplumConnection_1,dbUser_tGreenplumConnection_1 , dbPwd_tGreenplumConnection_1 , sharedConnectionName_tGreenplumConnection_1);
	if (null != conn_tGreenplumConnection_1) {
		
			log.debug("tGreenplumConnection_1 - Connection is set auto commit to 'true'.");
			conn_tGreenplumConnection_1.setAutoCommit(true);
	}

	globalMap.put("schema_" + "tGreenplumConnection_1",context.SOURCING_Schema);

	globalMap.put("conn_" + "tGreenplumConnection_1",conn_tGreenplumConnection_1);
 



/**
 * [tGreenplumConnection_1 begin ] stop
 */
	
	/**
	 * [tGreenplumConnection_1 main ] start
	 */

	

	
	
	currentComponent="tGreenplumConnection_1";

	

 


	tos_count_tGreenplumConnection_1++;

/**
 * [tGreenplumConnection_1 main ] stop
 */
	
	/**
	 * [tGreenplumConnection_1 end ] start
	 */

	

	
	
	currentComponent="tGreenplumConnection_1";

	

 
                if(log.isDebugEnabled())
            log.debug("tGreenplumConnection_1 - "  + ("Done.") );

ok_Hash.put("tGreenplumConnection_1", true);
end_Hash.put("tGreenplumConnection_1", System.currentTimeMillis());




/**
 * [tGreenplumConnection_1 end ] stop
 */
				}//end the resume

				
				    			if(resumeEntryMethodName == null || globalResumeTicket){
				    				resumeUtil.addLog("CHECKPOINT", "CONNECTION:SUBJOB_OK:tGreenplumConnection_1:OnSubjobOk", "", Thread.currentThread().getId() + "", "", "", "", "", "");
								}	    				    			
					    	
								if(execStat){    	
									runStat.updateStatOnConnection("OnSubjobOk1", 0, "ok");
								} 
							
							tGreenplumInput_1Process(globalMap); 
						



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage());
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tGreenplumConnection_1 finally ] start
	 */

	

	
	
	currentComponent="tGreenplumConnection_1";

	

 



/**
 * [tGreenplumConnection_1 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tGreenplumConnection_1_SUBPROCESS_STATE", 1);
	}
	


public static class row1Struct implements routines.system.IPersistableRow<row1Struct> {
    final static byte[] commonByteArrayLock_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Base_dynamic = new byte[0];
    static byte[] commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Base_dynamic = new byte[0];

	
			    public String source_name;

				public String getSource_name () {
					return this.source_name;
				}
				
			    public String host_name;

				public String getHost_name () {
					return this.host_name;
				}
				
			    public String database;

				public String getDatabase () {
					return this.database;
				}
				
			    public Integer port;

				public Integer getPort () {
					return this.port;
				}
				
			    public String user_name;

				public String getUser_name () {
					return this.user_name;
				}
				
			    public String password;

				public String getPassword () {
					return this.password;
				}
				
			    public String public_key;

				public String getPublic_key () {
					return this.public_key;
				}
				
			    public String type;

				public String getType () {
					return this.type;
				}
				
			    public String job_name;

				public String getJob_name () {
					return this.job_name;
				}
				



	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Base_dynamic.length) {
				if(length < 1024 && commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Base_dynamic.length == 0) {
   					commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Base_dynamic = new byte[1024];
				} else {
   					commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Base_dynamic = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Base_dynamic, 0, length);
			strReturn = new String(commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Base_dynamic, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
	private Integer readInteger(ObjectInputStream dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}

	private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException{
		if(intNum == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeInt(intNum);
    	}
	}

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Base_dynamic) {

        	try {

        		int length = 0;
		
					this.source_name = readString(dis);
					
					this.host_name = readString(dis);
					
					this.database = readString(dis);
					
						this.port = readInteger(dis);
					
					this.user_name = readString(dis);
					
					this.password = readString(dis);
					
					this.public_key = readString(dis);
					
					this.type = readString(dis);
					
					this.job_name = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// String
				
						writeString(this.source_name,dos);
					
					// String
				
						writeString(this.host_name,dos);
					
					// String
				
						writeString(this.database,dos);
					
					// Integer
				
						writeInteger(this.port,dos);
					
					// String
				
						writeString(this.user_name,dos);
					
					// String
				
						writeString(this.password,dos);
					
					// String
				
						writeString(this.public_key,dos);
					
					// String
				
						writeString(this.type,dos);
					
					// String
				
						writeString(this.job_name,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("source_name="+source_name);
		sb.append(",host_name="+host_name);
		sb.append(",database="+database);
		sb.append(",port="+String.valueOf(port));
		sb.append(",user_name="+user_name);
		sb.append(",password="+password);
		sb.append(",public_key="+public_key);
		sb.append(",type="+type);
		sb.append(",job_name="+job_name);
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				if(source_name == null){
        					sb.append("<null>");
        				}else{
            				sb.append(source_name);
            			}
            		
        			sb.append("|");
        		
        				if(host_name == null){
        					sb.append("<null>");
        				}else{
            				sb.append(host_name);
            			}
            		
        			sb.append("|");
        		
        				if(database == null){
        					sb.append("<null>");
        				}else{
            				sb.append(database);
            			}
            		
        			sb.append("|");
        		
        				if(port == null){
        					sb.append("<null>");
        				}else{
            				sb.append(port);
            			}
            		
        			sb.append("|");
        		
        				if(user_name == null){
        					sb.append("<null>");
        				}else{
            				sb.append(user_name);
            			}
            		
        			sb.append("|");
        		
        				if(password == null){
        					sb.append("<null>");
        				}else{
            				sb.append(password);
            			}
            		
        			sb.append("|");
        		
        				if(public_key == null){
        					sb.append("<null>");
        				}else{
            				sb.append(public_key);
            			}
            		
        			sb.append("|");
        		
        				if(type == null){
        					sb.append("<null>");
        				}else{
            				sb.append(type);
            			}
            		
        			sb.append("|");
        		
        				if(job_name == null){
        					sb.append("<null>");
        				}else{
            				sb.append(job_name);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(row1Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}
public void tGreenplumInput_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tGreenplumInput_1_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;



		row1Struct row1 = new row1Struct();




	
	/**
	 * [tSetGlobalVar_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tSetGlobalVar_1", false);
		start_Hash.put("tSetGlobalVar_1", System.currentTimeMillis());
		
	
	currentComponent="tSetGlobalVar_1";

	
			if (execStat) {
				if(resourceMap.get("inIterateVComp") == null){
					
						runStat.updateStatOnConnection("row1" + iterateId, 0, 0);
					
				}
			} 

		
		int tos_count_tSetGlobalVar_1 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tSetGlobalVar_1 - "  + ("Start to work.") );
    	class BytesLimit65535_tSetGlobalVar_1{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tSetGlobalVar_1 = new StringBuilder();
            log4jParamters_tSetGlobalVar_1.append("Parameters:");
                    log4jParamters_tSetGlobalVar_1.append("VARIABLES" + " = " + "[{VALUE="+("row1.host_name")+", KEY="+("\"host_name\"")+"}, {VALUE="+("row1.job_name")+", KEY="+("\"job_name\"")+"}, {VALUE="+("row1.database")+", KEY="+("\"database\"")+"}, {VALUE="+("row1.port")+", KEY="+("\"port\"")+"}, {VALUE="+("row1.user_name")+", KEY="+("\"user_name\"")+"}, {VALUE="+("row1.password")+", KEY="+("\"password\"")+"}, {VALUE="+("row1.public_key")+", KEY="+("\"public_key\"")+"}]");
                log4jParamters_tSetGlobalVar_1.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tSetGlobalVar_1 - "  + (log4jParamters_tSetGlobalVar_1) );
    		}
    	}
    	
        new BytesLimit65535_tSetGlobalVar_1().limitLog4jByte();

 



/**
 * [tSetGlobalVar_1 begin ] stop
 */



	
	/**
	 * [tGreenplumInput_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tGreenplumInput_1", false);
		start_Hash.put("tGreenplumInput_1", System.currentTimeMillis());
		
	
	currentComponent="tGreenplumInput_1";

	
		int tos_count_tGreenplumInput_1 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tGreenplumInput_1 - "  + ("Start to work.") );
    	class BytesLimit65535_tGreenplumInput_1{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tGreenplumInput_1 = new StringBuilder();
            log4jParamters_tGreenplumInput_1.append("Parameters:");
                    log4jParamters_tGreenplumInput_1.append("USE_EXISTING_CONNECTION" + " = " + "true");
                log4jParamters_tGreenplumInput_1.append(" | ");
                    log4jParamters_tGreenplumInput_1.append("CONNECTION" + " = " + "tGreenplumConnection_1");
                log4jParamters_tGreenplumInput_1.append(" | ");
                    log4jParamters_tGreenplumInput_1.append("TABLE" + " = " + "\"\"");
                log4jParamters_tGreenplumInput_1.append(" | ");
                    log4jParamters_tGreenplumInput_1.append("QUERYSTORE" + " = " + "\"\"");
                log4jParamters_tGreenplumInput_1.append(" | ");
                    log4jParamters_tGreenplumInput_1.append("QUERY" + " = " + "\"SELECT   system_name,  host_name,  database,  port,  user_name,  password,  public_key,  type,  CASE   WHEN type='Oracle Service' and  '\" +context.DB_VERSION+ \"'='12' THEN 'EDL_Oracle_to_greenplum_with_GPLoad_ver_DB12'  WHEN type='Oracle Service' THEN 'EDL_Oracle_to_greenplum_with_GPLoad'   WHEN type='Greenplum' THEN 'EDL_Greenplum_to_greenplum_with_GPLoad'   WHEN type='Oracle SID' and  '\" +context.DB_VERSION+ \"'='12' THEN 'EDL_Oracle_to_greenplum_with_GPLoad_ver_DB12'  WHEN type='Oracle SID' THEN 'EDL_Oracle_to_greenplum_with_GPLoad'   WHEN type='HVR' THEN 'EDL_HVR_stats'  WHEN type='File' THEN 'EDL_File_to_greenplum_with_GPLoad'  WHEN type='IBM AS400 DB2' THEN 'AS400_to_greenplum_with_GPLoad'   WHEN type='SQL Server' THEN 'EDL_MSSql_to_greenplum_with_GPLoad'   WHEN type='Teradata' THEN 'EDL_Teradata_to_greenplum_with_GPLoad'   WHEN type='GreenplumToFlatFile' THEN 'EDL_Greenplum_to_FlatFile'  WHEN type='Greenplum Oracle Service' THEN 'EDL_Greenplum_to_OracleBulk'  WHEN type='Mysql' THEN 'EDL_Mysql_to_greenplum_with_GPLoad'  ELSE type  END job_name  FROM sbdt.edl_connection c   WHERE LOWER(system_name) = '\" + context.GP_SOURCE_NAME + \"'\"");
                log4jParamters_tGreenplumInput_1.append(" | ");
                    log4jParamters_tGreenplumInput_1.append("USE_CURSOR" + " = " + "false");
                log4jParamters_tGreenplumInput_1.append(" | ");
                    log4jParamters_tGreenplumInput_1.append("TRIM_ALL_COLUMN" + " = " + "false");
                log4jParamters_tGreenplumInput_1.append(" | ");
                    log4jParamters_tGreenplumInput_1.append("TRIM_COLUMN" + " = " + "[{TRIM="+("false")+", SCHEMA_COLUMN="+("source_name")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("host_name")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("database")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("port")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("user_name")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("password")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("public_key")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("type")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("job_name")+"}]");
                log4jParamters_tGreenplumInput_1.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tGreenplumInput_1 - "  + (log4jParamters_tGreenplumInput_1) );
    		}
    	}
    	
        new BytesLimit65535_tGreenplumInput_1().limitLog4jByte();
	
    
	
		    int nb_line_tGreenplumInput_1 = 0;
		    java.sql.Connection conn_tGreenplumInput_1 = null;
		        conn_tGreenplumInput_1 = (java.sql.Connection)globalMap.get("conn_tGreenplumConnection_1");
				
				if(conn_tGreenplumInput_1 != null) {
					if(conn_tGreenplumInput_1.getMetaData() != null) {
						
						log.debug("tGreenplumInput_1 - Uses an existing connection with username '" + conn_tGreenplumInput_1.getMetaData().getUserName() + "'. Connection URL: " + conn_tGreenplumInput_1.getMetaData().getURL() + ".");
						
					}
				}
			
		    
			java.sql.Statement stmt_tGreenplumInput_1 = conn_tGreenplumInput_1.createStatement();

		    String dbquery_tGreenplumInput_1 = "SELECT \nsystem_name,\nhost_name,\ndatabase,\nport,\nuser_name,\npassword,\npublic_key,\ntype,\nCASE \nWHEN type='Oracle Service' and  '" +context.DB_VERSION+ "'='12' THEN 'EDL_Oracle_to_greenplum_with_GPLoad_ver_DB12'\nWHEN type='Oracle Service' THEN 'EDL_Oracle_to_greenplum_with_GPLoad' \nWHEN type='Greenplum' THEN 'EDL_Greenplum_to_greenplum_with_GPLoad' \nWHEN type='Oracle SID' and  '" +context.DB_VERSION+ "'='12' THEN 'EDL_Oracle_to_greenplum_with_GPLoad_ver_DB12'\nWHEN type='Oracle SID' THEN 'EDL_Oracle_to_greenplum_with_GPLoad' \nWHEN type='HVR' THEN 'EDL_HVR_stats'\nWHEN type='File' THEN 'EDL_File_to_greenplum_with_GPLoad'\nWHEN type='IBM AS400 DB2' THEN 'AS400_to_greenplum_with_GPLoad' \nWHEN type='SQL Server' THEN 'EDL_MSSql_to_greenplum_with_GPLoad' \nWHEN type='Teradata' THEN 'EDL_Teradata_to_greenplum_with_GPLoad' \nWHEN type='GreenplumToFlatFile' THEN 'EDL_Greenplum_to_FlatFile'\nWHEN type='Greenplum Oracle Service' THEN 'EDL_Greenplum_to_OracleBulk'\nWHEN type='Mysql' THEN 'EDL_Mysql_to_greenplum_with_GPLoad'\nELSE type\nEND job_name\nFROM sbdt.edl_connection c \nWHERE LOWER(system_name) = '" + context.GP_SOURCE_NAME + "'";
			
                log.debug("tGreenplumInput_1 - Executing the query: '"+dbquery_tGreenplumInput_1+"'.");
			

                       globalMap.put("tGreenplumInput_1_QUERY",dbquery_tGreenplumInput_1);

		    java.sql.ResultSet rs_tGreenplumInput_1 = null;
		try{
		    rs_tGreenplumInput_1 = stmt_tGreenplumInput_1.executeQuery(dbquery_tGreenplumInput_1);
		    java.sql.ResultSetMetaData rsmd_tGreenplumInput_1 = rs_tGreenplumInput_1.getMetaData();
		    int colQtyInRs_tGreenplumInput_1 = rsmd_tGreenplumInput_1.getColumnCount();

		    String tmpContent_tGreenplumInput_1 = null;
		    
		    
		    	log.debug("tGreenplumInput_1 - Retrieving records from the database.");
		    
		    while (rs_tGreenplumInput_1.next()) {
		        nb_line_tGreenplumInput_1++;
		        
							if(colQtyInRs_tGreenplumInput_1 < 1) {
								row1.source_name = null;
							} else {
	                         		
        	row1.source_name = routines.system.JDBCUtil.getString(rs_tGreenplumInput_1, 1, false);
		                    }
							if(colQtyInRs_tGreenplumInput_1 < 2) {
								row1.host_name = null;
							} else {
	                         		
        	row1.host_name = routines.system.JDBCUtil.getString(rs_tGreenplumInput_1, 2, false);
		                    }
							if(colQtyInRs_tGreenplumInput_1 < 3) {
								row1.database = null;
							} else {
	                         		
        	row1.database = routines.system.JDBCUtil.getString(rs_tGreenplumInput_1, 3, false);
		                    }
							if(colQtyInRs_tGreenplumInput_1 < 4) {
								row1.port = null;
							} else {
		                          
            if(rs_tGreenplumInput_1.getObject(4) != null) {
                row1.port = rs_tGreenplumInput_1.getInt(4);
            } else {
                    row1.port = null;
            }
		                    }
							if(colQtyInRs_tGreenplumInput_1 < 5) {
								row1.user_name = null;
							} else {
	                         		
        	row1.user_name = routines.system.JDBCUtil.getString(rs_tGreenplumInput_1, 5, false);
		                    }
							if(colQtyInRs_tGreenplumInput_1 < 6) {
								row1.password = null;
							} else {
	                         		
        	row1.password = routines.system.JDBCUtil.getString(rs_tGreenplumInput_1, 6, false);
		                    }
							if(colQtyInRs_tGreenplumInput_1 < 7) {
								row1.public_key = null;
							} else {
	                         		
        	row1.public_key = routines.system.JDBCUtil.getString(rs_tGreenplumInput_1, 7, false);
		                    }
							if(colQtyInRs_tGreenplumInput_1 < 8) {
								row1.type = null;
							} else {
	                         		
        	row1.type = routines.system.JDBCUtil.getString(rs_tGreenplumInput_1, 8, false);
		                    }
							if(colQtyInRs_tGreenplumInput_1 < 9) {
								row1.job_name = null;
							} else {
	                         		
        	row1.job_name = routines.system.JDBCUtil.getString(rs_tGreenplumInput_1, 9, false);
		                    }
					
						log.debug("tGreenplumInput_1 - Retrieving the record " + nb_line_tGreenplumInput_1 + ".");
					


 



/**
 * [tGreenplumInput_1 begin ] stop
 */
	
	/**
	 * [tGreenplumInput_1 main ] start
	 */

	

	
	
	currentComponent="tGreenplumInput_1";

	

 


	tos_count_tGreenplumInput_1++;

/**
 * [tGreenplumInput_1 main ] stop
 */

	
	/**
	 * [tSetGlobalVar_1 main ] start
	 */

	

	
	
	currentComponent="tSetGlobalVar_1";

	

			//row1
			//row1


			
				if(execStat){
					runStat.updateStatOnConnection("row1"+iterateId,1, 1);
				} 
			

		
    			if(log.isTraceEnabled()){
    				log.trace("row1 - " + (row1==null? "": row1.toLogString()));
    			}
    		

globalMap.put("host_name", row1.host_name);
globalMap.put("job_name", row1.job_name);
globalMap.put("database", row1.database);
globalMap.put("port", row1.port);
globalMap.put("user_name", row1.user_name);
globalMap.put("password", row1.password);
globalMap.put("public_key", row1.public_key);

 


	tos_count_tSetGlobalVar_1++;

/**
 * [tSetGlobalVar_1 main ] stop
 */



	
	/**
	 * [tGreenplumInput_1 end ] start
	 */

	

	
	
	currentComponent="tGreenplumInput_1";

	

	}
}finally{
	stmt_tGreenplumInput_1.close();

}
globalMap.put("tGreenplumInput_1_NB_LINE",nb_line_tGreenplumInput_1);
	    		log.debug("tGreenplumInput_1 - Retrieved records count: "+nb_line_tGreenplumInput_1 + " .");
			

 
                if(log.isDebugEnabled())
            log.debug("tGreenplumInput_1 - "  + ("Done.") );

ok_Hash.put("tGreenplumInput_1", true);
end_Hash.put("tGreenplumInput_1", System.currentTimeMillis());




/**
 * [tGreenplumInput_1 end ] stop
 */

	
	/**
	 * [tSetGlobalVar_1 end ] start
	 */

	

	
	
	currentComponent="tSetGlobalVar_1";

	

			if(execStat){
				if(resourceMap.get("inIterateVComp") == null || !((Boolean)resourceMap.get("inIterateVComp"))){
			 		runStat.updateStatOnConnection("row1"+iterateId,2, 0); 
			 	}
			}
		
 
                if(log.isDebugEnabled())
            log.debug("tSetGlobalVar_1 - "  + ("Done.") );

ok_Hash.put("tSetGlobalVar_1", true);
end_Hash.put("tSetGlobalVar_1", System.currentTimeMillis());




/**
 * [tSetGlobalVar_1 end ] stop
 */



				}//end the resume

				
				    			if(resumeEntryMethodName == null || globalResumeTicket){
				    				resumeUtil.addLog("CHECKPOINT", "CONNECTION:SUBJOB_OK:tGreenplumInput_1:OnSubjobOk", "", Thread.currentThread().getId() + "", "", "", "", "", "");
								}	    				    			
					    	
								if(execStat){    	
									runStat.updateStatOnConnection("OnSubjobOk35", 0, "ok");
								} 
							
							tGreenplumInput_4Process(globalMap); 
						



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage());
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tGreenplumInput_1 finally ] start
	 */

	

	
	
	currentComponent="tGreenplumInput_1";

	

 



/**
 * [tGreenplumInput_1 finally ] stop
 */

	
	/**
	 * [tSetGlobalVar_1 finally ] start
	 */

	

	
	
	currentComponent="tSetGlobalVar_1";

	

 



/**
 * [tSetGlobalVar_1 finally ] stop
 */



				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tGreenplumInput_1_SUBPROCESS_STATE", 1);
	}
	


public static class row6Struct implements routines.system.IPersistableRow<row6Struct> {
    final static byte[] commonByteArrayLock_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Base_dynamic = new byte[0];
    static byte[] commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Base_dynamic = new byte[0];

	
			    public String pgp_password;

				public String getPgp_password () {
					return this.pgp_password;
				}
				



	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Base_dynamic.length) {
				if(length < 1024 && commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Base_dynamic.length == 0) {
   					commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Base_dynamic = new byte[1024];
				} else {
   					commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Base_dynamic = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Base_dynamic, 0, length);
			strReturn = new String(commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Base_dynamic, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Base_dynamic) {

        	try {

        		int length = 0;
		
					this.pgp_password = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// String
				
						writeString(this.pgp_password,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("pgp_password="+pgp_password);
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				if(pgp_password == null){
        					sb.append("<null>");
        				}else{
            				sb.append(pgp_password);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(row6Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}
public void tGreenplumInput_4Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tGreenplumInput_4_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;



		row6Struct row6 = new row6Struct();




	
	/**
	 * [tSetGlobalVar_7 begin ] start
	 */

	

	
		
		ok_Hash.put("tSetGlobalVar_7", false);
		start_Hash.put("tSetGlobalVar_7", System.currentTimeMillis());
		
	
	currentComponent="tSetGlobalVar_7";

	
			if (execStat) {
				if(resourceMap.get("inIterateVComp") == null){
					
						runStat.updateStatOnConnection("row6" + iterateId, 0, 0);
					
				}
			} 

		
		int tos_count_tSetGlobalVar_7 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tSetGlobalVar_7 - "  + ("Start to work.") );
    	class BytesLimit65535_tSetGlobalVar_7{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tSetGlobalVar_7 = new StringBuilder();
            log4jParamters_tSetGlobalVar_7.append("Parameters:");
                    log4jParamters_tSetGlobalVar_7.append("VARIABLES" + " = " + "[{VALUE="+("row6.pgp_password")+", KEY="+("\"pgp_password\"")+"}]");
                log4jParamters_tSetGlobalVar_7.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tSetGlobalVar_7 - "  + (log4jParamters_tSetGlobalVar_7) );
    		}
    	}
    	
        new BytesLimit65535_tSetGlobalVar_7().limitLog4jByte();

 



/**
 * [tSetGlobalVar_7 begin ] stop
 */



	
	/**
	 * [tGreenplumInput_4 begin ] start
	 */

	

	
		
		ok_Hash.put("tGreenplumInput_4", false);
		start_Hash.put("tGreenplumInput_4", System.currentTimeMillis());
		
	
	currentComponent="tGreenplumInput_4";

	
		int tos_count_tGreenplumInput_4 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tGreenplumInput_4 - "  + ("Start to work.") );
    	class BytesLimit65535_tGreenplumInput_4{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tGreenplumInput_4 = new StringBuilder();
            log4jParamters_tGreenplumInput_4.append("Parameters:");
                    log4jParamters_tGreenplumInput_4.append("USE_EXISTING_CONNECTION" + " = " + "true");
                log4jParamters_tGreenplumInput_4.append(" | ");
                    log4jParamters_tGreenplumInput_4.append("CONNECTION" + " = " + "tGreenplumConnection_1");
                log4jParamters_tGreenplumInput_4.append(" | ");
                    log4jParamters_tGreenplumInput_4.append("TABLE" + " = " + "\"\"");
                log4jParamters_tGreenplumInput_4.append(" | ");
                    log4jParamters_tGreenplumInput_4.append("QUERYSTORE" + " = " + "\"\"");
                log4jParamters_tGreenplumInput_4.append(" | ");
                    log4jParamters_tGreenplumInput_4.append("QUERY" + " = " + "\"SELECT sbdt.edl_decrypt_password('\"+context.GP_SOURCE_NAME+\"','\"+context.PRIVATE_KEY+\"') pgp_password\"  ");
                log4jParamters_tGreenplumInput_4.append(" | ");
                    log4jParamters_tGreenplumInput_4.append("USE_CURSOR" + " = " + "false");
                log4jParamters_tGreenplumInput_4.append(" | ");
                    log4jParamters_tGreenplumInput_4.append("TRIM_ALL_COLUMN" + " = " + "false");
                log4jParamters_tGreenplumInput_4.append(" | ");
                    log4jParamters_tGreenplumInput_4.append("TRIM_COLUMN" + " = " + "[{TRIM="+("false")+", SCHEMA_COLUMN="+("pgp_password")+"}]");
                log4jParamters_tGreenplumInput_4.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tGreenplumInput_4 - "  + (log4jParamters_tGreenplumInput_4) );
    		}
    	}
    	
        new BytesLimit65535_tGreenplumInput_4().limitLog4jByte();
	
    
	
		    int nb_line_tGreenplumInput_4 = 0;
		    java.sql.Connection conn_tGreenplumInput_4 = null;
		        conn_tGreenplumInput_4 = (java.sql.Connection)globalMap.get("conn_tGreenplumConnection_1");
				
				if(conn_tGreenplumInput_4 != null) {
					if(conn_tGreenplumInput_4.getMetaData() != null) {
						
						log.debug("tGreenplumInput_4 - Uses an existing connection with username '" + conn_tGreenplumInput_4.getMetaData().getUserName() + "'. Connection URL: " + conn_tGreenplumInput_4.getMetaData().getURL() + ".");
						
					}
				}
			
		    
			java.sql.Statement stmt_tGreenplumInput_4 = conn_tGreenplumInput_4.createStatement();

		    String dbquery_tGreenplumInput_4 = "SELECT sbdt.edl_decrypt_password('"+context.GP_SOURCE_NAME+"','"+context.PRIVATE_KEY+"') pgp_password"
;
			
                log.debug("tGreenplumInput_4 - Executing the query: '"+dbquery_tGreenplumInput_4+"'.");
			

                       globalMap.put("tGreenplumInput_4_QUERY",dbquery_tGreenplumInput_4);

		    java.sql.ResultSet rs_tGreenplumInput_4 = null;
		try{
		    rs_tGreenplumInput_4 = stmt_tGreenplumInput_4.executeQuery(dbquery_tGreenplumInput_4);
		    java.sql.ResultSetMetaData rsmd_tGreenplumInput_4 = rs_tGreenplumInput_4.getMetaData();
		    int colQtyInRs_tGreenplumInput_4 = rsmd_tGreenplumInput_4.getColumnCount();

		    String tmpContent_tGreenplumInput_4 = null;
		    
		    
		    	log.debug("tGreenplumInput_4 - Retrieving records from the database.");
		    
		    while (rs_tGreenplumInput_4.next()) {
		        nb_line_tGreenplumInput_4++;
		        
							if(colQtyInRs_tGreenplumInput_4 < 1) {
								row6.pgp_password = null;
							} else {
	                         		
        	row6.pgp_password = routines.system.JDBCUtil.getString(rs_tGreenplumInput_4, 1, false);
		                    }
					
						log.debug("tGreenplumInput_4 - Retrieving the record " + nb_line_tGreenplumInput_4 + ".");
					


 



/**
 * [tGreenplumInput_4 begin ] stop
 */
	
	/**
	 * [tGreenplumInput_4 main ] start
	 */

	

	
	
	currentComponent="tGreenplumInput_4";

	

 


	tos_count_tGreenplumInput_4++;

/**
 * [tGreenplumInput_4 main ] stop
 */

	
	/**
	 * [tSetGlobalVar_7 main ] start
	 */

	

	
	
	currentComponent="tSetGlobalVar_7";

	

			//row6
			//row6


			
				if(execStat){
					runStat.updateStatOnConnection("row6"+iterateId,1, 1);
				} 
			

		
    			if(log.isTraceEnabled()){
    				log.trace("row6 - " + (row6==null? "": row6.toLogString()));
    			}
    		

globalMap.put("pgp_password", row6.pgp_password);

 


	tos_count_tSetGlobalVar_7++;

/**
 * [tSetGlobalVar_7 main ] stop
 */



	
	/**
	 * [tGreenplumInput_4 end ] start
	 */

	

	
	
	currentComponent="tGreenplumInput_4";

	

	}
}finally{
	stmt_tGreenplumInput_4.close();

}
globalMap.put("tGreenplumInput_4_NB_LINE",nb_line_tGreenplumInput_4);
	    		log.debug("tGreenplumInput_4 - Retrieved records count: "+nb_line_tGreenplumInput_4 + " .");
			

 
                if(log.isDebugEnabled())
            log.debug("tGreenplumInput_4 - "  + ("Done.") );

ok_Hash.put("tGreenplumInput_4", true);
end_Hash.put("tGreenplumInput_4", System.currentTimeMillis());




/**
 * [tGreenplumInput_4 end ] stop
 */

	
	/**
	 * [tSetGlobalVar_7 end ] start
	 */

	

	
	
	currentComponent="tSetGlobalVar_7";

	

			if(execStat){
				if(resourceMap.get("inIterateVComp") == null || !((Boolean)resourceMap.get("inIterateVComp"))){
			 		runStat.updateStatOnConnection("row6"+iterateId,2, 0); 
			 	}
			}
		
 
                if(log.isDebugEnabled())
            log.debug("tSetGlobalVar_7 - "  + ("Done.") );

ok_Hash.put("tSetGlobalVar_7", true);
end_Hash.put("tSetGlobalVar_7", System.currentTimeMillis());




/**
 * [tSetGlobalVar_7 end ] stop
 */



				}//end the resume

				
				    			if(resumeEntryMethodName == null || globalResumeTicket){
				    				resumeUtil.addLog("CHECKPOINT", "CONNECTION:SUBJOB_OK:tGreenplumInput_4:OnSubjobOk", "", Thread.currentThread().getId() + "", "", "", "", "", "");
								}	    				    			
					    	
								if(execStat){    	
									runStat.updateStatOnConnection("OnSubjobOk3", 0, "ok");
								} 
							
							tGreenplumInput_2Process(globalMap); 
						



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage());
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tGreenplumInput_4 finally ] start
	 */

	

	
	
	currentComponent="tGreenplumInput_4";

	

 



/**
 * [tGreenplumInput_4 finally ] stop
 */

	
	/**
	 * [tSetGlobalVar_7 finally ] start
	 */

	

	
	
	currentComponent="tSetGlobalVar_7";

	

 



/**
 * [tSetGlobalVar_7 finally ] stop
 */



				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tGreenplumInput_4_SUBPROCESS_STATE", 1);
	}
	


public static class row5Struct implements routines.system.IPersistableRow<row5Struct> {
    final static byte[] commonByteArrayLock_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Base_dynamic = new byte[0];
    static byte[] commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Base_dynamic = new byte[0];

	
			    public String plant_name;

				public String getPlant_name () {
					return this.plant_name;
				}
				
			    public String system_name;

				public String getSystem_name () {
					return this.system_name;
				}
				
			    public String data_path;

				public String getData_path () {
					return this.data_path;
				}
				
			    public String job_label_name;

				public String getJob_label_name () {
					return this.job_label_name;
				}
				
			    public String business;

				public String getBusiness () {
					return this.business;
				}
				
			    public String sub_business;

				public String getSub_business () {
					return this.sub_business;
				}
				
			    public String sbdt_type;

				public String getSbdt_type () {
					return this.sbdt_type;
				}
				
			    public String sbdt_schema_name;

				public String getSbdt_schema_name () {
					return this.sbdt_schema_name;
				}
				
			    public String sbdt_comment;

				public String getSbdt_comment () {
					return this.sbdt_comment;
				}
				
			    public String pod;

				public String getPod () {
					return this.pod;
				}
				



	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Base_dynamic.length) {
				if(length < 1024 && commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Base_dynamic.length == 0) {
   					commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Base_dynamic = new byte[1024];
				} else {
   					commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Base_dynamic = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Base_dynamic, 0, length);
			strReturn = new String(commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Base_dynamic, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Base_dynamic) {

        	try {

        		int length = 0;
		
					this.plant_name = readString(dis);
					
					this.system_name = readString(dis);
					
					this.data_path = readString(dis);
					
					this.job_label_name = readString(dis);
					
					this.business = readString(dis);
					
					this.sub_business = readString(dis);
					
					this.sbdt_type = readString(dis);
					
					this.sbdt_schema_name = readString(dis);
					
					this.sbdt_comment = readString(dis);
					
					this.pod = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// String
				
						writeString(this.plant_name,dos);
					
					// String
				
						writeString(this.system_name,dos);
					
					// String
				
						writeString(this.data_path,dos);
					
					// String
				
						writeString(this.job_label_name,dos);
					
					// String
				
						writeString(this.business,dos);
					
					// String
				
						writeString(this.sub_business,dos);
					
					// String
				
						writeString(this.sbdt_type,dos);
					
					// String
				
						writeString(this.sbdt_schema_name,dos);
					
					// String
				
						writeString(this.sbdt_comment,dos);
					
					// String
				
						writeString(this.pod,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("plant_name="+plant_name);
		sb.append(",system_name="+system_name);
		sb.append(",data_path="+data_path);
		sb.append(",job_label_name="+job_label_name);
		sb.append(",business="+business);
		sb.append(",sub_business="+sub_business);
		sb.append(",sbdt_type="+sbdt_type);
		sb.append(",sbdt_schema_name="+sbdt_schema_name);
		sb.append(",sbdt_comment="+sbdt_comment);
		sb.append(",pod="+pod);
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				if(plant_name == null){
        					sb.append("<null>");
        				}else{
            				sb.append(plant_name);
            			}
            		
        			sb.append("|");
        		
        				if(system_name == null){
        					sb.append("<null>");
        				}else{
            				sb.append(system_name);
            			}
            		
        			sb.append("|");
        		
        				if(data_path == null){
        					sb.append("<null>");
        				}else{
            				sb.append(data_path);
            			}
            		
        			sb.append("|");
        		
        				if(job_label_name == null){
        					sb.append("<null>");
        				}else{
            				sb.append(job_label_name);
            			}
            		
        			sb.append("|");
        		
        				if(business == null){
        					sb.append("<null>");
        				}else{
            				sb.append(business);
            			}
            		
        			sb.append("|");
        		
        				if(sub_business == null){
        					sb.append("<null>");
        				}else{
            				sb.append(sub_business);
            			}
            		
        			sb.append("|");
        		
        				if(sbdt_type == null){
        					sb.append("<null>");
        				}else{
            				sb.append(sbdt_type);
            			}
            		
        			sb.append("|");
        		
        				if(sbdt_schema_name == null){
        					sb.append("<null>");
        				}else{
            				sb.append(sbdt_schema_name);
            			}
            		
        			sb.append("|");
        		
        				if(sbdt_comment == null){
        					sb.append("<null>");
        				}else{
            				sb.append(sbdt_comment);
            			}
            		
        			sb.append("|");
        		
        				if(pod == null){
        					sb.append("<null>");
        				}else{
            				sb.append(pod);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(row5Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}
public void tGreenplumInput_2Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tGreenplumInput_2_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;



		row5Struct row5 = new row5Struct();




	
	/**
	 * [tSetGlobalVar_2 begin ] start
	 */

	

	
		
		ok_Hash.put("tSetGlobalVar_2", false);
		start_Hash.put("tSetGlobalVar_2", System.currentTimeMillis());
		
	
	currentComponent="tSetGlobalVar_2";

	
			if (execStat) {
				if(resourceMap.get("inIterateVComp") == null){
					
						runStat.updateStatOnConnection("row5" + iterateId, 0, 0);
					
				}
			} 

		
		int tos_count_tSetGlobalVar_2 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tSetGlobalVar_2 - "  + ("Start to work.") );
    	class BytesLimit65535_tSetGlobalVar_2{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tSetGlobalVar_2 = new StringBuilder();
            log4jParamters_tSetGlobalVar_2.append("Parameters:");
                    log4jParamters_tSetGlobalVar_2.append("VARIABLES" + " = " + "[{VALUE="+("row5.plant_name")+", KEY="+("\"plant_name\"")+"}, {VALUE="+("row5.system_name")+", KEY="+("\"system_name\"")+"}, {VALUE="+("row5.data_path")+", KEY="+("\"data_path\"")+"}, {VALUE="+("row5.job_label_name")+", KEY="+("\"job_label_name\"")+"}, {VALUE="+("row5.business")+", KEY="+("\"business\"")+"}, {VALUE="+("row5.sub_business")+", KEY="+("\"sub_business\"")+"}, {VALUE="+("row5.sbdt_type")+", KEY="+("\"sbdt_type\"")+"}, {VALUE="+("row5.sbdt_schema_name")+", KEY="+("\"sbdt_schema_name\"")+"}, {VALUE="+("row5.sbdt_comment")+", KEY="+("\"sbdt_comment\"")+"}, {VALUE="+("row5.pod")+", KEY="+("\"pod\"")+"}, {VALUE="+("\"\"")+", KEY="+("\"gp_sql\"")+"}]");
                log4jParamters_tSetGlobalVar_2.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tSetGlobalVar_2 - "  + (log4jParamters_tSetGlobalVar_2) );
    		}
    	}
    	
        new BytesLimit65535_tSetGlobalVar_2().limitLog4jByte();

 



/**
 * [tSetGlobalVar_2 begin ] stop
 */



	
	/**
	 * [tGreenplumInput_2 begin ] start
	 */

	

	
		
		ok_Hash.put("tGreenplumInput_2", false);
		start_Hash.put("tGreenplumInput_2", System.currentTimeMillis());
		
	
	currentComponent="tGreenplumInput_2";

	
		int tos_count_tGreenplumInput_2 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tGreenplumInput_2 - "  + ("Start to work.") );
    	class BytesLimit65535_tGreenplumInput_2{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tGreenplumInput_2 = new StringBuilder();
            log4jParamters_tGreenplumInput_2.append("Parameters:");
                    log4jParamters_tGreenplumInput_2.append("USE_EXISTING_CONNECTION" + " = " + "true");
                log4jParamters_tGreenplumInput_2.append(" | ");
                    log4jParamters_tGreenplumInput_2.append("CONNECTION" + " = " + "tGreenplumConnection_1");
                log4jParamters_tGreenplumInput_2.append(" | ");
                    log4jParamters_tGreenplumInput_2.append("TABLE" + " = " + "\"\"");
                log4jParamters_tGreenplumInput_2.append(" | ");
                    log4jParamters_tGreenplumInput_2.append("QUERYSTORE" + " = " + "\"\"");
                log4jParamters_tGreenplumInput_2.append(" | ");
                    log4jParamters_tGreenplumInput_2.append("QUERY" + " = " + "\"SELECT    'N/A' plant_name,    edl_source.system_name,    'Source2GP' data_path,    'N/A' job_label_name,    edl_source.business,    edl_source.sub_business,    edl_source.type sbdt_type,    edl_source.schema_name sbdt_schema_name,    edl_source.comment sbdt_comment,    edl_source.pod  FROM    sbdt.edl_connection,    sbdt.edl_source  WHERE    sbdt.edl_connection.system_name=edl_source.system_name AND    LOWER(edl_source.system_name) = '\" + context.GP_SOURCE_NAME + \"'\"  ");
                log4jParamters_tGreenplumInput_2.append(" | ");
                    log4jParamters_tGreenplumInput_2.append("USE_CURSOR" + " = " + "false");
                log4jParamters_tGreenplumInput_2.append(" | ");
                    log4jParamters_tGreenplumInput_2.append("TRIM_ALL_COLUMN" + " = " + "false");
                log4jParamters_tGreenplumInput_2.append(" | ");
                    log4jParamters_tGreenplumInput_2.append("TRIM_COLUMN" + " = " + "[{TRIM="+("false")+", SCHEMA_COLUMN="+("plant_name")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("system_name")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("data_path")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("job_label_name")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("business")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("sub_business")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("sbdt_type")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("sbdt_schema_name")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("sbdt_comment")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("pod")+"}]");
                log4jParamters_tGreenplumInput_2.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tGreenplumInput_2 - "  + (log4jParamters_tGreenplumInput_2) );
    		}
    	}
    	
        new BytesLimit65535_tGreenplumInput_2().limitLog4jByte();
	
    
	
		    int nb_line_tGreenplumInput_2 = 0;
		    java.sql.Connection conn_tGreenplumInput_2 = null;
		        conn_tGreenplumInput_2 = (java.sql.Connection)globalMap.get("conn_tGreenplumConnection_1");
				
				if(conn_tGreenplumInput_2 != null) {
					if(conn_tGreenplumInput_2.getMetaData() != null) {
						
						log.debug("tGreenplumInput_2 - Uses an existing connection with username '" + conn_tGreenplumInput_2.getMetaData().getUserName() + "'. Connection URL: " + conn_tGreenplumInput_2.getMetaData().getURL() + ".");
						
					}
				}
			
		    
			java.sql.Statement stmt_tGreenplumInput_2 = conn_tGreenplumInput_2.createStatement();

		    String dbquery_tGreenplumInput_2 = "SELECT\n  'N/A' plant_name,\n  edl_source.system_name,\n  'Source2GP' data_path,\n  'N/A' job_label_name,\n  edl_source.business,\n  edl_source.sub_business,\n  edl_source.type sbdt_type,\n  edl_source.schema_name sbdt_schema_name,\n  edl_source.comment sbdt_comment,\n  edl_source.pod\nFROM\n  sbdt.edl_connection,\n  sbdt.edl_source\nWHERE\n  sbdt.edl_connection.system_name=edl_source.system_name AND\n  LOWER(edl_source.system_name) = '" + context.GP_SOURCE_NAME + "'"
;
			
                log.debug("tGreenplumInput_2 - Executing the query: '"+dbquery_tGreenplumInput_2+"'.");
			

                       globalMap.put("tGreenplumInput_2_QUERY",dbquery_tGreenplumInput_2);

		    java.sql.ResultSet rs_tGreenplumInput_2 = null;
		try{
		    rs_tGreenplumInput_2 = stmt_tGreenplumInput_2.executeQuery(dbquery_tGreenplumInput_2);
		    java.sql.ResultSetMetaData rsmd_tGreenplumInput_2 = rs_tGreenplumInput_2.getMetaData();
		    int colQtyInRs_tGreenplumInput_2 = rsmd_tGreenplumInput_2.getColumnCount();

		    String tmpContent_tGreenplumInput_2 = null;
		    
		    
		    	log.debug("tGreenplumInput_2 - Retrieving records from the database.");
		    
		    while (rs_tGreenplumInput_2.next()) {
		        nb_line_tGreenplumInput_2++;
		        
							if(colQtyInRs_tGreenplumInput_2 < 1) {
								row5.plant_name = null;
							} else {
	                         		
        	row5.plant_name = routines.system.JDBCUtil.getString(rs_tGreenplumInput_2, 1, false);
		                    }
							if(colQtyInRs_tGreenplumInput_2 < 2) {
								row5.system_name = null;
							} else {
	                         		
        	row5.system_name = routines.system.JDBCUtil.getString(rs_tGreenplumInput_2, 2, false);
		                    }
							if(colQtyInRs_tGreenplumInput_2 < 3) {
								row5.data_path = null;
							} else {
	                         		
        	row5.data_path = routines.system.JDBCUtil.getString(rs_tGreenplumInput_2, 3, false);
		                    }
							if(colQtyInRs_tGreenplumInput_2 < 4) {
								row5.job_label_name = null;
							} else {
	                         		
        	row5.job_label_name = routines.system.JDBCUtil.getString(rs_tGreenplumInput_2, 4, false);
		                    }
							if(colQtyInRs_tGreenplumInput_2 < 5) {
								row5.business = null;
							} else {
	                         		
        	row5.business = routines.system.JDBCUtil.getString(rs_tGreenplumInput_2, 5, false);
		                    }
							if(colQtyInRs_tGreenplumInput_2 < 6) {
								row5.sub_business = null;
							} else {
	                         		
        	row5.sub_business = routines.system.JDBCUtil.getString(rs_tGreenplumInput_2, 6, false);
		                    }
							if(colQtyInRs_tGreenplumInput_2 < 7) {
								row5.sbdt_type = null;
							} else {
	                         		
        	row5.sbdt_type = routines.system.JDBCUtil.getString(rs_tGreenplumInput_2, 7, false);
		                    }
							if(colQtyInRs_tGreenplumInput_2 < 8) {
								row5.sbdt_schema_name = null;
							} else {
	                         		
        	row5.sbdt_schema_name = routines.system.JDBCUtil.getString(rs_tGreenplumInput_2, 8, false);
		                    }
							if(colQtyInRs_tGreenplumInput_2 < 9) {
								row5.sbdt_comment = null;
							} else {
	                         		
        	row5.sbdt_comment = routines.system.JDBCUtil.getString(rs_tGreenplumInput_2, 9, false);
		                    }
							if(colQtyInRs_tGreenplumInput_2 < 10) {
								row5.pod = null;
							} else {
	                         		
        	row5.pod = routines.system.JDBCUtil.getString(rs_tGreenplumInput_2, 10, false);
		                    }
					
						log.debug("tGreenplumInput_2 - Retrieving the record " + nb_line_tGreenplumInput_2 + ".");
					


 



/**
 * [tGreenplumInput_2 begin ] stop
 */
	
	/**
	 * [tGreenplumInput_2 main ] start
	 */

	

	
	
	currentComponent="tGreenplumInput_2";

	

 


	tos_count_tGreenplumInput_2++;

/**
 * [tGreenplumInput_2 main ] stop
 */

	
	/**
	 * [tSetGlobalVar_2 main ] start
	 */

	

	
	
	currentComponent="tSetGlobalVar_2";

	

			//row5
			//row5


			
				if(execStat){
					runStat.updateStatOnConnection("row5"+iterateId,1, 1);
				} 
			

		
    			if(log.isTraceEnabled()){
    				log.trace("row5 - " + (row5==null? "": row5.toLogString()));
    			}
    		

globalMap.put("plant_name", row5.plant_name);
globalMap.put("system_name", row5.system_name);
globalMap.put("data_path", row5.data_path);
globalMap.put("job_label_name", row5.job_label_name);
globalMap.put("business", row5.business);
globalMap.put("sub_business", row5.sub_business);
globalMap.put("sbdt_type", row5.sbdt_type);
globalMap.put("sbdt_schema_name", row5.sbdt_schema_name);
globalMap.put("sbdt_comment", row5.sbdt_comment);
globalMap.put("pod", row5.pod);
globalMap.put("gp_sql", "");

 


	tos_count_tSetGlobalVar_2++;

/**
 * [tSetGlobalVar_2 main ] stop
 */



	
	/**
	 * [tGreenplumInput_2 end ] start
	 */

	

	
	
	currentComponent="tGreenplumInput_2";

	

	}
}finally{
	stmt_tGreenplumInput_2.close();

}
globalMap.put("tGreenplumInput_2_NB_LINE",nb_line_tGreenplumInput_2);
	    		log.debug("tGreenplumInput_2 - Retrieved records count: "+nb_line_tGreenplumInput_2 + " .");
			

 
                if(log.isDebugEnabled())
            log.debug("tGreenplumInput_2 - "  + ("Done.") );

ok_Hash.put("tGreenplumInput_2", true);
end_Hash.put("tGreenplumInput_2", System.currentTimeMillis());




/**
 * [tGreenplumInput_2 end ] stop
 */

	
	/**
	 * [tSetGlobalVar_2 end ] start
	 */

	

	
	
	currentComponent="tSetGlobalVar_2";

	

			if(execStat){
				if(resourceMap.get("inIterateVComp") == null || !((Boolean)resourceMap.get("inIterateVComp"))){
			 		runStat.updateStatOnConnection("row5"+iterateId,2, 0); 
			 	}
			}
		
 
                if(log.isDebugEnabled())
            log.debug("tSetGlobalVar_2 - "  + ("Done.") );

ok_Hash.put("tSetGlobalVar_2", true);
end_Hash.put("tSetGlobalVar_2", System.currentTimeMillis());




/**
 * [tSetGlobalVar_2 end ] stop
 */



				}//end the resume

				
				    			if(resumeEntryMethodName == null || globalResumeTicket){
				    				resumeUtil.addLog("CHECKPOINT", "CONNECTION:SUBJOB_OK:tGreenplumInput_2:OnSubjobOk", "", Thread.currentThread().getId() + "", "", "", "", "", "");
								}	    				    			
					    	
								if(execStat){    	
									runStat.updateStatOnConnection("OnSubjobOk11", 0, "ok");
								} 
							
							tJava_1Process(globalMap); 
						



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage());
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tGreenplumInput_2 finally ] start
	 */

	

	
	
	currentComponent="tGreenplumInput_2";

	

 



/**
 * [tGreenplumInput_2 finally ] stop
 */

	
	/**
	 * [tSetGlobalVar_2 finally ] start
	 */

	

	
	
	currentComponent="tSetGlobalVar_2";

	

 



/**
 * [tSetGlobalVar_2 finally ] stop
 */



				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tGreenplumInput_2_SUBPROCESS_STATE", 1);
	}
	

public void tJava_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tJava_1_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tJava_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tJava_1", false);
		start_Hash.put("tJava_1", System.currentTimeMillis());
		
	
	currentComponent="tJava_1";

	
		int tos_count_tJava_1 = 0;
		
    	class BytesLimit65535_tJava_1{
    		public void limitLog4jByte() throws Exception{
    			
    		}
    	}
    	
        new BytesLimit65535_tJava_1().limitLog4jByte();


System.out.println("valami");
//System.out.println("MMMMMMMM");
System.out.println(globalMap.get("pgp_password"));
//System.out.println("MMMMMMMM");

context.SOURCE_HOST=((String)globalMap.get("host_name"));
context.SOURCE_DATABASE= ((String)globalMap.get("database"));
context.SOURCE_USER= ((String)globalMap.get("user_name"));
context.SOURCE_PORT= ((Integer)globalMap.get("port"));
context.SOURCE_PASSWORD=((String)globalMap.get("pgp_password"));
context.LOG_SYSTEM_NAME=(String)globalMap.get("system_name");
context.LOG_DATA_PATH=(String)globalMap.get("data_path");
context.LOG_JOB_NAME=context.JOB_LABEL_NAME;
context.LOG_PLANT_NAME=context.PLANT_NAME;
context.LOG_TECHNOLOGY="Talend";

System.out.println("MMMMMMMM");
System.out.println(globalMap.get("pgp_password"));
System.out.println(context.SOURCE_PASSWORD);
System.out.println("MMMMMMMM");


globalMap.put("orig_table_name", context.getProperty("TABLE_NAME"));
if (context.getProperty("TABLE_NAME").length() != 0) 
{
  String table_list=context.getProperty("TABLE_NAME");
  table_list=(table_list.replace(" ", "")).replace(",","','");
  //context.setProperty("TABLE_NAME", " AND UPPER(target_table_name) IN ('" + table_list.toUpperCase() + "')");
  context.TABLE_NAME=" AND UPPER(target_table_name) IN ('" + table_list.toUpperCase() + "') ";
  
  ////////////////////////////
  System.out.println("*******table_list");
  System.out.println(table_list);
  System.out.println("*******");
  ////////////////////////////
}

String strGpSqlTemplate=
"SELECT target_table_name log_table_name, ingestion_tool technology "+
"FROM sbdt.edl_table "+
"WHERE "+
"  (source_schema<>'na' OR '#JOB_NAME'='HVR_stats') AND "+
"  enabled='Y' AND "+
"  system_name='#GP_SOURCE_NAME' AND "+
"  update_type IN ('Incremental', 'Full','Append','Softdelete') "+
"  #TABLE_NAME "+
"ORDER BY load_order";

String strGpSql=strGpSqlTemplate;
strGpSql=strGpSql.replace("#JOB_NAME", (String)globalMap.get("job_name"));
strGpSql=strGpSql.replace("#GP_SOURCE_NAME", context.GP_SOURCE_NAME);
strGpSql=strGpSql.replace("#TABLE_NAME", context.TABLE_NAME);
globalMap.put("gp_sql",strGpSql);
System.out.println("MMMMMMMMMMMMMMMM");
System.out.println(context.PRIVATE_KEY);
System.out.println("MMMMMMMMMMMMMMMM");

/////////////////////////
  System.out.println("*******strGpSql");
  System.out.println(strGpSql);
  System.out.println("*******");
/////////////////////////


//System.out.println(globalMap.get("gp_sql"));
//context.getProperty("GP_SOURCE_NAME")
//context.getProperty("TABLE_NAME")
//System.out.println("SELECT target_table_name as log_table_name FROM sbdt.edl_table WHERE enabled='Y' and (source_schema <> 'na' or //'HVR_stats'='" + ((String)globalMap.get("job_name")) + "')" +  " and system_name = '" + context.getProperty("GP_SOURCE_NAME") + "' and //update_type in ('incremental', 'full','append','softdelete')" + context.getProperty("TABLE_NAME") +" order by load_order");

 



/**
 * [tJava_1 begin ] stop
 */
	
	/**
	 * [tJava_1 main ] start
	 */

	

	
	
	currentComponent="tJava_1";

	

 


	tos_count_tJava_1++;

/**
 * [tJava_1 main ] stop
 */
	
	/**
	 * [tJava_1 end ] start
	 */

	

	
	
	currentComponent="tJava_1";

	

 

ok_Hash.put("tJava_1", true);
end_Hash.put("tJava_1", System.currentTimeMillis());




/**
 * [tJava_1 end ] stop
 */
				}//end the resume

				
				    			if(resumeEntryMethodName == null || globalResumeTicket){
				    				resumeUtil.addLog("CHECKPOINT", "CONNECTION:SUBJOB_OK:tJava_1:OnSubjobOk", "", Thread.currentThread().getId() + "", "", "", "", "", "");
								}	    				    			
					    	
								if(execStat){    	
									runStat.updateStatOnConnection("OnSubjobOk5", 0, "ok");
								} 
							
							tGreenplumInput_3Process(globalMap); 
						



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage());
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tJava_1 finally ] start
	 */

	

	
	
	currentComponent="tJava_1";

	

 



/**
 * [tJava_1 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tJava_1_SUBPROCESS_STATE", 1);
	}
	


public static class fsStruct implements routines.system.IPersistableRow<fsStruct> {
    final static byte[] commonByteArrayLock_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Base_dynamic = new byte[0];
    static byte[] commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Base_dynamic = new byte[0];
	protected static final int DEFAULT_HASHCODE = 1;
    protected static final int PRIME = 31;
    protected int hashCode = DEFAULT_HASHCODE;
    public boolean hashCodeDirty = true;

    public String loopKey;



	
			    public String log_table_name;

				public String getLog_table_name () {
					return this.log_table_name;
				}
				
			    public String technology;

				public String getTechnology () {
					return this.technology;
				}
				


	@Override
	public int hashCode() {
		if (this.hashCodeDirty) {
			final int prime = PRIME;
			int result = DEFAULT_HASHCODE;
	
						result = prime * result + ((this.log_table_name == null) ? 0 : this.log_table_name.hashCode());
					
    		this.hashCode = result;
    		this.hashCodeDirty = false;
		}
		return this.hashCode;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) return true;
		if (obj == null) return false;
		if (getClass() != obj.getClass()) return false;
		final fsStruct other = (fsStruct) obj;
		
						if (this.log_table_name == null) {
							if (other.log_table_name != null)
								return false;
						
						} else if (!this.log_table_name.equals(other.log_table_name))
						
							return false;
					

		return true;
    }

	public void copyDataTo(fsStruct other) {

		other.log_table_name = this.log_table_name;
	            other.technology = this.technology;
	            
	}

	public void copyKeysDataTo(fsStruct other) {

		other.log_table_name = this.log_table_name;
	            	
	}




	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Base_dynamic.length) {
				if(length < 1024 && commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Base_dynamic.length == 0) {
   					commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Base_dynamic = new byte[1024];
				} else {
   					commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Base_dynamic = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Base_dynamic, 0, length);
			strReturn = new String(commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Base_dynamic, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Base_dynamic) {

        	try {

        		int length = 0;
		
					this.log_table_name = readString(dis);
					
					this.technology = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// String
				
						writeString(this.log_table_name,dos);
					
					// String
				
						writeString(this.technology,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("log_table_name="+log_table_name);
		sb.append(",technology="+technology);
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				if(log_table_name == null){
        					sb.append("<null>");
        				}else{
            				sb.append(log_table_name);
            			}
            		
        			sb.append("|");
        		
        				if(technology == null){
        					sb.append("<null>");
        				}else{
            				sb.append(technology);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(fsStruct other) {

		int returnValue = -1;
		
						returnValue = checkNullsAndCompare(this.log_table_name, other.log_table_name);
						if(returnValue != 0) {
							return returnValue;
						}

					
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public static class row2Struct implements routines.system.IPersistableRow<row2Struct> {
    final static byte[] commonByteArrayLock_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Base_dynamic = new byte[0];
    static byte[] commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Base_dynamic = new byte[0];

	
			    public String log_table_name;

				public String getLog_table_name () {
					return this.log_table_name;
				}
				
			    public String technology;

				public String getTechnology () {
					return this.technology;
				}
				



	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Base_dynamic.length) {
				if(length < 1024 && commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Base_dynamic.length == 0) {
   					commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Base_dynamic = new byte[1024];
				} else {
   					commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Base_dynamic = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Base_dynamic, 0, length);
			strReturn = new String(commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Base_dynamic, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Base_dynamic) {

        	try {

        		int length = 0;
		
					this.log_table_name = readString(dis);
					
					this.technology = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// String
				
						writeString(this.log_table_name,dos);
					
					// String
				
						writeString(this.technology,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("log_table_name="+log_table_name);
		sb.append(",technology="+technology);
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				if(log_table_name == null){
        					sb.append("<null>");
        				}else{
            				sb.append(log_table_name);
            			}
            		
        			sb.append("|");
        		
        				if(technology == null){
        					sb.append("<null>");
        				}else{
            				sb.append(technology);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(row2Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}
public void tGreenplumInput_3Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tGreenplumInput_3_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;



		row2Struct row2 = new row2Struct();
fsStruct fs = new fsStruct();





	
	/**
	 * [tFileOutputDelimitedGE_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tFileOutputDelimitedGE_1", false);
		start_Hash.put("tFileOutputDelimitedGE_1", System.currentTimeMillis());
		
	
	currentComponent="tFileOutputDelimitedGE_1";

	
			if (execStat) {
				if(resourceMap.get("inIterateVComp") == null){
					
						runStat.updateStatOnConnection("fs" + iterateId, 0, 0);
					
				}
			} 

		
		int tos_count_tFileOutputDelimitedGE_1 = 0;
		
    	class BytesLimit65535_tFileOutputDelimitedGE_1{
    		public void limitLog4jByte() throws Exception{
    			
    		}
    	}
    	
        new BytesLimit65535_tFileOutputDelimitedGE_1().limitLog4jByte();

    String log4jFileOutputDelimitedParamters_tFileOutputDelimitedGE_1 = "";
    log4jFileOutputDelimitedParamters_tFileOutputDelimitedGE_1 = log4jFileOutputDelimitedParamters_tFileOutputDelimitedGE_1 + "FILENAME = " + context.ETL_STORAGE_PATH + "/" +context.GP_SOURCE_NAME + "/" +((String)globalMap.get("timestamp"))+".csv" + " | ";
    log4jFileOutputDelimitedParamters_tFileOutputDelimitedGE_1 = log4jFileOutputDelimitedParamters_tFileOutputDelimitedGE_1 + "CSV_OPTION = " + false + " | ";
    log4jFileOutputDelimitedParamters_tFileOutputDelimitedGE_1 = log4jFileOutputDelimitedParamters_tFileOutputDelimitedGE_1 + "FIELDSEPARATOR = " + ";" + " | ";
    log4jFileOutputDelimitedParamters_tFileOutputDelimitedGE_1 = log4jFileOutputDelimitedParamters_tFileOutputDelimitedGE_1 + "INCLUDE_HEADER = " + false + " | ";
        log4jFileOutputDelimitedParamters_tFileOutputDelimitedGE_1 = log4jFileOutputDelimitedParamters_tFileOutputDelimitedGE_1 + "COMPRESS = " + false + " | ";
    log4jFileOutputDelimitedParamters_tFileOutputDelimitedGE_1 = log4jFileOutputDelimitedParamters_tFileOutputDelimitedGE_1 + "APPEND = " + false + " | ";
    log4jFileOutputDelimitedParamters_tFileOutputDelimitedGE_1 = log4jFileOutputDelimitedParamters_tFileOutputDelimitedGE_1 + "CREATE_DIRECTORY_IF_NOT_EXISTS = " + true + " | ";
    log4jFileOutputDelimitedParamters_tFileOutputDelimitedGE_1 = log4jFileOutputDelimitedParamters_tFileOutputDelimitedGE_1 + "SPLIT_INTO_SEVERAL_FILES = " + false + " | ";
    log4jFileOutputDelimitedParamters_tFileOutputDelimitedGE_1 = log4jFileOutputDelimitedParamters_tFileOutputDelimitedGE_1 + "OUTPUT_IN_ROW_MODE = " + false + " | ";

    log4jFileOutputDelimitedParamters_tFileOutputDelimitedGE_1 = "tFileOutputDelimitedGE_1 - Parameters:" + log4jFileOutputDelimitedParamters_tFileOutputDelimitedGE_1;
    log.debug(log4jFileOutputDelimitedParamters_tFileOutputDelimitedGE_1);
    StringBuffer log4jSb_tFileOutputDelimitedGE_1 = new StringBuffer();
    log.info("tFileOutputDelimitedGE_1 - Start to work.");
String fileName_tFileOutputDelimitedGE_1 = "";
    fileName_tFileOutputDelimitedGE_1 = (new java.io.File(context.ETL_STORAGE_PATH + "/" +context.GP_SOURCE_NAME + "/" +((String)globalMap.get("timestamp"))+".csv")).getAbsolutePath().replace("\\","/");
    String fullName_tFileOutputDelimitedGE_1 = null;
    String extension_tFileOutputDelimitedGE_1 = null;
    String directory_tFileOutputDelimitedGE_1 = null;
    if((fileName_tFileOutputDelimitedGE_1.indexOf("/") != -1)) {
        if(fileName_tFileOutputDelimitedGE_1.lastIndexOf(".") < fileName_tFileOutputDelimitedGE_1.lastIndexOf("/")) {
            fullName_tFileOutputDelimitedGE_1 = fileName_tFileOutputDelimitedGE_1;
            extension_tFileOutputDelimitedGE_1 = "";
        } else {
            fullName_tFileOutputDelimitedGE_1 = fileName_tFileOutputDelimitedGE_1.substring(0, fileName_tFileOutputDelimitedGE_1.lastIndexOf("."));
            extension_tFileOutputDelimitedGE_1 = fileName_tFileOutputDelimitedGE_1.substring(fileName_tFileOutputDelimitedGE_1.lastIndexOf("."));
        }
        directory_tFileOutputDelimitedGE_1 = fileName_tFileOutputDelimitedGE_1.substring(0, fileName_tFileOutputDelimitedGE_1.lastIndexOf("/"));
    } else {
        if(fileName_tFileOutputDelimitedGE_1.lastIndexOf(".") != -1) {
            fullName_tFileOutputDelimitedGE_1 = fileName_tFileOutputDelimitedGE_1.substring(0, fileName_tFileOutputDelimitedGE_1.lastIndexOf("."));
            extension_tFileOutputDelimitedGE_1 = fileName_tFileOutputDelimitedGE_1.substring(fileName_tFileOutputDelimitedGE_1.lastIndexOf("."));
        } else {
            fullName_tFileOutputDelimitedGE_1 = fileName_tFileOutputDelimitedGE_1;
            extension_tFileOutputDelimitedGE_1 = "";
        }
        directory_tFileOutputDelimitedGE_1 = "";
    }
    boolean isFileGenerated_tFileOutputDelimitedGE_1 = true;
    java.io.File filetFileOutputDelimitedGE_1 = new java.io.File(fileName_tFileOutputDelimitedGE_1);
    globalMap.put("tFileOutputDelimitedGE_1_FILE_NAME",fileName_tFileOutputDelimitedGE_1);
            int nb_line_tFileOutputDelimitedGE_1 = 0;
            int splitEvery_tFileOutputDelimitedGE_1 = 1000;
            int splitedFileNo_tFileOutputDelimitedGE_1 = 0;
            int currentRow_tFileOutputDelimitedGE_1 = 0;

            final String OUT_DELIM_tFileOutputDelimitedGE_1 = /** Start field tFileOutputDelimitedGE_1:FIELDSEPARATOR */";"/** End field tFileOutputDelimitedGE_1:FIELDSEPARATOR */;

            final String OUT_DELIM_ROWSEP_tFileOutputDelimitedGE_1 = /** Start field tFileOutputDelimitedGE_1:ROWSEPARATOR */"\n"/** End field tFileOutputDelimitedGE_1:ROWSEPARATOR */;

                    //create directory only if not exists
                    if(directory_tFileOutputDelimitedGE_1 != null && directory_tFileOutputDelimitedGE_1.trim().length() != 0) {
                        java.io.File dir_tFileOutputDelimitedGE_1 = new java.io.File(directory_tFileOutputDelimitedGE_1);
                        if(!dir_tFileOutputDelimitedGE_1.exists()) {
                                log.info("tFileOutputDelimitedGE_1 - Creating directory '" + dir_tFileOutputDelimitedGE_1.getCanonicalPath() +"'.");
                            dir_tFileOutputDelimitedGE_1.mkdirs();
                                log.info("tFileOutputDelimitedGE_1 - The directoy '"+ dir_tFileOutputDelimitedGE_1.getCanonicalPath() + "' has been created successfully.");
                        }
                    }

                        //routines.system.Row
                        java.io.Writer outtFileOutputDelimitedGE_1 = null;
                        outtFileOutputDelimitedGE_1 = new java.io.BufferedWriter(new java.io.OutputStreamWriter(
                        new java.io.FileOutputStream(fileName_tFileOutputDelimitedGE_1, false),"ISO-8859-15"));


        resourceMap.put("out_tFileOutputDelimitedGE_1", outtFileOutputDelimitedGE_1);
resourceMap.put("nb_line_tFileOutputDelimitedGE_1", nb_line_tFileOutputDelimitedGE_1);
 



/**
 * [tFileOutputDelimitedGE_1 begin ] stop
 */



	
	/**
	 * [tMap_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tMap_1", false);
		start_Hash.put("tMap_1", System.currentTimeMillis());
		
	
	currentComponent="tMap_1";

	
			if (execStat) {
				if(resourceMap.get("inIterateVComp") == null){
					
						runStat.updateStatOnConnection("row2" + iterateId, 0, 0);
					
				}
			} 

		
		int tos_count_tMap_1 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tMap_1 - "  + ("Start to work.") );
    	class BytesLimit65535_tMap_1{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tMap_1 = new StringBuilder();
            log4jParamters_tMap_1.append("Parameters:");
                    log4jParamters_tMap_1.append("LINK_STYLE" + " = " + "AUTO");
                log4jParamters_tMap_1.append(" | ");
                    log4jParamters_tMap_1.append("TEMPORARY_DATA_DIRECTORY" + " = " + "");
                log4jParamters_tMap_1.append(" | ");
                    log4jParamters_tMap_1.append("ROWS_BUFFER_SIZE" + " = " + "2000000");
                log4jParamters_tMap_1.append(" | ");
                    log4jParamters_tMap_1.append("CHANGE_HASH_AND_EQUALS_FOR_BIGDECIMAL" + " = " + "false");
                log4jParamters_tMap_1.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tMap_1 - "  + (log4jParamters_tMap_1) );
    		}
    	}
    	
        new BytesLimit65535_tMap_1().limitLog4jByte();




// ###############################
// # Lookup's keys initialization
		int count_row2_tMap_1 = 0;
		
// ###############################        

// ###############################
// # Vars initialization
class  Var__tMap_1__Struct  {
}
Var__tMap_1__Struct Var__tMap_1 = new Var__tMap_1__Struct();
// ###############################

// ###############################
// # Outputs initialization
				int count_fs_tMap_1 = 0;
				
fsStruct fs_tmp = new fsStruct();
// ###############################

        
        



        









 



/**
 * [tMap_1 begin ] stop
 */



	
	/**
	 * [tGreenplumInput_3 begin ] start
	 */

	

	
		
		ok_Hash.put("tGreenplumInput_3", false);
		start_Hash.put("tGreenplumInput_3", System.currentTimeMillis());
		
	
	currentComponent="tGreenplumInput_3";

	
		int tos_count_tGreenplumInput_3 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tGreenplumInput_3 - "  + ("Start to work.") );
    	class BytesLimit65535_tGreenplumInput_3{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tGreenplumInput_3 = new StringBuilder();
            log4jParamters_tGreenplumInput_3.append("Parameters:");
                    log4jParamters_tGreenplumInput_3.append("USE_EXISTING_CONNECTION" + " = " + "true");
                log4jParamters_tGreenplumInput_3.append(" | ");
                    log4jParamters_tGreenplumInput_3.append("CONNECTION" + " = " + "tGreenplumConnection_1");
                log4jParamters_tGreenplumInput_3.append(" | ");
                    log4jParamters_tGreenplumInput_3.append("TABLE" + " = " + "\"\"");
                log4jParamters_tGreenplumInput_3.append(" | ");
                    log4jParamters_tGreenplumInput_3.append("QUERYSTORE" + " = " + "\"\"");
                log4jParamters_tGreenplumInput_3.append(" | ");
                    log4jParamters_tGreenplumInput_3.append("QUERY" + " = " + "(String)globalMap.get(\"gp_sql\");");
                log4jParamters_tGreenplumInput_3.append(" | ");
                    log4jParamters_tGreenplumInput_3.append("USE_CURSOR" + " = " + "false");
                log4jParamters_tGreenplumInput_3.append(" | ");
                    log4jParamters_tGreenplumInput_3.append("TRIM_ALL_COLUMN" + " = " + "false");
                log4jParamters_tGreenplumInput_3.append(" | ");
                    log4jParamters_tGreenplumInput_3.append("TRIM_COLUMN" + " = " + "[{TRIM="+("false")+", SCHEMA_COLUMN="+("log_table_name")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("technology")+"}]");
                log4jParamters_tGreenplumInput_3.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tGreenplumInput_3 - "  + (log4jParamters_tGreenplumInput_3) );
    		}
    	}
    	
        new BytesLimit65535_tGreenplumInput_3().limitLog4jByte();
	
    
	
		    int nb_line_tGreenplumInput_3 = 0;
		    java.sql.Connection conn_tGreenplumInput_3 = null;
		        conn_tGreenplumInput_3 = (java.sql.Connection)globalMap.get("conn_tGreenplumConnection_1");
				
				if(conn_tGreenplumInput_3 != null) {
					if(conn_tGreenplumInput_3.getMetaData() != null) {
						
						log.debug("tGreenplumInput_3 - Uses an existing connection with username '" + conn_tGreenplumInput_3.getMetaData().getUserName() + "'. Connection URL: " + conn_tGreenplumInput_3.getMetaData().getURL() + ".");
						
					}
				}
			
		    
			java.sql.Statement stmt_tGreenplumInput_3 = conn_tGreenplumInput_3.createStatement();

		    String dbquery_tGreenplumInput_3 = (String)globalMap.get("gp_sql");;
			
                log.debug("tGreenplumInput_3 - Executing the query: '"+dbquery_tGreenplumInput_3+"'.");
			

                       globalMap.put("tGreenplumInput_3_QUERY",dbquery_tGreenplumInput_3);

		    java.sql.ResultSet rs_tGreenplumInput_3 = null;
		try{
		    rs_tGreenplumInput_3 = stmt_tGreenplumInput_3.executeQuery(dbquery_tGreenplumInput_3);
		    java.sql.ResultSetMetaData rsmd_tGreenplumInput_3 = rs_tGreenplumInput_3.getMetaData();
		    int colQtyInRs_tGreenplumInput_3 = rsmd_tGreenplumInput_3.getColumnCount();

		    String tmpContent_tGreenplumInput_3 = null;
		    
		    
		    	log.debug("tGreenplumInput_3 - Retrieving records from the database.");
		    
		    while (rs_tGreenplumInput_3.next()) {
		        nb_line_tGreenplumInput_3++;
		        
							if(colQtyInRs_tGreenplumInput_3 < 1) {
								row2.log_table_name = null;
							} else {
	                         		
        	row2.log_table_name = routines.system.JDBCUtil.getString(rs_tGreenplumInput_3, 1, false);
		                    }
							if(colQtyInRs_tGreenplumInput_3 < 2) {
								row2.technology = null;
							} else {
	                         		
        	row2.technology = routines.system.JDBCUtil.getString(rs_tGreenplumInput_3, 2, false);
		                    }
					
						log.debug("tGreenplumInput_3 - Retrieving the record " + nb_line_tGreenplumInput_3 + ".");
					


 



/**
 * [tGreenplumInput_3 begin ] stop
 */
	
	/**
	 * [tGreenplumInput_3 main ] start
	 */

	

	
	
	currentComponent="tGreenplumInput_3";

	

 


	tos_count_tGreenplumInput_3++;

/**
 * [tGreenplumInput_3 main ] stop
 */

	
	/**
	 * [tMap_1 main ] start
	 */

	

	
	
	currentComponent="tMap_1";

	

			//row2
			//row2


			
				if(execStat){
					runStat.updateStatOnConnection("row2"+iterateId,1, 1);
				} 
			

		
    			if(log.isTraceEnabled()){
    				log.trace("row2 - " + (row2==null? "": row2.toLogString()));
    			}
    		

		
		
		boolean hasCasePrimitiveKeyWithNull_tMap_1 = false;
		
        // ###############################
        // # Input tables (lookups)
		  boolean rejectedInnerJoin_tMap_1 = false;
		  boolean mainRowRejected_tMap_1 = false;
            				    								  
		// ###############################
        { // start of Var scope
        
	        // ###############################
        	// # Vars tables
        
Var__tMap_1__Struct Var = Var__tMap_1;// ###############################
        // ###############################
        // # Output tables

fs = null;


// # Output table : 'fs'
count_fs_tMap_1++;

fs_tmp.log_table_name = row2.log_table_name;
fs_tmp.technology = row2.technology ;
fs = fs_tmp;
log.debug("tMap_1 - Outputting the record " + count_fs_tMap_1 + " of the output table 'fs'.");

// ###############################

} // end of Var scope

rejectedInnerJoin_tMap_1 = false;










 


	tos_count_tMap_1++;

/**
 * [tMap_1 main ] stop
 */
// Start of branch "fs"
if(fs != null) { 



	
	/**
	 * [tFileOutputDelimitedGE_1 main ] start
	 */

	

	
	
	currentComponent="tFileOutputDelimitedGE_1";

	

			//fs
			//fs


			
				if(execStat){
					runStat.updateStatOnConnection("fs"+iterateId,1, 1);
				} 
			

		
    			if(log.isTraceEnabled()){
    				log.trace("fs - " + (fs==null? "": fs.toLogString()));
    			}
    		


                    StringBuilder sb_tFileOutputDelimitedGE_1 = new StringBuilder();
                            if(fs.log_table_name != null) {
                        sb_tFileOutputDelimitedGE_1.append(
                            fs.log_table_name
                        );
                            }
                            sb_tFileOutputDelimitedGE_1.append(OUT_DELIM_tFileOutputDelimitedGE_1);
                            if(fs.technology != null) {
                        sb_tFileOutputDelimitedGE_1.append(
                            fs.technology
                        );
                            }
                    sb_tFileOutputDelimitedGE_1.append(OUT_DELIM_ROWSEP_tFileOutputDelimitedGE_1);


                    synchronized (multiThreadLockWrite) {
                    nb_line_tFileOutputDelimitedGE_1++;
                    resourceMap.put("nb_line_tFileOutputDelimitedGE_1", nb_line_tFileOutputDelimitedGE_1);

                        outtFileOutputDelimitedGE_1.write(sb_tFileOutputDelimitedGE_1.toString());
                        log.debug("tFileOutputDelimitedGE_1 - Writing the record " + nb_line_tFileOutputDelimitedGE_1 + ".");
                        log.trace("tFileOutputDelimitedGE_1 - Content of the record " + nb_line_tFileOutputDelimitedGE_1 + ": " + sb_tFileOutputDelimitedGE_1);

                    }



 


	tos_count_tFileOutputDelimitedGE_1++;

/**
 * [tFileOutputDelimitedGE_1 main ] stop
 */

} // End of branch "fs"







	
	/**
	 * [tGreenplumInput_3 end ] start
	 */

	

	
	
	currentComponent="tGreenplumInput_3";

	

	}
}finally{
	stmt_tGreenplumInput_3.close();

}
globalMap.put("tGreenplumInput_3_NB_LINE",nb_line_tGreenplumInput_3);
	    		log.debug("tGreenplumInput_3 - Retrieved records count: "+nb_line_tGreenplumInput_3 + " .");
			

 
                if(log.isDebugEnabled())
            log.debug("tGreenplumInput_3 - "  + ("Done.") );

ok_Hash.put("tGreenplumInput_3", true);
end_Hash.put("tGreenplumInput_3", System.currentTimeMillis());




/**
 * [tGreenplumInput_3 end ] stop
 */

	
	/**
	 * [tMap_1 end ] start
	 */

	

	
	
	currentComponent="tMap_1";

	


// ###############################
// # Lookup hashes releasing
// ###############################      
				log.debug("tMap_1 - Written records count in the table 'fs': " + count_fs_tMap_1 + ".");





			if(execStat){
				if(resourceMap.get("inIterateVComp") == null || !((Boolean)resourceMap.get("inIterateVComp"))){
			 		runStat.updateStatOnConnection("row2"+iterateId,2, 0); 
			 	}
			}
		
 
                if(log.isDebugEnabled())
            log.debug("tMap_1 - "  + ("Done.") );

ok_Hash.put("tMap_1", true);
end_Hash.put("tMap_1", System.currentTimeMillis());




/**
 * [tMap_1 end ] stop
 */

	
	/**
	 * [tFileOutputDelimitedGE_1 end ] start
	 */

	

	
	
	currentComponent="tFileOutputDelimitedGE_1";

	



		
	   		synchronized (multiThreadLockWrite) {
		
			
					if(outtFileOutputDelimitedGE_1!=null) {
						outtFileOutputDelimitedGE_1.flush();
						outtFileOutputDelimitedGE_1.close();
					}
				
				globalMap.put("tFileOutputDelimitedGE_1_NB_LINE",nb_line_tFileOutputDelimitedGE_1);
				globalMap.put("tFileOutputDelimitedGE_1_FILE_NAME",fileName_tFileOutputDelimitedGE_1);
			
		
			}
		
		
		resourceMap.put("finish_tFileOutputDelimitedGE_1", true);
	
				log.info("tFileOutputDelimitedGE_1 - Written records count: " + nb_line_tFileOutputDelimitedGE_1 + " .");
				log.info("tFileOutputDelimitedGE_1 - Done.");

			if(execStat){
				if(resourceMap.get("inIterateVComp") == null || !((Boolean)resourceMap.get("inIterateVComp"))){
			 		runStat.updateStatOnConnection("fs"+iterateId,2, 0); 
			 	}
			}
		
 

ok_Hash.put("tFileOutputDelimitedGE_1", true);
end_Hash.put("tFileOutputDelimitedGE_1", System.currentTimeMillis());

				if(execStat){   
   	 				runStat.updateStatOnConnection("OnComponentOk1", 0, "ok");
				}
				tGreenplumClose_1Process(globalMap);



/**
 * [tFileOutputDelimitedGE_1 end ] stop
 */






				}//end the resume

				
				    			if(resumeEntryMethodName == null || globalResumeTicket){
				    				resumeUtil.addLog("CHECKPOINT", "CONNECTION:SUBJOB_OK:tGreenplumInput_3:OnSubjobOk", "", Thread.currentThread().getId() + "", "", "", "", "", "");
								}	    				    			
					    	
								if(execStat){    	
									runStat.updateStatOnConnection("OnSubjobOk13", 0, "ok");
								} 
							
							tJava_2Process(globalMap); 
						



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage());
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tGreenplumInput_3 finally ] start
	 */

	

	
	
	currentComponent="tGreenplumInput_3";

	

 



/**
 * [tGreenplumInput_3 finally ] stop
 */

	
	/**
	 * [tMap_1 finally ] start
	 */

	

	
	
	currentComponent="tMap_1";

	

 



/**
 * [tMap_1 finally ] stop
 */

	
	/**
	 * [tFileOutputDelimitedGE_1 finally ] start
	 */

	

	
	
	currentComponent="tFileOutputDelimitedGE_1";

	


		if(resourceMap.get("finish_tFileOutputDelimitedGE_1") == null){ 
			
		   		synchronized (multiThreadLockWrite) {
			
				
						java.io.Writer outtFileOutputDelimitedGE_1 = (java.io.Writer)resourceMap.get("out_tFileOutputDelimitedGE_1");
						if(outtFileOutputDelimitedGE_1!=null) {
							outtFileOutputDelimitedGE_1.flush();
							outtFileOutputDelimitedGE_1.close();
						}
					
				
				}
			
			
		}
	

 



/**
 * [tFileOutputDelimitedGE_1 finally ] stop
 */






				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tGreenplumInput_3_SUBPROCESS_STATE", 1);
	}
	

public void tGreenplumClose_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tGreenplumClose_1_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;





	
	/**
	 * [tGreenplumClose_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tGreenplumClose_1", false);
		start_Hash.put("tGreenplumClose_1", System.currentTimeMillis());
		
	
	currentComponent="tGreenplumClose_1";

	
		int tos_count_tGreenplumClose_1 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tGreenplumClose_1 - "  + ("Start to work.") );
    	class BytesLimit65535_tGreenplumClose_1{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tGreenplumClose_1 = new StringBuilder();
            log4jParamters_tGreenplumClose_1.append("Parameters:");
                    log4jParamters_tGreenplumClose_1.append("CONNECTION" + " = " + "tGreenplumConnection_1");
                log4jParamters_tGreenplumClose_1.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tGreenplumClose_1 - "  + (log4jParamters_tGreenplumClose_1) );
    		}
    	}
    	
        new BytesLimit65535_tGreenplumClose_1().limitLog4jByte();

 



/**
 * [tGreenplumClose_1 begin ] stop
 */
	
	/**
	 * [tGreenplumClose_1 main ] start
	 */

	

	
	
	currentComponent="tGreenplumClose_1";

	



	java.sql.Connection conn_tGreenplumClose_1 = (java.sql.Connection)globalMap.get("conn_tGreenplumConnection_1");
	if(conn_tGreenplumClose_1 != null && !conn_tGreenplumClose_1.isClosed())
	{
                if(log.isDebugEnabled())
            log.debug("tGreenplumClose_1 - "  + ("Closing the connection ")  + ("conn_tGreenplumConnection_1")  + (" to the database.") );
        conn_tGreenplumClose_1.close();
                if(log.isDebugEnabled())
            log.debug("tGreenplumClose_1 - "  + ("Connection ")  + ("conn_tGreenplumConnection_1")  + (" to the database has closed.") );
	}

 


	tos_count_tGreenplumClose_1++;

/**
 * [tGreenplumClose_1 main ] stop
 */
	
	/**
	 * [tGreenplumClose_1 end ] start
	 */

	

	
	
	currentComponent="tGreenplumClose_1";

	

 
                if(log.isDebugEnabled())
            log.debug("tGreenplumClose_1 - "  + ("Done.") );

ok_Hash.put("tGreenplumClose_1", true);
end_Hash.put("tGreenplumClose_1", System.currentTimeMillis());




/**
 * [tGreenplumClose_1 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage());
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tGreenplumClose_1 finally ] start
	 */

	

	
	
	currentComponent="tGreenplumClose_1";

	

 



/**
 * [tGreenplumClose_1 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tGreenplumClose_1_SUBPROCESS_STATE", 1);
	}
	

public void tJava_2Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tJava_2_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tJava_2 begin ] start
	 */

	

	
		
		ok_Hash.put("tJava_2", false);
		start_Hash.put("tJava_2", System.currentTimeMillis());
		
	
	currentComponent="tJava_2";

	
		int tos_count_tJava_2 = 0;
		
    	class BytesLimit65535_tJava_2{
    		public void limitLog4jByte() throws Exception{
    			
    		}
    	}
    	
        new BytesLimit65535_tJava_2().limitLog4jByte();


System.out.println("==============================");
System.out.println("(String)context.TABLE_NAME");
System.out.println(context.getProperty("TABLE_NAME").toUpperCase());
System.out.println("==============================");
System.out.println("(String)context.LOG_PLANT_NAME");
System.out.println(context.getProperty("LOG_PLANT_NAME").toUpperCase());
System.out.println("==============================");
System.out.println("(String)context.LOG_SYSTEM_NAME");
System.out.println(context.getProperty("LOG_SYSTEM_NAME").toUpperCase());
System.out.println("==============================");

context.LOG_RUN_ID=0;
//context.LOG_PLANT_NAME="NULL";
//context.LOG_SYSTEM_NAME="NULL";
context.LOG_TABLE_NAME=(String)((String)globalMap.get("orig_table_name") != null ? ((String)globalMap.get("orig_table_name")).toLowerCase() : "all");
//context.LOG_JOB_NAME="NULL";
//context.LOG_DATA_PATH="NULL";
//context.LOG_TECHNOLOGY="NULL";
context.LOG_STATUS="NULL";
context.LOG_NO_OF_INSERTS=0;
context.LOG_NO_OF_UPDATES=0;
context.LOG_NO_OF_DELETES=0;
context.LOG_NO_OF_ERRORS=0;
context.LOG_MESSAGE="NULL";
context.LOG_SOURCE_ROW_COUNT=0;
context.LOG_TARGET_ROW_COUNT=0;
context.LOG_ERROR_CATEGORY="NULL";

String strInsertLogTemplate = 
"SELECT sbdt.edl_log ("+
"  #RUN_ID, " +
"  #PLANT_NAME, " +
"  #SYSTEM_NAME, " +
"  #JOB_NAME, " +
"  #TABLE_NAME, " +
"  #STATUS, " +
"  #DATA_PATH, " +
"  #TECHNOLOGY, " +
"  #NO_OF_INSERTS, " +
"  #NO_OF_UPDATES, " +
"  #NO_OF_DELETES, " +
"  #NO_OF_ERRORS, " +
"  #MESSAGE, " +
"  #SOURCE_ROW_COUNT, " +
"  #TARGET_ROW_COUNT, " +
"  #ERROR_CATEGORY " +
") ";
globalMap.put("insert_log_template", strInsertLogTemplate);

String strIncrementRollingCallTemplate=
"SELECT sbdt.edl_increments_rolling ("+
"  #TARGET_SCHEMA, "+
"  #TARGET_TABLE_NAME "+
"); ";
globalMap.put("increment_rolling_call_template", strIncrementRollingCallTemplate);

String strSoftDeleteCallTemplate=
"SELECT sbdt.edl_softdelete ("+
"  #TARGET_SCHEMA, "+
"  #TARGET_TABLE_NAME "+
"); ";
globalMap.put("softdelete_call_template", strSoftDeleteCallTemplate);

String strDataProfilingCallTemplate=
"SELECT sbdt.edl_data_profiling ("+
"  #TARGET_SCHEMA, "+
"  #TARGET_TABLE_NAME "+
"); ";
globalMap.put("data_profiling_call_template", strDataProfilingCallTemplate);


//System.out.println("******************************");
//globalMap.put("now",new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(TalendDate.getCurrentDate()).toString());
//System.out.println(globalMap.get("now"));
//((String)globalMap.get("tJavaRow_5_ERROR_MESSAGE")) != null
//((Integer)context.LOG_RUN_ID).toString()
//globalMap.put("now_sql","TO_TIMESTAMP('" + ((String)globalMap.get("now")) + "', 'YYYY-MM-DD HH24:MI:SS')::TIMESTAMP WITH TIME ZONE ");
//System.out.println(globalMap.get("now_sql"));
//if (context.LOG_PLANT_NAME.equals("")==true) {
//  context.LOG_PLANT_NAME="Grove City";
//};
//System.out.println(globalMap.get("now"));
//((String)globalMap.get("now"))
//if (globalMap.get("now")=="X") {
//}
//if (context.getProperty("BF_SCHEMA").length() == 0) {
//	context.setProperty("TABLE_NAME", "pgpduke_energy");
//}

 



/**
 * [tJava_2 begin ] stop
 */
	
	/**
	 * [tJava_2 main ] start
	 */

	

	
	
	currentComponent="tJava_2";

	

 


	tos_count_tJava_2++;

/**
 * [tJava_2 main ] stop
 */
	
	/**
	 * [tJava_2 end ] start
	 */

	

	
	
	currentComponent="tJava_2";

	

 

ok_Hash.put("tJava_2", true);
end_Hash.put("tJava_2", System.currentTimeMillis());




/**
 * [tJava_2 end ] stop
 */
				}//end the resume

				
				    			if(resumeEntryMethodName == null || globalResumeTicket){
				    				resumeUtil.addLog("CHECKPOINT", "CONNECTION:SUBJOB_OK:tJava_2:OnSubjobOk", "", Thread.currentThread().getId() + "", "", "", "", "", "");
								}	    				    			
					    	
								if(execStat){    	
									runStat.updateStatOnConnection("OnSubjobOk14", 0, "ok");
								} 
							
							tGreenplumConnection_2Process(globalMap); 
						



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage());
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tJava_2 finally ] start
	 */

	

	
	
	currentComponent="tJava_2";

	

 



/**
 * [tJava_2 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tJava_2_SUBPROCESS_STATE", 1);
	}
	

public void tGreenplumConnection_2Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tGreenplumConnection_2_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tGreenplumConnection_2 begin ] start
	 */

	

	
		
		ok_Hash.put("tGreenplumConnection_2", false);
		start_Hash.put("tGreenplumConnection_2", System.currentTimeMillis());
		
	
	currentComponent="tGreenplumConnection_2";

	
		int tos_count_tGreenplumConnection_2 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tGreenplumConnection_2 - "  + ("Start to work.") );
    	class BytesLimit65535_tGreenplumConnection_2{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tGreenplumConnection_2 = new StringBuilder();
            log4jParamters_tGreenplumConnection_2.append("Parameters:");
                    log4jParamters_tGreenplumConnection_2.append("HOST" + " = " + "context.SOURCING_Server");
                log4jParamters_tGreenplumConnection_2.append(" | ");
                    log4jParamters_tGreenplumConnection_2.append("PORT" + " = " + "context.SOURCING_Port");
                log4jParamters_tGreenplumConnection_2.append(" | ");
                    log4jParamters_tGreenplumConnection_2.append("DBNAME" + " = " + "context.SOURCING_Database");
                log4jParamters_tGreenplumConnection_2.append(" | ");
                    log4jParamters_tGreenplumConnection_2.append("SCHEMA_DB" + " = " + "context.SOURCING_Schema");
                log4jParamters_tGreenplumConnection_2.append(" | ");
                    log4jParamters_tGreenplumConnection_2.append("USER" + " = " + "context.SOURCING_Login");
                log4jParamters_tGreenplumConnection_2.append(" | ");
                    log4jParamters_tGreenplumConnection_2.append("PASS" + " = " + String.valueOf(routines.system.PasswordEncryptUtil.encryptPassword(context.SOURCING_Password)).substring(0, 4) + "...");     
                log4jParamters_tGreenplumConnection_2.append(" | ");
                    log4jParamters_tGreenplumConnection_2.append("USE_SHARED_CONNECTION" + " = " + "true");
                log4jParamters_tGreenplumConnection_2.append(" | ");
                    log4jParamters_tGreenplumConnection_2.append("SHARED_CONNECTION_NAME" + " = " + "\"base_dynamic\"+((String)globalMap.get(\"timestamp\"))");
                log4jParamters_tGreenplumConnection_2.append(" | ");
                    log4jParamters_tGreenplumConnection_2.append("USE_SSL" + " = " + "true");
                log4jParamters_tGreenplumConnection_2.append(" | ");
                    log4jParamters_tGreenplumConnection_2.append("AUTO_COMMIT" + " = " + "true");
                log4jParamters_tGreenplumConnection_2.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tGreenplumConnection_2 - "  + (log4jParamters_tGreenplumConnection_2) );
    		}
    	}
    	
        new BytesLimit65535_tGreenplumConnection_2().limitLog4jByte();
	

	
				String url_tGreenplumConnection_2 = "jdbc:postgresql://"+context.SOURCING_Server+":"+context.SOURCING_Port+"/"+context.SOURCING_Database+"?ssl=true&sslfactory=org.postgresql.ssl.NonValidatingFactory";

	String dbUser_tGreenplumConnection_2 = context.SOURCING_Login;
	
	
		
	final String decryptedPassword_tGreenplumConnection_2 = context.SOURCING_Password; 
		String dbPwd_tGreenplumConnection_2 = decryptedPassword_tGreenplumConnection_2;
	

	java.sql.Connection conn_tGreenplumConnection_2 = null;
	
	
			SharedDBConnectionLog4j.initLogger(log,"tGreenplumConnection_2");
			String sharedConnectionName_tGreenplumConnection_2 = "base_dynamic"+((String)globalMap.get("timestamp"));
			conn_tGreenplumConnection_2 = SharedDBConnectionLog4j.getDBConnection("org.postgresql.Driver",url_tGreenplumConnection_2,dbUser_tGreenplumConnection_2 , dbPwd_tGreenplumConnection_2 , sharedConnectionName_tGreenplumConnection_2);
	if (null != conn_tGreenplumConnection_2) {
		
			log.debug("tGreenplumConnection_2 - Connection is set auto commit to 'true'.");
			conn_tGreenplumConnection_2.setAutoCommit(true);
	}

	globalMap.put("schema_" + "tGreenplumConnection_2",context.SOURCING_Schema);

	globalMap.put("conn_" + "tGreenplumConnection_2",conn_tGreenplumConnection_2);
 



/**
 * [tGreenplumConnection_2 begin ] stop
 */
	
	/**
	 * [tGreenplumConnection_2 main ] start
	 */

	

	
	
	currentComponent="tGreenplumConnection_2";

	

 


	tos_count_tGreenplumConnection_2++;

/**
 * [tGreenplumConnection_2 main ] stop
 */
	
	/**
	 * [tGreenplumConnection_2 end ] start
	 */

	

	
	
	currentComponent="tGreenplumConnection_2";

	

 
                if(log.isDebugEnabled())
            log.debug("tGreenplumConnection_2 - "  + ("Done.") );

ok_Hash.put("tGreenplumConnection_2", true);
end_Hash.put("tGreenplumConnection_2", System.currentTimeMillis());




/**
 * [tGreenplumConnection_2 end ] stop
 */
				}//end the resume

				
				    			if(resumeEntryMethodName == null || globalResumeTicket){
				    				resumeUtil.addLog("CHECKPOINT", "CONNECTION:SUBJOB_OK:tGreenplumConnection_2:OnSubjobOk", "", Thread.currentThread().getId() + "", "", "", "", "", "");
								}	    				    			
					    	
								if(execStat){    	
									runStat.updateStatOnConnection("OnSubjobOk15", 0, "ok");
								} 
							
							tGreenplumInput_5Process(globalMap); 
						



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage());
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tGreenplumConnection_2 finally ] start
	 */

	

	
	
	currentComponent="tGreenplumConnection_2";

	

 



/**
 * [tGreenplumConnection_2 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tGreenplumConnection_2_SUBPROCESS_STATE", 1);
	}
	


public static class row13Struct implements routines.system.IPersistableRow<row13Struct> {
    final static byte[] commonByteArrayLock_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Base_dynamic = new byte[0];
    static byte[] commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Base_dynamic = new byte[0];

	
			    public Integer run_id;

				public Integer getRun_id () {
					return this.run_id;
				}
				


	private Integer readInteger(ObjectInputStream dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}

	private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException{
		if(intNum == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeInt(intNum);
    	}
	}

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Base_dynamic) {

        	try {

        		int length = 0;
		
						this.run_id = readInteger(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// Integer
				
						writeInteger(this.run_id,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("run_id="+String.valueOf(run_id));
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				if(run_id == null){
        					sb.append("<null>");
        				}else{
            				sb.append(run_id);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(row13Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}
public void tGreenplumInput_5Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tGreenplumInput_5_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;



		row13Struct row13 = new row13Struct();




	
	/**
	 * [tJavaRow_3 begin ] start
	 */

	

	
		
		ok_Hash.put("tJavaRow_3", false);
		start_Hash.put("tJavaRow_3", System.currentTimeMillis());
		
	
	currentComponent="tJavaRow_3";

	
			if (execStat) {
				if(resourceMap.get("inIterateVComp") == null){
					
						runStat.updateStatOnConnection("row13" + iterateId, 0, 0);
					
				}
			} 

		
		int tos_count_tJavaRow_3 = 0;
		
    	class BytesLimit65535_tJavaRow_3{
    		public void limitLog4jByte() throws Exception{
    			
    		}
    	}
    	
        new BytesLimit65535_tJavaRow_3().limitLog4jByte();

int nb_line_tJavaRow_3 = 0;

 



/**
 * [tJavaRow_3 begin ] stop
 */



	
	/**
	 * [tGreenplumInput_5 begin ] start
	 */

	

	
		
		ok_Hash.put("tGreenplumInput_5", false);
		start_Hash.put("tGreenplumInput_5", System.currentTimeMillis());
		
	
	currentComponent="tGreenplumInput_5";

	
		int tos_count_tGreenplumInput_5 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tGreenplumInput_5 - "  + ("Start to work.") );
    	class BytesLimit65535_tGreenplumInput_5{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tGreenplumInput_5 = new StringBuilder();
            log4jParamters_tGreenplumInput_5.append("Parameters:");
                    log4jParamters_tGreenplumInput_5.append("USE_EXISTING_CONNECTION" + " = " + "true");
                log4jParamters_tGreenplumInput_5.append(" | ");
                    log4jParamters_tGreenplumInput_5.append("CONNECTION" + " = " + "tGreenplumConnection_2");
                log4jParamters_tGreenplumInput_5.append(" | ");
                    log4jParamters_tGreenplumInput_5.append("TABLE" + " = " + "\"\"");
                log4jParamters_tGreenplumInput_5.append(" | ");
                    log4jParamters_tGreenplumInput_5.append("QUERYSTORE" + " = " + "\"\"");
                log4jParamters_tGreenplumInput_5.append(" | ");
                    log4jParamters_tGreenplumInput_5.append("QUERY" + " = " + "\"select NEXTVAL('sbdt.edl_run_id_seq')\";  ");
                log4jParamters_tGreenplumInput_5.append(" | ");
                    log4jParamters_tGreenplumInput_5.append("USE_CURSOR" + " = " + "true");
                log4jParamters_tGreenplumInput_5.append(" | ");
                    log4jParamters_tGreenplumInput_5.append("CURSOR_SIZE" + " = " + "1000");
                log4jParamters_tGreenplumInput_5.append(" | ");
                    log4jParamters_tGreenplumInput_5.append("TRIM_ALL_COLUMN" + " = " + "false");
                log4jParamters_tGreenplumInput_5.append(" | ");
                    log4jParamters_tGreenplumInput_5.append("TRIM_COLUMN" + " = " + "[{TRIM="+("false")+", SCHEMA_COLUMN="+("run_id")+"}]");
                log4jParamters_tGreenplumInput_5.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tGreenplumInput_5 - "  + (log4jParamters_tGreenplumInput_5) );
    		}
    	}
    	
        new BytesLimit65535_tGreenplumInput_5().limitLog4jByte();
	
    
	
		    int nb_line_tGreenplumInput_5 = 0;
		    java.sql.Connection conn_tGreenplumInput_5 = null;
		        conn_tGreenplumInput_5 = (java.sql.Connection)globalMap.get("conn_tGreenplumConnection_2");
				
				if(conn_tGreenplumInput_5 != null) {
					if(conn_tGreenplumInput_5.getMetaData() != null) {
						
						log.debug("tGreenplumInput_5 - Uses an existing connection with username '" + conn_tGreenplumInput_5.getMetaData().getUserName() + "'. Connection URL: " + conn_tGreenplumInput_5.getMetaData().getURL() + ".");
						
					}
				}
			
		    
			java.sql.Statement stmt_tGreenplumInput_5 = conn_tGreenplumInput_5.createStatement();
                stmt_tGreenplumInput_5.setFetchSize(1000);

		    String dbquery_tGreenplumInput_5 = "select NEXTVAL('sbdt.edl_run_id_seq')";
;
			
                log.debug("tGreenplumInput_5 - Executing the query: '"+dbquery_tGreenplumInput_5+"'.");
			

                       globalMap.put("tGreenplumInput_5_QUERY",dbquery_tGreenplumInput_5);

		    java.sql.ResultSet rs_tGreenplumInput_5 = null;
		try{
		    rs_tGreenplumInput_5 = stmt_tGreenplumInput_5.executeQuery(dbquery_tGreenplumInput_5);
		    java.sql.ResultSetMetaData rsmd_tGreenplumInput_5 = rs_tGreenplumInput_5.getMetaData();
		    int colQtyInRs_tGreenplumInput_5 = rsmd_tGreenplumInput_5.getColumnCount();

		    String tmpContent_tGreenplumInput_5 = null;
		    
		    
		    	log.debug("tGreenplumInput_5 - Retrieving records from the database.");
		    
		    while (rs_tGreenplumInput_5.next()) {
		        nb_line_tGreenplumInput_5++;
		        
							if(colQtyInRs_tGreenplumInput_5 < 1) {
								row13.run_id = null;
							} else {
		                          
            if(rs_tGreenplumInput_5.getObject(1) != null) {
                row13.run_id = rs_tGreenplumInput_5.getInt(1);
            } else {
                    row13.run_id = null;
            }
		                    }
					
						log.debug("tGreenplumInput_5 - Retrieving the record " + nb_line_tGreenplumInput_5 + ".");
					


 



/**
 * [tGreenplumInput_5 begin ] stop
 */
	
	/**
	 * [tGreenplumInput_5 main ] start
	 */

	

	
	
	currentComponent="tGreenplumInput_5";

	

 


	tos_count_tGreenplumInput_5++;

/**
 * [tGreenplumInput_5 main ] stop
 */

	
	/**
	 * [tJavaRow_3 main ] start
	 */

	

	
	
	currentComponent="tJavaRow_3";

	

			//row13
			//row13


			
				if(execStat){
					runStat.updateStatOnConnection("row13"+iterateId,1, 1);
				} 
			

		
    			if(log.isTraceEnabled()){
    				log.trace("row13 - " + (row13==null? "": row13.toLogString()));
    			}
    		

    context.LOG_RUN_ID=row13.run_id;
globalMap.put("BASE_RUN_ID", row13.run_id);
    nb_line_tJavaRow_3++;   

 


	tos_count_tJavaRow_3++;

/**
 * [tJavaRow_3 main ] stop
 */



	
	/**
	 * [tGreenplumInput_5 end ] start
	 */

	

	
	
	currentComponent="tGreenplumInput_5";

	

	}
}finally{
	stmt_tGreenplumInput_5.close();

}
globalMap.put("tGreenplumInput_5_NB_LINE",nb_line_tGreenplumInput_5);
	    		log.debug("tGreenplumInput_5 - Retrieved records count: "+nb_line_tGreenplumInput_5 + " .");
			

 
                if(log.isDebugEnabled())
            log.debug("tGreenplumInput_5 - "  + ("Done.") );

ok_Hash.put("tGreenplumInput_5", true);
end_Hash.put("tGreenplumInput_5", System.currentTimeMillis());




/**
 * [tGreenplumInput_5 end ] stop
 */

	
	/**
	 * [tJavaRow_3 end ] start
	 */

	

	
	
	currentComponent="tJavaRow_3";

	

globalMap.put("tJavaRow_3_NB_LINE",nb_line_tJavaRow_3);
			if(execStat){
				if(resourceMap.get("inIterateVComp") == null || !((Boolean)resourceMap.get("inIterateVComp"))){
			 		runStat.updateStatOnConnection("row13"+iterateId,2, 0); 
			 	}
			}
		
 

ok_Hash.put("tJavaRow_3", true);
end_Hash.put("tJavaRow_3", System.currentTimeMillis());

   			if (true) {
   				
					if(execStat){   
   	 					runStat.updateStatOnConnection("If4", 0, "true");
					}
				
    			tJava_6Process(globalMap);
   			}

			   
   				else{
					if(execStat){   
   	 					runStat.updateStatOnConnection("If4", 0, "false");
					}   	 
   				}



/**
 * [tJavaRow_3 end ] stop
 */



				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage());
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tGreenplumInput_5 finally ] start
	 */

	

	
	
	currentComponent="tGreenplumInput_5";

	

 



/**
 * [tGreenplumInput_5 finally ] stop
 */

	
	/**
	 * [tJavaRow_3 finally ] start
	 */

	

	
	
	currentComponent="tJavaRow_3";

	

 



/**
 * [tJavaRow_3 finally ] stop
 */



				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tGreenplumInput_5_SUBPROCESS_STATE", 1);
	}
	

public void tJava_6Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tJava_6_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tJava_6 begin ] start
	 */

	

	
		
		ok_Hash.put("tJava_6", false);
		start_Hash.put("tJava_6", System.currentTimeMillis());
		
	
	currentComponent="tJava_6";

	
		int tos_count_tJava_6 = 0;
		
    	class BytesLimit65535_tJava_6{
    		public void limitLog4jByte() throws Exception{
    			
    		}
    	}
    	
        new BytesLimit65535_tJava_6().limitLog4jByte();


System.out.println("select row_id where run_id = "+((Integer)globalMap.get("BASE_RUN_ID")));
//context.LOG_PLANT_NAME="NULL";
//context.LOG_SYSTEM_NAME="NULL";
//context.LOG_TABLE_NAME="NULL";
//context.LOG_JOB_NAME="NULL";
//context.LOG_DATA_PATH="NULL";
//context.LOG_TECHNOLOGY="NULL";
context.LOG_STATUS="Start";
context.LOG_MESSAGE="NULL";
context.LOG_ERROR_CATEGORY="NULL";
context.LOG_NO_OF_INSERTS=0;
context.LOG_NO_OF_UPDATES=0;
context.LOG_NO_OF_DELETES=0;
context.LOG_NO_OF_ERRORS=0;
context.LOG_SOURCE_ROW_COUNT=0;
context.LOG_TARGET_ROW_COUNT=0;


String strInsertLogSql=(String)globalMap.get("insert_log_template");
strInsertLogSql=strInsertLogSql.replace("#RUN_ID", ((Integer)context.LOG_RUN_ID).toString());
strInsertLogSql=strInsertLogSql.replace("#PLANT_NAME", "'"+context.LOG_PLANT_NAME+"'");
strInsertLogSql=strInsertLogSql.replace("#SYSTEM_NAME", "'"+context.LOG_SYSTEM_NAME+"'");
strInsertLogSql=strInsertLogSql.replace("#JOB_NAME", "'"+((String)globalMap.get("jobname_prefix"))+context.LOG_JOB_NAME+"'");
strInsertLogSql=strInsertLogSql.replace("#TABLE_NAME", "'"+context.LOG_TABLE_NAME+"'");
strInsertLogSql=strInsertLogSql.replace("#STATUS", "'"+context.LOG_STATUS+"'");
strInsertLogSql=strInsertLogSql.replace("#DATA_PATH", "'"+context.LOG_DATA_PATH+"'");
strInsertLogSql=strInsertLogSql.replace("#TECHNOLOGY", "'"+context.LOG_TECHNOLOGY+"'");
strInsertLogSql=strInsertLogSql.replace("#NO_OF_INSERTS", ((Integer)context.LOG_NO_OF_INSERTS).toString());
strInsertLogSql=strInsertLogSql.replace("#NO_OF_UPDATES", ((Integer)context.LOG_NO_OF_UPDATES).toString());
strInsertLogSql=strInsertLogSql.replace("#NO_OF_DELETES", ((Integer)context.LOG_NO_OF_DELETES).toString());
strInsertLogSql=strInsertLogSql.replace("#NO_OF_ERRORS", ((Integer)context.LOG_NO_OF_ERRORS).toString());
strInsertLogSql=strInsertLogSql.replace("#MESSAGE", "'"+context.LOG_MESSAGE+"'");
strInsertLogSql=strInsertLogSql.replace("#SOURCE_ROW_COUNT", ((Integer)context.LOG_SOURCE_ROW_COUNT).toString());
strInsertLogSql=strInsertLogSql.replace("#TARGET_ROW_COUNT", ((Integer)context.LOG_TARGET_ROW_COUNT).toString());
strInsertLogSql=strInsertLogSql.replace("#ERROR_CATEGORY", "'"+context.LOG_ERROR_CATEGORY+"'");
globalMap.put("insert_log_sql",strInsertLogSql);
//System.out.println(globalMap.get("insert_log_sql"));
//System.out.println("==============================");
//System.out.println("==============================");
//globalMap.put("now",new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(TalendDate.getCurrentDate()).toString());
//System.out.println(globalMap.get("now"));
//globalMap.put("now_sql","TO_TIMESTAMP('" + ((String)globalMap.get("now")) + "', 'YYYY-MM-DD HH24:MI:SS')::TIMESTAMP WITH TIME ZONE ");
//System.out.println(globalMap.get("now_sql"));
//if (context.LOG_PLANT_NAME.equals("")==true) {
//  context.LOG_PLANT_NAME="Grove City";
//};
//if (context.LOG_APPLICATION.equals("")==true) {
//  context.LOG_APPLICATION="GET-ABM";
//};
 



/**
 * [tJava_6 begin ] stop
 */
	
	/**
	 * [tJava_6 main ] start
	 */

	

	
	
	currentComponent="tJava_6";

	

 


	tos_count_tJava_6++;

/**
 * [tJava_6 main ] stop
 */
	
	/**
	 * [tJava_6 end ] start
	 */

	

	
	
	currentComponent="tJava_6";

	

 

ok_Hash.put("tJava_6", true);
end_Hash.put("tJava_6", System.currentTimeMillis());




/**
 * [tJava_6 end ] stop
 */
				}//end the resume

				
				    			if(resumeEntryMethodName == null || globalResumeTicket){
				    				resumeUtil.addLog("CHECKPOINT", "CONNECTION:SUBJOB_OK:tJava_6:OnSubjobOk", "", Thread.currentThread().getId() + "", "", "", "", "", "");
								}	    				    			
					    	
								if(execStat){    	
									runStat.updateStatOnConnection("OnSubjobOk16", 0, "ok");
								} 
							
							tGreenplumRow_1Process(globalMap); 
						



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage());
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tJava_6 finally ] start
	 */

	

	
	
	currentComponent="tJava_6";

	

 



/**
 * [tJava_6 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tJava_6_SUBPROCESS_STATE", 1);
	}
	

public void tGreenplumRow_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tGreenplumRow_1_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tGreenplumRow_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tGreenplumRow_1", false);
		start_Hash.put("tGreenplumRow_1", System.currentTimeMillis());
		
	
	currentComponent="tGreenplumRow_1";

	
		int tos_count_tGreenplumRow_1 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tGreenplumRow_1 - "  + ("Start to work.") );
    	class BytesLimit65535_tGreenplumRow_1{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tGreenplumRow_1 = new StringBuilder();
            log4jParamters_tGreenplumRow_1.append("Parameters:");
                    log4jParamters_tGreenplumRow_1.append("USE_EXISTING_CONNECTION" + " = " + "true");
                log4jParamters_tGreenplumRow_1.append(" | ");
                    log4jParamters_tGreenplumRow_1.append("CONNECTION" + " = " + "tGreenplumConnection_2");
                log4jParamters_tGreenplumRow_1.append(" | ");
                    log4jParamters_tGreenplumRow_1.append("QUERYSTORE" + " = " + "\"\"");
                log4jParamters_tGreenplumRow_1.append(" | ");
                    log4jParamters_tGreenplumRow_1.append("QUERY" + " = " + "(String)globalMap.get(\"insert_log_sql\")");
                log4jParamters_tGreenplumRow_1.append(" | ");
                    log4jParamters_tGreenplumRow_1.append("DIE_ON_ERROR" + " = " + "true");
                log4jParamters_tGreenplumRow_1.append(" | ");
                    log4jParamters_tGreenplumRow_1.append("PROPAGATE_RECORD_SET" + " = " + "false");
                log4jParamters_tGreenplumRow_1.append(" | ");
                    log4jParamters_tGreenplumRow_1.append("USE_PREPAREDSTATEMENT" + " = " + "false");
                log4jParamters_tGreenplumRow_1.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tGreenplumRow_1 - "  + (log4jParamters_tGreenplumRow_1) );
    		}
    	}
    	
        new BytesLimit65535_tGreenplumRow_1().limitLog4jByte();

	java.sql.Connection conn_tGreenplumRow_1 = null;
	String query_tGreenplumRow_1 = "";
	boolean whetherReject_tGreenplumRow_1 = false;
				conn_tGreenplumRow_1 = (java.sql.Connection)globalMap.get("conn_tGreenplumConnection_2");
			
				if(conn_tGreenplumRow_1 != null) {
					if(conn_tGreenplumRow_1.getMetaData() != null) {
						
						log.debug("tGreenplumRow_1 - Uses an existing connection with username '" + conn_tGreenplumRow_1.getMetaData().getUserName() + "'. Connection URL: " + conn_tGreenplumRow_1.getMetaData().getURL() + ".");
						
					}
				}
			
		java.sql.Statement stmt_tGreenplumRow_1 = conn_tGreenplumRow_1.createStatement();
	

 



/**
 * [tGreenplumRow_1 begin ] stop
 */
	
	/**
	 * [tGreenplumRow_1 main ] start
	 */

	

	
	
	currentComponent="tGreenplumRow_1";

	

	    		log.debug("tGreenplumRow_1 - Executing the query: '" + (String)globalMap.get("insert_log_sql") + "'.");
			
query_tGreenplumRow_1 = (String)globalMap.get("insert_log_sql");
whetherReject_tGreenplumRow_1 = false;
globalMap.put("tGreenplumRow_1_QUERY",query_tGreenplumRow_1);
try {
		stmt_tGreenplumRow_1.execute(query_tGreenplumRow_1);
		
	    		log.info("tGreenplumRow_1 - Execute the query: '" + (String)globalMap.get("insert_log_sql") + "' has finished.");
			
	} catch (java.lang.Exception e) {
		whetherReject_tGreenplumRow_1 = true;
		
			throw(e);
			
	}
	
	if(!whetherReject_tGreenplumRow_1) {
		
	}
	

 


	tos_count_tGreenplumRow_1++;

/**
 * [tGreenplumRow_1 main ] stop
 */
	
	/**
	 * [tGreenplumRow_1 end ] start
	 */

	

	
	
	currentComponent="tGreenplumRow_1";

	

	
	stmt_tGreenplumRow_1.close();	

 
                if(log.isDebugEnabled())
            log.debug("tGreenplumRow_1 - "  + ("Done.") );

ok_Hash.put("tGreenplumRow_1", true);
end_Hash.put("tGreenplumRow_1", System.currentTimeMillis());




/**
 * [tGreenplumRow_1 end ] stop
 */
				}//end the resume

				
				    			if(resumeEntryMethodName == null || globalResumeTicket){
				    				resumeUtil.addLog("CHECKPOINT", "CONNECTION:SUBJOB_OK:tGreenplumRow_1:OnSubjobOk", "", Thread.currentThread().getId() + "", "", "", "", "", "");
								}	    				    			
					    	
								if(execStat){    	
									runStat.updateStatOnConnection("OnSubjobOk17", 0, "ok");
								} 
							
							tGreenplumClose_2Process(globalMap); 
						



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage());
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tGreenplumRow_1 finally ] start
	 */

	

	
	
	currentComponent="tGreenplumRow_1";

	

 



/**
 * [tGreenplumRow_1 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tGreenplumRow_1_SUBPROCESS_STATE", 1);
	}
	

public void tGreenplumClose_2Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tGreenplumClose_2_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tGreenplumClose_2 begin ] start
	 */

	

	
		
		ok_Hash.put("tGreenplumClose_2", false);
		start_Hash.put("tGreenplumClose_2", System.currentTimeMillis());
		
	
	currentComponent="tGreenplumClose_2";

	
		int tos_count_tGreenplumClose_2 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tGreenplumClose_2 - "  + ("Start to work.") );
    	class BytesLimit65535_tGreenplumClose_2{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tGreenplumClose_2 = new StringBuilder();
            log4jParamters_tGreenplumClose_2.append("Parameters:");
                    log4jParamters_tGreenplumClose_2.append("CONNECTION" + " = " + "tGreenplumConnection_2");
                log4jParamters_tGreenplumClose_2.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tGreenplumClose_2 - "  + (log4jParamters_tGreenplumClose_2) );
    		}
    	}
    	
        new BytesLimit65535_tGreenplumClose_2().limitLog4jByte();

 



/**
 * [tGreenplumClose_2 begin ] stop
 */
	
	/**
	 * [tGreenplumClose_2 main ] start
	 */

	

	
	
	currentComponent="tGreenplumClose_2";

	



	java.sql.Connection conn_tGreenplumClose_2 = (java.sql.Connection)globalMap.get("conn_tGreenplumConnection_2");
	if(conn_tGreenplumClose_2 != null && !conn_tGreenplumClose_2.isClosed())
	{
                if(log.isDebugEnabled())
            log.debug("tGreenplumClose_2 - "  + ("Closing the connection ")  + ("conn_tGreenplumConnection_2")  + (" to the database.") );
        conn_tGreenplumClose_2.close();
                if(log.isDebugEnabled())
            log.debug("tGreenplumClose_2 - "  + ("Connection ")  + ("conn_tGreenplumConnection_2")  + (" to the database has closed.") );
	}

 


	tos_count_tGreenplumClose_2++;

/**
 * [tGreenplumClose_2 main ] stop
 */
	
	/**
	 * [tGreenplumClose_2 end ] start
	 */

	

	
	
	currentComponent="tGreenplumClose_2";

	

 
                if(log.isDebugEnabled())
            log.debug("tGreenplumClose_2 - "  + ("Done.") );

ok_Hash.put("tGreenplumClose_2", true);
end_Hash.put("tGreenplumClose_2", System.currentTimeMillis());




/**
 * [tGreenplumClose_2 end ] stop
 */
				}//end the resume

				
				    			if(resumeEntryMethodName == null || globalResumeTicket){
				    				resumeUtil.addLog("CHECKPOINT", "CONNECTION:SUBJOB_OK:tGreenplumClose_2:OnSubjobOk", "", Thread.currentThread().getId() + "", "", "", "", "", "");
								}	    				    			
					    	
								if(execStat){    	
									runStat.updateStatOnConnection("OnSubjobOk18", 0, "ok");
								} 
							
							tFileInputDelimited_1Process(globalMap); 
						



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage());
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tGreenplumClose_2 finally ] start
	 */

	

	
	
	currentComponent="tGreenplumClose_2";

	

 



/**
 * [tGreenplumClose_2 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tGreenplumClose_2_SUBPROCESS_STATE", 1);
	}
	


public static class row4Struct implements routines.system.IPersistableRow<row4Struct> {
    final static byte[] commonByteArrayLock_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Base_dynamic = new byte[0];
    static byte[] commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Base_dynamic = new byte[0];

	



    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Base_dynamic) {

        	try {

        		int length = 0;
		

		

        }

		
			finally {}
		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
        }

			finally {}
		

    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(row4Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public static class row3Struct implements routines.system.IPersistableRow<row3Struct> {
    final static byte[] commonByteArrayLock_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Base_dynamic = new byte[0];
    static byte[] commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Base_dynamic = new byte[0];

	
			    public String log_table_name;

				public String getLog_table_name () {
					return this.log_table_name;
				}
				
			    public String technology;

				public String getTechnology () {
					return this.technology;
				}
				



	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Base_dynamic.length) {
				if(length < 1024 && commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Base_dynamic.length == 0) {
   					commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Base_dynamic = new byte[1024];
				} else {
   					commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Base_dynamic = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Base_dynamic, 0, length);
			strReturn = new String(commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Base_dynamic, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Base_dynamic) {

        	try {

        		int length = 0;
		
					this.log_table_name = readString(dis);
					
					this.technology = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// String
				
						writeString(this.log_table_name,dos);
					
					// String
				
						writeString(this.technology,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("log_table_name="+log_table_name);
		sb.append(",technology="+technology);
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				if(log_table_name == null){
        					sb.append("<null>");
        				}else{
            				sb.append(log_table_name);
            			}
            		
        			sb.append("|");
        		
        				if(technology == null){
        					sb.append("<null>");
        				}else{
            				sb.append(technology);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(row3Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}
public void tFileInputDelimited_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tFileInputDelimited_1_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;



		row3Struct row3 = new row3Struct();
row4Struct row4 = new row4Struct();





	
	/**
	 * [tFlowToIterate_1 begin ] start
	 */

	
				TalendThreadPool mtp_tRunJob_2 = new TalendThreadPool(context.THREAD);

				globalMap.put("lockWrite_tRunJob_2", new Object[0]);
				int threadIdCounter_tRunJob_2 =0;
						
			int NB_ITERATE_tRunJob_2 = 0; //for statistics
			

	
		
		ok_Hash.put("tFlowToIterate_1", false);
		start_Hash.put("tFlowToIterate_1", System.currentTimeMillis());
		
	
	currentComponent="tFlowToIterate_1";

	
			if (execStat) {
				if(resourceMap.get("inIterateVComp") == null){
					
						runStat.updateStatOnConnection("row4" + iterateId, 0, 0);
					
				}
			} 

		
		int tos_count_tFlowToIterate_1 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tFlowToIterate_1 - "  + ("Start to work.") );
    	class BytesLimit65535_tFlowToIterate_1{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tFlowToIterate_1 = new StringBuilder();
            log4jParamters_tFlowToIterate_1.append("Parameters:");
                    log4jParamters_tFlowToIterate_1.append("DEFAULT_MAP" + " = " + "true");
                log4jParamters_tFlowToIterate_1.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tFlowToIterate_1 - "  + (log4jParamters_tFlowToIterate_1) );
    		}
    	}
    	
        new BytesLimit65535_tFlowToIterate_1().limitLog4jByte();

int nb_line_tFlowToIterate_1 = 0;
int counter_tFlowToIterate_1 = 0;

 



/**
 * [tFlowToIterate_1 begin ] stop
 */



	
	/**
	 * [tJavaRow_2 begin ] start
	 */

	

	
		
		ok_Hash.put("tJavaRow_2", false);
		start_Hash.put("tJavaRow_2", System.currentTimeMillis());
		
	
	currentComponent="tJavaRow_2";

	
			if (execStat) {
				if(resourceMap.get("inIterateVComp") == null){
					
						runStat.updateStatOnConnection("row3" + iterateId, 0, 0);
					
				}
			} 

		
		int tos_count_tJavaRow_2 = 0;
		
    	class BytesLimit65535_tJavaRow_2{
    		public void limitLog4jByte() throws Exception{
    			
    		}
    	}
    	
        new BytesLimit65535_tJavaRow_2().limitLog4jByte();

int nb_line_tJavaRow_2 = 0;

 



/**
 * [tJavaRow_2 begin ] stop
 */



	
	/**
	 * [tFileInputDelimited_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tFileInputDelimited_1", false);
		start_Hash.put("tFileInputDelimited_1", System.currentTimeMillis());
		
	
	currentComponent="tFileInputDelimited_1";

	
		int tos_count_tFileInputDelimited_1 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tFileInputDelimited_1 - "  + ("Start to work.") );
    	class BytesLimit65535_tFileInputDelimited_1{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tFileInputDelimited_1 = new StringBuilder();
            log4jParamters_tFileInputDelimited_1.append("Parameters:");
                    log4jParamters_tFileInputDelimited_1.append("FILENAME" + " = " + "context.ETL_STORAGE_PATH + \"/\" +context.GP_SOURCE_NAME + \"/\" +((String)globalMap.get(\"timestamp\"))+\".csv\"");
                log4jParamters_tFileInputDelimited_1.append(" | ");
                    log4jParamters_tFileInputDelimited_1.append("CSV_OPTION" + " = " + "false");
                log4jParamters_tFileInputDelimited_1.append(" | ");
                    log4jParamters_tFileInputDelimited_1.append("ROWSEPARATOR" + " = " + "\"\\n\"");
                log4jParamters_tFileInputDelimited_1.append(" | ");
                    log4jParamters_tFileInputDelimited_1.append("FIELDSEPARATOR" + " = " + "\";\"");
                log4jParamters_tFileInputDelimited_1.append(" | ");
                    log4jParamters_tFileInputDelimited_1.append("HEADER" + " = " + "0");
                log4jParamters_tFileInputDelimited_1.append(" | ");
                    log4jParamters_tFileInputDelimited_1.append("FOOTER" + " = " + "0");
                log4jParamters_tFileInputDelimited_1.append(" | ");
                    log4jParamters_tFileInputDelimited_1.append("LIMIT" + " = " + "");
                log4jParamters_tFileInputDelimited_1.append(" | ");
                    log4jParamters_tFileInputDelimited_1.append("REMOVE_EMPTY_ROW" + " = " + "true");
                log4jParamters_tFileInputDelimited_1.append(" | ");
                    log4jParamters_tFileInputDelimited_1.append("UNCOMPRESS" + " = " + "false");
                log4jParamters_tFileInputDelimited_1.append(" | ");
                    log4jParamters_tFileInputDelimited_1.append("DIE_ON_ERROR" + " = " + "false");
                log4jParamters_tFileInputDelimited_1.append(" | ");
                    log4jParamters_tFileInputDelimited_1.append("ADVANCED_SEPARATOR" + " = " + "false");
                log4jParamters_tFileInputDelimited_1.append(" | ");
                    log4jParamters_tFileInputDelimited_1.append("RANDOM" + " = " + "false");
                log4jParamters_tFileInputDelimited_1.append(" | ");
                    log4jParamters_tFileInputDelimited_1.append("TRIMALL" + " = " + "false");
                log4jParamters_tFileInputDelimited_1.append(" | ");
                    log4jParamters_tFileInputDelimited_1.append("TRIMSELECT" + " = " + "[{TRIM="+("false")+", SCHEMA_COLUMN="+("log_table_name")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("technology")+"}]");
                log4jParamters_tFileInputDelimited_1.append(" | ");
                    log4jParamters_tFileInputDelimited_1.append("CHECK_FIELDS_NUM" + " = " + "false");
                log4jParamters_tFileInputDelimited_1.append(" | ");
                    log4jParamters_tFileInputDelimited_1.append("CHECK_DATE" + " = " + "false");
                log4jParamters_tFileInputDelimited_1.append(" | ");
                    log4jParamters_tFileInputDelimited_1.append("ENCODING" + " = " + "\"ISO-8859-15\"");
                log4jParamters_tFileInputDelimited_1.append(" | ");
                    log4jParamters_tFileInputDelimited_1.append("SPLITRECORD" + " = " + "false");
                log4jParamters_tFileInputDelimited_1.append(" | ");
                    log4jParamters_tFileInputDelimited_1.append("ENABLE_DECODE" + " = " + "false");
                log4jParamters_tFileInputDelimited_1.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tFileInputDelimited_1 - "  + (log4jParamters_tFileInputDelimited_1) );
    		}
    	}
    	
        new BytesLimit65535_tFileInputDelimited_1().limitLog4jByte();
	
	
	
 
	
	
	final routines.system.RowState rowstate_tFileInputDelimited_1 = new routines.system.RowState();
	
	
				int nb_line_tFileInputDelimited_1 = 0;
				org.talend.fileprocess.FileInputDelimited fid_tFileInputDelimited_1 = null;
				try{
					
						Object filename_tFileInputDelimited_1 = context.ETL_STORAGE_PATH + "/" +context.GP_SOURCE_NAME + "/" +((String)globalMap.get("timestamp"))+".csv";
						if(filename_tFileInputDelimited_1 instanceof java.io.InputStream){
							
			int footer_value_tFileInputDelimited_1 = 0, random_value_tFileInputDelimited_1 = -1;
			if(footer_value_tFileInputDelimited_1 >0 || random_value_tFileInputDelimited_1 > 0){
				throw new java.lang.Exception("When the input source is a stream,footer and random shouldn't be bigger than 0.");				
			}
		
						}
						try {
							fid_tFileInputDelimited_1 = new org.talend.fileprocess.FileInputDelimited(context.ETL_STORAGE_PATH + "/" +context.GP_SOURCE_NAME + "/" +((String)globalMap.get("timestamp"))+".csv", "ISO-8859-15",";","\n",true,0,0,-1,-1, false);
						} catch(java.lang.Exception e) {
							
								
									log.error("tFileInputDelimited_1 - " +e.getMessage());
								
								System.err.println(e.getMessage());
							
						}
					
				    
				    	log.info("tFileInputDelimited_1 - Retrieving records from the datasource.");
				    
					while (fid_tFileInputDelimited_1!=null && fid_tFileInputDelimited_1.nextRecord()) {
						rowstate_tFileInputDelimited_1.reset();
						
			    						row3 = null;			
												
									boolean whetherReject_tFileInputDelimited_1 = false;
									row3 = new row3Struct();
									try {
										
				int columnIndexWithD_tFileInputDelimited_1 = 0;
				
					columnIndexWithD_tFileInputDelimited_1 = 0;
					
							row3.log_table_name = fid_tFileInputDelimited_1.get(columnIndexWithD_tFileInputDelimited_1);
						
				
					columnIndexWithD_tFileInputDelimited_1 = 1;
					
							row3.technology = fid_tFileInputDelimited_1.get(columnIndexWithD_tFileInputDelimited_1);
						
				
				
										
										if(rowstate_tFileInputDelimited_1.getException()!=null) {
											throw rowstate_tFileInputDelimited_1.getException();
										}
										
										
							
			    					} catch (java.lang.Exception e) {
			        					whetherReject_tFileInputDelimited_1 = true;
			        					
												log.error("tFileInputDelimited_1 - " +e.getMessage());
											
			                					System.err.println(e.getMessage());
			                					row3 = null;
			                				
			    					}
								
			log.debug("tFileInputDelimited_1 - Retrieving the record " + fid_tFileInputDelimited_1.getRowNumber() + ".");
		

 



/**
 * [tFileInputDelimited_1 begin ] stop
 */
	
	/**
	 * [tFileInputDelimited_1 main ] start
	 */

	

	
	
	currentComponent="tFileInputDelimited_1";

	

 


	tos_count_tFileInputDelimited_1++;

/**
 * [tFileInputDelimited_1 main ] stop
 */
// Start of branch "row3"
if(row3 != null) { 



	
	/**
	 * [tJavaRow_2 main ] start
	 */

	

	
	
	currentComponent="tJavaRow_2";

	

			//row3
			//row3


			
				if(execStat){
					runStat.updateStatOnConnection("row3"+iterateId,1, 1);
				} 
			

		
    			if(log.isTraceEnabled()){
    				log.trace("row3 - " + (row3==null? "": row3.toLogString()));
    			}
    		

    context.TABLE_NAME=row3.log_table_name;
context.LOG_TECHNOLOGY=row3.technology;

//System.out.println(row3.log_table_name);
//System.out.println(row3.technology);

    nb_line_tJavaRow_2++;   

 


	tos_count_tJavaRow_2++;

/**
 * [tJavaRow_2 main ] stop
 */

	
	/**
	 * [tFlowToIterate_1 main ] start
	 */

	

	
	
	currentComponent="tFlowToIterate_1";

	

			//row4
			//row4


			
				if(execStat){
					runStat.updateStatOnConnection("row4"+iterateId,1, 1);
				} 
			

		
    			if(log.isTraceEnabled()){
    				log.trace("row4 - " + (row4==null? "": row4.toLogString()));
    			}
    		


    	
 
	   nb_line_tFlowToIterate_1++;  
       counter_tFlowToIterate_1++;
                if(log.isDebugEnabled())
            log.debug("tFlowToIterate_1 - "  + ("Current iteration is: ")  + (counter_tFlowToIterate_1)  + (".") );
       globalMap.put("tFlowToIterate_1_CURRENT_ITERATION", counter_tFlowToIterate_1);
 


	tos_count_tFlowToIterate_1++;

/**
 * [tFlowToIterate_1 main ] stop
 */
	NB_ITERATE_tRunJob_2++;
	
				
			class tRunJob_2Thread extends TalendThread {//implements routines.system.TalendThreadPool.PropertySettable
				class ThreadedMap extends java.util.HashMap<String, Object> {
			
					private static final long serialVersionUID = 0L;
		
					public ThreadedMap(java.util.Map<String, Object> globalMap) {
						super(globalMap);
					}
		
					@Override
					public Object put(String key, Object value) {
						
							super.put(key, value);
							return EDL_Base_dynamic.this.globalMap.put(key, value);
						
					}
				}	
				
					private final ContextProperties localContext = new ContextProperties();
				
				private java.util.Map<String, Object> globalMap = null;
				boolean isRunning = false;
				String iterateId = "";
				
				
						row3Struct row3 = new row3Struct();
row4Struct row4 = new row4Struct();

					
	
				public tRunJob_2Thread(java.util.Map<String, Object> globalMap,row3Struct row3,row4Struct row4, int threadID) {
					super();
					
		        		if(row3 != null){
		            		
		    					this.row3.log_table_name = row3.log_table_name;
		    	            
		    					this.row3.technology = row3.technology;
		    	            
		        		}
		        		
		        		if(row4 != null){
		            		
		        		}
		        		
					
						synchronized (globalMap) {
							this.globalMap = java.util.Collections.synchronizedMap(new ThreadedMap(globalMap));
					
						}
					iterateId = "." + threadID;
					
					
						//bug21906 copy context to local for mutilthread
						context.synchronizeContext();
						java.util.Enumeration<?> propertyNames = context.propertyNames();
						while(propertyNames.hasMoreElements()) {
							String propertyName = (String)propertyNames.nextElement();
							String propertyValue = context.getProperty(propertyName);
							localContext.setProperty(propertyName, propertyValue);
						}
						
							localContext.GP_SOURCE_NAME = context.GP_SOURCE_NAME;
						
							localContext.TABLE_NAME = context.TABLE_NAME;
						
							localContext.FORCE_DROP = context.FORCE_DROP;
						
							localContext.FORCE_BATCH = context.FORCE_BATCH;
						
							localContext.LOAD2HDFS = context.LOAD2HDFS;
						
							localContext.SOURCE_HOST = context.SOURCE_HOST;
						
							localContext.SOURCE_DATABASE = context.SOURCE_DATABASE;
						
							localContext.SOURCE_USER = context.SOURCE_USER;
						
							localContext.SOURCE_PORT = context.SOURCE_PORT;
						
							localContext.SOURCE_PASSWORD = context.SOURCE_PASSWORD;
						
							localContext.TOP_N_ROWS = context.TOP_N_ROWS;
						
							localContext.THREAD = context.THREAD;
						
							localContext.RUN_ID = context.RUN_ID;
						
							localContext.PROD2DEV = context.PROD2DEV;
						
							localContext.SEND_MAIL = context.SEND_MAIL;
						
							localContext.PUBLIC = context.PUBLIC;
						
							localContext.PYTHON_NEEDED = context.PYTHON_NEEDED;
						
							localContext.mail_to_error = context.mail_to_error;
						
							localContext.JOB_LABEL_NAME = context.JOB_LABEL_NAME;
						
							localContext.PLANT_NAME = context.PLANT_NAME;
						
							localContext.LOG_NO_OF_ERRORS = context.LOG_NO_OF_ERRORS;
						
							localContext.LOG_PLANT_NAME = context.LOG_PLANT_NAME;
						
							localContext.LOG_NO_OF_UPDATES = context.LOG_NO_OF_UPDATES;
						
							localContext.LOG_SOURCE_ROW_COUNT = context.LOG_SOURCE_ROW_COUNT;
						
							localContext.LOG_TECHNOLOGY = context.LOG_TECHNOLOGY;
						
							localContext.LOG_TABLE_NAME = context.LOG_TABLE_NAME;
						
							localContext.LOG_NO_OF_INSERTS = context.LOG_NO_OF_INSERTS;
						
							localContext.LOG_DATA_PATH = context.LOG_DATA_PATH;
						
							localContext.LOG_NO_OF_DELETES = context.LOG_NO_OF_DELETES;
						
							localContext.LOG_RUN_ID = context.LOG_RUN_ID;
						
							localContext.LOG_ERROR_CATEGORY = context.LOG_ERROR_CATEGORY;
						
							localContext.LOG_JOB_NAME = context.LOG_JOB_NAME;
						
							localContext.LOG_SYSTEM_NAME = context.LOG_SYSTEM_NAME;
						
							localContext.LOG_MESSAGE = context.LOG_MESSAGE;
						
							localContext.LOG_TARGET_ROW_COUNT = context.LOG_TARGET_ROW_COUNT;
						
							localContext.LOG_STATUS = context.LOG_STATUS;
						
							localContext.PRIVATE_KEY = context.PRIVATE_KEY;
						
							localContext.CURSOR_SIZE = context.CURSOR_SIZE;
						
							localContext.PROD2DEV_THREADS = context.PROD2DEV_THREADS;
						
							localContext.MAIL_TO = context.MAIL_TO;
						
							localContext.IGNORE_TIMEZONE = context.IGNORE_TIMEZONE;
						
							localContext.RECREATE_SCHEMA = context.RECREATE_SCHEMA;
						
							localContext.DB_VERSION = context.DB_VERSION;
						
							localContext.IS_MULTITHREAD_BY_TABLE = context.IS_MULTITHREAD_BY_TABLE;
						
							localContext.OSPASSWORD = context.OSPASSWORD;
						
							localContext.OSUSER = context.OSUSER;
						
							localContext.PYTHON_HOST = context.PYTHON_HOST;
						
							localContext.PYTHON_PATH = context.PYTHON_PATH;
						
							localContext.ETL_LOCALHOSTNAME = context.ETL_LOCALHOSTNAME;
						
							localContext.ETL_STORAGE_PATH = context.ETL_STORAGE_PATH;
						
							localContext.HAWQ_Source_Ports = context.HAWQ_Source_Ports;
						
							localContext.SOURCING_Database = context.SOURCING_Database;
						
							localContext.SOURCING_Login = context.SOURCING_Login;
						
							localContext.SOURCING_Password = context.SOURCING_Password;
						
							localContext.SOURCING_Port = context.SOURCING_Port;
						
							localContext.SOURCING_Schema = context.SOURCING_Schema;
						
							localContext.SOURCING_Server = context.SOURCING_Server;
						
				}


				public void run() {		
		
					java.util.Map threadRunResultMap = new java.util.HashMap();
					threadRunResultMap.put("errorCode", null);
					threadRunResultMap.put("status", "");
					threadLocal.set(threadRunResultMap);
					
					this.isRunning = true;
					String currentComponent = "";
					java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();
					
					try {			
						
							if(execStat){
								runStat.updateStatOnConnection("iterate1",0,"exec"+iterateId);
							}				
						

	
	/**
	 * [tRunJob_2 begin ] start
	 */

	

	
		
		ok_Hash.put("tRunJob_2", false);
		start_Hash.put("tRunJob_2", System.currentTimeMillis());
		
	
	currentComponent="tRunJob_2";

	
		int tos_count_tRunJob_2 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tRunJob_2 - "  + ("Start to work.") );
    	class BytesLimit65535_tRunJob_2{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tRunJob_2 = new StringBuilder();
            log4jParamters_tRunJob_2.append("Parameters:");
                    log4jParamters_tRunJob_2.append("USE_DYNAMIC_JOB" + " = " + "true");
                log4jParamters_tRunJob_2.append(" | ");
                    log4jParamters_tRunJob_2.append("CONTEXT_JOB" + " = " + "((String)globalMap.get(\"job_name\"))");
                log4jParamters_tRunJob_2.append(" | ");
                    log4jParamters_tRunJob_2.append("PROCESS" + " = " + "AS400_to_greenplum_with_GPLoad;EDL_Greenplum_to_FlatFile;EDL_Greenplum_to_greenplum_with_GPLoad;EDL_MSSql_to_greenplum_with_GPLoad;EDL_Mysql_to_greenplum_with_GPLoad;EDL_Oracle_to_greenplum_with_GPLoad;EDL_Teradata_to_greenplum_with_GPLoad");
                log4jParamters_tRunJob_2.append(" | ");
                    log4jParamters_tRunJob_2.append("CONTEXT_NAME" + " = " + "DEV");
                log4jParamters_tRunJob_2.append(" | ");
                    log4jParamters_tRunJob_2.append("DIE_ON_CHILD_ERROR" + " = " + "false");
                log4jParamters_tRunJob_2.append(" | ");
                    log4jParamters_tRunJob_2.append("TRANSMIT_WHOLE_CONTEXT" + " = " + "true");
                log4jParamters_tRunJob_2.append(" | ");
                    log4jParamters_tRunJob_2.append("CONTEXTPARAMS" + " = " + "[]");
                log4jParamters_tRunJob_2.append(" | ");
                    log4jParamters_tRunJob_2.append("PRINT_PARAMETER" + " = " + "false");
                log4jParamters_tRunJob_2.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tRunJob_2 - "  + (log4jParamters_tRunJob_2) );
    		}
    	}
    	
        new BytesLimit65535_tRunJob_2().limitLog4jByte();
class DealChildJobLibrary_tRunJob_2 {

	public String replaceJarPathsFromCrcMap(String originalClassPathLine) throws java.lang.Exception {
		String classPathLine = "";
		String crcMapPath = new java.io.File("../crcMap").getCanonicalPath();
		if (isNeedAddLibsPath( crcMapPath)) {
			java.util.Map<String, String> crcMap = null;
			java.io.ObjectInputStream ois = new ObjectInputStream(new java.io.FileInputStream(crcMapPath));
			crcMap = (java.util.Map<String, String>) ois.readObject();
			ois.close();
			classPathLine = addLibsPath(originalClassPathLine, crcMap);
		} else {
			classPathLine = originalClassPathLine;
		}
		return classPathLine;
	}
	
	private boolean isNeedAddLibsPath(String crcMapPath) {
		if (!(new java.io.File(crcMapPath).exists())) {// when not use cache
			return false;
		}
		return true;
	}
	
	
	private String addLibsPath(String line, java.util.Map<String, String> crcMap) {
		for (java.util.Map.Entry<String, String> entry : crcMap.entrySet()) {
			line = adaptLibPaths(line, entry);
		}
		return line;
	}
	
	private String adaptLibPaths(String line, java.util.Map.Entry<String, String> entry) {
		String jarName = entry.getValue();
		String crc = entry.getKey();
		String libStringFinder = "../lib/" + jarName;
		if (line.contains(libStringFinder)) {
			line = line.replace(libStringFinder, "../../../cache/lib/" + crc + "/" + jarName);
		} else if (line.contains(":$ROOT_PATH/" + jarName + ":")) {
			line = line.replace(":$ROOT_PATH/" + jarName + ":", ":$ROOT_PATH/../../../cache/lib/" + crc + "/" + jarName + ":");
		} else if (line.contains(";" + jarName + ";")) {
			line = line.replace(";" + jarName + ";", ";../../../cache/lib/" + crc + "/" + jarName + ";");
		}
		return line;
	}
	
}
	DealChildJobLibrary_tRunJob_2 dealChildJobLibrary_tRunJob_2 = new DealChildJobLibrary_tRunJob_2();

		//For different jobs, job name must be different, but classpath and JVM arguments are possbilely different
		java.util.Map<String,List<String>> childJob_commandLine_Mapper_tRunJob_2 = new java.util.HashMap<String,List<String>>();
		java.util.List<String> childJob_commandLine_tRunJob_2 = null;
		String classpathSeparator_tRunJob_2 = System.getProperty("path.separator");
		
				childJob_commandLine_tRunJob_2 = new java.util.ArrayList<String>();
				
				    childJob_commandLine_tRunJob_2.add("java");
				    
				    		childJob_commandLine_tRunJob_2.add("-Xms256M".replaceAll(";",classpathSeparator_tRunJob_2));
				    
				    		childJob_commandLine_tRunJob_2.add("-Xmx1024M".replaceAll(";",classpathSeparator_tRunJob_2));
				    
				    		childJob_commandLine_tRunJob_2.add("-cp".replaceAll(";",classpathSeparator_tRunJob_2));
				    
				    		childJob_commandLine_tRunJob_2.add(dealChildJobLibrary_tRunJob_2.replaceJarPathsFromCrcMap(".;../lib/routines.jar;../lib/log4j-1.2.16.jar;../lib/org.talend.dataquality.parser.jar;../lib/dom4j-1.6.1.jar;../lib/namedpipe-1.0.jar;../lib/talendcsv.jar;../lib/postgresql-8.3-603.jdbc3.jar;../lib/jt400_V5R2.jar;../lib/talend_file_enhanced_20070724.jar;../lib/antlr-runtime-3.5.2.jar;as400_to_greenplum_with_gpload_0_1.jar;").replaceAll(";",classpathSeparator_tRunJob_2));
				    
				    		childJob_commandLine_tRunJob_2.add("aws_dev_talend_ingestion_framework.as400_to_greenplum_with_gpload_0_1.AS400_to_greenplum_with_GPLoad".replaceAll(";",classpathSeparator_tRunJob_2));
				    
				    		childJob_commandLine_tRunJob_2.add("--father_pid="+pid.replaceAll(";",classpathSeparator_tRunJob_2));
				    
				    		childJob_commandLine_tRunJob_2.add("--root_pid="+rootPid.replaceAll(";",classpathSeparator_tRunJob_2));
				    
				    		childJob_commandLine_tRunJob_2.add("--father_node=tRunJob_2".replaceAll(";",classpathSeparator_tRunJob_2));
				    
				    		childJob_commandLine_tRunJob_2.add("--log4jLevel="+ log4jLevel.replaceAll(";",classpathSeparator_tRunJob_2));
				    
				    		childJob_commandLine_tRunJob_2.add("--context=SOURCING_DEV".replaceAll(";",classpathSeparator_tRunJob_2));
				    
				    		childJob_commandLine_tRunJob_2.add("%*".replaceAll(";",classpathSeparator_tRunJob_2));
				    
				childJob_commandLine_Mapper_tRunJob_2.put("AS400_to_greenplum_with_GPLoad",childJob_commandLine_tRunJob_2);	
			
				childJob_commandLine_tRunJob_2 = new java.util.ArrayList<String>();
				
				    childJob_commandLine_tRunJob_2.add("java");
				    
				    		childJob_commandLine_tRunJob_2.add("-Xmx4096M".replaceAll(";",classpathSeparator_tRunJob_2));
				    
				    		childJob_commandLine_tRunJob_2.add("-cp".replaceAll(";",classpathSeparator_tRunJob_2));
				    
				    		childJob_commandLine_tRunJob_2.add(dealChildJobLibrary_tRunJob_2.replaceJarPathsFromCrcMap(".;../lib/routines.jar;../lib/log4j-1.2.16.jar;../lib/org.talend.dataquality.parser.jar;../lib/dom4j-1.6.1.jar;../lib/talendcsv.jar;../lib/postgresql-8.3-603.jdbc3.jar;../lib/talend_file_enhanced_20070724.jar;../lib/antlr-runtime-3.5.2.jar;edl_greenplum_to_flatfile_0_1.jar;").replaceAll(";",classpathSeparator_tRunJob_2));
				    
				    		childJob_commandLine_tRunJob_2.add("aws_dev_talend_ingestion_framework.edl_greenplum_to_flatfile_0_1.EDL_Greenplum_to_FlatFile".replaceAll(";",classpathSeparator_tRunJob_2));
				    
				    		childJob_commandLine_tRunJob_2.add("--father_pid="+pid.replaceAll(";",classpathSeparator_tRunJob_2));
				    
				    		childJob_commandLine_tRunJob_2.add("--root_pid="+rootPid.replaceAll(";",classpathSeparator_tRunJob_2));
				    
				    		childJob_commandLine_tRunJob_2.add("--father_node=tRunJob_2".replaceAll(";",classpathSeparator_tRunJob_2));
				    
				    		childJob_commandLine_tRunJob_2.add("--log4jLevel="+ log4jLevel.replaceAll(";",classpathSeparator_tRunJob_2));
				    
				    		childJob_commandLine_tRunJob_2.add("--context=SOURCING_DEV".replaceAll(";",classpathSeparator_tRunJob_2));
				    
				    		childJob_commandLine_tRunJob_2.add("%*".replaceAll(";",classpathSeparator_tRunJob_2));
				    
				childJob_commandLine_Mapper_tRunJob_2.put("EDL_Greenplum_to_FlatFile",childJob_commandLine_tRunJob_2);	
			
				childJob_commandLine_tRunJob_2 = new java.util.ArrayList<String>();
				
				    childJob_commandLine_tRunJob_2.add("java");
				    
				    		childJob_commandLine_tRunJob_2.add("-Xms256M".replaceAll(";",classpathSeparator_tRunJob_2));
				    
				    		childJob_commandLine_tRunJob_2.add("-Xmx4096M".replaceAll(";",classpathSeparator_tRunJob_2));
				    
				    		childJob_commandLine_tRunJob_2.add("-cp".replaceAll(";",classpathSeparator_tRunJob_2));
				    
				    		childJob_commandLine_tRunJob_2.add(dealChildJobLibrary_tRunJob_2.replaceJarPathsFromCrcMap(".;../lib/routines.jar;../lib/log4j-1.2.16.jar;../lib/org.talend.dataquality.parser.jar;../lib/dom4j-1.6.1.jar;../lib/namedpipe-1.0.jar;../lib/talendcsv.jar;../lib/postgresql-8.3-603.jdbc3.jar;../lib/talend_file_enhanced_20070724.jar;../lib/antlr-runtime-3.5.2.jar;edl_greenplum_to_greenplum_with_gpload_0_1.jar;").replaceAll(";",classpathSeparator_tRunJob_2));
				    
				    		childJob_commandLine_tRunJob_2.add("aws_dev_talend_ingestion_framework.edl_greenplum_to_greenplum_with_gpload_0_1.EDL_Greenplum_to_greenplum_with_GPLoad".replaceAll(";",classpathSeparator_tRunJob_2));
				    
				    		childJob_commandLine_tRunJob_2.add("--father_pid="+pid.replaceAll(";",classpathSeparator_tRunJob_2));
				    
				    		childJob_commandLine_tRunJob_2.add("--root_pid="+rootPid.replaceAll(";",classpathSeparator_tRunJob_2));
				    
				    		childJob_commandLine_tRunJob_2.add("--father_node=tRunJob_2".replaceAll(";",classpathSeparator_tRunJob_2));
				    
				    		childJob_commandLine_tRunJob_2.add("--log4jLevel="+ log4jLevel.replaceAll(";",classpathSeparator_tRunJob_2));
				    
				    		childJob_commandLine_tRunJob_2.add("--context=SOURCING_DEV".replaceAll(";",classpathSeparator_tRunJob_2));
				    
				    		childJob_commandLine_tRunJob_2.add("%*".replaceAll(";",classpathSeparator_tRunJob_2));
				    
				childJob_commandLine_Mapper_tRunJob_2.put("EDL_Greenplum_to_greenplum_with_GPLoad",childJob_commandLine_tRunJob_2);	
			
				childJob_commandLine_tRunJob_2 = new java.util.ArrayList<String>();
				
				    childJob_commandLine_tRunJob_2.add("java");
				    
				    		childJob_commandLine_tRunJob_2.add("-Xms256M".replaceAll(";",classpathSeparator_tRunJob_2));
				    
				    		childJob_commandLine_tRunJob_2.add("-Xmx1024M".replaceAll(";",classpathSeparator_tRunJob_2));
				    
				    		childJob_commandLine_tRunJob_2.add("-cp".replaceAll(";",classpathSeparator_tRunJob_2));
				    
				    		childJob_commandLine_tRunJob_2.add(dealChildJobLibrary_tRunJob_2.replaceJarPathsFromCrcMap(".;../lib/routines.jar;../lib/log4j-1.2.16.jar;../lib/org.talend.dataquality.parser.jar;../lib/dom4j-1.6.1.jar;../lib/namedpipe-1.0.jar;../lib/talendcsv.jar;../lib/postgresql-8.3-603.jdbc3.jar;../lib/jtds-1.3.1-patch.jar;../lib/talend_file_enhanced_20070724.jar;../lib/talend_DB_mssqlUtil.jar;../lib/antlr-runtime-3.5.2.jar;edl_mssql_to_greenplum_with_gpload_0_1.jar;").replaceAll(";",classpathSeparator_tRunJob_2));
				    
				    		childJob_commandLine_tRunJob_2.add("aws_dev_talend_ingestion_framework.edl_mssql_to_greenplum_with_gpload_0_1.EDL_MSSql_to_greenplum_with_GPLoad".replaceAll(";",classpathSeparator_tRunJob_2));
				    
				    		childJob_commandLine_tRunJob_2.add("--father_pid="+pid.replaceAll(";",classpathSeparator_tRunJob_2));
				    
				    		childJob_commandLine_tRunJob_2.add("--root_pid="+rootPid.replaceAll(";",classpathSeparator_tRunJob_2));
				    
				    		childJob_commandLine_tRunJob_2.add("--father_node=tRunJob_2".replaceAll(";",classpathSeparator_tRunJob_2));
				    
				    		childJob_commandLine_tRunJob_2.add("--log4jLevel="+ log4jLevel.replaceAll(";",classpathSeparator_tRunJob_2));
				    
				    		childJob_commandLine_tRunJob_2.add("--context=SOURCING_DEV".replaceAll(";",classpathSeparator_tRunJob_2));
				    
				    		childJob_commandLine_tRunJob_2.add("%*".replaceAll(";",classpathSeparator_tRunJob_2));
				    
				childJob_commandLine_Mapper_tRunJob_2.put("EDL_MSSql_to_greenplum_with_GPLoad",childJob_commandLine_tRunJob_2);	
			
				childJob_commandLine_tRunJob_2 = new java.util.ArrayList<String>();
				
				    childJob_commandLine_tRunJob_2.add("java");
				    
				    		childJob_commandLine_tRunJob_2.add("-Xms256M".replaceAll(";",classpathSeparator_tRunJob_2));
				    
				    		childJob_commandLine_tRunJob_2.add("-Xmx4096M".replaceAll(";",classpathSeparator_tRunJob_2));
				    
				    		childJob_commandLine_tRunJob_2.add("-cp".replaceAll(";",classpathSeparator_tRunJob_2));
				    
				    		childJob_commandLine_tRunJob_2.add(dealChildJobLibrary_tRunJob_2.replaceJarPathsFromCrcMap(".;../lib/routines.jar;../lib/log4j-1.2.16.jar;../lib/org.talend.dataquality.parser.jar;../lib/dom4j-1.6.1.jar;../lib/namedpipe-1.0.jar;../lib/talendcsv.jar;../lib/postgresql-8.3-603.jdbc3.jar;../lib/mysql-connector-java-5.1.30-bin.jar;../lib/talend_file_enhanced_20070724.jar;../lib/antlr-runtime-3.5.2.jar;edl_mysql_to_greenplum_with_gpload_0_1.jar;").replaceAll(";",classpathSeparator_tRunJob_2));
				    
				    		childJob_commandLine_tRunJob_2.add("aws_dev_talend_ingestion_framework.edl_mysql_to_greenplum_with_gpload_0_1.EDL_Mysql_to_greenplum_with_GPLoad".replaceAll(";",classpathSeparator_tRunJob_2));
				    
				    		childJob_commandLine_tRunJob_2.add("--father_pid="+pid.replaceAll(";",classpathSeparator_tRunJob_2));
				    
				    		childJob_commandLine_tRunJob_2.add("--root_pid="+rootPid.replaceAll(";",classpathSeparator_tRunJob_2));
				    
				    		childJob_commandLine_tRunJob_2.add("--father_node=tRunJob_2".replaceAll(";",classpathSeparator_tRunJob_2));
				    
				    		childJob_commandLine_tRunJob_2.add("--log4jLevel="+ log4jLevel.replaceAll(";",classpathSeparator_tRunJob_2));
				    
				    		childJob_commandLine_tRunJob_2.add("--context=SOURCING_DEV".replaceAll(";",classpathSeparator_tRunJob_2));
				    
				    		childJob_commandLine_tRunJob_2.add("%*".replaceAll(";",classpathSeparator_tRunJob_2));
				    
				childJob_commandLine_Mapper_tRunJob_2.put("EDL_Mysql_to_greenplum_with_GPLoad",childJob_commandLine_tRunJob_2);	
			
				childJob_commandLine_tRunJob_2 = new java.util.ArrayList<String>();
				
				    childJob_commandLine_tRunJob_2.add("java");
				    
				    		childJob_commandLine_tRunJob_2.add("-Xms256M".replaceAll(";",classpathSeparator_tRunJob_2));
				    
				    		childJob_commandLine_tRunJob_2.add("-Xmx4096M".replaceAll(";",classpathSeparator_tRunJob_2));
				    
				    		childJob_commandLine_tRunJob_2.add("-cp".replaceAll(";",classpathSeparator_tRunJob_2));
				    
				    		childJob_commandLine_tRunJob_2.add(dealChildJobLibrary_tRunJob_2.replaceJarPathsFromCrcMap(".;../lib/routines.jar;../lib/log4j-1.2.16.jar;../lib/ojdbc6.jar;../lib/org.talend.dataquality.parser.jar;../lib/dom4j-1.6.1.jar;../lib/namedpipe-1.0.jar;../lib/talendcsv.jar;../lib/postgresql-8.3-603.jdbc3.jar;../lib/tns.jar;../lib/talend_file_enhanced_20070724.jar;../lib/talend-oracle-timestamptz.jar;../lib/antlr-runtime-3.5.2.jar;edl_oracle_to_greenplum_with_gpload_0_1.jar;edl_oracle_data_pipe_for_multiload_0_1.jar;").replaceAll(";",classpathSeparator_tRunJob_2));
				    
				    		childJob_commandLine_tRunJob_2.add("aws_dev_talend_ingestion_framework.edl_oracle_to_greenplum_with_gpload_0_1.EDL_Oracle_to_greenplum_with_GPLoad".replaceAll(";",classpathSeparator_tRunJob_2));
				    
				    		childJob_commandLine_tRunJob_2.add("--father_pid="+pid.replaceAll(";",classpathSeparator_tRunJob_2));
				    
				    		childJob_commandLine_tRunJob_2.add("--root_pid="+rootPid.replaceAll(";",classpathSeparator_tRunJob_2));
				    
				    		childJob_commandLine_tRunJob_2.add("--father_node=tRunJob_2".replaceAll(";",classpathSeparator_tRunJob_2));
				    
				    		childJob_commandLine_tRunJob_2.add("--log4jLevel="+ log4jLevel.replaceAll(";",classpathSeparator_tRunJob_2));
				    
				    		childJob_commandLine_tRunJob_2.add("--context=SOURCING_DEV".replaceAll(";",classpathSeparator_tRunJob_2));
				    
				    		childJob_commandLine_tRunJob_2.add("%*".replaceAll(";",classpathSeparator_tRunJob_2));
				    
				childJob_commandLine_Mapper_tRunJob_2.put("EDL_Oracle_to_greenplum_with_GPLoad",childJob_commandLine_tRunJob_2);	
			
				childJob_commandLine_tRunJob_2 = new java.util.ArrayList<String>();
				
				    childJob_commandLine_tRunJob_2.add("java");
				    
				    		childJob_commandLine_tRunJob_2.add("-Xms256M".replaceAll(";",classpathSeparator_tRunJob_2));
				    
				    		childJob_commandLine_tRunJob_2.add("-Xmx4096M".replaceAll(";",classpathSeparator_tRunJob_2));
				    
				    		childJob_commandLine_tRunJob_2.add("-cp".replaceAll(";",classpathSeparator_tRunJob_2));
				    
				    		childJob_commandLine_tRunJob_2.add(dealChildJobLibrary_tRunJob_2.replaceJarPathsFromCrcMap(".;../lib/routines.jar;../lib/log4j-1.2.16.jar;../lib/org.talend.dataquality.parser.jar;../lib/dom4j-1.6.1.jar;../lib/namedpipe-1.0.jar;../lib/talendcsv.jar;../lib/postgresql-8.3-603.jdbc3.jar;../lib/talend_file_enhanced_20070724.jar;../lib/tdgssconfig-15.10.00.14.jar;../lib/antlr-runtime-3.5.2.jar;../lib/terajdbc4-15.10.00.14.jar;edl_teradata_to_greenplum_with_gpload_0_1.jar;").replaceAll(";",classpathSeparator_tRunJob_2));
				    
				    		childJob_commandLine_tRunJob_2.add("aws_dev_talend_ingestion_framework.edl_teradata_to_greenplum_with_gpload_0_1.EDL_Teradata_to_greenplum_with_GPLoad".replaceAll(";",classpathSeparator_tRunJob_2));
				    
				    		childJob_commandLine_tRunJob_2.add("--father_pid="+pid.replaceAll(";",classpathSeparator_tRunJob_2));
				    
				    		childJob_commandLine_tRunJob_2.add("--root_pid="+rootPid.replaceAll(";",classpathSeparator_tRunJob_2));
				    
				    		childJob_commandLine_tRunJob_2.add("--father_node=tRunJob_2".replaceAll(";",classpathSeparator_tRunJob_2));
				    
				    		childJob_commandLine_tRunJob_2.add("--log4jLevel="+ log4jLevel.replaceAll(";",classpathSeparator_tRunJob_2));
				    
				    		childJob_commandLine_tRunJob_2.add("--context=SOURCING_DEV".replaceAll(";",classpathSeparator_tRunJob_2));
				    
				    		childJob_commandLine_tRunJob_2.add("%*".replaceAll(";",classpathSeparator_tRunJob_2));
				    
				childJob_commandLine_Mapper_tRunJob_2.put("EDL_Teradata_to_greenplum_with_GPLoad",childJob_commandLine_tRunJob_2);	
			

 



/**
 * [tRunJob_2 begin ] stop
 */
	
	/**
	 * [tRunJob_2 main ] start
	 */

	

	
	
	currentComponent="tRunJob_2";

	
	java.util.List<String> paraList_tRunJob_2 = new java.util.ArrayList<String>();
	
		if(childJob_commandLine_Mapper_tRunJob_2.get(((String)globalMap.get("job_name")))==null){
			throw new RuntimeException("The child job named "+((String)globalMap.get("job_name"))+" is not in the job list.");
		}
		paraList_tRunJob_2.addAll(childJob_commandLine_Mapper_tRunJob_2.get(((String)globalMap.get("job_name"))));
	
	//for feature:10589
	
		paraList_tRunJob_2.add("--stat_port=" + null);
	

	if(resuming_logs_dir_path != null){
		paraList_tRunJob_2.add("--resuming_logs_dir_path=" + resuming_logs_dir_path);
	}
	String childResumePath_tRunJob_2 = ResumeUtil.getChildJobCheckPointPath(resuming_checkpoint_path);
	String tRunJobName_tRunJob_2 = ResumeUtil.getRighttRunJob(resuming_checkpoint_path);
	if("tRunJob_2".equals(tRunJobName_tRunJob_2) && childResumePath_tRunJob_2 != null){
		paraList_tRunJob_2.add("--resuming_checkpoint_path=" + ResumeUtil.getChildJobCheckPointPath(resuming_checkpoint_path));
	}
	paraList_tRunJob_2.add("--parent_part_launcher=JOB:" + jobName + "/NODE:tRunJob_2");
	
	java.util.Map<String, Object> parentContextMap_tRunJob_2 = new java.util.HashMap<String, Object>();

	
		
		localContext.synchronizeContext();
		
			parentContextMap_tRunJob_2.put("GP_SOURCE_NAME", localContext.GP_SOURCE_NAME);
		
			parentContextMap_tRunJob_2.put("TABLE_NAME", localContext.TABLE_NAME);
		
			parentContextMap_tRunJob_2.put("FORCE_DROP", localContext.FORCE_DROP);
		
			parentContextMap_tRunJob_2.put("FORCE_BATCH", localContext.FORCE_BATCH);
		
			parentContextMap_tRunJob_2.put("LOAD2HDFS", localContext.LOAD2HDFS);
		
			parentContextMap_tRunJob_2.put("SOURCE_HOST", localContext.SOURCE_HOST);
		
			parentContextMap_tRunJob_2.put("SOURCE_DATABASE", localContext.SOURCE_DATABASE);
		
			parentContextMap_tRunJob_2.put("SOURCE_USER", localContext.SOURCE_USER);
		
			parentContextMap_tRunJob_2.put("SOURCE_PORT", localContext.SOURCE_PORT);
		
			parentContextMap_tRunJob_2.put("SOURCE_PASSWORD", localContext.SOURCE_PASSWORD);
		
			parentContextMap_tRunJob_2.put("TOP_N_ROWS", localContext.TOP_N_ROWS);
		
			parentContextMap_tRunJob_2.put("THREAD", localContext.THREAD);
		
			parentContextMap_tRunJob_2.put("RUN_ID", localContext.RUN_ID);
		
			parentContextMap_tRunJob_2.put("PROD2DEV", localContext.PROD2DEV);
		
			parentContextMap_tRunJob_2.put("SEND_MAIL", localContext.SEND_MAIL);
		
			parentContextMap_tRunJob_2.put("PUBLIC", localContext.PUBLIC);
		
			parentContextMap_tRunJob_2.put("PYTHON_NEEDED", localContext.PYTHON_NEEDED);
		
			parentContextMap_tRunJob_2.put("mail_to_error", localContext.mail_to_error);
		
			parentContextMap_tRunJob_2.put("JOB_LABEL_NAME", localContext.JOB_LABEL_NAME);
		
			parentContextMap_tRunJob_2.put("PLANT_NAME", localContext.PLANT_NAME);
		
			parentContextMap_tRunJob_2.put("LOG_NO_OF_ERRORS", localContext.LOG_NO_OF_ERRORS);
		
			parentContextMap_tRunJob_2.put("LOG_PLANT_NAME", localContext.LOG_PLANT_NAME);
		
			parentContextMap_tRunJob_2.put("LOG_NO_OF_UPDATES", localContext.LOG_NO_OF_UPDATES);
		
			parentContextMap_tRunJob_2.put("LOG_SOURCE_ROW_COUNT", localContext.LOG_SOURCE_ROW_COUNT);
		
			parentContextMap_tRunJob_2.put("LOG_TECHNOLOGY", localContext.LOG_TECHNOLOGY);
		
			parentContextMap_tRunJob_2.put("LOG_TABLE_NAME", localContext.LOG_TABLE_NAME);
		
			parentContextMap_tRunJob_2.put("LOG_NO_OF_INSERTS", localContext.LOG_NO_OF_INSERTS);
		
			parentContextMap_tRunJob_2.put("LOG_DATA_PATH", localContext.LOG_DATA_PATH);
		
			parentContextMap_tRunJob_2.put("LOG_NO_OF_DELETES", localContext.LOG_NO_OF_DELETES);
		
			parentContextMap_tRunJob_2.put("LOG_RUN_ID", localContext.LOG_RUN_ID);
		
			parentContextMap_tRunJob_2.put("LOG_ERROR_CATEGORY", localContext.LOG_ERROR_CATEGORY);
		
			parentContextMap_tRunJob_2.put("LOG_JOB_NAME", localContext.LOG_JOB_NAME);
		
			parentContextMap_tRunJob_2.put("LOG_SYSTEM_NAME", localContext.LOG_SYSTEM_NAME);
		
			parentContextMap_tRunJob_2.put("LOG_MESSAGE", localContext.LOG_MESSAGE);
		
			parentContextMap_tRunJob_2.put("LOG_TARGET_ROW_COUNT", localContext.LOG_TARGET_ROW_COUNT);
		
			parentContextMap_tRunJob_2.put("LOG_STATUS", localContext.LOG_STATUS);
		
			parentContextMap_tRunJob_2.put("PRIVATE_KEY", localContext.PRIVATE_KEY);
		
			parentContextMap_tRunJob_2.put("CURSOR_SIZE", localContext.CURSOR_SIZE);
		
			parentContextMap_tRunJob_2.put("PROD2DEV_THREADS", localContext.PROD2DEV_THREADS);
		
			parentContextMap_tRunJob_2.put("MAIL_TO", localContext.MAIL_TO);
		
			parentContextMap_tRunJob_2.put("IGNORE_TIMEZONE", localContext.IGNORE_TIMEZONE);
		
			parentContextMap_tRunJob_2.put("RECREATE_SCHEMA", localContext.RECREATE_SCHEMA);
		
			parentContextMap_tRunJob_2.put("DB_VERSION", localContext.DB_VERSION);
		
			parentContextMap_tRunJob_2.put("IS_MULTITHREAD_BY_TABLE", localContext.IS_MULTITHREAD_BY_TABLE);
		
			parentContextMap_tRunJob_2.put("OSPASSWORD", localContext.OSPASSWORD);
		
			parentContextMap_tRunJob_2.put("OSUSER", localContext.OSUSER);
		
			parentContextMap_tRunJob_2.put("PYTHON_HOST", localContext.PYTHON_HOST);
		
			parentContextMap_tRunJob_2.put("PYTHON_PATH", localContext.PYTHON_PATH);
		
			parentContextMap_tRunJob_2.put("ETL_LOCALHOSTNAME", localContext.ETL_LOCALHOSTNAME);
		
			parentContextMap_tRunJob_2.put("ETL_STORAGE_PATH", localContext.ETL_STORAGE_PATH);
		
			parentContextMap_tRunJob_2.put("HAWQ_Source_Ports", localContext.HAWQ_Source_Ports);
		
			parentContextMap_tRunJob_2.put("SOURCING_Database", localContext.SOURCING_Database);
		
			parentContextMap_tRunJob_2.put("SOURCING_Login", localContext.SOURCING_Login);
		
			parentContextMap_tRunJob_2.put("SOURCING_Password", localContext.SOURCING_Password);
		
			parentContextMap_tRunJob_2.put("SOURCING_Port", localContext.SOURCING_Port);
		
			parentContextMap_tRunJob_2.put("SOURCING_Schema", localContext.SOURCING_Schema);
		
			parentContextMap_tRunJob_2.put("SOURCING_Server", localContext.SOURCING_Server);
		 
		java.util.Enumeration<?> propertyNames_tRunJob_2 = localContext.propertyNames();
		while (propertyNames_tRunJob_2.hasMoreElements()) {
			String key_tRunJob_2 = (String) propertyNames_tRunJob_2.nextElement();
			Object value_tRunJob_2 = (Object) localContext.get(key_tRunJob_2);       
			paraList_tRunJob_2.add("--context_param " + key_tRunJob_2 + "=" + value_tRunJob_2);
			
		}
		

	Object obj_tRunJob_2 = null;

	
	
		Runtime runtime_tRunJob_2 = Runtime.getRuntime();
		final Process ps_tRunJob_2;
		ps_tRunJob_2 = runtime_tRunJob_2.exec((String[])paraList_tRunJob_2.toArray(new String[paraList_tRunJob_2.size()]));

		Thread normal_tRunJob_2 = new Thread() {
			public void run() {
				try {
					java.io.BufferedReader reader = new java.io.BufferedReader(new java.io.InputStreamReader(ps_tRunJob_2.getInputStream()));
					String line = "";
					try {
						while((line = reader.readLine()) != null) {
						System.out.println(line);
						}
					} finally {
					reader.close();
					}
				} catch(java.io.IOException ioe) {
					
						log.error("tRunJob_2 - " + ioe.getMessage());
					
					ioe.printStackTrace();
				}
	    	}
  		};
		
			log.info("tRunJob_2 - The child job '"+((String)globalMap.get("job_name"))+"' starts on the version '0.1' with the context ''.");
		
		normal_tRunJob_2.start();
		
			log.info("tRunJob_2 - The child job '"+((String)globalMap.get("job_name"))+"' is done.");
		

		final StringBuffer errorMsg_tRunJob_2 = new StringBuffer();
		Thread error_tRunJob_2 = new Thread() {
			public void run() {
				try {
					java.io.BufferedReader reader = new java.io.BufferedReader(new java.io.InputStreamReader(ps_tRunJob_2.getErrorStream()));
					String line = "";
        			try {
          				while((line = reader.readLine()) != null) {
            				errorMsg_tRunJob_2.append(line).append("\n");
          				}
        			} finally {
          				reader.close();
        			}
      			} catch(java.io.IOException ioe) {
					
						log.error("tRunJob_2 - " + ioe.getMessage());
					
			        ioe.printStackTrace();
      			}
    		}
		};
		error_tRunJob_2.start();

		//0 indicates normal termination	
		int result_tRunJob_2 = ps_tRunJob_2.waitFor();
		normal_tRunJob_2.join(10000);
		error_tRunJob_2.join(10000);
  
		globalMap.put("tRunJob_2_CHILD_RETURN_CODE",result_tRunJob_2);
		if(result_tRunJob_2 != 0){
   			globalMap.put("tRunJob_2_CHILD_EXCEPTION_STACKTRACE",errorMsg_tRunJob_2.toString());
			
				
					log.error("tRunJob_2 - Child job returns " + result_tRunJob_2 + ". It doesn't terminate normally.\n" + errorMsg_tRunJob_2.toString());
				
				System.err.println("Child job returns " + result_tRunJob_2 + ". It doesn't terminate normally.\n" + errorMsg_tRunJob_2.toString());
			
  		}

		

 


	tos_count_tRunJob_2++;

/**
 * [tRunJob_2 main ] stop
 */
	
	/**
	 * [tRunJob_2 end ] start
	 */

	

	
	
	currentComponent="tRunJob_2";

	

 
                if(log.isDebugEnabled())
            log.debug("tRunJob_2 - "  + ("Done.") );

ok_Hash.put("tRunJob_2", true);
end_Hash.put("tRunJob_2", System.currentTimeMillis());




/**
 * [tRunJob_2 end ] stop
 */
					if(execStat){
						runStat.updateStatOnConnection("iterate1",2,"exec"+iterateId);
					}				
				
						} catch (java.lang.Exception e) {
							this.status = "failure";
							Integer localErrorCode = (Integer) (((java.util.Map) threadLocal.get()).get("errorCode"));
							if (localErrorCode != null) {
								if (this.errorCode == null || localErrorCode.compareTo(this.errorCode) > 0) {
									this.errorCode = localErrorCode;
								}
							}					
				            		            
		                    TalendException te = new TalendException(e, currentComponent, globalMap);
							
							this.exception = te;
							talendThreadPool.setErrorThread(this);
				            talendThreadPool.stopAllWorkers();
	
						} catch (java.lang.Error error){
							this.status = "failure";
							Integer localErrorCode = (Integer) (((java.util.Map) threadLocal.get()).get("errorCode"));
							if (localErrorCode != null) {
								if (this.errorCode == null || localErrorCode.compareTo(this.errorCode) > 0) {
									this.errorCode = localErrorCode;
								}
							}					
							this.error = error;				            		            
							talendThreadPool.setErrorThread(this);
				            talendThreadPool.stopAllWorkers();
						} finally {
							try{
								
	
	/**
	 * [tRunJob_2 finally ] start
	 */

	

	
	
	currentComponent="tRunJob_2";

	

 



/**
 * [tRunJob_2 finally ] stop
 */
							}catch(java.lang.Exception e){	
								//ignore
							}catch(java.lang.Error error){
								//ignore
							}
							resourceMap = null;
						}
						this.isRunning = false;
				
						Integer localErrorCode = (Integer) (((java.util.Map) threadLocal.get()).get("errorCode"));
						String localStatus = (String) (((java.util.Map) threadLocal.get()).get("status"));
						if (localErrorCode != null) {
							if (this.errorCode == null || localErrorCode.compareTo(this.errorCode) > 0) {
								this.errorCode = localErrorCode;
							}
						} 
						if (!this.status.equals("failure")) {
							this.status = localStatus;
						}
						
						talendThreadPool.getTalendThreadResult().setErrorCode(this.errorCode);
						talendThreadPool.getTalendThreadResult().setStatus(this.status);						
					}
				}

				tRunJob_2Thread bt_tRunJob_2 = new tRunJob_2Thread(globalMap,row3,row4,threadIdCounter_tRunJob_2++);
				mtp_tRunJob_2.execute(bt_tRunJob_2);

				








} // End of branch "row3"




	
	/**
	 * [tFileInputDelimited_1 end ] start
	 */

	

	
	
	currentComponent="tFileInputDelimited_1";

	



            }
            }finally{
                if(!((Object)(context.ETL_STORAGE_PATH + "/" +context.GP_SOURCE_NAME + "/" +((String)globalMap.get("timestamp"))+".csv") instanceof java.io.InputStream)){
                	if(fid_tFileInputDelimited_1!=null){
                		fid_tFileInputDelimited_1.close();
                	}
                }
                if(fid_tFileInputDelimited_1!=null){
                	globalMap.put("tFileInputDelimited_1_NB_LINE", fid_tFileInputDelimited_1.getRowNumber());
					
						log.info("tFileInputDelimited_1 - Retrieved records count: "+ fid_tFileInputDelimited_1.getRowNumber() + ".");
					
                }
			}
			  

 
                if(log.isDebugEnabled())
            log.debug("tFileInputDelimited_1 - "  + ("Done.") );

ok_Hash.put("tFileInputDelimited_1", true);
end_Hash.put("tFileInputDelimited_1", System.currentTimeMillis());




/**
 * [tFileInputDelimited_1 end ] stop
 */

	
	/**
	 * [tJavaRow_2 end ] start
	 */

	

	
	
	currentComponent="tJavaRow_2";

	

globalMap.put("tJavaRow_2_NB_LINE",nb_line_tJavaRow_2);
			if(execStat){
				if(resourceMap.get("inIterateVComp") == null || !((Boolean)resourceMap.get("inIterateVComp"))){
			 		runStat.updateStatOnConnection("row3"+iterateId,2, 0); 
			 	}
			}
		
 

ok_Hash.put("tJavaRow_2", true);
end_Hash.put("tJavaRow_2", System.currentTimeMillis());




/**
 * [tJavaRow_2 end ] stop
 */

	
	/**
	 * [tFlowToIterate_1 end ] start
	 */

	

	
	
	currentComponent="tFlowToIterate_1";

	

globalMap.put("tFlowToIterate_1_NB_LINE",nb_line_tFlowToIterate_1);
			if(execStat){
				if(resourceMap.get("inIterateVComp") == null || !((Boolean)resourceMap.get("inIterateVComp"))){
			 		runStat.updateStatOnConnection("row4"+iterateId,2, 0); 
			 	}
			}
		
 
                if(log.isDebugEnabled())
            log.debug("tFlowToIterate_1 - "  + ("Done.") );

ok_Hash.put("tFlowToIterate_1", true);
end_Hash.put("tFlowToIterate_1", System.currentTimeMillis());


			mtp_tRunJob_2.waitForEndOfQueue();
			
			TalendThread errorThread_tRunJob_2 = mtp_tRunJob_2.getErrorThread();

	if(errorThread_tRunJob_2 != null) {
		Integer localErrorCode = (Integer) (((java.util.Map) threadLocal.get()).get("errorCode"));
		String localStatus = (String) (((java.util.Map) threadLocal.get()).get("status"));
		
		if (errorThread_tRunJob_2.errorCode != null) {
			if (localErrorCode == null || errorThread_tRunJob_2.errorCode.compareTo(localErrorCode) > 0) {
				((java.util.Map) threadLocal.get()).put("errorCode", errorThread_tRunJob_2.errorCode);
			}
		} 
		if (!localStatus.equals("failure")) {
			((java.util.Map) threadLocal.get()).put("status", errorThread_tRunJob_2.status);
		}
		if(errorThread_tRunJob_2.exception!=null){
			throw errorThread_tRunJob_2.exception;
		}		
	}else{
		Integer threadErrorCode = mtp_tRunJob_2.getTalendThreadResult().getErrorCode();
		String threadStatus = mtp_tRunJob_2.getTalendThreadResult().getStatus();
		
		Integer localErrorCode = (Integer) (((java.util.Map) threadLocal
				.get()).get("errorCode"));
		String localStatus = (String) (((java.util.Map) threadLocal
				.get()).get("status"));

		if (threadErrorCode != null) {
			if (localErrorCode == null
					|| threadErrorCode.compareTo(localErrorCode) > 0) {
				((java.util.Map) threadLocal.get()).put("errorCode",
						threadErrorCode);
			}
		} 
		if (!localStatus.equals("failure")) {
			((java.util.Map) threadLocal.get()).put("status",
					threadStatus);
		}
	}
			
			


/**
 * [tFlowToIterate_1 end ] stop
 */






				}//end the resume

				
				    			if(resumeEntryMethodName == null || globalResumeTicket){
				    				resumeUtil.addLog("CHECKPOINT", "CONNECTION:SUBJOB_OK:tFileInputDelimited_1:OnSubjobOk1", "", Thread.currentThread().getId() + "", "", "", "", "", "");
								}	    				    			
					    	
								if(execStat){    	
									runStat.updateStatOnConnection("OnSubjobOk8", 0, "ok");
								} 
							
							tFileDelete_1Process(globalMap); 
						
				    			if(resumeEntryMethodName == null || globalResumeTicket){
				    				resumeUtil.addLog("CHECKPOINT", "CONNECTION:SUBJOB_OK:tFileInputDelimited_1:OnSubjobOk2", "", Thread.currentThread().getId() + "", "", "", "", "", "");
								}	    				    			
					    	
								if(execStat){    	
									runStat.updateStatOnConnection("OnSubjobOk34", 0, "ok");
								} 
							
							tJava_13Process(globalMap); 
						
				    			if(resumeEntryMethodName == null || globalResumeTicket){
				    				resumeUtil.addLog("CHECKPOINT", "CONNECTION:SUBJOB_OK:tFileInputDelimited_1:OnSubjobOk3", "", Thread.currentThread().getId() + "", "", "", "", "", "");
								}	    				    			
					    	
								if(execStat){    	
									runStat.updateStatOnConnection("OnSubjobOk22", 0, "ok");
								} 
							
							tGreenplumConnection_4Process(globalMap); 
						
				    			if(resumeEntryMethodName == null || globalResumeTicket){
				    				resumeUtil.addLog("CHECKPOINT", "CONNECTION:SUBJOB_OK:tFileInputDelimited_1:OnSubjobOk4", "", Thread.currentThread().getId() + "", "", "", "", "", "");
								}	    				    			
					    	
								if(execStat){    	
									runStat.updateStatOnConnection("OnSubjobOk39", 0, "ok");
								} 
							
							tGreenplumConnection_6Process(globalMap); 
						
				    			if(resumeEntryMethodName == null || globalResumeTicket){
				    				resumeUtil.addLog("CHECKPOINT", "CONNECTION:SUBJOB_OK:tFileInputDelimited_1:OnSubjobOk5", "", Thread.currentThread().getId() + "", "", "", "", "", "");
								}	    				    			
					    	
								if(execStat){    	
									runStat.updateStatOnConnection("OnSubjobOk40", 0, "ok");
								} 
							
							tJava_14Process(globalMap); 
						
				    			if(resumeEntryMethodName == null || globalResumeTicket){
				    				resumeUtil.addLog("CHECKPOINT", "CONNECTION:SUBJOB_OK:tFileInputDelimited_1:OnSubjobOk6", "", Thread.currentThread().getId() + "", "", "", "", "", "");
								}	    				    			
					    	
								if(execStat){    	
									runStat.updateStatOnConnection("OnSubjobOk41", 0, "ok");
								} 
							
							tJava_15Process(globalMap); 
						



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage());
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tFileInputDelimited_1 finally ] start
	 */

	

	
	
	currentComponent="tFileInputDelimited_1";

	

 



/**
 * [tFileInputDelimited_1 finally ] stop
 */

	
	/**
	 * [tJavaRow_2 finally ] start
	 */

	

	
	
	currentComponent="tJavaRow_2";

	

 



/**
 * [tJavaRow_2 finally ] stop
 */

	
	/**
	 * [tFlowToIterate_1 finally ] start
	 */

	

	
	
	currentComponent="tFlowToIterate_1";

	

 



/**
 * [tFlowToIterate_1 finally ] stop
 */






				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tFileInputDelimited_1_SUBPROCESS_STATE", 1);
	}
	

public void tFileDelete_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tFileDelete_1_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;





	
	/**
	 * [tFileDelete_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tFileDelete_1", false);
		start_Hash.put("tFileDelete_1", System.currentTimeMillis());
		
				talendStats_STATS.addMessage("begin","tFileDelete_1");
				talendStats_STATSProcess(globalMap);
			
	
	currentComponent="tFileDelete_1";

	
		int tos_count_tFileDelete_1 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tFileDelete_1 - "  + ("Start to work.") );
    	class BytesLimit65535_tFileDelete_1{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tFileDelete_1 = new StringBuilder();
            log4jParamters_tFileDelete_1.append("Parameters:");
                    log4jParamters_tFileDelete_1.append("FILENAME" + " = " + "context.ETL_STORAGE_PATH + \"/\" +context.GP_SOURCE_NAME + \"/\" +((String)globalMap.get(\"timestamp\"))+\".csv\"");
                log4jParamters_tFileDelete_1.append(" | ");
                    log4jParamters_tFileDelete_1.append("FAILON" + " = " + "true");
                log4jParamters_tFileDelete_1.append(" | ");
                    log4jParamters_tFileDelete_1.append("FOLDER" + " = " + "false");
                log4jParamters_tFileDelete_1.append(" | ");
                    log4jParamters_tFileDelete_1.append("FOLDER_FILE" + " = " + "false");
                log4jParamters_tFileDelete_1.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tFileDelete_1 - "  + (log4jParamters_tFileDelete_1) );
    		}
    	}
    	
        new BytesLimit65535_tFileDelete_1().limitLog4jByte();

 



/**
 * [tFileDelete_1 begin ] stop
 */
	
	/**
	 * [tFileDelete_1 main ] start
	 */

	

	
	
	currentComponent="tFileDelete_1";

	

 

				final StringBuffer log4jSb_tFileDelete_1 = new StringBuffer();
			
class DeleteFoldertFileDelete_1{
	 /**
     * delete all the sub-files in 'file'
     * 
     * @param file
     */
	public boolean delete(java.io.File file) {
        java.io.File[] files = file.listFiles();
        for (int i = 0; i < files.length; i++) {
            if (files[i].isFile()) {
                files[i].delete();
            } else if (files[i].isDirectory()) {
                if (!files[i].delete()) {
                    delete(files[i]);
                }
            }
        }
        deleteDirectory(file);
        return file.delete();
    }

    /**
     * delete all the sub-folders in 'file'
     * 
     * @param file
     */
    private void deleteDirectory(java.io.File file) {
        java.io.File[] filed = file.listFiles();
        for (int i = 0; i < filed.length; i++) {
        	if(filed[i].isDirectory()) {
            	deleteDirectory(filed[i]);
            }
            filed[i].delete();
        }
    }

}
    java.io.File file_tFileDelete_1=new java.io.File(context.ETL_STORAGE_PATH + "/" +context.GP_SOURCE_NAME + "/" +((String)globalMap.get("timestamp"))+".csv");
    if(file_tFileDelete_1.exists()&& file_tFileDelete_1.isFile()){
    	if(file_tFileDelete_1.delete()){
    		globalMap.put("tFileDelete_1_CURRENT_STATUS", "File deleted.");
    		log.info("tFileDelete_1 - File : "+ file_tFileDelete_1.getAbsolutePath() + " is deleted.");
    	}else{
    		globalMap.put("tFileDelete_1_CURRENT_STATUS", "No file deleted.");
    		log.info("tFileDelete_1 - Fail to delete file : "+ file_tFileDelete_1.getAbsolutePath());
    	}
    }else{
    	globalMap.put("tFileDelete_1_CURRENT_STATUS", "File does not exist or is invalid.");
    		throw new RuntimeException("File does not exist or is invalid.");
	}
	globalMap.put("tFileDelete_1_DELETE_PATH",context.ETL_STORAGE_PATH + "/" +context.GP_SOURCE_NAME + "/" +((String)globalMap.get("timestamp"))+".csv");
    
     
 

 


	tos_count_tFileDelete_1++;

/**
 * [tFileDelete_1 main ] stop
 */
	
	/**
	 * [tFileDelete_1 end ] start
	 */

	

	
	
	currentComponent="tFileDelete_1";

	

 
                if(log.isDebugEnabled())
            log.debug("tFileDelete_1 - "  + ("Done.") );

ok_Hash.put("tFileDelete_1", true);
end_Hash.put("tFileDelete_1", System.currentTimeMillis());

talendStats_STATS.addMessage("end","tFileDelete_1", end_Hash.get("tFileDelete_1")-start_Hash.get("tFileDelete_1"));
talendStats_STATSProcess(globalMap);



/**
 * [tFileDelete_1 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage());
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tFileDelete_1 finally ] start
	 */

	

	
	
	currentComponent="tFileDelete_1";

	

 



/**
 * [tFileDelete_1 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tFileDelete_1_SUBPROCESS_STATE", 1);
	}
	

public void tJava_13Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tJava_13_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tJava_13 begin ] start
	 */

	

	
		
		ok_Hash.put("tJava_13", false);
		start_Hash.put("tJava_13", System.currentTimeMillis());
		
	
	currentComponent="tJava_13";

	
		int tos_count_tJava_13 = 0;
		
    	class BytesLimit65535_tJava_13{
    		public void limitLog4jByte() throws Exception{
    			
    		}
    	}
    	
        new BytesLimit65535_tJava_13().limitLog4jByte();



 



/**
 * [tJava_13 begin ] stop
 */
	
	/**
	 * [tJava_13 main ] start
	 */

	

	
	
	currentComponent="tJava_13";

	

 


	tos_count_tJava_13++;

/**
 * [tJava_13 main ] stop
 */
	
	/**
	 * [tJava_13 end ] start
	 */

	

	
	
	currentComponent="tJava_13";

	

 

ok_Hash.put("tJava_13", true);
end_Hash.put("tJava_13", System.currentTimeMillis());

   			if (context.getProperty("PROD2DEV").equals("Y")) {
   				
					if(execStat){   
   	 					runStat.updateStatOnConnection("If16", 0, "true");
					}
				
    			tRunJob_4Process(globalMap);
   			}

			   
   				else{
					if(execStat){   
   	 					runStat.updateStatOnConnection("If16", 0, "false");
					}   	 
   				}



/**
 * [tJava_13 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage());
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tJava_13 finally ] start
	 */

	

	
	
	currentComponent="tJava_13";

	

 



/**
 * [tJava_13 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tJava_13_SUBPROCESS_STATE", 1);
	}
	

public void tRunJob_4Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tRunJob_4_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;





	
	/**
	 * [tRunJob_4 begin ] start
	 */

	

	
		
		ok_Hash.put("tRunJob_4", false);
		start_Hash.put("tRunJob_4", System.currentTimeMillis());
		
	
	currentComponent="tRunJob_4";

	
		int tos_count_tRunJob_4 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tRunJob_4 - "  + ("Start to work.") );
    	class BytesLimit65535_tRunJob_4{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tRunJob_4 = new StringBuilder();
            log4jParamters_tRunJob_4.append("Parameters:");
                    log4jParamters_tRunJob_4.append("USE_DYNAMIC_JOB" + " = " + "false");
                log4jParamters_tRunJob_4.append(" | ");
                    log4jParamters_tRunJob_4.append("PROCESS" + " = " + "EDL_Prod2Dev_with_GP_FDIST");
                log4jParamters_tRunJob_4.append(" | ");
                    log4jParamters_tRunJob_4.append("USE_INDEPENDENT_PROCESS" + " = " + "false");
                log4jParamters_tRunJob_4.append(" | ");
                    log4jParamters_tRunJob_4.append("DIE_ON_CHILD_ERROR" + " = " + "false");
                log4jParamters_tRunJob_4.append(" | ");
                    log4jParamters_tRunJob_4.append("TRANSMIT_WHOLE_CONTEXT" + " = " + "true");
                log4jParamters_tRunJob_4.append(" | ");
                    log4jParamters_tRunJob_4.append("CONTEXTPARAMS" + " = " + "[{PARAM_NAME_COLUMN="+("GP_SOURCE_NAME")+", PARAM_VALUE_COLUMN="+("context.GP_SOURCE_NAME")+"}, {PARAM_NAME_COLUMN="+("FORCE_DROP")+", PARAM_VALUE_COLUMN="+("context.FORCE_DROP")+"}, {PARAM_NAME_COLUMN="+("RUN_ID")+", PARAM_VALUE_COLUMN="+("context.RUN_ID")+"}, {PARAM_NAME_COLUMN="+("TABLE_NAME")+", PARAM_VALUE_COLUMN="+("(String)globalMap.get(\"orig_table_name\")")+"}, {PARAM_NAME_COLUMN="+("ETL_STORAGE_PATH")+", PARAM_VALUE_COLUMN="+("context.ETL_STORAGE_PATH")+"}, {PARAM_NAME_COLUMN="+("ETL_LOCALHOSTNAME")+", PARAM_VALUE_COLUMN="+("context.ETL_LOCALHOSTNAME")+"}, {PARAM_NAME_COLUMN="+("SOURCE_DATABASE")+", PARAM_VALUE_COLUMN="+("context.SOURCING_Database")+"}, {PARAM_NAME_COLUMN="+("SOURCE_HOST")+", PARAM_VALUE_COLUMN="+("context.SOURCING_Server")+"}, {PARAM_NAME_COLUMN="+("SOURCE_PASSWORD")+", PARAM_VALUE_COLUMN="+("context.SOURCING_Password")+"}, {PARAM_NAME_COLUMN="+("SOURCE_USER")+", PARAM_VALUE_COLUMN="+("context.SOURCING_Login")+"}, {PARAM_NAME_COLUMN="+("SOURCING_Database")+", PARAM_VALUE_COLUMN="+("context.SOURCING_Database")+"}, {PARAM_NAME_COLUMN="+("SOURCING_Server")+", PARAM_VALUE_COLUMN="+("\"3.48.35.24\"")+"}, {PARAM_NAME_COLUMN="+("SOURCING_Login")+", PARAM_VALUE_COLUMN="+("context.SOURCING_Login")+"}, {PARAM_NAME_COLUMN="+("SOURCING_Password")+", PARAM_VALUE_COLUMN="+("context.SOURCING_Password")+"}, {PARAM_NAME_COLUMN="+("SOURCING_Port")+", PARAM_VALUE_COLUMN="+("context.SOURCING_Port")+"}, {PARAM_NAME_COLUMN="+("SOURCE_PORT")+", PARAM_VALUE_COLUMN="+("context.SOURCE_PORT")+"}, {PARAM_NAME_COLUMN="+("MAIL_TO")+", PARAM_VALUE_COLUMN="+("context.MAIL_TO")+"}, {PARAM_NAME_COLUMN="+("THREAD")+", PARAM_VALUE_COLUMN="+("context.PROD2DEV_THREADS")+"}, {PARAM_NAME_COLUMN="+("PUBLIC")+", PARAM_VALUE_COLUMN="+("context.PUBLIC")+"}, {PARAM_NAME_COLUMN="+("SEND_MAIL")+", PARAM_VALUE_COLUMN="+("context.SEND_MAIL")+"}]");
                log4jParamters_tRunJob_4.append(" | ");
                    log4jParamters_tRunJob_4.append("PROPAGATE_CHILD_RESULT" + " = " + "false");
                log4jParamters_tRunJob_4.append(" | ");
                    log4jParamters_tRunJob_4.append("PRINT_PARAMETER" + " = " + "false");
                log4jParamters_tRunJob_4.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tRunJob_4 - "  + (log4jParamters_tRunJob_4) );
    		}
    	}
    	
        new BytesLimit65535_tRunJob_4().limitLog4jByte();


 



/**
 * [tRunJob_4 begin ] stop
 */
	
	/**
	 * [tRunJob_4 main ] start
	 */

	

	
	
	currentComponent="tRunJob_4";

	
	java.util.List<String> paraList_tRunJob_4 = new java.util.ArrayList<String>();
	
	        			paraList_tRunJob_4.add("--father_pid="+pid);
	      			
	        			paraList_tRunJob_4.add("--root_pid="+rootPid);
	      			
	        			paraList_tRunJob_4.add("--father_node=tRunJob_4");
	      			
	        			paraList_tRunJob_4.add("--context=SOURCING_DEV");
	      			
			if(!"".equals(log4jLevel)){
				paraList_tRunJob_4.add("--log4jLevel="+log4jLevel);
			}
		
	//for feature:10589
	
		paraList_tRunJob_4.add("--stat_port=" + portStats);
	

	if(resuming_logs_dir_path != null){
		paraList_tRunJob_4.add("--resuming_logs_dir_path=" + resuming_logs_dir_path);
	}
	String childResumePath_tRunJob_4 = ResumeUtil.getChildJobCheckPointPath(resuming_checkpoint_path);
	String tRunJobName_tRunJob_4 = ResumeUtil.getRighttRunJob(resuming_checkpoint_path);
	if("tRunJob_4".equals(tRunJobName_tRunJob_4) && childResumePath_tRunJob_4 != null){
		paraList_tRunJob_4.add("--resuming_checkpoint_path=" + ResumeUtil.getChildJobCheckPointPath(resuming_checkpoint_path));
	}
	paraList_tRunJob_4.add("--parent_part_launcher=JOB:" + jobName + "/NODE:tRunJob_4");
	
	java.util.Map<String, Object> parentContextMap_tRunJob_4 = new java.util.HashMap<String, Object>();

	
		
		context.synchronizeContext();
		
			parentContextMap_tRunJob_4.put("GP_SOURCE_NAME", context.GP_SOURCE_NAME);
		
			parentContextMap_tRunJob_4.put("TABLE_NAME", context.TABLE_NAME);
		
			parentContextMap_tRunJob_4.put("FORCE_DROP", context.FORCE_DROP);
		
			parentContextMap_tRunJob_4.put("FORCE_BATCH", context.FORCE_BATCH);
		
			parentContextMap_tRunJob_4.put("LOAD2HDFS", context.LOAD2HDFS);
		
			parentContextMap_tRunJob_4.put("SOURCE_HOST", context.SOURCE_HOST);
		
			parentContextMap_tRunJob_4.put("SOURCE_DATABASE", context.SOURCE_DATABASE);
		
			parentContextMap_tRunJob_4.put("SOURCE_USER", context.SOURCE_USER);
		
			parentContextMap_tRunJob_4.put("SOURCE_PORT", context.SOURCE_PORT);
		
			parentContextMap_tRunJob_4.put("SOURCE_PASSWORD", context.SOURCE_PASSWORD);
		
			parentContextMap_tRunJob_4.put("TOP_N_ROWS", context.TOP_N_ROWS);
		
			parentContextMap_tRunJob_4.put("THREAD", context.THREAD);
		
			parentContextMap_tRunJob_4.put("RUN_ID", context.RUN_ID);
		
			parentContextMap_tRunJob_4.put("PROD2DEV", context.PROD2DEV);
		
			parentContextMap_tRunJob_4.put("SEND_MAIL", context.SEND_MAIL);
		
			parentContextMap_tRunJob_4.put("PUBLIC", context.PUBLIC);
		
			parentContextMap_tRunJob_4.put("PYTHON_NEEDED", context.PYTHON_NEEDED);
		
			parentContextMap_tRunJob_4.put("mail_to_error", context.mail_to_error);
		
			parentContextMap_tRunJob_4.put("JOB_LABEL_NAME", context.JOB_LABEL_NAME);
		
			parentContextMap_tRunJob_4.put("PLANT_NAME", context.PLANT_NAME);
		
			parentContextMap_tRunJob_4.put("LOG_NO_OF_ERRORS", context.LOG_NO_OF_ERRORS);
		
			parentContextMap_tRunJob_4.put("LOG_PLANT_NAME", context.LOG_PLANT_NAME);
		
			parentContextMap_tRunJob_4.put("LOG_NO_OF_UPDATES", context.LOG_NO_OF_UPDATES);
		
			parentContextMap_tRunJob_4.put("LOG_SOURCE_ROW_COUNT", context.LOG_SOURCE_ROW_COUNT);
		
			parentContextMap_tRunJob_4.put("LOG_TECHNOLOGY", context.LOG_TECHNOLOGY);
		
			parentContextMap_tRunJob_4.put("LOG_TABLE_NAME", context.LOG_TABLE_NAME);
		
			parentContextMap_tRunJob_4.put("LOG_NO_OF_INSERTS", context.LOG_NO_OF_INSERTS);
		
			parentContextMap_tRunJob_4.put("LOG_DATA_PATH", context.LOG_DATA_PATH);
		
			parentContextMap_tRunJob_4.put("LOG_NO_OF_DELETES", context.LOG_NO_OF_DELETES);
		
			parentContextMap_tRunJob_4.put("LOG_RUN_ID", context.LOG_RUN_ID);
		
			parentContextMap_tRunJob_4.put("LOG_ERROR_CATEGORY", context.LOG_ERROR_CATEGORY);
		
			parentContextMap_tRunJob_4.put("LOG_JOB_NAME", context.LOG_JOB_NAME);
		
			parentContextMap_tRunJob_4.put("LOG_SYSTEM_NAME", context.LOG_SYSTEM_NAME);
		
			parentContextMap_tRunJob_4.put("LOG_MESSAGE", context.LOG_MESSAGE);
		
			parentContextMap_tRunJob_4.put("LOG_TARGET_ROW_COUNT", context.LOG_TARGET_ROW_COUNT);
		
			parentContextMap_tRunJob_4.put("LOG_STATUS", context.LOG_STATUS);
		
			parentContextMap_tRunJob_4.put("PRIVATE_KEY", context.PRIVATE_KEY);
		
			parentContextMap_tRunJob_4.put("CURSOR_SIZE", context.CURSOR_SIZE);
		
			parentContextMap_tRunJob_4.put("PROD2DEV_THREADS", context.PROD2DEV_THREADS);
		
			parentContextMap_tRunJob_4.put("MAIL_TO", context.MAIL_TO);
		
			parentContextMap_tRunJob_4.put("IGNORE_TIMEZONE", context.IGNORE_TIMEZONE);
		
			parentContextMap_tRunJob_4.put("RECREATE_SCHEMA", context.RECREATE_SCHEMA);
		
			parentContextMap_tRunJob_4.put("DB_VERSION", context.DB_VERSION);
		
			parentContextMap_tRunJob_4.put("IS_MULTITHREAD_BY_TABLE", context.IS_MULTITHREAD_BY_TABLE);
		
			parentContextMap_tRunJob_4.put("OSPASSWORD", context.OSPASSWORD);
		
			parentContextMap_tRunJob_4.put("OSUSER", context.OSUSER);
		
			parentContextMap_tRunJob_4.put("PYTHON_HOST", context.PYTHON_HOST);
		
			parentContextMap_tRunJob_4.put("PYTHON_PATH", context.PYTHON_PATH);
		
			parentContextMap_tRunJob_4.put("ETL_LOCALHOSTNAME", context.ETL_LOCALHOSTNAME);
		
			parentContextMap_tRunJob_4.put("ETL_STORAGE_PATH", context.ETL_STORAGE_PATH);
		
			parentContextMap_tRunJob_4.put("HAWQ_Source_Ports", context.HAWQ_Source_Ports);
		
			parentContextMap_tRunJob_4.put("SOURCING_Database", context.SOURCING_Database);
		
			parentContextMap_tRunJob_4.put("SOURCING_Login", context.SOURCING_Login);
		
			parentContextMap_tRunJob_4.put("SOURCING_Password", context.SOURCING_Password);
		
			parentContextMap_tRunJob_4.put("SOURCING_Port", context.SOURCING_Port);
		
			parentContextMap_tRunJob_4.put("SOURCING_Schema", context.SOURCING_Schema);
		
			parentContextMap_tRunJob_4.put("SOURCING_Server", context.SOURCING_Server);
		 
		java.util.Enumeration<?> propertyNames_tRunJob_4 = context.propertyNames();
		while (propertyNames_tRunJob_4.hasMoreElements()) {
			String key_tRunJob_4 = (String) propertyNames_tRunJob_4.nextElement();
			Object value_tRunJob_4 = (Object) context.get(key_tRunJob_4);       
			paraList_tRunJob_4.add("--context_param " + key_tRunJob_4 + "=" + value_tRunJob_4);
			
		}
		

	Object obj_tRunJob_4 = null;

	
		obj_tRunJob_4 = context.GP_SOURCE_NAME;
		paraList_tRunJob_4.add("--context_param GP_SOURCE_NAME=" + RuntimeUtils.tRunJobConvertContext(obj_tRunJob_4));
		
		parentContextMap_tRunJob_4.put("GP_SOURCE_NAME", obj_tRunJob_4);
	
		obj_tRunJob_4 = context.FORCE_DROP;
		paraList_tRunJob_4.add("--context_param FORCE_DROP=" + RuntimeUtils.tRunJobConvertContext(obj_tRunJob_4));
		
		parentContextMap_tRunJob_4.put("FORCE_DROP", obj_tRunJob_4);
	
		obj_tRunJob_4 = context.RUN_ID;
		paraList_tRunJob_4.add("--context_param RUN_ID=" + RuntimeUtils.tRunJobConvertContext(obj_tRunJob_4));
		
		parentContextMap_tRunJob_4.put("RUN_ID", obj_tRunJob_4);
	
		obj_tRunJob_4 = (String)globalMap.get("orig_table_name");
		paraList_tRunJob_4.add("--context_param TABLE_NAME=" + RuntimeUtils.tRunJobConvertContext(obj_tRunJob_4));
		
		parentContextMap_tRunJob_4.put("TABLE_NAME", obj_tRunJob_4);
	
		obj_tRunJob_4 = context.ETL_STORAGE_PATH;
		paraList_tRunJob_4.add("--context_param ETL_STORAGE_PATH=" + RuntimeUtils.tRunJobConvertContext(obj_tRunJob_4));
		
		parentContextMap_tRunJob_4.put("ETL_STORAGE_PATH", obj_tRunJob_4);
	
		obj_tRunJob_4 = context.ETL_LOCALHOSTNAME;
		paraList_tRunJob_4.add("--context_param ETL_LOCALHOSTNAME=" + RuntimeUtils.tRunJobConvertContext(obj_tRunJob_4));
		
		parentContextMap_tRunJob_4.put("ETL_LOCALHOSTNAME", obj_tRunJob_4);
	
		obj_tRunJob_4 = context.SOURCING_Database;
		paraList_tRunJob_4.add("--context_param SOURCE_DATABASE=" + RuntimeUtils.tRunJobConvertContext(obj_tRunJob_4));
		
		parentContextMap_tRunJob_4.put("SOURCE_DATABASE", obj_tRunJob_4);
	
		obj_tRunJob_4 = context.SOURCING_Server;
		paraList_tRunJob_4.add("--context_param SOURCE_HOST=" + RuntimeUtils.tRunJobConvertContext(obj_tRunJob_4));
		
		parentContextMap_tRunJob_4.put("SOURCE_HOST", obj_tRunJob_4);
	
		obj_tRunJob_4 = context.SOURCING_Password;
		paraList_tRunJob_4.add("--context_param SOURCE_PASSWORD=" + RuntimeUtils.tRunJobConvertContext(obj_tRunJob_4));
		
		parentContextMap_tRunJob_4.put("SOURCE_PASSWORD", obj_tRunJob_4);
	
		obj_tRunJob_4 = context.SOURCING_Login;
		paraList_tRunJob_4.add("--context_param SOURCE_USER=" + RuntimeUtils.tRunJobConvertContext(obj_tRunJob_4));
		
		parentContextMap_tRunJob_4.put("SOURCE_USER", obj_tRunJob_4);
	
		obj_tRunJob_4 = context.SOURCING_Database;
		paraList_tRunJob_4.add("--context_param SOURCING_Database=" + RuntimeUtils.tRunJobConvertContext(obj_tRunJob_4));
		
		parentContextMap_tRunJob_4.put("SOURCING_Database", obj_tRunJob_4);
	
		obj_tRunJob_4 = "3.48.35.24";
		paraList_tRunJob_4.add("--context_param SOURCING_Server=" + RuntimeUtils.tRunJobConvertContext(obj_tRunJob_4));
		
		parentContextMap_tRunJob_4.put("SOURCING_Server", obj_tRunJob_4);
	
		obj_tRunJob_4 = context.SOURCING_Login;
		paraList_tRunJob_4.add("--context_param SOURCING_Login=" + RuntimeUtils.tRunJobConvertContext(obj_tRunJob_4));
		
		parentContextMap_tRunJob_4.put("SOURCING_Login", obj_tRunJob_4);
	
		obj_tRunJob_4 = context.SOURCING_Password;
		paraList_tRunJob_4.add("--context_param SOURCING_Password=" + RuntimeUtils.tRunJobConvertContext(obj_tRunJob_4));
		
		parentContextMap_tRunJob_4.put("SOURCING_Password", obj_tRunJob_4);
	
		obj_tRunJob_4 = context.SOURCING_Port;
		paraList_tRunJob_4.add("--context_param SOURCING_Port=" + RuntimeUtils.tRunJobConvertContext(obj_tRunJob_4));
		
		parentContextMap_tRunJob_4.put("SOURCING_Port", obj_tRunJob_4);
	
		obj_tRunJob_4 = context.SOURCE_PORT;
		paraList_tRunJob_4.add("--context_param SOURCE_PORT=" + RuntimeUtils.tRunJobConvertContext(obj_tRunJob_4));
		
		parentContextMap_tRunJob_4.put("SOURCE_PORT", obj_tRunJob_4);
	
		obj_tRunJob_4 = context.MAIL_TO;
		paraList_tRunJob_4.add("--context_param MAIL_TO=" + RuntimeUtils.tRunJobConvertContext(obj_tRunJob_4));
		
		parentContextMap_tRunJob_4.put("MAIL_TO", obj_tRunJob_4);
	
		obj_tRunJob_4 = context.PROD2DEV_THREADS;
		paraList_tRunJob_4.add("--context_param THREAD=" + RuntimeUtils.tRunJobConvertContext(obj_tRunJob_4));
		
		parentContextMap_tRunJob_4.put("THREAD", obj_tRunJob_4);
	
		obj_tRunJob_4 = context.PUBLIC;
		paraList_tRunJob_4.add("--context_param PUBLIC=" + RuntimeUtils.tRunJobConvertContext(obj_tRunJob_4));
		
		parentContextMap_tRunJob_4.put("PUBLIC", obj_tRunJob_4);
	
		obj_tRunJob_4 = context.SEND_MAIL;
		paraList_tRunJob_4.add("--context_param SEND_MAIL=" + RuntimeUtils.tRunJobConvertContext(obj_tRunJob_4));
		
		parentContextMap_tRunJob_4.put("SEND_MAIL", obj_tRunJob_4);
	
	
		aws_dev_talend_ingestion_framework.edl_prod2dev_with_gp_fdist_0_1.EDL_Prod2Dev_with_GP_FDIST childJob_tRunJob_4 = new aws_dev_talend_ingestion_framework.edl_prod2dev_with_gp_fdist_0_1.EDL_Prod2Dev_with_GP_FDIST();
	    // pass DataSources
	    java.util.Map<String, routines.system.TalendDataSource> talendDataSources_tRunJob_4 = (java.util.Map<String, routines.system.TalendDataSource>) globalMap
	            .get(KEY_DB_DATASOURCES);
	    if (null != talendDataSources_tRunJob_4) {
	        java.util.Map<String, javax.sql.DataSource> dataSources_tRunJob_4 = new java.util.HashMap<String, javax.sql.DataSource>();
	        for (java.util.Map.Entry<String, routines.system.TalendDataSource> talendDataSourceEntry_tRunJob_4 : talendDataSources_tRunJob_4
			        .entrySet()) {
	            dataSources_tRunJob_4.put(talendDataSourceEntry_tRunJob_4.getKey(),
	                    talendDataSourceEntry_tRunJob_4.getValue().getRawDataSource());
	        }
	        childJob_tRunJob_4.setDataSources(dataSources_tRunJob_4);
	    }
		  
			childJob_tRunJob_4.parentContextMap = parentContextMap_tRunJob_4;
		  
		
			log.info("tRunJob_4 - The child job 'aws_dev_talend_ingestion_framework.edl_prod2dev_with_gp_fdist_0_1.EDL_Prod2Dev_with_GP_FDIST' starts on the version '0.1' with the context 'SOURCING_DEV'.");
		
		String[][] childReturn_tRunJob_4 = childJob_tRunJob_4.runJob((String[]) paraList_tRunJob_4.toArray(new String[paraList_tRunJob_4.size()]));
		
			log.info("tRunJob_4 - The child job 'aws_dev_talend_ingestion_framework.edl_prod2dev_with_gp_fdist_0_1.EDL_Prod2Dev_with_GP_FDIST' is done.");
		
	  	
				((java.util.Map)threadLocal.get()).put("errorCode", childJob_tRunJob_4.getErrorCode());
			
	            
	    	if(childJob_tRunJob_4.getErrorCode() == null){
				globalMap.put("tRunJob_4_CHILD_RETURN_CODE", childJob_tRunJob_4.getStatus() != null && ("failure").equals(childJob_tRunJob_4.getStatus()) ? 1 : 0);
	    	}else{
				globalMap.put("tRunJob_4_CHILD_RETURN_CODE", childJob_tRunJob_4.getErrorCode());
		    }
		    if (childJob_tRunJob_4.getExceptionStackTrace() != null) { 
		    	globalMap.put("tRunJob_4_CHILD_EXCEPTION_STACKTRACE", childJob_tRunJob_4.getExceptionStackTrace());
		    }
	  
			
	  	

 


	tos_count_tRunJob_4++;

/**
 * [tRunJob_4 main ] stop
 */
	
	/**
	 * [tRunJob_4 end ] start
	 */

	

	
	
	currentComponent="tRunJob_4";

	

 
                if(log.isDebugEnabled())
            log.debug("tRunJob_4 - "  + ("Done.") );

ok_Hash.put("tRunJob_4", true);
end_Hash.put("tRunJob_4", System.currentTimeMillis());




/**
 * [tRunJob_4 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage());
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tRunJob_4 finally ] start
	 */

	

	
	
	currentComponent="tRunJob_4";

	

 



/**
 * [tRunJob_4 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tRunJob_4_SUBPROCESS_STATE", 1);
	}
	

public void tGreenplumConnection_4Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tGreenplumConnection_4_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tGreenplumConnection_4 begin ] start
	 */

	

	
		
		ok_Hash.put("tGreenplumConnection_4", false);
		start_Hash.put("tGreenplumConnection_4", System.currentTimeMillis());
		
	
	currentComponent="tGreenplumConnection_4";

	
		int tos_count_tGreenplumConnection_4 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tGreenplumConnection_4 - "  + ("Start to work.") );
    	class BytesLimit65535_tGreenplumConnection_4{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tGreenplumConnection_4 = new StringBuilder();
            log4jParamters_tGreenplumConnection_4.append("Parameters:");
                    log4jParamters_tGreenplumConnection_4.append("HOST" + " = " + "context.SOURCING_Server");
                log4jParamters_tGreenplumConnection_4.append(" | ");
                    log4jParamters_tGreenplumConnection_4.append("PORT" + " = " + "context.SOURCING_Port");
                log4jParamters_tGreenplumConnection_4.append(" | ");
                    log4jParamters_tGreenplumConnection_4.append("DBNAME" + " = " + "context.SOURCING_Database");
                log4jParamters_tGreenplumConnection_4.append(" | ");
                    log4jParamters_tGreenplumConnection_4.append("SCHEMA_DB" + " = " + "context.SOURCING_Schema");
                log4jParamters_tGreenplumConnection_4.append(" | ");
                    log4jParamters_tGreenplumConnection_4.append("USER" + " = " + "context.SOURCING_Login");
                log4jParamters_tGreenplumConnection_4.append(" | ");
                    log4jParamters_tGreenplumConnection_4.append("PASS" + " = " + String.valueOf(routines.system.PasswordEncryptUtil.encryptPassword(context.SOURCING_Password)).substring(0, 4) + "...");     
                log4jParamters_tGreenplumConnection_4.append(" | ");
                    log4jParamters_tGreenplumConnection_4.append("USE_SHARED_CONNECTION" + " = " + "true");
                log4jParamters_tGreenplumConnection_4.append(" | ");
                    log4jParamters_tGreenplumConnection_4.append("SHARED_CONNECTION_NAME" + " = " + "\"base_dynamic\"+((String)globalMap.get(\"timestamp\"))");
                log4jParamters_tGreenplumConnection_4.append(" | ");
                    log4jParamters_tGreenplumConnection_4.append("USE_SSL" + " = " + "true");
                log4jParamters_tGreenplumConnection_4.append(" | ");
                    log4jParamters_tGreenplumConnection_4.append("AUTO_COMMIT" + " = " + "true");
                log4jParamters_tGreenplumConnection_4.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tGreenplumConnection_4 - "  + (log4jParamters_tGreenplumConnection_4) );
    		}
    	}
    	
        new BytesLimit65535_tGreenplumConnection_4().limitLog4jByte();
	

	
				String url_tGreenplumConnection_4 = "jdbc:postgresql://"+context.SOURCING_Server+":"+context.SOURCING_Port+"/"+context.SOURCING_Database+"?ssl=true&sslfactory=org.postgresql.ssl.NonValidatingFactory";

	String dbUser_tGreenplumConnection_4 = context.SOURCING_Login;
	
	
		
	final String decryptedPassword_tGreenplumConnection_4 = context.SOURCING_Password; 
		String dbPwd_tGreenplumConnection_4 = decryptedPassword_tGreenplumConnection_4;
	

	java.sql.Connection conn_tGreenplumConnection_4 = null;
	
	
			SharedDBConnectionLog4j.initLogger(log,"tGreenplumConnection_4");
			String sharedConnectionName_tGreenplumConnection_4 = "base_dynamic"+((String)globalMap.get("timestamp"));
			conn_tGreenplumConnection_4 = SharedDBConnectionLog4j.getDBConnection("org.postgresql.Driver",url_tGreenplumConnection_4,dbUser_tGreenplumConnection_4 , dbPwd_tGreenplumConnection_4 , sharedConnectionName_tGreenplumConnection_4);
	if (null != conn_tGreenplumConnection_4) {
		
			log.debug("tGreenplumConnection_4 - Connection is set auto commit to 'true'.");
			conn_tGreenplumConnection_4.setAutoCommit(true);
	}

	globalMap.put("schema_" + "tGreenplumConnection_4",context.SOURCING_Schema);

	globalMap.put("conn_" + "tGreenplumConnection_4",conn_tGreenplumConnection_4);
 



/**
 * [tGreenplumConnection_4 begin ] stop
 */
	
	/**
	 * [tGreenplumConnection_4 main ] start
	 */

	

	
	
	currentComponent="tGreenplumConnection_4";

	

 


	tos_count_tGreenplumConnection_4++;

/**
 * [tGreenplumConnection_4 main ] stop
 */
	
	/**
	 * [tGreenplumConnection_4 end ] start
	 */

	

	
	
	currentComponent="tGreenplumConnection_4";

	

 
                if(log.isDebugEnabled())
            log.debug("tGreenplumConnection_4 - "  + ("Done.") );

ok_Hash.put("tGreenplumConnection_4", true);
end_Hash.put("tGreenplumConnection_4", System.currentTimeMillis());




/**
 * [tGreenplumConnection_4 end ] stop
 */
				}//end the resume

				
				    			if(resumeEntryMethodName == null || globalResumeTicket){
				    				resumeUtil.addLog("CHECKPOINT", "CONNECTION:SUBJOB_OK:tGreenplumConnection_4:OnSubjobOk", "", Thread.currentThread().getId() + "", "", "", "", "", "");
								}	    				    			
					    	
								if(execStat){    	
									runStat.updateStatOnConnection("OnSubjobOk26", 0, "ok");
								} 
							
							tGreenplumInput_8Process(globalMap); 
						



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage());
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tGreenplumConnection_4 finally ] start
	 */

	

	
	
	currentComponent="tGreenplumConnection_4";

	

 



/**
 * [tGreenplumConnection_4 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tGreenplumConnection_4_SUBPROCESS_STATE", 1);
	}
	


public static class row8Struct implements routines.system.IPersistableRow<row8Struct> {
    final static byte[] commonByteArrayLock_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Base_dynamic = new byte[0];
    static byte[] commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Base_dynamic = new byte[0];

	
			    public Integer row_id;

				public Integer getRow_id () {
					return this.row_id;
				}
				


	private Integer readInteger(ObjectInputStream dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}

	private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException{
		if(intNum == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeInt(intNum);
    	}
	}

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Base_dynamic) {

        	try {

        		int length = 0;
		
						this.row_id = readInteger(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// Integer
				
						writeInteger(this.row_id,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("row_id="+String.valueOf(row_id));
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				if(row_id == null){
        					sb.append("<null>");
        				}else{
            				sb.append(row_id);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(row8Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}
public void tGreenplumInput_8Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tGreenplumInput_8_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;



		row8Struct row8 = new row8Struct();




	
	/**
	 * [tSetGlobalVar_5 begin ] start
	 */

	

	
		
		ok_Hash.put("tSetGlobalVar_5", false);
		start_Hash.put("tSetGlobalVar_5", System.currentTimeMillis());
		
	
	currentComponent="tSetGlobalVar_5";

	
			if (execStat) {
				if(resourceMap.get("inIterateVComp") == null){
					
						runStat.updateStatOnConnection("row8" + iterateId, 0, 0);
					
				}
			} 

		
		int tos_count_tSetGlobalVar_5 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tSetGlobalVar_5 - "  + ("Start to work.") );
    	class BytesLimit65535_tSetGlobalVar_5{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tSetGlobalVar_5 = new StringBuilder();
            log4jParamters_tSetGlobalVar_5.append("Parameters:");
                    log4jParamters_tSetGlobalVar_5.append("VARIABLES" + " = " + "[{VALUE="+("row8.row_id")+", KEY="+("\"LOG_ROW_ID\"")+"}]");
                log4jParamters_tSetGlobalVar_5.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tSetGlobalVar_5 - "  + (log4jParamters_tSetGlobalVar_5) );
    		}
    	}
    	
        new BytesLimit65535_tSetGlobalVar_5().limitLog4jByte();

 



/**
 * [tSetGlobalVar_5 begin ] stop
 */



	
	/**
	 * [tGreenplumInput_8 begin ] start
	 */

	

	
		
		ok_Hash.put("tGreenplumInput_8", false);
		start_Hash.put("tGreenplumInput_8", System.currentTimeMillis());
		
	
	currentComponent="tGreenplumInput_8";

	
		int tos_count_tGreenplumInput_8 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tGreenplumInput_8 - "  + ("Start to work.") );
    	class BytesLimit65535_tGreenplumInput_8{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tGreenplumInput_8 = new StringBuilder();
            log4jParamters_tGreenplumInput_8.append("Parameters:");
                    log4jParamters_tGreenplumInput_8.append("USE_EXISTING_CONNECTION" + " = " + "true");
                log4jParamters_tGreenplumInput_8.append(" | ");
                    log4jParamters_tGreenplumInput_8.append("CONNECTION" + " = " + "tGreenplumConnection_4");
                log4jParamters_tGreenplumInput_8.append(" | ");
                    log4jParamters_tGreenplumInput_8.append("TABLE" + " = " + "\"\"");
                log4jParamters_tGreenplumInput_8.append(" | ");
                    log4jParamters_tGreenplumInput_8.append("QUERYSTORE" + " = " + "\"\"");
                log4jParamters_tGreenplumInput_8.append(" | ");
                    log4jParamters_tGreenplumInput_8.append("QUERY" + " = " + "\"select row_id from sbdt.edl_log where run_id = \"+((Integer)globalMap.get(\"BASE_RUN_ID\"))");
                log4jParamters_tGreenplumInput_8.append(" | ");
                    log4jParamters_tGreenplumInput_8.append("USE_CURSOR" + " = " + "false");
                log4jParamters_tGreenplumInput_8.append(" | ");
                    log4jParamters_tGreenplumInput_8.append("TRIM_ALL_COLUMN" + " = " + "false");
                log4jParamters_tGreenplumInput_8.append(" | ");
                    log4jParamters_tGreenplumInput_8.append("TRIM_COLUMN" + " = " + "[{TRIM="+("false")+", SCHEMA_COLUMN="+("row_id")+"}]");
                log4jParamters_tGreenplumInput_8.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tGreenplumInput_8 - "  + (log4jParamters_tGreenplumInput_8) );
    		}
    	}
    	
        new BytesLimit65535_tGreenplumInput_8().limitLog4jByte();
	
    
	
		    int nb_line_tGreenplumInput_8 = 0;
		    java.sql.Connection conn_tGreenplumInput_8 = null;
		        conn_tGreenplumInput_8 = (java.sql.Connection)globalMap.get("conn_tGreenplumConnection_4");
				
				if(conn_tGreenplumInput_8 != null) {
					if(conn_tGreenplumInput_8.getMetaData() != null) {
						
						log.debug("tGreenplumInput_8 - Uses an existing connection with username '" + conn_tGreenplumInput_8.getMetaData().getUserName() + "'. Connection URL: " + conn_tGreenplumInput_8.getMetaData().getURL() + ".");
						
					}
				}
			
		    
			java.sql.Statement stmt_tGreenplumInput_8 = conn_tGreenplumInput_8.createStatement();

		    String dbquery_tGreenplumInput_8 = "select row_id from sbdt.edl_log where run_id = "+((Integer)globalMap.get("BASE_RUN_ID"));
			
                log.debug("tGreenplumInput_8 - Executing the query: '"+dbquery_tGreenplumInput_8+"'.");
			

                       globalMap.put("tGreenplumInput_8_QUERY",dbquery_tGreenplumInput_8);

		    java.sql.ResultSet rs_tGreenplumInput_8 = null;
		try{
		    rs_tGreenplumInput_8 = stmt_tGreenplumInput_8.executeQuery(dbquery_tGreenplumInput_8);
		    java.sql.ResultSetMetaData rsmd_tGreenplumInput_8 = rs_tGreenplumInput_8.getMetaData();
		    int colQtyInRs_tGreenplumInput_8 = rsmd_tGreenplumInput_8.getColumnCount();

		    String tmpContent_tGreenplumInput_8 = null;
		    
		    
		    	log.debug("tGreenplumInput_8 - Retrieving records from the database.");
		    
		    while (rs_tGreenplumInput_8.next()) {
		        nb_line_tGreenplumInput_8++;
		        
							if(colQtyInRs_tGreenplumInput_8 < 1) {
								row8.row_id = null;
							} else {
		                          
            if(rs_tGreenplumInput_8.getObject(1) != null) {
                row8.row_id = rs_tGreenplumInput_8.getInt(1);
            } else {
                    row8.row_id = null;
            }
		                    }
					
						log.debug("tGreenplumInput_8 - Retrieving the record " + nb_line_tGreenplumInput_8 + ".");
					


 



/**
 * [tGreenplumInput_8 begin ] stop
 */
	
	/**
	 * [tGreenplumInput_8 main ] start
	 */

	

	
	
	currentComponent="tGreenplumInput_8";

	

 


	tos_count_tGreenplumInput_8++;

/**
 * [tGreenplumInput_8 main ] stop
 */

	
	/**
	 * [tSetGlobalVar_5 main ] start
	 */

	

	
	
	currentComponent="tSetGlobalVar_5";

	

			//row8
			//row8


			
				if(execStat){
					runStat.updateStatOnConnection("row8"+iterateId,1, 1);
				} 
			

		
    			if(log.isTraceEnabled()){
    				log.trace("row8 - " + (row8==null? "": row8.toLogString()));
    			}
    		

globalMap.put("LOG_ROW_ID", row8.row_id);

 


	tos_count_tSetGlobalVar_5++;

/**
 * [tSetGlobalVar_5 main ] stop
 */



	
	/**
	 * [tGreenplumInput_8 end ] start
	 */

	

	
	
	currentComponent="tGreenplumInput_8";

	

	}
}finally{
	stmt_tGreenplumInput_8.close();

}
globalMap.put("tGreenplumInput_8_NB_LINE",nb_line_tGreenplumInput_8);
	    		log.debug("tGreenplumInput_8 - Retrieved records count: "+nb_line_tGreenplumInput_8 + " .");
			

 
                if(log.isDebugEnabled())
            log.debug("tGreenplumInput_8 - "  + ("Done.") );

ok_Hash.put("tGreenplumInput_8", true);
end_Hash.put("tGreenplumInput_8", System.currentTimeMillis());




/**
 * [tGreenplumInput_8 end ] stop
 */

	
	/**
	 * [tSetGlobalVar_5 end ] start
	 */

	

	
	
	currentComponent="tSetGlobalVar_5";

	

			if(execStat){
				if(resourceMap.get("inIterateVComp") == null || !((Boolean)resourceMap.get("inIterateVComp"))){
			 		runStat.updateStatOnConnection("row8"+iterateId,2, 0); 
			 	}
			}
		
 
                if(log.isDebugEnabled())
            log.debug("tSetGlobalVar_5 - "  + ("Done.") );

ok_Hash.put("tSetGlobalVar_5", true);
end_Hash.put("tSetGlobalVar_5", System.currentTimeMillis());




/**
 * [tSetGlobalVar_5 end ] stop
 */



				}//end the resume

				
				    			if(resumeEntryMethodName == null || globalResumeTicket){
				    				resumeUtil.addLog("CHECKPOINT", "CONNECTION:SUBJOB_OK:tGreenplumInput_8:OnSubjobOk", "", Thread.currentThread().getId() + "", "", "", "", "", "");
								}	    				    			
					    	
								if(execStat){    	
									runStat.updateStatOnConnection("OnSubjobOk28", 0, "ok");
								} 
							
							tGreenplumInput_7Process(globalMap); 
						



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage());
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tGreenplumInput_8 finally ] start
	 */

	

	
	
	currentComponent="tGreenplumInput_8";

	

 



/**
 * [tGreenplumInput_8 finally ] stop
 */

	
	/**
	 * [tSetGlobalVar_5 finally ] start
	 */

	

	
	
	currentComponent="tSetGlobalVar_5";

	

 



/**
 * [tSetGlobalVar_5 finally ] stop
 */



				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tGreenplumInput_8_SUBPROCESS_STATE", 1);
	}
	


public static class row7Struct implements routines.system.IPersistableRow<row7Struct> {
    final static byte[] commonByteArrayLock_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Base_dynamic = new byte[0];
    static byte[] commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Base_dynamic = new byte[0];

	
			    public Integer cnt;

				public Integer getCnt () {
					return this.cnt;
				}
				
			    public String messages;

				public String getMessages () {
					return this.messages;
				}
				


	private Integer readInteger(ObjectInputStream dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}

	private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException{
		if(intNum == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeInt(intNum);
    	}
	}

	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Base_dynamic.length) {
				if(length < 1024 && commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Base_dynamic.length == 0) {
   					commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Base_dynamic = new byte[1024];
				} else {
   					commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Base_dynamic = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Base_dynamic, 0, length);
			strReturn = new String(commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Base_dynamic, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Base_dynamic) {

        	try {

        		int length = 0;
		
						this.cnt = readInteger(dis);
					
					this.messages = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// Integer
				
						writeInteger(this.cnt,dos);
					
					// String
				
						writeString(this.messages,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("cnt="+String.valueOf(cnt));
		sb.append(",messages="+messages);
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				if(cnt == null){
        					sb.append("<null>");
        				}else{
            				sb.append(cnt);
            			}
            		
        			sb.append("|");
        		
        				if(messages == null){
        					sb.append("<null>");
        				}else{
            				sb.append(messages);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(row7Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}
public void tGreenplumInput_7Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tGreenplumInput_7_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;



		row7Struct row7 = new row7Struct();




	
	/**
	 * [tSetGlobalVar_4 begin ] start
	 */

	

	
		
		ok_Hash.put("tSetGlobalVar_4", false);
		start_Hash.put("tSetGlobalVar_4", System.currentTimeMillis());
		
	
	currentComponent="tSetGlobalVar_4";

	
			if (execStat) {
				if(resourceMap.get("inIterateVComp") == null){
					
						runStat.updateStatOnConnection("row7" + iterateId, 0, 0);
					
				}
			} 

		
		int tos_count_tSetGlobalVar_4 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tSetGlobalVar_4 - "  + ("Start to work.") );
    	class BytesLimit65535_tSetGlobalVar_4{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tSetGlobalVar_4 = new StringBuilder();
            log4jParamters_tSetGlobalVar_4.append("Parameters:");
                    log4jParamters_tSetGlobalVar_4.append("VARIABLES" + " = " + "[{VALUE="+("row7.cnt + \" errors occurred: \" + row7.messages")+", KEY="+("\"error_message_desc\"")+"}, {VALUE="+("row7.cnt ")+", KEY="+("\"error_count\"")+"}]");
                log4jParamters_tSetGlobalVar_4.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tSetGlobalVar_4 - "  + (log4jParamters_tSetGlobalVar_4) );
    		}
    	}
    	
        new BytesLimit65535_tSetGlobalVar_4().limitLog4jByte();

 



/**
 * [tSetGlobalVar_4 begin ] stop
 */



	
	/**
	 * [tGreenplumInput_7 begin ] start
	 */

	

	
		
		ok_Hash.put("tGreenplumInput_7", false);
		start_Hash.put("tGreenplumInput_7", System.currentTimeMillis());
		
	
	currentComponent="tGreenplumInput_7";

	
		int tos_count_tGreenplumInput_7 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tGreenplumInput_7 - "  + ("Start to work.") );
    	class BytesLimit65535_tGreenplumInput_7{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tGreenplumInput_7 = new StringBuilder();
            log4jParamters_tGreenplumInput_7.append("Parameters:");
                    log4jParamters_tGreenplumInput_7.append("USE_EXISTING_CONNECTION" + " = " + "true");
                log4jParamters_tGreenplumInput_7.append(" | ");
                    log4jParamters_tGreenplumInput_7.append("CONNECTION" + " = " + "tGreenplumConnection_4");
                log4jParamters_tGreenplumInput_7.append(" | ");
                    log4jParamters_tGreenplumInput_7.append("TABLE" + " = " + "\"\"");
                log4jParamters_tGreenplumInput_7.append(" | ");
                    log4jParamters_tGreenplumInput_7.append("QUERYSTORE" + " = " + "\"\"");
                log4jParamters_tGreenplumInput_7.append(" | ");
                    log4jParamters_tGreenplumInput_7.append("QUERY" + " = " + "\"select count(*) cnt, substring( string_agg( table_name||' - '||message,' '),0,3950) message  from sbdt.edl_log where  data_path='\"+context.LOG_DATA_PATH+\"' and plant_name='\"+context.LOG_PLANT_NAME+\"' and system_name='\"+context.LOG_SYSTEM_NAME+\"' and status = 'Job Error' and row_id>\"+((Integer)globalMap.get(\"LOG_ROW_ID\"))");
                log4jParamters_tGreenplumInput_7.append(" | ");
                    log4jParamters_tGreenplumInput_7.append("USE_CURSOR" + " = " + "false");
                log4jParamters_tGreenplumInput_7.append(" | ");
                    log4jParamters_tGreenplumInput_7.append("TRIM_ALL_COLUMN" + " = " + "false");
                log4jParamters_tGreenplumInput_7.append(" | ");
                    log4jParamters_tGreenplumInput_7.append("TRIM_COLUMN" + " = " + "[{TRIM="+("false")+", SCHEMA_COLUMN="+("cnt")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("messages")+"}]");
                log4jParamters_tGreenplumInput_7.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tGreenplumInput_7 - "  + (log4jParamters_tGreenplumInput_7) );
    		}
    	}
    	
        new BytesLimit65535_tGreenplumInput_7().limitLog4jByte();
	
    
	
		    int nb_line_tGreenplumInput_7 = 0;
		    java.sql.Connection conn_tGreenplumInput_7 = null;
		        conn_tGreenplumInput_7 = (java.sql.Connection)globalMap.get("conn_tGreenplumConnection_4");
				
				if(conn_tGreenplumInput_7 != null) {
					if(conn_tGreenplumInput_7.getMetaData() != null) {
						
						log.debug("tGreenplumInput_7 - Uses an existing connection with username '" + conn_tGreenplumInput_7.getMetaData().getUserName() + "'. Connection URL: " + conn_tGreenplumInput_7.getMetaData().getURL() + ".");
						
					}
				}
			
		    
			java.sql.Statement stmt_tGreenplumInput_7 = conn_tGreenplumInput_7.createStatement();

		    String dbquery_tGreenplumInput_7 = "select count(*) cnt, substring( string_agg( table_name||' - '||message,' '),0,3950) message  from sbdt.edl_log where  data_path='"+context.LOG_DATA_PATH+"' and plant_name='"+context.LOG_PLANT_NAME+"' and system_name='"+context.LOG_SYSTEM_NAME+"' and status = 'Job Error' and row_id>"+((Integer)globalMap.get("LOG_ROW_ID"));
			
                log.debug("tGreenplumInput_7 - Executing the query: '"+dbquery_tGreenplumInput_7+"'.");
			

                       globalMap.put("tGreenplumInput_7_QUERY",dbquery_tGreenplumInput_7);

		    java.sql.ResultSet rs_tGreenplumInput_7 = null;
		try{
		    rs_tGreenplumInput_7 = stmt_tGreenplumInput_7.executeQuery(dbquery_tGreenplumInput_7);
		    java.sql.ResultSetMetaData rsmd_tGreenplumInput_7 = rs_tGreenplumInput_7.getMetaData();
		    int colQtyInRs_tGreenplumInput_7 = rsmd_tGreenplumInput_7.getColumnCount();

		    String tmpContent_tGreenplumInput_7 = null;
		    
		    
		    	log.debug("tGreenplumInput_7 - Retrieving records from the database.");
		    
		    while (rs_tGreenplumInput_7.next()) {
		        nb_line_tGreenplumInput_7++;
		        
							if(colQtyInRs_tGreenplumInput_7 < 1) {
								row7.cnt = null;
							} else {
		                          
            if(rs_tGreenplumInput_7.getObject(1) != null) {
                row7.cnt = rs_tGreenplumInput_7.getInt(1);
            } else {
                    row7.cnt = null;
            }
		                    }
							if(colQtyInRs_tGreenplumInput_7 < 2) {
								row7.messages = null;
							} else {
	                         		
        	row7.messages = routines.system.JDBCUtil.getString(rs_tGreenplumInput_7, 2, false);
		                    }
					
						log.debug("tGreenplumInput_7 - Retrieving the record " + nb_line_tGreenplumInput_7 + ".");
					


 



/**
 * [tGreenplumInput_7 begin ] stop
 */
	
	/**
	 * [tGreenplumInput_7 main ] start
	 */

	

	
	
	currentComponent="tGreenplumInput_7";

	

 


	tos_count_tGreenplumInput_7++;

/**
 * [tGreenplumInput_7 main ] stop
 */

	
	/**
	 * [tSetGlobalVar_4 main ] start
	 */

	

	
	
	currentComponent="tSetGlobalVar_4";

	

			//row7
			//row7


			
				if(execStat){
					runStat.updateStatOnConnection("row7"+iterateId,1, 1);
				} 
			

		
    			if(log.isTraceEnabled()){
    				log.trace("row7 - " + (row7==null? "": row7.toLogString()));
    			}
    		

globalMap.put("error_message_desc", row7.cnt + " errors occurred: " + row7.messages);
globalMap.put("error_count", row7.cnt );

 


	tos_count_tSetGlobalVar_4++;

/**
 * [tSetGlobalVar_4 main ] stop
 */



	
	/**
	 * [tGreenplumInput_7 end ] start
	 */

	

	
	
	currentComponent="tGreenplumInput_7";

	

	}
}finally{
	stmt_tGreenplumInput_7.close();

}
globalMap.put("tGreenplumInput_7_NB_LINE",nb_line_tGreenplumInput_7);
	    		log.debug("tGreenplumInput_7 - Retrieved records count: "+nb_line_tGreenplumInput_7 + " .");
			

 
                if(log.isDebugEnabled())
            log.debug("tGreenplumInput_7 - "  + ("Done.") );

ok_Hash.put("tGreenplumInput_7", true);
end_Hash.put("tGreenplumInput_7", System.currentTimeMillis());

   			if (((Integer)globalMap.get("error_count"))>0) {
   				
					if(execStat){   
   	 					runStat.updateStatOnConnection("If8", 0, "true");
					}
				
    			tJava_7Process(globalMap);
   			}

			   
   				else{
					if(execStat){   
   	 					runStat.updateStatOnConnection("If8", 0, "false");
					}   	 
   				}
   			if (((Integer)globalMap.get("error_count"))==0) {
   				
					if(execStat){   
   	 					runStat.updateStatOnConnection("If9", 0, "true");
					}
				
    			tJava_10Process(globalMap);
   			}

			   
   				else{
					if(execStat){   
   	 					runStat.updateStatOnConnection("If9", 0, "false");
					}   	 
   				}



/**
 * [tGreenplumInput_7 end ] stop
 */

	
	/**
	 * [tSetGlobalVar_4 end ] start
	 */

	

	
	
	currentComponent="tSetGlobalVar_4";

	

			if(execStat){
				if(resourceMap.get("inIterateVComp") == null || !((Boolean)resourceMap.get("inIterateVComp"))){
			 		runStat.updateStatOnConnection("row7"+iterateId,2, 0); 
			 	}
			}
		
 
                if(log.isDebugEnabled())
            log.debug("tSetGlobalVar_4 - "  + ("Done.") );

ok_Hash.put("tSetGlobalVar_4", true);
end_Hash.put("tSetGlobalVar_4", System.currentTimeMillis());




/**
 * [tSetGlobalVar_4 end ] stop
 */



				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage());
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tGreenplumInput_7 finally ] start
	 */

	

	
	
	currentComponent="tGreenplumInput_7";

	

 



/**
 * [tGreenplumInput_7 finally ] stop
 */

	
	/**
	 * [tSetGlobalVar_4 finally ] start
	 */

	

	
	
	currentComponent="tSetGlobalVar_4";

	

 



/**
 * [tSetGlobalVar_4 finally ] stop
 */



				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tGreenplumInput_7_SUBPROCESS_STATE", 1);
	}
	

public void tJava_7Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tJava_7_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tJava_7 begin ] start
	 */

	

	
		
		ok_Hash.put("tJava_7", false);
		start_Hash.put("tJava_7", System.currentTimeMillis());
		
	
	currentComponent="tJava_7";

	
		int tos_count_tJava_7 = 0;
		
    	class BytesLimit65535_tJava_7{
    		public void limitLog4jByte() throws Exception{
    			
    		}
    	}
    	
        new BytesLimit65535_tJava_7().limitLog4jByte();


//context.LOG_PLANT_NAME="NULL";
//context.LOG_SYSTEM_NAME="NULL";
//context.LOG_TABLE_NAME="NULL";
//context.LOG_JOB_NAME="NULL";
//context.LOG_DATA_PATH="NULL";
//context.LOG_TECHNOLOGY="NULL";
context.LOG_STATUS="Job Error";
context.LOG_MESSAGE=(String)globalMap.get("error_message_desc");
context.LOG_ERROR_CATEGORY="NULL";
context.LOG_NO_OF_INSERTS=0;
context.LOG_NO_OF_UPDATES=0;
context.LOG_NO_OF_DELETES=0;
context.LOG_NO_OF_ERRORS=0;
context.LOG_SOURCE_ROW_COUNT=0;
context.LOG_TARGET_ROW_COUNT=0;

String strInsertLogSql=(String)globalMap.get("insert_log_template");
strInsertLogSql=strInsertLogSql.replace("#PLANT_NAME", "'"+context.LOG_PLANT_NAME+"'");
strInsertLogSql=strInsertLogSql.replace("#SYSTEM_NAME", "'"+context.GP_SOURCE_NAME+"'");
strInsertLogSql=strInsertLogSql.replace("#JOB_NAME", "'"+((String)globalMap.get("jobname_prefix"))+context.LOG_JOB_NAME+"'");
strInsertLogSql=strInsertLogSql.replace("#TABLE_NAME", "'"+(String)globalMap.get("orig_table_name")+"'");
strInsertLogSql=strInsertLogSql.replace("#STATUS", "'"+context.LOG_STATUS+"'");
strInsertLogSql=strInsertLogSql.replace("#DATA_PATH", "'"+context.LOG_DATA_PATH+"'");
strInsertLogSql=strInsertLogSql.replace("#TECHNOLOGY", "'"+context.LOG_TECHNOLOGY+"'");
strInsertLogSql=strInsertLogSql.replace("#NO_OF_INSERTS", ((Integer)context.LOG_NO_OF_INSERTS).toString());
strInsertLogSql=strInsertLogSql.replace("#NO_OF_UPDATES", ((Integer)context.LOG_NO_OF_UPDATES).toString());
strInsertLogSql=strInsertLogSql.replace("#NO_OF_DELETES", ((Integer)context.LOG_NO_OF_DELETES).toString());
strInsertLogSql=strInsertLogSql.replace("#NO_OF_ERRORS", ((Integer)context.LOG_NO_OF_ERRORS).toString());
strInsertLogSql=strInsertLogSql.replace("#MESSAGE", "'"+context.LOG_MESSAGE+"'");
strInsertLogSql=strInsertLogSql.replace("#SOURCE_ROW_COUNT", ((Integer)context.LOG_SOURCE_ROW_COUNT).toString());
strInsertLogSql=strInsertLogSql.replace("#TARGET_ROW_COUNT", ((Integer)context.LOG_TARGET_ROW_COUNT).toString());
strInsertLogSql=strInsertLogSql.replace("#ERROR_CATEGORY", "'"+context.LOG_ERROR_CATEGORY+"'");
globalMap.put("insert_log_sql",strInsertLogSql);

//System.out.println(globalMap.get("insert_log_sql"));
//System.out.println(globalMap.get("error_message_desc"));
//System.out.println("******************************");
//System.out.println("******************************");
//globalMap.put("now",new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(TalendDate.getCurrentDate()).toString());
//System.out.println(globalMap.get("now"));
//((String)globalMap.get("tJavaRow_5_ERROR_MESSAGE")) != null
//((Integer)context.LOG_RUN_ID).toString()
//globalMap.put("now_sql","TO_TIMESTAMP('" + ((String)globalMap.get("now")) + "', 'YYYY-MM-DD HH24:MI:SS')::TIMESTAMP WITH TIME ZONE ");
//System.out.println(globalMap.get("now_sql"));
//if (context.LOG_PLANT_NAME.equals("")==true) {
//  context.LOG_PLANT_NAME="Grove City";
//};
//if (context.LOG_APPLICATION.equals("")==true) {
//  context.LOG_APPLICATION="GET-ABM";
//};
 



/**
 * [tJava_7 begin ] stop
 */
	
	/**
	 * [tJava_7 main ] start
	 */

	

	
	
	currentComponent="tJava_7";

	

 


	tos_count_tJava_7++;

/**
 * [tJava_7 main ] stop
 */
	
	/**
	 * [tJava_7 end ] start
	 */

	

	
	
	currentComponent="tJava_7";

	

 

ok_Hash.put("tJava_7", true);
end_Hash.put("tJava_7", System.currentTimeMillis());




/**
 * [tJava_7 end ] stop
 */
				}//end the resume

				
				    			if(resumeEntryMethodName == null || globalResumeTicket){
				    				resumeUtil.addLog("CHECKPOINT", "CONNECTION:SUBJOB_OK:tJava_7:OnSubjobOk", "", Thread.currentThread().getId() + "", "", "", "", "", "");
								}	    				    			
					    	
								if(execStat){    	
									runStat.updateStatOnConnection("OnSubjobOk19", 0, "ok");
								} 
							
							tGreenplumConnection_3Process(globalMap); 
						



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage());
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tJava_7 finally ] start
	 */

	

	
	
	currentComponent="tJava_7";

	

 



/**
 * [tJava_7 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tJava_7_SUBPROCESS_STATE", 1);
	}
	

public void tGreenplumConnection_3Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tGreenplumConnection_3_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tGreenplumConnection_3 begin ] start
	 */

	

	
		
		ok_Hash.put("tGreenplumConnection_3", false);
		start_Hash.put("tGreenplumConnection_3", System.currentTimeMillis());
		
	
	currentComponent="tGreenplumConnection_3";

	
		int tos_count_tGreenplumConnection_3 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tGreenplumConnection_3 - "  + ("Start to work.") );
    	class BytesLimit65535_tGreenplumConnection_3{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tGreenplumConnection_3 = new StringBuilder();
            log4jParamters_tGreenplumConnection_3.append("Parameters:");
                    log4jParamters_tGreenplumConnection_3.append("HOST" + " = " + "context.SOURCING_Server");
                log4jParamters_tGreenplumConnection_3.append(" | ");
                    log4jParamters_tGreenplumConnection_3.append("PORT" + " = " + "context.SOURCING_Port");
                log4jParamters_tGreenplumConnection_3.append(" | ");
                    log4jParamters_tGreenplumConnection_3.append("DBNAME" + " = " + "context.SOURCING_Database");
                log4jParamters_tGreenplumConnection_3.append(" | ");
                    log4jParamters_tGreenplumConnection_3.append("SCHEMA_DB" + " = " + "context.SOURCING_Schema");
                log4jParamters_tGreenplumConnection_3.append(" | ");
                    log4jParamters_tGreenplumConnection_3.append("USER" + " = " + "context.SOURCING_Login");
                log4jParamters_tGreenplumConnection_3.append(" | ");
                    log4jParamters_tGreenplumConnection_3.append("PASS" + " = " + String.valueOf(routines.system.PasswordEncryptUtil.encryptPassword(context.SOURCING_Password)).substring(0, 4) + "...");     
                log4jParamters_tGreenplumConnection_3.append(" | ");
                    log4jParamters_tGreenplumConnection_3.append("USE_SHARED_CONNECTION" + " = " + "true");
                log4jParamters_tGreenplumConnection_3.append(" | ");
                    log4jParamters_tGreenplumConnection_3.append("SHARED_CONNECTION_NAME" + " = " + "\"base_dynamic\"+((String)globalMap.get(\"timestamp\"))");
                log4jParamters_tGreenplumConnection_3.append(" | ");
                    log4jParamters_tGreenplumConnection_3.append("USE_SSL" + " = " + "true");
                log4jParamters_tGreenplumConnection_3.append(" | ");
                    log4jParamters_tGreenplumConnection_3.append("AUTO_COMMIT" + " = " + "true");
                log4jParamters_tGreenplumConnection_3.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tGreenplumConnection_3 - "  + (log4jParamters_tGreenplumConnection_3) );
    		}
    	}
    	
        new BytesLimit65535_tGreenplumConnection_3().limitLog4jByte();
	

	
				String url_tGreenplumConnection_3 = "jdbc:postgresql://"+context.SOURCING_Server+":"+context.SOURCING_Port+"/"+context.SOURCING_Database+"?ssl=true&sslfactory=org.postgresql.ssl.NonValidatingFactory";

	String dbUser_tGreenplumConnection_3 = context.SOURCING_Login;
	
	
		
	final String decryptedPassword_tGreenplumConnection_3 = context.SOURCING_Password; 
		String dbPwd_tGreenplumConnection_3 = decryptedPassword_tGreenplumConnection_3;
	

	java.sql.Connection conn_tGreenplumConnection_3 = null;
	
	
			SharedDBConnectionLog4j.initLogger(log,"tGreenplumConnection_3");
			String sharedConnectionName_tGreenplumConnection_3 = "base_dynamic"+((String)globalMap.get("timestamp"));
			conn_tGreenplumConnection_3 = SharedDBConnectionLog4j.getDBConnection("org.postgresql.Driver",url_tGreenplumConnection_3,dbUser_tGreenplumConnection_3 , dbPwd_tGreenplumConnection_3 , sharedConnectionName_tGreenplumConnection_3);
	if (null != conn_tGreenplumConnection_3) {
		
			log.debug("tGreenplumConnection_3 - Connection is set auto commit to 'true'.");
			conn_tGreenplumConnection_3.setAutoCommit(true);
	}

	globalMap.put("schema_" + "tGreenplumConnection_3",context.SOURCING_Schema);

	globalMap.put("conn_" + "tGreenplumConnection_3",conn_tGreenplumConnection_3);
 



/**
 * [tGreenplumConnection_3 begin ] stop
 */
	
	/**
	 * [tGreenplumConnection_3 main ] start
	 */

	

	
	
	currentComponent="tGreenplumConnection_3";

	

 


	tos_count_tGreenplumConnection_3++;

/**
 * [tGreenplumConnection_3 main ] stop
 */
	
	/**
	 * [tGreenplumConnection_3 end ] start
	 */

	

	
	
	currentComponent="tGreenplumConnection_3";

	

 
                if(log.isDebugEnabled())
            log.debug("tGreenplumConnection_3 - "  + ("Done.") );

ok_Hash.put("tGreenplumConnection_3", true);
end_Hash.put("tGreenplumConnection_3", System.currentTimeMillis());

   			if (context.LOG_RUN_ID == -1) {
   				
					if(execStat){   
   	 					runStat.updateStatOnConnection("If5", 0, "true");
					}
				
    			tGreenplumInput_6Process(globalMap);
   			}

			   
   				else{
					if(execStat){   
   	 					runStat.updateStatOnConnection("If5", 0, "false");
					}   	 
   				}
   			if (context.LOG_RUN_ID != -1) {
   				
					if(execStat){   
   	 					runStat.updateStatOnConnection("If6", 0, "true");
					}
				
    			tJava_8Process(globalMap);
   			}

			   
   				else{
					if(execStat){   
   	 					runStat.updateStatOnConnection("If6", 0, "false");
					}   	 
   				}



/**
 * [tGreenplumConnection_3 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage());
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tGreenplumConnection_3 finally ] start
	 */

	

	
	
	currentComponent="tGreenplumConnection_3";

	

 



/**
 * [tGreenplumConnection_3 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tGreenplumConnection_3_SUBPROCESS_STATE", 1);
	}
	


public static class row12Struct implements routines.system.IPersistableRow<row12Struct> {
    final static byte[] commonByteArrayLock_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Base_dynamic = new byte[0];
    static byte[] commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Base_dynamic = new byte[0];

	
			    public Integer run_id;

				public Integer getRun_id () {
					return this.run_id;
				}
				


	private Integer readInteger(ObjectInputStream dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}

	private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException{
		if(intNum == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeInt(intNum);
    	}
	}

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Base_dynamic) {

        	try {

        		int length = 0;
		
						this.run_id = readInteger(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// Integer
				
						writeInteger(this.run_id,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("run_id="+String.valueOf(run_id));
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				if(run_id == null){
        					sb.append("<null>");
        				}else{
            				sb.append(run_id);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(row12Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}
public void tGreenplumInput_6Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tGreenplumInput_6_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;



		row12Struct row12 = new row12Struct();




	
	/**
	 * [tJavaRow_4 begin ] start
	 */

	

	
		
		ok_Hash.put("tJavaRow_4", false);
		start_Hash.put("tJavaRow_4", System.currentTimeMillis());
		
	
	currentComponent="tJavaRow_4";

	
			if (execStat) {
				if(resourceMap.get("inIterateVComp") == null){
					
						runStat.updateStatOnConnection("row12" + iterateId, 0, 0);
					
				}
			} 

		
		int tos_count_tJavaRow_4 = 0;
		
    	class BytesLimit65535_tJavaRow_4{
    		public void limitLog4jByte() throws Exception{
    			
    		}
    	}
    	
        new BytesLimit65535_tJavaRow_4().limitLog4jByte();

int nb_line_tJavaRow_4 = 0;

 



/**
 * [tJavaRow_4 begin ] stop
 */



	
	/**
	 * [tGreenplumInput_6 begin ] start
	 */

	

	
		
		ok_Hash.put("tGreenplumInput_6", false);
		start_Hash.put("tGreenplumInput_6", System.currentTimeMillis());
		
	
	currentComponent="tGreenplumInput_6";

	
		int tos_count_tGreenplumInput_6 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tGreenplumInput_6 - "  + ("Start to work.") );
    	class BytesLimit65535_tGreenplumInput_6{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tGreenplumInput_6 = new StringBuilder();
            log4jParamters_tGreenplumInput_6.append("Parameters:");
                    log4jParamters_tGreenplumInput_6.append("USE_EXISTING_CONNECTION" + " = " + "true");
                log4jParamters_tGreenplumInput_6.append(" | ");
                    log4jParamters_tGreenplumInput_6.append("CONNECTION" + " = " + "tGreenplumConnection_3");
                log4jParamters_tGreenplumInput_6.append(" | ");
                    log4jParamters_tGreenplumInput_6.append("TABLE" + " = " + "\"\"");
                log4jParamters_tGreenplumInput_6.append(" | ");
                    log4jParamters_tGreenplumInput_6.append("QUERYSTORE" + " = " + "\"\"");
                log4jParamters_tGreenplumInput_6.append(" | ");
                    log4jParamters_tGreenplumInput_6.append("QUERY" + " = " + "\"select NEXTVAL('sbdt.edl_run_id_seq')\"");
                log4jParamters_tGreenplumInput_6.append(" | ");
                    log4jParamters_tGreenplumInput_6.append("USE_CURSOR" + " = " + "false");
                log4jParamters_tGreenplumInput_6.append(" | ");
                    log4jParamters_tGreenplumInput_6.append("TRIM_ALL_COLUMN" + " = " + "false");
                log4jParamters_tGreenplumInput_6.append(" | ");
                    log4jParamters_tGreenplumInput_6.append("TRIM_COLUMN" + " = " + "[{TRIM="+("false")+", SCHEMA_COLUMN="+("run_id")+"}]");
                log4jParamters_tGreenplumInput_6.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tGreenplumInput_6 - "  + (log4jParamters_tGreenplumInput_6) );
    		}
    	}
    	
        new BytesLimit65535_tGreenplumInput_6().limitLog4jByte();
	
    
	
		    int nb_line_tGreenplumInput_6 = 0;
		    java.sql.Connection conn_tGreenplumInput_6 = null;
		        conn_tGreenplumInput_6 = (java.sql.Connection)globalMap.get("conn_tGreenplumConnection_3");
				
				if(conn_tGreenplumInput_6 != null) {
					if(conn_tGreenplumInput_6.getMetaData() != null) {
						
						log.debug("tGreenplumInput_6 - Uses an existing connection with username '" + conn_tGreenplumInput_6.getMetaData().getUserName() + "'. Connection URL: " + conn_tGreenplumInput_6.getMetaData().getURL() + ".");
						
					}
				}
			
		    
			java.sql.Statement stmt_tGreenplumInput_6 = conn_tGreenplumInput_6.createStatement();

		    String dbquery_tGreenplumInput_6 = "select NEXTVAL('sbdt.edl_run_id_seq')";
			
                log.debug("tGreenplumInput_6 - Executing the query: '"+dbquery_tGreenplumInput_6+"'.");
			

                       globalMap.put("tGreenplumInput_6_QUERY",dbquery_tGreenplumInput_6);

		    java.sql.ResultSet rs_tGreenplumInput_6 = null;
		try{
		    rs_tGreenplumInput_6 = stmt_tGreenplumInput_6.executeQuery(dbquery_tGreenplumInput_6);
		    java.sql.ResultSetMetaData rsmd_tGreenplumInput_6 = rs_tGreenplumInput_6.getMetaData();
		    int colQtyInRs_tGreenplumInput_6 = rsmd_tGreenplumInput_6.getColumnCount();

		    String tmpContent_tGreenplumInput_6 = null;
		    
		    
		    	log.debug("tGreenplumInput_6 - Retrieving records from the database.");
		    
		    while (rs_tGreenplumInput_6.next()) {
		        nb_line_tGreenplumInput_6++;
		        
							if(colQtyInRs_tGreenplumInput_6 < 1) {
								row12.run_id = null;
							} else {
		                          
            if(rs_tGreenplumInput_6.getObject(1) != null) {
                row12.run_id = rs_tGreenplumInput_6.getInt(1);
            } else {
                    row12.run_id = null;
            }
		                    }
					
						log.debug("tGreenplumInput_6 - Retrieving the record " + nb_line_tGreenplumInput_6 + ".");
					


 



/**
 * [tGreenplumInput_6 begin ] stop
 */
	
	/**
	 * [tGreenplumInput_6 main ] start
	 */

	

	
	
	currentComponent="tGreenplumInput_6";

	

 


	tos_count_tGreenplumInput_6++;

/**
 * [tGreenplumInput_6 main ] stop
 */

	
	/**
	 * [tJavaRow_4 main ] start
	 */

	

	
	
	currentComponent="tJavaRow_4";

	

			//row12
			//row12


			
				if(execStat){
					runStat.updateStatOnConnection("row12"+iterateId,1, 1);
				} 
			

		
    			if(log.isTraceEnabled()){
    				log.trace("row12 - " + (row12==null? "": row12.toLogString()));
    			}
    		

    context.LOG_RUN_ID=row12.run_id;
    nb_line_tJavaRow_4++;   

 


	tos_count_tJavaRow_4++;

/**
 * [tJavaRow_4 main ] stop
 */



	
	/**
	 * [tGreenplumInput_6 end ] start
	 */

	

	
	
	currentComponent="tGreenplumInput_6";

	

	}
}finally{
	stmt_tGreenplumInput_6.close();

}
globalMap.put("tGreenplumInput_6_NB_LINE",nb_line_tGreenplumInput_6);
	    		log.debug("tGreenplumInput_6 - Retrieved records count: "+nb_line_tGreenplumInput_6 + " .");
			

 
                if(log.isDebugEnabled())
            log.debug("tGreenplumInput_6 - "  + ("Done.") );

ok_Hash.put("tGreenplumInput_6", true);
end_Hash.put("tGreenplumInput_6", System.currentTimeMillis());




/**
 * [tGreenplumInput_6 end ] stop
 */

	
	/**
	 * [tJavaRow_4 end ] start
	 */

	

	
	
	currentComponent="tJavaRow_4";

	

globalMap.put("tJavaRow_4_NB_LINE",nb_line_tJavaRow_4);
			if(execStat){
				if(resourceMap.get("inIterateVComp") == null || !((Boolean)resourceMap.get("inIterateVComp"))){
			 		runStat.updateStatOnConnection("row12"+iterateId,2, 0); 
			 	}
			}
		
 

ok_Hash.put("tJavaRow_4", true);
end_Hash.put("tJavaRow_4", System.currentTimeMillis());

   			if (true
) {
   				
					if(execStat){   
   	 					runStat.updateStatOnConnection("If7", 0, "true");
					}
				
    			tJava_8Process(globalMap);
   			}

			   
   				else{
					if(execStat){   
   	 					runStat.updateStatOnConnection("If7", 0, "false");
					}   	 
   				}



/**
 * [tJavaRow_4 end ] stop
 */



				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage());
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tGreenplumInput_6 finally ] start
	 */

	

	
	
	currentComponent="tGreenplumInput_6";

	

 



/**
 * [tGreenplumInput_6 finally ] stop
 */

	
	/**
	 * [tJavaRow_4 finally ] start
	 */

	

	
	
	currentComponent="tJavaRow_4";

	

 



/**
 * [tJavaRow_4 finally ] stop
 */



				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tGreenplumInput_6_SUBPROCESS_STATE", 1);
	}
	

public void tJava_8Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tJava_8_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tJava_8 begin ] start
	 */

	

	
		
		ok_Hash.put("tJava_8", false);
		start_Hash.put("tJava_8", System.currentTimeMillis());
		
	
	currentComponent="tJava_8";

	
		int tos_count_tJava_8 = 0;
		
    	class BytesLimit65535_tJava_8{
    		public void limitLog4jByte() throws Exception{
    			
    		}
    	}
    	
        new BytesLimit65535_tJava_8().limitLog4jByte();


String strInsertLogSql = (String)globalMap.get("insert_log_sql");
strInsertLogSql=strInsertLogSql.replace("#RUN_ID", ((Integer)context.LOG_RUN_ID).toString());
globalMap.put("insert_log_sql",strInsertLogSql);

 



/**
 * [tJava_8 begin ] stop
 */
	
	/**
	 * [tJava_8 main ] start
	 */

	

	
	
	currentComponent="tJava_8";

	

 


	tos_count_tJava_8++;

/**
 * [tJava_8 main ] stop
 */
	
	/**
	 * [tJava_8 end ] start
	 */

	

	
	
	currentComponent="tJava_8";

	

 

ok_Hash.put("tJava_8", true);
end_Hash.put("tJava_8", System.currentTimeMillis());




/**
 * [tJava_8 end ] stop
 */
				}//end the resume

				
				    			if(resumeEntryMethodName == null || globalResumeTicket){
				    				resumeUtil.addLog("CHECKPOINT", "CONNECTION:SUBJOB_OK:tJava_8:OnSubjobOk", "", Thread.currentThread().getId() + "", "", "", "", "", "");
								}	    				    			
					    	
								if(execStat){    	
									runStat.updateStatOnConnection("OnSubjobOk20", 0, "ok");
								} 
							
							tGreenplumRow_2Process(globalMap); 
						



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage());
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tJava_8 finally ] start
	 */

	

	
	
	currentComponent="tJava_8";

	

 



/**
 * [tJava_8 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tJava_8_SUBPROCESS_STATE", 1);
	}
	

public void tGreenplumRow_2Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tGreenplumRow_2_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tGreenplumRow_2 begin ] start
	 */

	

	
		
		ok_Hash.put("tGreenplumRow_2", false);
		start_Hash.put("tGreenplumRow_2", System.currentTimeMillis());
		
	
	currentComponent="tGreenplumRow_2";

	
		int tos_count_tGreenplumRow_2 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tGreenplumRow_2 - "  + ("Start to work.") );
    	class BytesLimit65535_tGreenplumRow_2{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tGreenplumRow_2 = new StringBuilder();
            log4jParamters_tGreenplumRow_2.append("Parameters:");
                    log4jParamters_tGreenplumRow_2.append("USE_EXISTING_CONNECTION" + " = " + "true");
                log4jParamters_tGreenplumRow_2.append(" | ");
                    log4jParamters_tGreenplumRow_2.append("CONNECTION" + " = " + "tGreenplumConnection_3");
                log4jParamters_tGreenplumRow_2.append(" | ");
                    log4jParamters_tGreenplumRow_2.append("QUERYSTORE" + " = " + "\"\"");
                log4jParamters_tGreenplumRow_2.append(" | ");
                    log4jParamters_tGreenplumRow_2.append("QUERY" + " = " + "(String)globalMap.get(\"insert_log_sql\")");
                log4jParamters_tGreenplumRow_2.append(" | ");
                    log4jParamters_tGreenplumRow_2.append("DIE_ON_ERROR" + " = " + "true");
                log4jParamters_tGreenplumRow_2.append(" | ");
                    log4jParamters_tGreenplumRow_2.append("PROPAGATE_RECORD_SET" + " = " + "false");
                log4jParamters_tGreenplumRow_2.append(" | ");
                    log4jParamters_tGreenplumRow_2.append("USE_PREPAREDSTATEMENT" + " = " + "false");
                log4jParamters_tGreenplumRow_2.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tGreenplumRow_2 - "  + (log4jParamters_tGreenplumRow_2) );
    		}
    	}
    	
        new BytesLimit65535_tGreenplumRow_2().limitLog4jByte();

	java.sql.Connection conn_tGreenplumRow_2 = null;
	String query_tGreenplumRow_2 = "";
	boolean whetherReject_tGreenplumRow_2 = false;
				conn_tGreenplumRow_2 = (java.sql.Connection)globalMap.get("conn_tGreenplumConnection_3");
			
				if(conn_tGreenplumRow_2 != null) {
					if(conn_tGreenplumRow_2.getMetaData() != null) {
						
						log.debug("tGreenplumRow_2 - Uses an existing connection with username '" + conn_tGreenplumRow_2.getMetaData().getUserName() + "'. Connection URL: " + conn_tGreenplumRow_2.getMetaData().getURL() + ".");
						
					}
				}
			
		java.sql.Statement stmt_tGreenplumRow_2 = conn_tGreenplumRow_2.createStatement();
	

 



/**
 * [tGreenplumRow_2 begin ] stop
 */
	
	/**
	 * [tGreenplumRow_2 main ] start
	 */

	

	
	
	currentComponent="tGreenplumRow_2";

	

	    		log.debug("tGreenplumRow_2 - Executing the query: '" + (String)globalMap.get("insert_log_sql") + "'.");
			
query_tGreenplumRow_2 = (String)globalMap.get("insert_log_sql");
whetherReject_tGreenplumRow_2 = false;
globalMap.put("tGreenplumRow_2_QUERY",query_tGreenplumRow_2);
try {
		stmt_tGreenplumRow_2.execute(query_tGreenplumRow_2);
		
	    		log.info("tGreenplumRow_2 - Execute the query: '" + (String)globalMap.get("insert_log_sql") + "' has finished.");
			
	} catch (java.lang.Exception e) {
		whetherReject_tGreenplumRow_2 = true;
		
			throw(e);
			
	}
	
	if(!whetherReject_tGreenplumRow_2) {
		
	}
	

 


	tos_count_tGreenplumRow_2++;

/**
 * [tGreenplumRow_2 main ] stop
 */
	
	/**
	 * [tGreenplumRow_2 end ] start
	 */

	

	
	
	currentComponent="tGreenplumRow_2";

	

	
	stmt_tGreenplumRow_2.close();	

 
                if(log.isDebugEnabled())
            log.debug("tGreenplumRow_2 - "  + ("Done.") );

ok_Hash.put("tGreenplumRow_2", true);
end_Hash.put("tGreenplumRow_2", System.currentTimeMillis());




/**
 * [tGreenplumRow_2 end ] stop
 */
				}//end the resume

				
				    			if(resumeEntryMethodName == null || globalResumeTicket){
				    				resumeUtil.addLog("CHECKPOINT", "CONNECTION:SUBJOB_OK:tGreenplumRow_2:OnSubjobOk", "", Thread.currentThread().getId() + "", "", "", "", "", "");
								}	    				    			
					    	
								if(execStat){    	
									runStat.updateStatOnConnection("OnSubjobOk21", 0, "ok");
								} 
							
							tGreenplumClose_3Process(globalMap); 
						



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage());
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tGreenplumRow_2 finally ] start
	 */

	

	
	
	currentComponent="tGreenplumRow_2";

	

 



/**
 * [tGreenplumRow_2 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tGreenplumRow_2_SUBPROCESS_STATE", 1);
	}
	

public void tGreenplumClose_3Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tGreenplumClose_3_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;





	
	/**
	 * [tGreenplumClose_3 begin ] start
	 */

	

	
		
		ok_Hash.put("tGreenplumClose_3", false);
		start_Hash.put("tGreenplumClose_3", System.currentTimeMillis());
		
	
	currentComponent="tGreenplumClose_3";

	
		int tos_count_tGreenplumClose_3 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tGreenplumClose_3 - "  + ("Start to work.") );
    	class BytesLimit65535_tGreenplumClose_3{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tGreenplumClose_3 = new StringBuilder();
            log4jParamters_tGreenplumClose_3.append("Parameters:");
                    log4jParamters_tGreenplumClose_3.append("CONNECTION" + " = " + "tGreenplumConnection_3");
                log4jParamters_tGreenplumClose_3.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tGreenplumClose_3 - "  + (log4jParamters_tGreenplumClose_3) );
    		}
    	}
    	
        new BytesLimit65535_tGreenplumClose_3().limitLog4jByte();

 



/**
 * [tGreenplumClose_3 begin ] stop
 */
	
	/**
	 * [tGreenplumClose_3 main ] start
	 */

	

	
	
	currentComponent="tGreenplumClose_3";

	



	java.sql.Connection conn_tGreenplumClose_3 = (java.sql.Connection)globalMap.get("conn_tGreenplumConnection_3");
	if(conn_tGreenplumClose_3 != null && !conn_tGreenplumClose_3.isClosed())
	{
                if(log.isDebugEnabled())
            log.debug("tGreenplumClose_3 - "  + ("Closing the connection ")  + ("conn_tGreenplumConnection_3")  + (" to the database.") );
        conn_tGreenplumClose_3.close();
                if(log.isDebugEnabled())
            log.debug("tGreenplumClose_3 - "  + ("Connection ")  + ("conn_tGreenplumConnection_3")  + (" to the database has closed.") );
	}

 


	tos_count_tGreenplumClose_3++;

/**
 * [tGreenplumClose_3 main ] stop
 */
	
	/**
	 * [tGreenplumClose_3 end ] start
	 */

	

	
	
	currentComponent="tGreenplumClose_3";

	

 
                if(log.isDebugEnabled())
            log.debug("tGreenplumClose_3 - "  + ("Done.") );

ok_Hash.put("tGreenplumClose_3", true);
end_Hash.put("tGreenplumClose_3", System.currentTimeMillis());




/**
 * [tGreenplumClose_3 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage());
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tGreenplumClose_3 finally ] start
	 */

	

	
	
	currentComponent="tGreenplumClose_3";

	

 



/**
 * [tGreenplumClose_3 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tGreenplumClose_3_SUBPROCESS_STATE", 1);
	}
	

public void tJava_10Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tJava_10_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tJava_10 begin ] start
	 */

	

	
		
		ok_Hash.put("tJava_10", false);
		start_Hash.put("tJava_10", System.currentTimeMillis());
		
	
	currentComponent="tJava_10";

	
		int tos_count_tJava_10 = 0;
		
    	class BytesLimit65535_tJava_10{
    		public void limitLog4jByte() throws Exception{
    			
    		}
    	}
    	
        new BytesLimit65535_tJava_10().limitLog4jByte();


//context.LOG_PLANT_NAME="NULL";
//context.LOG_SYSTEM_NAME="NULL";
//context.LOG_TABLE_NAME="NULL";
//context.LOG_JOB_NAME="NULL";
//context.LOG_DATA_PATH="NULL";
//context.LOG_TECHNOLOGY="NULL";
context.LOG_STATUS="Finish";
context.LOG_MESSAGE="NULL";
context.LOG_ERROR_CATEGORY="NULL";
context.LOG_NO_OF_INSERTS=0;
context.LOG_NO_OF_UPDATES=0;
context.LOG_NO_OF_DELETES=0;
context.LOG_NO_OF_ERRORS=0;
context.LOG_SOURCE_ROW_COUNT=0;
context.LOG_TARGET_ROW_COUNT=0;

 



/**
 * [tJava_10 begin ] stop
 */
	
	/**
	 * [tJava_10 main ] start
	 */

	

	
	
	currentComponent="tJava_10";

	

 


	tos_count_tJava_10++;

/**
 * [tJava_10 main ] stop
 */
	
	/**
	 * [tJava_10 end ] start
	 */

	

	
	
	currentComponent="tJava_10";

	

 

ok_Hash.put("tJava_10", true);
end_Hash.put("tJava_10", System.currentTimeMillis());




/**
 * [tJava_10 end ] stop
 */
				}//end the resume

				
				    			if(resumeEntryMethodName == null || globalResumeTicket){
				    				resumeUtil.addLog("CHECKPOINT", "CONNECTION:SUBJOB_OK:tJava_10:OnSubjobOk", "", Thread.currentThread().getId() + "", "", "", "", "", "");
								}	    				    			
					    	
								if(execStat){    	
									runStat.updateStatOnConnection("OnSubjobOk27", 0, "ok");
								} 
							
							tJava_9Process(globalMap); 
						



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage());
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tJava_10 finally ] start
	 */

	

	
	
	currentComponent="tJava_10";

	

 



/**
 * [tJava_10 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tJava_10_SUBPROCESS_STATE", 1);
	}
	

public void tJava_9Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tJava_9_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tJava_9 begin ] start
	 */

	

	
		
		ok_Hash.put("tJava_9", false);
		start_Hash.put("tJava_9", System.currentTimeMillis());
		
	
	currentComponent="tJava_9";

	
		int tos_count_tJava_9 = 0;
		
    	class BytesLimit65535_tJava_9{
    		public void limitLog4jByte() throws Exception{
    			
    		}
    	}
    	
        new BytesLimit65535_tJava_9().limitLog4jByte();



String strInsertLogSql=(String)globalMap.get("insert_log_template");
strInsertLogSql=strInsertLogSql.replace("#RUN_ID", ((Integer)context.LOG_RUN_ID).toString());
strInsertLogSql=strInsertLogSql.replace("#PLANT_NAME", "'"+context.LOG_PLANT_NAME+"'");
strInsertLogSql=strInsertLogSql.replace("#SYSTEM_NAME", "'"+context.LOG_SYSTEM_NAME+"'");
strInsertLogSql=strInsertLogSql.replace("#JOB_NAME", "'"+((String)globalMap.get("jobname_prefix"))+context.LOG_JOB_NAME+"'");
strInsertLogSql=strInsertLogSql.replace("#TABLE_NAME", "'"+(String)globalMap.get("orig_table_name")+"'");
strInsertLogSql=strInsertLogSql.replace("#STATUS", "'"+context.LOG_STATUS+"'");
strInsertLogSql=strInsertLogSql.replace("#DATA_PATH", "'"+context.LOG_DATA_PATH+"'");
strInsertLogSql=strInsertLogSql.replace("#TECHNOLOGY", "'"+context.LOG_TECHNOLOGY+"'");
strInsertLogSql=strInsertLogSql.replace("#NO_OF_INSERTS", ((Integer)context.LOG_NO_OF_INSERTS).toString());
strInsertLogSql=strInsertLogSql.replace("#NO_OF_UPDATES", ((Integer)context.LOG_NO_OF_UPDATES).toString());
strInsertLogSql=strInsertLogSql.replace("#NO_OF_DELETES", ((Integer)context.LOG_NO_OF_DELETES).toString());
strInsertLogSql=strInsertLogSql.replace("#NO_OF_ERRORS", ((Integer)context.LOG_NO_OF_ERRORS).toString());
strInsertLogSql=strInsertLogSql.replace("#MESSAGE", "'"+context.LOG_MESSAGE+"'");
strInsertLogSql=strInsertLogSql.replace("#SOURCE_ROW_COUNT", ((Integer)context.LOG_SOURCE_ROW_COUNT).toString());
strInsertLogSql=strInsertLogSql.replace("#TARGET_ROW_COUNT", ((Integer)context.LOG_TARGET_ROW_COUNT).toString());
strInsertLogSql=strInsertLogSql.replace("#ERROR_CATEGORY", "'"+context.LOG_ERROR_CATEGORY+"'");
globalMap.put("insert_log_sql",strInsertLogSql);
//System.out.println(globalMap.get("insert_log_sql"));
//System.out.println("==============================");
//System.out.println("==============================");
//globalMap.put("now",new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(TalendDate.getCurrentDate()).toString());
//System.out.println(globalMap.get("now"));
//globalMap.put("now_sql","TO_TIMESTAMP('" + ((String)globalMap.get("now")) + "', 'YYYY-MM-DD HH24:MI:SS')::TIMESTAMP WITH TIME ZONE ");
//System.out.println(globalMap.get("now_sql"));
//if (context.LOG_PLANT_NAME.equals("NULL")==true) {
//  context.LOG_PLANT_NAME="Grove City";
//};
//if (context.LOG_APPLICATION.equals("NULL")==true) {
//  context.LOG_APPLICATION="GET-ABM";
//};
 



/**
 * [tJava_9 begin ] stop
 */
	
	/**
	 * [tJava_9 main ] start
	 */

	

	
	
	currentComponent="tJava_9";

	

 


	tos_count_tJava_9++;

/**
 * [tJava_9 main ] stop
 */
	
	/**
	 * [tJava_9 end ] start
	 */

	

	
	
	currentComponent="tJava_9";

	

 

ok_Hash.put("tJava_9", true);
end_Hash.put("tJava_9", System.currentTimeMillis());

				if(execStat){   
   	 				runStat.updateStatOnConnection("OnComponentOk2", 0, "ok");
				}
				tGreenplumConnection_3Process(globalMap);



/**
 * [tJava_9 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage());
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tJava_9 finally ] start
	 */

	

	
	
	currentComponent="tJava_9";

	

 



/**
 * [tJava_9 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tJava_9_SUBPROCESS_STATE", 1);
	}
	

public void tGreenplumConnection_6Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tGreenplumConnection_6_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tGreenplumConnection_6 begin ] start
	 */

	

	
		
		ok_Hash.put("tGreenplumConnection_6", false);
		start_Hash.put("tGreenplumConnection_6", System.currentTimeMillis());
		
	
	currentComponent="tGreenplumConnection_6";

	
		int tos_count_tGreenplumConnection_6 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tGreenplumConnection_6 - "  + ("Start to work.") );
    	class BytesLimit65535_tGreenplumConnection_6{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tGreenplumConnection_6 = new StringBuilder();
            log4jParamters_tGreenplumConnection_6.append("Parameters:");
                    log4jParamters_tGreenplumConnection_6.append("HOST" + " = " + "context.SOURCING_Server");
                log4jParamters_tGreenplumConnection_6.append(" | ");
                    log4jParamters_tGreenplumConnection_6.append("PORT" + " = " + "context.SOURCING_Port");
                log4jParamters_tGreenplumConnection_6.append(" | ");
                    log4jParamters_tGreenplumConnection_6.append("DBNAME" + " = " + "context.SOURCING_Database");
                log4jParamters_tGreenplumConnection_6.append(" | ");
                    log4jParamters_tGreenplumConnection_6.append("SCHEMA_DB" + " = " + "context.SOURCING_Schema");
                log4jParamters_tGreenplumConnection_6.append(" | ");
                    log4jParamters_tGreenplumConnection_6.append("USER" + " = " + "context.SOURCING_Login");
                log4jParamters_tGreenplumConnection_6.append(" | ");
                    log4jParamters_tGreenplumConnection_6.append("PASS" + " = " + String.valueOf(routines.system.PasswordEncryptUtil.encryptPassword(context.SOURCING_Password)).substring(0, 4) + "...");     
                log4jParamters_tGreenplumConnection_6.append(" | ");
                    log4jParamters_tGreenplumConnection_6.append("USE_SHARED_CONNECTION" + " = " + "true");
                log4jParamters_tGreenplumConnection_6.append(" | ");
                    log4jParamters_tGreenplumConnection_6.append("SHARED_CONNECTION_NAME" + " = " + "\"base_dynamic\"+((String)globalMap.get(\"timestamp\"))");
                log4jParamters_tGreenplumConnection_6.append(" | ");
                    log4jParamters_tGreenplumConnection_6.append("USE_SSL" + " = " + "true");
                log4jParamters_tGreenplumConnection_6.append(" | ");
                    log4jParamters_tGreenplumConnection_6.append("AUTO_COMMIT" + " = " + "true");
                log4jParamters_tGreenplumConnection_6.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tGreenplumConnection_6 - "  + (log4jParamters_tGreenplumConnection_6) );
    		}
    	}
    	
        new BytesLimit65535_tGreenplumConnection_6().limitLog4jByte();
	

	
				String url_tGreenplumConnection_6 = "jdbc:postgresql://"+context.SOURCING_Server+":"+context.SOURCING_Port+"/"+context.SOURCING_Database+"?ssl=true&sslfactory=org.postgresql.ssl.NonValidatingFactory";

	String dbUser_tGreenplumConnection_6 = context.SOURCING_Login;
	
	
		
	final String decryptedPassword_tGreenplumConnection_6 = context.SOURCING_Password; 
		String dbPwd_tGreenplumConnection_6 = decryptedPassword_tGreenplumConnection_6;
	

	java.sql.Connection conn_tGreenplumConnection_6 = null;
	
	
			SharedDBConnectionLog4j.initLogger(log,"tGreenplumConnection_6");
			String sharedConnectionName_tGreenplumConnection_6 = "base_dynamic"+((String)globalMap.get("timestamp"));
			conn_tGreenplumConnection_6 = SharedDBConnectionLog4j.getDBConnection("org.postgresql.Driver",url_tGreenplumConnection_6,dbUser_tGreenplumConnection_6 , dbPwd_tGreenplumConnection_6 , sharedConnectionName_tGreenplumConnection_6);
	if (null != conn_tGreenplumConnection_6) {
		
			log.debug("tGreenplumConnection_6 - Connection is set auto commit to 'true'.");
			conn_tGreenplumConnection_6.setAutoCommit(true);
	}

	globalMap.put("schema_" + "tGreenplumConnection_6",context.SOURCING_Schema);

	globalMap.put("conn_" + "tGreenplumConnection_6",conn_tGreenplumConnection_6);
 



/**
 * [tGreenplumConnection_6 begin ] stop
 */
	
	/**
	 * [tGreenplumConnection_6 main ] start
	 */

	

	
	
	currentComponent="tGreenplumConnection_6";

	

 


	tos_count_tGreenplumConnection_6++;

/**
 * [tGreenplumConnection_6 main ] stop
 */
	
	/**
	 * [tGreenplumConnection_6 end ] start
	 */

	

	
	
	currentComponent="tGreenplumConnection_6";

	

 
                if(log.isDebugEnabled())
            log.debug("tGreenplumConnection_6 - "  + ("Done.") );

ok_Hash.put("tGreenplumConnection_6", true);
end_Hash.put("tGreenplumConnection_6", System.currentTimeMillis());




/**
 * [tGreenplumConnection_6 end ] stop
 */
				}//end the resume

				
				    			if(resumeEntryMethodName == null || globalResumeTicket){
				    				resumeUtil.addLog("CHECKPOINT", "CONNECTION:SUBJOB_OK:tGreenplumConnection_6:OnSubjobOk", "", Thread.currentThread().getId() + "", "", "", "", "", "");
								}	    				    			
					    	
								if(execStat){    	
									runStat.updateStatOnConnection("OnSubjobOk37", 0, "ok");
								} 
							
							tGreenplumInput_10Process(globalMap); 
						



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage());
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tGreenplumConnection_6 finally ] start
	 */

	

	
	
	currentComponent="tGreenplumConnection_6";

	

 



/**
 * [tGreenplumConnection_6 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tGreenplumConnection_6_SUBPROCESS_STATE", 1);
	}
	


public static class row11Struct implements routines.system.IPersistableRow<row11Struct> {
    final static byte[] commonByteArrayLock_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Base_dynamic = new byte[0];
    static byte[] commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Base_dynamic = new byte[0];

	
			    public String target_schema_priv;

				public String getTarget_schema_priv () {
					return this.target_schema_priv;
				}
				



	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Base_dynamic.length) {
				if(length < 1024 && commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Base_dynamic.length == 0) {
   					commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Base_dynamic = new byte[1024];
				} else {
   					commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Base_dynamic = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Base_dynamic, 0, length);
			strReturn = new String(commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Base_dynamic, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Base_dynamic) {

        	try {

        		int length = 0;
		
					this.target_schema_priv = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// String
				
						writeString(this.target_schema_priv,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("target_schema_priv="+target_schema_priv);
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				if(target_schema_priv == null){
        					sb.append("<null>");
        				}else{
            				sb.append(target_schema_priv);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(row11Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}
public void tGreenplumInput_10Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tGreenplumInput_10_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;



		row11Struct row11 = new row11Struct();




	
	/**
	 * [tFlowToIterate_2 begin ] start
	 */

				
			int NB_ITERATE_tGreenplumRow_4 = 0; //for statistics
			

	
		
		ok_Hash.put("tFlowToIterate_2", false);
		start_Hash.put("tFlowToIterate_2", System.currentTimeMillis());
		
	
	currentComponent="tFlowToIterate_2";

	
			if (execStat) {
				if(resourceMap.get("inIterateVComp") == null){
					
						runStat.updateStatOnConnection("row11" + iterateId, 0, 0);
					
				}
			} 

		
		int tos_count_tFlowToIterate_2 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tFlowToIterate_2 - "  + ("Start to work.") );
    	class BytesLimit65535_tFlowToIterate_2{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tFlowToIterate_2 = new StringBuilder();
            log4jParamters_tFlowToIterate_2.append("Parameters:");
                    log4jParamters_tFlowToIterate_2.append("DEFAULT_MAP" + " = " + "true");
                log4jParamters_tFlowToIterate_2.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tFlowToIterate_2 - "  + (log4jParamters_tFlowToIterate_2) );
    		}
    	}
    	
        new BytesLimit65535_tFlowToIterate_2().limitLog4jByte();

int nb_line_tFlowToIterate_2 = 0;
int counter_tFlowToIterate_2 = 0;

 



/**
 * [tFlowToIterate_2 begin ] stop
 */



	
	/**
	 * [tGreenplumInput_10 begin ] start
	 */

	

	
		
		ok_Hash.put("tGreenplumInput_10", false);
		start_Hash.put("tGreenplumInput_10", System.currentTimeMillis());
		
	
	currentComponent="tGreenplumInput_10";

	
		int tos_count_tGreenplumInput_10 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tGreenplumInput_10 - "  + ("Start to work.") );
    	class BytesLimit65535_tGreenplumInput_10{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tGreenplumInput_10 = new StringBuilder();
            log4jParamters_tGreenplumInput_10.append("Parameters:");
                    log4jParamters_tGreenplumInput_10.append("USE_EXISTING_CONNECTION" + " = " + "true");
                log4jParamters_tGreenplumInput_10.append(" | ");
                    log4jParamters_tGreenplumInput_10.append("CONNECTION" + " = " + "tGreenplumConnection_6");
                log4jParamters_tGreenplumInput_10.append(" | ");
                    log4jParamters_tGreenplumInput_10.append("TABLE" + " = " + "\"\"");
                log4jParamters_tGreenplumInput_10.append(" | ");
                    log4jParamters_tGreenplumInput_10.append("QUERYSTORE" + " = " + "\"\"");
                log4jParamters_tGreenplumInput_10.append(" | ");
                    log4jParamters_tGreenplumInput_10.append("QUERY" + " = " + "\"select distinct t.target_schema target_schema_priv from sbdt.edl_table t  where lower(t.system_name) = lower( '\" + (String)globalMap.get(\"system_name\") + \"') \"");
                log4jParamters_tGreenplumInput_10.append(" | ");
                    log4jParamters_tGreenplumInput_10.append("USE_CURSOR" + " = " + "false");
                log4jParamters_tGreenplumInput_10.append(" | ");
                    log4jParamters_tGreenplumInput_10.append("TRIM_ALL_COLUMN" + " = " + "false");
                log4jParamters_tGreenplumInput_10.append(" | ");
                    log4jParamters_tGreenplumInput_10.append("TRIM_COLUMN" + " = " + "[{TRIM="+("false")+", SCHEMA_COLUMN="+("target_schema_priv")+"}]");
                log4jParamters_tGreenplumInput_10.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tGreenplumInput_10 - "  + (log4jParamters_tGreenplumInput_10) );
    		}
    	}
    	
        new BytesLimit65535_tGreenplumInput_10().limitLog4jByte();
	
    
	
		    int nb_line_tGreenplumInput_10 = 0;
		    java.sql.Connection conn_tGreenplumInput_10 = null;
		        conn_tGreenplumInput_10 = (java.sql.Connection)globalMap.get("conn_tGreenplumConnection_6");
				
				if(conn_tGreenplumInput_10 != null) {
					if(conn_tGreenplumInput_10.getMetaData() != null) {
						
						log.debug("tGreenplumInput_10 - Uses an existing connection with username '" + conn_tGreenplumInput_10.getMetaData().getUserName() + "'. Connection URL: " + conn_tGreenplumInput_10.getMetaData().getURL() + ".");
						
					}
				}
			
		    
			java.sql.Statement stmt_tGreenplumInput_10 = conn_tGreenplumInput_10.createStatement();

		    String dbquery_tGreenplumInput_10 = "select distinct t.target_schema target_schema_priv from sbdt.edl_table t\nwhere lower(t.system_name) = lower( '" + (String)globalMap.get("system_name") + "') ";
			
                log.debug("tGreenplumInput_10 - Executing the query: '"+dbquery_tGreenplumInput_10+"'.");
			

                       globalMap.put("tGreenplumInput_10_QUERY",dbquery_tGreenplumInput_10);

		    java.sql.ResultSet rs_tGreenplumInput_10 = null;
		try{
		    rs_tGreenplumInput_10 = stmt_tGreenplumInput_10.executeQuery(dbquery_tGreenplumInput_10);
		    java.sql.ResultSetMetaData rsmd_tGreenplumInput_10 = rs_tGreenplumInput_10.getMetaData();
		    int colQtyInRs_tGreenplumInput_10 = rsmd_tGreenplumInput_10.getColumnCount();

		    String tmpContent_tGreenplumInput_10 = null;
		    
		    
		    	log.debug("tGreenplumInput_10 - Retrieving records from the database.");
		    
		    while (rs_tGreenplumInput_10.next()) {
		        nb_line_tGreenplumInput_10++;
		        
							if(colQtyInRs_tGreenplumInput_10 < 1) {
								row11.target_schema_priv = null;
							} else {
	                         		
        	row11.target_schema_priv = routines.system.JDBCUtil.getString(rs_tGreenplumInput_10, 1, false);
		                    }
					
						log.debug("tGreenplumInput_10 - Retrieving the record " + nb_line_tGreenplumInput_10 + ".");
					


 



/**
 * [tGreenplumInput_10 begin ] stop
 */
	
	/**
	 * [tGreenplumInput_10 main ] start
	 */

	

	
	
	currentComponent="tGreenplumInput_10";

	

 


	tos_count_tGreenplumInput_10++;

/**
 * [tGreenplumInput_10 main ] stop
 */

	
	/**
	 * [tFlowToIterate_2 main ] start
	 */

	

	
	
	currentComponent="tFlowToIterate_2";

	

			//row11
			//row11


			
				if(execStat){
					runStat.updateStatOnConnection("row11"+iterateId,1, 1);
				} 
			

		
    			if(log.isTraceEnabled()){
    				log.trace("row11 - " + (row11==null? "": row11.toLogString()));
    			}
    		


    	
                if(log.isTraceEnabled())
            log.trace("tFlowToIterate_2 - "  + ("Set global var, key=row11.target_schema_priv, value=")  + (row11.target_schema_priv)  + (".") );            
            globalMap.put("row11.target_schema_priv", row11.target_schema_priv);
    	
 
	   nb_line_tFlowToIterate_2++;  
       counter_tFlowToIterate_2++;
                if(log.isDebugEnabled())
            log.debug("tFlowToIterate_2 - "  + ("Current iteration is: ")  + (counter_tFlowToIterate_2)  + (".") );
       globalMap.put("tFlowToIterate_2_CURRENT_ITERATION", counter_tFlowToIterate_2);
 


	tos_count_tFlowToIterate_2++;

/**
 * [tFlowToIterate_2 main ] stop
 */
	NB_ITERATE_tGreenplumRow_4++;
	
	
				if(execStat){
					runStat.updateStatOnConnection("iterate2", 1, "exec" + NB_ITERATE_tGreenplumRow_4);
					//Thread.sleep(1000);
				}				
			

	
	/**
	 * [tGreenplumRow_4 begin ] start
	 */

	

	
		
		ok_Hash.put("tGreenplumRow_4", false);
		start_Hash.put("tGreenplumRow_4", System.currentTimeMillis());
		
	
	currentComponent="tGreenplumRow_4";

	
		int tos_count_tGreenplumRow_4 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tGreenplumRow_4 - "  + ("Start to work.") );
    	class BytesLimit65535_tGreenplumRow_4{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tGreenplumRow_4 = new StringBuilder();
            log4jParamters_tGreenplumRow_4.append("Parameters:");
                    log4jParamters_tGreenplumRow_4.append("USE_EXISTING_CONNECTION" + " = " + "true");
                log4jParamters_tGreenplumRow_4.append(" | ");
                    log4jParamters_tGreenplumRow_4.append("CONNECTION" + " = " + "tGreenplumConnection_6");
                log4jParamters_tGreenplumRow_4.append(" | ");
                    log4jParamters_tGreenplumRow_4.append("QUERYSTORE" + " = " + "\"\"");
                log4jParamters_tGreenplumRow_4.append(" | ");
                    log4jParamters_tGreenplumRow_4.append("QUERY" + " = " + "\"SELECT sbdt.set_privileges_by_schema (  '\"+ (String)globalMap.get(\"row11.target_schema_priv\") +\"' );\" ");
                log4jParamters_tGreenplumRow_4.append(" | ");
                    log4jParamters_tGreenplumRow_4.append("DIE_ON_ERROR" + " = " + "true");
                log4jParamters_tGreenplumRow_4.append(" | ");
                    log4jParamters_tGreenplumRow_4.append("PROPAGATE_RECORD_SET" + " = " + "false");
                log4jParamters_tGreenplumRow_4.append(" | ");
                    log4jParamters_tGreenplumRow_4.append("USE_PREPAREDSTATEMENT" + " = " + "false");
                log4jParamters_tGreenplumRow_4.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tGreenplumRow_4 - "  + (log4jParamters_tGreenplumRow_4) );
    		}
    	}
    	
        new BytesLimit65535_tGreenplumRow_4().limitLog4jByte();

	java.sql.Connection conn_tGreenplumRow_4 = null;
	String query_tGreenplumRow_4 = "";
	boolean whetherReject_tGreenplumRow_4 = false;
				conn_tGreenplumRow_4 = (java.sql.Connection)globalMap.get("conn_tGreenplumConnection_6");
			
				if(conn_tGreenplumRow_4 != null) {
					if(conn_tGreenplumRow_4.getMetaData() != null) {
						
						log.debug("tGreenplumRow_4 - Uses an existing connection with username '" + conn_tGreenplumRow_4.getMetaData().getUserName() + "'. Connection URL: " + conn_tGreenplumRow_4.getMetaData().getURL() + ".");
						
					}
				}
			
		java.sql.Statement stmt_tGreenplumRow_4 = conn_tGreenplumRow_4.createStatement();
	

 



/**
 * [tGreenplumRow_4 begin ] stop
 */
	
	/**
	 * [tGreenplumRow_4 main ] start
	 */

	

	
	
	currentComponent="tGreenplumRow_4";

	

	    		log.debug("tGreenplumRow_4 - Executing the query: '" + "SELECT sbdt.set_privileges_by_schema (  '"+ (String)globalMap.get("row11.target_schema_priv") +"' );"  + "'.");
			
query_tGreenplumRow_4 = "SELECT sbdt.set_privileges_by_schema (  '"+ (String)globalMap.get("row11.target_schema_priv") +"' );" ;
whetherReject_tGreenplumRow_4 = false;
globalMap.put("tGreenplumRow_4_QUERY",query_tGreenplumRow_4);
try {
		stmt_tGreenplumRow_4.execute(query_tGreenplumRow_4);
		
	    		log.info("tGreenplumRow_4 - Execute the query: '" + "SELECT sbdt.set_privileges_by_schema (  '"+ (String)globalMap.get("row11.target_schema_priv") +"' );"  + "' has finished.");
			
	} catch (java.lang.Exception e) {
		whetherReject_tGreenplumRow_4 = true;
		
			throw(e);
			
	}
	

 


	tos_count_tGreenplumRow_4++;

/**
 * [tGreenplumRow_4 main ] stop
 */
	
	/**
	 * [tGreenplumRow_4 end ] start
	 */

	

	
	
	currentComponent="tGreenplumRow_4";

	

	
	stmt_tGreenplumRow_4.close();	

 
                if(log.isDebugEnabled())
            log.debug("tGreenplumRow_4 - "  + ("Done.") );

ok_Hash.put("tGreenplumRow_4", true);
end_Hash.put("tGreenplumRow_4", System.currentTimeMillis());




/**
 * [tGreenplumRow_4 end ] stop
 */
						if(execStat){
							runStat.updateStatOnConnection("iterate2", 2, "exec" + NB_ITERATE_tGreenplumRow_4);
						}				
					







	
	/**
	 * [tGreenplumInput_10 end ] start
	 */

	

	
	
	currentComponent="tGreenplumInput_10";

	

	}
}finally{
	stmt_tGreenplumInput_10.close();

}
globalMap.put("tGreenplumInput_10_NB_LINE",nb_line_tGreenplumInput_10);
	    		log.debug("tGreenplumInput_10 - Retrieved records count: "+nb_line_tGreenplumInput_10 + " .");
			

 
                if(log.isDebugEnabled())
            log.debug("tGreenplumInput_10 - "  + ("Done.") );

ok_Hash.put("tGreenplumInput_10", true);
end_Hash.put("tGreenplumInput_10", System.currentTimeMillis());




/**
 * [tGreenplumInput_10 end ] stop
 */

	
	/**
	 * [tFlowToIterate_2 end ] start
	 */

	

	
	
	currentComponent="tFlowToIterate_2";

	

globalMap.put("tFlowToIterate_2_NB_LINE",nb_line_tFlowToIterate_2);
			if(execStat){
				if(resourceMap.get("inIterateVComp") == null || !((Boolean)resourceMap.get("inIterateVComp"))){
			 		runStat.updateStatOnConnection("row11"+iterateId,2, 0); 
			 	}
			}
		
 
                if(log.isDebugEnabled())
            log.debug("tFlowToIterate_2 - "  + ("Done.") );

ok_Hash.put("tFlowToIterate_2", true);
end_Hash.put("tFlowToIterate_2", System.currentTimeMillis());




/**
 * [tFlowToIterate_2 end ] stop
 */



				}//end the resume

				
				    			if(resumeEntryMethodName == null || globalResumeTicket){
				    				resumeUtil.addLog("CHECKPOINT", "CONNECTION:SUBJOB_OK:tGreenplumInput_10:OnSubjobOk", "", Thread.currentThread().getId() + "", "", "", "", "", "");
								}	    				    			
					    	
								if(execStat){    	
									runStat.updateStatOnConnection("OnSubjobOk38", 0, "ok");
								} 
							
							tGreenplumClose_4Process(globalMap); 
						



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage());
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tGreenplumInput_10 finally ] start
	 */

	

	
	
	currentComponent="tGreenplumInput_10";

	

 



/**
 * [tGreenplumInput_10 finally ] stop
 */

	
	/**
	 * [tFlowToIterate_2 finally ] start
	 */

	

	
	
	currentComponent="tFlowToIterate_2";

	

 



/**
 * [tFlowToIterate_2 finally ] stop
 */

	
	/**
	 * [tGreenplumRow_4 finally ] start
	 */

	

	
	
	currentComponent="tGreenplumRow_4";

	

 



/**
 * [tGreenplumRow_4 finally ] stop
 */






				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tGreenplumInput_10_SUBPROCESS_STATE", 1);
	}
	

public void tGreenplumClose_4Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tGreenplumClose_4_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;





	
	/**
	 * [tGreenplumClose_4 begin ] start
	 */

	

	
		
		ok_Hash.put("tGreenplumClose_4", false);
		start_Hash.put("tGreenplumClose_4", System.currentTimeMillis());
		
	
	currentComponent="tGreenplumClose_4";

	
		int tos_count_tGreenplumClose_4 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tGreenplumClose_4 - "  + ("Start to work.") );
    	class BytesLimit65535_tGreenplumClose_4{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tGreenplumClose_4 = new StringBuilder();
            log4jParamters_tGreenplumClose_4.append("Parameters:");
                    log4jParamters_tGreenplumClose_4.append("CONNECTION" + " = " + "tGreenplumConnection_6");
                log4jParamters_tGreenplumClose_4.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tGreenplumClose_4 - "  + (log4jParamters_tGreenplumClose_4) );
    		}
    	}
    	
        new BytesLimit65535_tGreenplumClose_4().limitLog4jByte();

 



/**
 * [tGreenplumClose_4 begin ] stop
 */
	
	/**
	 * [tGreenplumClose_4 main ] start
	 */

	

	
	
	currentComponent="tGreenplumClose_4";

	



	java.sql.Connection conn_tGreenplumClose_4 = (java.sql.Connection)globalMap.get("conn_tGreenplumConnection_6");
	if(conn_tGreenplumClose_4 != null && !conn_tGreenplumClose_4.isClosed())
	{
                if(log.isDebugEnabled())
            log.debug("tGreenplumClose_4 - "  + ("Closing the connection ")  + ("conn_tGreenplumConnection_6")  + (" to the database.") );
        conn_tGreenplumClose_4.close();
                if(log.isDebugEnabled())
            log.debug("tGreenplumClose_4 - "  + ("Connection ")  + ("conn_tGreenplumConnection_6")  + (" to the database has closed.") );
	}

 


	tos_count_tGreenplumClose_4++;

/**
 * [tGreenplumClose_4 main ] stop
 */
	
	/**
	 * [tGreenplumClose_4 end ] start
	 */

	

	
	
	currentComponent="tGreenplumClose_4";

	

 
                if(log.isDebugEnabled())
            log.debug("tGreenplumClose_4 - "  + ("Done.") );

ok_Hash.put("tGreenplumClose_4", true);
end_Hash.put("tGreenplumClose_4", System.currentTimeMillis());




/**
 * [tGreenplumClose_4 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage());
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tGreenplumClose_4 finally ] start
	 */

	

	
	
	currentComponent="tGreenplumClose_4";

	

 



/**
 * [tGreenplumClose_4 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tGreenplumClose_4_SUBPROCESS_STATE", 1);
	}
	

public void tJava_14Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tJava_14_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tJava_14 begin ] start
	 */

	

	
		
		ok_Hash.put("tJava_14", false);
		start_Hash.put("tJava_14", System.currentTimeMillis());
		
	
	currentComponent="tJava_14";

	
		int tos_count_tJava_14 = 0;
		
    	class BytesLimit65535_tJava_14{
    		public void limitLog4jByte() throws Exception{
    			
    		}
    	}
    	
        new BytesLimit65535_tJava_14().limitLog4jByte();


String foo = "bar";
System.out.println("===================================================================");
System.out.println("Call EDL_Get_Execution_Statistics_src2prd_GP if SEND_MAIL = 'Y'");
System.out.println(context.getProperty("SEND_MAIL").toUpperCase());
System.out.println("===================================================================");
 



/**
 * [tJava_14 begin ] stop
 */
	
	/**
	 * [tJava_14 main ] start
	 */

	

	
	
	currentComponent="tJava_14";

	

 


	tos_count_tJava_14++;

/**
 * [tJava_14 main ] stop
 */
	
	/**
	 * [tJava_14 end ] start
	 */

	

	
	
	currentComponent="tJava_14";

	

 

ok_Hash.put("tJava_14", true);
end_Hash.put("tJava_14", System.currentTimeMillis());

   			if (context.getProperty("SEND_MAIL").equals("Y")) {
   				
					if(execStat){   
   	 					runStat.updateStatOnConnection("If17", 0, "true");
					}
				
    			tRunJob_6Process(globalMap);
   			}

			   
   				else{
					if(execStat){   
   	 					runStat.updateStatOnConnection("If17", 0, "false");
					}   	 
   				}



/**
 * [tJava_14 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage());
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tJava_14 finally ] start
	 */

	

	
	
	currentComponent="tJava_14";

	

 



/**
 * [tJava_14 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tJava_14_SUBPROCESS_STATE", 1);
	}
	

public void tRunJob_6Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tRunJob_6_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;





	
	/**
	 * [tRunJob_6 begin ] start
	 */

	

	
		
		ok_Hash.put("tRunJob_6", false);
		start_Hash.put("tRunJob_6", System.currentTimeMillis());
		
	
	currentComponent="tRunJob_6";

	
		int tos_count_tRunJob_6 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tRunJob_6 - "  + ("Start to work.") );
    	class BytesLimit65535_tRunJob_6{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tRunJob_6 = new StringBuilder();
            log4jParamters_tRunJob_6.append("Parameters:");
                    log4jParamters_tRunJob_6.append("USE_DYNAMIC_JOB" + " = " + "false");
                log4jParamters_tRunJob_6.append(" | ");
                    log4jParamters_tRunJob_6.append("PROCESS" + " = " + "EDL_Get_Execution_Statistics_src2prd_GP");
                log4jParamters_tRunJob_6.append(" | ");
                    log4jParamters_tRunJob_6.append("USE_INDEPENDENT_PROCESS" + " = " + "false");
                log4jParamters_tRunJob_6.append(" | ");
                    log4jParamters_tRunJob_6.append("DIE_ON_CHILD_ERROR" + " = " + "false");
                log4jParamters_tRunJob_6.append(" | ");
                    log4jParamters_tRunJob_6.append("TRANSMIT_WHOLE_CONTEXT" + " = " + "true");
                log4jParamters_tRunJob_6.append(" | ");
                    log4jParamters_tRunJob_6.append("CONTEXTPARAMS" + " = " + "[{PARAM_NAME_COLUMN="+("RUN_ID")+", PARAM_VALUE_COLUMN="+("globalMap.get(\"BASE_RUN_ID\") ")+"}]");
                log4jParamters_tRunJob_6.append(" | ");
                    log4jParamters_tRunJob_6.append("PROPAGATE_CHILD_RESULT" + " = " + "false");
                log4jParamters_tRunJob_6.append(" | ");
                    log4jParamters_tRunJob_6.append("PRINT_PARAMETER" + " = " + "false");
                log4jParamters_tRunJob_6.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tRunJob_6 - "  + (log4jParamters_tRunJob_6) );
    		}
    	}
    	
        new BytesLimit65535_tRunJob_6().limitLog4jByte();


 



/**
 * [tRunJob_6 begin ] stop
 */
	
	/**
	 * [tRunJob_6 main ] start
	 */

	

	
	
	currentComponent="tRunJob_6";

	
	java.util.List<String> paraList_tRunJob_6 = new java.util.ArrayList<String>();
	
	        			paraList_tRunJob_6.add("--father_pid="+pid);
	      			
	        			paraList_tRunJob_6.add("--root_pid="+rootPid);
	      			
	        			paraList_tRunJob_6.add("--father_node=tRunJob_6");
	      			
	        			paraList_tRunJob_6.add("--context=SOURCING_PROD");
	      			
			if(!"".equals(log4jLevel)){
				paraList_tRunJob_6.add("--log4jLevel="+log4jLevel);
			}
		
	//for feature:10589
	
		paraList_tRunJob_6.add("--stat_port=" + portStats);
	

	if(resuming_logs_dir_path != null){
		paraList_tRunJob_6.add("--resuming_logs_dir_path=" + resuming_logs_dir_path);
	}
	String childResumePath_tRunJob_6 = ResumeUtil.getChildJobCheckPointPath(resuming_checkpoint_path);
	String tRunJobName_tRunJob_6 = ResumeUtil.getRighttRunJob(resuming_checkpoint_path);
	if("tRunJob_6".equals(tRunJobName_tRunJob_6) && childResumePath_tRunJob_6 != null){
		paraList_tRunJob_6.add("--resuming_checkpoint_path=" + ResumeUtil.getChildJobCheckPointPath(resuming_checkpoint_path));
	}
	paraList_tRunJob_6.add("--parent_part_launcher=JOB:" + jobName + "/NODE:tRunJob_6");
	
	java.util.Map<String, Object> parentContextMap_tRunJob_6 = new java.util.HashMap<String, Object>();

	
		
		context.synchronizeContext();
		
			parentContextMap_tRunJob_6.put("GP_SOURCE_NAME", context.GP_SOURCE_NAME);
		
			parentContextMap_tRunJob_6.put("TABLE_NAME", context.TABLE_NAME);
		
			parentContextMap_tRunJob_6.put("FORCE_DROP", context.FORCE_DROP);
		
			parentContextMap_tRunJob_6.put("FORCE_BATCH", context.FORCE_BATCH);
		
			parentContextMap_tRunJob_6.put("LOAD2HDFS", context.LOAD2HDFS);
		
			parentContextMap_tRunJob_6.put("SOURCE_HOST", context.SOURCE_HOST);
		
			parentContextMap_tRunJob_6.put("SOURCE_DATABASE", context.SOURCE_DATABASE);
		
			parentContextMap_tRunJob_6.put("SOURCE_USER", context.SOURCE_USER);
		
			parentContextMap_tRunJob_6.put("SOURCE_PORT", context.SOURCE_PORT);
		
			parentContextMap_tRunJob_6.put("SOURCE_PASSWORD", context.SOURCE_PASSWORD);
		
			parentContextMap_tRunJob_6.put("TOP_N_ROWS", context.TOP_N_ROWS);
		
			parentContextMap_tRunJob_6.put("THREAD", context.THREAD);
		
			parentContextMap_tRunJob_6.put("RUN_ID", context.RUN_ID);
		
			parentContextMap_tRunJob_6.put("PROD2DEV", context.PROD2DEV);
		
			parentContextMap_tRunJob_6.put("SEND_MAIL", context.SEND_MAIL);
		
			parentContextMap_tRunJob_6.put("PUBLIC", context.PUBLIC);
		
			parentContextMap_tRunJob_6.put("PYTHON_NEEDED", context.PYTHON_NEEDED);
		
			parentContextMap_tRunJob_6.put("mail_to_error", context.mail_to_error);
		
			parentContextMap_tRunJob_6.put("JOB_LABEL_NAME", context.JOB_LABEL_NAME);
		
			parentContextMap_tRunJob_6.put("PLANT_NAME", context.PLANT_NAME);
		
			parentContextMap_tRunJob_6.put("LOG_NO_OF_ERRORS", context.LOG_NO_OF_ERRORS);
		
			parentContextMap_tRunJob_6.put("LOG_PLANT_NAME", context.LOG_PLANT_NAME);
		
			parentContextMap_tRunJob_6.put("LOG_NO_OF_UPDATES", context.LOG_NO_OF_UPDATES);
		
			parentContextMap_tRunJob_6.put("LOG_SOURCE_ROW_COUNT", context.LOG_SOURCE_ROW_COUNT);
		
			parentContextMap_tRunJob_6.put("LOG_TECHNOLOGY", context.LOG_TECHNOLOGY);
		
			parentContextMap_tRunJob_6.put("LOG_TABLE_NAME", context.LOG_TABLE_NAME);
		
			parentContextMap_tRunJob_6.put("LOG_NO_OF_INSERTS", context.LOG_NO_OF_INSERTS);
		
			parentContextMap_tRunJob_6.put("LOG_DATA_PATH", context.LOG_DATA_PATH);
		
			parentContextMap_tRunJob_6.put("LOG_NO_OF_DELETES", context.LOG_NO_OF_DELETES);
		
			parentContextMap_tRunJob_6.put("LOG_RUN_ID", context.LOG_RUN_ID);
		
			parentContextMap_tRunJob_6.put("LOG_ERROR_CATEGORY", context.LOG_ERROR_CATEGORY);
		
			parentContextMap_tRunJob_6.put("LOG_JOB_NAME", context.LOG_JOB_NAME);
		
			parentContextMap_tRunJob_6.put("LOG_SYSTEM_NAME", context.LOG_SYSTEM_NAME);
		
			parentContextMap_tRunJob_6.put("LOG_MESSAGE", context.LOG_MESSAGE);
		
			parentContextMap_tRunJob_6.put("LOG_TARGET_ROW_COUNT", context.LOG_TARGET_ROW_COUNT);
		
			parentContextMap_tRunJob_6.put("LOG_STATUS", context.LOG_STATUS);
		
			parentContextMap_tRunJob_6.put("PRIVATE_KEY", context.PRIVATE_KEY);
		
			parentContextMap_tRunJob_6.put("CURSOR_SIZE", context.CURSOR_SIZE);
		
			parentContextMap_tRunJob_6.put("PROD2DEV_THREADS", context.PROD2DEV_THREADS);
		
			parentContextMap_tRunJob_6.put("MAIL_TO", context.MAIL_TO);
		
			parentContextMap_tRunJob_6.put("IGNORE_TIMEZONE", context.IGNORE_TIMEZONE);
		
			parentContextMap_tRunJob_6.put("RECREATE_SCHEMA", context.RECREATE_SCHEMA);
		
			parentContextMap_tRunJob_6.put("DB_VERSION", context.DB_VERSION);
		
			parentContextMap_tRunJob_6.put("IS_MULTITHREAD_BY_TABLE", context.IS_MULTITHREAD_BY_TABLE);
		
			parentContextMap_tRunJob_6.put("OSPASSWORD", context.OSPASSWORD);
		
			parentContextMap_tRunJob_6.put("OSUSER", context.OSUSER);
		
			parentContextMap_tRunJob_6.put("PYTHON_HOST", context.PYTHON_HOST);
		
			parentContextMap_tRunJob_6.put("PYTHON_PATH", context.PYTHON_PATH);
		
			parentContextMap_tRunJob_6.put("ETL_LOCALHOSTNAME", context.ETL_LOCALHOSTNAME);
		
			parentContextMap_tRunJob_6.put("ETL_STORAGE_PATH", context.ETL_STORAGE_PATH);
		
			parentContextMap_tRunJob_6.put("HAWQ_Source_Ports", context.HAWQ_Source_Ports);
		
			parentContextMap_tRunJob_6.put("SOURCING_Database", context.SOURCING_Database);
		
			parentContextMap_tRunJob_6.put("SOURCING_Login", context.SOURCING_Login);
		
			parentContextMap_tRunJob_6.put("SOURCING_Password", context.SOURCING_Password);
		
			parentContextMap_tRunJob_6.put("SOURCING_Port", context.SOURCING_Port);
		
			parentContextMap_tRunJob_6.put("SOURCING_Schema", context.SOURCING_Schema);
		
			parentContextMap_tRunJob_6.put("SOURCING_Server", context.SOURCING_Server);
		 
		java.util.Enumeration<?> propertyNames_tRunJob_6 = context.propertyNames();
		while (propertyNames_tRunJob_6.hasMoreElements()) {
			String key_tRunJob_6 = (String) propertyNames_tRunJob_6.nextElement();
			Object value_tRunJob_6 = (Object) context.get(key_tRunJob_6);       
			paraList_tRunJob_6.add("--context_param " + key_tRunJob_6 + "=" + value_tRunJob_6);
			
		}
		

	Object obj_tRunJob_6 = null;

	
		obj_tRunJob_6 = globalMap.get("BASE_RUN_ID") ;
		paraList_tRunJob_6.add("--context_param RUN_ID=" + RuntimeUtils.tRunJobConvertContext(obj_tRunJob_6));
		
		parentContextMap_tRunJob_6.put("RUN_ID", obj_tRunJob_6);
	
	
		aws_dev_talend_ingestion_framework.edl_get_execution_statistics_src2prd_gp_0_1.EDL_Get_Execution_Statistics_src2prd_GP childJob_tRunJob_6 = new aws_dev_talend_ingestion_framework.edl_get_execution_statistics_src2prd_gp_0_1.EDL_Get_Execution_Statistics_src2prd_GP();
	    // pass DataSources
	    java.util.Map<String, routines.system.TalendDataSource> talendDataSources_tRunJob_6 = (java.util.Map<String, routines.system.TalendDataSource>) globalMap
	            .get(KEY_DB_DATASOURCES);
	    if (null != talendDataSources_tRunJob_6) {
	        java.util.Map<String, javax.sql.DataSource> dataSources_tRunJob_6 = new java.util.HashMap<String, javax.sql.DataSource>();
	        for (java.util.Map.Entry<String, routines.system.TalendDataSource> talendDataSourceEntry_tRunJob_6 : talendDataSources_tRunJob_6
			        .entrySet()) {
	            dataSources_tRunJob_6.put(talendDataSourceEntry_tRunJob_6.getKey(),
	                    talendDataSourceEntry_tRunJob_6.getValue().getRawDataSource());
	        }
	        childJob_tRunJob_6.setDataSources(dataSources_tRunJob_6);
	    }
		  
			childJob_tRunJob_6.parentContextMap = parentContextMap_tRunJob_6;
		  
		
			log.info("tRunJob_6 - The child job 'aws_dev_talend_ingestion_framework.edl_get_execution_statistics_src2prd_gp_0_1.EDL_Get_Execution_Statistics_src2prd_GP' starts on the version '0.1' with the context 'SOURCING_PROD'.");
		
		String[][] childReturn_tRunJob_6 = childJob_tRunJob_6.runJob((String[]) paraList_tRunJob_6.toArray(new String[paraList_tRunJob_6.size()]));
		
			log.info("tRunJob_6 - The child job 'aws_dev_talend_ingestion_framework.edl_get_execution_statistics_src2prd_gp_0_1.EDL_Get_Execution_Statistics_src2prd_GP' is done.");
		
	  	
				((java.util.Map)threadLocal.get()).put("errorCode", childJob_tRunJob_6.getErrorCode());
			
	            
	    	if(childJob_tRunJob_6.getErrorCode() == null){
				globalMap.put("tRunJob_6_CHILD_RETURN_CODE", childJob_tRunJob_6.getStatus() != null && ("failure").equals(childJob_tRunJob_6.getStatus()) ? 1 : 0);
	    	}else{
				globalMap.put("tRunJob_6_CHILD_RETURN_CODE", childJob_tRunJob_6.getErrorCode());
		    }
		    if (childJob_tRunJob_6.getExceptionStackTrace() != null) { 
		    	globalMap.put("tRunJob_6_CHILD_EXCEPTION_STACKTRACE", childJob_tRunJob_6.getExceptionStackTrace());
		    }
	  
			
	  	

 


	tos_count_tRunJob_6++;

/**
 * [tRunJob_6 main ] stop
 */
	
	/**
	 * [tRunJob_6 end ] start
	 */

	

	
	
	currentComponent="tRunJob_6";

	

 
                if(log.isDebugEnabled())
            log.debug("tRunJob_6 - "  + ("Done.") );

ok_Hash.put("tRunJob_6", true);
end_Hash.put("tRunJob_6", System.currentTimeMillis());




/**
 * [tRunJob_6 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage());
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tRunJob_6 finally ] start
	 */

	

	
	
	currentComponent="tRunJob_6";

	

 



/**
 * [tRunJob_6 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tRunJob_6_SUBPROCESS_STATE", 1);
	}
	

public void tJava_15Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tJava_15_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;





	
	/**
	 * [tJava_15 begin ] start
	 */

	

	
		
		ok_Hash.put("tJava_15", false);
		start_Hash.put("tJava_15", System.currentTimeMillis());
		
	
	currentComponent="tJava_15";

	
		int tos_count_tJava_15 = 0;
		
    	class BytesLimit65535_tJava_15{
    		public void limitLog4jByte() throws Exception{
    			
    		}
    	}
    	
        new BytesLimit65535_tJava_15().limitLog4jByte();


String foo = "bar";
System.out.println("===================================================================");
System.out.println("Call EDL_Get_Execution_Statistics_prd2dev_GP if SEND_MAIL = 'Y'");
System.out.println(context.getProperty("SEND_MAIL").toUpperCase());
System.out.println("===================================================================");
 



/**
 * [tJava_15 begin ] stop
 */
	
	/**
	 * [tJava_15 main ] start
	 */

	

	
	
	currentComponent="tJava_15";

	

 


	tos_count_tJava_15++;

/**
 * [tJava_15 main ] stop
 */
	
	/**
	 * [tJava_15 end ] start
	 */

	

	
	
	currentComponent="tJava_15";

	

 

ok_Hash.put("tJava_15", true);
end_Hash.put("tJava_15", System.currentTimeMillis());




/**
 * [tJava_15 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage());
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tJava_15 finally ] start
	 */

	

	
	
	currentComponent="tJava_15";

	

 



/**
 * [tJava_15 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tJava_15_SUBPROCESS_STATE", 1);
	}
	

public void tSetGlobalVar_3Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tSetGlobalVar_3_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tSetGlobalVar_3 begin ] start
	 */

	

	
		
		ok_Hash.put("tSetGlobalVar_3", false);
		start_Hash.put("tSetGlobalVar_3", System.currentTimeMillis());
		
	
	currentComponent="tSetGlobalVar_3";

	
		int tos_count_tSetGlobalVar_3 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tSetGlobalVar_3 - "  + ("Start to work.") );
    	class BytesLimit65535_tSetGlobalVar_3{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tSetGlobalVar_3 = new StringBuilder();
            log4jParamters_tSetGlobalVar_3.append("Parameters:");
                    log4jParamters_tSetGlobalVar_3.append("VARIABLES" + " = " + "[{VALUE="+("\"\"")+", KEY="+("\"insert_log_sql\"")+"}, {VALUE="+("\"\"")+", KEY="+("\"insert_log_template\"")+"}, {VALUE="+("\"\"")+", KEY="+("\"increment_rolling_call\"")+"}, {VALUE="+("\"\"")+", KEY="+("\"increment_rolling_call_template\"")+"}, {VALUE="+("\"\"")+", KEY="+("\"softdelete_call\"")+"}, {VALUE="+("\"\"")+", KEY="+("\"softdelete_call_template\"")+"}, {VALUE="+("\"\"")+", KEY="+("\"data_profiling_call\"")+"}, {VALUE="+("\"\"")+", KEY="+("\"data_profiling_call_template\"")+"}, {VALUE="+("\"\"")+", KEY="+("\"gp_sql\"")+"}, {VALUE="+("TalendDate.getDate(\"yyyyMMddHH24mmssSSS\")")+", KEY="+("\"timestamp\"")+"}, {VALUE="+("\"S2GP_\"")+", KEY="+("\"jobname_prefix\"")+"}]");
                log4jParamters_tSetGlobalVar_3.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tSetGlobalVar_3 - "  + (log4jParamters_tSetGlobalVar_3) );
    		}
    	}
    	
        new BytesLimit65535_tSetGlobalVar_3().limitLog4jByte();

 



/**
 * [tSetGlobalVar_3 begin ] stop
 */
	
	/**
	 * [tSetGlobalVar_3 main ] start
	 */

	

	
	
	currentComponent="tSetGlobalVar_3";

	

globalMap.put("insert_log_sql", "");
globalMap.put("insert_log_template", "");
globalMap.put("increment_rolling_call", "");
globalMap.put("increment_rolling_call_template", "");
globalMap.put("softdelete_call", "");
globalMap.put("softdelete_call_template", "");
globalMap.put("data_profiling_call", "");
globalMap.put("data_profiling_call_template", "");
globalMap.put("gp_sql", "");
globalMap.put("timestamp", TalendDate.getDate("yyyyMMddHH24mmssSSS"));
globalMap.put("jobname_prefix", "S2GP_");

 


	tos_count_tSetGlobalVar_3++;

/**
 * [tSetGlobalVar_3 main ] stop
 */
	
	/**
	 * [tSetGlobalVar_3 end ] start
	 */

	

	
	
	currentComponent="tSetGlobalVar_3";

	

 
                if(log.isDebugEnabled())
            log.debug("tSetGlobalVar_3 - "  + ("Done.") );

ok_Hash.put("tSetGlobalVar_3", true);
end_Hash.put("tSetGlobalVar_3", System.currentTimeMillis());




/**
 * [tSetGlobalVar_3 end ] stop
 */
				}//end the resume

				
				    			if(resumeEntryMethodName == null || globalResumeTicket){
				    				resumeUtil.addLog("CHECKPOINT", "CONNECTION:SUBJOB_OK:tSetGlobalVar_3:OnSubjobOk", "", Thread.currentThread().getId() + "", "", "", "", "", "");
								}	    				    			
					    	
								if(execStat){    	
									runStat.updateStatOnConnection("OnSubjobOk12", 0, "ok");
								} 
							
							tGreenplumConnection_1Process(globalMap); 
						



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage());
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tSetGlobalVar_3 finally ] start
	 */

	

	
	
	currentComponent="tSetGlobalVar_3";

	

 



/**
 * [tSetGlobalVar_3 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tSetGlobalVar_3_SUBPROCESS_STATE", 1);
	}
	


public static class row_talendLogs_LOGSStruct implements routines.system.IPersistableRow<row_talendLogs_LOGSStruct> {
    final static byte[] commonByteArrayLock_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Base_dynamic = new byte[0];
    static byte[] commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Base_dynamic = new byte[0];

	
			    public java.util.Date moment;

				public java.util.Date getMoment () {
					return this.moment;
				}
				
			    public String pid;

				public String getPid () {
					return this.pid;
				}
				
			    public String root_pid;

				public String getRoot_pid () {
					return this.root_pid;
				}
				
			    public String father_pid;

				public String getFather_pid () {
					return this.father_pid;
				}
				
			    public String project;

				public String getProject () {
					return this.project;
				}
				
			    public String job;

				public String getJob () {
					return this.job;
				}
				
			    public String context;

				public String getContext () {
					return this.context;
				}
				
			    public Integer priority;

				public Integer getPriority () {
					return this.priority;
				}
				
			    public String type;

				public String getType () {
					return this.type;
				}
				
			    public String origin;

				public String getOrigin () {
					return this.origin;
				}
				
			    public String message;

				public String getMessage () {
					return this.message;
				}
				
			    public Integer code;

				public Integer getCode () {
					return this.code;
				}
				



	private java.util.Date readDate(ObjectInputStream dis) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(dis.readLong());
		}
		return dateReturn;
	}

    private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException{
		if(date1 == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeLong(date1.getTime());
    	}
    }

	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Base_dynamic.length) {
				if(length < 1024 && commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Base_dynamic.length == 0) {
   					commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Base_dynamic = new byte[1024];
				} else {
   					commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Base_dynamic = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Base_dynamic, 0, length);
			strReturn = new String(commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Base_dynamic, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
	private Integer readInteger(ObjectInputStream dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}

	private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException{
		if(intNum == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeInt(intNum);
    	}
	}

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Base_dynamic) {

        	try {

        		int length = 0;
		
					this.moment = readDate(dis);
					
					this.pid = readString(dis);
					
					this.root_pid = readString(dis);
					
					this.father_pid = readString(dis);
					
					this.project = readString(dis);
					
					this.job = readString(dis);
					
					this.context = readString(dis);
					
						this.priority = readInteger(dis);
					
					this.type = readString(dis);
					
					this.origin = readString(dis);
					
					this.message = readString(dis);
					
						this.code = readInteger(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// java.util.Date
				
						writeDate(this.moment,dos);
					
					// String
				
						writeString(this.pid,dos);
					
					// String
				
						writeString(this.root_pid,dos);
					
					// String
				
						writeString(this.father_pid,dos);
					
					// String
				
						writeString(this.project,dos);
					
					// String
				
						writeString(this.job,dos);
					
					// String
				
						writeString(this.context,dos);
					
					// Integer
				
						writeInteger(this.priority,dos);
					
					// String
				
						writeString(this.type,dos);
					
					// String
				
						writeString(this.origin,dos);
					
					// String
				
						writeString(this.message,dos);
					
					// Integer
				
						writeInteger(this.code,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("moment="+String.valueOf(moment));
		sb.append(",pid="+pid);
		sb.append(",root_pid="+root_pid);
		sb.append(",father_pid="+father_pid);
		sb.append(",project="+project);
		sb.append(",job="+job);
		sb.append(",context="+context);
		sb.append(",priority="+String.valueOf(priority));
		sb.append(",type="+type);
		sb.append(",origin="+origin);
		sb.append(",message="+message);
		sb.append(",code="+String.valueOf(code));
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				if(moment == null){
        					sb.append("<null>");
        				}else{
            				sb.append(moment);
            			}
            		
        			sb.append("|");
        		
        				if(pid == null){
        					sb.append("<null>");
        				}else{
            				sb.append(pid);
            			}
            		
        			sb.append("|");
        		
        				if(root_pid == null){
        					sb.append("<null>");
        				}else{
            				sb.append(root_pid);
            			}
            		
        			sb.append("|");
        		
        				if(father_pid == null){
        					sb.append("<null>");
        				}else{
            				sb.append(father_pid);
            			}
            		
        			sb.append("|");
        		
        				if(project == null){
        					sb.append("<null>");
        				}else{
            				sb.append(project);
            			}
            		
        			sb.append("|");
        		
        				if(job == null){
        					sb.append("<null>");
        				}else{
            				sb.append(job);
            			}
            		
        			sb.append("|");
        		
        				if(context == null){
        					sb.append("<null>");
        				}else{
            				sb.append(context);
            			}
            		
        			sb.append("|");
        		
        				if(priority == null){
        					sb.append("<null>");
        				}else{
            				sb.append(priority);
            			}
            		
        			sb.append("|");
        		
        				if(type == null){
        					sb.append("<null>");
        				}else{
            				sb.append(type);
            			}
            		
        			sb.append("|");
        		
        				if(origin == null){
        					sb.append("<null>");
        				}else{
            				sb.append(origin);
            			}
            		
        			sb.append("|");
        		
        				if(message == null){
        					sb.append("<null>");
        				}else{
            				sb.append(message);
            			}
            		
        			sb.append("|");
        		
        				if(code == null){
        					sb.append("<null>");
        				}else{
            				sb.append(code);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(row_talendLogs_LOGSStruct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}
public void talendLogs_LOGSProcess(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("talendLogs_LOGS_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
		String currentVirtualComponent = null;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;



		row_talendLogs_LOGSStruct row_talendLogs_LOGS = new row_talendLogs_LOGSStruct();




	
	/**
	 * [talendLogs_CONSOLE begin ] start
	 */

	

	
		
		ok_Hash.put("talendLogs_CONSOLE", false);
		start_Hash.put("talendLogs_CONSOLE", System.currentTimeMillis());
		
	
		currentVirtualComponent = "talendLogs_CONSOLE";
	
	currentComponent="talendLogs_CONSOLE";

	
			if (execStat) {
				if(resourceMap.get("inIterateVComp") == null){
					
						runStat.updateStatOnConnection("Main" + iterateId, 0, 0);
					
				}
			} 

		
		int tos_count_talendLogs_CONSOLE = 0;
		
                if(log.isDebugEnabled())
            log.debug("talendLogs_CONSOLE - "  + ("Start to work.") );
    	class BytesLimit65535_talendLogs_CONSOLE{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_talendLogs_CONSOLE = new StringBuilder();
            log4jParamters_talendLogs_CONSOLE.append("Parameters:");
                    log4jParamters_talendLogs_CONSOLE.append("BASIC_MODE" + " = " + "true");
                log4jParamters_talendLogs_CONSOLE.append(" | ");
                    log4jParamters_talendLogs_CONSOLE.append("TABLE_PRINT" + " = " + "false");
                log4jParamters_talendLogs_CONSOLE.append(" | ");
                    log4jParamters_talendLogs_CONSOLE.append("VERTICAL" + " = " + "false");
                log4jParamters_talendLogs_CONSOLE.append(" | ");
                    log4jParamters_talendLogs_CONSOLE.append("FIELDSEPARATOR" + " = " + "\"|\"");
                log4jParamters_talendLogs_CONSOLE.append(" | ");
                    log4jParamters_talendLogs_CONSOLE.append("PRINT_HEADER" + " = " + "false");
                log4jParamters_talendLogs_CONSOLE.append(" | ");
                    log4jParamters_talendLogs_CONSOLE.append("PRINT_UNIQUE_NAME" + " = " + "false");
                log4jParamters_talendLogs_CONSOLE.append(" | ");
                    log4jParamters_talendLogs_CONSOLE.append("PRINT_COLNAMES" + " = " + "false");
                log4jParamters_talendLogs_CONSOLE.append(" | ");
                    log4jParamters_talendLogs_CONSOLE.append("USE_FIXED_LENGTH" + " = " + "false");
                log4jParamters_talendLogs_CONSOLE.append(" | ");
                    log4jParamters_talendLogs_CONSOLE.append("PRINT_CONTENT_WITH_LOG4J" + " = " + "true");
                log4jParamters_talendLogs_CONSOLE.append(" | ");
                if(log.isDebugEnabled())
            log.debug("talendLogs_CONSOLE - "  + (log4jParamters_talendLogs_CONSOLE) );
    		}
    	}
    	
        new BytesLimit65535_talendLogs_CONSOLE().limitLog4jByte();

	///////////////////////
	
		final String OUTPUT_FIELD_SEPARATOR_talendLogs_CONSOLE = "|";
		java.io.PrintStream consoleOut_talendLogs_CONSOLE = null;	

 		StringBuilder strBuffer_talendLogs_CONSOLE = null;
		int nb_line_talendLogs_CONSOLE = 0;
///////////////////////    			



 



/**
 * [talendLogs_CONSOLE begin ] stop
 */



	
	/**
	 * [talendLogs_LOGS begin ] start
	 */

	

	
		
		ok_Hash.put("talendLogs_LOGS", false);
		start_Hash.put("talendLogs_LOGS", System.currentTimeMillis());
		
	
		currentVirtualComponent = "talendLogs_LOGS";
	
	currentComponent="talendLogs_LOGS";

	
		int tos_count_talendLogs_LOGS = 0;
		
                if(log.isDebugEnabled())
            log.debug("talendLogs_LOGS - "  + ("Start to work.") );
    	class BytesLimit65535_talendLogs_LOGS{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_talendLogs_LOGS = new StringBuilder();
            log4jParamters_talendLogs_LOGS.append("Parameters:");
                    log4jParamters_talendLogs_LOGS.append("CATCH_JAVA_EXCEPTION" + " = " + "true");
                log4jParamters_talendLogs_LOGS.append(" | ");
                    log4jParamters_talendLogs_LOGS.append("CATCH_TDIE" + " = " + "true");
                log4jParamters_talendLogs_LOGS.append(" | ");
                    log4jParamters_talendLogs_LOGS.append("CATCH_TWARN" + " = " + "true");
                log4jParamters_talendLogs_LOGS.append(" | ");
                    log4jParamters_talendLogs_LOGS.append("CATCH_TACTIONFAILURE" + " = " + "true");
                log4jParamters_talendLogs_LOGS.append(" | ");
                if(log.isDebugEnabled())
            log.debug("talendLogs_LOGS - "  + (log4jParamters_talendLogs_LOGS) );
    		}
    	}
    	
        new BytesLimit65535_talendLogs_LOGS().limitLog4jByte();

	for (LogCatcherUtils.LogCatcherMessage lcm : talendLogs_LOGS.getMessages()) {
		row_talendLogs_LOGS.type = lcm.getType();
		row_talendLogs_LOGS.origin = (lcm.getOrigin()==null || lcm.getOrigin().length()<1 ? null : lcm.getOrigin());
		row_talendLogs_LOGS.priority = lcm.getPriority();
		row_talendLogs_LOGS.message = lcm.getMessage();
		row_talendLogs_LOGS.code = lcm.getCode();
		
		row_talendLogs_LOGS.moment = java.util.Calendar.getInstance().getTime();
	
    	row_talendLogs_LOGS.pid = pid;
		row_talendLogs_LOGS.root_pid = rootPid;
		row_talendLogs_LOGS.father_pid = fatherPid;
	
    	row_talendLogs_LOGS.project = projectName;
    	row_talendLogs_LOGS.job = jobName;
    	row_talendLogs_LOGS.context = contextStr;
    		
 



/**
 * [talendLogs_LOGS begin ] stop
 */
	
	/**
	 * [talendLogs_LOGS main ] start
	 */

	

	
	
		currentVirtualComponent = "talendLogs_LOGS";
	
	currentComponent="talendLogs_LOGS";

	

 


	tos_count_talendLogs_LOGS++;

/**
 * [talendLogs_LOGS main ] stop
 */

	
	/**
	 * [talendLogs_CONSOLE main ] start
	 */

	

	
	
		currentVirtualComponent = "talendLogs_CONSOLE";
	
	currentComponent="talendLogs_CONSOLE";

	

			//Main
			//row_talendLogs_LOGS


			
				if(execStat){
					runStat.updateStatOnConnection("Main"+iterateId,1, 1);
				} 
			

		
///////////////////////		
						



				strBuffer_talendLogs_CONSOLE = new StringBuilder();




   				
	    		if(row_talendLogs_LOGS.moment != null) { //              
                    							
       
				strBuffer_talendLogs_CONSOLE.append(
								FormatterUtils.format_Date(row_talendLogs_LOGS.moment, "yyyy-MM-dd HH:mm:ss")				
				);


							
	    		} //  			

    			strBuffer_talendLogs_CONSOLE.append("|");
    			


   				
	    		if(row_talendLogs_LOGS.pid != null) { //              
                    							
       
				strBuffer_talendLogs_CONSOLE.append(
				                String.valueOf(row_talendLogs_LOGS.pid)							
				);


							
	    		} //  			

    			strBuffer_talendLogs_CONSOLE.append("|");
    			


   				
	    		if(row_talendLogs_LOGS.root_pid != null) { //              
                    							
       
				strBuffer_talendLogs_CONSOLE.append(
				                String.valueOf(row_talendLogs_LOGS.root_pid)							
				);


							
	    		} //  			

    			strBuffer_talendLogs_CONSOLE.append("|");
    			


   				
	    		if(row_talendLogs_LOGS.father_pid != null) { //              
                    							
       
				strBuffer_talendLogs_CONSOLE.append(
				                String.valueOf(row_talendLogs_LOGS.father_pid)							
				);


							
	    		} //  			

    			strBuffer_talendLogs_CONSOLE.append("|");
    			


   				
	    		if(row_talendLogs_LOGS.project != null) { //              
                    							
       
				strBuffer_talendLogs_CONSOLE.append(
				                String.valueOf(row_talendLogs_LOGS.project)							
				);


							
	    		} //  			

    			strBuffer_talendLogs_CONSOLE.append("|");
    			


   				
	    		if(row_talendLogs_LOGS.job != null) { //              
                    							
       
				strBuffer_talendLogs_CONSOLE.append(
				                String.valueOf(row_talendLogs_LOGS.job)							
				);


							
	    		} //  			

    			strBuffer_talendLogs_CONSOLE.append("|");
    			


   				
	    		if(row_talendLogs_LOGS.context != null) { //              
                    							
       
				strBuffer_talendLogs_CONSOLE.append(
				                String.valueOf(row_talendLogs_LOGS.context)							
				);


							
	    		} //  			

    			strBuffer_talendLogs_CONSOLE.append("|");
    			


   				
	    		if(row_talendLogs_LOGS.priority != null) { //              
                    							
       
				strBuffer_talendLogs_CONSOLE.append(
				                String.valueOf(row_talendLogs_LOGS.priority)							
				);


							
	    		} //  			

    			strBuffer_talendLogs_CONSOLE.append("|");
    			


   				
	    		if(row_talendLogs_LOGS.type != null) { //              
                    							
       
				strBuffer_talendLogs_CONSOLE.append(
				                String.valueOf(row_talendLogs_LOGS.type)							
				);


							
	    		} //  			

    			strBuffer_talendLogs_CONSOLE.append("|");
    			


   				
	    		if(row_talendLogs_LOGS.origin != null) { //              
                    							
       
				strBuffer_talendLogs_CONSOLE.append(
				                String.valueOf(row_talendLogs_LOGS.origin)							
				);


							
	    		} //  			

    			strBuffer_talendLogs_CONSOLE.append("|");
    			


   				
	    		if(row_talendLogs_LOGS.message != null) { //              
                    							
       
				strBuffer_talendLogs_CONSOLE.append(
				                String.valueOf(row_talendLogs_LOGS.message)							
				);


							
	    		} //  			

    			strBuffer_talendLogs_CONSOLE.append("|");
    			


   				
	    		if(row_talendLogs_LOGS.code != null) { //              
                    							
       
				strBuffer_talendLogs_CONSOLE.append(
				                String.valueOf(row_talendLogs_LOGS.code)							
				);


							
	    		} //  			
 

                    if (globalMap.get("tLogRow_CONSOLE")!=null)
                    {
                    	consoleOut_talendLogs_CONSOLE = (java.io.PrintStream) globalMap.get("tLogRow_CONSOLE");
                    }
                    else
                    {
                    	consoleOut_talendLogs_CONSOLE = new java.io.PrintStream(new java.io.BufferedOutputStream(System.out));
                    	globalMap.put("tLogRow_CONSOLE",consoleOut_talendLogs_CONSOLE);
                    }
                    	log.info("talendLogs_CONSOLE - Content of row "+(nb_line_talendLogs_CONSOLE+1)+": " + strBuffer_talendLogs_CONSOLE.toString());
                    consoleOut_talendLogs_CONSOLE.println(strBuffer_talendLogs_CONSOLE.toString());
                    consoleOut_talendLogs_CONSOLE.flush();
                    nb_line_talendLogs_CONSOLE++;
//////

//////                    
                    
///////////////////////    			

 


	tos_count_talendLogs_CONSOLE++;

/**
 * [talendLogs_CONSOLE main ] stop
 */



	
	/**
	 * [talendLogs_LOGS end ] start
	 */

	

	
	
		currentVirtualComponent = "talendLogs_LOGS";
	
	currentComponent="talendLogs_LOGS";

	
	}
 
                if(log.isDebugEnabled())
            log.debug("talendLogs_LOGS - "  + ("Done.") );

ok_Hash.put("talendLogs_LOGS", true);
end_Hash.put("talendLogs_LOGS", System.currentTimeMillis());




/**
 * [talendLogs_LOGS end ] stop
 */

	
	/**
	 * [talendLogs_CONSOLE end ] start
	 */

	

	
	
		currentVirtualComponent = "talendLogs_CONSOLE";
	
	currentComponent="talendLogs_CONSOLE";

	


//////
//////
globalMap.put("talendLogs_CONSOLE_NB_LINE",nb_line_talendLogs_CONSOLE);
                if(log.isInfoEnabled())
            log.info("talendLogs_CONSOLE - "  + ("Printed row count: ")  + (nb_line_talendLogs_CONSOLE)  + (".") );

///////////////////////    			

			if(execStat){
				if(resourceMap.get("inIterateVComp") == null || !((Boolean)resourceMap.get("inIterateVComp"))){
			 		runStat.updateStatOnConnection("Main"+iterateId,2, 0); 
			 	}
			}
		
 
                if(log.isDebugEnabled())
            log.debug("talendLogs_CONSOLE - "  + ("Done.") );

ok_Hash.put("talendLogs_CONSOLE", true);
end_Hash.put("talendLogs_CONSOLE", System.currentTimeMillis());




/**
 * [talendLogs_CONSOLE end ] stop
 */



				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage());
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
					te.setVirtualComponentName(currentVirtualComponent);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [talendLogs_LOGS finally ] start
	 */

	

	
	
		currentVirtualComponent = "talendLogs_LOGS";
	
	currentComponent="talendLogs_LOGS";

	

 



/**
 * [talendLogs_LOGS finally ] stop
 */

	
	/**
	 * [talendLogs_CONSOLE finally ] start
	 */

	

	
	
		currentVirtualComponent = "talendLogs_CONSOLE";
	
	currentComponent="talendLogs_CONSOLE";

	

 



/**
 * [talendLogs_CONSOLE finally ] stop
 */



				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("talendLogs_LOGS_SUBPROCESS_STATE", 1);
	}
	


public static class row_talendStats_STATSStruct implements routines.system.IPersistableRow<row_talendStats_STATSStruct> {
    final static byte[] commonByteArrayLock_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Base_dynamic = new byte[0];
    static byte[] commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Base_dynamic = new byte[0];

	
			    public java.util.Date moment;

				public java.util.Date getMoment () {
					return this.moment;
				}
				
			    public String pid;

				public String getPid () {
					return this.pid;
				}
				
			    public String father_pid;

				public String getFather_pid () {
					return this.father_pid;
				}
				
			    public String root_pid;

				public String getRoot_pid () {
					return this.root_pid;
				}
				
			    public Long system_pid;

				public Long getSystem_pid () {
					return this.system_pid;
				}
				
			    public String project;

				public String getProject () {
					return this.project;
				}
				
			    public String job;

				public String getJob () {
					return this.job;
				}
				
			    public String job_repository_id;

				public String getJob_repository_id () {
					return this.job_repository_id;
				}
				
			    public String job_version;

				public String getJob_version () {
					return this.job_version;
				}
				
			    public String context;

				public String getContext () {
					return this.context;
				}
				
			    public String origin;

				public String getOrigin () {
					return this.origin;
				}
				
			    public String message_type;

				public String getMessage_type () {
					return this.message_type;
				}
				
			    public String message;

				public String getMessage () {
					return this.message;
				}
				
			    public Long duration;

				public Long getDuration () {
					return this.duration;
				}
				



	private java.util.Date readDate(ObjectInputStream dis) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(dis.readLong());
		}
		return dateReturn;
	}

    private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException{
		if(date1 == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeLong(date1.getTime());
    	}
    }

	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Base_dynamic.length) {
				if(length < 1024 && commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Base_dynamic.length == 0) {
   					commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Base_dynamic = new byte[1024];
				} else {
   					commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Base_dynamic = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Base_dynamic, 0, length);
			strReturn = new String(commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Base_dynamic, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Base_dynamic) {

        	try {

        		int length = 0;
		
					this.moment = readDate(dis);
					
					this.pid = readString(dis);
					
					this.father_pid = readString(dis);
					
					this.root_pid = readString(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.system_pid = null;
           				} else {
           			    	this.system_pid = dis.readLong();
           				}
					
					this.project = readString(dis);
					
					this.job = readString(dis);
					
					this.job_repository_id = readString(dis);
					
					this.job_version = readString(dis);
					
					this.context = readString(dis);
					
					this.origin = readString(dis);
					
					this.message_type = readString(dis);
					
					this.message = readString(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.duration = null;
           				} else {
           			    	this.duration = dis.readLong();
           				}
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// java.util.Date
				
						writeDate(this.moment,dos);
					
					// String
				
						writeString(this.pid,dos);
					
					// String
				
						writeString(this.father_pid,dos);
					
					// String
				
						writeString(this.root_pid,dos);
					
					// Long
				
						if(this.system_pid == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeLong(this.system_pid);
		            	}
					
					// String
				
						writeString(this.project,dos);
					
					// String
				
						writeString(this.job,dos);
					
					// String
				
						writeString(this.job_repository_id,dos);
					
					// String
				
						writeString(this.job_version,dos);
					
					// String
				
						writeString(this.context,dos);
					
					// String
				
						writeString(this.origin,dos);
					
					// String
				
						writeString(this.message_type,dos);
					
					// String
				
						writeString(this.message,dos);
					
					// Long
				
						if(this.duration == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeLong(this.duration);
		            	}
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("moment="+String.valueOf(moment));
		sb.append(",pid="+pid);
		sb.append(",father_pid="+father_pid);
		sb.append(",root_pid="+root_pid);
		sb.append(",system_pid="+String.valueOf(system_pid));
		sb.append(",project="+project);
		sb.append(",job="+job);
		sb.append(",job_repository_id="+job_repository_id);
		sb.append(",job_version="+job_version);
		sb.append(",context="+context);
		sb.append(",origin="+origin);
		sb.append(",message_type="+message_type);
		sb.append(",message="+message);
		sb.append(",duration="+String.valueOf(duration));
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				if(moment == null){
        					sb.append("<null>");
        				}else{
            				sb.append(moment);
            			}
            		
        			sb.append("|");
        		
        				if(pid == null){
        					sb.append("<null>");
        				}else{
            				sb.append(pid);
            			}
            		
        			sb.append("|");
        		
        				if(father_pid == null){
        					sb.append("<null>");
        				}else{
            				sb.append(father_pid);
            			}
            		
        			sb.append("|");
        		
        				if(root_pid == null){
        					sb.append("<null>");
        				}else{
            				sb.append(root_pid);
            			}
            		
        			sb.append("|");
        		
        				if(system_pid == null){
        					sb.append("<null>");
        				}else{
            				sb.append(system_pid);
            			}
            		
        			sb.append("|");
        		
        				if(project == null){
        					sb.append("<null>");
        				}else{
            				sb.append(project);
            			}
            		
        			sb.append("|");
        		
        				if(job == null){
        					sb.append("<null>");
        				}else{
            				sb.append(job);
            			}
            		
        			sb.append("|");
        		
        				if(job_repository_id == null){
        					sb.append("<null>");
        				}else{
            				sb.append(job_repository_id);
            			}
            		
        			sb.append("|");
        		
        				if(job_version == null){
        					sb.append("<null>");
        				}else{
            				sb.append(job_version);
            			}
            		
        			sb.append("|");
        		
        				if(context == null){
        					sb.append("<null>");
        				}else{
            				sb.append(context);
            			}
            		
        			sb.append("|");
        		
        				if(origin == null){
        					sb.append("<null>");
        				}else{
            				sb.append(origin);
            			}
            		
        			sb.append("|");
        		
        				if(message_type == null){
        					sb.append("<null>");
        				}else{
            				sb.append(message_type);
            			}
            		
        			sb.append("|");
        		
        				if(message == null){
        					sb.append("<null>");
        				}else{
            				sb.append(message);
            			}
            		
        			sb.append("|");
        		
        				if(duration == null){
        					sb.append("<null>");
        				}else{
            				sb.append(duration);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(row_talendStats_STATSStruct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}
public void talendStats_STATSProcess(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("talendStats_STATS_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
		String currentVirtualComponent = null;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;



		row_talendStats_STATSStruct row_talendStats_STATS = new row_talendStats_STATSStruct();




	
	/**
	 * [talendStats_CONSOLE begin ] start
	 */

	

	
		
		ok_Hash.put("talendStats_CONSOLE", false);
		start_Hash.put("talendStats_CONSOLE", System.currentTimeMillis());
		
	
		currentVirtualComponent = "talendStats_CONSOLE";
	
	currentComponent="talendStats_CONSOLE";

	
			if (execStat) {
				if(resourceMap.get("inIterateVComp") == null){
					
						runStat.updateStatOnConnection("Main" + iterateId, 0, 0);
					
				}
			} 

		
		int tos_count_talendStats_CONSOLE = 0;
		
                if(log.isDebugEnabled())
            log.debug("talendStats_CONSOLE - "  + ("Start to work.") );
    	class BytesLimit65535_talendStats_CONSOLE{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_talendStats_CONSOLE = new StringBuilder();
            log4jParamters_talendStats_CONSOLE.append("Parameters:");
                    log4jParamters_talendStats_CONSOLE.append("BASIC_MODE" + " = " + "true");
                log4jParamters_talendStats_CONSOLE.append(" | ");
                    log4jParamters_talendStats_CONSOLE.append("TABLE_PRINT" + " = " + "false");
                log4jParamters_talendStats_CONSOLE.append(" | ");
                    log4jParamters_talendStats_CONSOLE.append("VERTICAL" + " = " + "false");
                log4jParamters_talendStats_CONSOLE.append(" | ");
                    log4jParamters_talendStats_CONSOLE.append("FIELDSEPARATOR" + " = " + "\"|\"");
                log4jParamters_talendStats_CONSOLE.append(" | ");
                    log4jParamters_talendStats_CONSOLE.append("PRINT_HEADER" + " = " + "false");
                log4jParamters_talendStats_CONSOLE.append(" | ");
                    log4jParamters_talendStats_CONSOLE.append("PRINT_UNIQUE_NAME" + " = " + "false");
                log4jParamters_talendStats_CONSOLE.append(" | ");
                    log4jParamters_talendStats_CONSOLE.append("PRINT_COLNAMES" + " = " + "false");
                log4jParamters_talendStats_CONSOLE.append(" | ");
                    log4jParamters_talendStats_CONSOLE.append("USE_FIXED_LENGTH" + " = " + "false");
                log4jParamters_talendStats_CONSOLE.append(" | ");
                    log4jParamters_talendStats_CONSOLE.append("PRINT_CONTENT_WITH_LOG4J" + " = " + "true");
                log4jParamters_talendStats_CONSOLE.append(" | ");
                if(log.isDebugEnabled())
            log.debug("talendStats_CONSOLE - "  + (log4jParamters_talendStats_CONSOLE) );
    		}
    	}
    	
        new BytesLimit65535_talendStats_CONSOLE().limitLog4jByte();

	///////////////////////
	
		final String OUTPUT_FIELD_SEPARATOR_talendStats_CONSOLE = "|";
		java.io.PrintStream consoleOut_talendStats_CONSOLE = null;	

 		StringBuilder strBuffer_talendStats_CONSOLE = null;
		int nb_line_talendStats_CONSOLE = 0;
///////////////////////    			



 



/**
 * [talendStats_CONSOLE begin ] stop
 */



	
	/**
	 * [talendStats_STATS begin ] start
	 */

	

	
		
		ok_Hash.put("talendStats_STATS", false);
		start_Hash.put("talendStats_STATS", System.currentTimeMillis());
		
	
		currentVirtualComponent = "talendStats_STATS";
	
	currentComponent="talendStats_STATS";

	
		int tos_count_talendStats_STATS = 0;
		
                if(log.isDebugEnabled())
            log.debug("talendStats_STATS - "  + ("Start to work.") );
    	class BytesLimit65535_talendStats_STATS{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_talendStats_STATS = new StringBuilder();
            log4jParamters_talendStats_STATS.append("Parameters:");
                if(log.isDebugEnabled())
            log.debug("talendStats_STATS - "  + (log4jParamters_talendStats_STATS) );
    		}
    	}
    	
        new BytesLimit65535_talendStats_STATS().limitLog4jByte();

	for (StatCatcherUtils.StatCatcherMessage scm : talendStats_STATS.getMessages()) {
		row_talendStats_STATS.pid = pid;
		row_talendStats_STATS.root_pid = rootPid;
		row_talendStats_STATS.father_pid = fatherPid;	
    	row_talendStats_STATS.project = projectName;
    	row_talendStats_STATS.job = jobName;
    	row_talendStats_STATS.context = contextStr;
		row_talendStats_STATS.origin = (scm.getOrigin()==null || scm.getOrigin().length()<1 ? null : scm.getOrigin());
		row_talendStats_STATS.message = scm.getMessage();
		row_talendStats_STATS.duration = scm.getDuration();
		row_talendStats_STATS.moment = scm.getMoment();
		row_talendStats_STATS.message_type = scm.getMessageType();
		row_talendStats_STATS.job_version = scm.getJobVersion();
		row_talendStats_STATS.job_repository_id = scm.getJobId();
		row_talendStats_STATS.system_pid = scm.getSystemPid();

 



/**
 * [talendStats_STATS begin ] stop
 */
	
	/**
	 * [talendStats_STATS main ] start
	 */

	

	
	
		currentVirtualComponent = "talendStats_STATS";
	
	currentComponent="talendStats_STATS";

	

 


	tos_count_talendStats_STATS++;

/**
 * [talendStats_STATS main ] stop
 */

	
	/**
	 * [talendStats_CONSOLE main ] start
	 */

	

	
	
		currentVirtualComponent = "talendStats_CONSOLE";
	
	currentComponent="talendStats_CONSOLE";

	

			//Main
			//row_talendStats_STATS


			
				if(execStat){
					runStat.updateStatOnConnection("Main"+iterateId,1, 1);
				} 
			

		
///////////////////////		
						



				strBuffer_talendStats_CONSOLE = new StringBuilder();




   				
	    		if(row_talendStats_STATS.moment != null) { //              
                    							
       
				strBuffer_talendStats_CONSOLE.append(
								FormatterUtils.format_Date(row_talendStats_STATS.moment, "yyyy-MM-dd HH:mm:ss")				
				);


							
	    		} //  			

    			strBuffer_talendStats_CONSOLE.append("|");
    			


   				
	    		if(row_talendStats_STATS.pid != null) { //              
                    							
       
				strBuffer_talendStats_CONSOLE.append(
				                String.valueOf(row_talendStats_STATS.pid)							
				);


							
	    		} //  			

    			strBuffer_talendStats_CONSOLE.append("|");
    			


   				
	    		if(row_talendStats_STATS.father_pid != null) { //              
                    							
       
				strBuffer_talendStats_CONSOLE.append(
				                String.valueOf(row_talendStats_STATS.father_pid)							
				);


							
	    		} //  			

    			strBuffer_talendStats_CONSOLE.append("|");
    			


   				
	    		if(row_talendStats_STATS.root_pid != null) { //              
                    							
       
				strBuffer_talendStats_CONSOLE.append(
				                String.valueOf(row_talendStats_STATS.root_pid)							
				);


							
	    		} //  			

    			strBuffer_talendStats_CONSOLE.append("|");
    			


   				
	    		if(row_talendStats_STATS.system_pid != null) { //              
                    							
       
				strBuffer_talendStats_CONSOLE.append(
				                String.valueOf(row_talendStats_STATS.system_pid)							
				);


							
	    		} //  			

    			strBuffer_talendStats_CONSOLE.append("|");
    			


   				
	    		if(row_talendStats_STATS.project != null) { //              
                    							
       
				strBuffer_talendStats_CONSOLE.append(
				                String.valueOf(row_talendStats_STATS.project)							
				);


							
	    		} //  			

    			strBuffer_talendStats_CONSOLE.append("|");
    			


   				
	    		if(row_talendStats_STATS.job != null) { //              
                    							
       
				strBuffer_talendStats_CONSOLE.append(
				                String.valueOf(row_talendStats_STATS.job)							
				);


							
	    		} //  			

    			strBuffer_talendStats_CONSOLE.append("|");
    			


   				
	    		if(row_talendStats_STATS.job_repository_id != null) { //              
                    							
       
				strBuffer_talendStats_CONSOLE.append(
				                String.valueOf(row_talendStats_STATS.job_repository_id)							
				);


							
	    		} //  			

    			strBuffer_talendStats_CONSOLE.append("|");
    			


   				
	    		if(row_talendStats_STATS.job_version != null) { //              
                    							
       
				strBuffer_talendStats_CONSOLE.append(
				                String.valueOf(row_talendStats_STATS.job_version)							
				);


							
	    		} //  			

    			strBuffer_talendStats_CONSOLE.append("|");
    			


   				
	    		if(row_talendStats_STATS.context != null) { //              
                    							
       
				strBuffer_talendStats_CONSOLE.append(
				                String.valueOf(row_talendStats_STATS.context)							
				);


							
	    		} //  			

    			strBuffer_talendStats_CONSOLE.append("|");
    			


   				
	    		if(row_talendStats_STATS.origin != null) { //              
                    							
       
				strBuffer_talendStats_CONSOLE.append(
				                String.valueOf(row_talendStats_STATS.origin)							
				);


							
	    		} //  			

    			strBuffer_talendStats_CONSOLE.append("|");
    			


   				
	    		if(row_talendStats_STATS.message_type != null) { //              
                    							
       
				strBuffer_talendStats_CONSOLE.append(
				                String.valueOf(row_talendStats_STATS.message_type)							
				);


							
	    		} //  			

    			strBuffer_talendStats_CONSOLE.append("|");
    			


   				
	    		if(row_talendStats_STATS.message != null) { //              
                    							
       
				strBuffer_talendStats_CONSOLE.append(
				                String.valueOf(row_talendStats_STATS.message)							
				);


							
	    		} //  			

    			strBuffer_talendStats_CONSOLE.append("|");
    			


   				
	    		if(row_talendStats_STATS.duration != null) { //              
                    							
       
				strBuffer_talendStats_CONSOLE.append(
				                String.valueOf(row_talendStats_STATS.duration)							
				);


							
	    		} //  			
 

                    if (globalMap.get("tLogRow_CONSOLE")!=null)
                    {
                    	consoleOut_talendStats_CONSOLE = (java.io.PrintStream) globalMap.get("tLogRow_CONSOLE");
                    }
                    else
                    {
                    	consoleOut_talendStats_CONSOLE = new java.io.PrintStream(new java.io.BufferedOutputStream(System.out));
                    	globalMap.put("tLogRow_CONSOLE",consoleOut_talendStats_CONSOLE);
                    }
                    	log.info("talendStats_CONSOLE - Content of row "+(nb_line_talendStats_CONSOLE+1)+": " + strBuffer_talendStats_CONSOLE.toString());
                    consoleOut_talendStats_CONSOLE.println(strBuffer_talendStats_CONSOLE.toString());
                    consoleOut_talendStats_CONSOLE.flush();
                    nb_line_talendStats_CONSOLE++;
//////

//////                    
                    
///////////////////////    			

 


	tos_count_talendStats_CONSOLE++;

/**
 * [talendStats_CONSOLE main ] stop
 */



	
	/**
	 * [talendStats_STATS end ] start
	 */

	

	
	
		currentVirtualComponent = "talendStats_STATS";
	
	currentComponent="talendStats_STATS";

	

	}


 
                if(log.isDebugEnabled())
            log.debug("talendStats_STATS - "  + ("Done.") );

ok_Hash.put("talendStats_STATS", true);
end_Hash.put("talendStats_STATS", System.currentTimeMillis());




/**
 * [talendStats_STATS end ] stop
 */

	
	/**
	 * [talendStats_CONSOLE end ] start
	 */

	

	
	
		currentVirtualComponent = "talendStats_CONSOLE";
	
	currentComponent="talendStats_CONSOLE";

	


//////
//////
globalMap.put("talendStats_CONSOLE_NB_LINE",nb_line_talendStats_CONSOLE);
                if(log.isInfoEnabled())
            log.info("talendStats_CONSOLE - "  + ("Printed row count: ")  + (nb_line_talendStats_CONSOLE)  + (".") );

///////////////////////    			

			if(execStat){
				if(resourceMap.get("inIterateVComp") == null || !((Boolean)resourceMap.get("inIterateVComp"))){
			 		runStat.updateStatOnConnection("Main"+iterateId,2, 0); 
			 	}
			}
		
 
                if(log.isDebugEnabled())
            log.debug("talendStats_CONSOLE - "  + ("Done.") );

ok_Hash.put("talendStats_CONSOLE", true);
end_Hash.put("talendStats_CONSOLE", System.currentTimeMillis());




/**
 * [talendStats_CONSOLE end ] stop
 */



				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage());
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
					te.setVirtualComponentName(currentVirtualComponent);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [talendStats_STATS finally ] start
	 */

	

	
	
		currentVirtualComponent = "talendStats_STATS";
	
	currentComponent="talendStats_STATS";

	

 



/**
 * [talendStats_STATS finally ] stop
 */

	
	/**
	 * [talendStats_CONSOLE finally ] start
	 */

	

	
	
		currentVirtualComponent = "talendStats_CONSOLE";
	
	currentComponent="talendStats_CONSOLE";

	

 



/**
 * [talendStats_CONSOLE finally ] stop
 */



				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("talendStats_STATS_SUBPROCESS_STATE", 1);
	}
	


public static class row_talendMeter_METTERStruct implements routines.system.IPersistableRow<row_talendMeter_METTERStruct> {
    final static byte[] commonByteArrayLock_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Base_dynamic = new byte[0];
    static byte[] commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Base_dynamic = new byte[0];

	
			    public java.util.Date moment;

				public java.util.Date getMoment () {
					return this.moment;
				}
				
			    public String pid;

				public String getPid () {
					return this.pid;
				}
				
			    public String father_pid;

				public String getFather_pid () {
					return this.father_pid;
				}
				
			    public String root_pid;

				public String getRoot_pid () {
					return this.root_pid;
				}
				
			    public Long system_pid;

				public Long getSystem_pid () {
					return this.system_pid;
				}
				
			    public String project;

				public String getProject () {
					return this.project;
				}
				
			    public String job;

				public String getJob () {
					return this.job;
				}
				
			    public String job_repository_id;

				public String getJob_repository_id () {
					return this.job_repository_id;
				}
				
			    public String job_version;

				public String getJob_version () {
					return this.job_version;
				}
				
			    public String context;

				public String getContext () {
					return this.context;
				}
				
			    public String origin;

				public String getOrigin () {
					return this.origin;
				}
				
			    public String label;

				public String getLabel () {
					return this.label;
				}
				
			    public Integer count;

				public Integer getCount () {
					return this.count;
				}
				
			    public Integer reference;

				public Integer getReference () {
					return this.reference;
				}
				
			    public String thresholds;

				public String getThresholds () {
					return this.thresholds;
				}
				



	private java.util.Date readDate(ObjectInputStream dis) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(dis.readLong());
		}
		return dateReturn;
	}

    private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException{
		if(date1 == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeLong(date1.getTime());
    	}
    }

	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Base_dynamic.length) {
				if(length < 1024 && commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Base_dynamic.length == 0) {
   					commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Base_dynamic = new byte[1024];
				} else {
   					commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Base_dynamic = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Base_dynamic, 0, length);
			strReturn = new String(commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Base_dynamic, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
	private Integer readInteger(ObjectInputStream dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}

	private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException{
		if(intNum == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeInt(intNum);
    	}
	}

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Base_dynamic) {

        	try {

        		int length = 0;
		
					this.moment = readDate(dis);
					
					this.pid = readString(dis);
					
					this.father_pid = readString(dis);
					
					this.root_pid = readString(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.system_pid = null;
           				} else {
           			    	this.system_pid = dis.readLong();
           				}
					
					this.project = readString(dis);
					
					this.job = readString(dis);
					
					this.job_repository_id = readString(dis);
					
					this.job_version = readString(dis);
					
					this.context = readString(dis);
					
					this.origin = readString(dis);
					
					this.label = readString(dis);
					
						this.count = readInteger(dis);
					
						this.reference = readInteger(dis);
					
					this.thresholds = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// java.util.Date
				
						writeDate(this.moment,dos);
					
					// String
				
						writeString(this.pid,dos);
					
					// String
				
						writeString(this.father_pid,dos);
					
					// String
				
						writeString(this.root_pid,dos);
					
					// Long
				
						if(this.system_pid == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeLong(this.system_pid);
		            	}
					
					// String
				
						writeString(this.project,dos);
					
					// String
				
						writeString(this.job,dos);
					
					// String
				
						writeString(this.job_repository_id,dos);
					
					// String
				
						writeString(this.job_version,dos);
					
					// String
				
						writeString(this.context,dos);
					
					// String
				
						writeString(this.origin,dos);
					
					// String
				
						writeString(this.label,dos);
					
					// Integer
				
						writeInteger(this.count,dos);
					
					// Integer
				
						writeInteger(this.reference,dos);
					
					// String
				
						writeString(this.thresholds,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("moment="+String.valueOf(moment));
		sb.append(",pid="+pid);
		sb.append(",father_pid="+father_pid);
		sb.append(",root_pid="+root_pid);
		sb.append(",system_pid="+String.valueOf(system_pid));
		sb.append(",project="+project);
		sb.append(",job="+job);
		sb.append(",job_repository_id="+job_repository_id);
		sb.append(",job_version="+job_version);
		sb.append(",context="+context);
		sb.append(",origin="+origin);
		sb.append(",label="+label);
		sb.append(",count="+String.valueOf(count));
		sb.append(",reference="+String.valueOf(reference));
		sb.append(",thresholds="+thresholds);
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				if(moment == null){
        					sb.append("<null>");
        				}else{
            				sb.append(moment);
            			}
            		
        			sb.append("|");
        		
        				if(pid == null){
        					sb.append("<null>");
        				}else{
            				sb.append(pid);
            			}
            		
        			sb.append("|");
        		
        				if(father_pid == null){
        					sb.append("<null>");
        				}else{
            				sb.append(father_pid);
            			}
            		
        			sb.append("|");
        		
        				if(root_pid == null){
        					sb.append("<null>");
        				}else{
            				sb.append(root_pid);
            			}
            		
        			sb.append("|");
        		
        				if(system_pid == null){
        					sb.append("<null>");
        				}else{
            				sb.append(system_pid);
            			}
            		
        			sb.append("|");
        		
        				if(project == null){
        					sb.append("<null>");
        				}else{
            				sb.append(project);
            			}
            		
        			sb.append("|");
        		
        				if(job == null){
        					sb.append("<null>");
        				}else{
            				sb.append(job);
            			}
            		
        			sb.append("|");
        		
        				if(job_repository_id == null){
        					sb.append("<null>");
        				}else{
            				sb.append(job_repository_id);
            			}
            		
        			sb.append("|");
        		
        				if(job_version == null){
        					sb.append("<null>");
        				}else{
            				sb.append(job_version);
            			}
            		
        			sb.append("|");
        		
        				if(context == null){
        					sb.append("<null>");
        				}else{
            				sb.append(context);
            			}
            		
        			sb.append("|");
        		
        				if(origin == null){
        					sb.append("<null>");
        				}else{
            				sb.append(origin);
            			}
            		
        			sb.append("|");
        		
        				if(label == null){
        					sb.append("<null>");
        				}else{
            				sb.append(label);
            			}
            		
        			sb.append("|");
        		
        				if(count == null){
        					sb.append("<null>");
        				}else{
            				sb.append(count);
            			}
            		
        			sb.append("|");
        		
        				if(reference == null){
        					sb.append("<null>");
        				}else{
            				sb.append(reference);
            			}
            		
        			sb.append("|");
        		
        				if(thresholds == null){
        					sb.append("<null>");
        				}else{
            				sb.append(thresholds);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(row_talendMeter_METTERStruct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}
public void talendMeter_METTERProcess(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("talendMeter_METTER_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
		String currentVirtualComponent = null;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;



		row_talendMeter_METTERStruct row_talendMeter_METTER = new row_talendMeter_METTERStruct();




	
	/**
	 * [talendMeter_CONSOLE begin ] start
	 */

	

	
		
		ok_Hash.put("talendMeter_CONSOLE", false);
		start_Hash.put("talendMeter_CONSOLE", System.currentTimeMillis());
		
	
		currentVirtualComponent = "talendMeter_CONSOLE";
	
	currentComponent="talendMeter_CONSOLE";

	
			if (execStat) {
				if(resourceMap.get("inIterateVComp") == null){
					
						runStat.updateStatOnConnection("Main" + iterateId, 0, 0);
					
				}
			} 

		
		int tos_count_talendMeter_CONSOLE = 0;
		
                if(log.isDebugEnabled())
            log.debug("talendMeter_CONSOLE - "  + ("Start to work.") );
    	class BytesLimit65535_talendMeter_CONSOLE{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_talendMeter_CONSOLE = new StringBuilder();
            log4jParamters_talendMeter_CONSOLE.append("Parameters:");
                    log4jParamters_talendMeter_CONSOLE.append("BASIC_MODE" + " = " + "true");
                log4jParamters_talendMeter_CONSOLE.append(" | ");
                    log4jParamters_talendMeter_CONSOLE.append("TABLE_PRINT" + " = " + "false");
                log4jParamters_talendMeter_CONSOLE.append(" | ");
                    log4jParamters_talendMeter_CONSOLE.append("VERTICAL" + " = " + "false");
                log4jParamters_talendMeter_CONSOLE.append(" | ");
                    log4jParamters_talendMeter_CONSOLE.append("FIELDSEPARATOR" + " = " + "\"|\"");
                log4jParamters_talendMeter_CONSOLE.append(" | ");
                    log4jParamters_talendMeter_CONSOLE.append("PRINT_HEADER" + " = " + "false");
                log4jParamters_talendMeter_CONSOLE.append(" | ");
                    log4jParamters_talendMeter_CONSOLE.append("PRINT_UNIQUE_NAME" + " = " + "false");
                log4jParamters_talendMeter_CONSOLE.append(" | ");
                    log4jParamters_talendMeter_CONSOLE.append("PRINT_COLNAMES" + " = " + "false");
                log4jParamters_talendMeter_CONSOLE.append(" | ");
                    log4jParamters_talendMeter_CONSOLE.append("USE_FIXED_LENGTH" + " = " + "false");
                log4jParamters_talendMeter_CONSOLE.append(" | ");
                    log4jParamters_talendMeter_CONSOLE.append("PRINT_CONTENT_WITH_LOG4J" + " = " + "true");
                log4jParamters_talendMeter_CONSOLE.append(" | ");
                if(log.isDebugEnabled())
            log.debug("talendMeter_CONSOLE - "  + (log4jParamters_talendMeter_CONSOLE) );
    		}
    	}
    	
        new BytesLimit65535_talendMeter_CONSOLE().limitLog4jByte();

	///////////////////////
	
		final String OUTPUT_FIELD_SEPARATOR_talendMeter_CONSOLE = "|";
		java.io.PrintStream consoleOut_talendMeter_CONSOLE = null;	

 		StringBuilder strBuffer_talendMeter_CONSOLE = null;
		int nb_line_talendMeter_CONSOLE = 0;
///////////////////////    			



 



/**
 * [talendMeter_CONSOLE begin ] stop
 */



	
	/**
	 * [talendMeter_METTER begin ] start
	 */

	

	
		
		ok_Hash.put("talendMeter_METTER", false);
		start_Hash.put("talendMeter_METTER", System.currentTimeMillis());
		
	
		currentVirtualComponent = "talendMeter_METTER";
	
	currentComponent="talendMeter_METTER";

	
		int tos_count_talendMeter_METTER = 0;
		
                if(log.isDebugEnabled())
            log.debug("talendMeter_METTER - "  + ("Start to work.") );
    	class BytesLimit65535_talendMeter_METTER{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_talendMeter_METTER = new StringBuilder();
            log4jParamters_talendMeter_METTER.append("Parameters:");
                if(log.isDebugEnabled())
            log.debug("talendMeter_METTER - "  + (log4jParamters_talendMeter_METTER) );
    		}
    	}
    	
        new BytesLimit65535_talendMeter_METTER().limitLog4jByte();

	for (MetterCatcherUtils.MetterCatcherMessage mcm : talendMeter_METTER.getMessages()) {
		row_talendMeter_METTER.pid = pid;
		row_talendMeter_METTER.root_pid = rootPid;
		row_talendMeter_METTER.father_pid = fatherPid;	
        row_talendMeter_METTER.project = projectName;
        row_talendMeter_METTER.job = jobName;
        row_talendMeter_METTER.context = contextStr;
		row_talendMeter_METTER.origin = (mcm.getOrigin()==null || mcm.getOrigin().length()<1 ? null : mcm.getOrigin());
		row_talendMeter_METTER.moment = mcm.getMoment();
		row_talendMeter_METTER.job_version = mcm.getJobVersion();
		row_talendMeter_METTER.job_repository_id = mcm.getJobId();
		row_talendMeter_METTER.system_pid = mcm.getSystemPid();
		row_talendMeter_METTER.label = mcm.getLabel();
		row_talendMeter_METTER.count = mcm.getCount();
		row_talendMeter_METTER.reference = talendMeter_METTER.getConnLinesCount(mcm.getReferense()+"_count");
		row_talendMeter_METTER.thresholds = mcm.getThresholds();
		

 



/**
 * [talendMeter_METTER begin ] stop
 */
	
	/**
	 * [talendMeter_METTER main ] start
	 */

	

	
	
		currentVirtualComponent = "talendMeter_METTER";
	
	currentComponent="talendMeter_METTER";

	

 


	tos_count_talendMeter_METTER++;

/**
 * [talendMeter_METTER main ] stop
 */

	
	/**
	 * [talendMeter_CONSOLE main ] start
	 */

	

	
	
		currentVirtualComponent = "talendMeter_CONSOLE";
	
	currentComponent="talendMeter_CONSOLE";

	

			//Main
			//row_talendMeter_METTER


			
				if(execStat){
					runStat.updateStatOnConnection("Main"+iterateId,1, 1);
				} 
			

		
///////////////////////		
						



				strBuffer_talendMeter_CONSOLE = new StringBuilder();




   				
	    		if(row_talendMeter_METTER.moment != null) { //              
                    							
       
				strBuffer_talendMeter_CONSOLE.append(
								FormatterUtils.format_Date(row_talendMeter_METTER.moment, "yyyy-MM-dd HH:mm:ss")				
				);


							
	    		} //  			

    			strBuffer_talendMeter_CONSOLE.append("|");
    			


   				
	    		if(row_talendMeter_METTER.pid != null) { //              
                    							
       
				strBuffer_talendMeter_CONSOLE.append(
				                String.valueOf(row_talendMeter_METTER.pid)							
				);


							
	    		} //  			

    			strBuffer_talendMeter_CONSOLE.append("|");
    			


   				
	    		if(row_talendMeter_METTER.father_pid != null) { //              
                    							
       
				strBuffer_talendMeter_CONSOLE.append(
				                String.valueOf(row_talendMeter_METTER.father_pid)							
				);


							
	    		} //  			

    			strBuffer_talendMeter_CONSOLE.append("|");
    			


   				
	    		if(row_talendMeter_METTER.root_pid != null) { //              
                    							
       
				strBuffer_talendMeter_CONSOLE.append(
				                String.valueOf(row_talendMeter_METTER.root_pid)							
				);


							
	    		} //  			

    			strBuffer_talendMeter_CONSOLE.append("|");
    			


   				
	    		if(row_talendMeter_METTER.system_pid != null) { //              
                    							
       
				strBuffer_talendMeter_CONSOLE.append(
				                String.valueOf(row_talendMeter_METTER.system_pid)							
				);


							
	    		} //  			

    			strBuffer_talendMeter_CONSOLE.append("|");
    			


   				
	    		if(row_talendMeter_METTER.project != null) { //              
                    							
       
				strBuffer_talendMeter_CONSOLE.append(
				                String.valueOf(row_talendMeter_METTER.project)							
				);


							
	    		} //  			

    			strBuffer_talendMeter_CONSOLE.append("|");
    			


   				
	    		if(row_talendMeter_METTER.job != null) { //              
                    							
       
				strBuffer_talendMeter_CONSOLE.append(
				                String.valueOf(row_talendMeter_METTER.job)							
				);


							
	    		} //  			

    			strBuffer_talendMeter_CONSOLE.append("|");
    			


   				
	    		if(row_talendMeter_METTER.job_repository_id != null) { //              
                    							
       
				strBuffer_talendMeter_CONSOLE.append(
				                String.valueOf(row_talendMeter_METTER.job_repository_id)							
				);


							
	    		} //  			

    			strBuffer_talendMeter_CONSOLE.append("|");
    			


   				
	    		if(row_talendMeter_METTER.job_version != null) { //              
                    							
       
				strBuffer_talendMeter_CONSOLE.append(
				                String.valueOf(row_talendMeter_METTER.job_version)							
				);


							
	    		} //  			

    			strBuffer_talendMeter_CONSOLE.append("|");
    			


   				
	    		if(row_talendMeter_METTER.context != null) { //              
                    							
       
				strBuffer_talendMeter_CONSOLE.append(
				                String.valueOf(row_talendMeter_METTER.context)							
				);


							
	    		} //  			

    			strBuffer_talendMeter_CONSOLE.append("|");
    			


   				
	    		if(row_talendMeter_METTER.origin != null) { //              
                    							
       
				strBuffer_talendMeter_CONSOLE.append(
				                String.valueOf(row_talendMeter_METTER.origin)							
				);


							
	    		} //  			

    			strBuffer_talendMeter_CONSOLE.append("|");
    			


   				
	    		if(row_talendMeter_METTER.label != null) { //              
                    							
       
				strBuffer_talendMeter_CONSOLE.append(
				                String.valueOf(row_talendMeter_METTER.label)							
				);


							
	    		} //  			

    			strBuffer_talendMeter_CONSOLE.append("|");
    			


   				
	    		if(row_talendMeter_METTER.count != null) { //              
                    							
       
				strBuffer_talendMeter_CONSOLE.append(
				                String.valueOf(row_talendMeter_METTER.count)							
				);


							
	    		} //  			

    			strBuffer_talendMeter_CONSOLE.append("|");
    			


   				
	    		if(row_talendMeter_METTER.reference != null) { //              
                    							
       
				strBuffer_talendMeter_CONSOLE.append(
				                String.valueOf(row_talendMeter_METTER.reference)							
				);


							
	    		} //  			

    			strBuffer_talendMeter_CONSOLE.append("|");
    			


   				
	    		if(row_talendMeter_METTER.thresholds != null) { //              
                    							
       
				strBuffer_talendMeter_CONSOLE.append(
				                String.valueOf(row_talendMeter_METTER.thresholds)							
				);


							
	    		} //  			
 

                    if (globalMap.get("tLogRow_CONSOLE")!=null)
                    {
                    	consoleOut_talendMeter_CONSOLE = (java.io.PrintStream) globalMap.get("tLogRow_CONSOLE");
                    }
                    else
                    {
                    	consoleOut_talendMeter_CONSOLE = new java.io.PrintStream(new java.io.BufferedOutputStream(System.out));
                    	globalMap.put("tLogRow_CONSOLE",consoleOut_talendMeter_CONSOLE);
                    }
                    	log.info("talendMeter_CONSOLE - Content of row "+(nb_line_talendMeter_CONSOLE+1)+": " + strBuffer_talendMeter_CONSOLE.toString());
                    consoleOut_talendMeter_CONSOLE.println(strBuffer_talendMeter_CONSOLE.toString());
                    consoleOut_talendMeter_CONSOLE.flush();
                    nb_line_talendMeter_CONSOLE++;
//////

//////                    
                    
///////////////////////    			

 


	tos_count_talendMeter_CONSOLE++;

/**
 * [talendMeter_CONSOLE main ] stop
 */



	
	/**
	 * [talendMeter_METTER end ] start
	 */

	

	
	
		currentVirtualComponent = "talendMeter_METTER";
	
	currentComponent="talendMeter_METTER";

	

	}


 
                if(log.isDebugEnabled())
            log.debug("talendMeter_METTER - "  + ("Done.") );

ok_Hash.put("talendMeter_METTER", true);
end_Hash.put("talendMeter_METTER", System.currentTimeMillis());




/**
 * [talendMeter_METTER end ] stop
 */

	
	/**
	 * [talendMeter_CONSOLE end ] start
	 */

	

	
	
		currentVirtualComponent = "talendMeter_CONSOLE";
	
	currentComponent="talendMeter_CONSOLE";

	


//////
//////
globalMap.put("talendMeter_CONSOLE_NB_LINE",nb_line_talendMeter_CONSOLE);
                if(log.isInfoEnabled())
            log.info("talendMeter_CONSOLE - "  + ("Printed row count: ")  + (nb_line_talendMeter_CONSOLE)  + (".") );

///////////////////////    			

			if(execStat){
				if(resourceMap.get("inIterateVComp") == null || !((Boolean)resourceMap.get("inIterateVComp"))){
			 		runStat.updateStatOnConnection("Main"+iterateId,2, 0); 
			 	}
			}
		
 
                if(log.isDebugEnabled())
            log.debug("talendMeter_CONSOLE - "  + ("Done.") );

ok_Hash.put("talendMeter_CONSOLE", true);
end_Hash.put("talendMeter_CONSOLE", System.currentTimeMillis());




/**
 * [talendMeter_CONSOLE end ] stop
 */



				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage());
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
					te.setVirtualComponentName(currentVirtualComponent);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [talendMeter_METTER finally ] start
	 */

	

	
	
		currentVirtualComponent = "talendMeter_METTER";
	
	currentComponent="talendMeter_METTER";

	

 



/**
 * [talendMeter_METTER finally ] stop
 */

	
	/**
	 * [talendMeter_CONSOLE finally ] start
	 */

	

	
	
		currentVirtualComponent = "talendMeter_CONSOLE";
	
	currentComponent="talendMeter_CONSOLE";

	

 



/**
 * [talendMeter_CONSOLE finally ] stop
 */



				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("talendMeter_METTER_SUBPROCESS_STATE", 1);
	}
	
    public String resuming_logs_dir_path = null;
    public String resuming_checkpoint_path = null;
    public String parent_part_launcher = null;
    private String resumeEntryMethodName = null;
    private boolean globalResumeTicket = false;

    public boolean watch = false;
    // portStats is null, it means don't execute the statistics
    public Integer portStats = null;
    public int portTraces = 4334;
    public String clientHost;
    public String defaultClientHost = "localhost";
    public String contextStr = "SOURCING_DEV";
    public boolean isDefaultContext = true;
    public String pid = "0";
    public String rootPid = null;
    public String fatherPid = null;
    public String fatherNode = null;
    public long startTime = 0;
    public boolean isChildJob = false;
    public String log4jLevel = "";

    private boolean execStat = true;

    private ThreadLocal<java.util.Map<String, String>> threadLocal = new ThreadLocal<java.util.Map<String, String>>() {
        protected java.util.Map<String, String> initialValue() {
            java.util.Map<String,String> threadRunResultMap = new java.util.HashMap<String, String>();
            threadRunResultMap.put("errorCode", null);
            threadRunResultMap.put("status", "");
            return threadRunResultMap;
        };
    };


    private SyncInt runningThreadCount =new SyncInt();

    private class SyncInt
    {
        private int count = 0;
        public synchronized void add(int i)
        {
            count +=i;
        }

        public synchronized int getCount()
        {
            return count;
        }
    }

    private java.util.Properties context_param = new java.util.Properties();
    public java.util.Map<String, Object> parentContextMap = new java.util.HashMap<String, Object>();

    public String status= "";

    public static void main(String[] args){
        final EDL_Base_dynamic EDL_Base_dynamicClass = new EDL_Base_dynamic();

        int exitCode = EDL_Base_dynamicClass.runJobInTOS(args);
	        if(exitCode==0){
		        log.info("TalendJob: 'EDL_Base_dynamic' - Done.");
	        }

        System.exit(exitCode);
    }


    public String[][] runJob(String[] args) {

        int exitCode = runJobInTOS(args);
        String[][] bufferValue = new String[][] { { Integer.toString(exitCode) } };

        return bufferValue;
    }

    public boolean hastBufferOutputComponent() {
		boolean hastBufferOutput = false;
    	
        return hastBufferOutput;
    }

    public int runJobInTOS(String[] args) {
	   	// reset status
	   	status = "";

        String lastStr = "";
        for (String arg : args) {
            if (arg.equalsIgnoreCase("--context_param")) {
                lastStr = arg;
            } else if (lastStr.equals("")) {
                evalParam(arg);
            } else {
                evalParam(lastStr + " " + arg);
                lastStr = "";
            }
        }

	        if(!"".equals(log4jLevel)){
				if("trace".equalsIgnoreCase(log4jLevel)){
					log.setLevel(org.apache.log4j.Level.TRACE);
				}else if("debug".equalsIgnoreCase(log4jLevel)){
					log.setLevel(org.apache.log4j.Level.DEBUG);
				}else if("info".equalsIgnoreCase(log4jLevel)){
					log.setLevel(org.apache.log4j.Level.INFO);
				}else if("warn".equalsIgnoreCase(log4jLevel)){
					log.setLevel(org.apache.log4j.Level.WARN);
				}else if("error".equalsIgnoreCase(log4jLevel)){
					log.setLevel(org.apache.log4j.Level.ERROR);
				}else if("fatal".equalsIgnoreCase(log4jLevel)){
					log.setLevel(org.apache.log4j.Level.FATAL);
				}else if ("off".equalsIgnoreCase(log4jLevel)){
					log.setLevel(org.apache.log4j.Level.OFF);
				}
				org.apache.log4j.Logger.getRootLogger().setLevel(log.getLevel());
    	    }
        	log.info("TalendJob: 'EDL_Base_dynamic' - Start.");
    	

        if(clientHost == null) {
            clientHost = defaultClientHost;
        }

        if(pid == null || "0".equals(pid)) {
            pid = TalendString.getAsciiRandomString(6);
        }

        if (rootPid==null) {
            rootPid = pid;
        }
        if (fatherPid==null) {
            fatherPid = pid;
        }else{
            isChildJob = true;
        }

        if (portStats != null) {
            // portStats = -1; //for testing
            if (portStats < 0 || portStats > 65535) {
                // issue:10869, the portStats is invalid, so this client socket can't open
                System.err.println("The statistics socket port " + portStats + " is invalid.");
                execStat = false;
            }
        } else {
            execStat = false;
        }

        try {
            //call job/subjob with an existing context, like: --context=production. if without this parameter, there will use the default context instead.
            java.io.InputStream inContext = EDL_Base_dynamic.class.getClassLoader().getResourceAsStream("aws_dev_talend_ingestion_framework/edl_base_dynamic_0_1/contexts/"+contextStr+".properties");
            if(isDefaultContext && inContext ==null) {

            } else {
                if (inContext!=null) {
                    //defaultProps is in order to keep the original context value
                    defaultProps.load(inContext);
                    inContext.close();
                    context = new ContextProperties(defaultProps);
                }else{
                    //print info and job continue to run, for case: context_param is not empty.
                    System.err.println("Could not find the context " + contextStr);
                }
            }

            if(!context_param.isEmpty()) {
                context.putAll(context_param);
            }
                context.GP_SOURCE_NAME=(String) context.getProperty("GP_SOURCE_NAME");
                context.TABLE_NAME=(String) context.getProperty("TABLE_NAME");
                context.FORCE_DROP=(String) context.getProperty("FORCE_DROP");
                context.FORCE_BATCH=(String) context.getProperty("FORCE_BATCH");
                context.LOAD2HDFS=(String) context.getProperty("LOAD2HDFS");
                context.SOURCE_HOST=(String) context.getProperty("SOURCE_HOST");
                context.SOURCE_DATABASE=(String) context.getProperty("SOURCE_DATABASE");
                context.SOURCE_USER=(String) context.getProperty("SOURCE_USER");
             try{
                 context.SOURCE_PORT=routines.system.ParserUtils.parseTo_Integer (context.getProperty("SOURCE_PORT"));
             }catch(NumberFormatException e){
                 context.SOURCE_PORT=null;
              }
                context.SOURCE_PASSWORD=(String) context.getProperty("SOURCE_PASSWORD");
             try{
                 context.TOP_N_ROWS=routines.system.ParserUtils.parseTo_Integer (context.getProperty("TOP_N_ROWS"));
             }catch(NumberFormatException e){
                 context.TOP_N_ROWS=null;
              }
             try{
                 context.THREAD=routines.system.ParserUtils.parseTo_Integer (context.getProperty("THREAD"));
             }catch(NumberFormatException e){
                 context.THREAD=null;
              }
             try{
                 context.RUN_ID=routines.system.ParserUtils.parseTo_Integer (context.getProperty("RUN_ID"));
             }catch(NumberFormatException e){
                 context.RUN_ID=null;
              }
                context.PROD2DEV=(String) context.getProperty("PROD2DEV");
                context.SEND_MAIL=(String) context.getProperty("SEND_MAIL");
                context.PUBLIC=(String) context.getProperty("PUBLIC");
                context.PYTHON_NEEDED=(String) context.getProperty("PYTHON_NEEDED");
                context.mail_to_error=(String) context.getProperty("mail_to_error");
                context.JOB_LABEL_NAME=(String) context.getProperty("JOB_LABEL_NAME");
                context.PLANT_NAME=(String) context.getProperty("PLANT_NAME");
             try{
                 context.LOG_NO_OF_ERRORS=routines.system.ParserUtils.parseTo_Integer (context.getProperty("LOG_NO_OF_ERRORS"));
             }catch(NumberFormatException e){
                 context.LOG_NO_OF_ERRORS=null;
              }
                context.LOG_PLANT_NAME=(String) context.getProperty("LOG_PLANT_NAME");
             try{
                 context.LOG_NO_OF_UPDATES=routines.system.ParserUtils.parseTo_Integer (context.getProperty("LOG_NO_OF_UPDATES"));
             }catch(NumberFormatException e){
                 context.LOG_NO_OF_UPDATES=null;
              }
             try{
                 context.LOG_SOURCE_ROW_COUNT=routines.system.ParserUtils.parseTo_Integer (context.getProperty("LOG_SOURCE_ROW_COUNT"));
             }catch(NumberFormatException e){
                 context.LOG_SOURCE_ROW_COUNT=null;
              }
                context.LOG_TECHNOLOGY=(String) context.getProperty("LOG_TECHNOLOGY");
                context.LOG_TABLE_NAME=(String) context.getProperty("LOG_TABLE_NAME");
             try{
                 context.LOG_NO_OF_INSERTS=routines.system.ParserUtils.parseTo_Integer (context.getProperty("LOG_NO_OF_INSERTS"));
             }catch(NumberFormatException e){
                 context.LOG_NO_OF_INSERTS=null;
              }
                context.LOG_DATA_PATH=(String) context.getProperty("LOG_DATA_PATH");
             try{
                 context.LOG_NO_OF_DELETES=routines.system.ParserUtils.parseTo_Integer (context.getProperty("LOG_NO_OF_DELETES"));
             }catch(NumberFormatException e){
                 context.LOG_NO_OF_DELETES=null;
              }
             try{
                 context.LOG_RUN_ID=routines.system.ParserUtils.parseTo_Integer (context.getProperty("LOG_RUN_ID"));
             }catch(NumberFormatException e){
                 context.LOG_RUN_ID=null;
              }
                context.LOG_ERROR_CATEGORY=(String) context.getProperty("LOG_ERROR_CATEGORY");
                context.LOG_JOB_NAME=(String) context.getProperty("LOG_JOB_NAME");
                context.LOG_SYSTEM_NAME=(String) context.getProperty("LOG_SYSTEM_NAME");
                context.LOG_MESSAGE=(String) context.getProperty("LOG_MESSAGE");
             try{
                 context.LOG_TARGET_ROW_COUNT=routines.system.ParserUtils.parseTo_Integer (context.getProperty("LOG_TARGET_ROW_COUNT"));
             }catch(NumberFormatException e){
                 context.LOG_TARGET_ROW_COUNT=null;
              }
                context.LOG_STATUS=(String) context.getProperty("LOG_STATUS");
            		String pwd_PRIVATE_KEY_value = context.getProperty("PRIVATE_KEY");
            		context.PRIVATE_KEY = null;
            		if(pwd_PRIVATE_KEY_value!=null) {
            			if(context_param.containsKey("PRIVATE_KEY")) {//no need to decrypt if it come from program argument or parent job runtime
            				context.PRIVATE_KEY = pwd_PRIVATE_KEY_value;
            			} else if (!pwd_PRIVATE_KEY_value.isEmpty()) {
            				try {
            					context.PRIVATE_KEY = routines.system.PasswordEncryptUtil.decryptPassword(pwd_PRIVATE_KEY_value);
            					context.put("PRIVATE_KEY",context.PRIVATE_KEY);
            				} catch (java.lang.RuntimeException e) {
            					//do nothing
            				}
            			}
            		}
             try{
                 context.CURSOR_SIZE=routines.system.ParserUtils.parseTo_Integer (context.getProperty("CURSOR_SIZE"));
             }catch(NumberFormatException e){
                 context.CURSOR_SIZE=null;
              }
             try{
                 context.PROD2DEV_THREADS=routines.system.ParserUtils.parseTo_Integer (context.getProperty("PROD2DEV_THREADS"));
             }catch(NumberFormatException e){
                 context.PROD2DEV_THREADS=null;
              }
                context.MAIL_TO=(String) context.getProperty("MAIL_TO");
                context.IGNORE_TIMEZONE=(String) context.getProperty("IGNORE_TIMEZONE");
                context.RECREATE_SCHEMA=(String) context.getProperty("RECREATE_SCHEMA");
                context.DB_VERSION=(String) context.getProperty("DB_VERSION");
                context.IS_MULTITHREAD_BY_TABLE=(String) context.getProperty("IS_MULTITHREAD_BY_TABLE");
                context.OSPASSWORD=(String) context.getProperty("OSPASSWORD");
                context.OSUSER=(String) context.getProperty("OSUSER");
                context.PYTHON_HOST=(String) context.getProperty("PYTHON_HOST");
                context.PYTHON_PATH=(String) context.getProperty("PYTHON_PATH");
                context.ETL_LOCALHOSTNAME=(String) context.getProperty("ETL_LOCALHOSTNAME");
                context.ETL_STORAGE_PATH=(String) context.getProperty("ETL_STORAGE_PATH");
                context.HAWQ_Source_Ports=(String) context.getProperty("HAWQ_Source_Ports");
                context.SOURCING_Database=(String) context.getProperty("SOURCING_Database");
                context.SOURCING_Login=(String) context.getProperty("SOURCING_Login");
            		String pwd_SOURCING_Password_value = context.getProperty("SOURCING_Password");
            		context.SOURCING_Password = null;
            		if(pwd_SOURCING_Password_value!=null) {
            			if(context_param.containsKey("SOURCING_Password")) {//no need to decrypt if it come from program argument or parent job runtime
            				context.SOURCING_Password = pwd_SOURCING_Password_value;
            			} else if (!pwd_SOURCING_Password_value.isEmpty()) {
            				try {
            					context.SOURCING_Password = routines.system.PasswordEncryptUtil.decryptPassword(pwd_SOURCING_Password_value);
            					context.put("SOURCING_Password",context.SOURCING_Password);
            				} catch (java.lang.RuntimeException e) {
            					//do nothing
            				}
            			}
            		}
                context.SOURCING_Port=(String) context.getProperty("SOURCING_Port");
                context.SOURCING_Schema=(String) context.getProperty("SOURCING_Schema");
                context.SOURCING_Server=(String) context.getProperty("SOURCING_Server");
        } catch (java.io.IOException ie) {
            System.err.println("Could not load context "+contextStr);
            ie.printStackTrace();
        }


        // get context value from parent directly
        if (parentContextMap != null && !parentContextMap.isEmpty()) {if (parentContextMap.containsKey("GP_SOURCE_NAME")) {
                context.GP_SOURCE_NAME = (String) parentContextMap.get("GP_SOURCE_NAME");
            }if (parentContextMap.containsKey("TABLE_NAME")) {
                context.TABLE_NAME = (String) parentContextMap.get("TABLE_NAME");
            }if (parentContextMap.containsKey("FORCE_DROP")) {
                context.FORCE_DROP = (String) parentContextMap.get("FORCE_DROP");
            }if (parentContextMap.containsKey("FORCE_BATCH")) {
                context.FORCE_BATCH = (String) parentContextMap.get("FORCE_BATCH");
            }if (parentContextMap.containsKey("LOAD2HDFS")) {
                context.LOAD2HDFS = (String) parentContextMap.get("LOAD2HDFS");
            }if (parentContextMap.containsKey("SOURCE_HOST")) {
                context.SOURCE_HOST = (String) parentContextMap.get("SOURCE_HOST");
            }if (parentContextMap.containsKey("SOURCE_DATABASE")) {
                context.SOURCE_DATABASE = (String) parentContextMap.get("SOURCE_DATABASE");
            }if (parentContextMap.containsKey("SOURCE_USER")) {
                context.SOURCE_USER = (String) parentContextMap.get("SOURCE_USER");
            }if (parentContextMap.containsKey("SOURCE_PORT")) {
                context.SOURCE_PORT = (Integer) parentContextMap.get("SOURCE_PORT");
            }if (parentContextMap.containsKey("SOURCE_PASSWORD")) {
                context.SOURCE_PASSWORD = (String) parentContextMap.get("SOURCE_PASSWORD");
            }if (parentContextMap.containsKey("TOP_N_ROWS")) {
                context.TOP_N_ROWS = (Integer) parentContextMap.get("TOP_N_ROWS");
            }if (parentContextMap.containsKey("THREAD")) {
                context.THREAD = (Integer) parentContextMap.get("THREAD");
            }if (parentContextMap.containsKey("RUN_ID")) {
                context.RUN_ID = (Integer) parentContextMap.get("RUN_ID");
            }if (parentContextMap.containsKey("PROD2DEV")) {
                context.PROD2DEV = (String) parentContextMap.get("PROD2DEV");
            }if (parentContextMap.containsKey("SEND_MAIL")) {
                context.SEND_MAIL = (String) parentContextMap.get("SEND_MAIL");
            }if (parentContextMap.containsKey("PUBLIC")) {
                context.PUBLIC = (String) parentContextMap.get("PUBLIC");
            }if (parentContextMap.containsKey("PYTHON_NEEDED")) {
                context.PYTHON_NEEDED = (String) parentContextMap.get("PYTHON_NEEDED");
            }if (parentContextMap.containsKey("mail_to_error")) {
                context.mail_to_error = (String) parentContextMap.get("mail_to_error");
            }if (parentContextMap.containsKey("JOB_LABEL_NAME")) {
                context.JOB_LABEL_NAME = (String) parentContextMap.get("JOB_LABEL_NAME");
            }if (parentContextMap.containsKey("PLANT_NAME")) {
                context.PLANT_NAME = (String) parentContextMap.get("PLANT_NAME");
            }if (parentContextMap.containsKey("LOG_NO_OF_ERRORS")) {
                context.LOG_NO_OF_ERRORS = (Integer) parentContextMap.get("LOG_NO_OF_ERRORS");
            }if (parentContextMap.containsKey("LOG_PLANT_NAME")) {
                context.LOG_PLANT_NAME = (String) parentContextMap.get("LOG_PLANT_NAME");
            }if (parentContextMap.containsKey("LOG_NO_OF_UPDATES")) {
                context.LOG_NO_OF_UPDATES = (Integer) parentContextMap.get("LOG_NO_OF_UPDATES");
            }if (parentContextMap.containsKey("LOG_SOURCE_ROW_COUNT")) {
                context.LOG_SOURCE_ROW_COUNT = (Integer) parentContextMap.get("LOG_SOURCE_ROW_COUNT");
            }if (parentContextMap.containsKey("LOG_TECHNOLOGY")) {
                context.LOG_TECHNOLOGY = (String) parentContextMap.get("LOG_TECHNOLOGY");
            }if (parentContextMap.containsKey("LOG_TABLE_NAME")) {
                context.LOG_TABLE_NAME = (String) parentContextMap.get("LOG_TABLE_NAME");
            }if (parentContextMap.containsKey("LOG_NO_OF_INSERTS")) {
                context.LOG_NO_OF_INSERTS = (Integer) parentContextMap.get("LOG_NO_OF_INSERTS");
            }if (parentContextMap.containsKey("LOG_DATA_PATH")) {
                context.LOG_DATA_PATH = (String) parentContextMap.get("LOG_DATA_PATH");
            }if (parentContextMap.containsKey("LOG_NO_OF_DELETES")) {
                context.LOG_NO_OF_DELETES = (Integer) parentContextMap.get("LOG_NO_OF_DELETES");
            }if (parentContextMap.containsKey("LOG_RUN_ID")) {
                context.LOG_RUN_ID = (Integer) parentContextMap.get("LOG_RUN_ID");
            }if (parentContextMap.containsKey("LOG_ERROR_CATEGORY")) {
                context.LOG_ERROR_CATEGORY = (String) parentContextMap.get("LOG_ERROR_CATEGORY");
            }if (parentContextMap.containsKey("LOG_JOB_NAME")) {
                context.LOG_JOB_NAME = (String) parentContextMap.get("LOG_JOB_NAME");
            }if (parentContextMap.containsKey("LOG_SYSTEM_NAME")) {
                context.LOG_SYSTEM_NAME = (String) parentContextMap.get("LOG_SYSTEM_NAME");
            }if (parentContextMap.containsKey("LOG_MESSAGE")) {
                context.LOG_MESSAGE = (String) parentContextMap.get("LOG_MESSAGE");
            }if (parentContextMap.containsKey("LOG_TARGET_ROW_COUNT")) {
                context.LOG_TARGET_ROW_COUNT = (Integer) parentContextMap.get("LOG_TARGET_ROW_COUNT");
            }if (parentContextMap.containsKey("LOG_STATUS")) {
                context.LOG_STATUS = (String) parentContextMap.get("LOG_STATUS");
            }if (parentContextMap.containsKey("PRIVATE_KEY")) {
                context.PRIVATE_KEY = (java.lang.String) parentContextMap.get("PRIVATE_KEY");
            }if (parentContextMap.containsKey("CURSOR_SIZE")) {
                context.CURSOR_SIZE = (Integer) parentContextMap.get("CURSOR_SIZE");
            }if (parentContextMap.containsKey("PROD2DEV_THREADS")) {
                context.PROD2DEV_THREADS = (Integer) parentContextMap.get("PROD2DEV_THREADS");
            }if (parentContextMap.containsKey("MAIL_TO")) {
                context.MAIL_TO = (String) parentContextMap.get("MAIL_TO");
            }if (parentContextMap.containsKey("IGNORE_TIMEZONE")) {
                context.IGNORE_TIMEZONE = (String) parentContextMap.get("IGNORE_TIMEZONE");
            }if (parentContextMap.containsKey("RECREATE_SCHEMA")) {
                context.RECREATE_SCHEMA = (String) parentContextMap.get("RECREATE_SCHEMA");
            }if (parentContextMap.containsKey("DB_VERSION")) {
                context.DB_VERSION = (String) parentContextMap.get("DB_VERSION");
            }if (parentContextMap.containsKey("IS_MULTITHREAD_BY_TABLE")) {
                context.IS_MULTITHREAD_BY_TABLE = (String) parentContextMap.get("IS_MULTITHREAD_BY_TABLE");
            }if (parentContextMap.containsKey("OSPASSWORD")) {
                context.OSPASSWORD = (String) parentContextMap.get("OSPASSWORD");
            }if (parentContextMap.containsKey("OSUSER")) {
                context.OSUSER = (String) parentContextMap.get("OSUSER");
            }if (parentContextMap.containsKey("PYTHON_HOST")) {
                context.PYTHON_HOST = (String) parentContextMap.get("PYTHON_HOST");
            }if (parentContextMap.containsKey("PYTHON_PATH")) {
                context.PYTHON_PATH = (String) parentContextMap.get("PYTHON_PATH");
            }if (parentContextMap.containsKey("ETL_LOCALHOSTNAME")) {
                context.ETL_LOCALHOSTNAME = (String) parentContextMap.get("ETL_LOCALHOSTNAME");
            }if (parentContextMap.containsKey("ETL_STORAGE_PATH")) {
                context.ETL_STORAGE_PATH = (String) parentContextMap.get("ETL_STORAGE_PATH");
            }if (parentContextMap.containsKey("HAWQ_Source_Ports")) {
                context.HAWQ_Source_Ports = (String) parentContextMap.get("HAWQ_Source_Ports");
            }if (parentContextMap.containsKey("SOURCING_Database")) {
                context.SOURCING_Database = (String) parentContextMap.get("SOURCING_Database");
            }if (parentContextMap.containsKey("SOURCING_Login")) {
                context.SOURCING_Login = (String) parentContextMap.get("SOURCING_Login");
            }if (parentContextMap.containsKey("SOURCING_Password")) {
                context.SOURCING_Password = (java.lang.String) parentContextMap.get("SOURCING_Password");
            }if (parentContextMap.containsKey("SOURCING_Port")) {
                context.SOURCING_Port = (String) parentContextMap.get("SOURCING_Port");
            }if (parentContextMap.containsKey("SOURCING_Schema")) {
                context.SOURCING_Schema = (String) parentContextMap.get("SOURCING_Schema");
            }if (parentContextMap.containsKey("SOURCING_Server")) {
                context.SOURCING_Server = (String) parentContextMap.get("SOURCING_Server");
            }
        }

        //Resume: init the resumeUtil
        resumeEntryMethodName = ResumeUtil.getResumeEntryMethodName(resuming_checkpoint_path);
        resumeUtil = new ResumeUtil(resuming_logs_dir_path, isChildJob, rootPid);
        resumeUtil.initCommonInfo(pid, rootPid, fatherPid, projectName, jobName, contextStr, jobVersion);

		List<String> parametersToEncrypt = new java.util.ArrayList<String>();
			parametersToEncrypt.add("PRIVATE_KEY");
			parametersToEncrypt.add("SOURCING_Password");
        //Resume: jobStart
        resumeUtil.addLog("JOB_STARTED", "JOB:" + jobName, parent_part_launcher, Thread.currentThread().getId() + "", "","","","",resumeUtil.convertToJsonText(context,parametersToEncrypt));

if(execStat) {
    try {
        runStat.openSocket(!isChildJob);
        runStat.setAllPID(rootPid, fatherPid, pid, jobName);
        runStat.startThreadStat(clientHost, portStats);
        runStat.updateStatOnJob(RunStat.JOBSTART, fatherNode);
    } catch (java.io.IOException ioException) {
        ioException.printStackTrace();
    }
}



	
	    java.util.concurrent.ConcurrentHashMap<Object, Object> concurrentHashMap = new java.util.concurrent.ConcurrentHashMap<Object, Object>();
	    globalMap.put("concurrentHashMap", concurrentHashMap);
	

    long startUsedMemory = Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory();
    long endUsedMemory = 0;
    long end = 0;

    startTime = System.currentTimeMillis();
        talendStats_STATS.addMessage("begin");


this.globalResumeTicket = true;//to run tPreJob



        try {
            talendStats_STATSProcess(globalMap);
        } catch (java.lang.Exception e) {
            e.printStackTrace();
        }

this.globalResumeTicket = false;//to run others jobs
final Thread launchingThread = Thread.currentThread();
        runningThreadCount.add(1);
        new Thread(){
            public void run() {
                java.util.Map threadRunResultMap = new java.util.HashMap();
                threadRunResultMap.put("errorCode", null);
                threadRunResultMap.put("status", "");
                threadLocal.set(threadRunResultMap);

                try {
((java.util.Map) threadLocal.get()).put("errorCode", null);tSetGlobalVar_3Process(globalMap);
if ( !"failure".equals(((java.util.Map)threadLocal.get()).get("status")) ) {
((java.util.Map) threadLocal.get()).put("status", "end");
}
}catch (TalendException e_tSetGlobalVar_3) {
globalMap.put("tSetGlobalVar_3_SUBPROCESS_STATE", -1);

e_tSetGlobalVar_3.printStackTrace();

}catch (java.lang.Error e_tSetGlobalVar_3) {
globalMap.put("tSetGlobalVar_3_SUBPROCESS_STATE", -1);
((java.util.Map) threadLocal.get()).put("status", "failure");throw e_tSetGlobalVar_3;

}
                finally {
                    Integer localErrorCode = (Integer)(((java.util.Map)threadLocal.get()).get("errorCode"));
                    String localStatus = (String)(((java.util.Map)threadLocal.get()).get("status"));
                    if (localErrorCode != null) {
                        if (errorCode == null || localErrorCode.compareTo(errorCode) > 0) {
                           errorCode = localErrorCode;
                        }
                    }
                    if (!status.equals("failure")){
                        status = localStatus;
                    }

                    if ("true".equals(((java.util.Map) threadLocal.get()).get("JobInterrupted"))) {
                        launchingThread.interrupt();
                    }

                    runningThreadCount.add(-1);
                }
            }
        }.start();

    boolean interrupted = false;
    while (runningThreadCount.getCount() > 0) {
        try {
            Thread.sleep(10);
        } catch (java.lang.InterruptedException e) {
            interrupted = true;
        } catch (java.lang.Exception e) {
            e.printStackTrace();
        }
    }

    if (interrupted) {
        Thread.currentThread().interrupt();
    }



this.globalResumeTicket = true;//to run tPostJob




        end = System.currentTimeMillis();

        if (watch) {
            System.out.println((end-startTime)+" milliseconds");
        }

        endUsedMemory = Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory();
        if (false) {
            System.out.println((endUsedMemory - startUsedMemory) + " bytes memory increase when running : EDL_Base_dynamic");
        }
        talendStats_STATS.addMessage(status==""?"end":status, (end-startTime));
        try {
            talendStats_STATSProcess(globalMap);
        } catch (java.lang.Exception e) {
            e.printStackTrace();
        }





if (execStat) {
    runStat.updateStatOnJob(RunStat.JOBEND, fatherNode);
    runStat.stopThreadStat();
}
    int returnCode = 0;
    if(errorCode == null) {
         returnCode = status != null && status.equals("failure") ? 1 : 0;
    } else {
         returnCode = errorCode.intValue();
    }
    resumeUtil.addLog("JOB_ENDED", "JOB:" + jobName, parent_part_launcher, Thread.currentThread().getId() + "", "","" + returnCode,"","","");

    return returnCode;

  }

    // only for OSGi env
    public void destroy() {
    closeSqlDbConnections();


    }



    private void closeSqlDbConnections() {
        try {
            Object obj_conn;
            obj_conn = globalMap.remove("conn_tGreenplumConnection_1");
            if (null != obj_conn) {
                ((java.sql.Connection) obj_conn).close();
            }
            obj_conn = globalMap.remove("conn_tGreenplumConnection_2");
            if (null != obj_conn) {
                ((java.sql.Connection) obj_conn).close();
            }
            obj_conn = globalMap.remove("conn_tGreenplumConnection_4");
            if (null != obj_conn) {
                ((java.sql.Connection) obj_conn).close();
            }
            obj_conn = globalMap.remove("conn_tGreenplumConnection_3");
            if (null != obj_conn) {
                ((java.sql.Connection) obj_conn).close();
            }
            obj_conn = globalMap.remove("conn_tGreenplumConnection_6");
            if (null != obj_conn) {
                ((java.sql.Connection) obj_conn).close();
            }
        } catch (java.lang.Exception e) {
        }
    }

		









    private java.util.Map<String, Object> getSharedConnections4REST() {
        java.util.Map<String, Object> connections = new java.util.HashMap<String, Object>();
            connections.put("conn_tGreenplumConnection_1", globalMap.get("conn_tGreenplumConnection_1"));
            connections.put("conn_tGreenplumConnection_2", globalMap.get("conn_tGreenplumConnection_2"));
            connections.put("conn_tGreenplumConnection_4", globalMap.get("conn_tGreenplumConnection_4"));
            connections.put("conn_tGreenplumConnection_3", globalMap.get("conn_tGreenplumConnection_3"));
            connections.put("conn_tGreenplumConnection_6", globalMap.get("conn_tGreenplumConnection_6"));






        return connections;
    }

    private void evalParam(String arg) {
        if (arg.startsWith("--resuming_logs_dir_path")) {
            resuming_logs_dir_path = arg.substring(25);
        } else if (arg.startsWith("--resuming_checkpoint_path")) {
            resuming_checkpoint_path = arg.substring(27);
        } else if (arg.startsWith("--parent_part_launcher")) {
            parent_part_launcher = arg.substring(23);
        } else if (arg.startsWith("--watch")) {
            watch = true;
        } else if (arg.startsWith("--stat_port=")) {
            String portStatsStr = arg.substring(12);
            if (portStatsStr != null && !portStatsStr.equals("null")) {
                portStats = Integer.parseInt(portStatsStr);
            }
        } else if (arg.startsWith("--trace_port=")) {
            portTraces = Integer.parseInt(arg.substring(13));
        } else if (arg.startsWith("--client_host=")) {
            clientHost = arg.substring(14);
        } else if (arg.startsWith("--context=")) {
            contextStr = arg.substring(10);
            isDefaultContext = false;
        } else if (arg.startsWith("--father_pid=")) {
            fatherPid = arg.substring(13);
        } else if (arg.startsWith("--root_pid=")) {
            rootPid = arg.substring(11);
        } else if (arg.startsWith("--father_node=")) {
            fatherNode = arg.substring(14);
        } else if (arg.startsWith("--pid=")) {
            pid = arg.substring(6);
        } else if (arg.startsWith("--context_param")) {
            String keyValue = arg.substring(16);
            int index = -1;
            if (keyValue != null && (index = keyValue.indexOf('=')) > -1) {
                if (fatherPid==null) {
                    context_param.put(keyValue.substring(0, index), replaceEscapeChars(keyValue.substring(index + 1)));
                } else { // the subjob won't escape the especial chars
                    context_param.put(keyValue.substring(0, index), keyValue.substring(index + 1) );
                }
            }
        }else if (arg.startsWith("--log4jLevel=")) {
            log4jLevel = arg.substring(13);
		}

    }

    private final String[][] escapeChars = {
        {"\\\\","\\"},{"\\n","\n"},{"\\'","\'"},{"\\r","\r"},
        {"\\f","\f"},{"\\b","\b"},{"\\t","\t"}
        };
    private String replaceEscapeChars (String keyValue) {

		if (keyValue == null || ("").equals(keyValue.trim())) {
			return keyValue;
		}

		StringBuilder result = new StringBuilder();
		int currIndex = 0;
		while (currIndex < keyValue.length()) {
			int index = -1;
			// judege if the left string includes escape chars
			for (String[] strArray : escapeChars) {
				index = keyValue.indexOf(strArray[0],currIndex);
				if (index>=0) {

					result.append(keyValue.substring(currIndex, index + strArray[0].length()).replace(strArray[0], strArray[1]));
					currIndex = index + strArray[0].length();
					break;
				}
			}
			// if the left string doesn't include escape chars, append the left into the result
			if (index < 0) {
				result.append(keyValue.substring(currIndex));
				currIndex = currIndex + keyValue.length();
			}
		}

		return result.toString();
    }

    public Integer getErrorCode() {
        return errorCode;
    }


    public String getStatus() {
        return status;
    }

    ResumeUtil resumeUtil = null;
}
/************************************************************************************************
 *     538826 characters generated by Talend Real-time Big Data Platform 
 *     on the October 19, 2018 3:30:30 PM CDT
 ************************************************************************************************/