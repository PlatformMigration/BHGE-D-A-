
package aws_dev_talend_ingestion_framework.as400_to_greenplum_with_gpload_0_1;

import routines.GEPostgreSQLViewConverter;
import routines.DataOperation;
import routines.TalendDataGenerator;
import routines.GEDynamicRoutine;
import routines.DataQuality;
import routines.GEDynamicRoutine_masking;
import routines.Relational;
import routines.GEroutines;
import routines.Mathematical;
import routines.DataQualityDependencies;
import routines.SQLike;
import routines.DataTypeMaps;
import routines.Numeric;
import routines.TalendString;
import routines.TransformMetadata;
import routines.StringHandling;
import routines.DQTechnical;
import routines.MDM;
import routines.TalendDate;
import routines.DataMasking;
import routines.DqStringHandling;
import routines.PopulateFromDynamic;
import routines.GPLoadRoutine;
import routines.system.*;
import routines.system.api.*;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.math.BigDecimal;
import java.io.ByteArrayOutputStream;
import java.io.ByteArrayInputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.ObjectOutputStream;
import java.io.ObjectInputStream;
import java.io.IOException;
import java.util.Comparator;
 




	//the import part of tJava_1
	//import java.util.List;

	//the import part of tJava_4
	//import java.util.List;

	//the import part of tJava_5
	//import java.util.List;

	//the import part of tJavaRow_2
	//import java.util.List;

	//the import part of tJavaRow_1
	//import java.util.List;

	//the import part of tJava_2
	//import java.util.List;

	//the import part of tJava_3
	//import java.util.List;


@SuppressWarnings("unused")

/**
 * Job: AS400_to_greenplum_with_GPLoad Purpose: <br>
 * Description:  <br>
 * @author Talend, admin
 * @version 6.3.1.20161216_1026
 * @status 
 */
public class AS400_to_greenplum_with_GPLoad implements TalendJob {
	static {System.setProperty("TalendJob.log", "AS400_to_greenplum_with_GPLoad.log");}
	private static org.apache.log4j.Logger log = org.apache.log4j.Logger.getLogger(AS400_to_greenplum_with_GPLoad.class);



	public final Object obj = new Object();

	// for transmiting parameters purpose
	private Object valueObject = null;

	public Object getValueObject() {
		return this.valueObject;
	}

	public void setValueObject(Object valueObject) {
		this.valueObject = valueObject;
	}
	
	private final static String defaultCharset = java.nio.charset.Charset.defaultCharset().name();

	
	private final static String utf8Charset = "UTF-8";

	// create and load default properties
	private java.util.Properties defaultProps = new java.util.Properties();
	// create application properties with default
	public class ContextProperties extends java.util.Properties {

		private static final long serialVersionUID = 1L;

		public ContextProperties(java.util.Properties properties){
			super(properties);
		}
		public ContextProperties(){
			super();
		}

		public void synchronizeContext(){
			
			if(SOURCE_HOST != null){
				
					this.setProperty("SOURCE_HOST", SOURCE_HOST.toString());
				
			}
			
			if(SOURCE_DATABASE != null){
				
					this.setProperty("SOURCE_DATABASE", SOURCE_DATABASE.toString());
				
			}
			
			if(SOURCE_USER != null){
				
					this.setProperty("SOURCE_USER", SOURCE_USER.toString());
				
			}
			
			if(SOURCE_PORT != null){
				
					this.setProperty("SOURCE_PORT", SOURCE_PORT.toString());
				
			}
			
			if(SOURCE_PASSWORD != null){
				
					this.setProperty("SOURCE_PASSWORD", SOURCE_PASSWORD.toString());
				
			}
			
			if(GP_SOURCE_NAME != null){
				
					this.setProperty("GP_SOURCE_NAME", GP_SOURCE_NAME.toString());
				
			}
			
			if(TABLE_NAME != null){
				
					this.setProperty("TABLE_NAME", TABLE_NAME.toString());
				
			}
			
			if(ETL_LOCALHOSTNAME != null){
				
					this.setProperty("ETL_LOCALHOSTNAME", ETL_LOCALHOSTNAME.toString());
				
			}
			
			if(HAWQ_Source_Ports != null){
				
					this.setProperty("HAWQ_Source_Ports", HAWQ_Source_Ports.toString());
				
			}
			
			if(ETL_STORAGE_PATH != null){
				
					this.setProperty("ETL_STORAGE_PATH", ETL_STORAGE_PATH.toString());
				
			}
			
			if(FORCE_DROP != null){
				
					this.setProperty("FORCE_DROP", FORCE_DROP.toString());
				
			}
			
			if(LOAD2HDFS != null){
				
					this.setProperty("LOAD2HDFS", LOAD2HDFS.toString());
				
			}
			
			if(SOURCING_Server != null){
				
					this.setProperty("SOURCING_Server", SOURCING_Server.toString());
				
			}
			
			if(SOURCING_Login != null){
				
					this.setProperty("SOURCING_Login", SOURCING_Login.toString());
				
			}
			
			if(SOURCING_Password != null){
				
					this.setProperty("SOURCING_Password", SOURCING_Password.toString());
				
			}
			
			if(SOURCING_Port != null){
				
					this.setProperty("SOURCING_Port", SOURCING_Port.toString());
				
			}
			
			if(SOURCING_Schema != null){
				
					this.setProperty("SOURCING_Schema", SOURCING_Schema.toString());
				
			}
			
			if(SOURCING_Database != null){
				
					this.setProperty("SOURCING_Database", SOURCING_Database.toString());
				
			}
			
			if(TOP_N_ROWS != null){
				
					this.setProperty("TOP_N_ROWS", TOP_N_ROWS.toString());
				
			}
			
			if(FORCE_BATCH != null){
				
					this.setProperty("FORCE_BATCH", FORCE_BATCH.toString());
				
			}
			
			if(RUN_ID != null){
				
					this.setProperty("RUN_ID", RUN_ID.toString());
				
			}
			
		}

public String SOURCE_HOST;
public String getSOURCE_HOST(){
	return this.SOURCE_HOST;
}
public String SOURCE_DATABASE;
public String getSOURCE_DATABASE(){
	return this.SOURCE_DATABASE;
}
public String SOURCE_USER;
public String getSOURCE_USER(){
	return this.SOURCE_USER;
}
public Integer SOURCE_PORT;
public Integer getSOURCE_PORT(){
	return this.SOURCE_PORT;
}
public java.lang.String SOURCE_PASSWORD;
public java.lang.String getSOURCE_PASSWORD(){
	return this.SOURCE_PASSWORD;
}
public String GP_SOURCE_NAME;
public String getGP_SOURCE_NAME(){
	return this.GP_SOURCE_NAME;
}
public String TABLE_NAME;
public String getTABLE_NAME(){
	return this.TABLE_NAME;
}
public String ETL_LOCALHOSTNAME;
public String getETL_LOCALHOSTNAME(){
	return this.ETL_LOCALHOSTNAME;
}
public String HAWQ_Source_Ports;
public String getHAWQ_Source_Ports(){
	return this.HAWQ_Source_Ports;
}
public String ETL_STORAGE_PATH;
public String getETL_STORAGE_PATH(){
	return this.ETL_STORAGE_PATH;
}
public String FORCE_DROP;
public String getFORCE_DROP(){
	return this.FORCE_DROP;
}
public String LOAD2HDFS;
public String getLOAD2HDFS(){
	return this.LOAD2HDFS;
}
public String SOURCING_Server;
public String getSOURCING_Server(){
	return this.SOURCING_Server;
}
public String SOURCING_Login;
public String getSOURCING_Login(){
	return this.SOURCING_Login;
}
public java.lang.String SOURCING_Password;
public java.lang.String getSOURCING_Password(){
	return this.SOURCING_Password;
}
public String SOURCING_Port;
public String getSOURCING_Port(){
	return this.SOURCING_Port;
}
public String SOURCING_Schema;
public String getSOURCING_Schema(){
	return this.SOURCING_Schema;
}
public String SOURCING_Database;
public String getSOURCING_Database(){
	return this.SOURCING_Database;
}
public Integer TOP_N_ROWS;
public Integer getTOP_N_ROWS(){
	return this.TOP_N_ROWS;
}
public String FORCE_BATCH;
public String getFORCE_BATCH(){
	return this.FORCE_BATCH;
}
public Integer RUN_ID;
public Integer getRUN_ID(){
	return this.RUN_ID;
}
	}
	private ContextProperties context = new ContextProperties();
	public ContextProperties getContext() {
		return this.context;
	}
	private final String jobVersion = "0.1";
	private final String jobName = "AS400_to_greenplum_with_GPLoad";
	private final String projectName = "AWS_DEV_TALEND_INGESTION_FRAMEWORK";
	public Integer errorCode = null;
	private String currentComponent = "";
	
		private final java.util.Map<String, Object> globalMap = new java.util.HashMap<String, Object>();
        private final static java.util.Map<String, Object> junitGlobalMap = new java.util.HashMap<String, Object>();
	
		private final java.util.Map<String, Long> start_Hash = new java.util.HashMap<String, Long>();
		private final java.util.Map<String, Long> end_Hash = new java.util.HashMap<String, Long>();
		private final java.util.Map<String, Boolean> ok_Hash = new java.util.HashMap<String, Boolean>();
		public  final java.util.List<String[]> globalBuffer = new java.util.ArrayList<String[]>();
	

private RunStat runStat = new RunStat();

	// OSGi DataSource
	private final static String KEY_DB_DATASOURCES = "KEY_DB_DATASOURCES";

	public void setDataSources(java.util.Map<String, javax.sql.DataSource> dataSources) {
		java.util.Map<String, routines.system.TalendDataSource> talendDataSources = new java.util.HashMap<String, routines.system.TalendDataSource>();
		for (java.util.Map.Entry<String, javax.sql.DataSource> dataSourceEntry : dataSources.entrySet()) {
			talendDataSources.put(dataSourceEntry.getKey(), new routines.system.TalendDataSource(dataSourceEntry.getValue()));
		}
		globalMap.put(KEY_DB_DATASOURCES, talendDataSources);
	}

	LogCatcherUtils tLogCatcher_1 = new LogCatcherUtils();
	LogCatcherUtils talendLogs_LOGS = new LogCatcherUtils();
	StatCatcherUtils talendStats_STATS = new StatCatcherUtils("_MRptkOT6EeSvtZgovRNCUQ", "0.1");
	MetterCatcherUtils talendMeter_METTER = new MetterCatcherUtils("_MRptkOT6EeSvtZgovRNCUQ", "0.1");

private final java.io.ByteArrayOutputStream baos = new java.io.ByteArrayOutputStream();
private final java.io.PrintStream errorMessagePS = new java.io.PrintStream(new java.io.BufferedOutputStream(baos));

public String getExceptionStackTrace() {
	if ("failure".equals(this.getStatus())) {
		errorMessagePS.flush();
		return baos.toString();
	}
	return null;
}

private Exception exception;

public Exception getException() {
	if ("failure".equals(this.getStatus())) {
		return this.exception;
	}
	return null;
}

private class TalendException extends Exception {

	private static final long serialVersionUID = 1L;

	private java.util.Map<String, Object> globalMap = null;
	private Exception e = null;
	private String currentComponent = null;
	private String virtualComponentName = null;
	
	public void setVirtualComponentName (String virtualComponentName){
		this.virtualComponentName = virtualComponentName;
	}

	private TalendException(Exception e, String errorComponent, final java.util.Map<String, Object> globalMap) {
		this.currentComponent= errorComponent;
		this.globalMap = globalMap;
		this.e = e;
	}

	public Exception getException() {
		return this.e;
	}

	public String getCurrentComponent() {
		return this.currentComponent;
	}

	
    public String getExceptionCauseMessage(Exception e){
        Throwable cause = e;
        String message = null;
        int i = 10;
        while (null != cause && 0 < i--) {
            message = cause.getMessage();
            if (null == message) {
                cause = cause.getCause();
            } else {
                break;          
            }
        }
        if (null == message) {
            message = e.getClass().getName();
        }   
        return message;
    }

	@Override
	public void printStackTrace() {
		if (!(e instanceof TalendException || e instanceof TDieException)) {
			if(virtualComponentName!=null && currentComponent.indexOf(virtualComponentName+"_")==0){
				globalMap.put(virtualComponentName+"_ERROR_MESSAGE",getExceptionCauseMessage(e));
			}
			 globalMap.put(currentComponent+"_ERROR_MESSAGE",getExceptionCauseMessage(e));
			System.err.println("Exception in component " + currentComponent);
		}
		if (!(e instanceof TDieException)) {
			if(e instanceof TalendException){
				e.printStackTrace();
			} else {
				e.printStackTrace();
				e.printStackTrace(errorMessagePS);
				AS400_to_greenplum_with_GPLoad.this.exception = e;
			}
		}
		if (!(e instanceof TalendException)) {
		try {
			for (java.lang.reflect.Method m : this.getClass().getEnclosingClass().getMethods()) {
				if (m.getName().compareTo(currentComponent + "_error") == 0) {
					m.invoke(AS400_to_greenplum_with_GPLoad.this, new Object[] { e , currentComponent, globalMap});
					break;
				}
			}

			if(!(e instanceof TDieException)){
				tLogCatcher_1.addMessage("Java Exception", currentComponent, 6, e.getClass().getName() + ":" + e.getMessage(), 1);
				talendLogs_LOGS.addMessage("Java Exception", currentComponent, 6, e.getClass().getName() + ":" + e.getMessage(), 1);
			try{
				tLogCatcher_1Process(globalMap);
			}finally{
				talendLogs_LOGSProcess(globalMap);
			}
			}
				} catch (TalendException e) {
					// do nothing
				
		} catch (Exception e) {
			this.e.printStackTrace();
		}
		}
	}
}

			public void tJava_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tJava_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tGreenplumConnection_2_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tGreenplumConnection_2_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tGreenplumInput_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tGreenplumInput_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tFlowToIterate_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tGreenplumInput_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tGreenplumRow_4_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tGreenplumInput_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tGreenplumInput_2_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tGreenplumInput_2_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tFlowToIterate_2_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tGreenplumInput_2_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tSetGlobalVar_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tSetGlobalVar_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tJava_4_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tJava_4_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tCreateTemporaryFile_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tCreateTemporaryFile_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tAS400Connection_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tAS400Connection_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tJDBCColumnList_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tJDBCColumnList_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tMap_2_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tJDBCColumnList_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tFlowToIterate_4_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tJDBCColumnList_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tJava_5_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tJDBCColumnList_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tGreenplumRow_5_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tGreenplumRow_5_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tGreenplumRow_6_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tGreenplumRow_6_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tAS400Input_2_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tAS400Input_2_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tMap_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tAS400Input_2_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tFileOutputDelimitedGE_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tAS400Input_2_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void vFlowMeter_row2_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tAS400Input_2_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tFileExist_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tFileExist_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tFileProperties_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tFileProperties_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tSetGlobalVar_2_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tFileProperties_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tGEGreenplumGPLoad_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tGEGreenplumGPLoad_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tFileInputFullRow_2_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tFileInputFullRow_2_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tJavaRow_2_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tFileInputFullRow_2_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tAS400Input_3_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tAS400Input_3_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tJavaRow_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tAS400Input_3_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tJava_2_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tJava_2_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tGreenplumRow_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tGreenplumRow_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tJava_3_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tJava_3_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tGreenplumRow_2_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tGreenplumRow_2_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tAS400Close_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tAS400Close_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tWarn_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tWarn_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tGreenplumRow_7_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tGreenplumRow_7_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tGreenplumClose_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tGreenplumClose_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tLogCatcher_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tLogCatcher_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tSetGlobalVar_3_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tLogCatcher_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tGreenplumConnection_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tGreenplumConnection_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tGreenplumRow_3_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tGreenplumRow_3_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tGreenplumClose_2_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tGreenplumClose_2_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tIterateToFlow_1_ITFO_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tJDBCColumnList_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tIterateToFlow_1_AI_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tJDBCColumnList_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tAggregateRow_1_AGGOUT_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
							tAggregateRow_1_AGGIN_error(exception, errorComponent, globalMap);
						
						}
					
			public void tAggregateRow_1_AGGIN_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tJDBCColumnList_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void talendLogs_LOGS_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
							talendLogs_CONSOLE_error(exception, errorComponent, globalMap);
						
						}
					
			public void talendLogs_CONSOLE_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					talendLogs_LOGS_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void talendStats_STATS_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
							talendStats_CONSOLE_error(exception, errorComponent, globalMap);
						
						}
					
			public void talendStats_CONSOLE_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					talendStats_STATS_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void talendMeter_METTER_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
							talendMeter_CONSOLE_error(exception, errorComponent, globalMap);
						
						}
					
			public void talendMeter_CONSOLE_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					talendMeter_METTER_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tJava_1_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tGreenplumConnection_2_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tGreenplumInput_1_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tGreenplumInput_2_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tSetGlobalVar_1_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tJava_4_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tCreateTemporaryFile_1_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tAS400Connection_1_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tJDBCColumnList_1_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tGreenplumRow_5_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tGreenplumRow_6_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tAS400Input_2_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tFileExist_1_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tFileProperties_1_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tGEGreenplumGPLoad_1_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tFileInputFullRow_2_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tAS400Input_3_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tJava_2_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tGreenplumRow_1_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tJava_3_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tGreenplumRow_2_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tAS400Close_1_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tWarn_1_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tGreenplumRow_7_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tGreenplumClose_1_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tLogCatcher_1_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tGreenplumConnection_1_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tGreenplumRow_3_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tGreenplumClose_2_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tIterateToFlow_1_AI_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void talendLogs_LOGS_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void talendStats_STATS_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void talendMeter_METTER_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			








public void tJava_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tJava_1_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tJava_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tJava_1", false);
		start_Hash.put("tJava_1", System.currentTimeMillis());
		
	
	currentComponent="tJava_1";

	
		int tos_count_tJava_1 = 0;
		
    	class BytesLimit65535_tJava_1{
    		public void limitLog4jByte() throws Exception{
    			
    		}
    	}
    	
        new BytesLimit65535_tJava_1().limitLog4jByte();


globalMap.put("orig_table_name", context.getProperty("TABLE_NAME"));
if (context.getProperty("TABLE_NAME").length() != 0) {
	context.setProperty("TABLE_NAME", " and upper(target_table_name) = '" + context.getProperty("TABLE_NAME").toUpperCase() + "'");
}

 



/**
 * [tJava_1 begin ] stop
 */
	
	/**
	 * [tJava_1 main ] start
	 */

	

	
	
	currentComponent="tJava_1";

	

 


	tos_count_tJava_1++;

/**
 * [tJava_1 main ] stop
 */
	
	/**
	 * [tJava_1 end ] start
	 */

	

	
	
	currentComponent="tJava_1";

	

 

ok_Hash.put("tJava_1", true);
end_Hash.put("tJava_1", System.currentTimeMillis());




/**
 * [tJava_1 end ] stop
 */
				}//end the resume

				
				    			if(resumeEntryMethodName == null || globalResumeTicket){
				    				resumeUtil.addLog("CHECKPOINT", "CONNECTION:SUBJOB_OK:tJava_1:OnSubjobOk", "", Thread.currentThread().getId() + "", "", "", "", "", "");
								}	    				    			
					    	
								if(execStat){    	
									runStat.updateStatOnConnection("OnSubjobOk7", 0, "ok");
								} 
							
							tGreenplumConnection_2Process(globalMap); 
						



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage());
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tJava_1 finally ] start
	 */

	

	
	
	currentComponent="tJava_1";

	

 



/**
 * [tJava_1 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tJava_1_SUBPROCESS_STATE", 1);
	}
	

public void tGreenplumConnection_2Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tGreenplumConnection_2_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tGreenplumConnection_2 begin ] start
	 */

	

	
		
		ok_Hash.put("tGreenplumConnection_2", false);
		start_Hash.put("tGreenplumConnection_2", System.currentTimeMillis());
		
	
	currentComponent="tGreenplumConnection_2";

	
		int tos_count_tGreenplumConnection_2 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tGreenplumConnection_2 - "  + ("Start to work.") );
    	class BytesLimit65535_tGreenplumConnection_2{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tGreenplumConnection_2 = new StringBuilder();
            log4jParamters_tGreenplumConnection_2.append("Parameters:");
                    log4jParamters_tGreenplumConnection_2.append("HOST" + " = " + "context.SOURCING_Server");
                log4jParamters_tGreenplumConnection_2.append(" | ");
                    log4jParamters_tGreenplumConnection_2.append("PORT" + " = " + "context.SOURCING_Port");
                log4jParamters_tGreenplumConnection_2.append(" | ");
                    log4jParamters_tGreenplumConnection_2.append("DBNAME" + " = " + "context.SOURCING_Database");
                log4jParamters_tGreenplumConnection_2.append(" | ");
                    log4jParamters_tGreenplumConnection_2.append("SCHEMA_DB" + " = " + "context.SOURCING_Schema");
                log4jParamters_tGreenplumConnection_2.append(" | ");
                    log4jParamters_tGreenplumConnection_2.append("USER" + " = " + "context.SOURCING_Login");
                log4jParamters_tGreenplumConnection_2.append(" | ");
                    log4jParamters_tGreenplumConnection_2.append("PASS" + " = " + String.valueOf(routines.system.PasswordEncryptUtil.encryptPassword(context.SOURCING_Password)).substring(0, 4) + "...");     
                log4jParamters_tGreenplumConnection_2.append(" | ");
                    log4jParamters_tGreenplumConnection_2.append("USE_SHARED_CONNECTION" + " = " + "false");
                log4jParamters_tGreenplumConnection_2.append(" | ");
                    log4jParamters_tGreenplumConnection_2.append("USE_SSL" + " = " + "true");
                log4jParamters_tGreenplumConnection_2.append(" | ");
                    log4jParamters_tGreenplumConnection_2.append("AUTO_COMMIT" + " = " + "true");
                log4jParamters_tGreenplumConnection_2.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tGreenplumConnection_2 - "  + (log4jParamters_tGreenplumConnection_2) );
    		}
    	}
    	
        new BytesLimit65535_tGreenplumConnection_2().limitLog4jByte();
	

	
				String url_tGreenplumConnection_2 = "jdbc:postgresql://"+context.SOURCING_Server+":"+context.SOURCING_Port+"/"+context.SOURCING_Database+"?ssl=true&sslfactory=org.postgresql.ssl.NonValidatingFactory";

	String dbUser_tGreenplumConnection_2 = context.SOURCING_Login;
	
	
		
	final String decryptedPassword_tGreenplumConnection_2 = context.SOURCING_Password; 
		String dbPwd_tGreenplumConnection_2 = decryptedPassword_tGreenplumConnection_2;
	

	java.sql.Connection conn_tGreenplumConnection_2 = null;
	
		
			String driverClass_tGreenplumConnection_2 = "org.postgresql.Driver";
			java.lang.Class.forName(driverClass_tGreenplumConnection_2);
		
	    		log.debug("tGreenplumConnection_2 - Driver ClassName: "+driverClass_tGreenplumConnection_2+".");
			
	    		log.debug("tGreenplumConnection_2 - Connection attempt to '" + url_tGreenplumConnection_2 + "' with the username '" + dbUser_tGreenplumConnection_2 + "'.");
			
		conn_tGreenplumConnection_2 = java.sql.DriverManager.getConnection(url_tGreenplumConnection_2,dbUser_tGreenplumConnection_2,dbPwd_tGreenplumConnection_2);
	    		log.debug("tGreenplumConnection_2 - Connection to '" + url_tGreenplumConnection_2 + "' has succeeded.");
			

		globalMap.put("conn_tGreenplumConnection_2", conn_tGreenplumConnection_2);
	if (null != conn_tGreenplumConnection_2) {
		
			log.debug("tGreenplumConnection_2 - Connection is set auto commit to 'true'.");
			conn_tGreenplumConnection_2.setAutoCommit(true);
	}

	globalMap.put("schema_" + "tGreenplumConnection_2",context.SOURCING_Schema);

	globalMap.put("conn_" + "tGreenplumConnection_2",conn_tGreenplumConnection_2);
 



/**
 * [tGreenplumConnection_2 begin ] stop
 */
	
	/**
	 * [tGreenplumConnection_2 main ] start
	 */

	

	
	
	currentComponent="tGreenplumConnection_2";

	

 


	tos_count_tGreenplumConnection_2++;

/**
 * [tGreenplumConnection_2 main ] stop
 */
	
	/**
	 * [tGreenplumConnection_2 end ] start
	 */

	

	
	
	currentComponent="tGreenplumConnection_2";

	

 
                if(log.isDebugEnabled())
            log.debug("tGreenplumConnection_2 - "  + ("Done.") );

ok_Hash.put("tGreenplumConnection_2", true);
end_Hash.put("tGreenplumConnection_2", System.currentTimeMillis());




/**
 * [tGreenplumConnection_2 end ] stop
 */
				}//end the resume

				
				    			if(resumeEntryMethodName == null || globalResumeTicket){
				    				resumeUtil.addLog("CHECKPOINT", "CONNECTION:SUBJOB_OK:tGreenplumConnection_2:OnSubjobOk", "", Thread.currentThread().getId() + "", "", "", "", "", "");
								}	    				    			
					    	
								if(execStat){    	
									runStat.updateStatOnConnection("OnSubjobOk18", 0, "ok");
								} 
							
							tGreenplumInput_1Process(globalMap); 
						



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage());
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tGreenplumConnection_2 finally ] start
	 */

	

	
	
	currentComponent="tGreenplumConnection_2";

	

 



/**
 * [tGreenplumConnection_2 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tGreenplumConnection_2_SUBPROCESS_STATE", 1);
	}
	


public static class row1Struct implements routines.system.IPersistableRow<row1Struct> {
    final static byte[] commonByteArrayLock_AWS_DEV_TALEND_INGESTION_FRAMEWORK_AS400_to_greenplum_with_GPLoad = new byte[0];
    static byte[] commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_AS400_to_greenplum_with_GPLoad = new byte[0];

	
			    public String source_name;

				public String getSource_name () {
					return this.source_name;
				}
				
			    public String source_table_name;

				public String getSource_table_name () {
					return this.source_table_name;
				}
				
			    public String target_table_name;

				public String getTarget_table_name () {
					return this.target_table_name;
				}
				
			    public String log_table_name;

				public String getLog_table_name () {
					return this.log_table_name;
				}
				
			    public String update_type;

				public String getUpdate_type () {
					return this.update_type;
				}
				
			    public String update_col;

				public String getUpdate_col () {
					return this.update_col;
				}
				
			    public java.util.Date last_update_date;

				public java.util.Date getLast_update_date () {
					return this.last_update_date;
				}
				
			    public String source_schema;

				public String getSource_schema () {
					return this.source_schema;
				}
				
			    public String target_schema;

				public String getTarget_schema () {
					return this.target_schema;
				}
				
			    public String target_schema_orig;

				public String getTarget_schema_orig () {
					return this.target_schema_orig;
				}
				
			    public java.util.Date now;

				public java.util.Date getNow () {
					return this.now;
				}
				



	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_AS400_to_greenplum_with_GPLoad.length) {
				if(length < 1024 && commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_AS400_to_greenplum_with_GPLoad.length == 0) {
   					commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_AS400_to_greenplum_with_GPLoad = new byte[1024];
				} else {
   					commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_AS400_to_greenplum_with_GPLoad = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_AS400_to_greenplum_with_GPLoad, 0, length);
			strReturn = new String(commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_AS400_to_greenplum_with_GPLoad, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }

	private java.util.Date readDate(ObjectInputStream dis) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(dis.readLong());
		}
		return dateReturn;
	}

    private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException{
		if(date1 == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeLong(date1.getTime());
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_AWS_DEV_TALEND_INGESTION_FRAMEWORK_AS400_to_greenplum_with_GPLoad) {

        	try {

        		int length = 0;
		
					this.source_name = readString(dis);
					
					this.source_table_name = readString(dis);
					
					this.target_table_name = readString(dis);
					
					this.log_table_name = readString(dis);
					
					this.update_type = readString(dis);
					
					this.update_col = readString(dis);
					
					this.last_update_date = readDate(dis);
					
					this.source_schema = readString(dis);
					
					this.target_schema = readString(dis);
					
					this.target_schema_orig = readString(dis);
					
					this.now = readDate(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// String
				
						writeString(this.source_name,dos);
					
					// String
				
						writeString(this.source_table_name,dos);
					
					// String
				
						writeString(this.target_table_name,dos);
					
					// String
				
						writeString(this.log_table_name,dos);
					
					// String
				
						writeString(this.update_type,dos);
					
					// String
				
						writeString(this.update_col,dos);
					
					// java.util.Date
				
						writeDate(this.last_update_date,dos);
					
					// String
				
						writeString(this.source_schema,dos);
					
					// String
				
						writeString(this.target_schema,dos);
					
					// String
				
						writeString(this.target_schema_orig,dos);
					
					// java.util.Date
				
						writeDate(this.now,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("source_name="+source_name);
		sb.append(",source_table_name="+source_table_name);
		sb.append(",target_table_name="+target_table_name);
		sb.append(",log_table_name="+log_table_name);
		sb.append(",update_type="+update_type);
		sb.append(",update_col="+update_col);
		sb.append(",last_update_date="+String.valueOf(last_update_date));
		sb.append(",source_schema="+source_schema);
		sb.append(",target_schema="+target_schema);
		sb.append(",target_schema_orig="+target_schema_orig);
		sb.append(",now="+String.valueOf(now));
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				if(source_name == null){
        					sb.append("<null>");
        				}else{
            				sb.append(source_name);
            			}
            		
        			sb.append("|");
        		
        				if(source_table_name == null){
        					sb.append("<null>");
        				}else{
            				sb.append(source_table_name);
            			}
            		
        			sb.append("|");
        		
        				if(target_table_name == null){
        					sb.append("<null>");
        				}else{
            				sb.append(target_table_name);
            			}
            		
        			sb.append("|");
        		
        				if(log_table_name == null){
        					sb.append("<null>");
        				}else{
            				sb.append(log_table_name);
            			}
            		
        			sb.append("|");
        		
        				if(update_type == null){
        					sb.append("<null>");
        				}else{
            				sb.append(update_type);
            			}
            		
        			sb.append("|");
        		
        				if(update_col == null){
        					sb.append("<null>");
        				}else{
            				sb.append(update_col);
            			}
            		
        			sb.append("|");
        		
        				if(last_update_date == null){
        					sb.append("<null>");
        				}else{
            				sb.append(last_update_date);
            			}
            		
        			sb.append("|");
        		
        				if(source_schema == null){
        					sb.append("<null>");
        				}else{
            				sb.append(source_schema);
            			}
            		
        			sb.append("|");
        		
        				if(target_schema == null){
        					sb.append("<null>");
        				}else{
            				sb.append(target_schema);
            			}
            		
        			sb.append("|");
        		
        				if(target_schema_orig == null){
        					sb.append("<null>");
        				}else{
            				sb.append(target_schema_orig);
            			}
            		
        			sb.append("|");
        		
        				if(now == null){
        					sb.append("<null>");
        				}else{
            				sb.append(now);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(row1Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}
public void tGreenplumInput_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tGreenplumInput_1_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;



		row1Struct row1 = new row1Struct();




	
	/**
	 * [tFlowToIterate_1 begin ] start
	 */

				
			int NB_ITERATE_tGreenplumRow_4 = 0; //for statistics
			

	
		
		ok_Hash.put("tFlowToIterate_1", false);
		start_Hash.put("tFlowToIterate_1", System.currentTimeMillis());
		
	
	currentComponent="tFlowToIterate_1";

	
			if (execStat) {
				if(resourceMap.get("inIterateVComp") == null){
					
						runStat.updateStatOnConnection("row1" + iterateId, 0, 0);
					
				}
			} 

		
		int tos_count_tFlowToIterate_1 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tFlowToIterate_1 - "  + ("Start to work.") );
    	class BytesLimit65535_tFlowToIterate_1{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tFlowToIterate_1 = new StringBuilder();
            log4jParamters_tFlowToIterate_1.append("Parameters:");
                    log4jParamters_tFlowToIterate_1.append("DEFAULT_MAP" + " = " + "true");
                log4jParamters_tFlowToIterate_1.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tFlowToIterate_1 - "  + (log4jParamters_tFlowToIterate_1) );
    		}
    	}
    	
        new BytesLimit65535_tFlowToIterate_1().limitLog4jByte();

int nb_line_tFlowToIterate_1 = 0;
int counter_tFlowToIterate_1 = 0;

 



/**
 * [tFlowToIterate_1 begin ] stop
 */



	
	/**
	 * [tGreenplumInput_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tGreenplumInput_1", false);
		start_Hash.put("tGreenplumInput_1", System.currentTimeMillis());
		
	
	currentComponent="tGreenplumInput_1";

	
		int tos_count_tGreenplumInput_1 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tGreenplumInput_1 - "  + ("Start to work.") );
    	class BytesLimit65535_tGreenplumInput_1{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tGreenplumInput_1 = new StringBuilder();
            log4jParamters_tGreenplumInput_1.append("Parameters:");
                    log4jParamters_tGreenplumInput_1.append("USE_EXISTING_CONNECTION" + " = " + "true");
                log4jParamters_tGreenplumInput_1.append(" | ");
                    log4jParamters_tGreenplumInput_1.append("CONNECTION" + " = " + "tGreenplumConnection_2");
                log4jParamters_tGreenplumInput_1.append(" | ");
                    log4jParamters_tGreenplumInput_1.append("TABLE" + " = " + "\"\"");
                log4jParamters_tGreenplumInput_1.append(" | ");
                    log4jParamters_tGreenplumInput_1.append("QUERYSTORE" + " = " + "\"\"");
                log4jParamters_tGreenplumInput_1.append(" | ");
                    log4jParamters_tGreenplumInput_1.append("QUERY" + " = " + "\"SELECT source_name,   source_table_name,   case when update_type='full' or last_update_date is null  or '\"+context.FORCE_BATCH+\"'='Y' then target_table_name  else lower(target_schema)||'_'||target_table_name  end as target_table_name,   target_table_name as log_table_name,  case when last_update_date is null or '\"+context.FORCE_BATCH+\"'='Y' then 'full'   else update_type  end as update_type,   update_col,   last_update_date,  source_schema,   case when update_type='full' or last_update_date is null or '\"+context.FORCE_BATCH+\"'='Y' then target_schema  else 'increments'  end as target_schema,   lower(target_schema) as target_schema_orig,  now() as now   FROM sbdt.tables WHERE source_schema <> 'na' and source_name = '\" + context.getProperty(\"GP_SOURCE_NAME\") +   \"' and update_type in ('incremental', 'full')\" +  context.getProperty(\"TABLE_NAME\")");
                log4jParamters_tGreenplumInput_1.append(" | ");
                    log4jParamters_tGreenplumInput_1.append("USE_CURSOR" + " = " + "false");
                log4jParamters_tGreenplumInput_1.append(" | ");
                    log4jParamters_tGreenplumInput_1.append("TRIM_ALL_COLUMN" + " = " + "false");
                log4jParamters_tGreenplumInput_1.append(" | ");
                    log4jParamters_tGreenplumInput_1.append("TRIM_COLUMN" + " = " + "[{TRIM="+("false")+", SCHEMA_COLUMN="+("source_name")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("source_table_name")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("target_table_name")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("log_table_name")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("update_type")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("update_col")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("last_update_date")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("source_schema")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("target_schema")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("target_schema_orig")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("now")+"}]");
                log4jParamters_tGreenplumInput_1.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tGreenplumInput_1 - "  + (log4jParamters_tGreenplumInput_1) );
    		}
    	}
    	
        new BytesLimit65535_tGreenplumInput_1().limitLog4jByte();
	
    
	
		    int nb_line_tGreenplumInput_1 = 0;
		    java.sql.Connection conn_tGreenplumInput_1 = null;
		        conn_tGreenplumInput_1 = (java.sql.Connection)globalMap.get("conn_tGreenplumConnection_2");
				
				if(conn_tGreenplumInput_1 != null) {
					if(conn_tGreenplumInput_1.getMetaData() != null) {
						
						log.debug("tGreenplumInput_1 - Uses an existing connection with username '" + conn_tGreenplumInput_1.getMetaData().getUserName() + "'. Connection URL: " + conn_tGreenplumInput_1.getMetaData().getURL() + ".");
						
					}
				}
			
		    
			java.sql.Statement stmt_tGreenplumInput_1 = conn_tGreenplumInput_1.createStatement();

		    String dbquery_tGreenplumInput_1 = "SELECT source_name, \nsource_table_name, \ncase when update_type='full' or last_update_date is null  or '"+context.FORCE_BATCH+"'='Y' then target_table_name\nelse lower(target_schema)||'_'||target_table_name\nend as target_table_name, \ntarget_table_name as log_table_name,\ncase when last_update_date is null or '"+context.FORCE_BATCH+"'='Y' then 'full' \nelse update_type\nend as update_type, \nupdate_col, \nlast_update_date,\nsource_schema, \ncase when update_type='full' or last_update_date is null or '"+context.FORCE_BATCH+"'='Y' then target_schema\nelse 'increments'\nend as target_schema, \nlower(target_schema) as target_schema_orig,\nnow() as now \nFROM sbdt.tables WHERE source_schema <> 'na' and source_name = '" + context.getProperty("GP_SOURCE_NAME") + 
"' and update_type in ('incremental', 'full')" +
context.getProperty("TABLE_NAME");
			
                log.debug("tGreenplumInput_1 - Executing the query: '"+dbquery_tGreenplumInput_1+"'.");
			

                       globalMap.put("tGreenplumInput_1_QUERY",dbquery_tGreenplumInput_1);

		    java.sql.ResultSet rs_tGreenplumInput_1 = null;
		try{
		    rs_tGreenplumInput_1 = stmt_tGreenplumInput_1.executeQuery(dbquery_tGreenplumInput_1);
		    java.sql.ResultSetMetaData rsmd_tGreenplumInput_1 = rs_tGreenplumInput_1.getMetaData();
		    int colQtyInRs_tGreenplumInput_1 = rsmd_tGreenplumInput_1.getColumnCount();

		    String tmpContent_tGreenplumInput_1 = null;
		    
		    
		    	log.debug("tGreenplumInput_1 - Retrieving records from the database.");
		    
		    while (rs_tGreenplumInput_1.next()) {
		        nb_line_tGreenplumInput_1++;
		        
							if(colQtyInRs_tGreenplumInput_1 < 1) {
								row1.source_name = null;
							} else {
	                         		
        	row1.source_name = routines.system.JDBCUtil.getString(rs_tGreenplumInput_1, 1, false);
		                    }
							if(colQtyInRs_tGreenplumInput_1 < 2) {
								row1.source_table_name = null;
							} else {
	                         		
        	row1.source_table_name = routines.system.JDBCUtil.getString(rs_tGreenplumInput_1, 2, false);
		                    }
							if(colQtyInRs_tGreenplumInput_1 < 3) {
								row1.target_table_name = null;
							} else {
	                         		
        	row1.target_table_name = routines.system.JDBCUtil.getString(rs_tGreenplumInput_1, 3, false);
		                    }
							if(colQtyInRs_tGreenplumInput_1 < 4) {
								row1.log_table_name = null;
							} else {
	                         		
        	row1.log_table_name = routines.system.JDBCUtil.getString(rs_tGreenplumInput_1, 4, false);
		                    }
							if(colQtyInRs_tGreenplumInput_1 < 5) {
								row1.update_type = null;
							} else {
	                         		
        	row1.update_type = routines.system.JDBCUtil.getString(rs_tGreenplumInput_1, 5, false);
		                    }
							if(colQtyInRs_tGreenplumInput_1 < 6) {
								row1.update_col = null;
							} else {
	                         		
        	row1.update_col = routines.system.JDBCUtil.getString(rs_tGreenplumInput_1, 6, false);
		                    }
							if(colQtyInRs_tGreenplumInput_1 < 7) {
								row1.last_update_date = null;
							} else {
										
			row1.last_update_date = routines.system.JDBCUtil.getDate(rs_tGreenplumInput_1, 7);
		                    }
							if(colQtyInRs_tGreenplumInput_1 < 8) {
								row1.source_schema = null;
							} else {
	                         		
        	row1.source_schema = routines.system.JDBCUtil.getString(rs_tGreenplumInput_1, 8, false);
		                    }
							if(colQtyInRs_tGreenplumInput_1 < 9) {
								row1.target_schema = null;
							} else {
	                         		
        	row1.target_schema = routines.system.JDBCUtil.getString(rs_tGreenplumInput_1, 9, false);
		                    }
							if(colQtyInRs_tGreenplumInput_1 < 10) {
								row1.target_schema_orig = null;
							} else {
	                         		
        	row1.target_schema_orig = routines.system.JDBCUtil.getString(rs_tGreenplumInput_1, 10, false);
		                    }
							if(colQtyInRs_tGreenplumInput_1 < 11) {
								row1.now = null;
							} else {
										
			row1.now = routines.system.JDBCUtil.getDate(rs_tGreenplumInput_1, 11);
		                    }
					
						log.debug("tGreenplumInput_1 - Retrieving the record " + nb_line_tGreenplumInput_1 + ".");
					


 



/**
 * [tGreenplumInput_1 begin ] stop
 */
	
	/**
	 * [tGreenplumInput_1 main ] start
	 */

	

	
	
	currentComponent="tGreenplumInput_1";

	

 


	tos_count_tGreenplumInput_1++;

/**
 * [tGreenplumInput_1 main ] stop
 */

	
	/**
	 * [tFlowToIterate_1 main ] start
	 */

	

	
	
	currentComponent="tFlowToIterate_1";

	

			//row1
			//row1


			
				if(execStat){
					runStat.updateStatOnConnection("row1"+iterateId,1, 1);
				} 
			

		
    			if(log.isTraceEnabled()){
    				log.trace("row1 - " + (row1==null? "": row1.toLogString()));
    			}
    		


    	
                if(log.isTraceEnabled())
            log.trace("tFlowToIterate_1 - "  + ("Set global var, key=row1.source_name, value=")  + (row1.source_name)  + (".") );            
            globalMap.put("row1.source_name", row1.source_name);
    	
                if(log.isTraceEnabled())
            log.trace("tFlowToIterate_1 - "  + ("Set global var, key=row1.source_table_name, value=")  + (row1.source_table_name)  + (".") );            
            globalMap.put("row1.source_table_name", row1.source_table_name);
    	
                if(log.isTraceEnabled())
            log.trace("tFlowToIterate_1 - "  + ("Set global var, key=row1.target_table_name, value=")  + (row1.target_table_name)  + (".") );            
            globalMap.put("row1.target_table_name", row1.target_table_name);
    	
                if(log.isTraceEnabled())
            log.trace("tFlowToIterate_1 - "  + ("Set global var, key=row1.log_table_name, value=")  + (row1.log_table_name)  + (".") );            
            globalMap.put("row1.log_table_name", row1.log_table_name);
    	
                if(log.isTraceEnabled())
            log.trace("tFlowToIterate_1 - "  + ("Set global var, key=row1.update_type, value=")  + (row1.update_type)  + (".") );            
            globalMap.put("row1.update_type", row1.update_type);
    	
                if(log.isTraceEnabled())
            log.trace("tFlowToIterate_1 - "  + ("Set global var, key=row1.update_col, value=")  + (row1.update_col)  + (".") );            
            globalMap.put("row1.update_col", row1.update_col);
    	
                if(log.isTraceEnabled())
            log.trace("tFlowToIterate_1 - "  + ("Set global var, key=row1.last_update_date, value=")  + (row1.last_update_date)  + (".") );            
            globalMap.put("row1.last_update_date", row1.last_update_date);
    	
                if(log.isTraceEnabled())
            log.trace("tFlowToIterate_1 - "  + ("Set global var, key=row1.source_schema, value=")  + (row1.source_schema)  + (".") );            
            globalMap.put("row1.source_schema", row1.source_schema);
    	
                if(log.isTraceEnabled())
            log.trace("tFlowToIterate_1 - "  + ("Set global var, key=row1.target_schema, value=")  + (row1.target_schema)  + (".") );            
            globalMap.put("row1.target_schema", row1.target_schema);
    	
                if(log.isTraceEnabled())
            log.trace("tFlowToIterate_1 - "  + ("Set global var, key=row1.target_schema_orig, value=")  + (row1.target_schema_orig)  + (".") );            
            globalMap.put("row1.target_schema_orig", row1.target_schema_orig);
    	
                if(log.isTraceEnabled())
            log.trace("tFlowToIterate_1 - "  + ("Set global var, key=row1.now, value=")  + (row1.now)  + (".") );            
            globalMap.put("row1.now", row1.now);
    	
 
	   nb_line_tFlowToIterate_1++;  
       counter_tFlowToIterate_1++;
                if(log.isDebugEnabled())
            log.debug("tFlowToIterate_1 - "  + ("Current iteration is: ")  + (counter_tFlowToIterate_1)  + (".") );
       globalMap.put("tFlowToIterate_1_CURRENT_ITERATION", counter_tFlowToIterate_1);
 


	tos_count_tFlowToIterate_1++;

/**
 * [tFlowToIterate_1 main ] stop
 */
	NB_ITERATE_tGreenplumRow_4++;
	
	
					if(execStat){				
	       				runStat.updateStatOnConnection("OnComponentOk5", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("row9", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("OnComponentOk9", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("FinalData", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("OnSubjobOk21", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("row7", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("OnSubjobOk", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("OnComponentOk7", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("OnSubjobOk5", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("If3", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("OnSubjobOk22", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("iterate3", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("fileprop", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("OnSubjobOk17", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("row2", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("OnComponentOk6", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("meterRowrow2", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("row5", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("OnSubjobOk14", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("OnComponentOk4", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("OnSubjobOk3", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("OnComponentOk8", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("If4", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("test", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("If10", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("iterate4", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("If6", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("If2", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("row3", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("If1", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("OnRowsEnd", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("If9", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("If8", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("OnSubjobOk1", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("OnSubjobOk4", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("If7", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("row8", 3, 0);
					}           			
				
				if(execStat){
					runStat.updateStatOnConnection("iterate1", 1, "exec" + NB_ITERATE_tGreenplumRow_4);
					//Thread.sleep(1000);
				}				
			

	
	/**
	 * [tGreenplumRow_4 begin ] start
	 */

	

	
		
		ok_Hash.put("tGreenplumRow_4", false);
		start_Hash.put("tGreenplumRow_4", System.currentTimeMillis());
		
	
	currentComponent="tGreenplumRow_4";

	
		int tos_count_tGreenplumRow_4 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tGreenplumRow_4 - "  + ("Start to work.") );
    	class BytesLimit65535_tGreenplumRow_4{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tGreenplumRow_4 = new StringBuilder();
            log4jParamters_tGreenplumRow_4.append("Parameters:");
                    log4jParamters_tGreenplumRow_4.append("USE_EXISTING_CONNECTION" + " = " + "true");
                log4jParamters_tGreenplumRow_4.append(" | ");
                    log4jParamters_tGreenplumRow_4.append("CONNECTION" + " = " + "tGreenplumConnection_2");
                log4jParamters_tGreenplumRow_4.append(" | ");
                    log4jParamters_tGreenplumRow_4.append("QUERYSTORE" + " = " + "\"\"");
                log4jParamters_tGreenplumRow_4.append(" | ");
                    log4jParamters_tGreenplumRow_4.append("QUERY" + " = " + "\"insert into sbdt.ingestion_log (row_id,run_id, source_name, table_name, no_of_records, status, updated_by, start_time, end_time, log_time, last_update_date) \" +  \"values ((select nextval('sbdt.seq_ingestion_log')), \"+  (Integer)context.RUN_ID+  \", '\" +  ((String)globalMap.get(\"row1.source_name\")) +  \"', '\" +  ((String)globalMap.get(\"row1.log_table_name\")) +  \"', null, 'STARTED', 'Talend'\" +  \", to_timestamp('\" +   new SimpleDateFormat(\"yyyy-MM-dd HH:mm:ss\").format(TalendDate.getCurrentDate()).toString() +  \"', 'YYYY-MM-DD HH24:MI:SS')::timestamp without time zone\" +  \", null\" +  \", to_timestamp('\" +   new SimpleDateFormat(\"yyyy-MM-dd HH:mm:ss\").format(TalendDate.getCurrentDate()).toString() +  \"', 'YYYY-MM-DD HH24:MI:SS')::timestamp without time zone \" +  \", to_timestamp(\" +   ((globalMap.get(\"row1.last_update_date\")==null) ? \"null\" : (\"'\" + String.valueOf(new SimpleDateFormat(\"yyyy-MM-dd HH:mm:ss\").format(((java.util.Date)globalMap.get(\"row1.last_update_date\")))) + \"'\")) +   \", 'YYYY-MM-DD HH24:MI:SS')::timestamp without time zone) \"  ");
                log4jParamters_tGreenplumRow_4.append(" | ");
                    log4jParamters_tGreenplumRow_4.append("DIE_ON_ERROR" + " = " + "true");
                log4jParamters_tGreenplumRow_4.append(" | ");
                    log4jParamters_tGreenplumRow_4.append("PROPAGATE_RECORD_SET" + " = " + "false");
                log4jParamters_tGreenplumRow_4.append(" | ");
                    log4jParamters_tGreenplumRow_4.append("USE_PREPAREDSTATEMENT" + " = " + "false");
                log4jParamters_tGreenplumRow_4.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tGreenplumRow_4 - "  + (log4jParamters_tGreenplumRow_4) );
    		}
    	}
    	
        new BytesLimit65535_tGreenplumRow_4().limitLog4jByte();

	java.sql.Connection conn_tGreenplumRow_4 = null;
	String query_tGreenplumRow_4 = "";
	boolean whetherReject_tGreenplumRow_4 = false;
				conn_tGreenplumRow_4 = (java.sql.Connection)globalMap.get("conn_tGreenplumConnection_2");
			
				if(conn_tGreenplumRow_4 != null) {
					if(conn_tGreenplumRow_4.getMetaData() != null) {
						
						log.debug("tGreenplumRow_4 - Uses an existing connection with username '" + conn_tGreenplumRow_4.getMetaData().getUserName() + "'. Connection URL: " + conn_tGreenplumRow_4.getMetaData().getURL() + ".");
						
					}
				}
			
		java.sql.Statement stmt_tGreenplumRow_4 = conn_tGreenplumRow_4.createStatement();
	

 



/**
 * [tGreenplumRow_4 begin ] stop
 */
	
	/**
	 * [tGreenplumRow_4 main ] start
	 */

	

	
	
	currentComponent="tGreenplumRow_4";

	

	    		log.debug("tGreenplumRow_4 - Executing the query: '" + "insert into sbdt.ingestion_log (row_id,run_id, source_name, table_name, no_of_records, status, updated_by, start_time, end_time, log_time, last_update_date) " +  "values ((select nextval('sbdt.seq_ingestion_log')), "+  (Integer)context.RUN_ID+  ", '" +  ((String)globalMap.get("row1.source_name")) +  "', '" +  ((String)globalMap.get("row1.log_table_name")) +  "', null, 'STARTED', 'Talend'" +  ", to_timestamp('" +   new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(TalendDate.getCurrentDate()).toString() +  "', 'YYYY-MM-DD HH24:MI:SS')::timestamp without time zone" +  ", null" +  ", to_timestamp('" +   new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(TalendDate.getCurrentDate()).toString() +  "', 'YYYY-MM-DD HH24:MI:SS')::timestamp without time zone " +  ", to_timestamp(" +   ((globalMap.get("row1.last_update_date")==null) ? "null" : ("'" + String.valueOf(new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(((java.util.Date)globalMap.get("row1.last_update_date")))) + "'")) +   ", 'YYYY-MM-DD HH24:MI:SS')::timestamp without time zone) "   + "'.");
			
query_tGreenplumRow_4 = "insert into sbdt.ingestion_log (row_id,run_id, source_name, table_name, no_of_records, status, updated_by, start_time, end_time, log_time, last_update_date) " +
"values ((select nextval('sbdt.seq_ingestion_log')), "+
(Integer)context.RUN_ID+
", '" +
((String)globalMap.get("row1.source_name")) +
"', '" +
((String)globalMap.get("row1.log_table_name")) +
"', null, 'STARTED', 'Talend'" +
", to_timestamp('" + 
new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(TalendDate.getCurrentDate()).toString() +
"', 'YYYY-MM-DD HH24:MI:SS')::timestamp without time zone" +
", null" +
", to_timestamp('" + 
new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(TalendDate.getCurrentDate()).toString() +
"', 'YYYY-MM-DD HH24:MI:SS')::timestamp without time zone " +
", to_timestamp(" + 
((globalMap.get("row1.last_update_date")==null) ? "null" : ("'" + String.valueOf(new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(((java.util.Date)globalMap.get("row1.last_update_date")))) + "'")) + 
", 'YYYY-MM-DD HH24:MI:SS')::timestamp without time zone) "
;
whetherReject_tGreenplumRow_4 = false;
globalMap.put("tGreenplumRow_4_QUERY",query_tGreenplumRow_4);
try {
		stmt_tGreenplumRow_4.execute(query_tGreenplumRow_4);
		
	    		log.info("tGreenplumRow_4 - Execute the query: '" + "insert into sbdt.ingestion_log (row_id,run_id, source_name, table_name, no_of_records, status, updated_by, start_time, end_time, log_time, last_update_date) " +
"values ((select nextval('sbdt.seq_ingestion_log')), "+
(Integer)context.RUN_ID+
", '" +
((String)globalMap.get("row1.source_name")) +
"', '" +
((String)globalMap.get("row1.log_table_name")) +
"', null, 'STARTED', 'Talend'" +
", to_timestamp('" + 
new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(TalendDate.getCurrentDate()).toString() +
"', 'YYYY-MM-DD HH24:MI:SS')::timestamp without time zone" +
", null" +
", to_timestamp('" + 
new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(TalendDate.getCurrentDate()).toString() +
"', 'YYYY-MM-DD HH24:MI:SS')::timestamp without time zone " +
", to_timestamp(" + 
((globalMap.get("row1.last_update_date")==null) ? "null" : ("'" + String.valueOf(new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(((java.util.Date)globalMap.get("row1.last_update_date")))) + "'")) + 
", 'YYYY-MM-DD HH24:MI:SS')::timestamp without time zone) "
 + "' has finished.");
			
	} catch (java.lang.Exception e) {
		whetherReject_tGreenplumRow_4 = true;
		
			throw(e);
			
	}
	
	if(!whetherReject_tGreenplumRow_4) {
		
	}
	

 


	tos_count_tGreenplumRow_4++;

/**
 * [tGreenplumRow_4 main ] stop
 */
	
	/**
	 * [tGreenplumRow_4 end ] start
	 */

	

	
	
	currentComponent="tGreenplumRow_4";

	

	
	stmt_tGreenplumRow_4.close();	

 
                if(log.isDebugEnabled())
            log.debug("tGreenplumRow_4 - "  + ("Done.") );

ok_Hash.put("tGreenplumRow_4", true);
end_Hash.put("tGreenplumRow_4", System.currentTimeMillis());

				if(execStat){   
   	 				runStat.updateStatOnConnection("OnComponentOk6", 0, "ok");
				}
				tGreenplumInput_2Process(globalMap);



/**
 * [tGreenplumRow_4 end ] stop
 */
						if(execStat){
							runStat.updateStatOnConnection("iterate1", 2, "exec" + NB_ITERATE_tGreenplumRow_4);
						}				
					







	
	/**
	 * [tGreenplumInput_1 end ] start
	 */

	

	
	
	currentComponent="tGreenplumInput_1";

	

	}
}finally{
	stmt_tGreenplumInput_1.close();

}
globalMap.put("tGreenplumInput_1_NB_LINE",nb_line_tGreenplumInput_1);
	    		log.debug("tGreenplumInput_1 - Retrieved records count: "+nb_line_tGreenplumInput_1 + " .");
			

 
                if(log.isDebugEnabled())
            log.debug("tGreenplumInput_1 - "  + ("Done.") );

ok_Hash.put("tGreenplumInput_1", true);
end_Hash.put("tGreenplumInput_1", System.currentTimeMillis());




/**
 * [tGreenplumInput_1 end ] stop
 */

	
	/**
	 * [tFlowToIterate_1 end ] start
	 */

	

	
	
	currentComponent="tFlowToIterate_1";

	

globalMap.put("tFlowToIterate_1_NB_LINE",nb_line_tFlowToIterate_1);
			if(execStat){
				if(resourceMap.get("inIterateVComp") == null || !((Boolean)resourceMap.get("inIterateVComp"))){
			 		runStat.updateStatOnConnection("row1"+iterateId,2, 0); 
			 	}
			}
		
 
                if(log.isDebugEnabled())
            log.debug("tFlowToIterate_1 - "  + ("Done.") );

ok_Hash.put("tFlowToIterate_1", true);
end_Hash.put("tFlowToIterate_1", System.currentTimeMillis());




/**
 * [tFlowToIterate_1 end ] stop
 */



				}//end the resume

				
				    			if(resumeEntryMethodName == null || globalResumeTicket){
				    				resumeUtil.addLog("CHECKPOINT", "CONNECTION:SUBJOB_OK:tGreenplumInput_1:OnSubjobOk", "", Thread.currentThread().getId() + "", "", "", "", "", "");
								}	    				    			
					    	
								if(execStat){    	
									runStat.updateStatOnConnection("OnSubjobOk19", 0, "ok");
								} 
							
							tGreenplumClose_1Process(globalMap); 
						



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage());
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tGreenplumInput_1 finally ] start
	 */

	

	
	
	currentComponent="tGreenplumInput_1";

	

 



/**
 * [tGreenplumInput_1 finally ] stop
 */

	
	/**
	 * [tFlowToIterate_1 finally ] start
	 */

	

	
	
	currentComponent="tFlowToIterate_1";

	

 



/**
 * [tFlowToIterate_1 finally ] stop
 */

	
	/**
	 * [tGreenplumRow_4 finally ] start
	 */

	

	
	
	currentComponent="tGreenplumRow_4";

	

 



/**
 * [tGreenplumRow_4 finally ] stop
 */






				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tGreenplumInput_1_SUBPROCESS_STATE", 1);
	}
	


public static class row3Struct implements routines.system.IPersistableRow<row3Struct> {
    final static byte[] commonByteArrayLock_AWS_DEV_TALEND_INGESTION_FRAMEWORK_AS400_to_greenplum_with_GPLoad = new byte[0];
    static byte[] commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_AS400_to_greenplum_with_GPLoad = new byte[0];

	
			    public BigDecimal row_id;

				public BigDecimal getRow_id () {
					return this.row_id;
				}
				



    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_AWS_DEV_TALEND_INGESTION_FRAMEWORK_AS400_to_greenplum_with_GPLoad) {

        	try {

        		int length = 0;
		
						this.row_id = (BigDecimal) dis.readObject();
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		
			} catch(ClassNotFoundException eCNFE) {
				 throw new RuntimeException(eCNFE);
		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// BigDecimal
				
       			    	dos.writeObject(this.row_id);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("row_id="+String.valueOf(row_id));
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				if(row_id == null){
        					sb.append("<null>");
        				}else{
            				sb.append(row_id);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(row3Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}
public void tGreenplumInput_2Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tGreenplumInput_2_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;



		row3Struct row3 = new row3Struct();




	
	/**
	 * [tFlowToIterate_2 begin ] start
	 */

	

	
		
		ok_Hash.put("tFlowToIterate_2", false);
		start_Hash.put("tFlowToIterate_2", System.currentTimeMillis());
		
	
	currentComponent="tFlowToIterate_2";

	
			if (execStat) {
				if(resourceMap.get("inIterateVComp") == null){
					
						runStat.updateStatOnConnection("row3" + iterateId, 0, 0);
					
				}
			} 

		
		int tos_count_tFlowToIterate_2 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tFlowToIterate_2 - "  + ("Start to work.") );
    	class BytesLimit65535_tFlowToIterate_2{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tFlowToIterate_2 = new StringBuilder();
            log4jParamters_tFlowToIterate_2.append("Parameters:");
                    log4jParamters_tFlowToIterate_2.append("DEFAULT_MAP" + " = " + "true");
                log4jParamters_tFlowToIterate_2.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tFlowToIterate_2 - "  + (log4jParamters_tFlowToIterate_2) );
    		}
    	}
    	
        new BytesLimit65535_tFlowToIterate_2().limitLog4jByte();

int nb_line_tFlowToIterate_2 = 0;
int counter_tFlowToIterate_2 = 0;

 



/**
 * [tFlowToIterate_2 begin ] stop
 */



	
	/**
	 * [tGreenplumInput_2 begin ] start
	 */

	

	
		
		ok_Hash.put("tGreenplumInput_2", false);
		start_Hash.put("tGreenplumInput_2", System.currentTimeMillis());
		
	
	currentComponent="tGreenplumInput_2";

	
		int tos_count_tGreenplumInput_2 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tGreenplumInput_2 - "  + ("Start to work.") );
    	class BytesLimit65535_tGreenplumInput_2{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tGreenplumInput_2 = new StringBuilder();
            log4jParamters_tGreenplumInput_2.append("Parameters:");
                    log4jParamters_tGreenplumInput_2.append("USE_EXISTING_CONNECTION" + " = " + "true");
                log4jParamters_tGreenplumInput_2.append(" | ");
                    log4jParamters_tGreenplumInput_2.append("CONNECTION" + " = " + "tGreenplumConnection_2");
                log4jParamters_tGreenplumInput_2.append(" | ");
                    log4jParamters_tGreenplumInput_2.append("TABLE" + " = " + "\"\"");
                log4jParamters_tGreenplumInput_2.append(" | ");
                    log4jParamters_tGreenplumInput_2.append("QUERYSTORE" + " = " + "\"\"");
                log4jParamters_tGreenplumInput_2.append(" | ");
                    log4jParamters_tGreenplumInput_2.append("QUERY" + " = " + "\"select row_id from sbdt.ingestion_log where source_name = '\" +   ((String)globalMap.get(\"row1.source_name\")) +  \"' and table_name = '\" +  ((String)globalMap.get(\"row1.log_table_name\")) +  \"' and status='STARTED' and updated_by='Talend' order by row_id desc limit 1\"");
                log4jParamters_tGreenplumInput_2.append(" | ");
                    log4jParamters_tGreenplumInput_2.append("USE_CURSOR" + " = " + "false");
                log4jParamters_tGreenplumInput_2.append(" | ");
                    log4jParamters_tGreenplumInput_2.append("TRIM_ALL_COLUMN" + " = " + "false");
                log4jParamters_tGreenplumInput_2.append(" | ");
                    log4jParamters_tGreenplumInput_2.append("TRIM_COLUMN" + " = " + "[{TRIM="+("false")+", SCHEMA_COLUMN="+("row_id")+"}]");
                log4jParamters_tGreenplumInput_2.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tGreenplumInput_2 - "  + (log4jParamters_tGreenplumInput_2) );
    		}
    	}
    	
        new BytesLimit65535_tGreenplumInput_2().limitLog4jByte();
	
    
	
		    int nb_line_tGreenplumInput_2 = 0;
		    java.sql.Connection conn_tGreenplumInput_2 = null;
		        conn_tGreenplumInput_2 = (java.sql.Connection)globalMap.get("conn_tGreenplumConnection_2");
				
				if(conn_tGreenplumInput_2 != null) {
					if(conn_tGreenplumInput_2.getMetaData() != null) {
						
						log.debug("tGreenplumInput_2 - Uses an existing connection with username '" + conn_tGreenplumInput_2.getMetaData().getUserName() + "'. Connection URL: " + conn_tGreenplumInput_2.getMetaData().getURL() + ".");
						
					}
				}
			
		    
			java.sql.Statement stmt_tGreenplumInput_2 = conn_tGreenplumInput_2.createStatement();

		    String dbquery_tGreenplumInput_2 = "select row_id from sbdt.ingestion_log where source_name = '" + 
((String)globalMap.get("row1.source_name")) +
"' and table_name = '" +
((String)globalMap.get("row1.log_table_name")) +
"' and status='STARTED' and updated_by='Talend' order by row_id desc limit 1";
			
                log.debug("tGreenplumInput_2 - Executing the query: '"+dbquery_tGreenplumInput_2+"'.");
			

                       globalMap.put("tGreenplumInput_2_QUERY",dbquery_tGreenplumInput_2);

		    java.sql.ResultSet rs_tGreenplumInput_2 = null;
		try{
		    rs_tGreenplumInput_2 = stmt_tGreenplumInput_2.executeQuery(dbquery_tGreenplumInput_2);
		    java.sql.ResultSetMetaData rsmd_tGreenplumInput_2 = rs_tGreenplumInput_2.getMetaData();
		    int colQtyInRs_tGreenplumInput_2 = rsmd_tGreenplumInput_2.getColumnCount();

		    String tmpContent_tGreenplumInput_2 = null;
		    
		    
		    	log.debug("tGreenplumInput_2 - Retrieving records from the database.");
		    
		    while (rs_tGreenplumInput_2.next()) {
		        nb_line_tGreenplumInput_2++;
		        
							if(colQtyInRs_tGreenplumInput_2 < 1) {
								row3.row_id = null;
							} else {
		                          
            if(rs_tGreenplumInput_2.getObject(1) != null) {
                row3.row_id = rs_tGreenplumInput_2.getBigDecimal(1);
            } else {
                    throw new RuntimeException("Null value in non-Nullable column");
            }
		                    }
					
						log.debug("tGreenplumInput_2 - Retrieving the record " + nb_line_tGreenplumInput_2 + ".");
					


 



/**
 * [tGreenplumInput_2 begin ] stop
 */
	
	/**
	 * [tGreenplumInput_2 main ] start
	 */

	

	
	
	currentComponent="tGreenplumInput_2";

	

 


	tos_count_tGreenplumInput_2++;

/**
 * [tGreenplumInput_2 main ] stop
 */

	
	/**
	 * [tFlowToIterate_2 main ] start
	 */

	

	
	
	currentComponent="tFlowToIterate_2";

	

			//row3
			//row3


			
				if(execStat){
					runStat.updateStatOnConnection("row3"+iterateId,1, 1);
				} 
			

		
    			if(log.isTraceEnabled()){
    				log.trace("row3 - " + (row3==null? "": row3.toLogString()));
    			}
    		


    	
                if(log.isTraceEnabled())
            log.trace("tFlowToIterate_2 - "  + ("Set global var, key=row3.row_id, value=")  + (row3.row_id)  + (".") );            
            globalMap.put("row3.row_id", row3.row_id);
    	
 
	   nb_line_tFlowToIterate_2++;  
       counter_tFlowToIterate_2++;
                if(log.isDebugEnabled())
            log.debug("tFlowToIterate_2 - "  + ("Current iteration is: ")  + (counter_tFlowToIterate_2)  + (".") );
       globalMap.put("tFlowToIterate_2_CURRENT_ITERATION", counter_tFlowToIterate_2);
 


	tos_count_tFlowToIterate_2++;

/**
 * [tFlowToIterate_2 main ] stop
 */



	
	/**
	 * [tGreenplumInput_2 end ] start
	 */

	

	
	
	currentComponent="tGreenplumInput_2";

	

	}
}finally{
	stmt_tGreenplumInput_2.close();

}
globalMap.put("tGreenplumInput_2_NB_LINE",nb_line_tGreenplumInput_2);
	    		log.debug("tGreenplumInput_2 - Retrieved records count: "+nb_line_tGreenplumInput_2 + " .");
			

 
                if(log.isDebugEnabled())
            log.debug("tGreenplumInput_2 - "  + ("Done.") );

ok_Hash.put("tGreenplumInput_2", true);
end_Hash.put("tGreenplumInput_2", System.currentTimeMillis());




/**
 * [tGreenplumInput_2 end ] stop
 */

	
	/**
	 * [tFlowToIterate_2 end ] start
	 */

	

	
	
	currentComponent="tFlowToIterate_2";

	

globalMap.put("tFlowToIterate_2_NB_LINE",nb_line_tFlowToIterate_2);
			if(execStat){
				if(resourceMap.get("inIterateVComp") == null || !((Boolean)resourceMap.get("inIterateVComp"))){
			 		runStat.updateStatOnConnection("row3"+iterateId,2, 0); 
			 	}
			}
		
 
                if(log.isDebugEnabled())
            log.debug("tFlowToIterate_2 - "  + ("Done.") );

ok_Hash.put("tFlowToIterate_2", true);
end_Hash.put("tFlowToIterate_2", System.currentTimeMillis());




/**
 * [tFlowToIterate_2 end ] stop
 */



				}//end the resume

				
				    			if(resumeEntryMethodName == null || globalResumeTicket){
				    				resumeUtil.addLog("CHECKPOINT", "CONNECTION:SUBJOB_OK:tGreenplumInput_2:OnSubjobOk", "", Thread.currentThread().getId() + "", "", "", "", "", "");
								}	    				    			
					    	
								if(execStat){    	
									runStat.updateStatOnConnection("OnSubjobOk1", 0, "ok");
								} 
							
							tSetGlobalVar_1Process(globalMap); 
						



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage());
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tGreenplumInput_2 finally ] start
	 */

	

	
	
	currentComponent="tGreenplumInput_2";

	

 



/**
 * [tGreenplumInput_2 finally ] stop
 */

	
	/**
	 * [tFlowToIterate_2 finally ] start
	 */

	

	
	
	currentComponent="tFlowToIterate_2";

	

 



/**
 * [tFlowToIterate_2 finally ] stop
 */



				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tGreenplumInput_2_SUBPROCESS_STATE", 1);
	}
	

public void tSetGlobalVar_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tSetGlobalVar_1_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tSetGlobalVar_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tSetGlobalVar_1", false);
		start_Hash.put("tSetGlobalVar_1", System.currentTimeMillis());
		
	
	currentComponent="tSetGlobalVar_1";

	
		int tos_count_tSetGlobalVar_1 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tSetGlobalVar_1 - "  + ("Start to work.") );
    	class BytesLimit65535_tSetGlobalVar_1{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tSetGlobalVar_1 = new StringBuilder();
            log4jParamters_tSetGlobalVar_1.append("Parameters:");
                    log4jParamters_tSetGlobalVar_1.append("VARIABLES" + " = " + "[{VALUE="+("\"\"")+", KEY="+("\"kicsi\"")+"}, {VALUE="+("0")+", KEY="+("\"cnt\"")+"}, {VALUE="+("\"\"")+", KEY="+("\"where_cond\"")+"}, {VALUE="+("\"\"")+", KEY="+("\"columnlist\"")+"}, {VALUE="+("\"\"")+", KEY="+("\"filetocheck\"")+"}, {VALUE="+("\"\"")+", KEY="+("\"distributed\"")+"}]");
                log4jParamters_tSetGlobalVar_1.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tSetGlobalVar_1 - "  + (log4jParamters_tSetGlobalVar_1) );
    		}
    	}
    	
        new BytesLimit65535_tSetGlobalVar_1().limitLog4jByte();

 



/**
 * [tSetGlobalVar_1 begin ] stop
 */
	
	/**
	 * [tSetGlobalVar_1 main ] start
	 */

	

	
	
	currentComponent="tSetGlobalVar_1";

	

globalMap.put("kicsi", "");
globalMap.put("cnt", 0);
globalMap.put("where_cond", "");
globalMap.put("columnlist", "");
globalMap.put("filetocheck", "");
globalMap.put("distributed", "");

 


	tos_count_tSetGlobalVar_1++;

/**
 * [tSetGlobalVar_1 main ] stop
 */
	
	/**
	 * [tSetGlobalVar_1 end ] start
	 */

	

	
	
	currentComponent="tSetGlobalVar_1";

	

 
                if(log.isDebugEnabled())
            log.debug("tSetGlobalVar_1 - "  + ("Done.") );

ok_Hash.put("tSetGlobalVar_1", true);
end_Hash.put("tSetGlobalVar_1", System.currentTimeMillis());




/**
 * [tSetGlobalVar_1 end ] stop
 */
				}//end the resume

				
				    			if(resumeEntryMethodName == null || globalResumeTicket){
				    				resumeUtil.addLog("CHECKPOINT", "CONNECTION:SUBJOB_OK:tSetGlobalVar_1:OnSubjobOk", "", Thread.currentThread().getId() + "", "", "", "", "", "");
								}	    				    			
					    	
								if(execStat){    	
									runStat.updateStatOnConnection("OnSubjobOk14", 0, "ok");
								} 
							
							tJava_4Process(globalMap); 
						



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage());
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tSetGlobalVar_1 finally ] start
	 */

	

	
	
	currentComponent="tSetGlobalVar_1";

	

 



/**
 * [tSetGlobalVar_1 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tSetGlobalVar_1_SUBPROCESS_STATE", 1);
	}
	

public void tJava_4Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tJava_4_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tJava_4 begin ] start
	 */

	

	
		
		ok_Hash.put("tJava_4", false);
		start_Hash.put("tJava_4", System.currentTimeMillis());
		
	
	currentComponent="tJava_4";

	
		int tos_count_tJava_4 = 0;
		
    	class BytesLimit65535_tJava_4{
    		public void limitLog4jByte() throws Exception{
    			
    		}
    	}
    	
        new BytesLimit65535_tJava_4().limitLog4jByte();


globalMap.put("filetocheck", 
context.ETL_STORAGE_PATH + "/" + context.GP_SOURCE_NAME + '/' + "/data/" + 
context.SOURCE_DATABASE + "/" + ((String)globalMap.get("row1.log_table_name")).replace("\"","").replace("#","__hash__").replace("$","__dollar__")  + 
".gz");

if (((String)globalMap.get("row1.update_type")).equals("incremental")) {
globalMap.put("where_cond", 
((String)globalMap.get("row1.update_col")) + 
" > to_timestamp('" + 
new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(((java.util.Date)globalMap.get("row1.last_update_date"))).toString() + 
"', 'YYYY-MM-DD HH24:MI:SS') and " +
((String)globalMap.get("row1.update_col")) + 
" <= to_timestamp('" + 
new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(((java.util.Date)globalMap.get("row1.now"))).toString() + 
"', 'YYYY-MM-DD HH24:MI:SS')"
);
if ( context.TOP_N_ROWS != null) { 
	globalMap.put("where_cond", (String)globalMap.get("where_cond") +" fetch first "+context.TOP_N_ROWS.toString()+" rows only");
	}
	
}
else {
	if ( context.TOP_N_ROWS != null) { 
	globalMap.put("where_cond","1=1 fetch first "+context.TOP_N_ROWS.toString()+" rows only");}
	else{
	globalMap.put("where_cond", "1=1");}
}
globalMap.put("tJavaRow_2_ERROR_MESSAGE", null);
 



/**
 * [tJava_4 begin ] stop
 */
	
	/**
	 * [tJava_4 main ] start
	 */

	

	
	
	currentComponent="tJava_4";

	

 


	tos_count_tJava_4++;

/**
 * [tJava_4 main ] stop
 */
	
	/**
	 * [tJava_4 end ] start
	 */

	

	
	
	currentComponent="tJava_4";

	

 

ok_Hash.put("tJava_4", true);
end_Hash.put("tJava_4", System.currentTimeMillis());




/**
 * [tJava_4 end ] stop
 */
				}//end the resume

				
				    			if(resumeEntryMethodName == null || globalResumeTicket){
				    				resumeUtil.addLog("CHECKPOINT", "CONNECTION:SUBJOB_OK:tJava_4:OnSubjobOk", "", Thread.currentThread().getId() + "", "", "", "", "", "");
								}	    				    			
					    	
								if(execStat){    	
									runStat.updateStatOnConnection("OnSubjobOk22", 0, "ok");
								} 
							
							tCreateTemporaryFile_1Process(globalMap); 
						



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage());
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tJava_4 finally ] start
	 */

	

	
	
	currentComponent="tJava_4";

	

 



/**
 * [tJava_4 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tJava_4_SUBPROCESS_STATE", 1);
	}
	

public void tCreateTemporaryFile_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tCreateTemporaryFile_1_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tCreateTemporaryFile_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tCreateTemporaryFile_1", false);
		start_Hash.put("tCreateTemporaryFile_1", System.currentTimeMillis());
		
	
	currentComponent="tCreateTemporaryFile_1";

	
		int tos_count_tCreateTemporaryFile_1 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tCreateTemporaryFile_1 - "  + ("Start to work.") );
    	class BytesLimit65535_tCreateTemporaryFile_1{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tCreateTemporaryFile_1 = new StringBuilder();
            log4jParamters_tCreateTemporaryFile_1.append("Parameters:");
                    log4jParamters_tCreateTemporaryFile_1.append("REMOVE" + " = " + "true");
                log4jParamters_tCreateTemporaryFile_1.append(" | ");
                    log4jParamters_tCreateTemporaryFile_1.append("USE_DEFAULT_DIR" + " = " + "false");
                log4jParamters_tCreateTemporaryFile_1.append(" | ");
                    log4jParamters_tCreateTemporaryFile_1.append("DIRECTORY" + " = " + "context.ETL_STORAGE_PATH + \"/\" +context.GP_SOURCE_NAME + \"/\" + \"/data/\"+context.SOURCE_DATABASE + \"/\"");
                log4jParamters_tCreateTemporaryFile_1.append(" | ");
                    log4jParamters_tCreateTemporaryFile_1.append("TEMPLATE" + " = " + "((String)globalMap.get(\"row1.log_table_name\")).replace(\"\\\"\",\"\").replace(\"#\",\"__hash__\").replace(\"$\",\"__dollar__\") + \"_XXXX_is\"");
                log4jParamters_tCreateTemporaryFile_1.append(" | ");
                    log4jParamters_tCreateTemporaryFile_1.append("SUFFIX" + " = " + "\"running\"");
                log4jParamters_tCreateTemporaryFile_1.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tCreateTemporaryFile_1 - "  + (log4jParamters_tCreateTemporaryFile_1) );
    		}
    	}
    	
        new BytesLimit65535_tCreateTemporaryFile_1().limitLog4jByte();


				final StringBuffer log4jSb_tCreateTemporaryFile_1 = new StringBuffer();
			
	java.io.File dir_tCreateTemporaryFile_1 = new java.io.File(context.ETL_STORAGE_PATH + "/" +context.GP_SOURCE_NAME + "/" + "/data/"+context.SOURCE_DATABASE + "/");
dir_tCreateTemporaryFile_1.mkdirs();
String name_tCreateTemporaryFile_1 = ((String)globalMap.get("row1.log_table_name")).replace("\"","").replace("#","__hash__").replace("$","__dollar__") + "_XXXX_is".replaceAll("XXXX", routines.TalendString.getAsciiRandomString(4).toUpperCase());
String suffix_tCreateTemporaryFile_1 = ("running".replaceAll("\\.", "").length() == 0) ? "tmp" : "running".replaceAll("\\.", "");
java.io.File file_tCreateTemporaryFile_1 = new java.io.File(dir_tCreateTemporaryFile_1, name_tCreateTemporaryFile_1 + "." + suffix_tCreateTemporaryFile_1);
if (file_tCreateTemporaryFile_1.createNewFile()){ 
    file_tCreateTemporaryFile_1.deleteOnExit();
}
globalMap.put("tCreateTemporaryFile_1_FILEPATH", file_tCreateTemporaryFile_1.getCanonicalPath());

	log.info("tCreateTemporaryFile_1 - tmp file path : " + file_tCreateTemporaryFile_1.getCanonicalPath() + ".");

 



/**
 * [tCreateTemporaryFile_1 begin ] stop
 */
	
	/**
	 * [tCreateTemporaryFile_1 main ] start
	 */

	

	
	
	currentComponent="tCreateTemporaryFile_1";

	

 


	tos_count_tCreateTemporaryFile_1++;

/**
 * [tCreateTemporaryFile_1 main ] stop
 */
	
	/**
	 * [tCreateTemporaryFile_1 end ] start
	 */

	

	
	
	currentComponent="tCreateTemporaryFile_1";

	

 
                if(log.isDebugEnabled())
            log.debug("tCreateTemporaryFile_1 - "  + ("Done.") );

ok_Hash.put("tCreateTemporaryFile_1", true);
end_Hash.put("tCreateTemporaryFile_1", System.currentTimeMillis());




/**
 * [tCreateTemporaryFile_1 end ] stop
 */
				}//end the resume

				
				    			if(resumeEntryMethodName == null || globalResumeTicket){
				    				resumeUtil.addLog("CHECKPOINT", "CONNECTION:SUBJOB_OK:tCreateTemporaryFile_1:OnSubjobOk", "", Thread.currentThread().getId() + "", "", "", "", "", "");
								}	    				    			
					    	
								if(execStat){    	
									runStat.updateStatOnConnection("OnSubjobOk5", 0, "ok");
								} 
							
							tAS400Connection_1Process(globalMap); 
						



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage());
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tCreateTemporaryFile_1 finally ] start
	 */

	

	
	
	currentComponent="tCreateTemporaryFile_1";

	

 



/**
 * [tCreateTemporaryFile_1 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tCreateTemporaryFile_1_SUBPROCESS_STATE", 1);
	}
	

public void tAS400Connection_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tAS400Connection_1_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tAS400Connection_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tAS400Connection_1", false);
		start_Hash.put("tAS400Connection_1", System.currentTimeMillis());
		
	
	currentComponent="tAS400Connection_1";

	
		int tos_count_tAS400Connection_1 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tAS400Connection_1 - "  + ("Start to work.") );
    	class BytesLimit65535_tAS400Connection_1{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tAS400Connection_1 = new StringBuilder();
            log4jParamters_tAS400Connection_1.append("Parameters:");
                    log4jParamters_tAS400Connection_1.append("DB_VERSION" + " = " + "jt400_V5R2.jar");
                log4jParamters_tAS400Connection_1.append(" | ");
                    log4jParamters_tAS400Connection_1.append("HOST" + " = " + "context.getProperty(\"SOURCE_HOST\")");
                log4jParamters_tAS400Connection_1.append(" | ");
                    log4jParamters_tAS400Connection_1.append("DBNAME" + " = " + "(String)globalMap.get(\"row1.source_schema\")");
                log4jParamters_tAS400Connection_1.append(" | ");
                    log4jParamters_tAS400Connection_1.append("USER" + " = " + "context.getProperty(\"SOURCE_USER\")");
                log4jParamters_tAS400Connection_1.append(" | ");
                    log4jParamters_tAS400Connection_1.append("PASS" + " = " + String.valueOf(routines.system.PasswordEncryptUtil.encryptPassword(context.SOURCE_PASSWORD)).substring(0, 4) + "...");     
                log4jParamters_tAS400Connection_1.append(" | ");
                    log4jParamters_tAS400Connection_1.append("USE_SHARED_CONNECTION" + " = " + "false");
                log4jParamters_tAS400Connection_1.append(" | ");
                    log4jParamters_tAS400Connection_1.append("PROPERTIES" + " = " + "\"prompt=false\"");
                log4jParamters_tAS400Connection_1.append(" | ");
                    log4jParamters_tAS400Connection_1.append("AUTO_COMMIT" + " = " + "false");
                log4jParamters_tAS400Connection_1.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tAS400Connection_1 - "  + (log4jParamters_tAS400Connection_1) );
    		}
    	}
    	
        new BytesLimit65535_tAS400Connection_1().limitLog4jByte();
	

	 
    	String url_tAS400Connection_1 = "jdbc:as400://" + context.getProperty("SOURCE_HOST") + "/" + (String)globalMap.get("row1.source_schema") + ";" + "prompt=false";

	String dbUser_tAS400Connection_1 = context.getProperty("SOURCE_USER");
	
	
		
	final String decryptedPassword_tAS400Connection_1 = context.SOURCE_PASSWORD; 
		String dbPwd_tAS400Connection_1 = decryptedPassword_tAS400Connection_1;
	

	java.sql.Connection conn_tAS400Connection_1 = null;
	
		
			String driverClass_tAS400Connection_1 = "com.ibm.as400.access.AS400JDBCDriver";
			java.lang.Class.forName(driverClass_tAS400Connection_1);
		
	    		log.debug("tAS400Connection_1 - Driver ClassName: "+driverClass_tAS400Connection_1+".");
			
	    		log.debug("tAS400Connection_1 - Connection attempt to '" + url_tAS400Connection_1 + "' with the username '" + dbUser_tAS400Connection_1 + "'.");
			
		conn_tAS400Connection_1 = java.sql.DriverManager.getConnection(url_tAS400Connection_1,dbUser_tAS400Connection_1,dbPwd_tAS400Connection_1);
	    		log.debug("tAS400Connection_1 - Connection to '" + url_tAS400Connection_1 + "' has succeeded.");
			

		globalMap.put("conn_tAS400Connection_1", conn_tAS400Connection_1);
	if (null != conn_tAS400Connection_1) {
		
			log.debug("tAS400Connection_1 - Connection is set auto commit to 'false'.");
			conn_tAS400Connection_1.setAutoCommit(false);
	}

	globalMap.put("conn_" + "tAS400Connection_1",conn_tAS400Connection_1);

 



/**
 * [tAS400Connection_1 begin ] stop
 */
	
	/**
	 * [tAS400Connection_1 main ] start
	 */

	

	
	
	currentComponent="tAS400Connection_1";

	

 


	tos_count_tAS400Connection_1++;

/**
 * [tAS400Connection_1 main ] stop
 */
	
	/**
	 * [tAS400Connection_1 end ] start
	 */

	

	
	
	currentComponent="tAS400Connection_1";

	

 
                if(log.isDebugEnabled())
            log.debug("tAS400Connection_1 - "  + ("Done.") );

ok_Hash.put("tAS400Connection_1", true);
end_Hash.put("tAS400Connection_1", System.currentTimeMillis());

				if(execStat){   
   	 				runStat.updateStatOnConnection("OnComponentOk9", 0, "ok");
				}
				tJDBCColumnList_1Process(globalMap);



/**
 * [tAS400Connection_1 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage());
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tAS400Connection_1 finally ] start
	 */

	

	
	
	currentComponent="tAS400Connection_1";

	

 



/**
 * [tAS400Connection_1 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tAS400Connection_1_SUBPROCESS_STATE", 1);
	}
	


public static class OnSubjobOkStructtIterateToFlow_1 implements routines.system.IPersistableRow<OnSubjobOkStructtIterateToFlow_1> {
    final static byte[] commonByteArrayLock_AWS_DEV_TALEND_INGESTION_FRAMEWORK_AS400_to_greenplum_with_GPLoad = new byte[0];
    static byte[] commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_AS400_to_greenplum_with_GPLoad = new byte[0];

	
			    public String TableName;

				public String getTableName () {
					return this.TableName;
				}
				
			    public String ColumnName;

				public String getColumnName () {
					return this.ColumnName;
				}
				
			    public Integer ColumnLength;

				public Integer getColumnLength () {
					return this.ColumnLength;
				}
				
			    public Integer ColumnPrecision;

				public Integer getColumnPrecision () {
					return this.ColumnPrecision;
				}
				
			    public Integer ColumnType;

				public Integer getColumnType () {
					return this.ColumnType;
				}
				
			    public String ColumnTypeName;

				public String getColumnTypeName () {
					return this.ColumnTypeName;
				}
				



	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_AS400_to_greenplum_with_GPLoad.length) {
				if(length < 1024 && commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_AS400_to_greenplum_with_GPLoad.length == 0) {
   					commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_AS400_to_greenplum_with_GPLoad = new byte[1024];
				} else {
   					commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_AS400_to_greenplum_with_GPLoad = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_AS400_to_greenplum_with_GPLoad, 0, length);
			strReturn = new String(commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_AS400_to_greenplum_with_GPLoad, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
	private Integer readInteger(ObjectInputStream dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}

	private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException{
		if(intNum == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeInt(intNum);
    	}
	}

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_AWS_DEV_TALEND_INGESTION_FRAMEWORK_AS400_to_greenplum_with_GPLoad) {

        	try {

        		int length = 0;
		
					this.TableName = readString(dis);
					
					this.ColumnName = readString(dis);
					
						this.ColumnLength = readInteger(dis);
					
						this.ColumnPrecision = readInteger(dis);
					
						this.ColumnType = readInteger(dis);
					
					this.ColumnTypeName = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// String
				
						writeString(this.TableName,dos);
					
					// String
				
						writeString(this.ColumnName,dos);
					
					// Integer
				
						writeInteger(this.ColumnLength,dos);
					
					// Integer
				
						writeInteger(this.ColumnPrecision,dos);
					
					// Integer
				
						writeInteger(this.ColumnType,dos);
					
					// String
				
						writeString(this.ColumnTypeName,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("TableName="+TableName);
		sb.append(",ColumnName="+ColumnName);
		sb.append(",ColumnLength="+String.valueOf(ColumnLength));
		sb.append(",ColumnPrecision="+String.valueOf(ColumnPrecision));
		sb.append(",ColumnType="+String.valueOf(ColumnType));
		sb.append(",ColumnTypeName="+ColumnTypeName);
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				if(TableName == null){
        					sb.append("<null>");
        				}else{
            				sb.append(TableName);
            			}
            		
        			sb.append("|");
        		
        				if(ColumnName == null){
        					sb.append("<null>");
        				}else{
            				sb.append(ColumnName);
            			}
            		
        			sb.append("|");
        		
        				if(ColumnLength == null){
        					sb.append("<null>");
        				}else{
            				sb.append(ColumnLength);
            			}
            		
        			sb.append("|");
        		
        				if(ColumnPrecision == null){
        					sb.append("<null>");
        				}else{
            				sb.append(ColumnPrecision);
            			}
            		
        			sb.append("|");
        		
        				if(ColumnType == null){
        					sb.append("<null>");
        				}else{
            				sb.append(ColumnType);
            			}
            		
        			sb.append("|");
        		
        				if(ColumnTypeName == null){
        					sb.append("<null>");
        				}else{
            				sb.append(ColumnTypeName);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(OnSubjobOkStructtIterateToFlow_1 other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}
public void tJDBCColumnList_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tJDBCColumnList_1_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
		String currentVirtualComponent = null;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tJDBCColumnList_1 begin ] start
	 */

				
			int NB_ITERATE_tIterateToFlow_1_ITFO = 0; //for statistics
			

	
		
		ok_Hash.put("tJDBCColumnList_1", false);
		start_Hash.put("tJDBCColumnList_1", System.currentTimeMillis());
		
	
	currentComponent="tJDBCColumnList_1";

	
		int tos_count_tJDBCColumnList_1 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tJDBCColumnList_1 - "  + ("Start to work.") );
    	class BytesLimit65535_tJDBCColumnList_1{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tJDBCColumnList_1 = new StringBuilder();
            log4jParamters_tJDBCColumnList_1.append("Parameters:");
                    log4jParamters_tJDBCColumnList_1.append("DBTYPE" + " = " + "AS400");
                log4jParamters_tJDBCColumnList_1.append(" | ");
                    log4jParamters_tJDBCColumnList_1.append("CONNECTION_AS400" + " = " + "tAS400Connection_1");
                log4jParamters_tJDBCColumnList_1.append(" | ");
                    log4jParamters_tJDBCColumnList_1.append("TABLE_NAME" + " = " + "((String)globalMap.get(\"row1.source_table_name\"))");
                log4jParamters_tJDBCColumnList_1.append(" | ");
                    log4jParamters_tJDBCColumnList_1.append("DIE_ON_ERROR" + " = " + "true");
                log4jParamters_tJDBCColumnList_1.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tJDBCColumnList_1 - "  + (log4jParamters_tJDBCColumnList_1) );
    		}
    	}
    	
        new BytesLimit65535_tJDBCColumnList_1().limitLog4jByte();

	java.sql.Connection conn_tJDBCColumnList_1 = (java.sql.Connection)globalMap.get("conn_tAS400Connection_1");
    java.sql.Statement stmt2_tJDBCColumnList_1 = null;
    int nb_column_tJDBCColumnList_1 = 0;
    try{
				if(conn_tJDBCColumnList_1 != null) {
					if(conn_tJDBCColumnList_1.getMetaData() != null) {
						
						log.debug("tJDBCColumnList_1 - Uses an existing connection with username '" + conn_tJDBCColumnList_1.getMetaData().getUserName() + "'. Connection URL: " + conn_tJDBCColumnList_1.getMetaData().getURL() + ".");
						
					}
				}
			

String tableName_tJDBCColumnList_1 = ((String)globalMap.get("row1.source_table_name"));

int column_count_tJDBCColumnList_1 = 0;

stmt2_tJDBCColumnList_1 = conn_tJDBCColumnList_1.createStatement();
    log.info("tJDBCColumnList_1 - Query:'"+"SELECT * from " + tableName_tJDBCColumnList_1 + " where 1<>1'.");
java.sql.ResultSet rs_tJDBCColumnList_1 = stmt2_tJDBCColumnList_1.executeQuery("SELECT * from " + tableName_tJDBCColumnList_1 + " where 1<>1");

java.sql.ResultSetMetaData rsMetaData_tJDBCColumnList_1 = rs_tJDBCColumnList_1.getMetaData();

column_count_tJDBCColumnList_1 = rsMetaData_tJDBCColumnList_1.getColumnCount();

for(int i_tJDBCColumnList_1 = 1; i_tJDBCColumnList_1 <= column_count_tJDBCColumnList_1; i_tJDBCColumnList_1++) {

	String currentColumnName_tJDBCColumnList_1 = rsMetaData_tJDBCColumnList_1.getColumnName(i_tJDBCColumnList_1);
	int currentColumnType_tJDBCColumnList_1 = rsMetaData_tJDBCColumnList_1.getColumnType(i_tJDBCColumnList_1);
	String currentColumnTypeName_tJDBCColumnList_1 = rsMetaData_tJDBCColumnList_1.getColumnTypeName(i_tJDBCColumnList_1);
	int currentColumnPrecision_tJDBCColumnList_1 = rsMetaData_tJDBCColumnList_1.getPrecision(i_tJDBCColumnList_1);
	int currentColumnScale_tJDBCColumnList_1 = rsMetaData_tJDBCColumnList_1.getScale(i_tJDBCColumnList_1);
	nb_column_tJDBCColumnList_1++;
        
        log.debug("tJDBCColumnList_1 - Retrieving the column "+i_tJDBCColumnList_1+".");
        StringBuffer logSB_tJDBCColumnList_1 = new StringBuffer("tJDBCColumnList_1 - ");
        logSB_tJDBCColumnList_1.append("Name of column "+i_tJDBCColumnList_1+":"+currentColumnName_tJDBCColumnList_1+" | ")
        .append("Type of column "+i_tJDBCColumnList_1+":"+currentColumnType_tJDBCColumnList_1+" | ")
        .append("Type name of column "+i_tJDBCColumnList_1+":"+currentColumnTypeName_tJDBCColumnList_1+" | ")
        .append("Precision of column "+i_tJDBCColumnList_1+":"+currentColumnPrecision_tJDBCColumnList_1+" | ")
        .append("Scale of column "+i_tJDBCColumnList_1+":"+currentColumnPrecision_tJDBCColumnList_1+" | ");
        log.trace(logSB_tJDBCColumnList_1.toString());
	globalMap.put("tJDBCColumnList_1_CURRENT_COLUMN", currentColumnName_tJDBCColumnList_1);
	globalMap.put("tJDBCColumnList_1_CURRENT_COLUMN_TYPE", currentColumnType_tJDBCColumnList_1);
	globalMap.put("tJDBCColumnList_1_CURRENT_COLUMN_TYPE_NAME", currentColumnTypeName_tJDBCColumnList_1);
	globalMap.put("tJDBCColumnList_1_CURRENT_COLUMN_PRECISION", currentColumnPrecision_tJDBCColumnList_1);
	globalMap.put("tJDBCColumnList_1_CURRENT_COLUMN_SCALE", currentColumnScale_tJDBCColumnList_1);

 



/**
 * [tJDBCColumnList_1 begin ] stop
 */
	
	/**
	 * [tJDBCColumnList_1 main ] start
	 */

	

	
	
	currentComponent="tJDBCColumnList_1";

	

 


	tos_count_tJDBCColumnList_1++;

/**
 * [tJDBCColumnList_1 main ] stop
 */
	NB_ITERATE_tIterateToFlow_1_ITFO++;
	
	
				if(execStat){
					runStat.updateStatOnConnection("iterate4", 1, "exec" + NB_ITERATE_tIterateToFlow_1_ITFO);
					//Thread.sleep(1000);
				}				
			

	
	/**
	 * [tIterateToFlow_1_ITFO begin ] start
	 */

	

	
		
		ok_Hash.put("tIterateToFlow_1_ITFO", false);
		start_Hash.put("tIterateToFlow_1_ITFO", System.currentTimeMillis());
		
	
		currentVirtualComponent = "tIterateToFlow_1";
	
	currentComponent="tIterateToFlow_1_ITFO";

	
		int tos_count_tIterateToFlow_1_ITFO = 0;
		
                if(log.isDebugEnabled())
            log.debug("tIterateToFlow_1_ITFO - "  + ("Start to work.") );
    	class BytesLimit65535_tIterateToFlow_1_ITFO{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tIterateToFlow_1_ITFO = new StringBuilder();
            log4jParamters_tIterateToFlow_1_ITFO.append("Parameters:");
                    log4jParamters_tIterateToFlow_1_ITFO.append("DESTINATION" + " = " + "tIterateToFlow_1");
                log4jParamters_tIterateToFlow_1_ITFO.append(" | ");
                    log4jParamters_tIterateToFlow_1_ITFO.append("MAPPING" + " = " + "[{VALUE="+("((String)globalMap.get(\"row1.target_table_name\"))")+", SCHEMA_COLUMN="+("TableName")+"}, {VALUE="+("((String)globalMap.get(\"tJDBCColumnList_1_CURRENT_COLUMN\"))")+", SCHEMA_COLUMN="+("ColumnName")+"}, {VALUE="+("((Integer)globalMap.get(\"tJDBCColumnList_1_CURRENT_COLUMN_SCALE\"))")+", SCHEMA_COLUMN="+("ColumnLength")+"}, {VALUE="+("((Integer)globalMap.get(\"tJDBCColumnList_1_CURRENT_COLUMN_PRECISION\"))")+", SCHEMA_COLUMN="+("ColumnPrecision")+"}, {VALUE="+("((Integer)globalMap.get(\"tJDBCColumnList_1_CURRENT_COLUMN_TYPE\"))")+", SCHEMA_COLUMN="+("ColumnType")+"}, {VALUE="+("((String)globalMap.get(\"tJDBCColumnList_1_CURRENT_COLUMN_TYPE_NAME\"))")+", SCHEMA_COLUMN="+("ColumnTypeName")+"}]");
                log4jParamters_tIterateToFlow_1_ITFO.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tIterateToFlow_1_ITFO - "  + (log4jParamters_tIterateToFlow_1_ITFO) );
    		}
    	}
    	
        new BytesLimit65535_tIterateToFlow_1_ITFO().limitLog4jByte();

OnSubjobOkStructtIterateToFlow_1 struct_tIterateToFlow_1_ITFO = new OnSubjobOkStructtIterateToFlow_1();
struct_tIterateToFlow_1_ITFO.TableName  = ((String)globalMap.get("row1.target_table_name"));
struct_tIterateToFlow_1_ITFO.ColumnName  = ((String)globalMap.get("tJDBCColumnList_1_CURRENT_COLUMN"));
struct_tIterateToFlow_1_ITFO.ColumnLength  = ((Integer)globalMap.get("tJDBCColumnList_1_CURRENT_COLUMN_SCALE"));
struct_tIterateToFlow_1_ITFO.ColumnPrecision  = ((Integer)globalMap.get("tJDBCColumnList_1_CURRENT_COLUMN_PRECISION"));
struct_tIterateToFlow_1_ITFO.ColumnType  = ((Integer)globalMap.get("tJDBCColumnList_1_CURRENT_COLUMN_TYPE"));
struct_tIterateToFlow_1_ITFO.ColumnTypeName  = ((String)globalMap.get("tJDBCColumnList_1_CURRENT_COLUMN_TYPE_NAME"));
	log.trace("struct_tIterateToFlow_1_ITFO - " + struct_tIterateToFlow_1_ITFO.toLogString());

    if(globalMap.get("tIterateToFlow_1") != null){
    	java.util.List<OnSubjobOkStructtIterateToFlow_1> list_tIterateToFlow_1_ITFO = (java.util.List<OnSubjobOkStructtIterateToFlow_1>)globalMap.get("tIterateToFlow_1"); 
    	list_tIterateToFlow_1_ITFO.add(struct_tIterateToFlow_1_ITFO);
    }else{
    	java.util.List<OnSubjobOkStructtIterateToFlow_1> list_tIterateToFlow_1_ITFO = new java.util.ArrayList<OnSubjobOkStructtIterateToFlow_1>();
    	list_tIterateToFlow_1_ITFO.add(struct_tIterateToFlow_1_ITFO);
    	globalMap.put("tIterateToFlow_1",list_tIterateToFlow_1_ITFO);
    }
 



/**
 * [tIterateToFlow_1_ITFO begin ] stop
 */
	
	/**
	 * [tIterateToFlow_1_ITFO main ] start
	 */

	

	
	
		currentVirtualComponent = "tIterateToFlow_1";
	
	currentComponent="tIterateToFlow_1_ITFO";

	

 


	tos_count_tIterateToFlow_1_ITFO++;

/**
 * [tIterateToFlow_1_ITFO main ] stop
 */
	
	/**
	 * [tIterateToFlow_1_ITFO end ] start
	 */

	

	
	
		currentVirtualComponent = "tIterateToFlow_1";
	
	currentComponent="tIterateToFlow_1_ITFO";

	

 
                if(log.isDebugEnabled())
            log.debug("tIterateToFlow_1_ITFO - "  + ("Done.") );

ok_Hash.put("tIterateToFlow_1_ITFO", true);
end_Hash.put("tIterateToFlow_1_ITFO", System.currentTimeMillis());




/**
 * [tIterateToFlow_1_ITFO end ] stop
 */
						if(execStat){
							runStat.updateStatOnConnection("iterate4", 2, "exec" + NB_ITERATE_tIterateToFlow_1_ITFO);
						}				
					




	
	/**
	 * [tJDBCColumnList_1 end ] start
	 */

	

	
	
	currentComponent="tJDBCColumnList_1";

	

}
}catch(Exception e_tJDBCColumnList_1){
        throw(e_tJDBCColumnList_1);
}finally{
    try{
        if(stmt2_tJDBCColumnList_1!=null){
            stmt2_tJDBCColumnList_1.close();
        }
    }catch(Exception e2_tJDBCColumnList_1){
            throw(e2_tJDBCColumnList_1);
    }
}
globalMap.put("tJDBCColumnList_1_NB_COLUMN", nb_column_tJDBCColumnList_1);
	    		log.info("tJDBCColumnList_1 - Retrieved columns count:"+nb_column_tJDBCColumnList_1 + " .");
			
 
                if(log.isDebugEnabled())
            log.debug("tJDBCColumnList_1 - "  + ("Done.") );

ok_Hash.put("tJDBCColumnList_1", true);
end_Hash.put("tJDBCColumnList_1", System.currentTimeMillis());




/**
 * [tJDBCColumnList_1 end ] stop
 */
				}//end the resume

				
				    			if(resumeEntryMethodName == null || globalResumeTicket){
				    				resumeUtil.addLog("CHECKPOINT", "CONNECTION:SUBJOB_OK:tJDBCColumnList_1:OnSubjobOk", "", Thread.currentThread().getId() + "", "", "", "", "", "");
								}	    				    			
					    	
								if(execStat){    	
									runStat.updateStatOnConnection("OnSubjobOk", 0, "ok");
								} 
							
							tIterateToFlow_1_AIProcess(globalMap); 
						



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage());
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
					te.setVirtualComponentName(currentVirtualComponent);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tJDBCColumnList_1 finally ] start
	 */

	

	
	
	currentComponent="tJDBCColumnList_1";

	

 



/**
 * [tJDBCColumnList_1 finally ] stop
 */

	
	/**
	 * [tIterateToFlow_1_ITFO finally ] start
	 */

	

	
	
		currentVirtualComponent = "tIterateToFlow_1";
	
	currentComponent="tIterateToFlow_1_ITFO";

	

 



/**
 * [tIterateToFlow_1_ITFO finally ] stop
 */



				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tJDBCColumnList_1_SUBPROCESS_STATE", 1);
	}
	

public void tGreenplumRow_5Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tGreenplumRow_5_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tGreenplumRow_5 begin ] start
	 */

	

	
		
		ok_Hash.put("tGreenplumRow_5", false);
		start_Hash.put("tGreenplumRow_5", System.currentTimeMillis());
		
	
	currentComponent="tGreenplumRow_5";

	
		int tos_count_tGreenplumRow_5 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tGreenplumRow_5 - "  + ("Start to work.") );
    	class BytesLimit65535_tGreenplumRow_5{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tGreenplumRow_5 = new StringBuilder();
            log4jParamters_tGreenplumRow_5.append("Parameters:");
                    log4jParamters_tGreenplumRow_5.append("USE_EXISTING_CONNECTION" + " = " + "true");
                log4jParamters_tGreenplumRow_5.append(" | ");
                    log4jParamters_tGreenplumRow_5.append("CONNECTION" + " = " + "tGreenplumConnection_2");
                log4jParamters_tGreenplumRow_5.append(" | ");
                    log4jParamters_tGreenplumRow_5.append("QUERYSTORE" + " = " + "\"\"");
                log4jParamters_tGreenplumRow_5.append(" | ");
                    log4jParamters_tGreenplumRow_5.append("QUERY" + " = " + "GEroutines.sqlDropTable((String)globalMap.get(\"row1.target_schema\"), \"\", (String)globalMap.get(\"row1.target_table_name\") )");
                log4jParamters_tGreenplumRow_5.append(" | ");
                    log4jParamters_tGreenplumRow_5.append("DIE_ON_ERROR" + " = " + "true");
                log4jParamters_tGreenplumRow_5.append(" | ");
                    log4jParamters_tGreenplumRow_5.append("PROPAGATE_RECORD_SET" + " = " + "false");
                log4jParamters_tGreenplumRow_5.append(" | ");
                    log4jParamters_tGreenplumRow_5.append("USE_PREPAREDSTATEMENT" + " = " + "false");
                log4jParamters_tGreenplumRow_5.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tGreenplumRow_5 - "  + (log4jParamters_tGreenplumRow_5) );
    		}
    	}
    	
        new BytesLimit65535_tGreenplumRow_5().limitLog4jByte();

	java.sql.Connection conn_tGreenplumRow_5 = null;
	String query_tGreenplumRow_5 = "";
	boolean whetherReject_tGreenplumRow_5 = false;
				conn_tGreenplumRow_5 = (java.sql.Connection)globalMap.get("conn_tGreenplumConnection_2");
			
				if(conn_tGreenplumRow_5 != null) {
					if(conn_tGreenplumRow_5.getMetaData() != null) {
						
						log.debug("tGreenplumRow_5 - Uses an existing connection with username '" + conn_tGreenplumRow_5.getMetaData().getUserName() + "'. Connection URL: " + conn_tGreenplumRow_5.getMetaData().getURL() + ".");
						
					}
				}
			
		java.sql.Statement stmt_tGreenplumRow_5 = conn_tGreenplumRow_5.createStatement();
	

 



/**
 * [tGreenplumRow_5 begin ] stop
 */
	
	/**
	 * [tGreenplumRow_5 main ] start
	 */

	

	
	
	currentComponent="tGreenplumRow_5";

	

	    		log.debug("tGreenplumRow_5 - Executing the query: '" + GEroutines.sqlDropTable((String)globalMap.get("row1.target_schema"), "", (String)globalMap.get("row1.target_table_name") ) + "'.");
			
query_tGreenplumRow_5 = GEroutines.sqlDropTable((String)globalMap.get("row1.target_schema"), "", (String)globalMap.get("row1.target_table_name") );
whetherReject_tGreenplumRow_5 = false;
globalMap.put("tGreenplumRow_5_QUERY",query_tGreenplumRow_5);
try {
		stmt_tGreenplumRow_5.execute(query_tGreenplumRow_5);
		
	    		log.info("tGreenplumRow_5 - Execute the query: '" + GEroutines.sqlDropTable((String)globalMap.get("row1.target_schema"), "", (String)globalMap.get("row1.target_table_name") ) + "' has finished.");
			
	} catch (java.lang.Exception e) {
		whetherReject_tGreenplumRow_5 = true;
		
			throw(e);
			
	}
	
	if(!whetherReject_tGreenplumRow_5) {
		
	}
	

 


	tos_count_tGreenplumRow_5++;

/**
 * [tGreenplumRow_5 main ] stop
 */
	
	/**
	 * [tGreenplumRow_5 end ] start
	 */

	

	
	
	currentComponent="tGreenplumRow_5";

	

	
	stmt_tGreenplumRow_5.close();	

 
                if(log.isDebugEnabled())
            log.debug("tGreenplumRow_5 - "  + ("Done.") );

ok_Hash.put("tGreenplumRow_5", true);
end_Hash.put("tGreenplumRow_5", System.currentTimeMillis());




/**
 * [tGreenplumRow_5 end ] stop
 */
				}//end the resume

				
				    			if(resumeEntryMethodName == null || globalResumeTicket){
				    				resumeUtil.addLog("CHECKPOINT", "CONNECTION:SUBJOB_OK:tGreenplumRow_5:OnSubjobOk", "", Thread.currentThread().getId() + "", "", "", "", "", "");
								}	    				    			
					    	
								if(execStat){    	
									runStat.updateStatOnConnection("OnSubjobOk4", 0, "ok");
								} 
							
							tGreenplumRow_6Process(globalMap); 
						



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage());
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tGreenplumRow_5 finally ] start
	 */

	

	
	
	currentComponent="tGreenplumRow_5";

	

 



/**
 * [tGreenplumRow_5 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tGreenplumRow_5_SUBPROCESS_STATE", 1);
	}
	

public void tGreenplumRow_6Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tGreenplumRow_6_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tGreenplumRow_6 begin ] start
	 */

	

	
		
		ok_Hash.put("tGreenplumRow_6", false);
		start_Hash.put("tGreenplumRow_6", System.currentTimeMillis());
		
	
	currentComponent="tGreenplumRow_6";

	
		int tos_count_tGreenplumRow_6 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tGreenplumRow_6 - "  + ("Start to work.") );
    	class BytesLimit65535_tGreenplumRow_6{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tGreenplumRow_6 = new StringBuilder();
            log4jParamters_tGreenplumRow_6.append("Parameters:");
                    log4jParamters_tGreenplumRow_6.append("USE_EXISTING_CONNECTION" + " = " + "true");
                log4jParamters_tGreenplumRow_6.append(" | ");
                    log4jParamters_tGreenplumRow_6.append("CONNECTION" + " = " + "tGreenplumConnection_2");
                log4jParamters_tGreenplumRow_6.append(" | ");
                    log4jParamters_tGreenplumRow_6.append("QUERYSTORE" + " = " + "\"\"");
                log4jParamters_tGreenplumRow_6.append(" | ");
                    log4jParamters_tGreenplumRow_6.append("QUERY" + " = " + "\"CREATE TABLE \" + (String)globalMap.get(\"row1.target_schema\") + \".\" +   (String)globalMap.get(\"row1.target_table_name\") +\" ( \" +   (String)globalMap.get(\"columnlist\") + \" )\"+  globalMap.get(\"distributed\")");
                log4jParamters_tGreenplumRow_6.append(" | ");
                    log4jParamters_tGreenplumRow_6.append("DIE_ON_ERROR" + " = " + "true");
                log4jParamters_tGreenplumRow_6.append(" | ");
                    log4jParamters_tGreenplumRow_6.append("PROPAGATE_RECORD_SET" + " = " + "false");
                log4jParamters_tGreenplumRow_6.append(" | ");
                    log4jParamters_tGreenplumRow_6.append("USE_PREPAREDSTATEMENT" + " = " + "false");
                log4jParamters_tGreenplumRow_6.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tGreenplumRow_6 - "  + (log4jParamters_tGreenplumRow_6) );
    		}
    	}
    	
        new BytesLimit65535_tGreenplumRow_6().limitLog4jByte();

	java.sql.Connection conn_tGreenplumRow_6 = null;
	String query_tGreenplumRow_6 = "";
	boolean whetherReject_tGreenplumRow_6 = false;
				conn_tGreenplumRow_6 = (java.sql.Connection)globalMap.get("conn_tGreenplumConnection_2");
			
				if(conn_tGreenplumRow_6 != null) {
					if(conn_tGreenplumRow_6.getMetaData() != null) {
						
						log.debug("tGreenplumRow_6 - Uses an existing connection with username '" + conn_tGreenplumRow_6.getMetaData().getUserName() + "'. Connection URL: " + conn_tGreenplumRow_6.getMetaData().getURL() + ".");
						
					}
				}
			
		java.sql.Statement stmt_tGreenplumRow_6 = conn_tGreenplumRow_6.createStatement();
	

 



/**
 * [tGreenplumRow_6 begin ] stop
 */
	
	/**
	 * [tGreenplumRow_6 main ] start
	 */

	

	
	
	currentComponent="tGreenplumRow_6";

	

	    		log.debug("tGreenplumRow_6 - Executing the query: '" + "CREATE TABLE " + (String)globalMap.get("row1.target_schema") + "." +   (String)globalMap.get("row1.target_table_name") +" ( " +   (String)globalMap.get("columnlist") + " )"+  globalMap.get("distributed") + "'.");
			
query_tGreenplumRow_6 = "CREATE TABLE " + (String)globalMap.get("row1.target_schema") + "." + 
(String)globalMap.get("row1.target_table_name") +" ( " + 
(String)globalMap.get("columnlist") + " )"+
globalMap.get("distributed");
whetherReject_tGreenplumRow_6 = false;
globalMap.put("tGreenplumRow_6_QUERY",query_tGreenplumRow_6);
try {
		stmt_tGreenplumRow_6.execute(query_tGreenplumRow_6);
		
	    		log.info("tGreenplumRow_6 - Execute the query: '" + "CREATE TABLE " + (String)globalMap.get("row1.target_schema") + "." + 
(String)globalMap.get("row1.target_table_name") +" ( " + 
(String)globalMap.get("columnlist") + " )"+
globalMap.get("distributed") + "' has finished.");
			
	} catch (java.lang.Exception e) {
		whetherReject_tGreenplumRow_6 = true;
		
			throw(e);
			
	}
	
	if(!whetherReject_tGreenplumRow_6) {
		
	}
	

 


	tos_count_tGreenplumRow_6++;

/**
 * [tGreenplumRow_6 main ] stop
 */
	
	/**
	 * [tGreenplumRow_6 end ] start
	 */

	

	
	
	currentComponent="tGreenplumRow_6";

	

	
	stmt_tGreenplumRow_6.close();	

 
                if(log.isDebugEnabled())
            log.debug("tGreenplumRow_6 - "  + ("Done.") );

ok_Hash.put("tGreenplumRow_6", true);
end_Hash.put("tGreenplumRow_6", System.currentTimeMillis());

				if(execStat){   
   	 				runStat.updateStatOnConnection("OnComponentOk7", 0, "ok");
				}
				tAS400Input_2Process(globalMap);



/**
 * [tGreenplumRow_6 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage());
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tGreenplumRow_6 finally ] start
	 */

	

	
	
	currentComponent="tGreenplumRow_6";

	

 



/**
 * [tGreenplumRow_6 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tGreenplumRow_6_SUBPROCESS_STATE", 1);
	}
	


public static class FinalDataStruct implements routines.system.IPersistableRow<FinalDataStruct> {
    final static byte[] commonByteArrayLock_AWS_DEV_TALEND_INGESTION_FRAMEWORK_AS400_to_greenplum_with_GPLoad = new byte[0];
    static byte[] commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_AS400_to_greenplum_with_GPLoad = new byte[0];

	
			    public String FinalData;

				public String getFinalData () {
					return this.FinalData;
				}
				



	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_AS400_to_greenplum_with_GPLoad.length) {
				if(length < 1024 && commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_AS400_to_greenplum_with_GPLoad.length == 0) {
   					commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_AS400_to_greenplum_with_GPLoad = new byte[1024];
				} else {
   					commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_AS400_to_greenplum_with_GPLoad = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_AS400_to_greenplum_with_GPLoad, 0, length);
			strReturn = new String(commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_AS400_to_greenplum_with_GPLoad, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_AWS_DEV_TALEND_INGESTION_FRAMEWORK_AS400_to_greenplum_with_GPLoad) {

        	try {

        		int length = 0;
		
					this.FinalData = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// String
				
						writeString(this.FinalData,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("FinalData="+FinalData);
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				if(FinalData == null){
        					sb.append("<null>");
        				}else{
            				sb.append(FinalData);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(FinalDataStruct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public static class row2Struct implements routines.system.IPersistableRow<row2Struct> {
    final static byte[] commonByteArrayLock_AWS_DEV_TALEND_INGESTION_FRAMEWORK_AS400_to_greenplum_with_GPLoad = new byte[0];
    static byte[] commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_AS400_to_greenplum_with_GPLoad = new byte[0];

	
			    public routines.system.Dynamic Data;

				public routines.system.Dynamic getData () {
					return this.Data;
				}
				



    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_AWS_DEV_TALEND_INGESTION_FRAMEWORK_AS400_to_greenplum_with_GPLoad) {

        	try {

        		int length = 0;
		
						this.Data = (routines.system.Dynamic) dis.readObject();
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		
			} catch(ClassNotFoundException eCNFE) {
				 throw new RuntimeException(eCNFE);
		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// Dynamic
				
       			    	dos.writeObject(this.Data);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("Data="+String.valueOf(Data));
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				if(Data == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Data);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(row2Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}
public void tAS400Input_2Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tAS400Input_2_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;



		row2Struct row2 = new row2Struct();
FinalDataStruct FinalData = new FinalDataStruct();






	
	/**
	 * [tFileOutputDelimitedGE_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tFileOutputDelimitedGE_1", false);
		start_Hash.put("tFileOutputDelimitedGE_1", System.currentTimeMillis());
		
	
	currentComponent="tFileOutputDelimitedGE_1";

	
			if (execStat) {
				if(resourceMap.get("inIterateVComp") == null){
					
						runStat.updateStatOnConnection("FinalData" + iterateId, 0, 0);
					
				}
			} 

		
		int tos_count_tFileOutputDelimitedGE_1 = 0;
		
    	class BytesLimit65535_tFileOutputDelimitedGE_1{
    		public void limitLog4jByte() throws Exception{
    			
    		}
    	}
    	
        new BytesLimit65535_tFileOutputDelimitedGE_1().limitLog4jByte();

    String log4jFileOutputDelimitedParamters_tFileOutputDelimitedGE_1 = "";
    log4jFileOutputDelimitedParamters_tFileOutputDelimitedGE_1 = log4jFileOutputDelimitedParamters_tFileOutputDelimitedGE_1 + "FILENAME = " + (String)globalMap.get("filetocheck") + " | ";
    log4jFileOutputDelimitedParamters_tFileOutputDelimitedGE_1 = log4jFileOutputDelimitedParamters_tFileOutputDelimitedGE_1 + "CSV_OPTION = " + false + " | ";
    log4jFileOutputDelimitedParamters_tFileOutputDelimitedGE_1 = log4jFileOutputDelimitedParamters_tFileOutputDelimitedGE_1 + "FIELDSEPARATOR = " + new String("\013") + " | ";
    log4jFileOutputDelimitedParamters_tFileOutputDelimitedGE_1 = log4jFileOutputDelimitedParamters_tFileOutputDelimitedGE_1 + "INCLUDE_HEADER = " + false + " | ";
        log4jFileOutputDelimitedParamters_tFileOutputDelimitedGE_1 = log4jFileOutputDelimitedParamters_tFileOutputDelimitedGE_1 + "COMPRESS = " + true + " | ";
    log4jFileOutputDelimitedParamters_tFileOutputDelimitedGE_1 = log4jFileOutputDelimitedParamters_tFileOutputDelimitedGE_1 + "APPEND = " + false + " | ";
    log4jFileOutputDelimitedParamters_tFileOutputDelimitedGE_1 = log4jFileOutputDelimitedParamters_tFileOutputDelimitedGE_1 + "CREATE_DIRECTORY_IF_NOT_EXISTS = " + true + " | ";
    log4jFileOutputDelimitedParamters_tFileOutputDelimitedGE_1 = log4jFileOutputDelimitedParamters_tFileOutputDelimitedGE_1 + "SPLIT_INTO_SEVERAL_FILES = " + false + " | ";
    log4jFileOutputDelimitedParamters_tFileOutputDelimitedGE_1 = log4jFileOutputDelimitedParamters_tFileOutputDelimitedGE_1 + "OUTPUT_IN_ROW_MODE = " + false + " | ";

    log4jFileOutputDelimitedParamters_tFileOutputDelimitedGE_1 = "tFileOutputDelimitedGE_1 - Parameters:" + log4jFileOutputDelimitedParamters_tFileOutputDelimitedGE_1;
    log.debug(log4jFileOutputDelimitedParamters_tFileOutputDelimitedGE_1);
    StringBuffer log4jSb_tFileOutputDelimitedGE_1 = new StringBuffer();
    log.info("tFileOutputDelimitedGE_1 - Start to work.");
String fileName_tFileOutputDelimitedGE_1 = "";
    fileName_tFileOutputDelimitedGE_1 = (new java.io.File((String)globalMap.get("filetocheck"))).getAbsolutePath().replace("\\","/");
    String fullName_tFileOutputDelimitedGE_1 = null;
    String extension_tFileOutputDelimitedGE_1 = null;
    String directory_tFileOutputDelimitedGE_1 = null;
    if((fileName_tFileOutputDelimitedGE_1.indexOf("/") != -1)) {
        if(fileName_tFileOutputDelimitedGE_1.lastIndexOf(".") < fileName_tFileOutputDelimitedGE_1.lastIndexOf("/")) {
            fullName_tFileOutputDelimitedGE_1 = fileName_tFileOutputDelimitedGE_1;
            extension_tFileOutputDelimitedGE_1 = "";
        } else {
            fullName_tFileOutputDelimitedGE_1 = fileName_tFileOutputDelimitedGE_1.substring(0, fileName_tFileOutputDelimitedGE_1.lastIndexOf("."));
            extension_tFileOutputDelimitedGE_1 = fileName_tFileOutputDelimitedGE_1.substring(fileName_tFileOutputDelimitedGE_1.lastIndexOf("."));
        }
        directory_tFileOutputDelimitedGE_1 = fileName_tFileOutputDelimitedGE_1.substring(0, fileName_tFileOutputDelimitedGE_1.lastIndexOf("/"));
    } else {
        if(fileName_tFileOutputDelimitedGE_1.lastIndexOf(".") != -1) {
            fullName_tFileOutputDelimitedGE_1 = fileName_tFileOutputDelimitedGE_1.substring(0, fileName_tFileOutputDelimitedGE_1.lastIndexOf("."));
            extension_tFileOutputDelimitedGE_1 = fileName_tFileOutputDelimitedGE_1.substring(fileName_tFileOutputDelimitedGE_1.lastIndexOf("."));
        } else {
            fullName_tFileOutputDelimitedGE_1 = fileName_tFileOutputDelimitedGE_1;
            extension_tFileOutputDelimitedGE_1 = "";
        }
        directory_tFileOutputDelimitedGE_1 = "";
    }
    boolean isFileGenerated_tFileOutputDelimitedGE_1 = true;
    java.io.File filetFileOutputDelimitedGE_1 = new java.io.File(fileName_tFileOutputDelimitedGE_1);
    globalMap.put("tFileOutputDelimitedGE_1_FILE_NAME",fileName_tFileOutputDelimitedGE_1);
            int nb_line_tFileOutputDelimitedGE_1 = 0;
            int splitEvery_tFileOutputDelimitedGE_1 = 1000;
            int splitedFileNo_tFileOutputDelimitedGE_1 = 0;
            int currentRow_tFileOutputDelimitedGE_1 = 0;

            final String OUT_DELIM_tFileOutputDelimitedGE_1 = /** Start field tFileOutputDelimitedGE_1:FIELDSEPARATOR */new String("\013")/** End field tFileOutputDelimitedGE_1:FIELDSEPARATOR */;

            final String OUT_DELIM_ROWSEP_tFileOutputDelimitedGE_1 = /** Start field tFileOutputDelimitedGE_1:ROWSEPARATOR */"\n"/** End field tFileOutputDelimitedGE_1:ROWSEPARATOR */;

                    //create directory only if not exists
                    if(directory_tFileOutputDelimitedGE_1 != null && directory_tFileOutputDelimitedGE_1.trim().length() != 0) {
                        java.io.File dir_tFileOutputDelimitedGE_1 = new java.io.File(directory_tFileOutputDelimitedGE_1);
                        if(!dir_tFileOutputDelimitedGE_1.exists()) {
                                log.info("tFileOutputDelimitedGE_1 - Creating directory '" + dir_tFileOutputDelimitedGE_1.getCanonicalPath() +"'.");
                            dir_tFileOutputDelimitedGE_1.mkdirs();
                                log.info("tFileOutputDelimitedGE_1 - The directoy '"+ dir_tFileOutputDelimitedGE_1.getCanonicalPath() + "' has been created successfully.");
                        }
                    }

                            filetFileOutputDelimitedGE_1 = new java.io.File(fileName_tFileOutputDelimitedGE_1);
                            String zipName_tFileOutputDelimitedGE_1 = fullName_tFileOutputDelimitedGE_1 + ".gz";
                            java.io.File file_tFileOutputDelimitedGE_1 = new java.io.File(zipName_tFileOutputDelimitedGE_1);
                            //routines.system.Row
                            java.util.zip.GZIPOutputStream zipOut_tFileOutputDelimitedGE_1= null;
                            java.io.Writer outtFileOutputDelimitedGE_1 = null;
                            zipOut_tFileOutputDelimitedGE_1= new java.util.zip.GZIPOutputStream(
                                    new java.io.BufferedOutputStream(new java.io.FileOutputStream(zipName_tFileOutputDelimitedGE_1)));
                            //zipOut_tFileOutputDelimitedGE_1.putNextEntry(new java.util.zip.ZipEntry(filetFileOutputDelimitedGE_1.getName()));
                            outtFileOutputDelimitedGE_1 = new java.io.BufferedWriter(new java.io.OutputStreamWriter(zipOut_tFileOutputDelimitedGE_1,"UTF-8"));


        resourceMap.put("out_tFileOutputDelimitedGE_1", outtFileOutputDelimitedGE_1);
resourceMap.put("nb_line_tFileOutputDelimitedGE_1", nb_line_tFileOutputDelimitedGE_1);
 



/**
 * [tFileOutputDelimitedGE_1 begin ] stop
 */



	
	/**
	 * [tMap_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tMap_1", false);
		start_Hash.put("tMap_1", System.currentTimeMillis());
		
	
	currentComponent="tMap_1";

	
			if (execStat) {
				if(resourceMap.get("inIterateVComp") == null){
					
						runStat.updateStatOnConnection("meterRowrow2" + iterateId, 0, 0);
					
				}
			} 

		
		int tos_count_tMap_1 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tMap_1 - "  + ("Start to work.") );
    	class BytesLimit65535_tMap_1{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tMap_1 = new StringBuilder();
            log4jParamters_tMap_1.append("Parameters:");
                    log4jParamters_tMap_1.append("LINK_STYLE" + " = " + "AUTO");
                log4jParamters_tMap_1.append(" | ");
                    log4jParamters_tMap_1.append("TEMPORARY_DATA_DIRECTORY" + " = " + "");
                log4jParamters_tMap_1.append(" | ");
                    log4jParamters_tMap_1.append("ROWS_BUFFER_SIZE" + " = " + "2000000");
                log4jParamters_tMap_1.append(" | ");
                    log4jParamters_tMap_1.append("CHANGE_HASH_AND_EQUALS_FOR_BIGDECIMAL" + " = " + "false");
                log4jParamters_tMap_1.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tMap_1 - "  + (log4jParamters_tMap_1) );
    		}
    	}
    	
        new BytesLimit65535_tMap_1().limitLog4jByte();




// ###############################
// # Lookup's keys initialization
		int count_row2_tMap_1 = 0;
		
// ###############################        

// ###############################
// # Vars initialization
class  Var__tMap_1__Struct  {
}
Var__tMap_1__Struct Var__tMap_1 = new Var__tMap_1__Struct();
// ###############################

// ###############################
// # Outputs initialization
				int count_FinalData_tMap_1 = 0;
				
FinalDataStruct FinalData_tmp = new FinalDataStruct();
// ###############################

        
        



        









 



/**
 * [tMap_1 begin ] stop
 */



	
	/**
	 * [vFlowMeter_row2 begin ] start
	 */

	

	
		
		ok_Hash.put("vFlowMeter_row2", false);
		start_Hash.put("vFlowMeter_row2", System.currentTimeMillis());
		
	
	currentComponent="vFlowMeter_row2";

	
			if (execStat) {
				if(resourceMap.get("inIterateVComp") == null){
					
						runStat.updateStatOnConnection("row2" + iterateId, 0, 0);
					
				}
			} 

		
		int tos_count_vFlowMeter_row2 = 0;
		
                if(log.isDebugEnabled())
            log.debug("vFlowMeter_row2 - "  + ("Start to work.") );
    	class BytesLimit65535_vFlowMeter_row2{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_vFlowMeter_row2 = new StringBuilder();
            log4jParamters_vFlowMeter_row2.append("Parameters:");
                    log4jParamters_vFlowMeter_row2.append("USEROWLABEL" + " = " + "true");
                log4jParamters_vFlowMeter_row2.append(" | ");
                    log4jParamters_vFlowMeter_row2.append("ABSOLUTE" + " = " + "Absolute");
                log4jParamters_vFlowMeter_row2.append(" | ");
                    log4jParamters_vFlowMeter_row2.append("THRESHLODS" + " = " + "[]");
                log4jParamters_vFlowMeter_row2.append(" | ");
                if(log.isDebugEnabled())
            log.debug("vFlowMeter_row2 - "  + (log4jParamters_vFlowMeter_row2) );
    		}
    	}
    	
        new BytesLimit65535_vFlowMeter_row2().limitLog4jByte();

    int count_vFlowMeter_row2 = 0; 
 



/**
 * [vFlowMeter_row2 begin ] stop
 */



	
	/**
	 * [tAS400Input_2 begin ] start
	 */

	

	
		
		ok_Hash.put("tAS400Input_2", false);
		start_Hash.put("tAS400Input_2", System.currentTimeMillis());
		
	
	currentComponent="tAS400Input_2";

	
		int tos_count_tAS400Input_2 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tAS400Input_2 - "  + ("Start to work.") );
    	class BytesLimit65535_tAS400Input_2{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tAS400Input_2 = new StringBuilder();
            log4jParamters_tAS400Input_2.append("Parameters:");
                    log4jParamters_tAS400Input_2.append("USE_EXISTING_CONNECTION" + " = " + "true");
                log4jParamters_tAS400Input_2.append(" | ");
                    log4jParamters_tAS400Input_2.append("CONNECTION" + " = " + "tAS400Connection_1");
                log4jParamters_tAS400Input_2.append(" | ");
                    log4jParamters_tAS400Input_2.append("TABLE" + " = " + "\"\"");
                log4jParamters_tAS400Input_2.append(" | ");
                    log4jParamters_tAS400Input_2.append("QUERYSTORE" + " = " + "\"\"");
                log4jParamters_tAS400Input_2.append(" | ");
                    log4jParamters_tAS400Input_2.append("QUERY" + " = " + "\"select * \" +   \" from \" +   ((String)globalMap.get(\"row1.source_schema\")) + \".\" + ((String)globalMap.get(\"row1.source_table_name\"))  +   \" where \" +   globalMap.get(\"where_cond\")");
                log4jParamters_tAS400Input_2.append(" | ");
                    log4jParamters_tAS400Input_2.append("TRIM_ALL_COLUMN" + " = " + "false");
                log4jParamters_tAS400Input_2.append(" | ");
                    log4jParamters_tAS400Input_2.append("TRIM_COLUMN" + " = " + "[{TRIM="+("false")+", SCHEMA_COLUMN="+("Data")+"}]");
                log4jParamters_tAS400Input_2.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tAS400Input_2 - "  + (log4jParamters_tAS400Input_2) );
    		}
    	}
    	
        new BytesLimit65535_tAS400Input_2().limitLog4jByte();
	
    
	
		    int nb_line_tAS400Input_2 = 0;
		    java.sql.Connection conn_tAS400Input_2 = null;
		        conn_tAS400Input_2 = (java.sql.Connection)globalMap.get("conn_tAS400Connection_1");
				
				if(conn_tAS400Input_2 != null) {
					if(conn_tAS400Input_2.getMetaData() != null) {
						
						log.debug("tAS400Input_2 - Uses an existing connection with username '" + conn_tAS400Input_2.getMetaData().getUserName() + "'. Connection URL: " + conn_tAS400Input_2.getMetaData().getURL() + ".");
						
					}
				}
			
		    
			java.sql.Statement stmt_tAS400Input_2 = conn_tAS400Input_2.createStatement();

		    String dbquery_tAS400Input_2 = "select * " + 
" from " + 
((String)globalMap.get("row1.source_schema")) + "." + ((String)globalMap.get("row1.source_table_name"))  + 
" where " + 
globalMap.get("where_cond");
			
                log.debug("tAS400Input_2 - Executing the query: '"+dbquery_tAS400Input_2+"'.");
			

                       globalMap.put("tAS400Input_2_QUERY",dbquery_tAS400Input_2);

		    java.sql.ResultSet rs_tAS400Input_2 = null;
		try{
		    rs_tAS400Input_2 = stmt_tAS400Input_2.executeQuery(dbquery_tAS400Input_2);
		    java.sql.ResultSetMetaData rsmd_tAS400Input_2 = rs_tAS400Input_2.getMetaData();
		    int colQtyInRs_tAS400Input_2 = rsmd_tAS400Input_2.getColumnCount();

		    routines.system.Dynamic dcg_tAS400Input_2 =  new routines.system.Dynamic();
		    dcg_tAS400Input_2.setDbmsId("as400_id");
		    List<String> listSchema_tAS400Input_2=new java.util.ArrayList<String>();
		    

			int fixedColumnCount_tAS400Input_2 = 0;

            for (int i = 1; i <= rsmd_tAS400Input_2.getColumnCount()-0; i++) {
                if (!(listSchema_tAS400Input_2.contains(rsmd_tAS400Input_2.getColumnLabel(i).toUpperCase()) )) {
                	routines.system.DynamicMetadata dcm_tAS400Input_2=new routines.system.DynamicMetadata();
                	dcm_tAS400Input_2.setName(rsmd_tAS400Input_2.getColumnLabel(i));
                	dcm_tAS400Input_2.setDbName(rsmd_tAS400Input_2.getColumnName(i));
                	dcm_tAS400Input_2.setType(routines.system.Dynamic.getTalendTypeFromDBType("as400_id", rsmd_tAS400Input_2.getColumnTypeName(i).toUpperCase(), rsmd_tAS400Input_2.getPrecision(i), rsmd_tAS400Input_2.getScale(i)));
                	dcm_tAS400Input_2.setDbType(rsmd_tAS400Input_2.getColumnTypeName(i));
                	dcm_tAS400Input_2.setDbTypeId(rsmd_tAS400Input_2.getColumnType(i));
                	dcm_tAS400Input_2.setFormat("yyyy-MM-dd'T'HH:mm:ss");
			dcm_tAS400Input_2.setLength(rsmd_tAS400Input_2.getPrecision(i));
                	dcm_tAS400Input_2.setPrecision(rsmd_tAS400Input_2.getScale(i));
                	dcm_tAS400Input_2.setNullable(rsmd_tAS400Input_2.isNullable(i) == 0 ? false : true);
                	dcm_tAS400Input_2.setKey(false);
                	dcm_tAS400Input_2.setSourceType(DynamicMetadata.sourceTypes.database);
                	dcm_tAS400Input_2.setColumnPosition(i);
                	dcg_tAS400Input_2.metadatas.add(dcm_tAS400Input_2);
                }
            }
		    String tmpContent_tAS400Input_2 = null;
		    
		    	int column_index_tAS400Input_2 =1;
		    
		    
		    	log.debug("tAS400Input_2 - Retrieving records from the database.");
		    
		    while (rs_tAS400Input_2.next()) {
		        nb_line_tAS400Input_2++;
		        
									column_index_tAS400Input_2 = 1;
								
							
							if(colQtyInRs_tAS400Input_2 < column_index_tAS400Input_2) {
								row2.Data = null;
							} else {
                                  row2.Data=dcg_tAS400Input_2;
                                		 routines.system.DynamicUtils.readColumnsFromDatabase(row2.Data, rs_tAS400Input_2, fixedColumnCount_tAS400Input_2,false);
		                    }
					
						log.debug("tAS400Input_2 - Retrieving the record " + nb_line_tAS400Input_2 + ".");
					



 



/**
 * [tAS400Input_2 begin ] stop
 */
	
	/**
	 * [tAS400Input_2 main ] start
	 */

	

	
	
	currentComponent="tAS400Input_2";

	

 


	tos_count_tAS400Input_2++;

/**
 * [tAS400Input_2 main ] stop
 */

	
	/**
	 * [vFlowMeter_row2 main ] start
	 */

	

	
	
	currentComponent="vFlowMeter_row2";

	

			//row2
			//row2


			
				if(execStat){
					runStat.updateStatOnConnection("row2"+iterateId,1, 1);
				} 
			

		
    			if(log.isTraceEnabled()){
    				log.trace("row2 - " + (row2==null? "": row2.toLogString()));
    			}
    		

    count_vFlowMeter_row2++; 
 


	tos_count_vFlowMeter_row2++;

/**
 * [vFlowMeter_row2 main ] stop
 */

	
	/**
	 * [tMap_1 main ] start
	 */

	

	
	
	currentComponent="tMap_1";

	

			//meterRowrow2
			//row2


			
				if(execStat){
					runStat.updateStatOnConnection("meterRowrow2"+iterateId,1, 1);
				} 
			

		
    			if(log.isTraceEnabled()){
    				log.trace("meterRowrow2 - " + (row2==null? "": row2.toLogString()));
    			}
    		

		
		
		boolean hasCasePrimitiveKeyWithNull_tMap_1 = false;
		
        // ###############################
        // # Input tables (lookups)
		  boolean rejectedInnerJoin_tMap_1 = false;
		  boolean mainRowRejected_tMap_1 = false;
            				    								  
		// ###############################
        { // start of Var scope
        
	        // ###############################
        	// # Vars tables
        
Var__tMap_1__Struct Var = Var__tMap_1;// ###############################
        // ###############################
        // # Output tables

FinalData = null;


// # Output table : 'FinalData'
count_FinalData_tMap_1++;

FinalData_tmp.FinalData = GEDynamicRoutine.returnDataAsString(row2.Data,new String("\013"));
FinalData = FinalData_tmp;
log.debug("tMap_1 - Outputting the record " + count_FinalData_tMap_1 + " of the output table 'FinalData'.");

// ###############################

} // end of Var scope

rejectedInnerJoin_tMap_1 = false;










 


	tos_count_tMap_1++;

/**
 * [tMap_1 main ] stop
 */
// Start of branch "FinalData"
if(FinalData != null) { 



	
	/**
	 * [tFileOutputDelimitedGE_1 main ] start
	 */

	

	
	
	currentComponent="tFileOutputDelimitedGE_1";

	

			//FinalData
			//FinalData


			
				if(execStat){
					runStat.updateStatOnConnection("FinalData"+iterateId,1, 1);
				} 
			

		
    			if(log.isTraceEnabled()){
    				log.trace("FinalData - " + (FinalData==null? "": FinalData.toLogString()));
    			}
    		


                    StringBuilder sb_tFileOutputDelimitedGE_1 = new StringBuilder();
                            if(FinalData.FinalData != null) {
                        sb_tFileOutputDelimitedGE_1.append(
                            FinalData.FinalData
                        );
                            }
                    sb_tFileOutputDelimitedGE_1.append(OUT_DELIM_ROWSEP_tFileOutputDelimitedGE_1);


                    nb_line_tFileOutputDelimitedGE_1++;
                    resourceMap.put("nb_line_tFileOutputDelimitedGE_1", nb_line_tFileOutputDelimitedGE_1);

                        outtFileOutputDelimitedGE_1.write(sb_tFileOutputDelimitedGE_1.toString());
                        log.debug("tFileOutputDelimitedGE_1 - Writing the record " + nb_line_tFileOutputDelimitedGE_1 + ".");
                        log.trace("tFileOutputDelimitedGE_1 - Content of the record " + nb_line_tFileOutputDelimitedGE_1 + ": " + sb_tFileOutputDelimitedGE_1);




 


	tos_count_tFileOutputDelimitedGE_1++;

/**
 * [tFileOutputDelimitedGE_1 main ] stop
 */

} // End of branch "FinalData"










	
	/**
	 * [tAS400Input_2 end ] start
	 */

	

	
	
	currentComponent="tAS400Input_2";

	

	}
}finally{
	stmt_tAS400Input_2.close();

}
globalMap.put("tAS400Input_2_NB_LINE",nb_line_tAS400Input_2);
	    		log.debug("tAS400Input_2 - Retrieved records count: "+nb_line_tAS400Input_2 + " .");
			

 
                if(log.isDebugEnabled())
            log.debug("tAS400Input_2 - "  + ("Done.") );

ok_Hash.put("tAS400Input_2", true);
end_Hash.put("tAS400Input_2", System.currentTimeMillis());




/**
 * [tAS400Input_2 end ] stop
 */

	
	/**
	 * [vFlowMeter_row2 end ] start
	 */

	

	
	
	currentComponent="vFlowMeter_row2";

	

                if(log.isDebugEnabled())
            log.debug("vFlowMeter_row2 - "  + ("Sending message to talendMeter_METTER.") );
	talendMeter_METTER.addMessage("row2", new Integer(count_vFlowMeter_row2), "null", "", "vFlowMeter_row2");

			if(execStat){
				if(resourceMap.get("inIterateVComp") == null || !((Boolean)resourceMap.get("inIterateVComp"))){
			 		runStat.updateStatOnConnection("row2"+iterateId,2, 0); 
			 	}
			}
		
 
                if(log.isDebugEnabled())
            log.debug("vFlowMeter_row2 - "  + ("Done.") );

ok_Hash.put("vFlowMeter_row2", true);
end_Hash.put("vFlowMeter_row2", System.currentTimeMillis());




/**
 * [vFlowMeter_row2 end ] stop
 */

	
	/**
	 * [tMap_1 end ] start
	 */

	

	
	
	currentComponent="tMap_1";

	


// ###############################
// # Lookup hashes releasing
// ###############################      
				log.debug("tMap_1 - Written records count in the table 'FinalData': " + count_FinalData_tMap_1 + ".");





			if(execStat){
				if(resourceMap.get("inIterateVComp") == null || !((Boolean)resourceMap.get("inIterateVComp"))){
			 		runStat.updateStatOnConnection("meterRowrow2"+iterateId,2, 0); 
			 	}
			}
		
 
                if(log.isDebugEnabled())
            log.debug("tMap_1 - "  + ("Done.") );

ok_Hash.put("tMap_1", true);
end_Hash.put("tMap_1", System.currentTimeMillis());




/**
 * [tMap_1 end ] stop
 */

	
	/**
	 * [tFileOutputDelimitedGE_1 end ] start
	 */

	

	
	
	currentComponent="tFileOutputDelimitedGE_1";

	



		
			
					if(outtFileOutputDelimitedGE_1!=null) {
						outtFileOutputDelimitedGE_1.flush();
						outtFileOutputDelimitedGE_1.close();
					}
				
				globalMap.put("tFileOutputDelimitedGE_1_NB_LINE",nb_line_tFileOutputDelimitedGE_1);
				globalMap.put("tFileOutputDelimitedGE_1_FILE_NAME",fileName_tFileOutputDelimitedGE_1);
			
		
		
		resourceMap.put("finish_tFileOutputDelimitedGE_1", true);
	
				log.info("tFileOutputDelimitedGE_1 - Written records count: " + nb_line_tFileOutputDelimitedGE_1 + " .");
				log.info("tFileOutputDelimitedGE_1 - Done.");

			if(execStat){
				if(resourceMap.get("inIterateVComp") == null || !((Boolean)resourceMap.get("inIterateVComp"))){
			 		runStat.updateStatOnConnection("FinalData"+iterateId,2, 0); 
			 	}
			}
		
 

ok_Hash.put("tFileOutputDelimitedGE_1", true);
end_Hash.put("tFileOutputDelimitedGE_1", System.currentTimeMillis());




/**
 * [tFileOutputDelimitedGE_1 end ] stop
 */









				}//end the resume

				
							talendMeter_METTERProcess(globalMap);
						
				    			if(resumeEntryMethodName == null || globalResumeTicket){
				    				resumeUtil.addLog("CHECKPOINT", "CONNECTION:SUBJOB_OK:tAS400Input_2:OnSubjobOk", "", Thread.currentThread().getId() + "", "", "", "", "", "");
								}	    				    			
					    	
								if(execStat){    	
									runStat.updateStatOnConnection("OnSubjobOk17", 0, "ok");
								} 
							
							tFileExist_1Process(globalMap); 
						



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage());
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tAS400Input_2 finally ] start
	 */

	

	
	
	currentComponent="tAS400Input_2";

	

 



/**
 * [tAS400Input_2 finally ] stop
 */

	
	/**
	 * [vFlowMeter_row2 finally ] start
	 */

	

	
	
	currentComponent="vFlowMeter_row2";

	

 



/**
 * [vFlowMeter_row2 finally ] stop
 */

	
	/**
	 * [tMap_1 finally ] start
	 */

	

	
	
	currentComponent="tMap_1";

	

 



/**
 * [tMap_1 finally ] stop
 */

	
	/**
	 * [tFileOutputDelimitedGE_1 finally ] start
	 */

	

	
	
	currentComponent="tFileOutputDelimitedGE_1";

	


		if(resourceMap.get("finish_tFileOutputDelimitedGE_1") == null){ 
			
				
						java.io.Writer outtFileOutputDelimitedGE_1 = (java.io.Writer)resourceMap.get("out_tFileOutputDelimitedGE_1");
						if(outtFileOutputDelimitedGE_1!=null) {
							outtFileOutputDelimitedGE_1.flush();
							outtFileOutputDelimitedGE_1.close();
						}
					
				
			
		}
	

 



/**
 * [tFileOutputDelimitedGE_1 finally ] stop
 */









				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tAS400Input_2_SUBPROCESS_STATE", 1);
	}
	

public void tFileExist_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tFileExist_1_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tFileExist_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tFileExist_1", false);
		start_Hash.put("tFileExist_1", System.currentTimeMillis());
		
	
	currentComponent="tFileExist_1";

	
		int tos_count_tFileExist_1 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tFileExist_1 - "  + ("Start to work.") );
    	class BytesLimit65535_tFileExist_1{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tFileExist_1 = new StringBuilder();
            log4jParamters_tFileExist_1.append("Parameters:");
                    log4jParamters_tFileExist_1.append("FILE_NAME" + " = " + "(String)globalMap.get(\"filetocheck\")");
                log4jParamters_tFileExist_1.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tFileExist_1 - "  + (log4jParamters_tFileExist_1) );
    		}
    	}
    	
        new BytesLimit65535_tFileExist_1().limitLog4jByte();

 



/**
 * [tFileExist_1 begin ] stop
 */
	
	/**
	 * [tFileExist_1 main ] start
	 */

	

	
	
	currentComponent="tFileExist_1";

	


				final StringBuffer log4jSb_tFileExist_1 = new StringBuffer();
			

java.io.File file_tFileExist_1 = new java.io.File((String)globalMap.get("filetocheck"));
if (!file_tFileExist_1.exists()) {
    globalMap.put("tFileExist_1_EXISTS",false);
    log.info("tFileExist_1 - Directory or file : " + file_tFileExist_1.getAbsolutePath() + " doesn't exist.");
}else{
	globalMap.put("tFileExist_1_EXISTS",true);
    log.info("tFileExist_1 - Directory or file : " + file_tFileExist_1.getAbsolutePath() + " exists.");
}

globalMap.put("tFileExist_1_FILENAME",(String)globalMap.get("filetocheck"));


 


	tos_count_tFileExist_1++;

/**
 * [tFileExist_1 main ] stop
 */
	
	/**
	 * [tFileExist_1 end ] start
	 */

	

	
	
	currentComponent="tFileExist_1";

	

 
                if(log.isDebugEnabled())
            log.debug("tFileExist_1 - "  + ("Done.") );

ok_Hash.put("tFileExist_1", true);
end_Hash.put("tFileExist_1", System.currentTimeMillis());

   			if (((Boolean)globalMap.get("tFileExist_1_EXISTS"))) {
   				
					if(execStat){   
   	 					runStat.updateStatOnConnection("If1", 0, "true");
					}
				
    			tFileProperties_1Process(globalMap);
   			}

			   
   				else{
					if(execStat){   
   	 					runStat.updateStatOnConnection("If1", 0, "false");
					}   	 
   				}



/**
 * [tFileExist_1 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage());
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tFileExist_1 finally ] start
	 */

	

	
	
	currentComponent="tFileExist_1";

	

 



/**
 * [tFileExist_1 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tFileExist_1_SUBPROCESS_STATE", 1);
	}
	


public static class filepropStruct implements routines.system.IPersistableRow<filepropStruct> {
    final static byte[] commonByteArrayLock_AWS_DEV_TALEND_INGESTION_FRAMEWORK_AS400_to_greenplum_with_GPLoad = new byte[0];
    static byte[] commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_AS400_to_greenplum_with_GPLoad = new byte[0];

	
			    public String abs_path;

				public String getAbs_path () {
					return this.abs_path;
				}
				
			    public String dirname;

				public String getDirname () {
					return this.dirname;
				}
				
			    public String basename;

				public String getBasename () {
					return this.basename;
				}
				
			    public String mode_string;

				public String getMode_string () {
					return this.mode_string;
				}
				
			    public Long size;

				public Long getSize () {
					return this.size;
				}
				
			    public Long mtime;

				public Long getMtime () {
					return this.mtime;
				}
				
			    public String mtime_string;

				public String getMtime_string () {
					return this.mtime_string;
				}
				



	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_AS400_to_greenplum_with_GPLoad.length) {
				if(length < 1024 && commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_AS400_to_greenplum_with_GPLoad.length == 0) {
   					commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_AS400_to_greenplum_with_GPLoad = new byte[1024];
				} else {
   					commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_AS400_to_greenplum_with_GPLoad = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_AS400_to_greenplum_with_GPLoad, 0, length);
			strReturn = new String(commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_AS400_to_greenplum_with_GPLoad, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_AWS_DEV_TALEND_INGESTION_FRAMEWORK_AS400_to_greenplum_with_GPLoad) {

        	try {

        		int length = 0;
		
					this.abs_path = readString(dis);
					
					this.dirname = readString(dis);
					
					this.basename = readString(dis);
					
					this.mode_string = readString(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.size = null;
           				} else {
           			    	this.size = dis.readLong();
           				}
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.mtime = null;
           				} else {
           			    	this.mtime = dis.readLong();
           				}
					
					this.mtime_string = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// String
				
						writeString(this.abs_path,dos);
					
					// String
				
						writeString(this.dirname,dos);
					
					// String
				
						writeString(this.basename,dos);
					
					// String
				
						writeString(this.mode_string,dos);
					
					// Long
				
						if(this.size == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeLong(this.size);
		            	}
					
					// Long
				
						if(this.mtime == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeLong(this.mtime);
		            	}
					
					// String
				
						writeString(this.mtime_string,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("abs_path="+abs_path);
		sb.append(",dirname="+dirname);
		sb.append(",basename="+basename);
		sb.append(",mode_string="+mode_string);
		sb.append(",size="+String.valueOf(size));
		sb.append(",mtime="+String.valueOf(mtime));
		sb.append(",mtime_string="+mtime_string);
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				if(abs_path == null){
        					sb.append("<null>");
        				}else{
            				sb.append(abs_path);
            			}
            		
        			sb.append("|");
        		
        				if(dirname == null){
        					sb.append("<null>");
        				}else{
            				sb.append(dirname);
            			}
            		
        			sb.append("|");
        		
        				if(basename == null){
        					sb.append("<null>");
        				}else{
            				sb.append(basename);
            			}
            		
        			sb.append("|");
        		
        				if(mode_string == null){
        					sb.append("<null>");
        				}else{
            				sb.append(mode_string);
            			}
            		
        			sb.append("|");
        		
        				if(size == null){
        					sb.append("<null>");
        				}else{
            				sb.append(size);
            			}
            		
        			sb.append("|");
        		
        				if(mtime == null){
        					sb.append("<null>");
        				}else{
            				sb.append(mtime);
            			}
            		
        			sb.append("|");
        		
        				if(mtime_string == null){
        					sb.append("<null>");
        				}else{
            				sb.append(mtime_string);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(filepropStruct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}
public void tFileProperties_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tFileProperties_1_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;



		filepropStruct fileprop = new filepropStruct();




	
	/**
	 * [tSetGlobalVar_2 begin ] start
	 */

	

	
		
		ok_Hash.put("tSetGlobalVar_2", false);
		start_Hash.put("tSetGlobalVar_2", System.currentTimeMillis());
		
	
	currentComponent="tSetGlobalVar_2";

	
			if (execStat) {
				if(resourceMap.get("inIterateVComp") == null){
					
						runStat.updateStatOnConnection("fileprop" + iterateId, 0, 0);
					
				}
			} 

		
		int tos_count_tSetGlobalVar_2 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tSetGlobalVar_2 - "  + ("Start to work.") );
    	class BytesLimit65535_tSetGlobalVar_2{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tSetGlobalVar_2 = new StringBuilder();
            log4jParamters_tSetGlobalVar_2.append("Parameters:");
                    log4jParamters_tSetGlobalVar_2.append("VARIABLES" + " = " + "[{VALUE="+("fileprop.size == null ? \"0\" : Long.toString(fileprop.size)")+", KEY="+("\"fileSize\"")+"}]");
                log4jParamters_tSetGlobalVar_2.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tSetGlobalVar_2 - "  + (log4jParamters_tSetGlobalVar_2) );
    		}
    	}
    	
        new BytesLimit65535_tSetGlobalVar_2().limitLog4jByte();

 



/**
 * [tSetGlobalVar_2 begin ] stop
 */



	
	/**
	 * [tFileProperties_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tFileProperties_1", false);
		start_Hash.put("tFileProperties_1", System.currentTimeMillis());
		
	
	currentComponent="tFileProperties_1";

	
		int tos_count_tFileProperties_1 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tFileProperties_1 - "  + ("Start to work.") );
    	class BytesLimit65535_tFileProperties_1{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tFileProperties_1 = new StringBuilder();
            log4jParamters_tFileProperties_1.append("Parameters:");
                    log4jParamters_tFileProperties_1.append("FILENAME" + " = " + "(String)globalMap.get(\"filetocheck\")");
                log4jParamters_tFileProperties_1.append(" | ");
                    log4jParamters_tFileProperties_1.append("MD5" + " = " + "false");
                log4jParamters_tFileProperties_1.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tFileProperties_1 - "  + (log4jParamters_tFileProperties_1) );
    		}
    	}
    	
        new BytesLimit65535_tFileProperties_1().limitLog4jByte();


				final StringBuffer log4jSb_tFileProperties_1 = new StringBuffer();
			

java.io.File file_tFileProperties_1 = new java.io.File((String)globalMap.get("filetocheck"));
fileprop = new filepropStruct();

if(file_tFileProperties_1.exists()) {
    fileprop.abs_path = file_tFileProperties_1.getAbsolutePath();
    fileprop.dirname = file_tFileProperties_1.getParent();
    fileprop.basename = file_tFileProperties_1.getName();
    String r_tFileProperties_1 = (file_tFileProperties_1.canRead())?"r":"-";
	String w_tFileProperties_1 = (file_tFileProperties_1.canWrite())?"w":"-";
	//String x_ = (file_.canExecute())?"x":"-"; /*since JDK1.6*/
    fileprop.mode_string = r_tFileProperties_1 + w_tFileProperties_1;
    fileprop.size = file_tFileProperties_1.length();
    fileprop.mtime = file_tFileProperties_1.lastModified();
    fileprop.mtime_string =(new java.util.Date(file_tFileProperties_1.lastModified())).toString();
	
	
}
	else {
		log.info("tFileProperties_1 - File : " + file_tFileProperties_1.getAbsolutePath() + " doesn't exist.");
	}
 



/**
 * [tFileProperties_1 begin ] stop
 */
	
	/**
	 * [tFileProperties_1 main ] start
	 */

	

	
	
	currentComponent="tFileProperties_1";

	

 


	tos_count_tFileProperties_1++;

/**
 * [tFileProperties_1 main ] stop
 */

	
	/**
	 * [tSetGlobalVar_2 main ] start
	 */

	

	
	
	currentComponent="tSetGlobalVar_2";

	

			//fileprop
			//fileprop


			
				if(execStat){
					runStat.updateStatOnConnection("fileprop"+iterateId,1, 1);
				} 
			

		
    			if(log.isTraceEnabled()){
    				log.trace("fileprop - " + (fileprop==null? "": fileprop.toLogString()));
    			}
    		

globalMap.put("fileSize", fileprop.size == null ? "0" : Long.toString(fileprop.size));

 


	tos_count_tSetGlobalVar_2++;

/**
 * [tSetGlobalVar_2 main ] stop
 */



	
	/**
	 * [tFileProperties_1 end ] start
	 */

	

	
	
	currentComponent="tFileProperties_1";

	

 
                if(log.isDebugEnabled())
            log.debug("tFileProperties_1 - "  + ("Done.") );

ok_Hash.put("tFileProperties_1", true);
end_Hash.put("tFileProperties_1", System.currentTimeMillis());




/**
 * [tFileProperties_1 end ] stop
 */

	
	/**
	 * [tSetGlobalVar_2 end ] start
	 */

	

	
	
	currentComponent="tSetGlobalVar_2";

	

			if(execStat){
				if(resourceMap.get("inIterateVComp") == null || !((Boolean)resourceMap.get("inIterateVComp"))){
			 		runStat.updateStatOnConnection("fileprop"+iterateId,2, 0); 
			 	}
			}
		
 
                if(log.isDebugEnabled())
            log.debug("tSetGlobalVar_2 - "  + ("Done.") );

ok_Hash.put("tSetGlobalVar_2", true);
end_Hash.put("tSetGlobalVar_2", System.currentTimeMillis());

   			if ((fileprop.size == null ? "20" : Long.toString(fileprop.size)).equals("20") == false) {
   				
					if(execStat){   
   	 					runStat.updateStatOnConnection("If2", 0, "true");
					}
				
    			tGEGreenplumGPLoad_1Process(globalMap);
   			}

			   
   				else{
					if(execStat){   
   	 					runStat.updateStatOnConnection("If2", 0, "false");
					}   	 
   				}
   			if ((fileprop.size == null ? "20" : Long.toString(fileprop.size)).equals("20") == true
) {
   				
					if(execStat){   
   	 					runStat.updateStatOnConnection("If6", 0, "true");
					}
				
    			tAS400Input_3Process(globalMap);
   			}

			   
   				else{
					if(execStat){   
   	 					runStat.updateStatOnConnection("If6", 0, "false");
					}   	 
   				}



/**
 * [tSetGlobalVar_2 end ] stop
 */



				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage());
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tFileProperties_1 finally ] start
	 */

	

	
	
	currentComponent="tFileProperties_1";

	

 



/**
 * [tFileProperties_1 finally ] stop
 */

	
	/**
	 * [tSetGlobalVar_2 finally ] start
	 */

	

	
	
	currentComponent="tSetGlobalVar_2";

	

 



/**
 * [tSetGlobalVar_2 finally ] stop
 */



				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tFileProperties_1_SUBPROCESS_STATE", 1);
	}
	

public void tGEGreenplumGPLoad_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tGEGreenplumGPLoad_1_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tGEGreenplumGPLoad_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tGEGreenplumGPLoad_1", false);
		start_Hash.put("tGEGreenplumGPLoad_1", System.currentTimeMillis());
		
	
	currentComponent="tGEGreenplumGPLoad_1";

	
		int tos_count_tGEGreenplumGPLoad_1 = 0;
		
    	class BytesLimit65535_tGEGreenplumGPLoad_1{
    		public void limitLog4jByte() throws Exception{
    			
    		}
    	}
    	
        new BytesLimit65535_tGEGreenplumGPLoad_1().limitLog4jByte();

				log.info("tGEGreenplumGPLoad_1 - Start to work");
				StringBuffer log4jSb_tGEGreenplumGPLoad_1 = new StringBuffer();
	int deletedCount_tGEGreenplumGPLoad_1 = 0;
	int insertedCount_tGEGreenplumGPLoad_1 = 0;

	String tableName_tGEGreenplumGPLoad_1 = (String)globalMap.get("row1.target_table_name");
	String dbschema_tGEGreenplumGPLoad_1 = (String)globalMap.get("row1.target_schema");
	String tableName4Load_tGEGreenplumGPLoad_1 = "\"" + tableName_tGEGreenplumGPLoad_1 + "\"";
	if(dbschema_tGEGreenplumGPLoad_1 != null && dbschema_tGEGreenplumGPLoad_1.trim().length() > 0) {
		tableName_tGEGreenplumGPLoad_1 = dbschema_tGEGreenplumGPLoad_1 + "\".\"" + (String)globalMap.get("row1.target_table_name");
		tableName4Load_tGEGreenplumGPLoad_1 = "\""+dbschema_tGEGreenplumGPLoad_1 + "\".\"" + (String)globalMap.get("row1.target_table_name")+"\"";
	}

		java.lang.Class.forName("org.postgresql.Driver");  
				String url_tGEGreenplumGPLoad_1 = "jdbc:postgresql://"+context.SOURCING_Server+":"+context.SOURCING_Port+"/"+context.SOURCING_Database+"?ssl=true&sslfactory=org.postgresql.ssl.NonValidatingFactory";
		// String url_tGEGreenplumGPLoad_1 = "jdbc:postgresql://"+context.SOURCING_Server+":"+context.SOURCING_Port+"/"+context.SOURCING_Database+"?ssl=true&sslfactory=org.postgresql.ssl.NonValidatingFactory";
		String dbUser_tGEGreenplumGPLoad_1 = context.SOURCING_Login;
		String dbPwd_tGEGreenplumGPLoad_1 = context.SOURCING_Password;
		java.sql.Connection conn_tGEGreenplumGPLoad_1 = null;
		
				String log4jDebugParamters_tGEGreenplumGPLoad_1 = "";
				
				
					String dbhost_log4j_tGEGreenplumGPLoad_1 = context.SOURCING_Server;
					log4jDebugParamters_tGEGreenplumGPLoad_1 = log4jDebugParamters_tGEGreenplumGPLoad_1 + "HOST = " + dbhost_log4j_tGEGreenplumGPLoad_1 + " | ";
				
				
					String dbport_log4j_tGEGreenplumGPLoad_1 = context.SOURCING_Port;
					log4jDebugParamters_tGEGreenplumGPLoad_1 = log4jDebugParamters_tGEGreenplumGPLoad_1 + "PORT = " + dbport_log4j_tGEGreenplumGPLoad_1 + " | ";
				
				
					String dbname_log4j_tGEGreenplumGPLoad_1 = context.SOURCING_Database;
					log4jDebugParamters_tGEGreenplumGPLoad_1 = log4jDebugParamters_tGEGreenplumGPLoad_1 + "DBNAME = " + dbname_log4j_tGEGreenplumGPLoad_1 + " | ";
				
				
					String dbuser_log4j_tGEGreenplumGPLoad_1 = context.SOURCING_Login;
					log4jDebugParamters_tGEGreenplumGPLoad_1 = log4jDebugParamters_tGEGreenplumGPLoad_1 + "USERNAME = " + dbuser_log4j_tGEGreenplumGPLoad_1 + " | ";
				
				
				
				
					String dbSchema_log4j_tGEGreenplumGPLoad_1 = (String)globalMap.get("row1.target_schema");
					log4jDebugParamters_tGEGreenplumGPLoad_1 = log4jDebugParamters_tGEGreenplumGPLoad_1 + "DBSCHEMA = " + dbSchema_log4j_tGEGreenplumGPLoad_1 + " | ";
				
				
				
				
				
					String table_log4j_tGEGreenplumGPLoad_1 = (String)globalMap.get("row1.target_table_name");
					log4jDebugParamters_tGEGreenplumGPLoad_1 = log4jDebugParamters_tGEGreenplumGPLoad_1 + "TABLE = " + table_log4j_tGEGreenplumGPLoad_1 + " | ";
				
				
				log4jDebugParamters_tGEGreenplumGPLoad_1 = "tGEGreenplumGPLoad_1 - Parameters:" + log4jDebugParamters_tGEGreenplumGPLoad_1;
				log.debug("tGEGreenplumGPLoad_1 - Driver ClassName: org.postgresql.Driver.");
				log.debug(log4jDebugParamters_tGEGreenplumGPLoad_1);	
		
			log.info("tGEGreenplumGPLoad_1 - Connection attempt to '" + url_tGEGreenplumGPLoad_1 + "' with the username '" + dbUser_tGEGreenplumGPLoad_1 + "'.");
		
		conn_tGEGreenplumGPLoad_1 = java.sql.DriverManager.getConnection(url_tGEGreenplumGPLoad_1, dbUser_tGEGreenplumGPLoad_1, dbPwd_tGEGreenplumGPLoad_1);
		
			log.info("tGEGreenplumGPLoad_1 - Connection to '" + url_tGEGreenplumGPLoad_1 + "' has succeeded." );
		
		
        conn_tGEGreenplumGPLoad_1.close();

		
	        String delim_tGEGreenplumGPLoad_1 = "\\013";
		String escape_tGEGreenplumGPLoad_1 = "\\";
		String quote_tGEGreenplumGPLoad_1 = "\"";
		delim_tGEGreenplumGPLoad_1 = "\t".equals(delim_tGEGreenplumGPLoad_1) ? "\\t" : delim_tGEGreenplumGPLoad_1;
		/**
		 Create Directory if does not exists 
		*/
		String directory_tGEGreenplumGPLoad_1 = context.ETL_STORAGE_PATH + "/" + context.GP_SOURCE_NAME + "/data/" +context.SOURCE_DATABASE  + "/" + ((String)globalMap.get("row1.log_table_name"))  + ".yaml";
		//create directory only if not exists
	    if(directory_tGEGreenplumGPLoad_1 != null && directory_tGEGreenplumGPLoad_1.trim().length() != 0 
	    		&& directory_tGEGreenplumGPLoad_1.replace("\\","/").contains("/")) {
	    	directory_tGEGreenplumGPLoad_1 = directory_tGEGreenplumGPLoad_1.substring(0, directory_tGEGreenplumGPLoad_1.replace("\\","/").lastIndexOf("/"));
	    	java.io.File dir_tGEGreenplumGPLoad_1 = new java.io.File(directory_tGEGreenplumGPLoad_1);
	        	if(!dir_tGEGreenplumGPLoad_1.exists()) {
					dir_tGEGreenplumGPLoad_1.mkdirs();
					System.out.println("Created Directory:" + dir_tGEGreenplumGPLoad_1);
	            }
	    }

		java.io.PrintWriter gpctrl_tGEGreenplumGPLoad_1 = new java.io.PrintWriter(new java.io.FileOutputStream(context.ETL_STORAGE_PATH + "/" + context.GP_SOURCE_NAME + "/data/" +context.SOURCE_DATABASE  + "/" + ((String)globalMap.get("row1.log_table_name"))  + ".yaml", false), true);
		gpctrl_tGEGreenplumGPLoad_1.println("---");
		gpctrl_tGEGreenplumGPLoad_1.println("VERSION: 1.0.0.1");
		gpctrl_tGEGreenplumGPLoad_1.println("DATABASE: " + context.SOURCING_Database);
		gpctrl_tGEGreenplumGPLoad_1.println("USER: " + context.SOURCING_Login);
		gpctrl_tGEGreenplumGPLoad_1.println("PASSWORD: " + context.SOURCING_Password);
		gpctrl_tGEGreenplumGPLoad_1.println("HOST: " + context.SOURCING_Server);
		gpctrl_tGEGreenplumGPLoad_1.println("PORT: " + context.SOURCING_Port);
		gpctrl_tGEGreenplumGPLoad_1.println("GPLOAD:");
		gpctrl_tGEGreenplumGPLoad_1.println("  INPUT:");
		gpctrl_tGEGreenplumGPLoad_1.println("    - SOURCE:");
		String sourceLocalHostname_tGEGreenplumGPLoad_1 = context.ETL_LOCALHOSTNAME;
		if(sourceLocalHostname_tGEGreenplumGPLoad_1.length()>0) {
			gpctrl_tGEGreenplumGPLoad_1.println("        LOCAL_HOSTNAME:");
			gpctrl_tGEGreenplumGPLoad_1.println("        - "+context.ETL_LOCALHOSTNAME);
		}
		String sourcePort_tGEGreenplumGPLoad_1 = context.HAWQ_Source_Ports;
		if(sourcePort_tGEGreenplumGPLoad_1.length() > 0 ) {
			gpctrl_tGEGreenplumGPLoad_1.println("        PORT_RANGE: "+context.HAWQ_Source_Ports);
		} else {
			gpctrl_tGEGreenplumGPLoad_1.println("        PORT_RANGE: "+"[8500,8999]");
		}
		gpctrl_tGEGreenplumGPLoad_1.println("        FILE:");
		
		gpctrl_tGEGreenplumGPLoad_1.println("          - " + (String)globalMap.get("filetocheck"));
		
		gpctrl_tGEGreenplumGPLoad_1.println("    - MAX_LINE_LENGTH: 268435456");
		String columnDefList_tGEGreenplumGPLoad_1 = GPLoadRoutine.getGPLoadColumnList((String)globalMap.get("columnlist"));
		if(columnDefList_tGEGreenplumGPLoad_1.length() > 0) {
			gpctrl_tGEGreenplumGPLoad_1.println("    - COLUMNS:");
			gpctrl_tGEGreenplumGPLoad_1.println(GPLoadRoutine.getGPLoadColumnList((String)globalMap.get("columnlist")));
		}
		gpctrl_tGEGreenplumGPLoad_1.println("    - DELIMITER: E'" + delim_tGEGreenplumGPLoad_1 + "'");
		gpctrl_tGEGreenplumGPLoad_1.println("    - ESCAPE: '" + escape_tGEGreenplumGPLoad_1 + "'");
		
		gpctrl_tGEGreenplumGPLoad_1.println("    - FORMAT: text");
		
		
		gpctrl_tGEGreenplumGPLoad_1.println("    - ENCODING: " + "UTF8");
		
				gpctrl_tGEGreenplumGPLoad_1.println("    - ERROR_LIMIT: " + 1000);
				
		gpctrl_tGEGreenplumGPLoad_1.println("  OUTPUT: ");
		gpctrl_tGEGreenplumGPLoad_1.println("    - TABLE: " + (String)globalMap.get("row1.target_schema")+"."+(String)globalMap.get("row1.target_table_name"));
		gpctrl_tGEGreenplumGPLoad_1.println("    - MODE: insert");
		

		gpctrl_tGEGreenplumGPLoad_1.close();
		

	final StringBuilder gploadOutput_tGEGreenplumGPLoad_1 = new StringBuilder(200);
	/**
		Create an exception handler to be able to catch exception coming from the thread.
	*/
	final class GpLoadExceptionHandler_tGEGreenplumGPLoad_1 implements Thread.UncaughtExceptionHandler {

		private Thread.UncaughtExceptionHandler defaultUEH;
		private volatile Throwable tr;

		public GpLoadExceptionHandler_tGEGreenplumGPLoad_1() {
        	this.defaultUEH = Thread.getDefaultUncaughtExceptionHandler();
    	}

        public void uncaughtException(Thread t, Throwable e) {
    	    tr = e;
	       	defaultUEH.uncaughtException(t, e);
    	}

    	public Throwable getException() {
    		return tr;
    	}

    	public void resetException() {
    		this.tr = null;
    	}
	}
	GpLoadExceptionHandler_tGEGreenplumGPLoad_1 h_tGEGreenplumGPLoad_1 = new GpLoadExceptionHandler_tGEGreenplumGPLoad_1() ;

	Thread gploadThread_tGEGreenplumGPLoad_1 =
		new Thread() {
		public void run() {
			try {
				String[] envp = null;
				String[] cmds = new String[] {"gpload","-f",context.ETL_STORAGE_PATH + "/" + context.GP_SOURCE_NAME + "/data/" +context.SOURCE_DATABASE  + "/" + ((String)globalMap.get("row1.log_table_name"))  + ".yaml","-h",context.SOURCING_Server,"-p",context.SOURCING_Port,"-U",context.SOURCING_Login,"-d",context.SOURCING_Database,"-l",context.ETL_STORAGE_PATH + "/" +context.GP_SOURCE_NAME + "/data/" + context.SOURCE_DATABASE  + "/" + ((String)globalMap.get("row1.log_table_name")).replace("\"","").replace("#","__hash__").replace("$","__dollar__")  + new SimpleDateFormat("yyyyMMddHHmmss").format(((java.util.Date)globalMap.get("row1.now"))).toString() + ".log","-v"};
				Boolean failure = false;
				Runtime rt = Runtime.getRuntime();
				final Process ps = rt.exec(cmds, envp);
				java.io.BufferedReader reader = new java.io.BufferedReader(new java.io.InputStreamReader(ps.getInputStream()));
				String line = "";
				while ((line = reader.readLine()) != null) {
					gploadOutput_tGEGreenplumGPLoad_1.append(line);
					if(line.contains("|INFO|rows Inserted")){
						globalMap.put("tGEGreenplumGPLoad_1_NB_LINE_INSERTED",Integer.parseInt(line.substring(line.indexOf("=")+1).replace(" ","")));
					} else
					if(line.contains("|INFO|rows Updated")){
					      globalMap.put("tGEGreenplumGPLoad_1_NB_LINE_UPDATED", Integer.parseInt(line.substring(line.indexOf("=")+1).replace(" ","")));
					} else if(line.contains("|INFO|data formatting errors =")){
					      globalMap.put("tGEGreenplumGPLoad_1_NB_DATA_ERRORS", Integer.parseInt(line.substring(line.indexOf("=")+1).replace(" ","")));
					} else if(line.contains("|INFO|gpload ") && !line.contains("session") && !line.contains("gpload.py") ){
					      globalMap.put("tGEGreenplumGPLoad_1_STATUS", line.substring(line.indexOf("gpload ")+7).replace(" ",""));
					} else if(line.contains("|INFO|running time:")){
					      line = line.substring(line.indexOf("time: ")+5).replace(" ","");
					      globalMap.put("tGEGreenplumGPLoad_1_RUNTIME", line.substring(0,line.indexOf("seconds")));
					} else if(line.contains("|ERROR|")){
						failure = true;
					      line = line.substring(line.indexOf("|ERROR|")+7);
					      String line1 = line;
					      if(line.length()>1250) {
					            String tmp = line.substring(0, 1000);
					            tmp += ".....";
					            tmp += line.substring(line.length()-200);
					            line = tmp;
					      }
					      globalMap.put("tGEGreenplumGPLoad_1_ERRORMESSAGE", line);
					      if(true){
					      	throw new RuntimeException ("gpload failed because: " + line1);
					      } else {
					      	System.out.println("WARNING GPLOAD FAILURE:" + line1);
					      }
					}
				}
				reader = new java.io.BufferedReader(new java.io.InputStreamReader(ps.getErrorStream()));
				line = "";
				while ((line = reader.readLine()) != null) {
					gploadOutput_tGEGreenplumGPLoad_1.append(line);

					if (line.contains("name 'tableName' is not defined") ) {
						failure = true;

						String line1 = "Table (" + context.SOURCING_Database + "." + (String)globalMap.get("row1.target_schema") + "." + (String)globalMap.get("row1.target_table_name") + ") is not available in target (" + context.SOURCING_Server + ")!";
						globalMap.put("tGEGreenplumGPLoad_1_ERRORMESSAGE", line1);
					    if(true){
					      	throw new RuntimeException ("gpload failed because: " + line1);
					    } else {
					      	System.out.println("WARNING GPLOAD FAILURE:" + line1);
					    }
					}
					if (line.toUpperCase().contains("ERROR") ) {
						failure = true;
						globalMap.put("tGEGreenplumGPLoad_1_ERRORMESSAGE", line);
					    if(true){
					      	throw new RuntimeException ("gpload failed because: " + line);
					    } else {
					      	System.out.println("WARNING GPLOAD FAILURE:" + line);
					    }
					}
				}
			}
			catch (java.lang.Exception e) {
				
					log.fatal("tGEGreenplumGPLoad_1 - " + e.getMessage());
				
				globalMap.put("tGEGreenplumGPLoad_1_GPLOAD_ERROR",e.getMessage());
				throw new RuntimeException(e.getMessage(),e.getCause());
			}
		}
	};
	gploadThread_tGEGreenplumGPLoad_1.setUncaughtExceptionHandler(h_tGEGreenplumGPLoad_1);
	Thread gploadThread_retry_tGEGreenplumGPLoad_1 =
		new Thread() {
		public void run() {
			try {
				String[] envp = null;
				String[] cmds = new String[] {"gpload","-f",context.ETL_STORAGE_PATH + "/" + context.GP_SOURCE_NAME + "/data/" +context.SOURCE_DATABASE  + "/" + ((String)globalMap.get("row1.log_table_name"))  + ".yaml","-h",context.SOURCING_Server,"-p",context.SOURCING_Port,"-U",context.SOURCING_Login,"-d",context.SOURCING_Database,"-l",context.ETL_STORAGE_PATH + "/" +context.GP_SOURCE_NAME + "/data/" + context.SOURCE_DATABASE  + "/" + ((String)globalMap.get("row1.log_table_name")).replace("\"","").replace("#","__hash__").replace("$","__dollar__")  + new SimpleDateFormat("yyyyMMddHHmmss").format(((java.util.Date)globalMap.get("row1.now"))).toString() + ".log","-v"};
				Boolean failure = false;
				Runtime rt = Runtime.getRuntime();
				final Process ps = rt.exec(cmds, envp);
				java.io.BufferedReader reader = new java.io.BufferedReader(new java.io.InputStreamReader(ps.getInputStream()));
				String line = "";
				while ((line = reader.readLine()) != null) {
					gploadOutput_tGEGreenplumGPLoad_1.append(line);
					if(line.contains("|INFO|rows Inserted")){
						globalMap.put("tGEGreenplumGPLoad_1_NB_LINE_INSERTED",Integer.parseInt(line.substring(line.indexOf("=")+1).replace(" ","")));
					} else
					if(line.contains("|INFO|rows Updated")){
					      globalMap.put("tGEGreenplumGPLoad_1_NB_LINE_UPDATED", Integer.parseInt(line.substring(line.indexOf("=")+1).replace(" ","")));
					} else if(line.contains("|INFO|data formatting errors =")){
					      globalMap.put("tGEGreenplumGPLoad_1_NB_DATA_ERRORS", Integer.parseInt(line.substring(line.indexOf("=")+1).replace(" ","")));
					} else if(line.contains("|INFO|gpload ") && !line.contains("session") && !line.contains("gpload.py") ){
					      globalMap.put("tGEGreenplumGPLoad_1_STATUS", line.substring(line.indexOf("gpload ")+7).replace(" ",""));
					} else if(line.contains("|INFO|running time:")){
					      line = line.substring(line.indexOf("time: ")+5).replace(" ","");
					      globalMap.put("tGEGreenplumGPLoad_1_RUNTIME", line.substring(0,line.indexOf("seconds")));
					} else if(line.contains("|ERROR|")){
						failure = true;
					      line = line.substring(line.indexOf("|ERROR|")+7);
					      String line1 = line;
					      if(line.length()>1250) {
					            String tmp = line.substring(0, 1000);
					            tmp += ".....";
					            tmp += line.substring(line.length()-200);
					            line = tmp;
					      }
					      globalMap.put("tGEGreenplumGPLoad_1_ERRORMESSAGE", line);
					      if(true){
					      	throw new RuntimeException ("gpload failed because: " + line1);
					      } else {
					      	System.out.println("WARNING GPLOAD FAILURE:" + line1);
					      }
					}
				}
				reader = new java.io.BufferedReader(new java.io.InputStreamReader(ps.getErrorStream()));
				line = "";
				while ((line = reader.readLine()) != null) {
					gploadOutput_tGEGreenplumGPLoad_1.append(line);

					if (line.contains("name 'tableName' is not defined") ) {
						failure = true;

						String line1 = "Table (" + context.SOURCING_Database + "." + (String)globalMap.get("row1.target_schema") + "." + (String)globalMap.get("row1.target_table_name") + ") is not available in target (" + context.SOURCING_Server + ")!";
						globalMap.put("tGEGreenplumGPLoad_1_ERRORMESSAGE", line1);
					    if(true){
					      	throw new RuntimeException ("gpload failed because: " + line1);
					    } else {
					      	System.out.println("WARNING GPLOAD FAILURE:" + line1);
					    }
					}
					if (line.toUpperCase().contains("ERROR") ) {
						failure = true;
						globalMap.put("tGEGreenplumGPLoad_1_ERRORMESSAGE", line);
					    if(true){
					      	throw new RuntimeException ("gpload failed because: " + line);
					    } else {
					      	System.out.println("WARNING GPLOAD FAILURE:" + line);
					    }
					}
				}
			}
			catch (java.lang.Exception e) {
				
					log.fatal("tGEGreenplumGPLoad_1 - " + e.getMessage());
				
				globalMap.put("tGEGreenplumGPLoad_1_GPLOAD_ERROR",e.getMessage());
				throw new RuntimeException(e.getMessage(),e.getCause());
			}
		}
	};
	gploadThread_retry_tGEGreenplumGPLoad_1.setUncaughtExceptionHandler(h_tGEGreenplumGPLoad_1);
		
			log.info("tGEGreenplumGPLoad_1 - Loading data into database.");
		
	gploadThread_tGEGreenplumGPLoad_1.start();
	gploadThread_tGEGreenplumGPLoad_1.join(0);
	globalMap.put("tGEGreenplumGPLoad_1_GPLOAD_OUTPUT", gploadOutput_tGEGreenplumGPLoad_1.toString());
	globalMap.put("tGEGreenplumGPLoad_1_NB_LINE", insertedCount_tGEGreenplumGPLoad_1);
		
			log.info("tGEGreenplumGPLoad_1 - Loaded records count:" + insertedCount_tGEGreenplumGPLoad_1 + ".");
			log.info("tGEGreenplumGPLoad_1 - Has finished.");
		

 



/**
 * [tGEGreenplumGPLoad_1 begin ] stop
 */
	
	/**
	 * [tGEGreenplumGPLoad_1 main ] start
	 */

	

	
	
	currentComponent="tGEGreenplumGPLoad_1";

	



 


	tos_count_tGEGreenplumGPLoad_1++;

/**
 * [tGEGreenplumGPLoad_1 main ] stop
 */
	
	/**
	 * [tGEGreenplumGPLoad_1 end ] start
	 */

	

	
	
	currentComponent="tGEGreenplumGPLoad_1";

	


	if (h_tGEGreenplumGPLoad_1.getException() != null ) {
		if (h_tGEGreenplumGPLoad_1.getException() instanceof Error)
           	throw (Error) h_tGEGreenplumGPLoad_1.getException();
        if (h_tGEGreenplumGPLoad_1.getException() instanceof RuntimeException)
           	throw (RuntimeException) h_tGEGreenplumGPLoad_1.getException();
        else
	      	throw new RuntimeException(h_tGEGreenplumGPLoad_1.getException());
	}
	globalMap.put("tGEGreenplumGPLoad_1_GPLOAD_OUTPUT", gploadOutput_tGEGreenplumGPLoad_1.toString());
	globalMap.put("tGEGreenplumGPLoad_1_NB_LINE", insertedCount_tGEGreenplumGPLoad_1);
	
 

ok_Hash.put("tGEGreenplumGPLoad_1", true);
end_Hash.put("tGEGreenplumGPLoad_1", System.currentTimeMillis());




/**
 * [tGEGreenplumGPLoad_1 end ] stop
 */
				}//end the resume

				
				    			if(resumeEntryMethodName == null || globalResumeTicket){
				    				resumeUtil.addLog("CHECKPOINT", "CONNECTION:SUBJOB_OK:tGEGreenplumGPLoad_1:OnSubjobOk", "", Thread.currentThread().getId() + "", "", "", "", "", "");
								}	    				    			
					    	
								if(execStat){    	
									runStat.updateStatOnConnection("OnSubjobOk3", 0, "ok");
								} 
							
							tFileInputFullRow_2Process(globalMap); 
						



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage());
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tGEGreenplumGPLoad_1 finally ] start
	 */

	

	
	
	currentComponent="tGEGreenplumGPLoad_1";

	

 



/**
 * [tGEGreenplumGPLoad_1 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tGEGreenplumGPLoad_1_SUBPROCESS_STATE", 1);
	}
	


public static class row9Struct implements routines.system.IPersistableRow<row9Struct> {
    final static byte[] commonByteArrayLock_AWS_DEV_TALEND_INGESTION_FRAMEWORK_AS400_to_greenplum_with_GPLoad = new byte[0];
    static byte[] commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_AS400_to_greenplum_with_GPLoad = new byte[0];

	
			    public String line;

				public String getLine () {
					return this.line;
				}
				



	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_AS400_to_greenplum_with_GPLoad.length) {
				if(length < 1024 && commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_AS400_to_greenplum_with_GPLoad.length == 0) {
   					commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_AS400_to_greenplum_with_GPLoad = new byte[1024];
				} else {
   					commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_AS400_to_greenplum_with_GPLoad = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_AS400_to_greenplum_with_GPLoad, 0, length);
			strReturn = new String(commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_AS400_to_greenplum_with_GPLoad, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_AWS_DEV_TALEND_INGESTION_FRAMEWORK_AS400_to_greenplum_with_GPLoad) {

        	try {

        		int length = 0;
		
					this.line = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// String
				
						writeString(this.line,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("line="+line);
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				if(line == null){
        					sb.append("<null>");
        				}else{
            				sb.append(line);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(row9Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}
public void tFileInputFullRow_2Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tFileInputFullRow_2_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;



		row9Struct row9 = new row9Struct();




	
	/**
	 * [tJavaRow_2 begin ] start
	 */

	

	
		
		ok_Hash.put("tJavaRow_2", false);
		start_Hash.put("tJavaRow_2", System.currentTimeMillis());
		
	
	currentComponent="tJavaRow_2";

	
			if (execStat) {
				if(resourceMap.get("inIterateVComp") == null){
					
						runStat.updateStatOnConnection("row9" + iterateId, 0, 0);
					
				}
			} 

		
		int tos_count_tJavaRow_2 = 0;
		
    	class BytesLimit65535_tJavaRow_2{
    		public void limitLog4jByte() throws Exception{
    			
    		}
    	}
    	
        new BytesLimit65535_tJavaRow_2().limitLog4jByte();

int nb_line_tJavaRow_2 = 0;

 



/**
 * [tJavaRow_2 begin ] stop
 */



	
	/**
	 * [tFileInputFullRow_2 begin ] start
	 */

	

	
		
		ok_Hash.put("tFileInputFullRow_2", false);
		start_Hash.put("tFileInputFullRow_2", System.currentTimeMillis());
		
	
	currentComponent="tFileInputFullRow_2";

	
		int tos_count_tFileInputFullRow_2 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tFileInputFullRow_2 - "  + ("Start to work.") );
    	class BytesLimit65535_tFileInputFullRow_2{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tFileInputFullRow_2 = new StringBuilder();
            log4jParamters_tFileInputFullRow_2.append("Parameters:");
                    log4jParamters_tFileInputFullRow_2.append("FILENAME" + " = " + "context.ETL_STORAGE_PATH + \"/\" +context.GP_SOURCE_NAME + \"/data/\" + context.SOURCE_DATABASE  + \"/\" + ((String)globalMap.get(\"row1.log_table_name\")).replace(\"\\\"\",\"\").replace(\"#\",\"__hash__\").replace(\"$\",\"__dollar__\")  + new SimpleDateFormat(\"yyyyMMddHHmmss\").format(((java.util.Date)globalMap.get(\"row1.now\"))).toString() + \".log\"");
                log4jParamters_tFileInputFullRow_2.append(" | ");
                    log4jParamters_tFileInputFullRow_2.append("ROWSEPARATOR" + " = " + "\"\\n\"");
                log4jParamters_tFileInputFullRow_2.append(" | ");
                    log4jParamters_tFileInputFullRow_2.append("HEADER" + " = " + "");
                log4jParamters_tFileInputFullRow_2.append(" | ");
                    log4jParamters_tFileInputFullRow_2.append("FOOTER" + " = " + "");
                log4jParamters_tFileInputFullRow_2.append(" | ");
                    log4jParamters_tFileInputFullRow_2.append("LIMIT" + " = " + "");
                log4jParamters_tFileInputFullRow_2.append(" | ");
                    log4jParamters_tFileInputFullRow_2.append("REMOVE_EMPTY_ROW" + " = " + "true");
                log4jParamters_tFileInputFullRow_2.append(" | ");
                    log4jParamters_tFileInputFullRow_2.append("ENCODING" + " = " + "\"ISO-8859-15\"");
                log4jParamters_tFileInputFullRow_2.append(" | ");
                    log4jParamters_tFileInputFullRow_2.append("RANDOM" + " = " + "false");
                log4jParamters_tFileInputFullRow_2.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tFileInputFullRow_2 - "  + (log4jParamters_tFileInputFullRow_2) );
    		}
    	}
    	
        new BytesLimit65535_tFileInputFullRow_2().limitLog4jByte();

				final StringBuffer log4jSb_tFileInputFullRow_2 = new StringBuffer();
			
	org.talend.fileprocess.FileInputDelimited fid_tFileInputFullRow_2 = null;

					log.debug("tFileInputFullRow_2 - Retrieving records from the datasource.");
			

	try{//}
		fid_tFileInputFullRow_2 =new org.talend.fileprocess.FileInputDelimited(context.ETL_STORAGE_PATH + "/" +context.GP_SOURCE_NAME + "/data/" + context.SOURCE_DATABASE  + "/" + ((String)globalMap.get("row1.log_table_name")).replace("\"","").replace("#","__hash__").replace("$","__dollar__")  + new SimpleDateFormat("yyyyMMddHHmmss").format(((java.util.Date)globalMap.get("row1.now"))).toString() + ".log","ISO-8859-15","","\n",true,0,0,-1,-1,false);
		while (fid_tFileInputFullRow_2.nextRecord()) {//}
			row9 = null;						
	boolean whetherReject_tFileInputFullRow_2 = false;
	row9 = new row9Struct();
		row9.line = fid_tFileInputFullRow_2.get(0);

 



/**
 * [tFileInputFullRow_2 begin ] stop
 */
	
	/**
	 * [tFileInputFullRow_2 main ] start
	 */

	

	
	
	currentComponent="tFileInputFullRow_2";

	

 


	tos_count_tFileInputFullRow_2++;

/**
 * [tFileInputFullRow_2 main ] stop
 */

	
	/**
	 * [tJavaRow_2 main ] start
	 */

	

	
	
	currentComponent="tJavaRow_2";

	

			//row9
			//row9


			
				if(execStat){
					runStat.updateStatOnConnection("row9"+iterateId,1, 1);
				} 
			

		
    			if(log.isTraceEnabled()){
    				log.trace("row9 - " + (row9==null? "": row9.toLogString()));
    			}
    		

    
String line = row9.line;
System.out.println(line);
if(line.contains("|INFO|rows Inserted")){
	System.out.println("gpload_inserted: " + String.valueOf(Integer.parseInt(line.substring(line.indexOf("=")+1).replace(" ",""))));
} else
if(line.contains("|INFO|rows Updated")){
	System.out.println("gpload_updated: " + String.valueOf(Integer.parseInt(line.substring(line.indexOf("=")+1).replace(" ",""))));
} else if(line.contains("|INFO|data formatting errors =")){
	System.out.println("gpload_data_errors: " +  String.valueOf(Integer.parseInt(line.substring(line.indexOf("=")+1).replace(" ",""))));
} else if(line.contains("|INFO|gpload ") && !line.contains("session")){
	System.out.println("gpload_status: " + line.substring(line.indexOf("gpload ")+7).replace(" ",""));
} else if(line.contains("|INFO|running time:")){
	line = line.substring(line.indexOf("time: ")+5).replace(" ","");
	System.out.println("gpload_runtime: " + line.substring(0,line.indexOf("seconds")));
} else if(line.contains("|ERROR|")){
	System.out.println("ERROR_ZZZ");
	line = line.substring(line.indexOf("|ERROR|")+7);
	if(line.length()>1250) {
		String tmp = line.substring(0, 1000);
		tmp += ".....";
		tmp += line.substring(line.length()-200);
		line = tmp;
	}
	globalMap.put("tJavaRow_2_ERROR_MESSAGE", "GPload error");
	;
}


    nb_line_tJavaRow_2++;   

 


	tos_count_tJavaRow_2++;

/**
 * [tJavaRow_2 main ] stop
 */



	
	/**
	 * [tFileInputFullRow_2 end ] start
	 */

	

	
	
	currentComponent="tFileInputFullRow_2";

	

	


            }
           	}finally{
           		if(fid_tFileInputFullRow_2!=null){
            		fid_tFileInputFullRow_2.close();
            	}
            }
            globalMap.put("tFileInputFullRow_2_NB_LINE", fid_tFileInputFullRow_2.getRowNumber());
				log.debug("tFileInputFullRow_2 - Retrieved records count: "+ globalMap.get("tFileInputFullRow_2_NB_LINE") + " .");
			
 
                if(log.isDebugEnabled())
            log.debug("tFileInputFullRow_2 - "  + ("Done.") );

ok_Hash.put("tFileInputFullRow_2", true);
end_Hash.put("tFileInputFullRow_2", System.currentTimeMillis());




/**
 * [tFileInputFullRow_2 end ] stop
 */

	
	/**
	 * [tJavaRow_2 end ] start
	 */

	

	
	
	currentComponent="tJavaRow_2";

	

globalMap.put("tJavaRow_2_NB_LINE",nb_line_tJavaRow_2);
			if(execStat){
				if(resourceMap.get("inIterateVComp") == null || !((Boolean)resourceMap.get("inIterateVComp"))){
			 		runStat.updateStatOnConnection("row9"+iterateId,2, 0); 
			 	}
			}
		
 

ok_Hash.put("tJavaRow_2", true);
end_Hash.put("tJavaRow_2", System.currentTimeMillis());

   			if (((String)globalMap.get("tJavaRow_2_ERROR_MESSAGE")) == null) {
   				
					if(execStat){   
   	 					runStat.updateStatOnConnection("If8", 0, "true");
					}
				
    			tAS400Input_3Process(globalMap);
   			}

			   
   				else{
					if(execStat){   
   	 					runStat.updateStatOnConnection("If8", 0, "false");
					}   	 
   				}
   			if (((String)globalMap.get("tJavaRow_2_ERROR_MESSAGE")) != null
) {
   				
					if(execStat){   
   	 					runStat.updateStatOnConnection("If7", 0, "true");
					}
				
    			tWarn_1Process(globalMap);
   			}

			   
   				else{
					if(execStat){   
   	 					runStat.updateStatOnConnection("If7", 0, "false");
					}   	 
   				}



/**
 * [tJavaRow_2 end ] stop
 */



				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage());
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tFileInputFullRow_2 finally ] start
	 */

	

	
	
	currentComponent="tFileInputFullRow_2";

	

 



/**
 * [tFileInputFullRow_2 finally ] stop
 */

	
	/**
	 * [tJavaRow_2 finally ] start
	 */

	

	
	
	currentComponent="tJavaRow_2";

	

 



/**
 * [tJavaRow_2 finally ] stop
 */



				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tFileInputFullRow_2_SUBPROCESS_STATE", 1);
	}
	


public static class row8Struct implements routines.system.IPersistableRow<row8Struct> {
    final static byte[] commonByteArrayLock_AWS_DEV_TALEND_INGESTION_FRAMEWORK_AS400_to_greenplum_with_GPLoad = new byte[0];
    static byte[] commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_AS400_to_greenplum_with_GPLoad = new byte[0];

	
			    public Integer cnt;

				public Integer getCnt () {
					return this.cnt;
				}
				


	private Integer readInteger(ObjectInputStream dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}

	private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException{
		if(intNum == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeInt(intNum);
    	}
	}

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_AWS_DEV_TALEND_INGESTION_FRAMEWORK_AS400_to_greenplum_with_GPLoad) {

        	try {

        		int length = 0;
		
						this.cnt = readInteger(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// Integer
				
						writeInteger(this.cnt,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("cnt="+String.valueOf(cnt));
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				if(cnt == null){
        					sb.append("<null>");
        				}else{
            				sb.append(cnt);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(row8Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}
public void tAS400Input_3Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tAS400Input_3_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;



		row8Struct row8 = new row8Struct();




	
	/**
	 * [tJavaRow_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tJavaRow_1", false);
		start_Hash.put("tJavaRow_1", System.currentTimeMillis());
		
	
	currentComponent="tJavaRow_1";

	
			if (execStat) {
				if(resourceMap.get("inIterateVComp") == null){
					
						runStat.updateStatOnConnection("row8" + iterateId, 0, 0);
					
				}
			} 

		
		int tos_count_tJavaRow_1 = 0;
		
    	class BytesLimit65535_tJavaRow_1{
    		public void limitLog4jByte() throws Exception{
    			
    		}
    	}
    	
        new BytesLimit65535_tJavaRow_1().limitLog4jByte();

int nb_line_tJavaRow_1 = 0;

 



/**
 * [tJavaRow_1 begin ] stop
 */



	
	/**
	 * [tAS400Input_3 begin ] start
	 */

	

	
		
		ok_Hash.put("tAS400Input_3", false);
		start_Hash.put("tAS400Input_3", System.currentTimeMillis());
		
	
	currentComponent="tAS400Input_3";

	
		int tos_count_tAS400Input_3 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tAS400Input_3 - "  + ("Start to work.") );
    	class BytesLimit65535_tAS400Input_3{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tAS400Input_3 = new StringBuilder();
            log4jParamters_tAS400Input_3.append("Parameters:");
                    log4jParamters_tAS400Input_3.append("USE_EXISTING_CONNECTION" + " = " + "true");
                log4jParamters_tAS400Input_3.append(" | ");
                    log4jParamters_tAS400Input_3.append("CONNECTION" + " = " + "tAS400Connection_1");
                log4jParamters_tAS400Input_3.append(" | ");
                    log4jParamters_tAS400Input_3.append("TABLE" + " = " + "\"\"");
                log4jParamters_tAS400Input_3.append(" | ");
                    log4jParamters_tAS400Input_3.append("QUERYSTORE" + " = " + "\"\"");
                log4jParamters_tAS400Input_3.append(" | ");
                    log4jParamters_tAS400Input_3.append("QUERY" + " = " + "\" select count(*) as cnt\" +  \" from \" +   ((String)globalMap.get(\"row1.source_schema\")) + \".\" + ((String)globalMap.get(\"row1.source_table_name\"))  ");
                log4jParamters_tAS400Input_3.append(" | ");
                    log4jParamters_tAS400Input_3.append("TRIM_ALL_COLUMN" + " = " + "false");
                log4jParamters_tAS400Input_3.append(" | ");
                    log4jParamters_tAS400Input_3.append("TRIM_COLUMN" + " = " + "[{TRIM="+("false")+", SCHEMA_COLUMN="+("cnt")+"}]");
                log4jParamters_tAS400Input_3.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tAS400Input_3 - "  + (log4jParamters_tAS400Input_3) );
    		}
    	}
    	
        new BytesLimit65535_tAS400Input_3().limitLog4jByte();
	
    
	
		    int nb_line_tAS400Input_3 = 0;
		    java.sql.Connection conn_tAS400Input_3 = null;
		        conn_tAS400Input_3 = (java.sql.Connection)globalMap.get("conn_tAS400Connection_1");
				
				if(conn_tAS400Input_3 != null) {
					if(conn_tAS400Input_3.getMetaData() != null) {
						
						log.debug("tAS400Input_3 - Uses an existing connection with username '" + conn_tAS400Input_3.getMetaData().getUserName() + "'. Connection URL: " + conn_tAS400Input_3.getMetaData().getURL() + ".");
						
					}
				}
			
		    
			java.sql.Statement stmt_tAS400Input_3 = conn_tAS400Input_3.createStatement();

		    String dbquery_tAS400Input_3 = " select count(*) as cnt" +
" from " + 
((String)globalMap.get("row1.source_schema")) + "." + ((String)globalMap.get("row1.source_table_name"))  ;
			
                log.debug("tAS400Input_3 - Executing the query: '"+dbquery_tAS400Input_3+"'.");
			

                       globalMap.put("tAS400Input_3_QUERY",dbquery_tAS400Input_3);

		    java.sql.ResultSet rs_tAS400Input_3 = null;
		try{
		    rs_tAS400Input_3 = stmt_tAS400Input_3.executeQuery(dbquery_tAS400Input_3);
		    java.sql.ResultSetMetaData rsmd_tAS400Input_3 = rs_tAS400Input_3.getMetaData();
		    int colQtyInRs_tAS400Input_3 = rsmd_tAS400Input_3.getColumnCount();

		    String tmpContent_tAS400Input_3 = null;
		    
		    
		    	log.debug("tAS400Input_3 - Retrieving records from the database.");
		    
		    while (rs_tAS400Input_3.next()) {
		        nb_line_tAS400Input_3++;
		        
							if(colQtyInRs_tAS400Input_3 < 1) {
								row8.cnt = null;
							} else {
		                          
            if(rs_tAS400Input_3.getObject(1) != null) {
                row8.cnt = rs_tAS400Input_3.getInt(1);
            } else {
                    row8.cnt = null;
            }
		                    }
					
						log.debug("tAS400Input_3 - Retrieving the record " + nb_line_tAS400Input_3 + ".");
					



 



/**
 * [tAS400Input_3 begin ] stop
 */
	
	/**
	 * [tAS400Input_3 main ] start
	 */

	

	
	
	currentComponent="tAS400Input_3";

	

 


	tos_count_tAS400Input_3++;

/**
 * [tAS400Input_3 main ] stop
 */

	
	/**
	 * [tJavaRow_1 main ] start
	 */

	

	
	
	currentComponent="tJavaRow_1";

	

			//row8
			//row8


			
				if(execStat){
					runStat.updateStatOnConnection("row8"+iterateId,1, 1);
				} 
			

		
    			if(log.isTraceEnabled()){
    				log.trace("row8 - " + (row8==null? "": row8.toLogString()));
    			}
    		

    System.out.println("count(*): " + row8.cnt);
globalMap.put("cnt", row8.cnt);
    nb_line_tJavaRow_1++;   

 


	tos_count_tJavaRow_1++;

/**
 * [tJavaRow_1 main ] stop
 */



	
	/**
	 * [tAS400Input_3 end ] start
	 */

	

	
	
	currentComponent="tAS400Input_3";

	

	}
}finally{
	stmt_tAS400Input_3.close();

}
globalMap.put("tAS400Input_3_NB_LINE",nb_line_tAS400Input_3);
	    		log.debug("tAS400Input_3 - Retrieved records count: "+nb_line_tAS400Input_3 + " .");
			

 
                if(log.isDebugEnabled())
            log.debug("tAS400Input_3 - "  + ("Done.") );

ok_Hash.put("tAS400Input_3", true);
end_Hash.put("tAS400Input_3", System.currentTimeMillis());

				if(execStat){   
   	 				runStat.updateStatOnConnection("OnComponentOk8", 0, "ok");
				}
				tAS400Close_1Process(globalMap);



/**
 * [tAS400Input_3 end ] stop
 */

	
	/**
	 * [tJavaRow_1 end ] start
	 */

	

	
	
	currentComponent="tJavaRow_1";

	

globalMap.put("tJavaRow_1_NB_LINE",nb_line_tJavaRow_1);
			if(execStat){
				if(resourceMap.get("inIterateVComp") == null || !((Boolean)resourceMap.get("inIterateVComp"))){
			 		runStat.updateStatOnConnection("row8"+iterateId,2, 0); 
			 	}
			}
		
 

ok_Hash.put("tJavaRow_1", true);
end_Hash.put("tJavaRow_1", System.currentTimeMillis());

				if(execStat){   
   	 				runStat.updateStatOnConnection("OnComponentOk5", 0, "ok");
				}
				tJava_2Process(globalMap);



/**
 * [tJavaRow_1 end ] stop
 */



				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage());
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tAS400Input_3 finally ] start
	 */

	

	
	
	currentComponent="tAS400Input_3";

	

 



/**
 * [tAS400Input_3 finally ] stop
 */

	
	/**
	 * [tJavaRow_1 finally ] start
	 */

	

	
	
	currentComponent="tJavaRow_1";

	

 



/**
 * [tJavaRow_1 finally ] stop
 */



				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tAS400Input_3_SUBPROCESS_STATE", 1);
	}
	

public void tJava_2Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tJava_2_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tJava_2 begin ] start
	 */

	

	
		
		ok_Hash.put("tJava_2", false);
		start_Hash.put("tJava_2", System.currentTimeMillis());
		
	
	currentComponent="tJava_2";

	
		int tos_count_tJava_2 = 0;
		
    	class BytesLimit65535_tJava_2{
    		public void limitLog4jByte() throws Exception{
    			
    		}
    	}
    	
        new BytesLimit65535_tJava_2().limitLog4jByte();



 



/**
 * [tJava_2 begin ] stop
 */
	
	/**
	 * [tJava_2 main ] start
	 */

	

	
	
	currentComponent="tJava_2";

	

 


	tos_count_tJava_2++;

/**
 * [tJava_2 main ] stop
 */
	
	/**
	 * [tJava_2 end ] start
	 */

	

	
	
	currentComponent="tJava_2";

	

 

ok_Hash.put("tJava_2", true);
end_Hash.put("tJava_2", System.currentTimeMillis());

   			if (((String)globalMap.get("row1.update_type")).equals("incremental")) {
   				
					if(execStat){   
   	 					runStat.updateStatOnConnection("If3", 0, "true");
					}
				
    			tGreenplumRow_1Process(globalMap);
   			}

			   
   				else{
					if(execStat){   
   	 					runStat.updateStatOnConnection("If3", 0, "false");
					}   	 
   				}
   			if (((String)globalMap.get("row1.update_type")).equals("full")) {
   				
					if(execStat){   
   	 					runStat.updateStatOnConnection("If4", 0, "true");
					}
				
    			tGreenplumRow_2Process(globalMap);
   			}

			   
   				else{
					if(execStat){   
   	 					runStat.updateStatOnConnection("If4", 0, "false");
					}   	 
   				}



/**
 * [tJava_2 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage());
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tJava_2 finally ] start
	 */

	

	
	
	currentComponent="tJava_2";

	

 



/**
 * [tJava_2 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tJava_2_SUBPROCESS_STATE", 1);
	}
	

public void tGreenplumRow_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tGreenplumRow_1_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tGreenplumRow_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tGreenplumRow_1", false);
		start_Hash.put("tGreenplumRow_1", System.currentTimeMillis());
		
	
	currentComponent="tGreenplumRow_1";

	
		int tos_count_tGreenplumRow_1 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tGreenplumRow_1 - "  + ("Start to work.") );
    	class BytesLimit65535_tGreenplumRow_1{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tGreenplumRow_1 = new StringBuilder();
            log4jParamters_tGreenplumRow_1.append("Parameters:");
                    log4jParamters_tGreenplumRow_1.append("USE_EXISTING_CONNECTION" + " = " + "true");
                log4jParamters_tGreenplumRow_1.append(" | ");
                    log4jParamters_tGreenplumRow_1.append("CONNECTION" + " = " + "tGreenplumConnection_2");
                log4jParamters_tGreenplumRow_1.append(" | ");
                    log4jParamters_tGreenplumRow_1.append("QUERYSTORE" + " = " + "\"\"");
                log4jParamters_tGreenplumRow_1.append(" | ");
                    log4jParamters_tGreenplumRow_1.append("QUERY" + " = " + "\"select sbdt.increments_rolling('\" +   globalMap.get(\"row1.target_schema_orig\") +   \"', '\" +  globalMap.get(\"row1.log_table_name\") + \"', \" +   \"to_timestamp('\" +   new SimpleDateFormat(\"yyyy-MM-dd HH:mm:ss\").format(((java.util.Date)globalMap.get(\"row1.now\"))).toString() +   \"', 'YYYY-MM-DD HH24:MI:SS')::timestamp without time zone,\" +  ((BigDecimal)globalMap.get(\"row3.row_id\")) + \");\" +    \" select sbdt.db_size('\" + globalMap.get(\"row1.target_schema_orig\") +   \"', '\" +  globalMap.get(\"row1.log_table_name\") + \"');\"+    \"update sbdt.ingestion_log set source_row_count=\" +  ((Integer)globalMap.get(\"cnt\")) +   \", target_row_count=(select count(*) from \" +globalMap.get(\"row1.target_schema_orig\") +   \".\" +  globalMap.get(\"row1.log_table_name\")+  \") where row_id = \" + ((BigDecimal)globalMap.get(\"row3.row_id\")) + \";\"");
                log4jParamters_tGreenplumRow_1.append(" | ");
                    log4jParamters_tGreenplumRow_1.append("DIE_ON_ERROR" + " = " + "true");
                log4jParamters_tGreenplumRow_1.append(" | ");
                    log4jParamters_tGreenplumRow_1.append("PROPAGATE_RECORD_SET" + " = " + "false");
                log4jParamters_tGreenplumRow_1.append(" | ");
                    log4jParamters_tGreenplumRow_1.append("USE_PREPAREDSTATEMENT" + " = " + "false");
                log4jParamters_tGreenplumRow_1.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tGreenplumRow_1 - "  + (log4jParamters_tGreenplumRow_1) );
    		}
    	}
    	
        new BytesLimit65535_tGreenplumRow_1().limitLog4jByte();

	java.sql.Connection conn_tGreenplumRow_1 = null;
	String query_tGreenplumRow_1 = "";
	boolean whetherReject_tGreenplumRow_1 = false;
				conn_tGreenplumRow_1 = (java.sql.Connection)globalMap.get("conn_tGreenplumConnection_2");
			
				if(conn_tGreenplumRow_1 != null) {
					if(conn_tGreenplumRow_1.getMetaData() != null) {
						
						log.debug("tGreenplumRow_1 - Uses an existing connection with username '" + conn_tGreenplumRow_1.getMetaData().getUserName() + "'. Connection URL: " + conn_tGreenplumRow_1.getMetaData().getURL() + ".");
						
					}
				}
			
		java.sql.Statement stmt_tGreenplumRow_1 = conn_tGreenplumRow_1.createStatement();
	

 



/**
 * [tGreenplumRow_1 begin ] stop
 */
	
	/**
	 * [tGreenplumRow_1 main ] start
	 */

	

	
	
	currentComponent="tGreenplumRow_1";

	

	    		log.debug("tGreenplumRow_1 - Executing the query: '" + "select sbdt.increments_rolling('" +   globalMap.get("row1.target_schema_orig") +   "', '" +  globalMap.get("row1.log_table_name") + "', " +   "to_timestamp('" +   new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(((java.util.Date)globalMap.get("row1.now"))).toString() +   "', 'YYYY-MM-DD HH24:MI:SS')::timestamp without time zone," +  ((BigDecimal)globalMap.get("row3.row_id")) + ");" +    " select sbdt.db_size('" + globalMap.get("row1.target_schema_orig") +   "', '" +  globalMap.get("row1.log_table_name") + "');"+    "update sbdt.ingestion_log set source_row_count=" +  ((Integer)globalMap.get("cnt")) +   ", target_row_count=(select count(*) from " +globalMap.get("row1.target_schema_orig") +   "." +  globalMap.get("row1.log_table_name")+  ") where row_id = " + ((BigDecimal)globalMap.get("row3.row_id")) + ";" + "'.");
			
query_tGreenplumRow_1 = "select sbdt.increments_rolling('" + 
globalMap.get("row1.target_schema_orig") + 
"', '" +
globalMap.get("row1.log_table_name") + "', " + 
"to_timestamp('" + 
new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(((java.util.Date)globalMap.get("row1.now"))).toString() + 
"', 'YYYY-MM-DD HH24:MI:SS')::timestamp without time zone," +
((BigDecimal)globalMap.get("row3.row_id")) + ");" +

" select sbdt.db_size('" + globalMap.get("row1.target_schema_orig") + 
"', '" +
globalMap.get("row1.log_table_name") + "');"+

"update sbdt.ingestion_log set source_row_count=" +
((Integer)globalMap.get("cnt")) + 
", target_row_count=(select count(*) from " +globalMap.get("row1.target_schema_orig") + 
"." +
globalMap.get("row1.log_table_name")+
") where row_id = " + ((BigDecimal)globalMap.get("row3.row_id")) + ";";
whetherReject_tGreenplumRow_1 = false;
globalMap.put("tGreenplumRow_1_QUERY",query_tGreenplumRow_1);
try {
		stmt_tGreenplumRow_1.execute(query_tGreenplumRow_1);
		
	    		log.info("tGreenplumRow_1 - Execute the query: '" + "select sbdt.increments_rolling('" + 
globalMap.get("row1.target_schema_orig") + 
"', '" +
globalMap.get("row1.log_table_name") + "', " + 
"to_timestamp('" + 
new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(((java.util.Date)globalMap.get("row1.now"))).toString() + 
"', 'YYYY-MM-DD HH24:MI:SS')::timestamp without time zone," +
((BigDecimal)globalMap.get("row3.row_id")) + ");" +

" select sbdt.db_size('" + globalMap.get("row1.target_schema_orig") + 
"', '" +
globalMap.get("row1.log_table_name") + "');"+

"update sbdt.ingestion_log set source_row_count=" +
((Integer)globalMap.get("cnt")) + 
", target_row_count=(select count(*) from " +globalMap.get("row1.target_schema_orig") + 
"." +
globalMap.get("row1.log_table_name")+
") where row_id = " + ((BigDecimal)globalMap.get("row3.row_id")) + ";" + "' has finished.");
			
	} catch (java.lang.Exception e) {
		whetherReject_tGreenplumRow_1 = true;
		
			throw(e);
			
	}
	
	if(!whetherReject_tGreenplumRow_1) {
		
	}
	

 


	tos_count_tGreenplumRow_1++;

/**
 * [tGreenplumRow_1 main ] stop
 */
	
	/**
	 * [tGreenplumRow_1 end ] start
	 */

	

	
	
	currentComponent="tGreenplumRow_1";

	

	
	stmt_tGreenplumRow_1.close();	

 
                if(log.isDebugEnabled())
            log.debug("tGreenplumRow_1 - "  + ("Done.") );

ok_Hash.put("tGreenplumRow_1", true);
end_Hash.put("tGreenplumRow_1", System.currentTimeMillis());




/**
 * [tGreenplumRow_1 end ] stop
 */
				}//end the resume

				
				    			if(resumeEntryMethodName == null || globalResumeTicket){
				    				resumeUtil.addLog("CHECKPOINT", "CONNECTION:SUBJOB_OK:tGreenplumRow_1:OnSubjobOk", "", Thread.currentThread().getId() + "", "", "", "", "", "");
								}	    				    			
					    	
								if(execStat){    	
									runStat.updateStatOnConnection("OnSubjobOk21", 0, "ok");
								} 
							
							tJava_3Process(globalMap); 
						



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage());
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tGreenplumRow_1 finally ] start
	 */

	

	
	
	currentComponent="tGreenplumRow_1";

	

 



/**
 * [tGreenplumRow_1 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tGreenplumRow_1_SUBPROCESS_STATE", 1);
	}
	

public void tJava_3Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tJava_3_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;





	
	/**
	 * [tJava_3 begin ] start
	 */

	

	
		
		ok_Hash.put("tJava_3", false);
		start_Hash.put("tJava_3", System.currentTimeMillis());
		
	
	currentComponent="tJava_3";

	
		int tos_count_tJava_3 = 0;
		
    	class BytesLimit65535_tJava_3{
    		public void limitLog4jByte() throws Exception{
    			
    		}
    	}
    	
        new BytesLimit65535_tJava_3().limitLog4jByte();


System.out.println(
((String)globalMap.get("tGreenplumRow_1_QUERY"))
);

System.out.println(
((String)globalMap.get("tGreenplumRow_1_ERROR_MESSAGE"))
);

 



/**
 * [tJava_3 begin ] stop
 */
	
	/**
	 * [tJava_3 main ] start
	 */

	

	
	
	currentComponent="tJava_3";

	

 


	tos_count_tJava_3++;

/**
 * [tJava_3 main ] stop
 */
	
	/**
	 * [tJava_3 end ] start
	 */

	

	
	
	currentComponent="tJava_3";

	

 

ok_Hash.put("tJava_3", true);
end_Hash.put("tJava_3", System.currentTimeMillis());




/**
 * [tJava_3 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage());
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tJava_3 finally ] start
	 */

	

	
	
	currentComponent="tJava_3";

	

 



/**
 * [tJava_3 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tJava_3_SUBPROCESS_STATE", 1);
	}
	

public void tGreenplumRow_2Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tGreenplumRow_2_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;





	
	/**
	 * [tGreenplumRow_2 begin ] start
	 */

	

	
		
		ok_Hash.put("tGreenplumRow_2", false);
		start_Hash.put("tGreenplumRow_2", System.currentTimeMillis());
		
	
	currentComponent="tGreenplumRow_2";

	
		int tos_count_tGreenplumRow_2 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tGreenplumRow_2 - "  + ("Start to work.") );
    	class BytesLimit65535_tGreenplumRow_2{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tGreenplumRow_2 = new StringBuilder();
            log4jParamters_tGreenplumRow_2.append("Parameters:");
                    log4jParamters_tGreenplumRow_2.append("USE_EXISTING_CONNECTION" + " = " + "true");
                log4jParamters_tGreenplumRow_2.append(" | ");
                    log4jParamters_tGreenplumRow_2.append("CONNECTION" + " = " + "tGreenplumConnection_2");
                log4jParamters_tGreenplumRow_2.append(" | ");
                    log4jParamters_tGreenplumRow_2.append("QUERYSTORE" + " = " + "\"\"");
                log4jParamters_tGreenplumRow_2.append(" | ");
                    log4jParamters_tGreenplumRow_2.append("QUERY" + " = " + "\"update sbdt.ingestion_log set status='FINISHED', end_time=to_timestamp('\" +   new SimpleDateFormat(\"yyyy-MM-dd HH:mm:ss\").format(TalendDate.getCurrentDate()).toString() +  \"', 'YYYY-MM-DD HH24:MI:SS')::timestamp without time zone, log_time=to_timestamp('\" +   new SimpleDateFormat(\"yyyy-MM-dd HH:mm:ss\").format(TalendDate.getCurrentDate()).toString() +  \"', 'YYYY-MM-DD HH24:MI:SS')::timestamp without time zone, no_of_records=\" +  ((Integer)globalMap.get(\"cnt\")) +   \", no_of_inserts=\" +  ((Integer)globalMap.get(\"cnt\")) +   \", source_row_count=\" +  ((Integer)globalMap.get(\"cnt\")) +   \", target_row_count=(select count(*) from \" +globalMap.get(\"row1.target_schema_orig\") +   \".\" +  globalMap.get(\"row1.log_table_name\") +  \")  where row_id = \" + ((BigDecimal)globalMap.get(\"row3.row_id\")) + \";\" +      \" update sbdt.tables set last_update_date = to_timestamp('\" +  new SimpleDateFormat(\"yyyy-MM-dd HH:mm:ss\").format(((java.util.Date)globalMap.get(\"row1.now\"))).toString() +   \"', 'YYYY-MM-DD HH24:MI:SS')::timestamp without time zone \" +  \", previous_last_update_date=\" +  \"case when update_type='incremental' then to_timestamp(\" +   ((globalMap.get(\"row1.last_update_date\")==null) ? \"null\" : (\"'\" + String.valueOf(new SimpleDateFormat(\"yyyy-MM-dd HH:mm:ss\").format(((java.util.Date)globalMap.get(\"row1.last_update_date\")))) + \"'\")) +  \", 'YYYY-MM-DD HH24:MI:SS')::timestamp without time zone else null end \" +   \" where source_name='\" + ((String)globalMap.get(\"row1.source_name\")) + \"' and \" +  \" target_table_name='\" + ((String)globalMap.get(\"row1.log_table_name\")) + \"';\" +    \" select sbdt.dataprofile_table_fast('\" + ((String)globalMap.get(\"row1.target_schema_orig\")) + \"', '\" +  ((String)globalMap.get(\"row1.target_table_name\")) + \"', false);\" +    \" select sbdt.db_size('\" + globalMap.get(\"row1.target_schema_orig\") +   \"', '\" +  globalMap.get(\"row1.log_table_name\") + \"');\"");
                log4jParamters_tGreenplumRow_2.append(" | ");
                    log4jParamters_tGreenplumRow_2.append("DIE_ON_ERROR" + " = " + "true");
                log4jParamters_tGreenplumRow_2.append(" | ");
                    log4jParamters_tGreenplumRow_2.append("PROPAGATE_RECORD_SET" + " = " + "false");
                log4jParamters_tGreenplumRow_2.append(" | ");
                    log4jParamters_tGreenplumRow_2.append("USE_PREPAREDSTATEMENT" + " = " + "false");
                log4jParamters_tGreenplumRow_2.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tGreenplumRow_2 - "  + (log4jParamters_tGreenplumRow_2) );
    		}
    	}
    	
        new BytesLimit65535_tGreenplumRow_2().limitLog4jByte();

	java.sql.Connection conn_tGreenplumRow_2 = null;
	String query_tGreenplumRow_2 = "";
	boolean whetherReject_tGreenplumRow_2 = false;
				conn_tGreenplumRow_2 = (java.sql.Connection)globalMap.get("conn_tGreenplumConnection_2");
			
				if(conn_tGreenplumRow_2 != null) {
					if(conn_tGreenplumRow_2.getMetaData() != null) {
						
						log.debug("tGreenplumRow_2 - Uses an existing connection with username '" + conn_tGreenplumRow_2.getMetaData().getUserName() + "'. Connection URL: " + conn_tGreenplumRow_2.getMetaData().getURL() + ".");
						
					}
				}
			
		java.sql.Statement stmt_tGreenplumRow_2 = conn_tGreenplumRow_2.createStatement();
	

 



/**
 * [tGreenplumRow_2 begin ] stop
 */
	
	/**
	 * [tGreenplumRow_2 main ] start
	 */

	

	
	
	currentComponent="tGreenplumRow_2";

	

	    		log.debug("tGreenplumRow_2 - Executing the query: '" + "update sbdt.ingestion_log set status='FINISHED', end_time=to_timestamp('" +   new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(TalendDate.getCurrentDate()).toString() +  "', 'YYYY-MM-DD HH24:MI:SS')::timestamp without time zone, log_time=to_timestamp('" +   new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(TalendDate.getCurrentDate()).toString() +  "', 'YYYY-MM-DD HH24:MI:SS')::timestamp without time zone, no_of_records=" +  ((Integer)globalMap.get("cnt")) +   ", no_of_inserts=" +  ((Integer)globalMap.get("cnt")) +   ", source_row_count=" +  ((Integer)globalMap.get("cnt")) +   ", target_row_count=(select count(*) from " +globalMap.get("row1.target_schema_orig") +   "." +  globalMap.get("row1.log_table_name") +  ")  where row_id = " + ((BigDecimal)globalMap.get("row3.row_id")) + ";" +      " update sbdt.tables set last_update_date = to_timestamp('" +  new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(((java.util.Date)globalMap.get("row1.now"))).toString() +   "', 'YYYY-MM-DD HH24:MI:SS')::timestamp without time zone " +  ", previous_last_update_date=" +  "case when update_type='incremental' then to_timestamp(" +   ((globalMap.get("row1.last_update_date")==null) ? "null" : ("'" + String.valueOf(new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(((java.util.Date)globalMap.get("row1.last_update_date")))) + "'")) +  ", 'YYYY-MM-DD HH24:MI:SS')::timestamp without time zone else null end " +   " where source_name='" + ((String)globalMap.get("row1.source_name")) + "' and " +  " target_table_name='" + ((String)globalMap.get("row1.log_table_name")) + "';" +    " select sbdt.dataprofile_table_fast('" + ((String)globalMap.get("row1.target_schema_orig")) + "', '" +  ((String)globalMap.get("row1.target_table_name")) + "', false);" +    " select sbdt.db_size('" + globalMap.get("row1.target_schema_orig") +   "', '" +  globalMap.get("row1.log_table_name") + "');" + "'.");
			
query_tGreenplumRow_2 = "update sbdt.ingestion_log set status='FINISHED', end_time=to_timestamp('" + 
new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(TalendDate.getCurrentDate()).toString() +
"', 'YYYY-MM-DD HH24:MI:SS')::timestamp without time zone, log_time=to_timestamp('" + 
new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(TalendDate.getCurrentDate()).toString() +
"', 'YYYY-MM-DD HH24:MI:SS')::timestamp without time zone, no_of_records=" +
((Integer)globalMap.get("cnt")) + 
", no_of_inserts=" +
((Integer)globalMap.get("cnt")) + 
", source_row_count=" +
((Integer)globalMap.get("cnt")) + 
", target_row_count=(select count(*) from " +globalMap.get("row1.target_schema_orig") + 
"." +
globalMap.get("row1.log_table_name") +
")  where row_id = " + ((BigDecimal)globalMap.get("row3.row_id")) + ";" +


" update sbdt.tables set last_update_date = to_timestamp('" +
new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(((java.util.Date)globalMap.get("row1.now"))).toString() + 
"', 'YYYY-MM-DD HH24:MI:SS')::timestamp without time zone " +
", previous_last_update_date=" +
"case when update_type='incremental' then to_timestamp(" + 
((globalMap.get("row1.last_update_date")==null) ? "null" : ("'" + String.valueOf(new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(((java.util.Date)globalMap.get("row1.last_update_date")))) + "'")) +
", 'YYYY-MM-DD HH24:MI:SS')::timestamp without time zone else null end " + 
" where source_name='" + ((String)globalMap.get("row1.source_name")) + "' and " +
" target_table_name='" + ((String)globalMap.get("row1.log_table_name")) + "';" +

" select sbdt.dataprofile_table_fast('" + ((String)globalMap.get("row1.target_schema_orig")) + "', '" +
((String)globalMap.get("row1.target_table_name")) + "', false);" +

" select sbdt.db_size('" + globalMap.get("row1.target_schema_orig") + 
"', '" +
globalMap.get("row1.log_table_name") + "');";
whetherReject_tGreenplumRow_2 = false;
globalMap.put("tGreenplumRow_2_QUERY",query_tGreenplumRow_2);
try {
		stmt_tGreenplumRow_2.execute(query_tGreenplumRow_2);
		
	    		log.info("tGreenplumRow_2 - Execute the query: '" + "update sbdt.ingestion_log set status='FINISHED', end_time=to_timestamp('" + 
new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(TalendDate.getCurrentDate()).toString() +
"', 'YYYY-MM-DD HH24:MI:SS')::timestamp without time zone, log_time=to_timestamp('" + 
new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(TalendDate.getCurrentDate()).toString() +
"', 'YYYY-MM-DD HH24:MI:SS')::timestamp without time zone, no_of_records=" +
((Integer)globalMap.get("cnt")) + 
", no_of_inserts=" +
((Integer)globalMap.get("cnt")) + 
", source_row_count=" +
((Integer)globalMap.get("cnt")) + 
", target_row_count=(select count(*) from " +globalMap.get("row1.target_schema_orig") + 
"." +
globalMap.get("row1.log_table_name") +
")  where row_id = " + ((BigDecimal)globalMap.get("row3.row_id")) + ";" +


" update sbdt.tables set last_update_date = to_timestamp('" +
new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(((java.util.Date)globalMap.get("row1.now"))).toString() + 
"', 'YYYY-MM-DD HH24:MI:SS')::timestamp without time zone " +
", previous_last_update_date=" +
"case when update_type='incremental' then to_timestamp(" + 
((globalMap.get("row1.last_update_date")==null) ? "null" : ("'" + String.valueOf(new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(((java.util.Date)globalMap.get("row1.last_update_date")))) + "'")) +
", 'YYYY-MM-DD HH24:MI:SS')::timestamp without time zone else null end " + 
" where source_name='" + ((String)globalMap.get("row1.source_name")) + "' and " +
" target_table_name='" + ((String)globalMap.get("row1.log_table_name")) + "';" +

" select sbdt.dataprofile_table_fast('" + ((String)globalMap.get("row1.target_schema_orig")) + "', '" +
((String)globalMap.get("row1.target_table_name")) + "', false);" +

" select sbdt.db_size('" + globalMap.get("row1.target_schema_orig") + 
"', '" +
globalMap.get("row1.log_table_name") + "');" + "' has finished.");
			
	} catch (java.lang.Exception e) {
		whetherReject_tGreenplumRow_2 = true;
		
			throw(e);
			
	}
	

 


	tos_count_tGreenplumRow_2++;

/**
 * [tGreenplumRow_2 main ] stop
 */
	
	/**
	 * [tGreenplumRow_2 end ] start
	 */

	

	
	
	currentComponent="tGreenplumRow_2";

	

	
	stmt_tGreenplumRow_2.close();	

 
                if(log.isDebugEnabled())
            log.debug("tGreenplumRow_2 - "  + ("Done.") );

ok_Hash.put("tGreenplumRow_2", true);
end_Hash.put("tGreenplumRow_2", System.currentTimeMillis());




/**
 * [tGreenplumRow_2 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage());
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tGreenplumRow_2 finally ] start
	 */

	

	
	
	currentComponent="tGreenplumRow_2";

	

 



/**
 * [tGreenplumRow_2 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tGreenplumRow_2_SUBPROCESS_STATE", 1);
	}
	

public void tAS400Close_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tAS400Close_1_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;





	
	/**
	 * [tAS400Close_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tAS400Close_1", false);
		start_Hash.put("tAS400Close_1", System.currentTimeMillis());
		
	
	currentComponent="tAS400Close_1";

	
		int tos_count_tAS400Close_1 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tAS400Close_1 - "  + ("Start to work.") );
    	class BytesLimit65535_tAS400Close_1{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tAS400Close_1 = new StringBuilder();
            log4jParamters_tAS400Close_1.append("Parameters:");
                    log4jParamters_tAS400Close_1.append("CONNECTION" + " = " + "tAS400Connection_1");
                log4jParamters_tAS400Close_1.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tAS400Close_1 - "  + (log4jParamters_tAS400Close_1) );
    		}
    	}
    	
        new BytesLimit65535_tAS400Close_1().limitLog4jByte();

 



/**
 * [tAS400Close_1 begin ] stop
 */
	
	/**
	 * [tAS400Close_1 main ] start
	 */

	

	
	
	currentComponent="tAS400Close_1";

	



	java.sql.Connection conn_tAS400Close_1 = (java.sql.Connection)globalMap.get("conn_tAS400Connection_1");
	if(conn_tAS400Close_1 != null && !conn_tAS400Close_1.isClosed())
	{
                if(log.isDebugEnabled())
            log.debug("tAS400Close_1 - "  + ("Closing the connection ")  + ("conn_tAS400Connection_1")  + (" to the database.") );
        conn_tAS400Close_1.close();
                if(log.isDebugEnabled())
            log.debug("tAS400Close_1 - "  + ("Connection ")  + ("conn_tAS400Connection_1")  + (" to the database has closed.") );
	}

 


	tos_count_tAS400Close_1++;

/**
 * [tAS400Close_1 main ] stop
 */
	
	/**
	 * [tAS400Close_1 end ] start
	 */

	

	
	
	currentComponent="tAS400Close_1";

	

 
                if(log.isDebugEnabled())
            log.debug("tAS400Close_1 - "  + ("Done.") );

ok_Hash.put("tAS400Close_1", true);
end_Hash.put("tAS400Close_1", System.currentTimeMillis());




/**
 * [tAS400Close_1 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage());
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tAS400Close_1 finally ] start
	 */

	

	
	
	currentComponent="tAS400Close_1";

	

 



/**
 * [tAS400Close_1 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tAS400Close_1_SUBPROCESS_STATE", 1);
	}
	

public void tWarn_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tWarn_1_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;





	
	/**
	 * [tWarn_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tWarn_1", false);
		start_Hash.put("tWarn_1", System.currentTimeMillis());
		
	
	currentComponent="tWarn_1";

	
		int tos_count_tWarn_1 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tWarn_1 - "  + ("Start to work.") );
    	class BytesLimit65535_tWarn_1{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tWarn_1 = new StringBuilder();
            log4jParamters_tWarn_1.append("Parameters:");
                    log4jParamters_tWarn_1.append("MESSAGE" + " = " + "\"GPload: An error has occurred. See the log file...\"");
                log4jParamters_tWarn_1.append(" | ");
                    log4jParamters_tWarn_1.append("CODE" + " = " + "666");
                log4jParamters_tWarn_1.append(" | ");
                    log4jParamters_tWarn_1.append("PRIORITY" + " = " + "6");
                log4jParamters_tWarn_1.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tWarn_1 - "  + (log4jParamters_tWarn_1) );
    		}
    	}
    	
        new BytesLimit65535_tWarn_1().limitLog4jByte();

 



/**
 * [tWarn_1 begin ] stop
 */
	
	/**
	 * [tWarn_1 main ] start
	 */

	

	
	
	currentComponent="tWarn_1";

	

		
	resumeUtil.addLog("USER_DEF_LOG", "NODE:tWarn_1", "", Thread.currentThread().getId() + "", "FATAL","","GPload: An error has occurred. See the log file...","", "");
            log.fatal("tWarn_1 - "  + ("Message: ")  + ("GPload: An error has occurred. See the log file...")  + (". Code: ")  + (666) );
                if(log.isDebugEnabled())
            log.debug("tWarn_1 - "  + ("Sending message to tLogCatcher_1.") );
	tLogCatcher_1.addMessage("tWarn", "tWarn_1", 6, "GPload: An error has occurred. See the log file...", 666);
	tLogCatcher_1Process(globalMap);
                if(log.isDebugEnabled())
            log.debug("tWarn_1 - "  + ("Sending message to talendLogs_LOGS.") );
	talendLogs_LOGS.addMessage("tWarn", "tWarn_1", 6, "GPload: An error has occurred. See the log file...", 666);
	talendLogs_LOGSProcess(globalMap);
globalMap.put("tWarn_1_WARN_MESSAGES", "GPload: An error has occurred. See the log file..."); 
globalMap.put("tWarn_1_WARN_PRIORITY", 6);
globalMap.put("tWarn_1_WARN_CODE", 666);


 


	tos_count_tWarn_1++;

/**
 * [tWarn_1 main ] stop
 */
	
	/**
	 * [tWarn_1 end ] start
	 */

	

	
	
	currentComponent="tWarn_1";

	

 
                if(log.isDebugEnabled())
            log.debug("tWarn_1 - "  + ("Done.") );

ok_Hash.put("tWarn_1", true);
end_Hash.put("tWarn_1", System.currentTimeMillis());




/**
 * [tWarn_1 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage());
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tWarn_1 finally ] start
	 */

	

	
	
	currentComponent="tWarn_1";

	

 



/**
 * [tWarn_1 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tWarn_1_SUBPROCESS_STATE", 1);
	}
	

public void tGreenplumRow_7Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tGreenplumRow_7_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tGreenplumRow_7 begin ] start
	 */

	

	
		
		ok_Hash.put("tGreenplumRow_7", false);
		start_Hash.put("tGreenplumRow_7", System.currentTimeMillis());
		
	
	currentComponent="tGreenplumRow_7";

	
		int tos_count_tGreenplumRow_7 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tGreenplumRow_7 - "  + ("Start to work.") );
    	class BytesLimit65535_tGreenplumRow_7{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tGreenplumRow_7 = new StringBuilder();
            log4jParamters_tGreenplumRow_7.append("Parameters:");
                    log4jParamters_tGreenplumRow_7.append("USE_EXISTING_CONNECTION" + " = " + "true");
                log4jParamters_tGreenplumRow_7.append(" | ");
                    log4jParamters_tGreenplumRow_7.append("CONNECTION" + " = " + "tGreenplumConnection_2");
                log4jParamters_tGreenplumRow_7.append(" | ");
                    log4jParamters_tGreenplumRow_7.append("QUERYSTORE" + " = " + "\"\"");
                log4jParamters_tGreenplumRow_7.append(" | ");
                    log4jParamters_tGreenplumRow_7.append("QUERY" + " = " + "\"truncate table \" + (String)globalMap.get(\"row1.target_schema\") + \".\" + (String)globalMap.get(\"row1.target_table_name\")");
                log4jParamters_tGreenplumRow_7.append(" | ");
                    log4jParamters_tGreenplumRow_7.append("DIE_ON_ERROR" + " = " + "true");
                log4jParamters_tGreenplumRow_7.append(" | ");
                    log4jParamters_tGreenplumRow_7.append("PROPAGATE_RECORD_SET" + " = " + "false");
                log4jParamters_tGreenplumRow_7.append(" | ");
                    log4jParamters_tGreenplumRow_7.append("USE_PREPAREDSTATEMENT" + " = " + "false");
                log4jParamters_tGreenplumRow_7.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tGreenplumRow_7 - "  + (log4jParamters_tGreenplumRow_7) );
    		}
    	}
    	
        new BytesLimit65535_tGreenplumRow_7().limitLog4jByte();

	java.sql.Connection conn_tGreenplumRow_7 = null;
	String query_tGreenplumRow_7 = "";
	boolean whetherReject_tGreenplumRow_7 = false;
				conn_tGreenplumRow_7 = (java.sql.Connection)globalMap.get("conn_tGreenplumConnection_2");
			
				if(conn_tGreenplumRow_7 != null) {
					if(conn_tGreenplumRow_7.getMetaData() != null) {
						
						log.debug("tGreenplumRow_7 - Uses an existing connection with username '" + conn_tGreenplumRow_7.getMetaData().getUserName() + "'. Connection URL: " + conn_tGreenplumRow_7.getMetaData().getURL() + ".");
						
					}
				}
			
		java.sql.Statement stmt_tGreenplumRow_7 = conn_tGreenplumRow_7.createStatement();
	

 



/**
 * [tGreenplumRow_7 begin ] stop
 */
	
	/**
	 * [tGreenplumRow_7 main ] start
	 */

	

	
	
	currentComponent="tGreenplumRow_7";

	

	    		log.debug("tGreenplumRow_7 - Executing the query: '" + "truncate table " + (String)globalMap.get("row1.target_schema") + "." + (String)globalMap.get("row1.target_table_name") + "'.");
			
query_tGreenplumRow_7 = "truncate table " + (String)globalMap.get("row1.target_schema") + "." + (String)globalMap.get("row1.target_table_name");
whetherReject_tGreenplumRow_7 = false;
globalMap.put("tGreenplumRow_7_QUERY",query_tGreenplumRow_7);
try {
		stmt_tGreenplumRow_7.execute(query_tGreenplumRow_7);
		
	    		log.info("tGreenplumRow_7 - Execute the query: '" + "truncate table " + (String)globalMap.get("row1.target_schema") + "." + (String)globalMap.get("row1.target_table_name") + "' has finished.");
			
	} catch (java.lang.Exception e) {
		whetherReject_tGreenplumRow_7 = true;
		
			throw(e);
			
	}
	
	if(!whetherReject_tGreenplumRow_7) {
		
	}
	

 


	tos_count_tGreenplumRow_7++;

/**
 * [tGreenplumRow_7 main ] stop
 */
	
	/**
	 * [tGreenplumRow_7 end ] start
	 */

	

	
	
	currentComponent="tGreenplumRow_7";

	

	
	stmt_tGreenplumRow_7.close();	

 
                if(log.isDebugEnabled())
            log.debug("tGreenplumRow_7 - "  + ("Done.") );

ok_Hash.put("tGreenplumRow_7", true);
end_Hash.put("tGreenplumRow_7", System.currentTimeMillis());

				if(execStat){   
   	 				runStat.updateStatOnConnection("OnComponentOk4", 0, "ok");
				}
				tAS400Input_2Process(globalMap);



/**
 * [tGreenplumRow_7 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage());
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tGreenplumRow_7 finally ] start
	 */

	

	
	
	currentComponent="tGreenplumRow_7";

	

 



/**
 * [tGreenplumRow_7 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tGreenplumRow_7_SUBPROCESS_STATE", 1);
	}
	

public void tGreenplumClose_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tGreenplumClose_1_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;





	
	/**
	 * [tGreenplumClose_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tGreenplumClose_1", false);
		start_Hash.put("tGreenplumClose_1", System.currentTimeMillis());
		
	
	currentComponent="tGreenplumClose_1";

	
		int tos_count_tGreenplumClose_1 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tGreenplumClose_1 - "  + ("Start to work.") );
    	class BytesLimit65535_tGreenplumClose_1{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tGreenplumClose_1 = new StringBuilder();
            log4jParamters_tGreenplumClose_1.append("Parameters:");
                    log4jParamters_tGreenplumClose_1.append("CONNECTION" + " = " + "tGreenplumConnection_2");
                log4jParamters_tGreenplumClose_1.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tGreenplumClose_1 - "  + (log4jParamters_tGreenplumClose_1) );
    		}
    	}
    	
        new BytesLimit65535_tGreenplumClose_1().limitLog4jByte();

 



/**
 * [tGreenplumClose_1 begin ] stop
 */
	
	/**
	 * [tGreenplumClose_1 main ] start
	 */

	

	
	
	currentComponent="tGreenplumClose_1";

	



	java.sql.Connection conn_tGreenplumClose_1 = (java.sql.Connection)globalMap.get("conn_tGreenplumConnection_2");
	if(conn_tGreenplumClose_1 != null && !conn_tGreenplumClose_1.isClosed())
	{
                if(log.isDebugEnabled())
            log.debug("tGreenplumClose_1 - "  + ("Closing the connection ")  + ("conn_tGreenplumConnection_2")  + (" to the database.") );
        conn_tGreenplumClose_1.close();
                if(log.isDebugEnabled())
            log.debug("tGreenplumClose_1 - "  + ("Connection ")  + ("conn_tGreenplumConnection_2")  + (" to the database has closed.") );
	}

 


	tos_count_tGreenplumClose_1++;

/**
 * [tGreenplumClose_1 main ] stop
 */
	
	/**
	 * [tGreenplumClose_1 end ] start
	 */

	

	
	
	currentComponent="tGreenplumClose_1";

	

 
                if(log.isDebugEnabled())
            log.debug("tGreenplumClose_1 - "  + ("Done.") );

ok_Hash.put("tGreenplumClose_1", true);
end_Hash.put("tGreenplumClose_1", System.currentTimeMillis());




/**
 * [tGreenplumClose_1 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage());
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tGreenplumClose_1 finally ] start
	 */

	

	
	
	currentComponent="tGreenplumClose_1";

	

 



/**
 * [tGreenplumClose_1 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tGreenplumClose_1_SUBPROCESS_STATE", 1);
	}
	


public static class row6Struct implements routines.system.IPersistableRow<row6Struct> {
    final static byte[] commonByteArrayLock_AWS_DEV_TALEND_INGESTION_FRAMEWORK_AS400_to_greenplum_with_GPLoad = new byte[0];
    static byte[] commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_AS400_to_greenplum_with_GPLoad = new byte[0];

	
			    public java.util.Date moment;

				public java.util.Date getMoment () {
					return this.moment;
				}
				
			    public String pid;

				public String getPid () {
					return this.pid;
				}
				
			    public String root_pid;

				public String getRoot_pid () {
					return this.root_pid;
				}
				
			    public String father_pid;

				public String getFather_pid () {
					return this.father_pid;
				}
				
			    public String project;

				public String getProject () {
					return this.project;
				}
				
			    public String job;

				public String getJob () {
					return this.job;
				}
				
			    public String context;

				public String getContext () {
					return this.context;
				}
				
			    public Integer priority;

				public Integer getPriority () {
					return this.priority;
				}
				
			    public String type;

				public String getType () {
					return this.type;
				}
				
			    public String origin;

				public String getOrigin () {
					return this.origin;
				}
				
			    public String message;

				public String getMessage () {
					return this.message;
				}
				
			    public Integer code;

				public Integer getCode () {
					return this.code;
				}
				



	private java.util.Date readDate(ObjectInputStream dis) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(dis.readLong());
		}
		return dateReturn;
	}

    private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException{
		if(date1 == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeLong(date1.getTime());
    	}
    }

	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_AS400_to_greenplum_with_GPLoad.length) {
				if(length < 1024 && commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_AS400_to_greenplum_with_GPLoad.length == 0) {
   					commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_AS400_to_greenplum_with_GPLoad = new byte[1024];
				} else {
   					commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_AS400_to_greenplum_with_GPLoad = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_AS400_to_greenplum_with_GPLoad, 0, length);
			strReturn = new String(commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_AS400_to_greenplum_with_GPLoad, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
	private Integer readInteger(ObjectInputStream dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}

	private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException{
		if(intNum == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeInt(intNum);
    	}
	}

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_AWS_DEV_TALEND_INGESTION_FRAMEWORK_AS400_to_greenplum_with_GPLoad) {

        	try {

        		int length = 0;
		
					this.moment = readDate(dis);
					
					this.pid = readString(dis);
					
					this.root_pid = readString(dis);
					
					this.father_pid = readString(dis);
					
					this.project = readString(dis);
					
					this.job = readString(dis);
					
					this.context = readString(dis);
					
						this.priority = readInteger(dis);
					
					this.type = readString(dis);
					
					this.origin = readString(dis);
					
					this.message = readString(dis);
					
						this.code = readInteger(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// java.util.Date
				
						writeDate(this.moment,dos);
					
					// String
				
						writeString(this.pid,dos);
					
					// String
				
						writeString(this.root_pid,dos);
					
					// String
				
						writeString(this.father_pid,dos);
					
					// String
				
						writeString(this.project,dos);
					
					// String
				
						writeString(this.job,dos);
					
					// String
				
						writeString(this.context,dos);
					
					// Integer
				
						writeInteger(this.priority,dos);
					
					// String
				
						writeString(this.type,dos);
					
					// String
				
						writeString(this.origin,dos);
					
					// String
				
						writeString(this.message,dos);
					
					// Integer
				
						writeInteger(this.code,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("moment="+String.valueOf(moment));
		sb.append(",pid="+pid);
		sb.append(",root_pid="+root_pid);
		sb.append(",father_pid="+father_pid);
		sb.append(",project="+project);
		sb.append(",job="+job);
		sb.append(",context="+context);
		sb.append(",priority="+String.valueOf(priority));
		sb.append(",type="+type);
		sb.append(",origin="+origin);
		sb.append(",message="+message);
		sb.append(",code="+String.valueOf(code));
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				if(moment == null){
        					sb.append("<null>");
        				}else{
            				sb.append(moment);
            			}
            		
        			sb.append("|");
        		
        				if(pid == null){
        					sb.append("<null>");
        				}else{
            				sb.append(pid);
            			}
            		
        			sb.append("|");
        		
        				if(root_pid == null){
        					sb.append("<null>");
        				}else{
            				sb.append(root_pid);
            			}
            		
        			sb.append("|");
        		
        				if(father_pid == null){
        					sb.append("<null>");
        				}else{
            				sb.append(father_pid);
            			}
            		
        			sb.append("|");
        		
        				if(project == null){
        					sb.append("<null>");
        				}else{
            				sb.append(project);
            			}
            		
        			sb.append("|");
        		
        				if(job == null){
        					sb.append("<null>");
        				}else{
            				sb.append(job);
            			}
            		
        			sb.append("|");
        		
        				if(context == null){
        					sb.append("<null>");
        				}else{
            				sb.append(context);
            			}
            		
        			sb.append("|");
        		
        				if(priority == null){
        					sb.append("<null>");
        				}else{
            				sb.append(priority);
            			}
            		
        			sb.append("|");
        		
        				if(type == null){
        					sb.append("<null>");
        				}else{
            				sb.append(type);
            			}
            		
        			sb.append("|");
        		
        				if(origin == null){
        					sb.append("<null>");
        				}else{
            				sb.append(origin);
            			}
            		
        			sb.append("|");
        		
        				if(message == null){
        					sb.append("<null>");
        				}else{
            				sb.append(message);
            			}
            		
        			sb.append("|");
        		
        				if(code == null){
        					sb.append("<null>");
        				}else{
            				sb.append(code);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(row6Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}
public void tLogCatcher_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tLogCatcher_1_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;



		row6Struct row6 = new row6Struct();




	
	/**
	 * [tSetGlobalVar_3 begin ] start
	 */

	

	
		
		ok_Hash.put("tSetGlobalVar_3", false);
		start_Hash.put("tSetGlobalVar_3", System.currentTimeMillis());
		
	
	currentComponent="tSetGlobalVar_3";

	
			if (execStat) {
				if(resourceMap.get("inIterateVComp") == null){
					
						runStat.updateStatOnConnection("row6" + iterateId, 0, 0);
					
				}
			} 

		
		int tos_count_tSetGlobalVar_3 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tSetGlobalVar_3 - "  + ("Start to work.") );
    	class BytesLimit65535_tSetGlobalVar_3{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tSetGlobalVar_3 = new StringBuilder();
            log4jParamters_tSetGlobalVar_3.append("Parameters:");
                    log4jParamters_tSetGlobalVar_3.append("VARIABLES" + " = " + "[{VALUE="+("row6.job + \" - \" + row6.origin + \" - \" + row6.message")+", KEY="+("\"error_message_desc\"")+"}]");
                log4jParamters_tSetGlobalVar_3.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tSetGlobalVar_3 - "  + (log4jParamters_tSetGlobalVar_3) );
    		}
    	}
    	
        new BytesLimit65535_tSetGlobalVar_3().limitLog4jByte();

 



/**
 * [tSetGlobalVar_3 begin ] stop
 */



	
	/**
	 * [tLogCatcher_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tLogCatcher_1", false);
		start_Hash.put("tLogCatcher_1", System.currentTimeMillis());
		
	
	currentComponent="tLogCatcher_1";

	
		int tos_count_tLogCatcher_1 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tLogCatcher_1 - "  + ("Start to work.") );
    	class BytesLimit65535_tLogCatcher_1{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tLogCatcher_1 = new StringBuilder();
            log4jParamters_tLogCatcher_1.append("Parameters:");
                    log4jParamters_tLogCatcher_1.append("CATCH_JAVA_EXCEPTION" + " = " + "true");
                log4jParamters_tLogCatcher_1.append(" | ");
                    log4jParamters_tLogCatcher_1.append("CATCH_TDIE" + " = " + "true");
                log4jParamters_tLogCatcher_1.append(" | ");
                    log4jParamters_tLogCatcher_1.append("CATCH_TWARN" + " = " + "true");
                log4jParamters_tLogCatcher_1.append(" | ");
                    log4jParamters_tLogCatcher_1.append("CATCH_TACTIONFAILURE" + " = " + "true");
                log4jParamters_tLogCatcher_1.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tLogCatcher_1 - "  + (log4jParamters_tLogCatcher_1) );
    		}
    	}
    	
        new BytesLimit65535_tLogCatcher_1().limitLog4jByte();

	for (LogCatcherUtils.LogCatcherMessage lcm : tLogCatcher_1.getMessages()) {
		row6.type = lcm.getType();
		row6.origin = (lcm.getOrigin()==null || lcm.getOrigin().length()<1 ? null : lcm.getOrigin());
		row6.priority = lcm.getPriority();
		row6.message = lcm.getMessage();
		row6.code = lcm.getCode();
		
		row6.moment = java.util.Calendar.getInstance().getTime();
	
    	row6.pid = pid;
		row6.root_pid = rootPid;
		row6.father_pid = fatherPid;
	
    	row6.project = projectName;
    	row6.job = jobName;
    	row6.context = contextStr;
    		
 



/**
 * [tLogCatcher_1 begin ] stop
 */
	
	/**
	 * [tLogCatcher_1 main ] start
	 */

	

	
	
	currentComponent="tLogCatcher_1";

	

 


	tos_count_tLogCatcher_1++;

/**
 * [tLogCatcher_1 main ] stop
 */

	
	/**
	 * [tSetGlobalVar_3 main ] start
	 */

	

	
	
	currentComponent="tSetGlobalVar_3";

	

			//row6
			//row6


			
				if(execStat){
					runStat.updateStatOnConnection("row6"+iterateId,1, 1);
				} 
			

		
    			if(log.isTraceEnabled()){
    				log.trace("row6 - " + (row6==null? "": row6.toLogString()));
    			}
    		

globalMap.put("error_message_desc", row6.job + " - " + row6.origin + " - " + row6.message);

 


	tos_count_tSetGlobalVar_3++;

/**
 * [tSetGlobalVar_3 main ] stop
 */



	
	/**
	 * [tLogCatcher_1 end ] start
	 */

	

	
	
	currentComponent="tLogCatcher_1";

	
	}
 
                if(log.isDebugEnabled())
            log.debug("tLogCatcher_1 - "  + ("Done.") );

ok_Hash.put("tLogCatcher_1", true);
end_Hash.put("tLogCatcher_1", System.currentTimeMillis());




/**
 * [tLogCatcher_1 end ] stop
 */

	
	/**
	 * [tSetGlobalVar_3 end ] start
	 */

	

	
	
	currentComponent="tSetGlobalVar_3";

	

			if(execStat){
				if(resourceMap.get("inIterateVComp") == null || !((Boolean)resourceMap.get("inIterateVComp"))){
			 		runStat.updateStatOnConnection("row6"+iterateId,2, 0); 
			 	}
			}
		
 
                if(log.isDebugEnabled())
            log.debug("tSetGlobalVar_3 - "  + ("Done.") );

ok_Hash.put("tSetGlobalVar_3", true);
end_Hash.put("tSetGlobalVar_3", System.currentTimeMillis());




/**
 * [tSetGlobalVar_3 end ] stop
 */



				}//end the resume

				
				    			if(resumeEntryMethodName == null || globalResumeTicket){
				    				resumeUtil.addLog("CHECKPOINT", "CONNECTION:SUBJOB_OK:tLogCatcher_1:OnSubjobOk", "", Thread.currentThread().getId() + "", "", "", "", "", "");
								}	    				    			
					    	
								if(execStat){    	
									runStat.updateStatOnConnection("OnSubjobOk26", 0, "ok");
								} 
							
							tGreenplumConnection_1Process(globalMap); 
						



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage());
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tLogCatcher_1 finally ] start
	 */

	

	
	
	currentComponent="tLogCatcher_1";

	

 



/**
 * [tLogCatcher_1 finally ] stop
 */

	
	/**
	 * [tSetGlobalVar_3 finally ] start
	 */

	

	
	
	currentComponent="tSetGlobalVar_3";

	

 



/**
 * [tSetGlobalVar_3 finally ] stop
 */



				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tLogCatcher_1_SUBPROCESS_STATE", 1);
	}
	

public void tGreenplumConnection_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tGreenplumConnection_1_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tGreenplumConnection_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tGreenplumConnection_1", false);
		start_Hash.put("tGreenplumConnection_1", System.currentTimeMillis());
		
	
	currentComponent="tGreenplumConnection_1";

	
		int tos_count_tGreenplumConnection_1 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tGreenplumConnection_1 - "  + ("Start to work.") );
    	class BytesLimit65535_tGreenplumConnection_1{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tGreenplumConnection_1 = new StringBuilder();
            log4jParamters_tGreenplumConnection_1.append("Parameters:");
                    log4jParamters_tGreenplumConnection_1.append("HOST" + " = " + "context.SOURCING_Server");
                log4jParamters_tGreenplumConnection_1.append(" | ");
                    log4jParamters_tGreenplumConnection_1.append("PORT" + " = " + "context.SOURCING_Port");
                log4jParamters_tGreenplumConnection_1.append(" | ");
                    log4jParamters_tGreenplumConnection_1.append("DBNAME" + " = " + "context.SOURCING_Database");
                log4jParamters_tGreenplumConnection_1.append(" | ");
                    log4jParamters_tGreenplumConnection_1.append("SCHEMA_DB" + " = " + "context.SOURCING_Schema");
                log4jParamters_tGreenplumConnection_1.append(" | ");
                    log4jParamters_tGreenplumConnection_1.append("USER" + " = " + "context.SOURCING_Login");
                log4jParamters_tGreenplumConnection_1.append(" | ");
                    log4jParamters_tGreenplumConnection_1.append("PASS" + " = " + String.valueOf(routines.system.PasswordEncryptUtil.encryptPassword(context.SOURCING_Password)).substring(0, 4) + "...");     
                log4jParamters_tGreenplumConnection_1.append(" | ");
                    log4jParamters_tGreenplumConnection_1.append("USE_SHARED_CONNECTION" + " = " + "false");
                log4jParamters_tGreenplumConnection_1.append(" | ");
                    log4jParamters_tGreenplumConnection_1.append("USE_SSL" + " = " + "true");
                log4jParamters_tGreenplumConnection_1.append(" | ");
                    log4jParamters_tGreenplumConnection_1.append("AUTO_COMMIT" + " = " + "true");
                log4jParamters_tGreenplumConnection_1.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tGreenplumConnection_1 - "  + (log4jParamters_tGreenplumConnection_1) );
    		}
    	}
    	
        new BytesLimit65535_tGreenplumConnection_1().limitLog4jByte();
	

	
				String url_tGreenplumConnection_1 = "jdbc:postgresql://"+context.SOURCING_Server+":"+context.SOURCING_Port+"/"+context.SOURCING_Database+"?ssl=true&sslfactory=org.postgresql.ssl.NonValidatingFactory";

	String dbUser_tGreenplumConnection_1 = context.SOURCING_Login;
	
	
		
	final String decryptedPassword_tGreenplumConnection_1 = context.SOURCING_Password; 
		String dbPwd_tGreenplumConnection_1 = decryptedPassword_tGreenplumConnection_1;
	

	java.sql.Connection conn_tGreenplumConnection_1 = null;
	
		
			String driverClass_tGreenplumConnection_1 = "org.postgresql.Driver";
			java.lang.Class.forName(driverClass_tGreenplumConnection_1);
		
	    		log.debug("tGreenplumConnection_1 - Driver ClassName: "+driverClass_tGreenplumConnection_1+".");
			
	    		log.debug("tGreenplumConnection_1 - Connection attempt to '" + url_tGreenplumConnection_1 + "' with the username '" + dbUser_tGreenplumConnection_1 + "'.");
			
		conn_tGreenplumConnection_1 = java.sql.DriverManager.getConnection(url_tGreenplumConnection_1,dbUser_tGreenplumConnection_1,dbPwd_tGreenplumConnection_1);
	    		log.debug("tGreenplumConnection_1 - Connection to '" + url_tGreenplumConnection_1 + "' has succeeded.");
			

		globalMap.put("conn_tGreenplumConnection_1", conn_tGreenplumConnection_1);
	if (null != conn_tGreenplumConnection_1) {
		
			log.debug("tGreenplumConnection_1 - Connection is set auto commit to 'true'.");
			conn_tGreenplumConnection_1.setAutoCommit(true);
	}

	globalMap.put("schema_" + "tGreenplumConnection_1",context.SOURCING_Schema);

	globalMap.put("conn_" + "tGreenplumConnection_1",conn_tGreenplumConnection_1);
 



/**
 * [tGreenplumConnection_1 begin ] stop
 */
	
	/**
	 * [tGreenplumConnection_1 main ] start
	 */

	

	
	
	currentComponent="tGreenplumConnection_1";

	

 


	tos_count_tGreenplumConnection_1++;

/**
 * [tGreenplumConnection_1 main ] stop
 */
	
	/**
	 * [tGreenplumConnection_1 end ] start
	 */

	

	
	
	currentComponent="tGreenplumConnection_1";

	

 
                if(log.isDebugEnabled())
            log.debug("tGreenplumConnection_1 - "  + ("Done.") );

ok_Hash.put("tGreenplumConnection_1", true);
end_Hash.put("tGreenplumConnection_1", System.currentTimeMillis());




/**
 * [tGreenplumConnection_1 end ] stop
 */
				}//end the resume

				
				    			if(resumeEntryMethodName == null || globalResumeTicket){
				    				resumeUtil.addLog("CHECKPOINT", "CONNECTION:SUBJOB_OK:tGreenplumConnection_1:OnSubjobOk", "", Thread.currentThread().getId() + "", "", "", "", "", "");
								}	    				    			
					    	
								if(execStat){    	
									runStat.updateStatOnConnection("OnSubjobOk27", 0, "ok");
								} 
							
							tGreenplumRow_3Process(globalMap); 
						



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage());
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tGreenplumConnection_1 finally ] start
	 */

	

	
	
	currentComponent="tGreenplumConnection_1";

	

 



/**
 * [tGreenplumConnection_1 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tGreenplumConnection_1_SUBPROCESS_STATE", 1);
	}
	

public void tGreenplumRow_3Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tGreenplumRow_3_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tGreenplumRow_3 begin ] start
	 */

	

	
		
		ok_Hash.put("tGreenplumRow_3", false);
		start_Hash.put("tGreenplumRow_3", System.currentTimeMillis());
		
	
	currentComponent="tGreenplumRow_3";

	
		int tos_count_tGreenplumRow_3 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tGreenplumRow_3 - "  + ("Start to work.") );
    	class BytesLimit65535_tGreenplumRow_3{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tGreenplumRow_3 = new StringBuilder();
            log4jParamters_tGreenplumRow_3.append("Parameters:");
                    log4jParamters_tGreenplumRow_3.append("USE_EXISTING_CONNECTION" + " = " + "true");
                log4jParamters_tGreenplumRow_3.append(" | ");
                    log4jParamters_tGreenplumRow_3.append("CONNECTION" + " = " + "tGreenplumConnection_2");
                log4jParamters_tGreenplumRow_3.append(" | ");
                    log4jParamters_tGreenplumRow_3.append("QUERYSTORE" + " = " + "\"\"");
                log4jParamters_tGreenplumRow_3.append(" | ");
                    log4jParamters_tGreenplumRow_3.append("QUERY" + " = " + "\"update sbdt.ingestion_log set status='ERROR', end_time=to_timestamp('\" +   new SimpleDateFormat(\"yyyy-MM-dd HH:mm:ss\").format(TalendDate.getCurrentDate()).toString() +  \"', 'YYYY-MM-DD HH24:MI:SS')::timestamp without time zone, log_time=to_timestamp('\" +   new SimpleDateFormat(\"yyyy-MM-dd HH:mm:ss\").format(TalendDate.getCurrentDate()).toString() +  \"', 'YYYY-MM-DD HH24:MI:SS')::timestamp without time zone\" +  \", messages='\" +((String)globalMap.get(\"error_message_desc\")) +  \"' where row_id = \" + ((BigDecimal)globalMap.get(\"row3.row_id\"))");
                log4jParamters_tGreenplumRow_3.append(" | ");
                    log4jParamters_tGreenplumRow_3.append("DIE_ON_ERROR" + " = " + "true");
                log4jParamters_tGreenplumRow_3.append(" | ");
                    log4jParamters_tGreenplumRow_3.append("PROPAGATE_RECORD_SET" + " = " + "false");
                log4jParamters_tGreenplumRow_3.append(" | ");
                    log4jParamters_tGreenplumRow_3.append("USE_PREPAREDSTATEMENT" + " = " + "false");
                log4jParamters_tGreenplumRow_3.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tGreenplumRow_3 - "  + (log4jParamters_tGreenplumRow_3) );
    		}
    	}
    	
        new BytesLimit65535_tGreenplumRow_3().limitLog4jByte();

	java.sql.Connection conn_tGreenplumRow_3 = null;
	String query_tGreenplumRow_3 = "";
	boolean whetherReject_tGreenplumRow_3 = false;
				conn_tGreenplumRow_3 = (java.sql.Connection)globalMap.get("conn_tGreenplumConnection_2");
			
				if(conn_tGreenplumRow_3 != null) {
					if(conn_tGreenplumRow_3.getMetaData() != null) {
						
						log.debug("tGreenplumRow_3 - Uses an existing connection with username '" + conn_tGreenplumRow_3.getMetaData().getUserName() + "'. Connection URL: " + conn_tGreenplumRow_3.getMetaData().getURL() + ".");
						
					}
				}
			
		java.sql.Statement stmt_tGreenplumRow_3 = conn_tGreenplumRow_3.createStatement();
	

 



/**
 * [tGreenplumRow_3 begin ] stop
 */
	
	/**
	 * [tGreenplumRow_3 main ] start
	 */

	

	
	
	currentComponent="tGreenplumRow_3";

	

	    		log.debug("tGreenplumRow_3 - Executing the query: '" + "update sbdt.ingestion_log set status='ERROR', end_time=to_timestamp('" +   new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(TalendDate.getCurrentDate()).toString() +  "', 'YYYY-MM-DD HH24:MI:SS')::timestamp without time zone, log_time=to_timestamp('" +   new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(TalendDate.getCurrentDate()).toString() +  "', 'YYYY-MM-DD HH24:MI:SS')::timestamp without time zone" +  ", messages='" +((String)globalMap.get("error_message_desc")) +  "' where row_id = " + ((BigDecimal)globalMap.get("row3.row_id")) + "'.");
			
query_tGreenplumRow_3 = "update sbdt.ingestion_log set status='ERROR', end_time=to_timestamp('" + 
new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(TalendDate.getCurrentDate()).toString() +
"', 'YYYY-MM-DD HH24:MI:SS')::timestamp without time zone, log_time=to_timestamp('" + 
new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(TalendDate.getCurrentDate()).toString() +
"', 'YYYY-MM-DD HH24:MI:SS')::timestamp without time zone" +
", messages='" +((String)globalMap.get("error_message_desc")) +
"' where row_id = " + ((BigDecimal)globalMap.get("row3.row_id"));
whetherReject_tGreenplumRow_3 = false;
globalMap.put("tGreenplumRow_3_QUERY",query_tGreenplumRow_3);
try {
		stmt_tGreenplumRow_3.execute(query_tGreenplumRow_3);
		
	    		log.info("tGreenplumRow_3 - Execute the query: '" + "update sbdt.ingestion_log set status='ERROR', end_time=to_timestamp('" + 
new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(TalendDate.getCurrentDate()).toString() +
"', 'YYYY-MM-DD HH24:MI:SS')::timestamp without time zone, log_time=to_timestamp('" + 
new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(TalendDate.getCurrentDate()).toString() +
"', 'YYYY-MM-DD HH24:MI:SS')::timestamp without time zone" +
", messages='" +((String)globalMap.get("error_message_desc")) +
"' where row_id = " + ((BigDecimal)globalMap.get("row3.row_id")) + "' has finished.");
			
	} catch (java.lang.Exception e) {
		whetherReject_tGreenplumRow_3 = true;
		
			throw(e);
			
	}
	
	if(!whetherReject_tGreenplumRow_3) {
		
	}
	

 


	tos_count_tGreenplumRow_3++;

/**
 * [tGreenplumRow_3 main ] stop
 */
	
	/**
	 * [tGreenplumRow_3 end ] start
	 */

	

	
	
	currentComponent="tGreenplumRow_3";

	

	
	stmt_tGreenplumRow_3.close();	

 
                if(log.isDebugEnabled())
            log.debug("tGreenplumRow_3 - "  + ("Done.") );

ok_Hash.put("tGreenplumRow_3", true);
end_Hash.put("tGreenplumRow_3", System.currentTimeMillis());

   			if (true) {
   				
					if(execStat){   
   	 					runStat.updateStatOnConnection("If14", 0, "true");
					}
				
    			tGreenplumClose_2Process(globalMap);
   			}

			   
   				else{
					if(execStat){   
   	 					runStat.updateStatOnConnection("If14", 0, "false");
					}   	 
   				}



/**
 * [tGreenplumRow_3 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage());
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tGreenplumRow_3 finally ] start
	 */

	

	
	
	currentComponent="tGreenplumRow_3";

	

 



/**
 * [tGreenplumRow_3 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tGreenplumRow_3_SUBPROCESS_STATE", 1);
	}
	

public void tGreenplumClose_2Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tGreenplumClose_2_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;





	
	/**
	 * [tGreenplumClose_2 begin ] start
	 */

	

	
		
		ok_Hash.put("tGreenplumClose_2", false);
		start_Hash.put("tGreenplumClose_2", System.currentTimeMillis());
		
	
	currentComponent="tGreenplumClose_2";

	
		int tos_count_tGreenplumClose_2 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tGreenplumClose_2 - "  + ("Start to work.") );
    	class BytesLimit65535_tGreenplumClose_2{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tGreenplumClose_2 = new StringBuilder();
            log4jParamters_tGreenplumClose_2.append("Parameters:");
                    log4jParamters_tGreenplumClose_2.append("CONNECTION" + " = " + "tGreenplumConnection_1");
                log4jParamters_tGreenplumClose_2.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tGreenplumClose_2 - "  + (log4jParamters_tGreenplumClose_2) );
    		}
    	}
    	
        new BytesLimit65535_tGreenplumClose_2().limitLog4jByte();

 



/**
 * [tGreenplumClose_2 begin ] stop
 */
	
	/**
	 * [tGreenplumClose_2 main ] start
	 */

	

	
	
	currentComponent="tGreenplumClose_2";

	



	java.sql.Connection conn_tGreenplumClose_2 = (java.sql.Connection)globalMap.get("conn_tGreenplumConnection_1");
	if(conn_tGreenplumClose_2 != null && !conn_tGreenplumClose_2.isClosed())
	{
                if(log.isDebugEnabled())
            log.debug("tGreenplumClose_2 - "  + ("Closing the connection ")  + ("conn_tGreenplumConnection_1")  + (" to the database.") );
        conn_tGreenplumClose_2.close();
                if(log.isDebugEnabled())
            log.debug("tGreenplumClose_2 - "  + ("Connection ")  + ("conn_tGreenplumConnection_1")  + (" to the database has closed.") );
	}

 


	tos_count_tGreenplumClose_2++;

/**
 * [tGreenplumClose_2 main ] stop
 */
	
	/**
	 * [tGreenplumClose_2 end ] start
	 */

	

	
	
	currentComponent="tGreenplumClose_2";

	

 
                if(log.isDebugEnabled())
            log.debug("tGreenplumClose_2 - "  + ("Done.") );

ok_Hash.put("tGreenplumClose_2", true);
end_Hash.put("tGreenplumClose_2", System.currentTimeMillis());




/**
 * [tGreenplumClose_2 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage());
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tGreenplumClose_2 finally ] start
	 */

	

	
	
	currentComponent="tGreenplumClose_2";

	

 



/**
 * [tGreenplumClose_2 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tGreenplumClose_2_SUBPROCESS_STATE", 1);
	}
	


public static class row5Struct implements routines.system.IPersistableRow<row5Struct> {
    final static byte[] commonByteArrayLock_AWS_DEV_TALEND_INGESTION_FRAMEWORK_AS400_to_greenplum_with_GPLoad = new byte[0];
    static byte[] commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_AS400_to_greenplum_with_GPLoad = new byte[0];

	
			    public String TableName;

				public String getTableName () {
					return this.TableName;
				}
				
			    public String OriginalTableName;

				public String getOriginalTableName () {
					return this.OriginalTableName;
				}
				
			    public String ColumnList;

				public String getColumnList () {
					return this.ColumnList;
				}
				



	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_AS400_to_greenplum_with_GPLoad.length) {
				if(length < 1024 && commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_AS400_to_greenplum_with_GPLoad.length == 0) {
   					commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_AS400_to_greenplum_with_GPLoad = new byte[1024];
				} else {
   					commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_AS400_to_greenplum_with_GPLoad = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_AS400_to_greenplum_with_GPLoad, 0, length);
			strReturn = new String(commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_AS400_to_greenplum_with_GPLoad, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_AWS_DEV_TALEND_INGESTION_FRAMEWORK_AS400_to_greenplum_with_GPLoad) {

        	try {

        		int length = 0;
		
					this.TableName = readString(dis);
					
					this.OriginalTableName = readString(dis);
					
					this.ColumnList = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// String
				
						writeString(this.TableName,dos);
					
					// String
				
						writeString(this.OriginalTableName,dos);
					
					// String
				
						writeString(this.ColumnList,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("TableName="+TableName);
		sb.append(",OriginalTableName="+OriginalTableName);
		sb.append(",ColumnList="+ColumnList);
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				if(TableName == null){
        					sb.append("<null>");
        				}else{
            				sb.append(TableName);
            			}
            		
        			sb.append("|");
        		
        				if(OriginalTableName == null){
        					sb.append("<null>");
        				}else{
            				sb.append(OriginalTableName);
            			}
            		
        			sb.append("|");
        		
        				if(ColumnList == null){
        					sb.append("<null>");
        				}else{
            				sb.append(ColumnList);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(row5Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public static class OnRowsEndStructtAggregateRow_1 implements routines.system.IPersistableRow<OnRowsEndStructtAggregateRow_1> {
    final static byte[] commonByteArrayLock_AWS_DEV_TALEND_INGESTION_FRAMEWORK_AS400_to_greenplum_with_GPLoad = new byte[0];
    static byte[] commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_AS400_to_greenplum_with_GPLoad = new byte[0];

	
			    public String TableName;

				public String getTableName () {
					return this.TableName;
				}
				
			    public String OriginalTableName;

				public String getOriginalTableName () {
					return this.OriginalTableName;
				}
				
			    public String ColumnList;

				public String getColumnList () {
					return this.ColumnList;
				}
				



	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_AS400_to_greenplum_with_GPLoad.length) {
				if(length < 1024 && commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_AS400_to_greenplum_with_GPLoad.length == 0) {
   					commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_AS400_to_greenplum_with_GPLoad = new byte[1024];
				} else {
   					commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_AS400_to_greenplum_with_GPLoad = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_AS400_to_greenplum_with_GPLoad, 0, length);
			strReturn = new String(commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_AS400_to_greenplum_with_GPLoad, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_AWS_DEV_TALEND_INGESTION_FRAMEWORK_AS400_to_greenplum_with_GPLoad) {

        	try {

        		int length = 0;
		
					this.TableName = readString(dis);
					
					this.OriginalTableName = readString(dis);
					
					this.ColumnList = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// String
				
						writeString(this.TableName,dos);
					
					// String
				
						writeString(this.OriginalTableName,dos);
					
					// String
				
						writeString(this.ColumnList,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("TableName="+TableName);
		sb.append(",OriginalTableName="+OriginalTableName);
		sb.append(",ColumnList="+ColumnList);
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				if(TableName == null){
        					sb.append("<null>");
        				}else{
            				sb.append(TableName);
            			}
            		
        			sb.append("|");
        		
        				if(OriginalTableName == null){
        					sb.append("<null>");
        				}else{
            				sb.append(OriginalTableName);
            			}
            		
        			sb.append("|");
        		
        				if(ColumnList == null){
        					sb.append("<null>");
        				}else{
            				sb.append(ColumnList);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(OnRowsEndStructtAggregateRow_1 other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public static class testStruct implements routines.system.IPersistableRow<testStruct> {
    final static byte[] commonByteArrayLock_AWS_DEV_TALEND_INGESTION_FRAMEWORK_AS400_to_greenplum_with_GPLoad = new byte[0];
    static byte[] commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_AS400_to_greenplum_with_GPLoad = new byte[0];

	
			    public String TableName;

				public String getTableName () {
					return this.TableName;
				}
				
			    public String OriginalTableName;

				public String getOriginalTableName () {
					return this.OriginalTableName;
				}
				
			    public String FIELDS;

				public String getFIELDS () {
					return this.FIELDS;
				}
				



	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_AS400_to_greenplum_with_GPLoad.length) {
				if(length < 1024 && commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_AS400_to_greenplum_with_GPLoad.length == 0) {
   					commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_AS400_to_greenplum_with_GPLoad = new byte[1024];
				} else {
   					commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_AS400_to_greenplum_with_GPLoad = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_AS400_to_greenplum_with_GPLoad, 0, length);
			strReturn = new String(commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_AS400_to_greenplum_with_GPLoad, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_AWS_DEV_TALEND_INGESTION_FRAMEWORK_AS400_to_greenplum_with_GPLoad) {

        	try {

        		int length = 0;
		
					this.TableName = readString(dis);
					
					this.OriginalTableName = readString(dis);
					
					this.FIELDS = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// String
				
						writeString(this.TableName,dos);
					
					// String
				
						writeString(this.OriginalTableName,dos);
					
					// String
				
						writeString(this.FIELDS,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("TableName="+TableName);
		sb.append(",OriginalTableName="+OriginalTableName);
		sb.append(",FIELDS="+FIELDS);
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				if(TableName == null){
        					sb.append("<null>");
        				}else{
            				sb.append(TableName);
            			}
            		
        			sb.append("|");
        		
        				if(OriginalTableName == null){
        					sb.append("<null>");
        				}else{
            				sb.append(OriginalTableName);
            			}
            		
        			sb.append("|");
        		
        				if(FIELDS == null){
        					sb.append("<null>");
        				}else{
            				sb.append(FIELDS);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(testStruct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public static class row7Struct implements routines.system.IPersistableRow<row7Struct> {
    final static byte[] commonByteArrayLock_AWS_DEV_TALEND_INGESTION_FRAMEWORK_AS400_to_greenplum_with_GPLoad = new byte[0];
    static byte[] commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_AS400_to_greenplum_with_GPLoad = new byte[0];

	
			    public String TableName;

				public String getTableName () {
					return this.TableName;
				}
				
			    public String ColumnName;

				public String getColumnName () {
					return this.ColumnName;
				}
				
			    public Integer ColumnLength;

				public Integer getColumnLength () {
					return this.ColumnLength;
				}
				
			    public Integer ColumnPrecision;

				public Integer getColumnPrecision () {
					return this.ColumnPrecision;
				}
				
			    public Integer ColumnType;

				public Integer getColumnType () {
					return this.ColumnType;
				}
				
			    public String ColumnTypeName;

				public String getColumnTypeName () {
					return this.ColumnTypeName;
				}
				



	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_AS400_to_greenplum_with_GPLoad.length) {
				if(length < 1024 && commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_AS400_to_greenplum_with_GPLoad.length == 0) {
   					commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_AS400_to_greenplum_with_GPLoad = new byte[1024];
				} else {
   					commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_AS400_to_greenplum_with_GPLoad = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_AS400_to_greenplum_with_GPLoad, 0, length);
			strReturn = new String(commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_AS400_to_greenplum_with_GPLoad, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
	private Integer readInteger(ObjectInputStream dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}

	private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException{
		if(intNum == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeInt(intNum);
    	}
	}

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_AWS_DEV_TALEND_INGESTION_FRAMEWORK_AS400_to_greenplum_with_GPLoad) {

        	try {

        		int length = 0;
		
					this.TableName = readString(dis);
					
					this.ColumnName = readString(dis);
					
						this.ColumnLength = readInteger(dis);
					
						this.ColumnPrecision = readInteger(dis);
					
						this.ColumnType = readInteger(dis);
					
					this.ColumnTypeName = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// String
				
						writeString(this.TableName,dos);
					
					// String
				
						writeString(this.ColumnName,dos);
					
					// Integer
				
						writeInteger(this.ColumnLength,dos);
					
					// Integer
				
						writeInteger(this.ColumnPrecision,dos);
					
					// Integer
				
						writeInteger(this.ColumnType,dos);
					
					// String
				
						writeString(this.ColumnTypeName,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("TableName="+TableName);
		sb.append(",ColumnName="+ColumnName);
		sb.append(",ColumnLength="+String.valueOf(ColumnLength));
		sb.append(",ColumnPrecision="+String.valueOf(ColumnPrecision));
		sb.append(",ColumnType="+String.valueOf(ColumnType));
		sb.append(",ColumnTypeName="+ColumnTypeName);
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				if(TableName == null){
        					sb.append("<null>");
        				}else{
            				sb.append(TableName);
            			}
            		
        			sb.append("|");
        		
        				if(ColumnName == null){
        					sb.append("<null>");
        				}else{
            				sb.append(ColumnName);
            			}
            		
        			sb.append("|");
        		
        				if(ColumnLength == null){
        					sb.append("<null>");
        				}else{
            				sb.append(ColumnLength);
            			}
            		
        			sb.append("|");
        		
        				if(ColumnPrecision == null){
        					sb.append("<null>");
        				}else{
            				sb.append(ColumnPrecision);
            			}
            		
        			sb.append("|");
        		
        				if(ColumnType == null){
        					sb.append("<null>");
        				}else{
            				sb.append(ColumnType);
            			}
            		
        			sb.append("|");
        		
        				if(ColumnTypeName == null){
        					sb.append("<null>");
        				}else{
            				sb.append(ColumnTypeName);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(row7Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}
public void tIterateToFlow_1_AIProcess(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tIterateToFlow_1_AI_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
		String currentVirtualComponent = null;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;



		row7Struct row7 = new row7Struct();
testStruct test = new testStruct();
row5Struct row5 = new row5Struct();





	
	/**
	 * [tAggregateRow_1_AGGOUT begin ] start
	 */

	

	
		
		ok_Hash.put("tAggregateRow_1_AGGOUT", false);
		start_Hash.put("tAggregateRow_1_AGGOUT", System.currentTimeMillis());
		
	
		currentVirtualComponent = "tAggregateRow_1";
	
	currentComponent="tAggregateRow_1_AGGOUT";

	
			if (execStat) {
				if(resourceMap.get("inIterateVComp") == null){
					
						runStat.updateStatOnConnection("test" + iterateId, 0, 0);
					
				}
			} 

		
		int tos_count_tAggregateRow_1_AGGOUT = 0;
		
                if(log.isDebugEnabled())
            log.debug("tAggregateRow_1_AGGOUT - "  + ("Start to work.") );
    	class BytesLimit65535_tAggregateRow_1_AGGOUT{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tAggregateRow_1_AGGOUT = new StringBuilder();
            log4jParamters_tAggregateRow_1_AGGOUT.append("Parameters:");
                    log4jParamters_tAggregateRow_1_AGGOUT.append("DESTINATION" + " = " + "tAggregateRow_1");
                log4jParamters_tAggregateRow_1_AGGOUT.append(" | ");
                    log4jParamters_tAggregateRow_1_AGGOUT.append("GROUPBYS" + " = " + "[{OUTPUT_COLUMN="+("TableName")+", INPUT_COLUMN="+("TableName")+"}, {OUTPUT_COLUMN="+("OriginalTableName")+", INPUT_COLUMN="+("OriginalTableName")+"}]");
                log4jParamters_tAggregateRow_1_AGGOUT.append(" | ");
                    log4jParamters_tAggregateRow_1_AGGOUT.append("OPERATIONS" + " = " + "[{OUTPUT_COLUMN="+("ColumnList")+", INPUT_COLUMN="+("FIELDS")+", IGNORE_NULL="+("false")+", FUNCTION="+("list")+"}]");
                log4jParamters_tAggregateRow_1_AGGOUT.append(" | ");
                    log4jParamters_tAggregateRow_1_AGGOUT.append("LIST_DELIMITER" + " = " + "\",\"");
                log4jParamters_tAggregateRow_1_AGGOUT.append(" | ");
                    log4jParamters_tAggregateRow_1_AGGOUT.append("USE_FINANCIAL_PRECISION" + " = " + "true");
                log4jParamters_tAggregateRow_1_AGGOUT.append(" | ");
                    log4jParamters_tAggregateRow_1_AGGOUT.append("CHECK_TYPE_OVERFLOW" + " = " + "false");
                log4jParamters_tAggregateRow_1_AGGOUT.append(" | ");
                    log4jParamters_tAggregateRow_1_AGGOUT.append("CHECK_ULP" + " = " + "false");
                log4jParamters_tAggregateRow_1_AGGOUT.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tAggregateRow_1_AGGOUT - "  + (log4jParamters_tAggregateRow_1_AGGOUT) );
    		}
    	}
    	
        new BytesLimit65535_tAggregateRow_1_AGGOUT().limitLog4jByte();

// ------------ Seems it is not used

java.util.Map hashAggreg_tAggregateRow_1 = new java.util.HashMap(); 

// ------------

	class UtilClass_tAggregateRow_1 { // G_OutBegin_AggR_144

		public double sd(Double[] data) {
	        final int n = data.length;
        	if (n < 2) {
	            return Double.NaN;
        	}
        	double d1 = 0d;
        	double d2 =0d;
	        
	        for (int i = 0; i < data.length; i++) {
            	d1 += (data[i]*data[i]);
            	d2 += data[i];
        	}
        
	        return Math.sqrt((n*d1 - d2*d2)/n/(n-1));
	    }
	    
		public void checkedIADD(byte a, byte b, boolean checkTypeOverFlow, boolean checkUlp) {
		    byte r = (byte) (a + b);
		    if (checkTypeOverFlow && ((a ^ r) & (b ^ r)) < 0) {
		        throw new RuntimeException(buildOverflowMessage(String.valueOf(a), String.valueOf(b), "'short/Short'", "'byte/Byte'"));
		    }
		}
		
		public void checkedIADD(short a, short b, boolean checkTypeOverFlow, boolean checkUlp) {
		    short r = (short) (a + b);
		    if (checkTypeOverFlow && ((a ^ r) & (b ^ r)) < 0) {
		        throw new RuntimeException(buildOverflowMessage(String.valueOf(a), String.valueOf(b), "'int/Integer'", "'short/Short'"));
		    }
		}
		
		public void checkedIADD(int a, int b, boolean checkTypeOverFlow, boolean checkUlp) {
		    int r = a + b;
		    if (checkTypeOverFlow && ((a ^ r) & (b ^ r)) < 0) {
		        throw new RuntimeException(buildOverflowMessage(String.valueOf(a), String.valueOf(b), "'long/Long'", "'int/Integer'"));
		    }
		}
		
		public void checkedIADD(long a, long b, boolean checkTypeOverFlow, boolean checkUlp) {
		    long r = a + b;
		    if (checkTypeOverFlow && ((a ^ r) & (b ^ r)) < 0) {
		        throw new RuntimeException(buildOverflowMessage(String.valueOf(a), String.valueOf(b), "'BigDecimal'", "'long/Long'"));
		    }
		}
		
		public void checkedIADD(float a, float b, boolean checkTypeOverFlow, boolean checkUlp) {
		
			if(checkUlp) {
			    float minAddedValue = Math.ulp(a);
			    if (minAddedValue > Math.abs(b)) {
			        throw new RuntimeException(buildPrecisionMessage(String.valueOf(a), String.valueOf(b), "'double' or 'BigDecimal'", "'float/Float'"));
			    }
			}
			
		    if (checkTypeOverFlow && ((double) a + (double) b > (double) Float.MAX_VALUE) || ((double) a + (double) b < (double) -Float.MAX_VALUE)) {
		        throw new RuntimeException(buildOverflowMessage(String.valueOf(a), String.valueOf(b), "'double' or 'BigDecimal'", "'float/Float'"));
		    }
		}
		
		public void checkedIADD(double a, double b, boolean checkTypeOverFlow, boolean checkUlp) {
		
			if(checkUlp) {
			    double minAddedValue = Math.ulp(a);
			    if (minAddedValue > Math.abs(b)) {
			        throw new RuntimeException(buildPrecisionMessage(String.valueOf(a), String.valueOf(a), "'BigDecimal'", "'double/Double'"));
			    }
			}
		
		    if (checkTypeOverFlow && (a + b > (double) Double.MAX_VALUE) || (a + b < -Double.MAX_VALUE )) {
		        throw new RuntimeException(buildOverflowMessage(String.valueOf(a), String.valueOf(b), "'BigDecimal'", "'double/Double'"));
		    }
		}
		
		public void checkedIADD(double a, byte b, boolean checkTypeOverFlow, boolean checkUlp) {
		
		    if (checkTypeOverFlow && (a + b > (double) Double.MAX_VALUE) || (a + b < -Double.MAX_VALUE )) {
		        throw new RuntimeException(buildOverflowMessage(String.valueOf(a), String.valueOf(b), "'BigDecimal'", "'double/Double'"));
		    }
		}
		
		public void checkedIADD(double a, short b, boolean checkTypeOverFlow, boolean checkUlp) {
		
		    if (checkTypeOverFlow && (a + b > (double) Double.MAX_VALUE) || (a + b < -Double.MAX_VALUE )) {
		        throw new RuntimeException(buildOverflowMessage(String.valueOf(a), String.valueOf(b), "'BigDecimal'", "'double/Double'"));
		    }
		}
		
		public void checkedIADD(double a, int b, boolean checkTypeOverFlow, boolean checkUlp) {
		
		    if (checkTypeOverFlow && (a + b > (double) Double.MAX_VALUE) || (a + b < -Double.MAX_VALUE )) {
		        throw new RuntimeException(buildOverflowMessage(String.valueOf(a), String.valueOf(b), "'BigDecimal'", "'double/Double'"));
		    }
		}
		
		public void checkedIADD(double a, float b, boolean checkTypeOverFlow, boolean checkUlp) {
		
			if(checkUlp) {
			    double minAddedValue = Math.ulp(a);
			    if (minAddedValue > Math.abs(b)) {
			        throw new RuntimeException(buildPrecisionMessage(String.valueOf(a), String.valueOf(a), "'BigDecimal'", "'double/Double'"));
			    }
			}
		
		    if (checkTypeOverFlow && (a + b > (double) Double.MAX_VALUE) || (a + b < -Double.MAX_VALUE )) {
		        throw new RuntimeException(buildOverflowMessage(String.valueOf(a), String.valueOf(b), "'BigDecimal'", "'double/Double'"));
		    }
		}
		
		private String buildOverflowMessage(String a, String b, String advicedTypes, String originalType) {
		    return "Type overflow when adding " + b + " to " + a
		    + ", to resolve this problem, increase the precision by using "+ advicedTypes +" type in place of "+ originalType +".";
		}
		
		private String buildPrecisionMessage(String a, String b, String advicedTypes, String originalType) {
		    return "The double precision is unsufficient to add the value " + b + " to " + a
		    + ", to resolve this problem, increase the precision by using "+ advicedTypes +" type in place of "+ originalType +".";
		}

	} // G_OutBegin_AggR_144

	UtilClass_tAggregateRow_1 utilClass_tAggregateRow_1 = new UtilClass_tAggregateRow_1();

	

	class AggOperationStruct_tAggregateRow_1 { // G_OutBegin_AggR_100

		private static final int DEFAULT_HASHCODE = 1;
	    private static final int PRIME = 31;
	    private int hashCode = DEFAULT_HASHCODE;
	    public boolean hashCodeDirty = true;

    				String TableName;
    				String OriginalTableName;StringBuilder ColumnList_list = new StringBuilder();
           			boolean ColumnList_list_firstEmpty = false;
           			
        
	    @Override
		public int hashCode() {
			if (this.hashCodeDirty) {
				final int prime = PRIME;
				int result = DEFAULT_HASHCODE;
		
							result = prime * result + ((this.TableName == null) ? 0 : this.TableName.hashCode());
							
							result = prime * result + ((this.OriginalTableName == null) ? 0 : this.OriginalTableName.hashCode());
							
	    		this.hashCode = result;
	    		this.hashCodeDirty = false;		
			}
			return this.hashCode;
		}
		
		@Override
		public boolean equals(Object obj) {
			if (this == obj) return true;
			if (obj == null) return false;
			if (getClass() != obj.getClass()) return false;
			final AggOperationStruct_tAggregateRow_1 other = (AggOperationStruct_tAggregateRow_1) obj;
			
							if (this.TableName == null) {
								if (other.TableName != null) 
									return false;
							} else if (!this.TableName.equals(other.TableName)) 
								return false;
						
							if (this.OriginalTableName == null) {
								if (other.OriginalTableName != null) 
									return false;
							} else if (!this.OriginalTableName.equals(other.OriginalTableName)) 
								return false;
						
			
			return true;
		}
  
        
	} // G_OutBegin_AggR_100

	AggOperationStruct_tAggregateRow_1 operation_result_tAggregateRow_1 = null;
	AggOperationStruct_tAggregateRow_1 operation_finder_tAggregateRow_1 = new AggOperationStruct_tAggregateRow_1();
	java.util.Map<AggOperationStruct_tAggregateRow_1,AggOperationStruct_tAggregateRow_1> hash_tAggregateRow_1 = new java.util.HashMap<AggOperationStruct_tAggregateRow_1,AggOperationStruct_tAggregateRow_1>();
	
	String delimiter_tAggregateRow_1 = ",";
	

 



/**
 * [tAggregateRow_1_AGGOUT begin ] stop
 */



	
	/**
	 * [tMap_2 begin ] start
	 */

	

	
		
		ok_Hash.put("tMap_2", false);
		start_Hash.put("tMap_2", System.currentTimeMillis());
		
	
	currentComponent="tMap_2";

	
			if (execStat) {
				if(resourceMap.get("inIterateVComp") == null){
					
						runStat.updateStatOnConnection("row7" + iterateId, 0, 0);
					
				}
			} 

		
		int tos_count_tMap_2 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tMap_2 - "  + ("Start to work.") );
    	class BytesLimit65535_tMap_2{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tMap_2 = new StringBuilder();
            log4jParamters_tMap_2.append("Parameters:");
                    log4jParamters_tMap_2.append("LINK_STYLE" + " = " + "AUTO");
                log4jParamters_tMap_2.append(" | ");
                    log4jParamters_tMap_2.append("TEMPORARY_DATA_DIRECTORY" + " = " + "");
                log4jParamters_tMap_2.append(" | ");
                    log4jParamters_tMap_2.append("ROWS_BUFFER_SIZE" + " = " + "2000000");
                log4jParamters_tMap_2.append(" | ");
                    log4jParamters_tMap_2.append("CHANGE_HASH_AND_EQUALS_FOR_BIGDECIMAL" + " = " + "false");
                log4jParamters_tMap_2.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tMap_2 - "  + (log4jParamters_tMap_2) );
    		}
    	}
    	
        new BytesLimit65535_tMap_2().limitLog4jByte();




// ###############################
// # Lookup's keys initialization
		int count_row7_tMap_2 = 0;
		
// ###############################        

// ###############################
// # Vars initialization
class  Var__tMap_2__Struct  {
	String ColumnTypeName;
}
Var__tMap_2__Struct Var__tMap_2 = new Var__tMap_2__Struct();
// ###############################

// ###############################
// # Outputs initialization
				int count_test_tMap_2 = 0;
				
testStruct test_tmp = new testStruct();
// ###############################

        
        



        









 



/**
 * [tMap_2 begin ] stop
 */



	
	/**
	 * [tIterateToFlow_1_AI begin ] start
	 */

	

	
		
		ok_Hash.put("tIterateToFlow_1_AI", false);
		start_Hash.put("tIterateToFlow_1_AI", System.currentTimeMillis());
		
	
		currentVirtualComponent = "tIterateToFlow_1";
	
	currentComponent="tIterateToFlow_1_AI";

	
		int tos_count_tIterateToFlow_1_AI = 0;
		
    	class BytesLimit65535_tIterateToFlow_1_AI{
    		public void limitLog4jByte() throws Exception{
    			
    		}
    	}
    	
        new BytesLimit65535_tIterateToFlow_1_AI().limitLog4jByte();

        
        int nb_line_tIterateToFlow_1_AI = 0;
        java.util.List<OnSubjobOkStructtIterateToFlow_1> list_tIterateToFlow_1_AI = (java.util.List<OnSubjobOkStructtIterateToFlow_1>)globalMap.get("tIterateToFlow_1");
        if(list_tIterateToFlow_1_AI == null) {
            list_tIterateToFlow_1_AI = new java.util.ArrayList<OnSubjobOkStructtIterateToFlow_1>();
        }        
        for(OnSubjobOkStructtIterateToFlow_1 row_tIterateToFlow_1_AI : list_tIterateToFlow_1_AI){
        					
    						row7.TableName = row_tIterateToFlow_1_AI.TableName;
    											
    						row7.ColumnName = row_tIterateToFlow_1_AI.ColumnName;
    											
    						row7.ColumnLength = row_tIterateToFlow_1_AI.ColumnLength;
    											
    						row7.ColumnPrecision = row_tIterateToFlow_1_AI.ColumnPrecision;
    											
    						row7.ColumnType = row_tIterateToFlow_1_AI.ColumnType;
    											
    						row7.ColumnTypeName = row_tIterateToFlow_1_AI.ColumnTypeName;
    						

 



/**
 * [tIterateToFlow_1_AI begin ] stop
 */
	
	/**
	 * [tIterateToFlow_1_AI main ] start
	 */

	

	
	
		currentVirtualComponent = "tIterateToFlow_1";
	
	currentComponent="tIterateToFlow_1_AI";

	

 


	tos_count_tIterateToFlow_1_AI++;

/**
 * [tIterateToFlow_1_AI main ] stop
 */

	
	/**
	 * [tMap_2 main ] start
	 */

	

	
	
	currentComponent="tMap_2";

	

			//row7
			//row7


			
				if(execStat){
					runStat.updateStatOnConnection("row7"+iterateId,1, 1);
				} 
			

		
    			if(log.isTraceEnabled()){
    				log.trace("row7 - " + (row7==null? "": row7.toLogString()));
    			}
    		

		
		
		boolean hasCasePrimitiveKeyWithNull_tMap_2 = false;
		
        // ###############################
        // # Input tables (lookups)
		  boolean rejectedInnerJoin_tMap_2 = false;
		  boolean mainRowRejected_tMap_2 = false;
            				    								  
		// ###############################
        { // start of Var scope
        
	        // ###############################
        	// # Vars tables
        
Var__tMap_2__Struct Var = Var__tMap_2;
Var.ColumnTypeName = GEroutines.mapAS400ToGreenplumTypes(row7.ColumnTypeName)     ;// ###############################
        // ###############################
        // # Output tables

test = null;


// # Output table : 'test'
count_test_tMap_2++;

test_tmp.TableName = GEroutines.fixBadTableNames(row7.TableName)  ;
test_tmp.OriginalTableName = row7.TableName ;
test_tmp.FIELDS = GEroutines.fixBadTableNames(row7.ColumnName) +" "+Var.ColumnTypeName  +" "+GEroutines.getLengthAndPrecision(Var.ColumnTypeName, row7.ColumnPrecision, row7.ColumnLength);
test = test_tmp;
log.debug("tMap_2 - Outputting the record " + count_test_tMap_2 + " of the output table 'test'.");

// ###############################

} // end of Var scope

rejectedInnerJoin_tMap_2 = false;










 


	tos_count_tMap_2++;

/**
 * [tMap_2 main ] stop
 */
// Start of branch "test"
if(test != null) { 



	
	/**
	 * [tAggregateRow_1_AGGOUT main ] start
	 */

	

	
	
		currentVirtualComponent = "tAggregateRow_1";
	
	currentComponent="tAggregateRow_1_AGGOUT";

	

			//test
			//test


			
				if(execStat){
					runStat.updateStatOnConnection("test"+iterateId,1, 1);
				} 
			

		
    			if(log.isTraceEnabled()){
    				log.trace("test - " + (test==null? "": test.toLogString()));
    			}
    		
	
operation_finder_tAggregateRow_1.TableName = test.TableName;
			operation_finder_tAggregateRow_1.OriginalTableName = test.OriginalTableName;
			

	operation_finder_tAggregateRow_1.hashCodeDirty = true;
	
	operation_result_tAggregateRow_1 = hash_tAggregateRow_1.get(operation_finder_tAggregateRow_1);

	

	if(operation_result_tAggregateRow_1 == null) { // G_OutMain_AggR_001

		operation_result_tAggregateRow_1 = new AggOperationStruct_tAggregateRow_1();

		operation_result_tAggregateRow_1.TableName = operation_finder_tAggregateRow_1.TableName;
				operation_result_tAggregateRow_1.OriginalTableName = operation_finder_tAggregateRow_1.OriginalTableName;
				
		
		

		hash_tAggregateRow_1.put(operation_result_tAggregateRow_1, operation_result_tAggregateRow_1);
	
	} // G_OutMain_AggR_001


	
				if(operation_result_tAggregateRow_1.ColumnList_list.length() > 0) {
					operation_result_tAggregateRow_1.ColumnList_list.append(",");
				} 
				else if(operation_result_tAggregateRow_1.ColumnList_list_firstEmpty){
					operation_result_tAggregateRow_1.ColumnList_list.append(",");
				}
					if(operation_result_tAggregateRow_1.ColumnList_list != null) {
						if(operation_result_tAggregateRow_1.ColumnList_list_firstEmpty==false && ("").equals(String.valueOf(test.FIELDS))){
							operation_result_tAggregateRow_1.ColumnList_list_firstEmpty = true;
						}
						operation_result_tAggregateRow_1.ColumnList_list = operation_result_tAggregateRow_1.ColumnList_list.append(String.valueOf(test.FIELDS));
					}
				


 


	tos_count_tAggregateRow_1_AGGOUT++;

/**
 * [tAggregateRow_1_AGGOUT main ] stop
 */

} // End of branch "test"







	
	/**
	 * [tIterateToFlow_1_AI end ] start
	 */

	

	
	
		currentVirtualComponent = "tIterateToFlow_1";
	
	currentComponent="tIterateToFlow_1_AI";

	
	nb_line_tIterateToFlow_1_AI++;
}
globalMap.put("tIterateToFlow_1_AI_NB_LINE",nb_line_tIterateToFlow_1_AI);
 

ok_Hash.put("tIterateToFlow_1_AI", true);
end_Hash.put("tIterateToFlow_1_AI", System.currentTimeMillis());




/**
 * [tIterateToFlow_1_AI end ] stop
 */

	
	/**
	 * [tMap_2 end ] start
	 */

	

	
	
	currentComponent="tMap_2";

	


// ###############################
// # Lookup hashes releasing
// ###############################      
				log.debug("tMap_2 - Written records count in the table 'test': " + count_test_tMap_2 + ".");





			if(execStat){
				if(resourceMap.get("inIterateVComp") == null || !((Boolean)resourceMap.get("inIterateVComp"))){
			 		runStat.updateStatOnConnection("row7"+iterateId,2, 0); 
			 	}
			}
		
 
                if(log.isDebugEnabled())
            log.debug("tMap_2 - "  + ("Done.") );

ok_Hash.put("tMap_2", true);
end_Hash.put("tMap_2", System.currentTimeMillis());




/**
 * [tMap_2 end ] stop
 */

	
	/**
	 * [tAggregateRow_1_AGGOUT end ] start
	 */

	

	
	
		currentVirtualComponent = "tAggregateRow_1";
	
	currentComponent="tAggregateRow_1_AGGOUT";

	

			if(execStat){
				if(resourceMap.get("inIterateVComp") == null || !((Boolean)resourceMap.get("inIterateVComp"))){
			 		runStat.updateStatOnConnection("test"+iterateId,2, 0); 
			 	}
			}
		
 
                if(log.isDebugEnabled())
            log.debug("tAggregateRow_1_AGGOUT - "  + ("Done.") );

ok_Hash.put("tAggregateRow_1_AGGOUT", true);
end_Hash.put("tAggregateRow_1_AGGOUT", System.currentTimeMillis());




/**
 * [tAggregateRow_1_AGGOUT end ] stop
 */


	
	/**
	 * [tFlowToIterate_4 begin ] start
	 */

				
			int NB_ITERATE_tJava_5 = 0; //for statistics
			

	
		
		ok_Hash.put("tFlowToIterate_4", false);
		start_Hash.put("tFlowToIterate_4", System.currentTimeMillis());
		
	
	currentComponent="tFlowToIterate_4";

	
			if (execStat) {
				if(resourceMap.get("inIterateVComp") == null){
					
						runStat.updateStatOnConnection("row5" + iterateId, 0, 0);
					
				}
			} 

		
		int tos_count_tFlowToIterate_4 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tFlowToIterate_4 - "  + ("Start to work.") );
    	class BytesLimit65535_tFlowToIterate_4{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tFlowToIterate_4 = new StringBuilder();
            log4jParamters_tFlowToIterate_4.append("Parameters:");
                    log4jParamters_tFlowToIterate_4.append("DEFAULT_MAP" + " = " + "true");
                log4jParamters_tFlowToIterate_4.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tFlowToIterate_4 - "  + (log4jParamters_tFlowToIterate_4) );
    		}
    	}
    	
        new BytesLimit65535_tFlowToIterate_4().limitLog4jByte();

int nb_line_tFlowToIterate_4 = 0;
int counter_tFlowToIterate_4 = 0;

 



/**
 * [tFlowToIterate_4 begin ] stop
 */



	
	/**
	 * [tAggregateRow_1_AGGIN begin ] start
	 */

	

	
		
		ok_Hash.put("tAggregateRow_1_AGGIN", false);
		start_Hash.put("tAggregateRow_1_AGGIN", System.currentTimeMillis());
		
	
		currentVirtualComponent = "tAggregateRow_1";
	
	currentComponent="tAggregateRow_1_AGGIN";

	
		int tos_count_tAggregateRow_1_AGGIN = 0;
		
                if(log.isDebugEnabled())
            log.debug("tAggregateRow_1_AGGIN - "  + ("Start to work.") );
    	class BytesLimit65535_tAggregateRow_1_AGGIN{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tAggregateRow_1_AGGIN = new StringBuilder();
            log4jParamters_tAggregateRow_1_AGGIN.append("Parameters:");
                    log4jParamters_tAggregateRow_1_AGGIN.append("ORIGIN" + " = " + "tAggregateRow_1");
                log4jParamters_tAggregateRow_1_AGGIN.append(" | ");
                    log4jParamters_tAggregateRow_1_AGGIN.append("GROUPBYS" + " = " + "[{OUTPUT_COLUMN="+("TableName")+", INPUT_COLUMN="+("TableName")+"}, {OUTPUT_COLUMN="+("OriginalTableName")+", INPUT_COLUMN="+("OriginalTableName")+"}]");
                log4jParamters_tAggregateRow_1_AGGIN.append(" | ");
                    log4jParamters_tAggregateRow_1_AGGIN.append("OPERATIONS" + " = " + "[{OUTPUT_COLUMN="+("ColumnList")+", INPUT_COLUMN="+("FIELDS")+", IGNORE_NULL="+("false")+", FUNCTION="+("list")+"}]");
                log4jParamters_tAggregateRow_1_AGGIN.append(" | ");
                    log4jParamters_tAggregateRow_1_AGGIN.append("LIST_DELIMITER" + " = " + "\",\"");
                log4jParamters_tAggregateRow_1_AGGIN.append(" | ");
                    log4jParamters_tAggregateRow_1_AGGIN.append("USE_FINANCIAL_PRECISION" + " = " + "true");
                log4jParamters_tAggregateRow_1_AGGIN.append(" | ");
                    log4jParamters_tAggregateRow_1_AGGIN.append("CHECK_TYPE_OVERFLOW" + " = " + "false");
                log4jParamters_tAggregateRow_1_AGGIN.append(" | ");
                    log4jParamters_tAggregateRow_1_AGGIN.append("CHECK_ULP" + " = " + "false");
                log4jParamters_tAggregateRow_1_AGGIN.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tAggregateRow_1_AGGIN - "  + (log4jParamters_tAggregateRow_1_AGGIN) );
    		}
    	}
    	
        new BytesLimit65535_tAggregateRow_1_AGGIN().limitLog4jByte();

java.util.Collection<AggOperationStruct_tAggregateRow_1> values_tAggregateRow_1 = hash_tAggregateRow_1.values();

globalMap.put("tAggregateRow_1_NB_LINE", values_tAggregateRow_1.size());

                if(log.isInfoEnabled())
            log.info("tAggregateRow_1_AGGIN - "  + ("Retrieving the aggregation results.") );
for(AggOperationStruct_tAggregateRow_1 aggregated_row_tAggregateRow_1 : values_tAggregateRow_1) { // G_AggR_600



 



/**
 * [tAggregateRow_1_AGGIN begin ] stop
 */
	
	/**
	 * [tAggregateRow_1_AGGIN main ] start
	 */

	

	
	
		currentVirtualComponent = "tAggregateRow_1";
	
	currentComponent="tAggregateRow_1_AGGIN";

	

            				    row5.TableName = aggregated_row_tAggregateRow_1.TableName;
            				    
            				    row5.OriginalTableName = aggregated_row_tAggregateRow_1.OriginalTableName;
            				    
    								row5.ColumnList = aggregated_row_tAggregateRow_1.ColumnList_list.toString();
	    						
                if(log.isDebugEnabled())
            log.debug("tAggregateRow_1_AGGIN - "  + ("Operation function: 'list' on the column 'FIELDS'.") );

 


	tos_count_tAggregateRow_1_AGGIN++;

/**
 * [tAggregateRow_1_AGGIN main ] stop
 */

	
	/**
	 * [tFlowToIterate_4 main ] start
	 */

	

	
	
	currentComponent="tFlowToIterate_4";

	

			//row5
			//row5


			
				if(execStat){
					runStat.updateStatOnConnection("row5"+iterateId,1, 1);
				} 
			

		
    			if(log.isTraceEnabled()){
    				log.trace("row5 - " + (row5==null? "": row5.toLogString()));
    			}
    		


    	
                if(log.isTraceEnabled())
            log.trace("tFlowToIterate_4 - "  + ("Set global var, key=row5.TableName, value=")  + (row5.TableName)  + (".") );            
            globalMap.put("row5.TableName", row5.TableName);
    	
                if(log.isTraceEnabled())
            log.trace("tFlowToIterate_4 - "  + ("Set global var, key=row5.OriginalTableName, value=")  + (row5.OriginalTableName)  + (".") );            
            globalMap.put("row5.OriginalTableName", row5.OriginalTableName);
    	
                if(log.isTraceEnabled())
            log.trace("tFlowToIterate_4 - "  + ("Set global var, key=row5.ColumnList, value=")  + (row5.ColumnList)  + (".") );            
            globalMap.put("row5.ColumnList", row5.ColumnList);
    	
 
	   nb_line_tFlowToIterate_4++;  
       counter_tFlowToIterate_4++;
                if(log.isDebugEnabled())
            log.debug("tFlowToIterate_4 - "  + ("Current iteration is: ")  + (counter_tFlowToIterate_4)  + (".") );
       globalMap.put("tFlowToIterate_4_CURRENT_ITERATION", counter_tFlowToIterate_4);
 


	tos_count_tFlowToIterate_4++;

/**
 * [tFlowToIterate_4 main ] stop
 */
	NB_ITERATE_tJava_5++;
	
	
					if(execStat){				
	       				runStat.updateStatOnConnection("meterRowrow2", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("OnComponentOk5", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("OnComponentOk4", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("row9", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("FinalData", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("OnSubjobOk3", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("OnComponentOk8", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("If4", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("OnSubjobOk21", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("If10", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("OnComponentOk7", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("If6", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("If2", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("If3", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("If1", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("If9", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("fileprop", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("If8", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("OnSubjobOk17", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("OnSubjobOk4", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("If7", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("row2", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("row8", 3, 0);
					}           			
				
				if(execStat){
					runStat.updateStatOnConnection("iterate3", 1, "exec" + NB_ITERATE_tJava_5);
					//Thread.sleep(1000);
				}				
			

	
	/**
	 * [tJava_5 begin ] start
	 */

	

	
		
		ok_Hash.put("tJava_5", false);
		start_Hash.put("tJava_5", System.currentTimeMillis());
		
	
	currentComponent="tJava_5";

	
		int tos_count_tJava_5 = 0;
		
    	class BytesLimit65535_tJava_5{
    		public void limitLog4jByte() throws Exception{
    			
    		}
    	}
    	
        new BytesLimit65535_tJava_5().limitLog4jByte();


globalMap.put("columnlist", (String)globalMap.get("row5.ColumnList"));

if (globalMap.get("distributed").equals("")==false) {
	String str;
	str = "DISTRIBUTED BY (" + globalMap.get("distributed") + ");\n";
	str = str + "ALTER TABLE " + (String)globalMap.get("row1.target_schema") +
	"." + ((String)globalMap.get("row1.target_table_name")) +
	" ADD CONSTRAINT uq_" + ((String)globalMap.get("row1.target_table_name")) +
	" UNIQUE (" + globalMap.get("distributed") + ");";
	globalMap.put("distributed", str);
} 

 



/**
 * [tJava_5 begin ] stop
 */
	
	/**
	 * [tJava_5 main ] start
	 */

	

	
	
	currentComponent="tJava_5";

	

 


	tos_count_tJava_5++;

/**
 * [tJava_5 main ] stop
 */
	
	/**
	 * [tJava_5 end ] start
	 */

	

	
	
	currentComponent="tJava_5";

	

 

ok_Hash.put("tJava_5", true);
end_Hash.put("tJava_5", System.currentTimeMillis());

   			if (((String)globalMap.get("row1.update_type")).equals("incremental") || context.getProperty("FORCE_DROP").equals("Y")) {
   				
					if(execStat){   
   	 					runStat.updateStatOnConnection("If10", 0, "true");
					}
				
    			tGreenplumRow_5Process(globalMap);
   			}

			   
   				else{
					if(execStat){   
   	 					runStat.updateStatOnConnection("If10", 0, "false");
					}   	 
   				}
   			if (((String)globalMap.get("row1.update_type")).equals("full") && !context.getProperty("FORCE_DROP").equals("Y")) {
   				
					if(execStat){   
   	 					runStat.updateStatOnConnection("If9", 0, "true");
					}
				
    			tGreenplumRow_7Process(globalMap);
   			}

			   
   				else{
					if(execStat){   
   	 					runStat.updateStatOnConnection("If9", 0, "false");
					}   	 
   				}



/**
 * [tJava_5 end ] stop
 */
						if(execStat){
							runStat.updateStatOnConnection("iterate3", 2, "exec" + NB_ITERATE_tJava_5);
						}				
					







	
	/**
	 * [tAggregateRow_1_AGGIN end ] start
	 */

	

	
	
		currentVirtualComponent = "tAggregateRow_1";
	
	currentComponent="tAggregateRow_1_AGGIN";

	

} // G_AggR_600

 
                if(log.isDebugEnabled())
            log.debug("tAggregateRow_1_AGGIN - "  + ("Done.") );

ok_Hash.put("tAggregateRow_1_AGGIN", true);
end_Hash.put("tAggregateRow_1_AGGIN", System.currentTimeMillis());




/**
 * [tAggregateRow_1_AGGIN end ] stop
 */

	
	/**
	 * [tFlowToIterate_4 end ] start
	 */

	

	
	
	currentComponent="tFlowToIterate_4";

	

globalMap.put("tFlowToIterate_4_NB_LINE",nb_line_tFlowToIterate_4);
			if(execStat){
				if(resourceMap.get("inIterateVComp") == null || !((Boolean)resourceMap.get("inIterateVComp"))){
			 		runStat.updateStatOnConnection("row5"+iterateId,2, 0); 
			 	}
			}
		
 
                if(log.isDebugEnabled())
            log.debug("tFlowToIterate_4 - "  + ("Done.") );

ok_Hash.put("tFlowToIterate_4", true);
end_Hash.put("tFlowToIterate_4", System.currentTimeMillis());




/**
 * [tFlowToIterate_4 end ] stop
 */












				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage());
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
					te.setVirtualComponentName(currentVirtualComponent);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
							//free memory for "tAggregateRow_1_AGGIN"
							globalMap.remove("tAggregateRow_1");
						
							//free memory for "tIterateToFlow_1_AI"
							globalMap.remove("tIterateToFlow_1");
						
				try{
					
	
	/**
	 * [tIterateToFlow_1_AI finally ] start
	 */

	

	
	
		currentVirtualComponent = "tIterateToFlow_1";
	
	currentComponent="tIterateToFlow_1_AI";

	

 



/**
 * [tIterateToFlow_1_AI finally ] stop
 */

	
	/**
	 * [tMap_2 finally ] start
	 */

	

	
	
	currentComponent="tMap_2";

	

 



/**
 * [tMap_2 finally ] stop
 */

	
	/**
	 * [tAggregateRow_1_AGGOUT finally ] start
	 */

	

	
	
		currentVirtualComponent = "tAggregateRow_1";
	
	currentComponent="tAggregateRow_1_AGGOUT";

	

 



/**
 * [tAggregateRow_1_AGGOUT finally ] stop
 */

	
	/**
	 * [tAggregateRow_1_AGGIN finally ] start
	 */

	

	
	
		currentVirtualComponent = "tAggregateRow_1";
	
	currentComponent="tAggregateRow_1_AGGIN";

	

 



/**
 * [tAggregateRow_1_AGGIN finally ] stop
 */

	
	/**
	 * [tFlowToIterate_4 finally ] start
	 */

	

	
	
	currentComponent="tFlowToIterate_4";

	

 



/**
 * [tFlowToIterate_4 finally ] stop
 */

	
	/**
	 * [tJava_5 finally ] start
	 */

	

	
	
	currentComponent="tJava_5";

	

 



/**
 * [tJava_5 finally ] stop
 */















				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tIterateToFlow_1_AI_SUBPROCESS_STATE", 1);
	}
	


public static class row_talendLogs_LOGSStruct implements routines.system.IPersistableRow<row_talendLogs_LOGSStruct> {
    final static byte[] commonByteArrayLock_AWS_DEV_TALEND_INGESTION_FRAMEWORK_AS400_to_greenplum_with_GPLoad = new byte[0];
    static byte[] commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_AS400_to_greenplum_with_GPLoad = new byte[0];

	
			    public java.util.Date moment;

				public java.util.Date getMoment () {
					return this.moment;
				}
				
			    public String pid;

				public String getPid () {
					return this.pid;
				}
				
			    public String root_pid;

				public String getRoot_pid () {
					return this.root_pid;
				}
				
			    public String father_pid;

				public String getFather_pid () {
					return this.father_pid;
				}
				
			    public String project;

				public String getProject () {
					return this.project;
				}
				
			    public String job;

				public String getJob () {
					return this.job;
				}
				
			    public String context;

				public String getContext () {
					return this.context;
				}
				
			    public Integer priority;

				public Integer getPriority () {
					return this.priority;
				}
				
			    public String type;

				public String getType () {
					return this.type;
				}
				
			    public String origin;

				public String getOrigin () {
					return this.origin;
				}
				
			    public String message;

				public String getMessage () {
					return this.message;
				}
				
			    public Integer code;

				public Integer getCode () {
					return this.code;
				}
				



	private java.util.Date readDate(ObjectInputStream dis) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(dis.readLong());
		}
		return dateReturn;
	}

    private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException{
		if(date1 == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeLong(date1.getTime());
    	}
    }

	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_AS400_to_greenplum_with_GPLoad.length) {
				if(length < 1024 && commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_AS400_to_greenplum_with_GPLoad.length == 0) {
   					commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_AS400_to_greenplum_with_GPLoad = new byte[1024];
				} else {
   					commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_AS400_to_greenplum_with_GPLoad = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_AS400_to_greenplum_with_GPLoad, 0, length);
			strReturn = new String(commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_AS400_to_greenplum_with_GPLoad, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
	private Integer readInteger(ObjectInputStream dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}

	private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException{
		if(intNum == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeInt(intNum);
    	}
	}

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_AWS_DEV_TALEND_INGESTION_FRAMEWORK_AS400_to_greenplum_with_GPLoad) {

        	try {

        		int length = 0;
		
					this.moment = readDate(dis);
					
					this.pid = readString(dis);
					
					this.root_pid = readString(dis);
					
					this.father_pid = readString(dis);
					
					this.project = readString(dis);
					
					this.job = readString(dis);
					
					this.context = readString(dis);
					
						this.priority = readInteger(dis);
					
					this.type = readString(dis);
					
					this.origin = readString(dis);
					
					this.message = readString(dis);
					
						this.code = readInteger(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// java.util.Date
				
						writeDate(this.moment,dos);
					
					// String
				
						writeString(this.pid,dos);
					
					// String
				
						writeString(this.root_pid,dos);
					
					// String
				
						writeString(this.father_pid,dos);
					
					// String
				
						writeString(this.project,dos);
					
					// String
				
						writeString(this.job,dos);
					
					// String
				
						writeString(this.context,dos);
					
					// Integer
				
						writeInteger(this.priority,dos);
					
					// String
				
						writeString(this.type,dos);
					
					// String
				
						writeString(this.origin,dos);
					
					// String
				
						writeString(this.message,dos);
					
					// Integer
				
						writeInteger(this.code,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("moment="+String.valueOf(moment));
		sb.append(",pid="+pid);
		sb.append(",root_pid="+root_pid);
		sb.append(",father_pid="+father_pid);
		sb.append(",project="+project);
		sb.append(",job="+job);
		sb.append(",context="+context);
		sb.append(",priority="+String.valueOf(priority));
		sb.append(",type="+type);
		sb.append(",origin="+origin);
		sb.append(",message="+message);
		sb.append(",code="+String.valueOf(code));
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				if(moment == null){
        					sb.append("<null>");
        				}else{
            				sb.append(moment);
            			}
            		
        			sb.append("|");
        		
        				if(pid == null){
        					sb.append("<null>");
        				}else{
            				sb.append(pid);
            			}
            		
        			sb.append("|");
        		
        				if(root_pid == null){
        					sb.append("<null>");
        				}else{
            				sb.append(root_pid);
            			}
            		
        			sb.append("|");
        		
        				if(father_pid == null){
        					sb.append("<null>");
        				}else{
            				sb.append(father_pid);
            			}
            		
        			sb.append("|");
        		
        				if(project == null){
        					sb.append("<null>");
        				}else{
            				sb.append(project);
            			}
            		
        			sb.append("|");
        		
        				if(job == null){
        					sb.append("<null>");
        				}else{
            				sb.append(job);
            			}
            		
        			sb.append("|");
        		
        				if(context == null){
        					sb.append("<null>");
        				}else{
            				sb.append(context);
            			}
            		
        			sb.append("|");
        		
        				if(priority == null){
        					sb.append("<null>");
        				}else{
            				sb.append(priority);
            			}
            		
        			sb.append("|");
        		
        				if(type == null){
        					sb.append("<null>");
        				}else{
            				sb.append(type);
            			}
            		
        			sb.append("|");
        		
        				if(origin == null){
        					sb.append("<null>");
        				}else{
            				sb.append(origin);
            			}
            		
        			sb.append("|");
        		
        				if(message == null){
        					sb.append("<null>");
        				}else{
            				sb.append(message);
            			}
            		
        			sb.append("|");
        		
        				if(code == null){
        					sb.append("<null>");
        				}else{
            				sb.append(code);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(row_talendLogs_LOGSStruct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}
public void talendLogs_LOGSProcess(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("talendLogs_LOGS_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
		String currentVirtualComponent = null;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;



		row_talendLogs_LOGSStruct row_talendLogs_LOGS = new row_talendLogs_LOGSStruct();




	
	/**
	 * [talendLogs_CONSOLE begin ] start
	 */

	

	
		
		ok_Hash.put("talendLogs_CONSOLE", false);
		start_Hash.put("talendLogs_CONSOLE", System.currentTimeMillis());
		
	
		currentVirtualComponent = "talendLogs_CONSOLE";
	
	currentComponent="talendLogs_CONSOLE";

	
			if (execStat) {
				if(resourceMap.get("inIterateVComp") == null){
					
						runStat.updateStatOnConnection("Main" + iterateId, 0, 0);
					
				}
			} 

		
		int tos_count_talendLogs_CONSOLE = 0;
		
                if(log.isDebugEnabled())
            log.debug("talendLogs_CONSOLE - "  + ("Start to work.") );
    	class BytesLimit65535_talendLogs_CONSOLE{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_talendLogs_CONSOLE = new StringBuilder();
            log4jParamters_talendLogs_CONSOLE.append("Parameters:");
                    log4jParamters_talendLogs_CONSOLE.append("BASIC_MODE" + " = " + "true");
                log4jParamters_talendLogs_CONSOLE.append(" | ");
                    log4jParamters_talendLogs_CONSOLE.append("TABLE_PRINT" + " = " + "false");
                log4jParamters_talendLogs_CONSOLE.append(" | ");
                    log4jParamters_talendLogs_CONSOLE.append("VERTICAL" + " = " + "false");
                log4jParamters_talendLogs_CONSOLE.append(" | ");
                    log4jParamters_talendLogs_CONSOLE.append("FIELDSEPARATOR" + " = " + "\"|\"");
                log4jParamters_talendLogs_CONSOLE.append(" | ");
                    log4jParamters_talendLogs_CONSOLE.append("PRINT_HEADER" + " = " + "false");
                log4jParamters_talendLogs_CONSOLE.append(" | ");
                    log4jParamters_talendLogs_CONSOLE.append("PRINT_UNIQUE_NAME" + " = " + "false");
                log4jParamters_talendLogs_CONSOLE.append(" | ");
                    log4jParamters_talendLogs_CONSOLE.append("PRINT_COLNAMES" + " = " + "false");
                log4jParamters_talendLogs_CONSOLE.append(" | ");
                    log4jParamters_talendLogs_CONSOLE.append("USE_FIXED_LENGTH" + " = " + "false");
                log4jParamters_talendLogs_CONSOLE.append(" | ");
                    log4jParamters_talendLogs_CONSOLE.append("PRINT_CONTENT_WITH_LOG4J" + " = " + "true");
                log4jParamters_talendLogs_CONSOLE.append(" | ");
                if(log.isDebugEnabled())
            log.debug("talendLogs_CONSOLE - "  + (log4jParamters_talendLogs_CONSOLE) );
    		}
    	}
    	
        new BytesLimit65535_talendLogs_CONSOLE().limitLog4jByte();

	///////////////////////
	
		final String OUTPUT_FIELD_SEPARATOR_talendLogs_CONSOLE = "|";
		java.io.PrintStream consoleOut_talendLogs_CONSOLE = null;	

 		StringBuilder strBuffer_talendLogs_CONSOLE = null;
		int nb_line_talendLogs_CONSOLE = 0;
///////////////////////    			



 



/**
 * [talendLogs_CONSOLE begin ] stop
 */



	
	/**
	 * [talendLogs_LOGS begin ] start
	 */

	

	
		
		ok_Hash.put("talendLogs_LOGS", false);
		start_Hash.put("talendLogs_LOGS", System.currentTimeMillis());
		
	
		currentVirtualComponent = "talendLogs_LOGS";
	
	currentComponent="talendLogs_LOGS";

	
		int tos_count_talendLogs_LOGS = 0;
		
                if(log.isDebugEnabled())
            log.debug("talendLogs_LOGS - "  + ("Start to work.") );
    	class BytesLimit65535_talendLogs_LOGS{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_talendLogs_LOGS = new StringBuilder();
            log4jParamters_talendLogs_LOGS.append("Parameters:");
                    log4jParamters_talendLogs_LOGS.append("CATCH_JAVA_EXCEPTION" + " = " + "true");
                log4jParamters_talendLogs_LOGS.append(" | ");
                    log4jParamters_talendLogs_LOGS.append("CATCH_TDIE" + " = " + "true");
                log4jParamters_talendLogs_LOGS.append(" | ");
                    log4jParamters_talendLogs_LOGS.append("CATCH_TWARN" + " = " + "true");
                log4jParamters_talendLogs_LOGS.append(" | ");
                    log4jParamters_talendLogs_LOGS.append("CATCH_TACTIONFAILURE" + " = " + "true");
                log4jParamters_talendLogs_LOGS.append(" | ");
                if(log.isDebugEnabled())
            log.debug("talendLogs_LOGS - "  + (log4jParamters_talendLogs_LOGS) );
    		}
    	}
    	
        new BytesLimit65535_talendLogs_LOGS().limitLog4jByte();

	for (LogCatcherUtils.LogCatcherMessage lcm : talendLogs_LOGS.getMessages()) {
		row_talendLogs_LOGS.type = lcm.getType();
		row_talendLogs_LOGS.origin = (lcm.getOrigin()==null || lcm.getOrigin().length()<1 ? null : lcm.getOrigin());
		row_talendLogs_LOGS.priority = lcm.getPriority();
		row_talendLogs_LOGS.message = lcm.getMessage();
		row_talendLogs_LOGS.code = lcm.getCode();
		
		row_talendLogs_LOGS.moment = java.util.Calendar.getInstance().getTime();
	
    	row_talendLogs_LOGS.pid = pid;
		row_talendLogs_LOGS.root_pid = rootPid;
		row_talendLogs_LOGS.father_pid = fatherPid;
	
    	row_talendLogs_LOGS.project = projectName;
    	row_talendLogs_LOGS.job = jobName;
    	row_talendLogs_LOGS.context = contextStr;
    		
 



/**
 * [talendLogs_LOGS begin ] stop
 */
	
	/**
	 * [talendLogs_LOGS main ] start
	 */

	

	
	
		currentVirtualComponent = "talendLogs_LOGS";
	
	currentComponent="talendLogs_LOGS";

	

 


	tos_count_talendLogs_LOGS++;

/**
 * [talendLogs_LOGS main ] stop
 */

	
	/**
	 * [talendLogs_CONSOLE main ] start
	 */

	

	
	
		currentVirtualComponent = "talendLogs_CONSOLE";
	
	currentComponent="talendLogs_CONSOLE";

	

			//Main
			//row_talendLogs_LOGS


			
				if(execStat){
					runStat.updateStatOnConnection("Main"+iterateId,1, 1);
				} 
			

		
///////////////////////		
						



				strBuffer_talendLogs_CONSOLE = new StringBuilder();




   				
	    		if(row_talendLogs_LOGS.moment != null) { //              
                    							
       
				strBuffer_talendLogs_CONSOLE.append(
								FormatterUtils.format_Date(row_talendLogs_LOGS.moment, "yyyy-MM-dd HH:mm:ss")				
				);


							
	    		} //  			

    			strBuffer_talendLogs_CONSOLE.append("|");
    			


   				
	    		if(row_talendLogs_LOGS.pid != null) { //              
                    							
       
				strBuffer_talendLogs_CONSOLE.append(
				                String.valueOf(row_talendLogs_LOGS.pid)							
				);


							
	    		} //  			

    			strBuffer_talendLogs_CONSOLE.append("|");
    			


   				
	    		if(row_talendLogs_LOGS.root_pid != null) { //              
                    							
       
				strBuffer_talendLogs_CONSOLE.append(
				                String.valueOf(row_talendLogs_LOGS.root_pid)							
				);


							
	    		} //  			

    			strBuffer_talendLogs_CONSOLE.append("|");
    			


   				
	    		if(row_talendLogs_LOGS.father_pid != null) { //              
                    							
       
				strBuffer_talendLogs_CONSOLE.append(
				                String.valueOf(row_talendLogs_LOGS.father_pid)							
				);


							
	    		} //  			

    			strBuffer_talendLogs_CONSOLE.append("|");
    			


   				
	    		if(row_talendLogs_LOGS.project != null) { //              
                    							
       
				strBuffer_talendLogs_CONSOLE.append(
				                String.valueOf(row_talendLogs_LOGS.project)							
				);


							
	    		} //  			

    			strBuffer_talendLogs_CONSOLE.append("|");
    			


   				
	    		if(row_talendLogs_LOGS.job != null) { //              
                    							
       
				strBuffer_talendLogs_CONSOLE.append(
				                String.valueOf(row_talendLogs_LOGS.job)							
				);


							
	    		} //  			

    			strBuffer_talendLogs_CONSOLE.append("|");
    			


   				
	    		if(row_talendLogs_LOGS.context != null) { //              
                    							
       
				strBuffer_talendLogs_CONSOLE.append(
				                String.valueOf(row_talendLogs_LOGS.context)							
				);


							
	    		} //  			

    			strBuffer_talendLogs_CONSOLE.append("|");
    			


   				
	    		if(row_talendLogs_LOGS.priority != null) { //              
                    							
       
				strBuffer_talendLogs_CONSOLE.append(
				                String.valueOf(row_talendLogs_LOGS.priority)							
				);


							
	    		} //  			

    			strBuffer_talendLogs_CONSOLE.append("|");
    			


   				
	    		if(row_talendLogs_LOGS.type != null) { //              
                    							
       
				strBuffer_talendLogs_CONSOLE.append(
				                String.valueOf(row_talendLogs_LOGS.type)							
				);


							
	    		} //  			

    			strBuffer_talendLogs_CONSOLE.append("|");
    			


   				
	    		if(row_talendLogs_LOGS.origin != null) { //              
                    							
       
				strBuffer_talendLogs_CONSOLE.append(
				                String.valueOf(row_talendLogs_LOGS.origin)							
				);


							
	    		} //  			

    			strBuffer_talendLogs_CONSOLE.append("|");
    			


   				
	    		if(row_talendLogs_LOGS.message != null) { //              
                    							
       
				strBuffer_talendLogs_CONSOLE.append(
				                String.valueOf(row_talendLogs_LOGS.message)							
				);


							
	    		} //  			

    			strBuffer_talendLogs_CONSOLE.append("|");
    			


   				
	    		if(row_talendLogs_LOGS.code != null) { //              
                    							
       
				strBuffer_talendLogs_CONSOLE.append(
				                String.valueOf(row_talendLogs_LOGS.code)							
				);


							
	    		} //  			
 

                    if (globalMap.get("tLogRow_CONSOLE")!=null)
                    {
                    	consoleOut_talendLogs_CONSOLE = (java.io.PrintStream) globalMap.get("tLogRow_CONSOLE");
                    }
                    else
                    {
                    	consoleOut_talendLogs_CONSOLE = new java.io.PrintStream(new java.io.BufferedOutputStream(System.out));
                    	globalMap.put("tLogRow_CONSOLE",consoleOut_talendLogs_CONSOLE);
                    }
                    	log.info("talendLogs_CONSOLE - Content of row "+(nb_line_talendLogs_CONSOLE+1)+": " + strBuffer_talendLogs_CONSOLE.toString());
                    consoleOut_talendLogs_CONSOLE.println(strBuffer_talendLogs_CONSOLE.toString());
                    consoleOut_talendLogs_CONSOLE.flush();
                    nb_line_talendLogs_CONSOLE++;
//////

//////                    
                    
///////////////////////    			

 


	tos_count_talendLogs_CONSOLE++;

/**
 * [talendLogs_CONSOLE main ] stop
 */



	
	/**
	 * [talendLogs_LOGS end ] start
	 */

	

	
	
		currentVirtualComponent = "talendLogs_LOGS";
	
	currentComponent="talendLogs_LOGS";

	
	}
 
                if(log.isDebugEnabled())
            log.debug("talendLogs_LOGS - "  + ("Done.") );

ok_Hash.put("talendLogs_LOGS", true);
end_Hash.put("talendLogs_LOGS", System.currentTimeMillis());




/**
 * [talendLogs_LOGS end ] stop
 */

	
	/**
	 * [talendLogs_CONSOLE end ] start
	 */

	

	
	
		currentVirtualComponent = "talendLogs_CONSOLE";
	
	currentComponent="talendLogs_CONSOLE";

	


//////
//////
globalMap.put("talendLogs_CONSOLE_NB_LINE",nb_line_talendLogs_CONSOLE);
                if(log.isInfoEnabled())
            log.info("talendLogs_CONSOLE - "  + ("Printed row count: ")  + (nb_line_talendLogs_CONSOLE)  + (".") );

///////////////////////    			

			if(execStat){
				if(resourceMap.get("inIterateVComp") == null || !((Boolean)resourceMap.get("inIterateVComp"))){
			 		runStat.updateStatOnConnection("Main"+iterateId,2, 0); 
			 	}
			}
		
 
                if(log.isDebugEnabled())
            log.debug("talendLogs_CONSOLE - "  + ("Done.") );

ok_Hash.put("talendLogs_CONSOLE", true);
end_Hash.put("talendLogs_CONSOLE", System.currentTimeMillis());




/**
 * [talendLogs_CONSOLE end ] stop
 */



				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage());
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
					te.setVirtualComponentName(currentVirtualComponent);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [talendLogs_LOGS finally ] start
	 */

	

	
	
		currentVirtualComponent = "talendLogs_LOGS";
	
	currentComponent="talendLogs_LOGS";

	

 



/**
 * [talendLogs_LOGS finally ] stop
 */

	
	/**
	 * [talendLogs_CONSOLE finally ] start
	 */

	

	
	
		currentVirtualComponent = "talendLogs_CONSOLE";
	
	currentComponent="talendLogs_CONSOLE";

	

 



/**
 * [talendLogs_CONSOLE finally ] stop
 */



				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("talendLogs_LOGS_SUBPROCESS_STATE", 1);
	}
	


public static class row_talendStats_STATSStruct implements routines.system.IPersistableRow<row_talendStats_STATSStruct> {
    final static byte[] commonByteArrayLock_AWS_DEV_TALEND_INGESTION_FRAMEWORK_AS400_to_greenplum_with_GPLoad = new byte[0];
    static byte[] commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_AS400_to_greenplum_with_GPLoad = new byte[0];

	
			    public java.util.Date moment;

				public java.util.Date getMoment () {
					return this.moment;
				}
				
			    public String pid;

				public String getPid () {
					return this.pid;
				}
				
			    public String father_pid;

				public String getFather_pid () {
					return this.father_pid;
				}
				
			    public String root_pid;

				public String getRoot_pid () {
					return this.root_pid;
				}
				
			    public Long system_pid;

				public Long getSystem_pid () {
					return this.system_pid;
				}
				
			    public String project;

				public String getProject () {
					return this.project;
				}
				
			    public String job;

				public String getJob () {
					return this.job;
				}
				
			    public String job_repository_id;

				public String getJob_repository_id () {
					return this.job_repository_id;
				}
				
			    public String job_version;

				public String getJob_version () {
					return this.job_version;
				}
				
			    public String context;

				public String getContext () {
					return this.context;
				}
				
			    public String origin;

				public String getOrigin () {
					return this.origin;
				}
				
			    public String message_type;

				public String getMessage_type () {
					return this.message_type;
				}
				
			    public String message;

				public String getMessage () {
					return this.message;
				}
				
			    public Long duration;

				public Long getDuration () {
					return this.duration;
				}
				



	private java.util.Date readDate(ObjectInputStream dis) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(dis.readLong());
		}
		return dateReturn;
	}

    private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException{
		if(date1 == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeLong(date1.getTime());
    	}
    }

	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_AS400_to_greenplum_with_GPLoad.length) {
				if(length < 1024 && commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_AS400_to_greenplum_with_GPLoad.length == 0) {
   					commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_AS400_to_greenplum_with_GPLoad = new byte[1024];
				} else {
   					commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_AS400_to_greenplum_with_GPLoad = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_AS400_to_greenplum_with_GPLoad, 0, length);
			strReturn = new String(commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_AS400_to_greenplum_with_GPLoad, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_AWS_DEV_TALEND_INGESTION_FRAMEWORK_AS400_to_greenplum_with_GPLoad) {

        	try {

        		int length = 0;
		
					this.moment = readDate(dis);
					
					this.pid = readString(dis);
					
					this.father_pid = readString(dis);
					
					this.root_pid = readString(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.system_pid = null;
           				} else {
           			    	this.system_pid = dis.readLong();
           				}
					
					this.project = readString(dis);
					
					this.job = readString(dis);
					
					this.job_repository_id = readString(dis);
					
					this.job_version = readString(dis);
					
					this.context = readString(dis);
					
					this.origin = readString(dis);
					
					this.message_type = readString(dis);
					
					this.message = readString(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.duration = null;
           				} else {
           			    	this.duration = dis.readLong();
           				}
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// java.util.Date
				
						writeDate(this.moment,dos);
					
					// String
				
						writeString(this.pid,dos);
					
					// String
				
						writeString(this.father_pid,dos);
					
					// String
				
						writeString(this.root_pid,dos);
					
					// Long
				
						if(this.system_pid == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeLong(this.system_pid);
		            	}
					
					// String
				
						writeString(this.project,dos);
					
					// String
				
						writeString(this.job,dos);
					
					// String
				
						writeString(this.job_repository_id,dos);
					
					// String
				
						writeString(this.job_version,dos);
					
					// String
				
						writeString(this.context,dos);
					
					// String
				
						writeString(this.origin,dos);
					
					// String
				
						writeString(this.message_type,dos);
					
					// String
				
						writeString(this.message,dos);
					
					// Long
				
						if(this.duration == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeLong(this.duration);
		            	}
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("moment="+String.valueOf(moment));
		sb.append(",pid="+pid);
		sb.append(",father_pid="+father_pid);
		sb.append(",root_pid="+root_pid);
		sb.append(",system_pid="+String.valueOf(system_pid));
		sb.append(",project="+project);
		sb.append(",job="+job);
		sb.append(",job_repository_id="+job_repository_id);
		sb.append(",job_version="+job_version);
		sb.append(",context="+context);
		sb.append(",origin="+origin);
		sb.append(",message_type="+message_type);
		sb.append(",message="+message);
		sb.append(",duration="+String.valueOf(duration));
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				if(moment == null){
        					sb.append("<null>");
        				}else{
            				sb.append(moment);
            			}
            		
        			sb.append("|");
        		
        				if(pid == null){
        					sb.append("<null>");
        				}else{
            				sb.append(pid);
            			}
            		
        			sb.append("|");
        		
        				if(father_pid == null){
        					sb.append("<null>");
        				}else{
            				sb.append(father_pid);
            			}
            		
        			sb.append("|");
        		
        				if(root_pid == null){
        					sb.append("<null>");
        				}else{
            				sb.append(root_pid);
            			}
            		
        			sb.append("|");
        		
        				if(system_pid == null){
        					sb.append("<null>");
        				}else{
            				sb.append(system_pid);
            			}
            		
        			sb.append("|");
        		
        				if(project == null){
        					sb.append("<null>");
        				}else{
            				sb.append(project);
            			}
            		
        			sb.append("|");
        		
        				if(job == null){
        					sb.append("<null>");
        				}else{
            				sb.append(job);
            			}
            		
        			sb.append("|");
        		
        				if(job_repository_id == null){
        					sb.append("<null>");
        				}else{
            				sb.append(job_repository_id);
            			}
            		
        			sb.append("|");
        		
        				if(job_version == null){
        					sb.append("<null>");
        				}else{
            				sb.append(job_version);
            			}
            		
        			sb.append("|");
        		
        				if(context == null){
        					sb.append("<null>");
        				}else{
            				sb.append(context);
            			}
            		
        			sb.append("|");
        		
        				if(origin == null){
        					sb.append("<null>");
        				}else{
            				sb.append(origin);
            			}
            		
        			sb.append("|");
        		
        				if(message_type == null){
        					sb.append("<null>");
        				}else{
            				sb.append(message_type);
            			}
            		
        			sb.append("|");
        		
        				if(message == null){
        					sb.append("<null>");
        				}else{
            				sb.append(message);
            			}
            		
        			sb.append("|");
        		
        				if(duration == null){
        					sb.append("<null>");
        				}else{
            				sb.append(duration);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(row_talendStats_STATSStruct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}
public void talendStats_STATSProcess(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("talendStats_STATS_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
		String currentVirtualComponent = null;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;



		row_talendStats_STATSStruct row_talendStats_STATS = new row_talendStats_STATSStruct();




	
	/**
	 * [talendStats_CONSOLE begin ] start
	 */

	

	
		
		ok_Hash.put("talendStats_CONSOLE", false);
		start_Hash.put("talendStats_CONSOLE", System.currentTimeMillis());
		
	
		currentVirtualComponent = "talendStats_CONSOLE";
	
	currentComponent="talendStats_CONSOLE";

	
			if (execStat) {
				if(resourceMap.get("inIterateVComp") == null){
					
						runStat.updateStatOnConnection("Main" + iterateId, 0, 0);
					
				}
			} 

		
		int tos_count_talendStats_CONSOLE = 0;
		
                if(log.isDebugEnabled())
            log.debug("talendStats_CONSOLE - "  + ("Start to work.") );
    	class BytesLimit65535_talendStats_CONSOLE{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_talendStats_CONSOLE = new StringBuilder();
            log4jParamters_talendStats_CONSOLE.append("Parameters:");
                    log4jParamters_talendStats_CONSOLE.append("BASIC_MODE" + " = " + "true");
                log4jParamters_talendStats_CONSOLE.append(" | ");
                    log4jParamters_talendStats_CONSOLE.append("TABLE_PRINT" + " = " + "false");
                log4jParamters_talendStats_CONSOLE.append(" | ");
                    log4jParamters_talendStats_CONSOLE.append("VERTICAL" + " = " + "false");
                log4jParamters_talendStats_CONSOLE.append(" | ");
                    log4jParamters_talendStats_CONSOLE.append("FIELDSEPARATOR" + " = " + "\"|\"");
                log4jParamters_talendStats_CONSOLE.append(" | ");
                    log4jParamters_talendStats_CONSOLE.append("PRINT_HEADER" + " = " + "false");
                log4jParamters_talendStats_CONSOLE.append(" | ");
                    log4jParamters_talendStats_CONSOLE.append("PRINT_UNIQUE_NAME" + " = " + "false");
                log4jParamters_talendStats_CONSOLE.append(" | ");
                    log4jParamters_talendStats_CONSOLE.append("PRINT_COLNAMES" + " = " + "false");
                log4jParamters_talendStats_CONSOLE.append(" | ");
                    log4jParamters_talendStats_CONSOLE.append("USE_FIXED_LENGTH" + " = " + "false");
                log4jParamters_talendStats_CONSOLE.append(" | ");
                    log4jParamters_talendStats_CONSOLE.append("PRINT_CONTENT_WITH_LOG4J" + " = " + "true");
                log4jParamters_talendStats_CONSOLE.append(" | ");
                if(log.isDebugEnabled())
            log.debug("talendStats_CONSOLE - "  + (log4jParamters_talendStats_CONSOLE) );
    		}
    	}
    	
        new BytesLimit65535_talendStats_CONSOLE().limitLog4jByte();

	///////////////////////
	
		final String OUTPUT_FIELD_SEPARATOR_talendStats_CONSOLE = "|";
		java.io.PrintStream consoleOut_talendStats_CONSOLE = null;	

 		StringBuilder strBuffer_talendStats_CONSOLE = null;
		int nb_line_talendStats_CONSOLE = 0;
///////////////////////    			



 



/**
 * [talendStats_CONSOLE begin ] stop
 */



	
	/**
	 * [talendStats_STATS begin ] start
	 */

	

	
		
		ok_Hash.put("talendStats_STATS", false);
		start_Hash.put("talendStats_STATS", System.currentTimeMillis());
		
	
		currentVirtualComponent = "talendStats_STATS";
	
	currentComponent="talendStats_STATS";

	
		int tos_count_talendStats_STATS = 0;
		
                if(log.isDebugEnabled())
            log.debug("talendStats_STATS - "  + ("Start to work.") );
    	class BytesLimit65535_talendStats_STATS{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_talendStats_STATS = new StringBuilder();
            log4jParamters_talendStats_STATS.append("Parameters:");
                if(log.isDebugEnabled())
            log.debug("talendStats_STATS - "  + (log4jParamters_talendStats_STATS) );
    		}
    	}
    	
        new BytesLimit65535_talendStats_STATS().limitLog4jByte();

	for (StatCatcherUtils.StatCatcherMessage scm : talendStats_STATS.getMessages()) {
		row_talendStats_STATS.pid = pid;
		row_talendStats_STATS.root_pid = rootPid;
		row_talendStats_STATS.father_pid = fatherPid;	
    	row_talendStats_STATS.project = projectName;
    	row_talendStats_STATS.job = jobName;
    	row_talendStats_STATS.context = contextStr;
		row_talendStats_STATS.origin = (scm.getOrigin()==null || scm.getOrigin().length()<1 ? null : scm.getOrigin());
		row_talendStats_STATS.message = scm.getMessage();
		row_talendStats_STATS.duration = scm.getDuration();
		row_talendStats_STATS.moment = scm.getMoment();
		row_talendStats_STATS.message_type = scm.getMessageType();
		row_talendStats_STATS.job_version = scm.getJobVersion();
		row_talendStats_STATS.job_repository_id = scm.getJobId();
		row_talendStats_STATS.system_pid = scm.getSystemPid();

 



/**
 * [talendStats_STATS begin ] stop
 */
	
	/**
	 * [talendStats_STATS main ] start
	 */

	

	
	
		currentVirtualComponent = "talendStats_STATS";
	
	currentComponent="talendStats_STATS";

	

 


	tos_count_talendStats_STATS++;

/**
 * [talendStats_STATS main ] stop
 */

	
	/**
	 * [talendStats_CONSOLE main ] start
	 */

	

	
	
		currentVirtualComponent = "talendStats_CONSOLE";
	
	currentComponent="talendStats_CONSOLE";

	

			//Main
			//row_talendStats_STATS


			
				if(execStat){
					runStat.updateStatOnConnection("Main"+iterateId,1, 1);
				} 
			

		
///////////////////////		
						



				strBuffer_talendStats_CONSOLE = new StringBuilder();




   				
	    		if(row_talendStats_STATS.moment != null) { //              
                    							
       
				strBuffer_talendStats_CONSOLE.append(
								FormatterUtils.format_Date(row_talendStats_STATS.moment, "yyyy-MM-dd HH:mm:ss")				
				);


							
	    		} //  			

    			strBuffer_talendStats_CONSOLE.append("|");
    			


   				
	    		if(row_talendStats_STATS.pid != null) { //              
                    							
       
				strBuffer_talendStats_CONSOLE.append(
				                String.valueOf(row_talendStats_STATS.pid)							
				);


							
	    		} //  			

    			strBuffer_talendStats_CONSOLE.append("|");
    			


   				
	    		if(row_talendStats_STATS.father_pid != null) { //              
                    							
       
				strBuffer_talendStats_CONSOLE.append(
				                String.valueOf(row_talendStats_STATS.father_pid)							
				);


							
	    		} //  			

    			strBuffer_talendStats_CONSOLE.append("|");
    			


   				
	    		if(row_talendStats_STATS.root_pid != null) { //              
                    							
       
				strBuffer_talendStats_CONSOLE.append(
				                String.valueOf(row_talendStats_STATS.root_pid)							
				);


							
	    		} //  			

    			strBuffer_talendStats_CONSOLE.append("|");
    			


   				
	    		if(row_talendStats_STATS.system_pid != null) { //              
                    							
       
				strBuffer_talendStats_CONSOLE.append(
				                String.valueOf(row_talendStats_STATS.system_pid)							
				);


							
	    		} //  			

    			strBuffer_talendStats_CONSOLE.append("|");
    			


   				
	    		if(row_talendStats_STATS.project != null) { //              
                    							
       
				strBuffer_talendStats_CONSOLE.append(
				                String.valueOf(row_talendStats_STATS.project)							
				);


							
	    		} //  			

    			strBuffer_talendStats_CONSOLE.append("|");
    			


   				
	    		if(row_talendStats_STATS.job != null) { //              
                    							
       
				strBuffer_talendStats_CONSOLE.append(
				                String.valueOf(row_talendStats_STATS.job)							
				);


							
	    		} //  			

    			strBuffer_talendStats_CONSOLE.append("|");
    			


   				
	    		if(row_talendStats_STATS.job_repository_id != null) { //              
                    							
       
				strBuffer_talendStats_CONSOLE.append(
				                String.valueOf(row_talendStats_STATS.job_repository_id)							
				);


							
	    		} //  			

    			strBuffer_talendStats_CONSOLE.append("|");
    			


   				
	    		if(row_talendStats_STATS.job_version != null) { //              
                    							
       
				strBuffer_talendStats_CONSOLE.append(
				                String.valueOf(row_talendStats_STATS.job_version)							
				);


							
	    		} //  			

    			strBuffer_talendStats_CONSOLE.append("|");
    			


   				
	    		if(row_talendStats_STATS.context != null) { //              
                    							
       
				strBuffer_talendStats_CONSOLE.append(
				                String.valueOf(row_talendStats_STATS.context)							
				);


							
	    		} //  			

    			strBuffer_talendStats_CONSOLE.append("|");
    			


   				
	    		if(row_talendStats_STATS.origin != null) { //              
                    							
       
				strBuffer_talendStats_CONSOLE.append(
				                String.valueOf(row_talendStats_STATS.origin)							
				);


							
	    		} //  			

    			strBuffer_talendStats_CONSOLE.append("|");
    			


   				
	    		if(row_talendStats_STATS.message_type != null) { //              
                    							
       
				strBuffer_talendStats_CONSOLE.append(
				                String.valueOf(row_talendStats_STATS.message_type)							
				);


							
	    		} //  			

    			strBuffer_talendStats_CONSOLE.append("|");
    			


   				
	    		if(row_talendStats_STATS.message != null) { //              
                    							
       
				strBuffer_talendStats_CONSOLE.append(
				                String.valueOf(row_talendStats_STATS.message)							
				);


							
	    		} //  			

    			strBuffer_talendStats_CONSOLE.append("|");
    			


   				
	    		if(row_talendStats_STATS.duration != null) { //              
                    							
       
				strBuffer_talendStats_CONSOLE.append(
				                String.valueOf(row_talendStats_STATS.duration)							
				);


							
	    		} //  			
 

                    if (globalMap.get("tLogRow_CONSOLE")!=null)
                    {
                    	consoleOut_talendStats_CONSOLE = (java.io.PrintStream) globalMap.get("tLogRow_CONSOLE");
                    }
                    else
                    {
                    	consoleOut_talendStats_CONSOLE = new java.io.PrintStream(new java.io.BufferedOutputStream(System.out));
                    	globalMap.put("tLogRow_CONSOLE",consoleOut_talendStats_CONSOLE);
                    }
                    	log.info("talendStats_CONSOLE - Content of row "+(nb_line_talendStats_CONSOLE+1)+": " + strBuffer_talendStats_CONSOLE.toString());
                    consoleOut_talendStats_CONSOLE.println(strBuffer_talendStats_CONSOLE.toString());
                    consoleOut_talendStats_CONSOLE.flush();
                    nb_line_talendStats_CONSOLE++;
//////

//////                    
                    
///////////////////////    			

 


	tos_count_talendStats_CONSOLE++;

/**
 * [talendStats_CONSOLE main ] stop
 */



	
	/**
	 * [talendStats_STATS end ] start
	 */

	

	
	
		currentVirtualComponent = "talendStats_STATS";
	
	currentComponent="talendStats_STATS";

	

	}


 
                if(log.isDebugEnabled())
            log.debug("talendStats_STATS - "  + ("Done.") );

ok_Hash.put("talendStats_STATS", true);
end_Hash.put("talendStats_STATS", System.currentTimeMillis());




/**
 * [talendStats_STATS end ] stop
 */

	
	/**
	 * [talendStats_CONSOLE end ] start
	 */

	

	
	
		currentVirtualComponent = "talendStats_CONSOLE";
	
	currentComponent="talendStats_CONSOLE";

	


//////
//////
globalMap.put("talendStats_CONSOLE_NB_LINE",nb_line_talendStats_CONSOLE);
                if(log.isInfoEnabled())
            log.info("talendStats_CONSOLE - "  + ("Printed row count: ")  + (nb_line_talendStats_CONSOLE)  + (".") );

///////////////////////    			

			if(execStat){
				if(resourceMap.get("inIterateVComp") == null || !((Boolean)resourceMap.get("inIterateVComp"))){
			 		runStat.updateStatOnConnection("Main"+iterateId,2, 0); 
			 	}
			}
		
 
                if(log.isDebugEnabled())
            log.debug("talendStats_CONSOLE - "  + ("Done.") );

ok_Hash.put("talendStats_CONSOLE", true);
end_Hash.put("talendStats_CONSOLE", System.currentTimeMillis());




/**
 * [talendStats_CONSOLE end ] stop
 */



				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage());
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
					te.setVirtualComponentName(currentVirtualComponent);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [talendStats_STATS finally ] start
	 */

	

	
	
		currentVirtualComponent = "talendStats_STATS";
	
	currentComponent="talendStats_STATS";

	

 



/**
 * [talendStats_STATS finally ] stop
 */

	
	/**
	 * [talendStats_CONSOLE finally ] start
	 */

	

	
	
		currentVirtualComponent = "talendStats_CONSOLE";
	
	currentComponent="talendStats_CONSOLE";

	

 



/**
 * [talendStats_CONSOLE finally ] stop
 */



				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("talendStats_STATS_SUBPROCESS_STATE", 1);
	}
	


public static class row_talendMeter_METTERStruct implements routines.system.IPersistableRow<row_talendMeter_METTERStruct> {
    final static byte[] commonByteArrayLock_AWS_DEV_TALEND_INGESTION_FRAMEWORK_AS400_to_greenplum_with_GPLoad = new byte[0];
    static byte[] commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_AS400_to_greenplum_with_GPLoad = new byte[0];

	
			    public java.util.Date moment;

				public java.util.Date getMoment () {
					return this.moment;
				}
				
			    public String pid;

				public String getPid () {
					return this.pid;
				}
				
			    public String father_pid;

				public String getFather_pid () {
					return this.father_pid;
				}
				
			    public String root_pid;

				public String getRoot_pid () {
					return this.root_pid;
				}
				
			    public Long system_pid;

				public Long getSystem_pid () {
					return this.system_pid;
				}
				
			    public String project;

				public String getProject () {
					return this.project;
				}
				
			    public String job;

				public String getJob () {
					return this.job;
				}
				
			    public String job_repository_id;

				public String getJob_repository_id () {
					return this.job_repository_id;
				}
				
			    public String job_version;

				public String getJob_version () {
					return this.job_version;
				}
				
			    public String context;

				public String getContext () {
					return this.context;
				}
				
			    public String origin;

				public String getOrigin () {
					return this.origin;
				}
				
			    public String label;

				public String getLabel () {
					return this.label;
				}
				
			    public Integer count;

				public Integer getCount () {
					return this.count;
				}
				
			    public Integer reference;

				public Integer getReference () {
					return this.reference;
				}
				
			    public String thresholds;

				public String getThresholds () {
					return this.thresholds;
				}
				



	private java.util.Date readDate(ObjectInputStream dis) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(dis.readLong());
		}
		return dateReturn;
	}

    private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException{
		if(date1 == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeLong(date1.getTime());
    	}
    }

	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_AS400_to_greenplum_with_GPLoad.length) {
				if(length < 1024 && commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_AS400_to_greenplum_with_GPLoad.length == 0) {
   					commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_AS400_to_greenplum_with_GPLoad = new byte[1024];
				} else {
   					commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_AS400_to_greenplum_with_GPLoad = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_AS400_to_greenplum_with_GPLoad, 0, length);
			strReturn = new String(commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_AS400_to_greenplum_with_GPLoad, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
	private Integer readInteger(ObjectInputStream dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}

	private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException{
		if(intNum == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeInt(intNum);
    	}
	}

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_AWS_DEV_TALEND_INGESTION_FRAMEWORK_AS400_to_greenplum_with_GPLoad) {

        	try {

        		int length = 0;
		
					this.moment = readDate(dis);
					
					this.pid = readString(dis);
					
					this.father_pid = readString(dis);
					
					this.root_pid = readString(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.system_pid = null;
           				} else {
           			    	this.system_pid = dis.readLong();
           				}
					
					this.project = readString(dis);
					
					this.job = readString(dis);
					
					this.job_repository_id = readString(dis);
					
					this.job_version = readString(dis);
					
					this.context = readString(dis);
					
					this.origin = readString(dis);
					
					this.label = readString(dis);
					
						this.count = readInteger(dis);
					
						this.reference = readInteger(dis);
					
					this.thresholds = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// java.util.Date
				
						writeDate(this.moment,dos);
					
					// String
				
						writeString(this.pid,dos);
					
					// String
				
						writeString(this.father_pid,dos);
					
					// String
				
						writeString(this.root_pid,dos);
					
					// Long
				
						if(this.system_pid == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeLong(this.system_pid);
		            	}
					
					// String
				
						writeString(this.project,dos);
					
					// String
				
						writeString(this.job,dos);
					
					// String
				
						writeString(this.job_repository_id,dos);
					
					// String
				
						writeString(this.job_version,dos);
					
					// String
				
						writeString(this.context,dos);
					
					// String
				
						writeString(this.origin,dos);
					
					// String
				
						writeString(this.label,dos);
					
					// Integer
				
						writeInteger(this.count,dos);
					
					// Integer
				
						writeInteger(this.reference,dos);
					
					// String
				
						writeString(this.thresholds,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("moment="+String.valueOf(moment));
		sb.append(",pid="+pid);
		sb.append(",father_pid="+father_pid);
		sb.append(",root_pid="+root_pid);
		sb.append(",system_pid="+String.valueOf(system_pid));
		sb.append(",project="+project);
		sb.append(",job="+job);
		sb.append(",job_repository_id="+job_repository_id);
		sb.append(",job_version="+job_version);
		sb.append(",context="+context);
		sb.append(",origin="+origin);
		sb.append(",label="+label);
		sb.append(",count="+String.valueOf(count));
		sb.append(",reference="+String.valueOf(reference));
		sb.append(",thresholds="+thresholds);
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				if(moment == null){
        					sb.append("<null>");
        				}else{
            				sb.append(moment);
            			}
            		
        			sb.append("|");
        		
        				if(pid == null){
        					sb.append("<null>");
        				}else{
            				sb.append(pid);
            			}
            		
        			sb.append("|");
        		
        				if(father_pid == null){
        					sb.append("<null>");
        				}else{
            				sb.append(father_pid);
            			}
            		
        			sb.append("|");
        		
        				if(root_pid == null){
        					sb.append("<null>");
        				}else{
            				sb.append(root_pid);
            			}
            		
        			sb.append("|");
        		
        				if(system_pid == null){
        					sb.append("<null>");
        				}else{
            				sb.append(system_pid);
            			}
            		
        			sb.append("|");
        		
        				if(project == null){
        					sb.append("<null>");
        				}else{
            				sb.append(project);
            			}
            		
        			sb.append("|");
        		
        				if(job == null){
        					sb.append("<null>");
        				}else{
            				sb.append(job);
            			}
            		
        			sb.append("|");
        		
        				if(job_repository_id == null){
        					sb.append("<null>");
        				}else{
            				sb.append(job_repository_id);
            			}
            		
        			sb.append("|");
        		
        				if(job_version == null){
        					sb.append("<null>");
        				}else{
            				sb.append(job_version);
            			}
            		
        			sb.append("|");
        		
        				if(context == null){
        					sb.append("<null>");
        				}else{
            				sb.append(context);
            			}
            		
        			sb.append("|");
        		
        				if(origin == null){
        					sb.append("<null>");
        				}else{
            				sb.append(origin);
            			}
            		
        			sb.append("|");
        		
        				if(label == null){
        					sb.append("<null>");
        				}else{
            				sb.append(label);
            			}
            		
        			sb.append("|");
        		
        				if(count == null){
        					sb.append("<null>");
        				}else{
            				sb.append(count);
            			}
            		
        			sb.append("|");
        		
        				if(reference == null){
        					sb.append("<null>");
        				}else{
            				sb.append(reference);
            			}
            		
        			sb.append("|");
        		
        				if(thresholds == null){
        					sb.append("<null>");
        				}else{
            				sb.append(thresholds);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(row_talendMeter_METTERStruct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}
public void talendMeter_METTERProcess(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("talendMeter_METTER_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
		String currentVirtualComponent = null;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;



		row_talendMeter_METTERStruct row_talendMeter_METTER = new row_talendMeter_METTERStruct();




	
	/**
	 * [talendMeter_CONSOLE begin ] start
	 */

	

	
		
		ok_Hash.put("talendMeter_CONSOLE", false);
		start_Hash.put("talendMeter_CONSOLE", System.currentTimeMillis());
		
	
		currentVirtualComponent = "talendMeter_CONSOLE";
	
	currentComponent="talendMeter_CONSOLE";

	
			if (execStat) {
				if(resourceMap.get("inIterateVComp") == null){
					
						runStat.updateStatOnConnection("Main" + iterateId, 0, 0);
					
				}
			} 

		
		int tos_count_talendMeter_CONSOLE = 0;
		
                if(log.isDebugEnabled())
            log.debug("talendMeter_CONSOLE - "  + ("Start to work.") );
    	class BytesLimit65535_talendMeter_CONSOLE{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_talendMeter_CONSOLE = new StringBuilder();
            log4jParamters_talendMeter_CONSOLE.append("Parameters:");
                    log4jParamters_talendMeter_CONSOLE.append("BASIC_MODE" + " = " + "true");
                log4jParamters_talendMeter_CONSOLE.append(" | ");
                    log4jParamters_talendMeter_CONSOLE.append("TABLE_PRINT" + " = " + "false");
                log4jParamters_talendMeter_CONSOLE.append(" | ");
                    log4jParamters_talendMeter_CONSOLE.append("VERTICAL" + " = " + "false");
                log4jParamters_talendMeter_CONSOLE.append(" | ");
                    log4jParamters_talendMeter_CONSOLE.append("FIELDSEPARATOR" + " = " + "\"|\"");
                log4jParamters_talendMeter_CONSOLE.append(" | ");
                    log4jParamters_talendMeter_CONSOLE.append("PRINT_HEADER" + " = " + "false");
                log4jParamters_talendMeter_CONSOLE.append(" | ");
                    log4jParamters_talendMeter_CONSOLE.append("PRINT_UNIQUE_NAME" + " = " + "false");
                log4jParamters_talendMeter_CONSOLE.append(" | ");
                    log4jParamters_talendMeter_CONSOLE.append("PRINT_COLNAMES" + " = " + "false");
                log4jParamters_talendMeter_CONSOLE.append(" | ");
                    log4jParamters_talendMeter_CONSOLE.append("USE_FIXED_LENGTH" + " = " + "false");
                log4jParamters_talendMeter_CONSOLE.append(" | ");
                    log4jParamters_talendMeter_CONSOLE.append("PRINT_CONTENT_WITH_LOG4J" + " = " + "true");
                log4jParamters_talendMeter_CONSOLE.append(" | ");
                if(log.isDebugEnabled())
            log.debug("talendMeter_CONSOLE - "  + (log4jParamters_talendMeter_CONSOLE) );
    		}
    	}
    	
        new BytesLimit65535_talendMeter_CONSOLE().limitLog4jByte();

	///////////////////////
	
		final String OUTPUT_FIELD_SEPARATOR_talendMeter_CONSOLE = "|";
		java.io.PrintStream consoleOut_talendMeter_CONSOLE = null;	

 		StringBuilder strBuffer_talendMeter_CONSOLE = null;
		int nb_line_talendMeter_CONSOLE = 0;
///////////////////////    			



 



/**
 * [talendMeter_CONSOLE begin ] stop
 */



	
	/**
	 * [talendMeter_METTER begin ] start
	 */

	

	
		
		ok_Hash.put("talendMeter_METTER", false);
		start_Hash.put("talendMeter_METTER", System.currentTimeMillis());
		
	
		currentVirtualComponent = "talendMeter_METTER";
	
	currentComponent="talendMeter_METTER";

	
		int tos_count_talendMeter_METTER = 0;
		
                if(log.isDebugEnabled())
            log.debug("talendMeter_METTER - "  + ("Start to work.") );
    	class BytesLimit65535_talendMeter_METTER{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_talendMeter_METTER = new StringBuilder();
            log4jParamters_talendMeter_METTER.append("Parameters:");
                if(log.isDebugEnabled())
            log.debug("talendMeter_METTER - "  + (log4jParamters_talendMeter_METTER) );
    		}
    	}
    	
        new BytesLimit65535_talendMeter_METTER().limitLog4jByte();

	for (MetterCatcherUtils.MetterCatcherMessage mcm : talendMeter_METTER.getMessages()) {
		row_talendMeter_METTER.pid = pid;
		row_talendMeter_METTER.root_pid = rootPid;
		row_talendMeter_METTER.father_pid = fatherPid;	
        row_talendMeter_METTER.project = projectName;
        row_talendMeter_METTER.job = jobName;
        row_talendMeter_METTER.context = contextStr;
		row_talendMeter_METTER.origin = (mcm.getOrigin()==null || mcm.getOrigin().length()<1 ? null : mcm.getOrigin());
		row_talendMeter_METTER.moment = mcm.getMoment();
		row_talendMeter_METTER.job_version = mcm.getJobVersion();
		row_talendMeter_METTER.job_repository_id = mcm.getJobId();
		row_talendMeter_METTER.system_pid = mcm.getSystemPid();
		row_talendMeter_METTER.label = mcm.getLabel();
		row_talendMeter_METTER.count = mcm.getCount();
		row_talendMeter_METTER.reference = talendMeter_METTER.getConnLinesCount(mcm.getReferense()+"_count");
		row_talendMeter_METTER.thresholds = mcm.getThresholds();
		

 



/**
 * [talendMeter_METTER begin ] stop
 */
	
	/**
	 * [talendMeter_METTER main ] start
	 */

	

	
	
		currentVirtualComponent = "talendMeter_METTER";
	
	currentComponent="talendMeter_METTER";

	

 


	tos_count_talendMeter_METTER++;

/**
 * [talendMeter_METTER main ] stop
 */

	
	/**
	 * [talendMeter_CONSOLE main ] start
	 */

	

	
	
		currentVirtualComponent = "talendMeter_CONSOLE";
	
	currentComponent="talendMeter_CONSOLE";

	

			//Main
			//row_talendMeter_METTER


			
				if(execStat){
					runStat.updateStatOnConnection("Main"+iterateId,1, 1);
				} 
			

		
///////////////////////		
						



				strBuffer_talendMeter_CONSOLE = new StringBuilder();




   				
	    		if(row_talendMeter_METTER.moment != null) { //              
                    							
       
				strBuffer_talendMeter_CONSOLE.append(
								FormatterUtils.format_Date(row_talendMeter_METTER.moment, "yyyy-MM-dd HH:mm:ss")				
				);


							
	    		} //  			

    			strBuffer_talendMeter_CONSOLE.append("|");
    			


   				
	    		if(row_talendMeter_METTER.pid != null) { //              
                    							
       
				strBuffer_talendMeter_CONSOLE.append(
				                String.valueOf(row_talendMeter_METTER.pid)							
				);


							
	    		} //  			

    			strBuffer_talendMeter_CONSOLE.append("|");
    			


   				
	    		if(row_talendMeter_METTER.father_pid != null) { //              
                    							
       
				strBuffer_talendMeter_CONSOLE.append(
				                String.valueOf(row_talendMeter_METTER.father_pid)							
				);


							
	    		} //  			

    			strBuffer_talendMeter_CONSOLE.append("|");
    			


   				
	    		if(row_talendMeter_METTER.root_pid != null) { //              
                    							
       
				strBuffer_talendMeter_CONSOLE.append(
				                String.valueOf(row_talendMeter_METTER.root_pid)							
				);


							
	    		} //  			

    			strBuffer_talendMeter_CONSOLE.append("|");
    			


   				
	    		if(row_talendMeter_METTER.system_pid != null) { //              
                    							
       
				strBuffer_talendMeter_CONSOLE.append(
				                String.valueOf(row_talendMeter_METTER.system_pid)							
				);


							
	    		} //  			

    			strBuffer_talendMeter_CONSOLE.append("|");
    			


   				
	    		if(row_talendMeter_METTER.project != null) { //              
                    							
       
				strBuffer_talendMeter_CONSOLE.append(
				                String.valueOf(row_talendMeter_METTER.project)							
				);


							
	    		} //  			

    			strBuffer_talendMeter_CONSOLE.append("|");
    			


   				
	    		if(row_talendMeter_METTER.job != null) { //              
                    							
       
				strBuffer_talendMeter_CONSOLE.append(
				                String.valueOf(row_talendMeter_METTER.job)							
				);


							
	    		} //  			

    			strBuffer_talendMeter_CONSOLE.append("|");
    			


   				
	    		if(row_talendMeter_METTER.job_repository_id != null) { //              
                    							
       
				strBuffer_talendMeter_CONSOLE.append(
				                String.valueOf(row_talendMeter_METTER.job_repository_id)							
				);


							
	    		} //  			

    			strBuffer_talendMeter_CONSOLE.append("|");
    			


   				
	    		if(row_talendMeter_METTER.job_version != null) { //              
                    							
       
				strBuffer_talendMeter_CONSOLE.append(
				                String.valueOf(row_talendMeter_METTER.job_version)							
				);


							
	    		} //  			

    			strBuffer_talendMeter_CONSOLE.append("|");
    			


   				
	    		if(row_talendMeter_METTER.context != null) { //              
                    							
       
				strBuffer_talendMeter_CONSOLE.append(
				                String.valueOf(row_talendMeter_METTER.context)							
				);


							
	    		} //  			

    			strBuffer_talendMeter_CONSOLE.append("|");
    			


   				
	    		if(row_talendMeter_METTER.origin != null) { //              
                    							
       
				strBuffer_talendMeter_CONSOLE.append(
				                String.valueOf(row_talendMeter_METTER.origin)							
				);


							
	    		} //  			

    			strBuffer_talendMeter_CONSOLE.append("|");
    			


   				
	    		if(row_talendMeter_METTER.label != null) { //              
                    							
       
				strBuffer_talendMeter_CONSOLE.append(
				                String.valueOf(row_talendMeter_METTER.label)							
				);


							
	    		} //  			

    			strBuffer_talendMeter_CONSOLE.append("|");
    			


   				
	    		if(row_talendMeter_METTER.count != null) { //              
                    							
       
				strBuffer_talendMeter_CONSOLE.append(
				                String.valueOf(row_talendMeter_METTER.count)							
				);


							
	    		} //  			

    			strBuffer_talendMeter_CONSOLE.append("|");
    			


   				
	    		if(row_talendMeter_METTER.reference != null) { //              
                    							
       
				strBuffer_talendMeter_CONSOLE.append(
				                String.valueOf(row_talendMeter_METTER.reference)							
				);


							
	    		} //  			

    			strBuffer_talendMeter_CONSOLE.append("|");
    			


   				
	    		if(row_talendMeter_METTER.thresholds != null) { //              
                    							
       
				strBuffer_talendMeter_CONSOLE.append(
				                String.valueOf(row_talendMeter_METTER.thresholds)							
				);


							
	    		} //  			
 

                    if (globalMap.get("tLogRow_CONSOLE")!=null)
                    {
                    	consoleOut_talendMeter_CONSOLE = (java.io.PrintStream) globalMap.get("tLogRow_CONSOLE");
                    }
                    else
                    {
                    	consoleOut_talendMeter_CONSOLE = new java.io.PrintStream(new java.io.BufferedOutputStream(System.out));
                    	globalMap.put("tLogRow_CONSOLE",consoleOut_talendMeter_CONSOLE);
                    }
                    	log.info("talendMeter_CONSOLE - Content of row "+(nb_line_talendMeter_CONSOLE+1)+": " + strBuffer_talendMeter_CONSOLE.toString());
                    consoleOut_talendMeter_CONSOLE.println(strBuffer_talendMeter_CONSOLE.toString());
                    consoleOut_talendMeter_CONSOLE.flush();
                    nb_line_talendMeter_CONSOLE++;
//////

//////                    
                    
///////////////////////    			

 


	tos_count_talendMeter_CONSOLE++;

/**
 * [talendMeter_CONSOLE main ] stop
 */



	
	/**
	 * [talendMeter_METTER end ] start
	 */

	

	
	
		currentVirtualComponent = "talendMeter_METTER";
	
	currentComponent="talendMeter_METTER";

	

	}


 
                if(log.isDebugEnabled())
            log.debug("talendMeter_METTER - "  + ("Done.") );

ok_Hash.put("talendMeter_METTER", true);
end_Hash.put("talendMeter_METTER", System.currentTimeMillis());




/**
 * [talendMeter_METTER end ] stop
 */

	
	/**
	 * [talendMeter_CONSOLE end ] start
	 */

	

	
	
		currentVirtualComponent = "talendMeter_CONSOLE";
	
	currentComponent="talendMeter_CONSOLE";

	


//////
//////
globalMap.put("talendMeter_CONSOLE_NB_LINE",nb_line_talendMeter_CONSOLE);
                if(log.isInfoEnabled())
            log.info("talendMeter_CONSOLE - "  + ("Printed row count: ")  + (nb_line_talendMeter_CONSOLE)  + (".") );

///////////////////////    			

			if(execStat){
				if(resourceMap.get("inIterateVComp") == null || !((Boolean)resourceMap.get("inIterateVComp"))){
			 		runStat.updateStatOnConnection("Main"+iterateId,2, 0); 
			 	}
			}
		
 
                if(log.isDebugEnabled())
            log.debug("talendMeter_CONSOLE - "  + ("Done.") );

ok_Hash.put("talendMeter_CONSOLE", true);
end_Hash.put("talendMeter_CONSOLE", System.currentTimeMillis());




/**
 * [talendMeter_CONSOLE end ] stop
 */



				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage());
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
					te.setVirtualComponentName(currentVirtualComponent);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [talendMeter_METTER finally ] start
	 */

	

	
	
		currentVirtualComponent = "talendMeter_METTER";
	
	currentComponent="talendMeter_METTER";

	

 



/**
 * [talendMeter_METTER finally ] stop
 */

	
	/**
	 * [talendMeter_CONSOLE finally ] start
	 */

	

	
	
		currentVirtualComponent = "talendMeter_CONSOLE";
	
	currentComponent="talendMeter_CONSOLE";

	

 



/**
 * [talendMeter_CONSOLE finally ] stop
 */



				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("talendMeter_METTER_SUBPROCESS_STATE", 1);
	}
	
    public String resuming_logs_dir_path = null;
    public String resuming_checkpoint_path = null;
    public String parent_part_launcher = null;
    private String resumeEntryMethodName = null;
    private boolean globalResumeTicket = false;

    public boolean watch = false;
    // portStats is null, it means don't execute the statistics
    public Integer portStats = null;
    public int portTraces = 4334;
    public String clientHost;
    public String defaultClientHost = "localhost";
    public String contextStr = "SOURCING_DEV";
    public boolean isDefaultContext = true;
    public String pid = "0";
    public String rootPid = null;
    public String fatherPid = null;
    public String fatherNode = null;
    public long startTime = 0;
    public boolean isChildJob = false;
    public String log4jLevel = "";

    private boolean execStat = true;

    private ThreadLocal<java.util.Map<String, String>> threadLocal = new ThreadLocal<java.util.Map<String, String>>() {
        protected java.util.Map<String, String> initialValue() {
            java.util.Map<String,String> threadRunResultMap = new java.util.HashMap<String, String>();
            threadRunResultMap.put("errorCode", null);
            threadRunResultMap.put("status", "");
            return threadRunResultMap;
        };
    };



    private java.util.Properties context_param = new java.util.Properties();
    public java.util.Map<String, Object> parentContextMap = new java.util.HashMap<String, Object>();

    public String status= "";

    public static void main(String[] args){
        final AS400_to_greenplum_with_GPLoad AS400_to_greenplum_with_GPLoadClass = new AS400_to_greenplum_with_GPLoad();

        int exitCode = AS400_to_greenplum_with_GPLoadClass.runJobInTOS(args);
	        if(exitCode==0){
		        log.info("TalendJob: 'AS400_to_greenplum_with_GPLoad' - Done.");
	        }

        System.exit(exitCode);
    }


    public String[][] runJob(String[] args) {

        int exitCode = runJobInTOS(args);
        String[][] bufferValue = new String[][] { { Integer.toString(exitCode) } };

        return bufferValue;
    }

    public boolean hastBufferOutputComponent() {
		boolean hastBufferOutput = false;
    	
        return hastBufferOutput;
    }

    public int runJobInTOS(String[] args) {
	   	// reset status
	   	status = "";

        String lastStr = "";
        for (String arg : args) {
            if (arg.equalsIgnoreCase("--context_param")) {
                lastStr = arg;
            } else if (lastStr.equals("")) {
                evalParam(arg);
            } else {
                evalParam(lastStr + " " + arg);
                lastStr = "";
            }
        }

	        if(!"".equals(log4jLevel)){
				if("trace".equalsIgnoreCase(log4jLevel)){
					log.setLevel(org.apache.log4j.Level.TRACE);
				}else if("debug".equalsIgnoreCase(log4jLevel)){
					log.setLevel(org.apache.log4j.Level.DEBUG);
				}else if("info".equalsIgnoreCase(log4jLevel)){
					log.setLevel(org.apache.log4j.Level.INFO);
				}else if("warn".equalsIgnoreCase(log4jLevel)){
					log.setLevel(org.apache.log4j.Level.WARN);
				}else if("error".equalsIgnoreCase(log4jLevel)){
					log.setLevel(org.apache.log4j.Level.ERROR);
				}else if("fatal".equalsIgnoreCase(log4jLevel)){
					log.setLevel(org.apache.log4j.Level.FATAL);
				}else if ("off".equalsIgnoreCase(log4jLevel)){
					log.setLevel(org.apache.log4j.Level.OFF);
				}
				org.apache.log4j.Logger.getRootLogger().setLevel(log.getLevel());
    	    }
        	log.info("TalendJob: 'AS400_to_greenplum_with_GPLoad' - Start.");
    	

        if(clientHost == null) {
            clientHost = defaultClientHost;
        }

        if(pid == null || "0".equals(pid)) {
            pid = TalendString.getAsciiRandomString(6);
        }

        if (rootPid==null) {
            rootPid = pid;
        }
        if (fatherPid==null) {
            fatherPid = pid;
        }else{
            isChildJob = true;
        }

        if (portStats != null) {
            // portStats = -1; //for testing
            if (portStats < 0 || portStats > 65535) {
                // issue:10869, the portStats is invalid, so this client socket can't open
                System.err.println("The statistics socket port " + portStats + " is invalid.");
                execStat = false;
            }
        } else {
            execStat = false;
        }

        try {
            //call job/subjob with an existing context, like: --context=production. if without this parameter, there will use the default context instead.
            java.io.InputStream inContext = AS400_to_greenplum_with_GPLoad.class.getClassLoader().getResourceAsStream("aws_dev_talend_ingestion_framework/as400_to_greenplum_with_gpload_0_1/contexts/"+contextStr+".properties");
            if(isDefaultContext && inContext ==null) {

            } else {
                if (inContext!=null) {
                    //defaultProps is in order to keep the original context value
                    defaultProps.load(inContext);
                    inContext.close();
                    context = new ContextProperties(defaultProps);
                }else{
                    //print info and job continue to run, for case: context_param is not empty.
                    System.err.println("Could not find the context " + contextStr);
                }
            }

            if(!context_param.isEmpty()) {
                context.putAll(context_param);
            }
                context.SOURCE_HOST=(String) context.getProperty("SOURCE_HOST");
                context.SOURCE_DATABASE=(String) context.getProperty("SOURCE_DATABASE");
                context.SOURCE_USER=(String) context.getProperty("SOURCE_USER");
             try{
                 context.SOURCE_PORT=routines.system.ParserUtils.parseTo_Integer (context.getProperty("SOURCE_PORT"));
             }catch(NumberFormatException e){
                 context.SOURCE_PORT=null;
              }
            		String pwd_SOURCE_PASSWORD_value = context.getProperty("SOURCE_PASSWORD");
            		context.SOURCE_PASSWORD = null;
            		if(pwd_SOURCE_PASSWORD_value!=null) {
            			if(context_param.containsKey("SOURCE_PASSWORD")) {//no need to decrypt if it come from program argument or parent job runtime
            				context.SOURCE_PASSWORD = pwd_SOURCE_PASSWORD_value;
            			} else if (!pwd_SOURCE_PASSWORD_value.isEmpty()) {
            				try {
            					context.SOURCE_PASSWORD = routines.system.PasswordEncryptUtil.decryptPassword(pwd_SOURCE_PASSWORD_value);
            					context.put("SOURCE_PASSWORD",context.SOURCE_PASSWORD);
            				} catch (java.lang.RuntimeException e) {
            					//do nothing
            				}
            			}
            		}
                context.GP_SOURCE_NAME=(String) context.getProperty("GP_SOURCE_NAME");
                context.TABLE_NAME=(String) context.getProperty("TABLE_NAME");
                context.ETL_LOCALHOSTNAME=(String) context.getProperty("ETL_LOCALHOSTNAME");
                context.HAWQ_Source_Ports=(String) context.getProperty("HAWQ_Source_Ports");
                context.ETL_STORAGE_PATH=(String) context.getProperty("ETL_STORAGE_PATH");
                context.FORCE_DROP=(String) context.getProperty("FORCE_DROP");
                context.LOAD2HDFS=(String) context.getProperty("LOAD2HDFS");
                context.SOURCING_Server=(String) context.getProperty("SOURCING_Server");
                context.SOURCING_Login=(String) context.getProperty("SOURCING_Login");
            		String pwd_SOURCING_Password_value = context.getProperty("SOURCING_Password");
            		context.SOURCING_Password = null;
            		if(pwd_SOURCING_Password_value!=null) {
            			if(context_param.containsKey("SOURCING_Password")) {//no need to decrypt if it come from program argument or parent job runtime
            				context.SOURCING_Password = pwd_SOURCING_Password_value;
            			} else if (!pwd_SOURCING_Password_value.isEmpty()) {
            				try {
            					context.SOURCING_Password = routines.system.PasswordEncryptUtil.decryptPassword(pwd_SOURCING_Password_value);
            					context.put("SOURCING_Password",context.SOURCING_Password);
            				} catch (java.lang.RuntimeException e) {
            					//do nothing
            				}
            			}
            		}
                context.SOURCING_Port=(String) context.getProperty("SOURCING_Port");
                context.SOURCING_Schema=(String) context.getProperty("SOURCING_Schema");
                context.SOURCING_Database=(String) context.getProperty("SOURCING_Database");
             try{
                 context.TOP_N_ROWS=routines.system.ParserUtils.parseTo_Integer (context.getProperty("TOP_N_ROWS"));
             }catch(NumberFormatException e){
                 context.TOP_N_ROWS=null;
              }
                context.FORCE_BATCH=(String) context.getProperty("FORCE_BATCH");
             try{
                 context.RUN_ID=routines.system.ParserUtils.parseTo_Integer (context.getProperty("RUN_ID"));
             }catch(NumberFormatException e){
                 context.RUN_ID=null;
              }
        } catch (java.io.IOException ie) {
            System.err.println("Could not load context "+contextStr);
            ie.printStackTrace();
        }


        // get context value from parent directly
        if (parentContextMap != null && !parentContextMap.isEmpty()) {if (parentContextMap.containsKey("SOURCE_HOST")) {
                context.SOURCE_HOST = (String) parentContextMap.get("SOURCE_HOST");
            }if (parentContextMap.containsKey("SOURCE_DATABASE")) {
                context.SOURCE_DATABASE = (String) parentContextMap.get("SOURCE_DATABASE");
            }if (parentContextMap.containsKey("SOURCE_USER")) {
                context.SOURCE_USER = (String) parentContextMap.get("SOURCE_USER");
            }if (parentContextMap.containsKey("SOURCE_PORT")) {
                context.SOURCE_PORT = (Integer) parentContextMap.get("SOURCE_PORT");
            }if (parentContextMap.containsKey("SOURCE_PASSWORD")) {
                context.SOURCE_PASSWORD = (java.lang.String) parentContextMap.get("SOURCE_PASSWORD");
            }if (parentContextMap.containsKey("GP_SOURCE_NAME")) {
                context.GP_SOURCE_NAME = (String) parentContextMap.get("GP_SOURCE_NAME");
            }if (parentContextMap.containsKey("TABLE_NAME")) {
                context.TABLE_NAME = (String) parentContextMap.get("TABLE_NAME");
            }if (parentContextMap.containsKey("ETL_LOCALHOSTNAME")) {
                context.ETL_LOCALHOSTNAME = (String) parentContextMap.get("ETL_LOCALHOSTNAME");
            }if (parentContextMap.containsKey("HAWQ_Source_Ports")) {
                context.HAWQ_Source_Ports = (String) parentContextMap.get("HAWQ_Source_Ports");
            }if (parentContextMap.containsKey("ETL_STORAGE_PATH")) {
                context.ETL_STORAGE_PATH = (String) parentContextMap.get("ETL_STORAGE_PATH");
            }if (parentContextMap.containsKey("FORCE_DROP")) {
                context.FORCE_DROP = (String) parentContextMap.get("FORCE_DROP");
            }if (parentContextMap.containsKey("LOAD2HDFS")) {
                context.LOAD2HDFS = (String) parentContextMap.get("LOAD2HDFS");
            }if (parentContextMap.containsKey("SOURCING_Server")) {
                context.SOURCING_Server = (String) parentContextMap.get("SOURCING_Server");
            }if (parentContextMap.containsKey("SOURCING_Login")) {
                context.SOURCING_Login = (String) parentContextMap.get("SOURCING_Login");
            }if (parentContextMap.containsKey("SOURCING_Password")) {
                context.SOURCING_Password = (java.lang.String) parentContextMap.get("SOURCING_Password");
            }if (parentContextMap.containsKey("SOURCING_Port")) {
                context.SOURCING_Port = (String) parentContextMap.get("SOURCING_Port");
            }if (parentContextMap.containsKey("SOURCING_Schema")) {
                context.SOURCING_Schema = (String) parentContextMap.get("SOURCING_Schema");
            }if (parentContextMap.containsKey("SOURCING_Database")) {
                context.SOURCING_Database = (String) parentContextMap.get("SOURCING_Database");
            }if (parentContextMap.containsKey("TOP_N_ROWS")) {
                context.TOP_N_ROWS = (Integer) parentContextMap.get("TOP_N_ROWS");
            }if (parentContextMap.containsKey("FORCE_BATCH")) {
                context.FORCE_BATCH = (String) parentContextMap.get("FORCE_BATCH");
            }if (parentContextMap.containsKey("RUN_ID")) {
                context.RUN_ID = (Integer) parentContextMap.get("RUN_ID");
            }
        }

        //Resume: init the resumeUtil
        resumeEntryMethodName = ResumeUtil.getResumeEntryMethodName(resuming_checkpoint_path);
        resumeUtil = new ResumeUtil(resuming_logs_dir_path, isChildJob, rootPid);
        resumeUtil.initCommonInfo(pid, rootPid, fatherPid, projectName, jobName, contextStr, jobVersion);

		List<String> parametersToEncrypt = new java.util.ArrayList<String>();
			parametersToEncrypt.add("SOURCE_PASSWORD");
			parametersToEncrypt.add("SOURCING_Password");
        //Resume: jobStart
        resumeUtil.addLog("JOB_STARTED", "JOB:" + jobName, parent_part_launcher, Thread.currentThread().getId() + "", "","","","",resumeUtil.convertToJsonText(context,parametersToEncrypt));

if(execStat) {
    try {
        runStat.openSocket(!isChildJob);
        runStat.setAllPID(rootPid, fatherPid, pid, jobName);
        runStat.startThreadStat(clientHost, portStats);
        runStat.updateStatOnJob(RunStat.JOBSTART, fatherNode);
    } catch (java.io.IOException ioException) {
        ioException.printStackTrace();
    }
}



	
	    java.util.concurrent.ConcurrentHashMap<Object, Object> concurrentHashMap = new java.util.concurrent.ConcurrentHashMap<Object, Object>();
	    globalMap.put("concurrentHashMap", concurrentHashMap);
	

    long startUsedMemory = Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory();
    long endUsedMemory = 0;
    long end = 0;

    startTime = System.currentTimeMillis();
        talendStats_STATS.addMessage("begin");


this.globalResumeTicket = true;//to run tPreJob



        try {
            talendStats_STATSProcess(globalMap);
        } catch (java.lang.Exception e) {
            e.printStackTrace();
        }

this.globalResumeTicket = false;//to run others jobs

try {
errorCode = null;tJava_1Process(globalMap);
if(!"failure".equals(status)) { status = "end"; }
}catch (TalendException e_tJava_1) {
globalMap.put("tJava_1_SUBPROCESS_STATE", -1);

e_tJava_1.printStackTrace();

}

this.globalResumeTicket = true;//to run tPostJob




        end = System.currentTimeMillis();

        if (watch) {
            System.out.println((end-startTime)+" milliseconds");
        }

        endUsedMemory = Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory();
        if (false) {
            System.out.println((endUsedMemory - startUsedMemory) + " bytes memory increase when running : AS400_to_greenplum_with_GPLoad");
        }
        talendStats_STATS.addMessage(status==""?"end":status, (end-startTime));
        try {
            talendStats_STATSProcess(globalMap);
        } catch (java.lang.Exception e) {
            e.printStackTrace();
        }





if (execStat) {
    runStat.updateStatOnJob(RunStat.JOBEND, fatherNode);
    runStat.stopThreadStat();
}
    int returnCode = 0;
    if(errorCode == null) {
         returnCode = status != null && status.equals("failure") ? 1 : 0;
    } else {
         returnCode = errorCode.intValue();
    }
    resumeUtil.addLog("JOB_ENDED", "JOB:" + jobName, parent_part_launcher, Thread.currentThread().getId() + "", "","" + returnCode,"","","");

    return returnCode;

  }

    // only for OSGi env
    public void destroy() {
    closeSqlDbConnections();


    }



    private void closeSqlDbConnections() {
        try {
            Object obj_conn;
            obj_conn = globalMap.remove("conn_tAS400Connection_1");
            if (null != obj_conn) {
                ((java.sql.Connection) obj_conn).close();
            }
            obj_conn = globalMap.remove("conn_tGreenplumConnection_2");
            if (null != obj_conn) {
                ((java.sql.Connection) obj_conn).close();
            }
            obj_conn = globalMap.remove("conn_tGreenplumConnection_1");
            if (null != obj_conn) {
                ((java.sql.Connection) obj_conn).close();
            }
        } catch (java.lang.Exception e) {
        }
    }

		









    private java.util.Map<String, Object> getSharedConnections4REST() {
        java.util.Map<String, Object> connections = new java.util.HashMap<String, Object>();
            connections.put("conn_tAS400Connection_1", globalMap.get("conn_tAS400Connection_1"));
            connections.put("conn_tGreenplumConnection_2", globalMap.get("conn_tGreenplumConnection_2"));
            connections.put("conn_tGreenplumConnection_1", globalMap.get("conn_tGreenplumConnection_1"));






        return connections;
    }

    private void evalParam(String arg) {
        if (arg.startsWith("--resuming_logs_dir_path")) {
            resuming_logs_dir_path = arg.substring(25);
        } else if (arg.startsWith("--resuming_checkpoint_path")) {
            resuming_checkpoint_path = arg.substring(27);
        } else if (arg.startsWith("--parent_part_launcher")) {
            parent_part_launcher = arg.substring(23);
        } else if (arg.startsWith("--watch")) {
            watch = true;
        } else if (arg.startsWith("--stat_port=")) {
            String portStatsStr = arg.substring(12);
            if (portStatsStr != null && !portStatsStr.equals("null")) {
                portStats = Integer.parseInt(portStatsStr);
            }
        } else if (arg.startsWith("--trace_port=")) {
            portTraces = Integer.parseInt(arg.substring(13));
        } else if (arg.startsWith("--client_host=")) {
            clientHost = arg.substring(14);
        } else if (arg.startsWith("--context=")) {
            contextStr = arg.substring(10);
            isDefaultContext = false;
        } else if (arg.startsWith("--father_pid=")) {
            fatherPid = arg.substring(13);
        } else if (arg.startsWith("--root_pid=")) {
            rootPid = arg.substring(11);
        } else if (arg.startsWith("--father_node=")) {
            fatherNode = arg.substring(14);
        } else if (arg.startsWith("--pid=")) {
            pid = arg.substring(6);
        } else if (arg.startsWith("--context_param")) {
            String keyValue = arg.substring(16);
            int index = -1;
            if (keyValue != null && (index = keyValue.indexOf('=')) > -1) {
                if (fatherPid==null) {
                    context_param.put(keyValue.substring(0, index), replaceEscapeChars(keyValue.substring(index + 1)));
                } else { // the subjob won't escape the especial chars
                    context_param.put(keyValue.substring(0, index), keyValue.substring(index + 1) );
                }
            }
        }else if (arg.startsWith("--log4jLevel=")) {
            log4jLevel = arg.substring(13);
		}

    }

    private final String[][] escapeChars = {
        {"\\\\","\\"},{"\\n","\n"},{"\\'","\'"},{"\\r","\r"},
        {"\\f","\f"},{"\\b","\b"},{"\\t","\t"}
        };
    private String replaceEscapeChars (String keyValue) {

		if (keyValue == null || ("").equals(keyValue.trim())) {
			return keyValue;
		}

		StringBuilder result = new StringBuilder();
		int currIndex = 0;
		while (currIndex < keyValue.length()) {
			int index = -1;
			// judege if the left string includes escape chars
			for (String[] strArray : escapeChars) {
				index = keyValue.indexOf(strArray[0],currIndex);
				if (index>=0) {

					result.append(keyValue.substring(currIndex, index + strArray[0].length()).replace(strArray[0], strArray[1]));
					currIndex = index + strArray[0].length();
					break;
				}
			}
			// if the left string doesn't include escape chars, append the left into the result
			if (index < 0) {
				result.append(keyValue.substring(currIndex));
				currIndex = currIndex + keyValue.length();
			}
		}

		return result.toString();
    }

    public Integer getErrorCode() {
        return errorCode;
    }


    public String getStatus() {
        return status;
    }

    ResumeUtil resumeUtil = null;
}
/************************************************************************************************
 *     495237 characters generated by Talend Real-time Big Data Platform 
 *     on the October 19, 2018 3:29:54 PM CDT
 ************************************************************************************************/