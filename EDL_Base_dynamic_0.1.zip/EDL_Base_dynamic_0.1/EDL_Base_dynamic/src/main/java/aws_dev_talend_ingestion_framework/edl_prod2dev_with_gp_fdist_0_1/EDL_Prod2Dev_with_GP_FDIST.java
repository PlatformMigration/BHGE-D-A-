
package aws_dev_talend_ingestion_framework.edl_prod2dev_with_gp_fdist_0_1;

import routines.DataOperation;
import routines.TalendDataGenerator;
import routines.GEDynamicRoutine;
import routines.DataQuality;
import routines.Relational;
import routines.GEroutines;
import routines.Mathematical;
import routines.DataQualityDependencies;
import routines.SQLike;
import routines.Numeric;
import routines.TalendString;
import routines.StringHandling;
import routines.DQTechnical;
import routines.MDM;
import routines.TalendDate;
import routines.DataMasking;
import routines.DqStringHandling;
import routines.GPLoadRoutine;
import routines.system.*;
import routines.system.api.*;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.math.BigDecimal;
import java.io.ByteArrayOutputStream;
import java.io.ByteArrayInputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.ObjectOutputStream;
import java.io.ObjectInputStream;
import java.io.IOException;
import java.util.Comparator;
 




	//the import part of tJava_2
	//import java.util.List;

	//the import part of tJava_5
	//import java.util.List;

	//the import part of tJavaRow_3
	//import java.util.List;

	//the import part of tJava_7
	//import java.util.List;

	//the import part of tJavaRow_6
	//import java.util.List;

	//the import part of tJava_11
	//import java.util.List;

	//the import part of tJavaRow_5
	//import java.util.List;

	//the import part of tJava_13
	//import java.util.List;

	//the import part of tJava_15
	//import java.util.List;

	//the import part of tJava_9
	//import java.util.List;

	//the import part of tJava_12
	//import java.util.List;

	//the import part of tJava_3
	//import java.util.List;

	//the import part of tJava_10
	//import java.util.List;

	//the import part of tJava_16
	//import java.util.List;


@SuppressWarnings("unused")

/**
 * Job: EDL_Prod2Dev_with_GP_FDIST Purpose: EDL_Prod2Dev_with_GP_FDIST_ZN<br>
 * Description: EDL_Prod2Dev_with_GP_FDIST_ZN <br>
 * @author Talend, admin
 * @version 6.3.1.20161216_1026
 * @status 
 */
public class EDL_Prod2Dev_with_GP_FDIST implements TalendJob {
	static {System.setProperty("TalendJob.log", "EDL_Prod2Dev_with_GP_FDIST.log");}
	private static org.apache.log4j.Logger log = org.apache.log4j.Logger.getLogger(EDL_Prod2Dev_with_GP_FDIST.class);



	public final Object obj = new Object();

	// for transmiting parameters purpose
	private Object valueObject = null;

	public Object getValueObject() {
		return this.valueObject;
	}

	public void setValueObject(Object valueObject) {
		this.valueObject = valueObject;
	}
	private Object[] multiThreadLockWrite = new Object[0];
	
	private final static String defaultCharset = java.nio.charset.Charset.defaultCharset().name();

	
	private final static String utf8Charset = "UTF-8";

	// create and load default properties
	private java.util.Properties defaultProps = new java.util.Properties();
	// create application properties with default
	public class ContextProperties extends java.util.Properties {

		private static final long serialVersionUID = 1L;

		public ContextProperties(java.util.Properties properties){
			super(properties);
		}
		public ContextProperties(){
			super();
		}

		public void synchronizeContext(){
			
			if(GP_SOURCE_NAME != null){
				
					this.setProperty("GP_SOURCE_NAME", GP_SOURCE_NAME.toString());
				
			}
			
			if(TABLE_NAME != null){
				
					this.setProperty("TABLE_NAME", TABLE_NAME.toString());
				
			}
			
			if(FORCE_DROP != null){
				
					this.setProperty("FORCE_DROP", FORCE_DROP.toString());
				
			}
			
			if(LOAD2HDFS != null){
				
					this.setProperty("LOAD2HDFS", LOAD2HDFS.toString());
				
			}
			
			if(RUN_ID != null){
				
					this.setProperty("RUN_ID", RUN_ID.toString());
				
			}
			
			if(ORIG_DATABASE_NAME != null){
				
					this.setProperty("ORIG_DATABASE_NAME", ORIG_DATABASE_NAME.toString());
				
			}
			
			if(FDIST_PARAM != null){
				
					this.setProperty("FDIST_PARAM", FDIST_PARAM.toString());
				
			}
			
			if(LOG_NO_OF_ERRORS != null){
				
					this.setProperty("LOG_NO_OF_ERRORS", LOG_NO_OF_ERRORS.toString());
				
			}
			
			if(LOG_PLANT_NAME != null){
				
					this.setProperty("LOG_PLANT_NAME", LOG_PLANT_NAME.toString());
				
			}
			
			if(LOG_NO_OF_UPDATES != null){
				
					this.setProperty("LOG_NO_OF_UPDATES", LOG_NO_OF_UPDATES.toString());
				
			}
			
			if(LOG_SOURCE_ROW_COUNT != null){
				
					this.setProperty("LOG_SOURCE_ROW_COUNT", LOG_SOURCE_ROW_COUNT.toString());
				
			}
			
			if(LOG_TECHNOLOGY != null){
				
					this.setProperty("LOG_TECHNOLOGY", LOG_TECHNOLOGY.toString());
				
			}
			
			if(LOG_TABLE_NAME != null){
				
					this.setProperty("LOG_TABLE_NAME", LOG_TABLE_NAME.toString());
				
			}
			
			if(LOG_NO_OF_INSERTS != null){
				
					this.setProperty("LOG_NO_OF_INSERTS", LOG_NO_OF_INSERTS.toString());
				
			}
			
			if(LOG_DATA_PATH != null){
				
					this.setProperty("LOG_DATA_PATH", LOG_DATA_PATH.toString());
				
			}
			
			if(LOG_NO_OF_DELETES != null){
				
					this.setProperty("LOG_NO_OF_DELETES", LOG_NO_OF_DELETES.toString());
				
			}
			
			if(LOG_RUN_ID != null){
				
					this.setProperty("LOG_RUN_ID", LOG_RUN_ID.toString());
				
			}
			
			if(LOG_ERROR_CATEGORY != null){
				
					this.setProperty("LOG_ERROR_CATEGORY", LOG_ERROR_CATEGORY.toString());
				
			}
			
			if(LOG_JOB_NAME != null){
				
					this.setProperty("LOG_JOB_NAME", LOG_JOB_NAME.toString());
				
			}
			
			if(LOG_SYSTEM_NAME != null){
				
					this.setProperty("LOG_SYSTEM_NAME", LOG_SYSTEM_NAME.toString());
				
			}
			
			if(LOG_MESSAGE != null){
				
					this.setProperty("LOG_MESSAGE", LOG_MESSAGE.toString());
				
			}
			
			if(LOG_TARGET_ROW_COUNT != null){
				
					this.setProperty("LOG_TARGET_ROW_COUNT", LOG_TARGET_ROW_COUNT.toString());
				
			}
			
			if(LOG_STATUS != null){
				
					this.setProperty("LOG_STATUS", LOG_STATUS.toString());
				
			}
			
			if(JOB_LABEL_NAME != null){
				
					this.setProperty("JOB_LABEL_NAME", JOB_LABEL_NAME.toString());
				
			}
			
			if(PLANT_NAME != null){
				
					this.setProperty("PLANT_NAME", PLANT_NAME.toString());
				
			}
			
			if(SEND_MAIL != null){
				
					this.setProperty("SEND_MAIL", SEND_MAIL.toString());
				
			}
			
			if(MAIL_TO != null){
				
					this.setProperty("MAIL_TO", MAIL_TO.toString());
				
			}
			
			if(PUBLIC != null){
				
					this.setProperty("PUBLIC", PUBLIC.toString());
				
			}
			
			if(THREAD != null){
				
					this.setProperty("THREAD", THREAD.toString());
				
			}
			
			if(ETL_LOCALHOSTNAME != null){
				
					this.setProperty("ETL_LOCALHOSTNAME", ETL_LOCALHOSTNAME.toString());
				
			}
			
			if(ETL_STORAGE_PATH != null){
				
					this.setProperty("ETL_STORAGE_PATH", ETL_STORAGE_PATH.toString());
				
			}
			
			if(HAWQ_Source_Ports != null){
				
					this.setProperty("HAWQ_Source_Ports", HAWQ_Source_Ports.toString());
				
			}
			
			if(SOURCE_DATABASE != null){
				
					this.setProperty("SOURCE_DATABASE", SOURCE_DATABASE.toString());
				
			}
			
			if(SOURCE_HOST != null){
				
					this.setProperty("SOURCE_HOST", SOURCE_HOST.toString());
				
			}
			
			if(SOURCE_PASSWORD != null){
				
					this.setProperty("SOURCE_PASSWORD", SOURCE_PASSWORD.toString());
				
			}
			
			if(SOURCE_PORT != null){
				
					this.setProperty("SOURCE_PORT", SOURCE_PORT.toString());
				
			}
			
			if(SOURCE_USER != null){
				
					this.setProperty("SOURCE_USER", SOURCE_USER.toString());
				
			}
			
			if(SOURCING_Database != null){
				
					this.setProperty("SOURCING_Database", SOURCING_Database.toString());
				
			}
			
			if(SOURCING_Login != null){
				
					this.setProperty("SOURCING_Login", SOURCING_Login.toString());
				
			}
			
			if(SOURCING_Password != null){
				
					this.setProperty("SOURCING_Password", SOURCING_Password.toString());
				
			}
			
			if(SOURCING_Port != null){
				
					this.setProperty("SOURCING_Port", SOURCING_Port.toString());
				
			}
			
			if(SOURCING_Schema != null){
				
					this.setProperty("SOURCING_Schema", SOURCING_Schema.toString());
				
			}
			
			if(SOURCING_Server != null){
				
					this.setProperty("SOURCING_Server", SOURCING_Server.toString());
				
			}
			
		}

public String GP_SOURCE_NAME;
public String getGP_SOURCE_NAME(){
	return this.GP_SOURCE_NAME;
}
public String TABLE_NAME;
public String getTABLE_NAME(){
	return this.TABLE_NAME;
}
public String FORCE_DROP;
public String getFORCE_DROP(){
	return this.FORCE_DROP;
}
public String LOAD2HDFS;
public String getLOAD2HDFS(){
	return this.LOAD2HDFS;
}
public Integer RUN_ID;
public Integer getRUN_ID(){
	return this.RUN_ID;
}
public String ORIG_DATABASE_NAME;
public String getORIG_DATABASE_NAME(){
	return this.ORIG_DATABASE_NAME;
}
public String FDIST_PARAM;
public String getFDIST_PARAM(){
	return this.FDIST_PARAM;
}
public Integer LOG_NO_OF_ERRORS;
public Integer getLOG_NO_OF_ERRORS(){
	return this.LOG_NO_OF_ERRORS;
}
public String LOG_PLANT_NAME;
public String getLOG_PLANT_NAME(){
	return this.LOG_PLANT_NAME;
}
public Integer LOG_NO_OF_UPDATES;
public Integer getLOG_NO_OF_UPDATES(){
	return this.LOG_NO_OF_UPDATES;
}
public Integer LOG_SOURCE_ROW_COUNT;
public Integer getLOG_SOURCE_ROW_COUNT(){
	return this.LOG_SOURCE_ROW_COUNT;
}
public String LOG_TECHNOLOGY;
public String getLOG_TECHNOLOGY(){
	return this.LOG_TECHNOLOGY;
}
public String LOG_TABLE_NAME;
public String getLOG_TABLE_NAME(){
	return this.LOG_TABLE_NAME;
}
public Integer LOG_NO_OF_INSERTS;
public Integer getLOG_NO_OF_INSERTS(){
	return this.LOG_NO_OF_INSERTS;
}
public String LOG_DATA_PATH;
public String getLOG_DATA_PATH(){
	return this.LOG_DATA_PATH;
}
public Integer LOG_NO_OF_DELETES;
public Integer getLOG_NO_OF_DELETES(){
	return this.LOG_NO_OF_DELETES;
}
public Integer LOG_RUN_ID;
public Integer getLOG_RUN_ID(){
	return this.LOG_RUN_ID;
}
public String LOG_ERROR_CATEGORY;
public String getLOG_ERROR_CATEGORY(){
	return this.LOG_ERROR_CATEGORY;
}
public String LOG_JOB_NAME;
public String getLOG_JOB_NAME(){
	return this.LOG_JOB_NAME;
}
public String LOG_SYSTEM_NAME;
public String getLOG_SYSTEM_NAME(){
	return this.LOG_SYSTEM_NAME;
}
public String LOG_MESSAGE;
public String getLOG_MESSAGE(){
	return this.LOG_MESSAGE;
}
public Integer LOG_TARGET_ROW_COUNT;
public Integer getLOG_TARGET_ROW_COUNT(){
	return this.LOG_TARGET_ROW_COUNT;
}
public String LOG_STATUS;
public String getLOG_STATUS(){
	return this.LOG_STATUS;
}
public String JOB_LABEL_NAME;
public String getJOB_LABEL_NAME(){
	return this.JOB_LABEL_NAME;
}
public String PLANT_NAME;
public String getPLANT_NAME(){
	return this.PLANT_NAME;
}
public String SEND_MAIL;
public String getSEND_MAIL(){
	return this.SEND_MAIL;
}
public String MAIL_TO;
public String getMAIL_TO(){
	return this.MAIL_TO;
}
public String PUBLIC;
public String getPUBLIC(){
	return this.PUBLIC;
}
public Integer THREAD;
public Integer getTHREAD(){
	return this.THREAD;
}
public String ETL_LOCALHOSTNAME;
public String getETL_LOCALHOSTNAME(){
	return this.ETL_LOCALHOSTNAME;
}
public String ETL_STORAGE_PATH;
public String getETL_STORAGE_PATH(){
	return this.ETL_STORAGE_PATH;
}
public String HAWQ_Source_Ports;
public String getHAWQ_Source_Ports(){
	return this.HAWQ_Source_Ports;
}
public String SOURCE_DATABASE;
public String getSOURCE_DATABASE(){
	return this.SOURCE_DATABASE;
}
public String SOURCE_HOST;
public String getSOURCE_HOST(){
	return this.SOURCE_HOST;
}
public java.lang.String SOURCE_PASSWORD;
public java.lang.String getSOURCE_PASSWORD(){
	return this.SOURCE_PASSWORD;
}
public Integer SOURCE_PORT;
public Integer getSOURCE_PORT(){
	return this.SOURCE_PORT;
}
public String SOURCE_USER;
public String getSOURCE_USER(){
	return this.SOURCE_USER;
}
public String SOURCING_Database;
public String getSOURCING_Database(){
	return this.SOURCING_Database;
}
public String SOURCING_Login;
public String getSOURCING_Login(){
	return this.SOURCING_Login;
}
public java.lang.String SOURCING_Password;
public java.lang.String getSOURCING_Password(){
	return this.SOURCING_Password;
}
public String SOURCING_Port;
public String getSOURCING_Port(){
	return this.SOURCING_Port;
}
public String SOURCING_Schema;
public String getSOURCING_Schema(){
	return this.SOURCING_Schema;
}
public String SOURCING_Server;
public String getSOURCING_Server(){
	return this.SOURCING_Server;
}
	}
	private ContextProperties context = new ContextProperties();
	public ContextProperties getContext() {
		return this.context;
	}
	private final String jobVersion = "0.1";
	private final String jobName = "EDL_Prod2Dev_with_GP_FDIST";
	private final String projectName = "AWS_DEV_TALEND_INGESTION_FRAMEWORK";
	public Integer errorCode = null;
	private String currentComponent = "";
	
		private final java.util.Map<String, Object> globalMap = java.util.Collections.synchronizedMap(new java.util.HashMap<String, Object>());
	
		private final java.util.Map<String, Long> start_Hash = java.util.Collections.synchronizedMap(new java.util.HashMap<String, Long>());
		private final java.util.Map<String, Long> end_Hash = java.util.Collections.synchronizedMap(new java.util.HashMap<String, Long>());
		private final java.util.Map<String, Boolean> ok_Hash = java.util.Collections.synchronizedMap(new java.util.HashMap<String, Boolean>());
		public  final java.util.List<String[]> globalBuffer = java.util.Collections.synchronizedList(new java.util.ArrayList<String[]>());
	

private RunStat runStat = new RunStat();

	// OSGi DataSource
	private final static String KEY_DB_DATASOURCES = "KEY_DB_DATASOURCES";

	public void setDataSources(java.util.Map<String, javax.sql.DataSource> dataSources) {
		java.util.Map<String, routines.system.TalendDataSource> talendDataSources = new java.util.HashMap<String, routines.system.TalendDataSource>();
		for (java.util.Map.Entry<String, javax.sql.DataSource> dataSourceEntry : dataSources.entrySet()) {
			talendDataSources.put(dataSourceEntry.getKey(), new routines.system.TalendDataSource(dataSourceEntry.getValue()));
		}
		globalMap.put(KEY_DB_DATASOURCES, talendDataSources);
	}

	LogCatcherUtils talendLogs_LOGS = new LogCatcherUtils();
	StatCatcherUtils talendStats_STATS = new StatCatcherUtils("_F420sISiEeaHiLEk6FDciQ", "0.1");
	MetterCatcherUtils talendMeter_METTER = new MetterCatcherUtils("_F420sISiEeaHiLEk6FDciQ", "0.1");

private final java.io.ByteArrayOutputStream baos = new java.io.ByteArrayOutputStream();
private final java.io.PrintStream errorMessagePS = new java.io.PrintStream(new java.io.BufferedOutputStream(baos));

public String getExceptionStackTrace() {
	if ("failure".equals(this.getStatus())) {
		errorMessagePS.flush();
		return baos.toString();
	}
	return null;
}

private Exception exception;

public Exception getException() {
	if ("failure".equals(this.getStatus())) {
		return this.exception;
	}
	return null;
}

private class TalendException extends Exception {

	private static final long serialVersionUID = 1L;

	private java.util.Map<String, Object> globalMap = null;
	private Exception e = null;
	private String currentComponent = null;
	private String virtualComponentName = null;
	
	public void setVirtualComponentName (String virtualComponentName){
		this.virtualComponentName = virtualComponentName;
	}

	private TalendException(Exception e, String errorComponent, final java.util.Map<String, Object> globalMap) {
		this.currentComponent= errorComponent;
		this.globalMap = globalMap;
		this.e = e;
	}

	public Exception getException() {
		return this.e;
	}

	public String getCurrentComponent() {
		return this.currentComponent;
	}

	
    public String getExceptionCauseMessage(Exception e){
        Throwable cause = e;
        String message = null;
        int i = 10;
        while (null != cause && 0 < i--) {
            message = cause.getMessage();
            if (null == message) {
                cause = cause.getCause();
            } else {
                break;          
            }
        }
        if (null == message) {
            message = e.getClass().getName();
        }   
        return message;
    }

	@Override
	public void printStackTrace() {
		if (!(e instanceof TalendException || e instanceof TDieException)) {
			if(virtualComponentName!=null && currentComponent.indexOf(virtualComponentName+"_")==0){
				globalMap.put(virtualComponentName+"_ERROR_MESSAGE",getExceptionCauseMessage(e));
			}
			 globalMap.put(currentComponent+"_ERROR_MESSAGE",getExceptionCauseMessage(e));
			System.err.println("Exception in component " + currentComponent);
		}
		if (!(e instanceof TDieException)) {
			if(e instanceof TalendException){
				e.printStackTrace();
			} else {
				e.printStackTrace();
				e.printStackTrace(errorMessagePS);
				EDL_Prod2Dev_with_GP_FDIST.this.exception = e;
			}
		}
		if (!(e instanceof TalendException)) {
		try {
			for (java.lang.reflect.Method m : this.getClass().getEnclosingClass().getMethods()) {
				if (m.getName().compareTo(currentComponent + "_error") == 0) {
					m.invoke(EDL_Prod2Dev_with_GP_FDIST.this, new Object[] { e , currentComponent, globalMap});
					break;
				}
			}

			if(!(e instanceof TDieException)){
				talendLogs_LOGS.addMessage("Java Exception", currentComponent, 6, e.getClass().getName() + ":" + e.getMessage(), 1);
				talendLogs_LOGSProcess(globalMap);
			}
				} catch (TalendException e) {
					// do nothing
				
		} catch (Exception e) {
			this.e.printStackTrace();
		}
		}
	}
}

			public void tJava_2_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				((java.util.Map)threadLocal.get()).put("status", "failure");
				
					tJava_2_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tGreenplumInput_9_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				((java.util.Map)threadLocal.get()).put("status", "failure");
				
					tGreenplumInput_9_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tMap_2_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				((java.util.Map)threadLocal.get()).put("status", "failure");
				
					tGreenplumInput_9_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tFileOutputDelimitedGE_3_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				((java.util.Map)threadLocal.get()).put("status", "failure");
				
					tGreenplumInput_9_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tGreenplumClose_3_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				((java.util.Map)threadLocal.get()).put("status", "failure");
				
					tGreenplumClose_3_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tJava_5_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				((java.util.Map)threadLocal.get()).put("status", "failure");
				
					tJava_5_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tGreenplumConnection_3_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				((java.util.Map)threadLocal.get()).put("status", "failure");
				
					tGreenplumConnection_3_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tGreenplumInput_5_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				((java.util.Map)threadLocal.get()).put("status", "failure");
				
					tGreenplumInput_5_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tJavaRow_3_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				((java.util.Map)threadLocal.get()).put("status", "failure");
				
					tGreenplumInput_5_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tJava_7_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				((java.util.Map)threadLocal.get()).put("status", "failure");
				
					tJava_7_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tGreenplumRow_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				((java.util.Map)threadLocal.get()).put("status", "failure");
				
					tGreenplumRow_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tGreenplumClose_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				((java.util.Map)threadLocal.get()).put("status", "failure");
				
					tGreenplumClose_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tFileInputDelimited_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				((java.util.Map)threadLocal.get()).put("status", "failure");
				
					tFileInputDelimited_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tJavaRow_6_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				((java.util.Map)threadLocal.get()).put("status", "failure");
				
					tFileInputDelimited_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tFlowToIterate_2_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				((java.util.Map)threadLocal.get()).put("status", "failure");
				
					tFileInputDelimited_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tRunJob_2_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				((java.util.Map)threadLocal.get()).put("status", "failure");
				
					tFileInputDelimited_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tFileDelete_2_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
							talendStats_STATS.addMessage("failure",errorComponent, end_Hash.get(errorComponent)-start_Hash.get(errorComponent));
							talendStats_STATSProcess(globalMap);
							
				((java.util.Map)threadLocal.get()).put("status", "failure");
				
					tFileDelete_2_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tGreenplumConnection_6_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				((java.util.Map)threadLocal.get()).put("status", "failure");
				
					tGreenplumConnection_6_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tGreenplumInput_10_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				((java.util.Map)threadLocal.get()).put("status", "failure");
				
					tGreenplumInput_10_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tSetGlobalVar_6_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				((java.util.Map)threadLocal.get()).put("status", "failure");
				
					tGreenplumInput_10_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tGreenplumInput_11_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				((java.util.Map)threadLocal.get()).put("status", "failure");
				
					tGreenplumInput_11_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tSetGlobalVar_7_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				((java.util.Map)threadLocal.get()).put("status", "failure");
				
					tGreenplumInput_11_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tJava_11_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				((java.util.Map)threadLocal.get()).put("status", "failure");
				
					tJava_11_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tGreenplumConnection_7_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				((java.util.Map)threadLocal.get()).put("status", "failure");
				
					tGreenplumConnection_7_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tGreenplumInput_12_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				((java.util.Map)threadLocal.get()).put("status", "failure");
				
					tGreenplumInput_12_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tJavaRow_5_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				((java.util.Map)threadLocal.get()).put("status", "failure");
				
					tGreenplumInput_12_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tJava_13_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				((java.util.Map)threadLocal.get()).put("status", "failure");
				
					tJava_13_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tGreenplumRow_3_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				((java.util.Map)threadLocal.get()).put("status", "failure");
				
					tGreenplumRow_3_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tGreenplumClose_4_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				((java.util.Map)threadLocal.get()).put("status", "failure");
				
					tGreenplumClose_4_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tJava_15_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				((java.util.Map)threadLocal.get()).put("status", "failure");
				
					tJava_15_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tRunJob_3_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				((java.util.Map)threadLocal.get()).put("status", "failure");
				
					tRunJob_3_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tJava_9_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				((java.util.Map)threadLocal.get()).put("status", "failure");
				
					tJava_9_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tJava_12_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				((java.util.Map)threadLocal.get()).put("status", "failure");
				
					tJava_12_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tGreenplumConnection_8_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				((java.util.Map)threadLocal.get()).put("status", "failure");
				
					tGreenplumConnection_8_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tGreenplumInput_13_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				((java.util.Map)threadLocal.get()).put("status", "failure");
				
					tGreenplumInput_13_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tFlowToIterate_3_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				((java.util.Map)threadLocal.get()).put("status", "failure");
				
					tGreenplumInput_13_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tGreenplumRow_4_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				((java.util.Map)threadLocal.get()).put("status", "failure");
				
					tGreenplumInput_13_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tGreenplumClose_5_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				((java.util.Map)threadLocal.get()).put("status", "failure");
				
					tGreenplumClose_5_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tJava_3_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				((java.util.Map)threadLocal.get()).put("status", "failure");
				
					tJava_3_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tSetGlobalVar_3_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				((java.util.Map)threadLocal.get()).put("status", "failure");
				
					tSetGlobalVar_3_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tGreenplumConnection_4_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				((java.util.Map)threadLocal.get()).put("status", "failure");
				
					tGreenplumConnection_4_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tGreenplumInput_6_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				((java.util.Map)threadLocal.get()).put("status", "failure");
				
					tGreenplumInput_6_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tSetGlobalVar_4_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				((java.util.Map)threadLocal.get()).put("status", "failure");
				
					tGreenplumInput_6_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tGreenplumInput_8_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				((java.util.Map)threadLocal.get()).put("status", "failure");
				
					tGreenplumInput_8_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tSetGlobalVar_5_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				((java.util.Map)threadLocal.get()).put("status", "failure");
				
					tGreenplumInput_8_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tJava_10_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				((java.util.Map)threadLocal.get()).put("status", "failure");
				
					tJava_10_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tJava_16_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				((java.util.Map)threadLocal.get()).put("status", "failure");
				
					tJava_16_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tFileOutputDelimitedGE_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				((java.util.Map)threadLocal.get()).put("status", "failure");
				
					tFileOutputDelimitedGE_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void talendLogs_LOGS_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
							talendLogs_CONSOLE_error(exception, errorComponent, globalMap);
						
						}
					
			public void talendLogs_CONSOLE_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				((java.util.Map)threadLocal.get()).put("status", "failure");
				
					talendLogs_LOGS_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void talendStats_STATS_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
							talendStats_CONSOLE_error(exception, errorComponent, globalMap);
						
						}
					
			public void talendStats_CONSOLE_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				((java.util.Map)threadLocal.get()).put("status", "failure");
				
					talendStats_STATS_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void talendMeter_METTER_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
							talendMeter_CONSOLE_error(exception, errorComponent, globalMap);
						
						}
					
			public void talendMeter_CONSOLE_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				((java.util.Map)threadLocal.get()).put("status", "failure");
				
					talendMeter_METTER_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tJava_2_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tGreenplumInput_9_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tGreenplumClose_3_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tJava_5_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tGreenplumConnection_3_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tGreenplumInput_5_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tJava_7_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tGreenplumRow_1_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tGreenplumClose_1_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tFileInputDelimited_1_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tFileDelete_2_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tGreenplumConnection_6_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tGreenplumInput_10_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tGreenplumInput_11_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tJava_11_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tGreenplumConnection_7_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tGreenplumInput_12_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tJava_13_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tGreenplumRow_3_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tGreenplumClose_4_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tJava_15_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tRunJob_3_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tJava_9_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tJava_12_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tGreenplumConnection_8_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tGreenplumInput_13_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tGreenplumClose_5_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tJava_3_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tSetGlobalVar_3_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tGreenplumConnection_4_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tGreenplumInput_6_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tGreenplumInput_8_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tJava_10_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tJava_16_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tFileOutputDelimitedGE_1_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void talendLogs_LOGS_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void talendStats_STATS_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void talendMeter_METTER_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			








public void tJava_2Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tJava_2_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tJava_2 begin ] start
	 */

	

	
		
		ok_Hash.put("tJava_2", false);
		start_Hash.put("tJava_2", System.currentTimeMillis());
		
	
	currentComponent="tJava_2";

	
		int tos_count_tJava_2 = 0;
		
    	class BytesLimit65535_tJava_2{
    		public void limitLog4jByte() throws Exception{
    			
    		}
    	}
    	
        new BytesLimit65535_tJava_2().limitLog4jByte();


System.out.println(context.TABLE_NAME);
System.out.println((String)globalMap.get("job_name"));
System.out.println(context.GP_SOURCE_NAME);


	
System.out.println(context.TABLE_NAME);

String strGpSqlTemplate=
"SELECT target_table_name log_table_name, ingestion_tool technology "+
"FROM sbdt.edl_table "+
"WHERE "+
"  (source_schema<>'na' OR '#JOB_NAME'='HVR_stats') AND "+
"  enabled='Y' AND "+
"  system_name='#GP_SOURCE_NAME' AND "+
"  update_type IN ('Incremental', 'Full','Append','Softdelete') "+
"  #TABLE_NAME "+
"ORDER BY load_order";
System.out.println((String)globalMap.get("gp_sql"));
String strGpSql=strGpSqlTemplate;
strGpSql=strGpSql.replace("#JOB_NAME", (String)globalMap.get("job_name"));
strGpSql=strGpSql.replace("#GP_SOURCE_NAME", context.GP_SOURCE_NAME);
strGpSql=strGpSql.replace("#TABLE_NAME", context.TABLE_NAME);
globalMap.put("gp_sql",strGpSql);
 



/**
 * [tJava_2 begin ] stop
 */
	
	/**
	 * [tJava_2 main ] start
	 */

	

	
	
	currentComponent="tJava_2";

	

 


	tos_count_tJava_2++;

/**
 * [tJava_2 main ] stop
 */
	
	/**
	 * [tJava_2 end ] start
	 */

	

	
	
	currentComponent="tJava_2";

	

 

ok_Hash.put("tJava_2", true);
end_Hash.put("tJava_2", System.currentTimeMillis());




/**
 * [tJava_2 end ] stop
 */
				}//end the resume

				
				    			if(resumeEntryMethodName == null || globalResumeTicket){
				    				resumeUtil.addLog("CHECKPOINT", "CONNECTION:SUBJOB_OK:tJava_2:OnSubjobOk", "", Thread.currentThread().getId() + "", "", "", "", "", "");
								}	    				    			
					    	
								if(execStat){    	
									runStat.updateStatOnConnection("OnSubjobOk27", 0, "ok");
								} 
							
							tGreenplumInput_9Process(globalMap); 
						



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage());
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tJava_2 finally ] start
	 */

	

	
	
	currentComponent="tJava_2";

	

 



/**
 * [tJava_2 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tJava_2_SUBPROCESS_STATE", 1);
	}
	


public static class copyOffsStruct implements routines.system.IPersistableRow<copyOffsStruct> {
    final static byte[] commonByteArrayLock_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Prod2Dev_with_GP_FDIST = new byte[0];
    static byte[] commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Prod2Dev_with_GP_FDIST = new byte[0];
	protected static final int DEFAULT_HASHCODE = 1;
    protected static final int PRIME = 31;
    protected int hashCode = DEFAULT_HASHCODE;
    public boolean hashCodeDirty = true;

    public String loopKey;



	
			    public String log_table_name;

				public String getLog_table_name () {
					return this.log_table_name;
				}
				
			    public String technology;

				public String getTechnology () {
					return this.technology;
				}
				


	@Override
	public int hashCode() {
		if (this.hashCodeDirty) {
			final int prime = PRIME;
			int result = DEFAULT_HASHCODE;
	
						result = prime * result + ((this.log_table_name == null) ? 0 : this.log_table_name.hashCode());
					
    		this.hashCode = result;
    		this.hashCodeDirty = false;
		}
		return this.hashCode;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) return true;
		if (obj == null) return false;
		if (getClass() != obj.getClass()) return false;
		final copyOffsStruct other = (copyOffsStruct) obj;
		
						if (this.log_table_name == null) {
							if (other.log_table_name != null)
								return false;
						
						} else if (!this.log_table_name.equals(other.log_table_name))
						
							return false;
					

		return true;
    }

	public void copyDataTo(copyOffsStruct other) {

		other.log_table_name = this.log_table_name;
	            other.technology = this.technology;
	            
	}

	public void copyKeysDataTo(copyOffsStruct other) {

		other.log_table_name = this.log_table_name;
	            	
	}




	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Prod2Dev_with_GP_FDIST.length) {
				if(length < 1024 && commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Prod2Dev_with_GP_FDIST.length == 0) {
   					commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Prod2Dev_with_GP_FDIST = new byte[1024];
				} else {
   					commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Prod2Dev_with_GP_FDIST = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Prod2Dev_with_GP_FDIST, 0, length);
			strReturn = new String(commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Prod2Dev_with_GP_FDIST, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Prod2Dev_with_GP_FDIST) {

        	try {

        		int length = 0;
		
					this.log_table_name = readString(dis);
					
					this.technology = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// String
				
						writeString(this.log_table_name,dos);
					
					// String
				
						writeString(this.technology,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("log_table_name="+log_table_name);
		sb.append(",technology="+technology);
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				if(log_table_name == null){
        					sb.append("<null>");
        				}else{
            				sb.append(log_table_name);
            			}
            		
        			sb.append("|");
        		
        				if(technology == null){
        					sb.append("<null>");
        				}else{
            				sb.append(technology);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(copyOffsStruct other) {

		int returnValue = -1;
		
						returnValue = checkNullsAndCompare(this.log_table_name, other.log_table_name);
						if(returnValue != 0) {
							return returnValue;
						}

					
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public static class row8Struct implements routines.system.IPersistableRow<row8Struct> {
    final static byte[] commonByteArrayLock_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Prod2Dev_with_GP_FDIST = new byte[0];
    static byte[] commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Prod2Dev_with_GP_FDIST = new byte[0];

	
			    public String log_table_name;

				public String getLog_table_name () {
					return this.log_table_name;
				}
				
			    public String technology;

				public String getTechnology () {
					return this.technology;
				}
				



	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Prod2Dev_with_GP_FDIST.length) {
				if(length < 1024 && commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Prod2Dev_with_GP_FDIST.length == 0) {
   					commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Prod2Dev_with_GP_FDIST = new byte[1024];
				} else {
   					commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Prod2Dev_with_GP_FDIST = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Prod2Dev_with_GP_FDIST, 0, length);
			strReturn = new String(commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Prod2Dev_with_GP_FDIST, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Prod2Dev_with_GP_FDIST) {

        	try {

        		int length = 0;
		
					this.log_table_name = readString(dis);
					
					this.technology = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// String
				
						writeString(this.log_table_name,dos);
					
					// String
				
						writeString(this.technology,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("log_table_name="+log_table_name);
		sb.append(",technology="+technology);
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				if(log_table_name == null){
        					sb.append("<null>");
        				}else{
            				sb.append(log_table_name);
            			}
            		
        			sb.append("|");
        		
        				if(technology == null){
        					sb.append("<null>");
        				}else{
            				sb.append(technology);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(row8Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}
public void tGreenplumInput_9Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tGreenplumInput_9_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;



		row8Struct row8 = new row8Struct();
copyOffsStruct copyOffs = new copyOffsStruct();





	
	/**
	 * [tFileOutputDelimitedGE_3 begin ] start
	 */

	

	
		
		ok_Hash.put("tFileOutputDelimitedGE_3", false);
		start_Hash.put("tFileOutputDelimitedGE_3", System.currentTimeMillis());
		
	
	currentComponent="tFileOutputDelimitedGE_3";

	
			if (execStat) {
				if(resourceMap.get("inIterateVComp") == null){
					
						runStat.updateStatOnConnection("copyOffs" + iterateId, 0, 0);
					
				}
			} 

		
		int tos_count_tFileOutputDelimitedGE_3 = 0;
		
    	class BytesLimit65535_tFileOutputDelimitedGE_3{
    		public void limitLog4jByte() throws Exception{
    			
    		}
    	}
    	
        new BytesLimit65535_tFileOutputDelimitedGE_3().limitLog4jByte();

    String log4jFileOutputDelimitedParamters_tFileOutputDelimitedGE_3 = "";
    log4jFileOutputDelimitedParamters_tFileOutputDelimitedGE_3 = log4jFileOutputDelimitedParamters_tFileOutputDelimitedGE_3 + "FILENAME = " + context.ETL_STORAGE_PATH + "/" +context.GP_SOURCE_NAME + "/" +((String)globalMap.get("timestamp"))+".csv" + " | ";
    log4jFileOutputDelimitedParamters_tFileOutputDelimitedGE_3 = log4jFileOutputDelimitedParamters_tFileOutputDelimitedGE_3 + "CSV_OPTION = " + false + " | ";
    log4jFileOutputDelimitedParamters_tFileOutputDelimitedGE_3 = log4jFileOutputDelimitedParamters_tFileOutputDelimitedGE_3 + "FIELDSEPARATOR = " + ";" + " | ";
    log4jFileOutputDelimitedParamters_tFileOutputDelimitedGE_3 = log4jFileOutputDelimitedParamters_tFileOutputDelimitedGE_3 + "INCLUDE_HEADER = " + false + " | ";
        log4jFileOutputDelimitedParamters_tFileOutputDelimitedGE_3 = log4jFileOutputDelimitedParamters_tFileOutputDelimitedGE_3 + "COMPRESS = " + false + " | ";
    log4jFileOutputDelimitedParamters_tFileOutputDelimitedGE_3 = log4jFileOutputDelimitedParamters_tFileOutputDelimitedGE_3 + "APPEND = " + false + " | ";
    log4jFileOutputDelimitedParamters_tFileOutputDelimitedGE_3 = log4jFileOutputDelimitedParamters_tFileOutputDelimitedGE_3 + "CREATE_DIRECTORY_IF_NOT_EXISTS = " + true + " | ";
    log4jFileOutputDelimitedParamters_tFileOutputDelimitedGE_3 = log4jFileOutputDelimitedParamters_tFileOutputDelimitedGE_3 + "SPLIT_INTO_SEVERAL_FILES = " + false + " | ";
    log4jFileOutputDelimitedParamters_tFileOutputDelimitedGE_3 = log4jFileOutputDelimitedParamters_tFileOutputDelimitedGE_3 + "OUTPUT_IN_ROW_MODE = " + false + " | ";

    log4jFileOutputDelimitedParamters_tFileOutputDelimitedGE_3 = "tFileOutputDelimitedGE_3 - Parameters:" + log4jFileOutputDelimitedParamters_tFileOutputDelimitedGE_3;
    log.debug(log4jFileOutputDelimitedParamters_tFileOutputDelimitedGE_3);
    StringBuffer log4jSb_tFileOutputDelimitedGE_3 = new StringBuffer();
    log.info("tFileOutputDelimitedGE_3 - Start to work.");
String fileName_tFileOutputDelimitedGE_3 = "";
    fileName_tFileOutputDelimitedGE_3 = (new java.io.File(context.ETL_STORAGE_PATH + "/" +context.GP_SOURCE_NAME + "/" +((String)globalMap.get("timestamp"))+".csv")).getAbsolutePath().replace("\\","/");
    String fullName_tFileOutputDelimitedGE_3 = null;
    String extension_tFileOutputDelimitedGE_3 = null;
    String directory_tFileOutputDelimitedGE_3 = null;
    if((fileName_tFileOutputDelimitedGE_3.indexOf("/") != -1)) {
        if(fileName_tFileOutputDelimitedGE_3.lastIndexOf(".") < fileName_tFileOutputDelimitedGE_3.lastIndexOf("/")) {
            fullName_tFileOutputDelimitedGE_3 = fileName_tFileOutputDelimitedGE_3;
            extension_tFileOutputDelimitedGE_3 = "";
        } else {
            fullName_tFileOutputDelimitedGE_3 = fileName_tFileOutputDelimitedGE_3.substring(0, fileName_tFileOutputDelimitedGE_3.lastIndexOf("."));
            extension_tFileOutputDelimitedGE_3 = fileName_tFileOutputDelimitedGE_3.substring(fileName_tFileOutputDelimitedGE_3.lastIndexOf("."));
        }
        directory_tFileOutputDelimitedGE_3 = fileName_tFileOutputDelimitedGE_3.substring(0, fileName_tFileOutputDelimitedGE_3.lastIndexOf("/"));
    } else {
        if(fileName_tFileOutputDelimitedGE_3.lastIndexOf(".") != -1) {
            fullName_tFileOutputDelimitedGE_3 = fileName_tFileOutputDelimitedGE_3.substring(0, fileName_tFileOutputDelimitedGE_3.lastIndexOf("."));
            extension_tFileOutputDelimitedGE_3 = fileName_tFileOutputDelimitedGE_3.substring(fileName_tFileOutputDelimitedGE_3.lastIndexOf("."));
        } else {
            fullName_tFileOutputDelimitedGE_3 = fileName_tFileOutputDelimitedGE_3;
            extension_tFileOutputDelimitedGE_3 = "";
        }
        directory_tFileOutputDelimitedGE_3 = "";
    }
    boolean isFileGenerated_tFileOutputDelimitedGE_3 = true;
    java.io.File filetFileOutputDelimitedGE_3 = new java.io.File(fileName_tFileOutputDelimitedGE_3);
    globalMap.put("tFileOutputDelimitedGE_3_FILE_NAME",fileName_tFileOutputDelimitedGE_3);
            int nb_line_tFileOutputDelimitedGE_3 = 0;
            int splitEvery_tFileOutputDelimitedGE_3 = 1000;
            int splitedFileNo_tFileOutputDelimitedGE_3 = 0;
            int currentRow_tFileOutputDelimitedGE_3 = 0;

            final String OUT_DELIM_tFileOutputDelimitedGE_3 = /** Start field tFileOutputDelimitedGE_3:FIELDSEPARATOR */";"/** End field tFileOutputDelimitedGE_3:FIELDSEPARATOR */;

            final String OUT_DELIM_ROWSEP_tFileOutputDelimitedGE_3 = /** Start field tFileOutputDelimitedGE_3:ROWSEPARATOR */"\n"/** End field tFileOutputDelimitedGE_3:ROWSEPARATOR */;

                    //create directory only if not exists
                    if(directory_tFileOutputDelimitedGE_3 != null && directory_tFileOutputDelimitedGE_3.trim().length() != 0) {
                        java.io.File dir_tFileOutputDelimitedGE_3 = new java.io.File(directory_tFileOutputDelimitedGE_3);
                        if(!dir_tFileOutputDelimitedGE_3.exists()) {
                                log.info("tFileOutputDelimitedGE_3 - Creating directory '" + dir_tFileOutputDelimitedGE_3.getCanonicalPath() +"'.");
                            dir_tFileOutputDelimitedGE_3.mkdirs();
                                log.info("tFileOutputDelimitedGE_3 - The directoy '"+ dir_tFileOutputDelimitedGE_3.getCanonicalPath() + "' has been created successfully.");
                        }
                    }

                        //routines.system.Row
                        java.io.Writer outtFileOutputDelimitedGE_3 = null;
                        outtFileOutputDelimitedGE_3 = new java.io.BufferedWriter(new java.io.OutputStreamWriter(
                        new java.io.FileOutputStream(fileName_tFileOutputDelimitedGE_3, false),"ISO-8859-15"));


        resourceMap.put("out_tFileOutputDelimitedGE_3", outtFileOutputDelimitedGE_3);
resourceMap.put("nb_line_tFileOutputDelimitedGE_3", nb_line_tFileOutputDelimitedGE_3);
 



/**
 * [tFileOutputDelimitedGE_3 begin ] stop
 */



	
	/**
	 * [tMap_2 begin ] start
	 */

	

	
		
		ok_Hash.put("tMap_2", false);
		start_Hash.put("tMap_2", System.currentTimeMillis());
		
	
	currentComponent="tMap_2";

	
			if (execStat) {
				if(resourceMap.get("inIterateVComp") == null){
					
						runStat.updateStatOnConnection("row8" + iterateId, 0, 0);
					
				}
			} 

		
		int tos_count_tMap_2 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tMap_2 - "  + ("Start to work.") );
    	class BytesLimit65535_tMap_2{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tMap_2 = new StringBuilder();
            log4jParamters_tMap_2.append("Parameters:");
                    log4jParamters_tMap_2.append("LINK_STYLE" + " = " + "AUTO");
                log4jParamters_tMap_2.append(" | ");
                    log4jParamters_tMap_2.append("TEMPORARY_DATA_DIRECTORY" + " = " + "");
                log4jParamters_tMap_2.append(" | ");
                    log4jParamters_tMap_2.append("ROWS_BUFFER_SIZE" + " = " + "2000000");
                log4jParamters_tMap_2.append(" | ");
                    log4jParamters_tMap_2.append("CHANGE_HASH_AND_EQUALS_FOR_BIGDECIMAL" + " = " + "false");
                log4jParamters_tMap_2.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tMap_2 - "  + (log4jParamters_tMap_2) );
    		}
    	}
    	
        new BytesLimit65535_tMap_2().limitLog4jByte();




// ###############################
// # Lookup's keys initialization
		int count_row8_tMap_2 = 0;
		
// ###############################        

// ###############################
// # Vars initialization
class  Var__tMap_2__Struct  {
}
Var__tMap_2__Struct Var__tMap_2 = new Var__tMap_2__Struct();
// ###############################

// ###############################
// # Outputs initialization
				int count_copyOffs_tMap_2 = 0;
				
copyOffsStruct copyOffs_tmp = new copyOffsStruct();
// ###############################

        
        



        









 



/**
 * [tMap_2 begin ] stop
 */



	
	/**
	 * [tGreenplumInput_9 begin ] start
	 */

	

	
		
		ok_Hash.put("tGreenplumInput_9", false);
		start_Hash.put("tGreenplumInput_9", System.currentTimeMillis());
		
	
	currentComponent="tGreenplumInput_9";

	
		int tos_count_tGreenplumInput_9 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tGreenplumInput_9 - "  + ("Start to work.") );
    	class BytesLimit65535_tGreenplumInput_9{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tGreenplumInput_9 = new StringBuilder();
            log4jParamters_tGreenplumInput_9.append("Parameters:");
                    log4jParamters_tGreenplumInput_9.append("USE_EXISTING_CONNECTION" + " = " + "true");
                log4jParamters_tGreenplumInput_9.append(" | ");
                    log4jParamters_tGreenplumInput_9.append("CONNECTION" + " = " + "tGreenplumConnection_4");
                log4jParamters_tGreenplumInput_9.append(" | ");
                    log4jParamters_tGreenplumInput_9.append("TABLE" + " = " + "\"\"");
                log4jParamters_tGreenplumInput_9.append(" | ");
                    log4jParamters_tGreenplumInput_9.append("QUERYSTORE" + " = " + "\"\"");
                log4jParamters_tGreenplumInput_9.append(" | ");
                    log4jParamters_tGreenplumInput_9.append("QUERY" + " = " + "(String)globalMap.get(\"gp_sql\");");
                log4jParamters_tGreenplumInput_9.append(" | ");
                    log4jParamters_tGreenplumInput_9.append("USE_CURSOR" + " = " + "false");
                log4jParamters_tGreenplumInput_9.append(" | ");
                    log4jParamters_tGreenplumInput_9.append("TRIM_ALL_COLUMN" + " = " + "false");
                log4jParamters_tGreenplumInput_9.append(" | ");
                    log4jParamters_tGreenplumInput_9.append("TRIM_COLUMN" + " = " + "[{TRIM="+("false")+", SCHEMA_COLUMN="+("log_table_name")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("technology")+"}]");
                log4jParamters_tGreenplumInput_9.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tGreenplumInput_9 - "  + (log4jParamters_tGreenplumInput_9) );
    		}
    	}
    	
        new BytesLimit65535_tGreenplumInput_9().limitLog4jByte();
	
    
	
		    int nb_line_tGreenplumInput_9 = 0;
		    java.sql.Connection conn_tGreenplumInput_9 = null;
		        conn_tGreenplumInput_9 = (java.sql.Connection)globalMap.get("conn_tGreenplumConnection_4");
				
				if(conn_tGreenplumInput_9 != null) {
					if(conn_tGreenplumInput_9.getMetaData() != null) {
						
						log.debug("tGreenplumInput_9 - Uses an existing connection with username '" + conn_tGreenplumInput_9.getMetaData().getUserName() + "'. Connection URL: " + conn_tGreenplumInput_9.getMetaData().getURL() + ".");
						
					}
				}
			
		    
			java.sql.Statement stmt_tGreenplumInput_9 = conn_tGreenplumInput_9.createStatement();

		    String dbquery_tGreenplumInput_9 = (String)globalMap.get("gp_sql");;
			
                log.debug("tGreenplumInput_9 - Executing the query: '"+dbquery_tGreenplumInput_9+"'.");
			

                       globalMap.put("tGreenplumInput_9_QUERY",dbquery_tGreenplumInput_9);

		    java.sql.ResultSet rs_tGreenplumInput_9 = null;
		try{
		    rs_tGreenplumInput_9 = stmt_tGreenplumInput_9.executeQuery(dbquery_tGreenplumInput_9);
		    java.sql.ResultSetMetaData rsmd_tGreenplumInput_9 = rs_tGreenplumInput_9.getMetaData();
		    int colQtyInRs_tGreenplumInput_9 = rsmd_tGreenplumInput_9.getColumnCount();

		    String tmpContent_tGreenplumInput_9 = null;
		    
		    
		    	log.debug("tGreenplumInput_9 - Retrieving records from the database.");
		    
		    while (rs_tGreenplumInput_9.next()) {
		        nb_line_tGreenplumInput_9++;
		        
							if(colQtyInRs_tGreenplumInput_9 < 1) {
								row8.log_table_name = null;
							} else {
	                         		
        	row8.log_table_name = routines.system.JDBCUtil.getString(rs_tGreenplumInput_9, 1, false);
		                    }
							if(colQtyInRs_tGreenplumInput_9 < 2) {
								row8.technology = null;
							} else {
	                         		
        	row8.technology = routines.system.JDBCUtil.getString(rs_tGreenplumInput_9, 2, false);
		                    }
					
						log.debug("tGreenplumInput_9 - Retrieving the record " + nb_line_tGreenplumInput_9 + ".");
					


 



/**
 * [tGreenplumInput_9 begin ] stop
 */
	
	/**
	 * [tGreenplumInput_9 main ] start
	 */

	

	
	
	currentComponent="tGreenplumInput_9";

	

 


	tos_count_tGreenplumInput_9++;

/**
 * [tGreenplumInput_9 main ] stop
 */

	
	/**
	 * [tMap_2 main ] start
	 */

	

	
	
	currentComponent="tMap_2";

	

			//row8
			//row8


			
				if(execStat){
					runStat.updateStatOnConnection("row8"+iterateId,1, 1);
				} 
			

		
    			if(log.isTraceEnabled()){
    				log.trace("row8 - " + (row8==null? "": row8.toLogString()));
    			}
    		

		
		
		boolean hasCasePrimitiveKeyWithNull_tMap_2 = false;
		
        // ###############################
        // # Input tables (lookups)
		  boolean rejectedInnerJoin_tMap_2 = false;
		  boolean mainRowRejected_tMap_2 = false;
            				    								  
		// ###############################
        { // start of Var scope
        
	        // ###############################
        	// # Vars tables
        
Var__tMap_2__Struct Var = Var__tMap_2;// ###############################
        // ###############################
        // # Output tables

copyOffs = null;


// # Output table : 'copyOffs'
count_copyOffs_tMap_2++;

copyOffs_tmp.log_table_name = row8.log_table_name;
copyOffs_tmp.technology = row8.technology ;
copyOffs = copyOffs_tmp;
log.debug("tMap_2 - Outputting the record " + count_copyOffs_tMap_2 + " of the output table 'copyOffs'.");

// ###############################

} // end of Var scope

rejectedInnerJoin_tMap_2 = false;










 


	tos_count_tMap_2++;

/**
 * [tMap_2 main ] stop
 */
// Start of branch "copyOffs"
if(copyOffs != null) { 



	
	/**
	 * [tFileOutputDelimitedGE_3 main ] start
	 */

	

	
	
	currentComponent="tFileOutputDelimitedGE_3";

	

			//copyOffs
			//copyOffs


			
				if(execStat){
					runStat.updateStatOnConnection("copyOffs"+iterateId,1, 1);
				} 
			

		
    			if(log.isTraceEnabled()){
    				log.trace("copyOffs - " + (copyOffs==null? "": copyOffs.toLogString()));
    			}
    		


                    StringBuilder sb_tFileOutputDelimitedGE_3 = new StringBuilder();
                            if(copyOffs.log_table_name != null) {
                        sb_tFileOutputDelimitedGE_3.append(
                            copyOffs.log_table_name
                        );
                            }
                            sb_tFileOutputDelimitedGE_3.append(OUT_DELIM_tFileOutputDelimitedGE_3);
                            if(copyOffs.technology != null) {
                        sb_tFileOutputDelimitedGE_3.append(
                            copyOffs.technology
                        );
                            }
                    sb_tFileOutputDelimitedGE_3.append(OUT_DELIM_ROWSEP_tFileOutputDelimitedGE_3);


                    synchronized (multiThreadLockWrite) {
                    nb_line_tFileOutputDelimitedGE_3++;
                    resourceMap.put("nb_line_tFileOutputDelimitedGE_3", nb_line_tFileOutputDelimitedGE_3);

                        outtFileOutputDelimitedGE_3.write(sb_tFileOutputDelimitedGE_3.toString());
                        log.debug("tFileOutputDelimitedGE_3 - Writing the record " + nb_line_tFileOutputDelimitedGE_3 + ".");
                        log.trace("tFileOutputDelimitedGE_3 - Content of the record " + nb_line_tFileOutputDelimitedGE_3 + ": " + sb_tFileOutputDelimitedGE_3);

                    }



 


	tos_count_tFileOutputDelimitedGE_3++;

/**
 * [tFileOutputDelimitedGE_3 main ] stop
 */

} // End of branch "copyOffs"







	
	/**
	 * [tGreenplumInput_9 end ] start
	 */

	

	
	
	currentComponent="tGreenplumInput_9";

	

	}
}finally{
	stmt_tGreenplumInput_9.close();

}
globalMap.put("tGreenplumInput_9_NB_LINE",nb_line_tGreenplumInput_9);
	    		log.debug("tGreenplumInput_9 - Retrieved records count: "+nb_line_tGreenplumInput_9 + " .");
			

 
                if(log.isDebugEnabled())
            log.debug("tGreenplumInput_9 - "  + ("Done.") );

ok_Hash.put("tGreenplumInput_9", true);
end_Hash.put("tGreenplumInput_9", System.currentTimeMillis());




/**
 * [tGreenplumInput_9 end ] stop
 */

	
	/**
	 * [tMap_2 end ] start
	 */

	

	
	
	currentComponent="tMap_2";

	


// ###############################
// # Lookup hashes releasing
// ###############################      
				log.debug("tMap_2 - Written records count in the table 'copyOffs': " + count_copyOffs_tMap_2 + ".");





			if(execStat){
				if(resourceMap.get("inIterateVComp") == null || !((Boolean)resourceMap.get("inIterateVComp"))){
			 		runStat.updateStatOnConnection("row8"+iterateId,2, 0); 
			 	}
			}
		
 
                if(log.isDebugEnabled())
            log.debug("tMap_2 - "  + ("Done.") );

ok_Hash.put("tMap_2", true);
end_Hash.put("tMap_2", System.currentTimeMillis());




/**
 * [tMap_2 end ] stop
 */

	
	/**
	 * [tFileOutputDelimitedGE_3 end ] start
	 */

	

	
	
	currentComponent="tFileOutputDelimitedGE_3";

	



		
	   		synchronized (multiThreadLockWrite) {
		
			
					if(outtFileOutputDelimitedGE_3!=null) {
						outtFileOutputDelimitedGE_3.flush();
						outtFileOutputDelimitedGE_3.close();
					}
				
				globalMap.put("tFileOutputDelimitedGE_3_NB_LINE",nb_line_tFileOutputDelimitedGE_3);
				globalMap.put("tFileOutputDelimitedGE_3_FILE_NAME",fileName_tFileOutputDelimitedGE_3);
			
		
			}
		
		
		resourceMap.put("finish_tFileOutputDelimitedGE_3", true);
	
				log.info("tFileOutputDelimitedGE_3 - Written records count: " + nb_line_tFileOutputDelimitedGE_3 + " .");
				log.info("tFileOutputDelimitedGE_3 - Done.");

			if(execStat){
				if(resourceMap.get("inIterateVComp") == null || !((Boolean)resourceMap.get("inIterateVComp"))){
			 		runStat.updateStatOnConnection("copyOffs"+iterateId,2, 0); 
			 	}
			}
		
 

ok_Hash.put("tFileOutputDelimitedGE_3", true);
end_Hash.put("tFileOutputDelimitedGE_3", System.currentTimeMillis());

				if(execStat){   
   	 				runStat.updateStatOnConnection("OnComponentOk9", 0, "ok");
				}
				tGreenplumClose_3Process(globalMap);



/**
 * [tFileOutputDelimitedGE_3 end ] stop
 */






				}//end the resume

				
				    			if(resumeEntryMethodName == null || globalResumeTicket){
				    				resumeUtil.addLog("CHECKPOINT", "CONNECTION:SUBJOB_OK:tGreenplumInput_9:OnSubjobOk", "", Thread.currentThread().getId() + "", "", "", "", "", "");
								}	    				    			
					    	
								if(execStat){    	
									runStat.updateStatOnConnection("OnSubjobOk28", 0, "ok");
								} 
							
							tJava_5Process(globalMap); 
						



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage());
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tGreenplumInput_9 finally ] start
	 */

	

	
	
	currentComponent="tGreenplumInput_9";

	

 



/**
 * [tGreenplumInput_9 finally ] stop
 */

	
	/**
	 * [tMap_2 finally ] start
	 */

	

	
	
	currentComponent="tMap_2";

	

 



/**
 * [tMap_2 finally ] stop
 */

	
	/**
	 * [tFileOutputDelimitedGE_3 finally ] start
	 */

	

	
	
	currentComponent="tFileOutputDelimitedGE_3";

	


		if(resourceMap.get("finish_tFileOutputDelimitedGE_3") == null){ 
			
		   		synchronized (multiThreadLockWrite) {
			
				
						java.io.Writer outtFileOutputDelimitedGE_3 = (java.io.Writer)resourceMap.get("out_tFileOutputDelimitedGE_3");
						if(outtFileOutputDelimitedGE_3!=null) {
							outtFileOutputDelimitedGE_3.flush();
							outtFileOutputDelimitedGE_3.close();
						}
					
				
				}
			
			
		}
	

 



/**
 * [tFileOutputDelimitedGE_3 finally ] stop
 */






				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tGreenplumInput_9_SUBPROCESS_STATE", 1);
	}
	

public void tGreenplumClose_3Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tGreenplumClose_3_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;





	
	/**
	 * [tGreenplumClose_3 begin ] start
	 */

	

	
		
		ok_Hash.put("tGreenplumClose_3", false);
		start_Hash.put("tGreenplumClose_3", System.currentTimeMillis());
		
	
	currentComponent="tGreenplumClose_3";

	
		int tos_count_tGreenplumClose_3 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tGreenplumClose_3 - "  + ("Start to work.") );
    	class BytesLimit65535_tGreenplumClose_3{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tGreenplumClose_3 = new StringBuilder();
            log4jParamters_tGreenplumClose_3.append("Parameters:");
                    log4jParamters_tGreenplumClose_3.append("CONNECTION" + " = " + "tGreenplumConnection_4");
                log4jParamters_tGreenplumClose_3.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tGreenplumClose_3 - "  + (log4jParamters_tGreenplumClose_3) );
    		}
    	}
    	
        new BytesLimit65535_tGreenplumClose_3().limitLog4jByte();

 



/**
 * [tGreenplumClose_3 begin ] stop
 */
	
	/**
	 * [tGreenplumClose_3 main ] start
	 */

	

	
	
	currentComponent="tGreenplumClose_3";

	



	java.sql.Connection conn_tGreenplumClose_3 = (java.sql.Connection)globalMap.get("conn_tGreenplumConnection_4");
	if(conn_tGreenplumClose_3 != null && !conn_tGreenplumClose_3.isClosed())
	{
                if(log.isDebugEnabled())
            log.debug("tGreenplumClose_3 - "  + ("Closing the connection ")  + ("conn_tGreenplumConnection_4")  + (" to the database.") );
        conn_tGreenplumClose_3.close();
                if(log.isDebugEnabled())
            log.debug("tGreenplumClose_3 - "  + ("Connection ")  + ("conn_tGreenplumConnection_4")  + (" to the database has closed.") );
	}

 


	tos_count_tGreenplumClose_3++;

/**
 * [tGreenplumClose_3 main ] stop
 */
	
	/**
	 * [tGreenplumClose_3 end ] start
	 */

	

	
	
	currentComponent="tGreenplumClose_3";

	

 
                if(log.isDebugEnabled())
            log.debug("tGreenplumClose_3 - "  + ("Done.") );

ok_Hash.put("tGreenplumClose_3", true);
end_Hash.put("tGreenplumClose_3", System.currentTimeMillis());




/**
 * [tGreenplumClose_3 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage());
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tGreenplumClose_3 finally ] start
	 */

	

	
	
	currentComponent="tGreenplumClose_3";

	

 



/**
 * [tGreenplumClose_3 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tGreenplumClose_3_SUBPROCESS_STATE", 1);
	}
	

public void tJava_5Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tJava_5_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tJava_5 begin ] start
	 */

	

	
		
		ok_Hash.put("tJava_5", false);
		start_Hash.put("tJava_5", System.currentTimeMillis());
		
	
	currentComponent="tJava_5";

	
		int tos_count_tJava_5 = 0;
		
    	class BytesLimit65535_tJava_5{
    		public void limitLog4jByte() throws Exception{
    			
    		}
    	}
    	
        new BytesLimit65535_tJava_5().limitLog4jByte();


System.out.println("==============================");
System.out.println("(String)context.TABLE_NAME");
System.out.println(context.getProperty("TABLE_NAME").toUpperCase());
System.out.println("==============================");
System.out.println("(String)context.LOG_PLANT_NAME");
System.out.println(context.getProperty("LOG_PLANT_NAME").toUpperCase());
System.out.println("==============================");
System.out.println("(String)context.LOG_SYSTEM_NAME");
System.out.println(context.getProperty("LOG_SYSTEM_NAME").toUpperCase());
System.out.println("==============================");

context.LOG_RUN_ID=0;
//context.LOG_PLANT_NAME="NULL";
//context.LOG_SYSTEM_NAME="NULL";
context.LOG_TABLE_NAME=(String)((String)globalMap.get("orig_table_name") != null ? ((String)globalMap.get("orig_table_name")).toLowerCase() : "all");
//context.LOG_JOB_NAME="NULL";
//context.LOG_DATA_PATH="NULL";
//context.LOG_TECHNOLOGY="NULL";
context.LOG_STATUS="NULL";
context.LOG_NO_OF_INSERTS=0;
context.LOG_NO_OF_UPDATES=0;
context.LOG_NO_OF_DELETES=0;
context.LOG_NO_OF_ERRORS=0;
context.LOG_MESSAGE="NULL";
context.LOG_SOURCE_ROW_COUNT=0;
context.LOG_TARGET_ROW_COUNT=0;
context.LOG_ERROR_CATEGORY="NULL";

String strInsertLogTemplate = 
"SELECT sbdt.edl_log ("+
"  #RUN_ID, " +
"  #PLANT_NAME, " +
"  #SYSTEM_NAME, " +
"  #JOB_NAME, " +
"  #TABLE_NAME, " +
"  #STATUS, " +
"  #DATA_PATH, " +
"  #TECHNOLOGY, " +
"  #NO_OF_INSERTS, " +
"  #NO_OF_UPDATES, " +
"  #NO_OF_DELETES, " +
"  #NO_OF_ERRORS, " +
"  #MESSAGE, " +
"  #SOURCE_ROW_COUNT, " +
"  #TARGET_ROW_COUNT, " +
"  #ERROR_CATEGORY " +
") ";
globalMap.put("insert_log_template", strInsertLogTemplate);

String strIncrementRollingCallTemplate=
"SELECT sbdt.edl_increments_rolling ("+
"  #TARGET_SCHEMA, "+
"  #TARGET_TABLE_NAME "+
"); ";
globalMap.put("increment_rolling_call_template", strIncrementRollingCallTemplate);

String strSoftDeleteCallTemplate=
"SELECT sbdt.edl_softdelete ("+
"  #TARGET_SCHEMA, "+
"  #TARGET_TABLE_NAME "+
"); ";
globalMap.put("softdelete_call_template", strSoftDeleteCallTemplate);

String strDataProfilingCallTemplate=
"SELECT sbdt.edl_data_profiling ("+
"  #TARGET_SCHEMA, "+
"  #TARGET_TABLE_NAME "+
"); ";
globalMap.put("data_profiling_call_template", strDataProfilingCallTemplate);


//System.out.println("******************************");
//globalMap.put("now",new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(TalendDate.getCurrentDate()).toString());
//System.out.println(globalMap.get("now"));
//((String)globalMap.get("tJavaRow_4_ERROR_MESSAGE")) != null
//((Integer)context.LOG_RUN_ID).toString()
//globalMap.put("now_sql","TO_TIMESTAMP('" + ((String)globalMap.get("now")) + "', 'YYYY-MM-DD HH24:MI:SS')::TIMESTAMP WITH TIME ZONE ");
//System.out.println(globalMap.get("now_sql"));
//if (context.LOG_PLANT_NAME.equals("")==true) {
//  context.LOG_PLANT_NAME="Grove City";
//};
//System.out.println(globalMap.get("now"));
//((String)globalMap.get("now"))
//if (globalMap.get("now")=="X") {
//}
//if (context.getProperty("BF_SCHEMA").length() == 0) {
//	context.setProperty("TABLE_NAME", "pgpduke_energy");
//}

 



/**
 * [tJava_5 begin ] stop
 */
	
	/**
	 * [tJava_5 main ] start
	 */

	

	
	
	currentComponent="tJava_5";

	

 


	tos_count_tJava_5++;

/**
 * [tJava_5 main ] stop
 */
	
	/**
	 * [tJava_5 end ] start
	 */

	

	
	
	currentComponent="tJava_5";

	

 

ok_Hash.put("tJava_5", true);
end_Hash.put("tJava_5", System.currentTimeMillis());




/**
 * [tJava_5 end ] stop
 */
				}//end the resume

				
				    			if(resumeEntryMethodName == null || globalResumeTicket){
				    				resumeUtil.addLog("CHECKPOINT", "CONNECTION:SUBJOB_OK:tJava_5:OnSubjobOk", "", Thread.currentThread().getId() + "", "", "", "", "", "");
								}	    				    			
					    	
								if(execStat){    	
									runStat.updateStatOnConnection("OnSubjobOk15", 0, "ok");
								} 
							
							tGreenplumConnection_3Process(globalMap); 
						



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage());
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tJava_5 finally ] start
	 */

	

	
	
	currentComponent="tJava_5";

	

 



/**
 * [tJava_5 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tJava_5_SUBPROCESS_STATE", 1);
	}
	

public void tGreenplumConnection_3Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tGreenplumConnection_3_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tGreenplumConnection_3 begin ] start
	 */

	

	
		
		ok_Hash.put("tGreenplumConnection_3", false);
		start_Hash.put("tGreenplumConnection_3", System.currentTimeMillis());
		
	
	currentComponent="tGreenplumConnection_3";

	
		int tos_count_tGreenplumConnection_3 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tGreenplumConnection_3 - "  + ("Start to work.") );
    	class BytesLimit65535_tGreenplumConnection_3{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tGreenplumConnection_3 = new StringBuilder();
            log4jParamters_tGreenplumConnection_3.append("Parameters:");
                    log4jParamters_tGreenplumConnection_3.append("HOST" + " = " + "context.SOURCE_HOST");
                log4jParamters_tGreenplumConnection_3.append(" | ");
                    log4jParamters_tGreenplumConnection_3.append("PORT" + " = " + "context.SOURCE_PORT");
                log4jParamters_tGreenplumConnection_3.append(" | ");
                    log4jParamters_tGreenplumConnection_3.append("DBNAME" + " = " + "context.SOURCE_DATABASE");
                log4jParamters_tGreenplumConnection_3.append(" | ");
                    log4jParamters_tGreenplumConnection_3.append("SCHEMA_DB" + " = " + "\"\"");
                log4jParamters_tGreenplumConnection_3.append(" | ");
                    log4jParamters_tGreenplumConnection_3.append("USER" + " = " + "context.SOURCE_USER");
                log4jParamters_tGreenplumConnection_3.append(" | ");
                    log4jParamters_tGreenplumConnection_3.append("PASS" + " = " + String.valueOf(routines.system.PasswordEncryptUtil.encryptPassword(context.SOURCE_PASSWORD)).substring(0, 4) + "...");     
                log4jParamters_tGreenplumConnection_3.append(" | ");
                    log4jParamters_tGreenplumConnection_3.append("USE_SHARED_CONNECTION" + " = " + "true");
                log4jParamters_tGreenplumConnection_3.append(" | ");
                    log4jParamters_tGreenplumConnection_3.append("SHARED_CONNECTION_NAME" + " = " + "\"base_dynamic\"+((String)globalMap.get(\"timestamp\"))");
                log4jParamters_tGreenplumConnection_3.append(" | ");
                    log4jParamters_tGreenplumConnection_3.append("USE_SSL" + " = " + "true");
                log4jParamters_tGreenplumConnection_3.append(" | ");
                    log4jParamters_tGreenplumConnection_3.append("AUTO_COMMIT" + " = " + "true");
                log4jParamters_tGreenplumConnection_3.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tGreenplumConnection_3 - "  + (log4jParamters_tGreenplumConnection_3) );
    		}
    	}
    	
        new BytesLimit65535_tGreenplumConnection_3().limitLog4jByte();
	

	
				String url_tGreenplumConnection_3 = "jdbc:postgresql://"+context.SOURCE_HOST+":"+context.SOURCE_PORT+"/"+context.SOURCE_DATABASE+"?ssl=true&sslfactory=org.postgresql.ssl.NonValidatingFactory";

	String dbUser_tGreenplumConnection_3 = context.SOURCE_USER;
	
	
		
	final String decryptedPassword_tGreenplumConnection_3 = context.SOURCE_PASSWORD; 
		String dbPwd_tGreenplumConnection_3 = decryptedPassword_tGreenplumConnection_3;
	

	java.sql.Connection conn_tGreenplumConnection_3 = null;
	
	
			SharedDBConnectionLog4j.initLogger(log,"tGreenplumConnection_3");
			String sharedConnectionName_tGreenplumConnection_3 = "base_dynamic"+((String)globalMap.get("timestamp"));
			conn_tGreenplumConnection_3 = SharedDBConnectionLog4j.getDBConnection("org.postgresql.Driver",url_tGreenplumConnection_3,dbUser_tGreenplumConnection_3 , dbPwd_tGreenplumConnection_3 , sharedConnectionName_tGreenplumConnection_3);
	if (null != conn_tGreenplumConnection_3) {
		
			log.debug("tGreenplumConnection_3 - Connection is set auto commit to 'true'.");
			conn_tGreenplumConnection_3.setAutoCommit(true);
	}

	globalMap.put("schema_" + "tGreenplumConnection_3","");

	globalMap.put("conn_" + "tGreenplumConnection_3",conn_tGreenplumConnection_3);
 



/**
 * [tGreenplumConnection_3 begin ] stop
 */
	
	/**
	 * [tGreenplumConnection_3 main ] start
	 */

	

	
	
	currentComponent="tGreenplumConnection_3";

	

 


	tos_count_tGreenplumConnection_3++;

/**
 * [tGreenplumConnection_3 main ] stop
 */
	
	/**
	 * [tGreenplumConnection_3 end ] start
	 */

	

	
	
	currentComponent="tGreenplumConnection_3";

	

 
                if(log.isDebugEnabled())
            log.debug("tGreenplumConnection_3 - "  + ("Done.") );

ok_Hash.put("tGreenplumConnection_3", true);
end_Hash.put("tGreenplumConnection_3", System.currentTimeMillis());




/**
 * [tGreenplumConnection_3 end ] stop
 */
				}//end the resume

				
				    			if(resumeEntryMethodName == null || globalResumeTicket){
				    				resumeUtil.addLog("CHECKPOINT", "CONNECTION:SUBJOB_OK:tGreenplumConnection_3:OnSubjobOk", "", Thread.currentThread().getId() + "", "", "", "", "", "");
								}	    				    			
					    	
								if(execStat){    	
									runStat.updateStatOnConnection("OnSubjobOk16", 0, "ok");
								} 
							
							tGreenplumInput_5Process(globalMap); 
						



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage());
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tGreenplumConnection_3 finally ] start
	 */

	

	
	
	currentComponent="tGreenplumConnection_3";

	

 



/**
 * [tGreenplumConnection_3 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tGreenplumConnection_3_SUBPROCESS_STATE", 1);
	}
	


public static class row13Struct implements routines.system.IPersistableRow<row13Struct> {
    final static byte[] commonByteArrayLock_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Prod2Dev_with_GP_FDIST = new byte[0];
    static byte[] commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Prod2Dev_with_GP_FDIST = new byte[0];

	
			    public Integer run_id;

				public Integer getRun_id () {
					return this.run_id;
				}
				


	private Integer readInteger(ObjectInputStream dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}

	private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException{
		if(intNum == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeInt(intNum);
    	}
	}

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Prod2Dev_with_GP_FDIST) {

        	try {

        		int length = 0;
		
						this.run_id = readInteger(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// Integer
				
						writeInteger(this.run_id,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("run_id="+String.valueOf(run_id));
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				if(run_id == null){
        					sb.append("<null>");
        				}else{
            				sb.append(run_id);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(row13Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}
public void tGreenplumInput_5Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tGreenplumInput_5_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;



		row13Struct row13 = new row13Struct();




	
	/**
	 * [tJavaRow_3 begin ] start
	 */

	

	
		
		ok_Hash.put("tJavaRow_3", false);
		start_Hash.put("tJavaRow_3", System.currentTimeMillis());
		
	
	currentComponent="tJavaRow_3";

	
			if (execStat) {
				if(resourceMap.get("inIterateVComp") == null){
					
						runStat.updateStatOnConnection("row13" + iterateId, 0, 0);
					
				}
			} 

		
		int tos_count_tJavaRow_3 = 0;
		
    	class BytesLimit65535_tJavaRow_3{
    		public void limitLog4jByte() throws Exception{
    			
    		}
    	}
    	
        new BytesLimit65535_tJavaRow_3().limitLog4jByte();

int nb_line_tJavaRow_3 = 0;

 



/**
 * [tJavaRow_3 begin ] stop
 */



	
	/**
	 * [tGreenplumInput_5 begin ] start
	 */

	

	
		
		ok_Hash.put("tGreenplumInput_5", false);
		start_Hash.put("tGreenplumInput_5", System.currentTimeMillis());
		
	
	currentComponent="tGreenplumInput_5";

	
		int tos_count_tGreenplumInput_5 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tGreenplumInput_5 - "  + ("Start to work.") );
    	class BytesLimit65535_tGreenplumInput_5{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tGreenplumInput_5 = new StringBuilder();
            log4jParamters_tGreenplumInput_5.append("Parameters:");
                    log4jParamters_tGreenplumInput_5.append("USE_EXISTING_CONNECTION" + " = " + "true");
                log4jParamters_tGreenplumInput_5.append(" | ");
                    log4jParamters_tGreenplumInput_5.append("CONNECTION" + " = " + "tGreenplumConnection_3");
                log4jParamters_tGreenplumInput_5.append(" | ");
                    log4jParamters_tGreenplumInput_5.append("TABLE" + " = " + "\"\"");
                log4jParamters_tGreenplumInput_5.append(" | ");
                    log4jParamters_tGreenplumInput_5.append("QUERYSTORE" + " = " + "\"\"");
                log4jParamters_tGreenplumInput_5.append(" | ");
                    log4jParamters_tGreenplumInput_5.append("QUERY" + " = " + "\"select NEXTVAL('sbdt.edl_run_id_seq')\";  ");
                log4jParamters_tGreenplumInput_5.append(" | ");
                    log4jParamters_tGreenplumInput_5.append("USE_CURSOR" + " = " + "true");
                log4jParamters_tGreenplumInput_5.append(" | ");
                    log4jParamters_tGreenplumInput_5.append("CURSOR_SIZE" + " = " + "1000");
                log4jParamters_tGreenplumInput_5.append(" | ");
                    log4jParamters_tGreenplumInput_5.append("TRIM_ALL_COLUMN" + " = " + "false");
                log4jParamters_tGreenplumInput_5.append(" | ");
                    log4jParamters_tGreenplumInput_5.append("TRIM_COLUMN" + " = " + "[{TRIM="+("false")+", SCHEMA_COLUMN="+("run_id")+"}]");
                log4jParamters_tGreenplumInput_5.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tGreenplumInput_5 - "  + (log4jParamters_tGreenplumInput_5) );
    		}
    	}
    	
        new BytesLimit65535_tGreenplumInput_5().limitLog4jByte();
	
    
	
		    int nb_line_tGreenplumInput_5 = 0;
		    java.sql.Connection conn_tGreenplumInput_5 = null;
		        conn_tGreenplumInput_5 = (java.sql.Connection)globalMap.get("conn_tGreenplumConnection_3");
				
				if(conn_tGreenplumInput_5 != null) {
					if(conn_tGreenplumInput_5.getMetaData() != null) {
						
						log.debug("tGreenplumInput_5 - Uses an existing connection with username '" + conn_tGreenplumInput_5.getMetaData().getUserName() + "'. Connection URL: " + conn_tGreenplumInput_5.getMetaData().getURL() + ".");
						
					}
				}
			
		    
			java.sql.Statement stmt_tGreenplumInput_5 = conn_tGreenplumInput_5.createStatement();
                stmt_tGreenplumInput_5.setFetchSize(1000);

		    String dbquery_tGreenplumInput_5 = "select NEXTVAL('sbdt.edl_run_id_seq')";
;
			
                log.debug("tGreenplumInput_5 - Executing the query: '"+dbquery_tGreenplumInput_5+"'.");
			

                       globalMap.put("tGreenplumInput_5_QUERY",dbquery_tGreenplumInput_5);

		    java.sql.ResultSet rs_tGreenplumInput_5 = null;
		try{
		    rs_tGreenplumInput_5 = stmt_tGreenplumInput_5.executeQuery(dbquery_tGreenplumInput_5);
		    java.sql.ResultSetMetaData rsmd_tGreenplumInput_5 = rs_tGreenplumInput_5.getMetaData();
		    int colQtyInRs_tGreenplumInput_5 = rsmd_tGreenplumInput_5.getColumnCount();

		    String tmpContent_tGreenplumInput_5 = null;
		    
		    
		    	log.debug("tGreenplumInput_5 - Retrieving records from the database.");
		    
		    while (rs_tGreenplumInput_5.next()) {
		        nb_line_tGreenplumInput_5++;
		        
							if(colQtyInRs_tGreenplumInput_5 < 1) {
								row13.run_id = null;
							} else {
		                          
            if(rs_tGreenplumInput_5.getObject(1) != null) {
                row13.run_id = rs_tGreenplumInput_5.getInt(1);
            } else {
                    row13.run_id = null;
            }
		                    }
					
						log.debug("tGreenplumInput_5 - Retrieving the record " + nb_line_tGreenplumInput_5 + ".");
					


 



/**
 * [tGreenplumInput_5 begin ] stop
 */
	
	/**
	 * [tGreenplumInput_5 main ] start
	 */

	

	
	
	currentComponent="tGreenplumInput_5";

	

 


	tos_count_tGreenplumInput_5++;

/**
 * [tGreenplumInput_5 main ] stop
 */

	
	/**
	 * [tJavaRow_3 main ] start
	 */

	

	
	
	currentComponent="tJavaRow_3";

	

			//row13
			//row13


			
				if(execStat){
					runStat.updateStatOnConnection("row13"+iterateId,1, 1);
				} 
			

		
    			if(log.isTraceEnabled()){
    				log.trace("row13 - " + (row13==null? "": row13.toLogString()));
    			}
    		

    context.LOG_RUN_ID=row13.run_id;
globalMap.put("BASE_RUN_ID", row13.run_id);
    nb_line_tJavaRow_3++;   

 


	tos_count_tJavaRow_3++;

/**
 * [tJavaRow_3 main ] stop
 */



	
	/**
	 * [tGreenplumInput_5 end ] start
	 */

	

	
	
	currentComponent="tGreenplumInput_5";

	

	}
}finally{
	stmt_tGreenplumInput_5.close();

}
globalMap.put("tGreenplumInput_5_NB_LINE",nb_line_tGreenplumInput_5);
	    		log.debug("tGreenplumInput_5 - Retrieved records count: "+nb_line_tGreenplumInput_5 + " .");
			

 
                if(log.isDebugEnabled())
            log.debug("tGreenplumInput_5 - "  + ("Done.") );

ok_Hash.put("tGreenplumInput_5", true);
end_Hash.put("tGreenplumInput_5", System.currentTimeMillis());




/**
 * [tGreenplumInput_5 end ] stop
 */

	
	/**
	 * [tJavaRow_3 end ] start
	 */

	

	
	
	currentComponent="tJavaRow_3";

	

globalMap.put("tJavaRow_3_NB_LINE",nb_line_tJavaRow_3);
			if(execStat){
				if(resourceMap.get("inIterateVComp") == null || !((Boolean)resourceMap.get("inIterateVComp"))){
			 		runStat.updateStatOnConnection("row13"+iterateId,2, 0); 
			 	}
			}
		
 

ok_Hash.put("tJavaRow_3", true);
end_Hash.put("tJavaRow_3", System.currentTimeMillis());

   			if (true) {
   				
					if(execStat){   
   	 					runStat.updateStatOnConnection("If3", 0, "true");
					}
				
    			tJava_7Process(globalMap);
   			}

			   
   				else{
					if(execStat){   
   	 					runStat.updateStatOnConnection("If3", 0, "false");
					}   	 
   				}



/**
 * [tJavaRow_3 end ] stop
 */



				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage());
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tGreenplumInput_5 finally ] start
	 */

	

	
	
	currentComponent="tGreenplumInput_5";

	

 



/**
 * [tGreenplumInput_5 finally ] stop
 */

	
	/**
	 * [tJavaRow_3 finally ] start
	 */

	

	
	
	currentComponent="tJavaRow_3";

	

 



/**
 * [tJavaRow_3 finally ] stop
 */



				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tGreenplumInput_5_SUBPROCESS_STATE", 1);
	}
	

public void tJava_7Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tJava_7_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tJava_7 begin ] start
	 */

	

	
		
		ok_Hash.put("tJava_7", false);
		start_Hash.put("tJava_7", System.currentTimeMillis());
		
	
	currentComponent="tJava_7";

	
		int tos_count_tJava_7 = 0;
		
    	class BytesLimit65535_tJava_7{
    		public void limitLog4jByte() throws Exception{
    			
    		}
    	}
    	
        new BytesLimit65535_tJava_7().limitLog4jByte();


System.out.println("select row_id where run_id = "+((Integer)globalMap.get("BASE_RUN_ID")));
//context.LOG_PLANT_NAME="NULL";
//context.LOG_SYSTEM_NAME="NULL";
//context.LOG_TABLE_NAME="NULL";
//context.LOG_JOB_NAME="NULL";
//context.LOG_DATA_PATH="NULL";
//context.LOG_TECHNOLOGY="NULL";
context.LOG_STATUS="Start";
context.LOG_MESSAGE="NULL";
context.LOG_ERROR_CATEGORY="NULL";
context.LOG_NO_OF_INSERTS=0;
context.LOG_NO_OF_UPDATES=0;
context.LOG_NO_OF_DELETES=0;
context.LOG_NO_OF_ERRORS=0;
context.LOG_SOURCE_ROW_COUNT=0;
context.LOG_TARGET_ROW_COUNT=0;


String strInsertLogSql=(String)globalMap.get("insert_log_template");
strInsertLogSql=strInsertLogSql.replace("#RUN_ID", ((Integer)context.LOG_RUN_ID).toString());
strInsertLogSql=strInsertLogSql.replace("#PLANT_NAME", "'"+context.LOG_PLANT_NAME+"'");
strInsertLogSql=strInsertLogSql.replace("#SYSTEM_NAME", "'"+context.LOG_SYSTEM_NAME+"'");
strInsertLogSql=strInsertLogSql.replace("#JOB_NAME", "'"+((String)globalMap.get("jobname_prefix"))+context.LOG_JOB_NAME+"'");
strInsertLogSql=strInsertLogSql.replace("#TABLE_NAME", "'"+context.LOG_TABLE_NAME+"'");
strInsertLogSql=strInsertLogSql.replace("#STATUS", "'"+context.LOG_STATUS+"'");
strInsertLogSql=strInsertLogSql.replace("#DATA_PATH", "'"+context.LOG_DATA_PATH+"'");
strInsertLogSql=strInsertLogSql.replace("#TECHNOLOGY", "'"+context.LOG_TECHNOLOGY+"'");
strInsertLogSql=strInsertLogSql.replace("#NO_OF_INSERTS", ((Integer)context.LOG_NO_OF_INSERTS).toString());
strInsertLogSql=strInsertLogSql.replace("#NO_OF_UPDATES", ((Integer)context.LOG_NO_OF_UPDATES).toString());
strInsertLogSql=strInsertLogSql.replace("#NO_OF_DELETES", ((Integer)context.LOG_NO_OF_DELETES).toString());
strInsertLogSql=strInsertLogSql.replace("#NO_OF_ERRORS", ((Integer)context.LOG_NO_OF_ERRORS).toString());
strInsertLogSql=strInsertLogSql.replace("#MESSAGE", "'"+context.LOG_MESSAGE+"'");
strInsertLogSql=strInsertLogSql.replace("#SOURCE_ROW_COUNT", ((Integer)context.LOG_SOURCE_ROW_COUNT).toString());
strInsertLogSql=strInsertLogSql.replace("#TARGET_ROW_COUNT", ((Integer)context.LOG_TARGET_ROW_COUNT).toString());
strInsertLogSql=strInsertLogSql.replace("#ERROR_CATEGORY", "'"+context.LOG_ERROR_CATEGORY+"'");
globalMap.put("insert_log_sql",strInsertLogSql);
//System.out.println(globalMap.get("insert_log_sql"));
//System.out.println("==============================");
//System.out.println("==============================");
//globalMap.put("now",new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(TalendDate.getCurrentDate()).toString());
//System.out.println(globalMap.get("now"));
//globalMap.put("now_sql","TO_TIMESTAMP('" + ((String)globalMap.get("now")) + "', 'YYYY-MM-DD HH24:MI:SS')::TIMESTAMP WITH TIME ZONE ");
//System.out.println(globalMap.get("now_sql"));
//if (context.LOG_PLANT_NAME.equals("")==true) {
//  context.LOG_PLANT_NAME="Grove City";
//};
//if (context.LOG_APPLICATION.equals("")==true) {
//  context.LOG_APPLICATION="GET-ABM";
//};
 



/**
 * [tJava_7 begin ] stop
 */
	
	/**
	 * [tJava_7 main ] start
	 */

	

	
	
	currentComponent="tJava_7";

	

 


	tos_count_tJava_7++;

/**
 * [tJava_7 main ] stop
 */
	
	/**
	 * [tJava_7 end ] start
	 */

	

	
	
	currentComponent="tJava_7";

	

 

ok_Hash.put("tJava_7", true);
end_Hash.put("tJava_7", System.currentTimeMillis());




/**
 * [tJava_7 end ] stop
 */
				}//end the resume

				
				    			if(resumeEntryMethodName == null || globalResumeTicket){
				    				resumeUtil.addLog("CHECKPOINT", "CONNECTION:SUBJOB_OK:tJava_7:OnSubjobOk", "", Thread.currentThread().getId() + "", "", "", "", "", "");
								}	    				    			
					    	
								if(execStat){    	
									runStat.updateStatOnConnection("OnSubjobOk20", 0, "ok");
								} 
							
							tGreenplumRow_1Process(globalMap); 
						



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage());
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tJava_7 finally ] start
	 */

	

	
	
	currentComponent="tJava_7";

	

 



/**
 * [tJava_7 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tJava_7_SUBPROCESS_STATE", 1);
	}
	

public void tGreenplumRow_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tGreenplumRow_1_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tGreenplumRow_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tGreenplumRow_1", false);
		start_Hash.put("tGreenplumRow_1", System.currentTimeMillis());
		
	
	currentComponent="tGreenplumRow_1";

	
		int tos_count_tGreenplumRow_1 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tGreenplumRow_1 - "  + ("Start to work.") );
    	class BytesLimit65535_tGreenplumRow_1{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tGreenplumRow_1 = new StringBuilder();
            log4jParamters_tGreenplumRow_1.append("Parameters:");
                    log4jParamters_tGreenplumRow_1.append("USE_EXISTING_CONNECTION" + " = " + "true");
                log4jParamters_tGreenplumRow_1.append(" | ");
                    log4jParamters_tGreenplumRow_1.append("CONNECTION" + " = " + "tGreenplumConnection_3");
                log4jParamters_tGreenplumRow_1.append(" | ");
                    log4jParamters_tGreenplumRow_1.append("QUERYSTORE" + " = " + "\"\"");
                log4jParamters_tGreenplumRow_1.append(" | ");
                    log4jParamters_tGreenplumRow_1.append("QUERY" + " = " + "(String)globalMap.get(\"insert_log_sql\")");
                log4jParamters_tGreenplumRow_1.append(" | ");
                    log4jParamters_tGreenplumRow_1.append("DIE_ON_ERROR" + " = " + "true");
                log4jParamters_tGreenplumRow_1.append(" | ");
                    log4jParamters_tGreenplumRow_1.append("PROPAGATE_RECORD_SET" + " = " + "false");
                log4jParamters_tGreenplumRow_1.append(" | ");
                    log4jParamters_tGreenplumRow_1.append("USE_PREPAREDSTATEMENT" + " = " + "false");
                log4jParamters_tGreenplumRow_1.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tGreenplumRow_1 - "  + (log4jParamters_tGreenplumRow_1) );
    		}
    	}
    	
        new BytesLimit65535_tGreenplumRow_1().limitLog4jByte();

	java.sql.Connection conn_tGreenplumRow_1 = null;
	String query_tGreenplumRow_1 = "";
	boolean whetherReject_tGreenplumRow_1 = false;
				conn_tGreenplumRow_1 = (java.sql.Connection)globalMap.get("conn_tGreenplumConnection_3");
			
				if(conn_tGreenplumRow_1 != null) {
					if(conn_tGreenplumRow_1.getMetaData() != null) {
						
						log.debug("tGreenplumRow_1 - Uses an existing connection with username '" + conn_tGreenplumRow_1.getMetaData().getUserName() + "'. Connection URL: " + conn_tGreenplumRow_1.getMetaData().getURL() + ".");
						
					}
				}
			
		java.sql.Statement stmt_tGreenplumRow_1 = conn_tGreenplumRow_1.createStatement();
	

 



/**
 * [tGreenplumRow_1 begin ] stop
 */
	
	/**
	 * [tGreenplumRow_1 main ] start
	 */

	

	
	
	currentComponent="tGreenplumRow_1";

	

	    		log.debug("tGreenplumRow_1 - Executing the query: '" + (String)globalMap.get("insert_log_sql") + "'.");
			
query_tGreenplumRow_1 = (String)globalMap.get("insert_log_sql");
whetherReject_tGreenplumRow_1 = false;
globalMap.put("tGreenplumRow_1_QUERY",query_tGreenplumRow_1);
try {
		stmt_tGreenplumRow_1.execute(query_tGreenplumRow_1);
		
	    		log.info("tGreenplumRow_1 - Execute the query: '" + (String)globalMap.get("insert_log_sql") + "' has finished.");
			
	} catch (java.lang.Exception e) {
		whetherReject_tGreenplumRow_1 = true;
		
			throw(e);
			
	}
	
	if(!whetherReject_tGreenplumRow_1) {
		
	}
	

 


	tos_count_tGreenplumRow_1++;

/**
 * [tGreenplumRow_1 main ] stop
 */
	
	/**
	 * [tGreenplumRow_1 end ] start
	 */

	

	
	
	currentComponent="tGreenplumRow_1";

	

	
	stmt_tGreenplumRow_1.close();	

 
                if(log.isDebugEnabled())
            log.debug("tGreenplumRow_1 - "  + ("Done.") );

ok_Hash.put("tGreenplumRow_1", true);
end_Hash.put("tGreenplumRow_1", System.currentTimeMillis());




/**
 * [tGreenplumRow_1 end ] stop
 */
				}//end the resume

				
				    			if(resumeEntryMethodName == null || globalResumeTicket){
				    				resumeUtil.addLog("CHECKPOINT", "CONNECTION:SUBJOB_OK:tGreenplumRow_1:OnSubjobOk", "", Thread.currentThread().getId() + "", "", "", "", "", "");
								}	    				    			
					    	
								if(execStat){    	
									runStat.updateStatOnConnection("OnSubjobOk21", 0, "ok");
								} 
							
							tGreenplumClose_1Process(globalMap); 
						



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage());
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tGreenplumRow_1 finally ] start
	 */

	

	
	
	currentComponent="tGreenplumRow_1";

	

 



/**
 * [tGreenplumRow_1 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tGreenplumRow_1_SUBPROCESS_STATE", 1);
	}
	

public void tGreenplumClose_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tGreenplumClose_1_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tGreenplumClose_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tGreenplumClose_1", false);
		start_Hash.put("tGreenplumClose_1", System.currentTimeMillis());
		
	
	currentComponent="tGreenplumClose_1";

	
		int tos_count_tGreenplumClose_1 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tGreenplumClose_1 - "  + ("Start to work.") );
    	class BytesLimit65535_tGreenplumClose_1{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tGreenplumClose_1 = new StringBuilder();
            log4jParamters_tGreenplumClose_1.append("Parameters:");
                    log4jParamters_tGreenplumClose_1.append("CONNECTION" + " = " + "tGreenplumConnection_3");
                log4jParamters_tGreenplumClose_1.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tGreenplumClose_1 - "  + (log4jParamters_tGreenplumClose_1) );
    		}
    	}
    	
        new BytesLimit65535_tGreenplumClose_1().limitLog4jByte();

 



/**
 * [tGreenplumClose_1 begin ] stop
 */
	
	/**
	 * [tGreenplumClose_1 main ] start
	 */

	

	
	
	currentComponent="tGreenplumClose_1";

	



	java.sql.Connection conn_tGreenplumClose_1 = (java.sql.Connection)globalMap.get("conn_tGreenplumConnection_3");
	if(conn_tGreenplumClose_1 != null && !conn_tGreenplumClose_1.isClosed())
	{
                if(log.isDebugEnabled())
            log.debug("tGreenplumClose_1 - "  + ("Closing the connection ")  + ("conn_tGreenplumConnection_3")  + (" to the database.") );
        conn_tGreenplumClose_1.close();
                if(log.isDebugEnabled())
            log.debug("tGreenplumClose_1 - "  + ("Connection ")  + ("conn_tGreenplumConnection_3")  + (" to the database has closed.") );
	}

 


	tos_count_tGreenplumClose_1++;

/**
 * [tGreenplumClose_1 main ] stop
 */
	
	/**
	 * [tGreenplumClose_1 end ] start
	 */

	

	
	
	currentComponent="tGreenplumClose_1";

	

 
                if(log.isDebugEnabled())
            log.debug("tGreenplumClose_1 - "  + ("Done.") );

ok_Hash.put("tGreenplumClose_1", true);
end_Hash.put("tGreenplumClose_1", System.currentTimeMillis());




/**
 * [tGreenplumClose_1 end ] stop
 */
				}//end the resume

				
				    			if(resumeEntryMethodName == null || globalResumeTicket){
				    				resumeUtil.addLog("CHECKPOINT", "CONNECTION:SUBJOB_OK:tGreenplumClose_1:OnSubjobOk", "", Thread.currentThread().getId() + "", "", "", "", "", "");
								}	    				    			
					    	
								if(execStat){    	
									runStat.updateStatOnConnection("OnSubjobOk22", 0, "ok");
								} 
							
							tFileInputDelimited_1Process(globalMap); 
						



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage());
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tGreenplumClose_1 finally ] start
	 */

	

	
	
	currentComponent="tGreenplumClose_1";

	

 



/**
 * [tGreenplumClose_1 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tGreenplumClose_1_SUBPROCESS_STATE", 1);
	}
	


public static class row15Struct implements routines.system.IPersistableRow<row15Struct> {
    final static byte[] commonByteArrayLock_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Prod2Dev_with_GP_FDIST = new byte[0];
    static byte[] commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Prod2Dev_with_GP_FDIST = new byte[0];

	



    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Prod2Dev_with_GP_FDIST) {

        	try {

        		int length = 0;
		

		

        }

		
			finally {}
		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
        }

			finally {}
		

    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(row15Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public static class row14Struct implements routines.system.IPersistableRow<row14Struct> {
    final static byte[] commonByteArrayLock_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Prod2Dev_with_GP_FDIST = new byte[0];
    static byte[] commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Prod2Dev_with_GP_FDIST = new byte[0];

	
			    public String log_table_name;

				public String getLog_table_name () {
					return this.log_table_name;
				}
				
			    public String technology;

				public String getTechnology () {
					return this.technology;
				}
				



	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Prod2Dev_with_GP_FDIST.length) {
				if(length < 1024 && commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Prod2Dev_with_GP_FDIST.length == 0) {
   					commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Prod2Dev_with_GP_FDIST = new byte[1024];
				} else {
   					commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Prod2Dev_with_GP_FDIST = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Prod2Dev_with_GP_FDIST, 0, length);
			strReturn = new String(commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Prod2Dev_with_GP_FDIST, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Prod2Dev_with_GP_FDIST) {

        	try {

        		int length = 0;
		
					this.log_table_name = readString(dis);
					
					this.technology = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// String
				
						writeString(this.log_table_name,dos);
					
					// String
				
						writeString(this.technology,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("log_table_name="+log_table_name);
		sb.append(",technology="+technology);
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				if(log_table_name == null){
        					sb.append("<null>");
        				}else{
            				sb.append(log_table_name);
            			}
            		
        			sb.append("|");
        		
        				if(technology == null){
        					sb.append("<null>");
        				}else{
            				sb.append(technology);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(row14Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}
public void tFileInputDelimited_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tFileInputDelimited_1_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;



		row14Struct row14 = new row14Struct();
row15Struct row15 = new row15Struct();





	
	/**
	 * [tFlowToIterate_2 begin ] start
	 */

				
			int NB_ITERATE_tRunJob_2 = 0; //for statistics
			

	
		
		ok_Hash.put("tFlowToIterate_2", false);
		start_Hash.put("tFlowToIterate_2", System.currentTimeMillis());
		
	
	currentComponent="tFlowToIterate_2";

	
			if (execStat) {
				if(resourceMap.get("inIterateVComp") == null){
					
						runStat.updateStatOnConnection("row15" + iterateId, 0, 0);
					
				}
			} 

		
		int tos_count_tFlowToIterate_2 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tFlowToIterate_2 - "  + ("Start to work.") );
    	class BytesLimit65535_tFlowToIterate_2{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tFlowToIterate_2 = new StringBuilder();
            log4jParamters_tFlowToIterate_2.append("Parameters:");
                    log4jParamters_tFlowToIterate_2.append("DEFAULT_MAP" + " = " + "true");
                log4jParamters_tFlowToIterate_2.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tFlowToIterate_2 - "  + (log4jParamters_tFlowToIterate_2) );
    		}
    	}
    	
        new BytesLimit65535_tFlowToIterate_2().limitLog4jByte();

int nb_line_tFlowToIterate_2 = 0;
int counter_tFlowToIterate_2 = 0;

 



/**
 * [tFlowToIterate_2 begin ] stop
 */



	
	/**
	 * [tJavaRow_6 begin ] start
	 */

	

	
		
		ok_Hash.put("tJavaRow_6", false);
		start_Hash.put("tJavaRow_6", System.currentTimeMillis());
		
	
	currentComponent="tJavaRow_6";

	
			if (execStat) {
				if(resourceMap.get("inIterateVComp") == null){
					
						runStat.updateStatOnConnection("row14" + iterateId, 0, 0);
					
				}
			} 

		
		int tos_count_tJavaRow_6 = 0;
		
    	class BytesLimit65535_tJavaRow_6{
    		public void limitLog4jByte() throws Exception{
    			
    		}
    	}
    	
        new BytesLimit65535_tJavaRow_6().limitLog4jByte();

int nb_line_tJavaRow_6 = 0;

 



/**
 * [tJavaRow_6 begin ] stop
 */



	
	/**
	 * [tFileInputDelimited_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tFileInputDelimited_1", false);
		start_Hash.put("tFileInputDelimited_1", System.currentTimeMillis());
		
	
	currentComponent="tFileInputDelimited_1";

	
		int tos_count_tFileInputDelimited_1 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tFileInputDelimited_1 - "  + ("Start to work.") );
    	class BytesLimit65535_tFileInputDelimited_1{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tFileInputDelimited_1 = new StringBuilder();
            log4jParamters_tFileInputDelimited_1.append("Parameters:");
                    log4jParamters_tFileInputDelimited_1.append("FILENAME" + " = " + "context.ETL_STORAGE_PATH + \"/\" +context.GP_SOURCE_NAME + \"/\" +((String)globalMap.get(\"timestamp\"))+\".csv\"");
                log4jParamters_tFileInputDelimited_1.append(" | ");
                    log4jParamters_tFileInputDelimited_1.append("CSV_OPTION" + " = " + "false");
                log4jParamters_tFileInputDelimited_1.append(" | ");
                    log4jParamters_tFileInputDelimited_1.append("ROWSEPARATOR" + " = " + "\"\\n\"");
                log4jParamters_tFileInputDelimited_1.append(" | ");
                    log4jParamters_tFileInputDelimited_1.append("FIELDSEPARATOR" + " = " + "\";\"");
                log4jParamters_tFileInputDelimited_1.append(" | ");
                    log4jParamters_tFileInputDelimited_1.append("HEADER" + " = " + "0");
                log4jParamters_tFileInputDelimited_1.append(" | ");
                    log4jParamters_tFileInputDelimited_1.append("FOOTER" + " = " + "0");
                log4jParamters_tFileInputDelimited_1.append(" | ");
                    log4jParamters_tFileInputDelimited_1.append("LIMIT" + " = " + "");
                log4jParamters_tFileInputDelimited_1.append(" | ");
                    log4jParamters_tFileInputDelimited_1.append("REMOVE_EMPTY_ROW" + " = " + "true");
                log4jParamters_tFileInputDelimited_1.append(" | ");
                    log4jParamters_tFileInputDelimited_1.append("UNCOMPRESS" + " = " + "false");
                log4jParamters_tFileInputDelimited_1.append(" | ");
                    log4jParamters_tFileInputDelimited_1.append("DIE_ON_ERROR" + " = " + "false");
                log4jParamters_tFileInputDelimited_1.append(" | ");
                    log4jParamters_tFileInputDelimited_1.append("ADVANCED_SEPARATOR" + " = " + "false");
                log4jParamters_tFileInputDelimited_1.append(" | ");
                    log4jParamters_tFileInputDelimited_1.append("RANDOM" + " = " + "false");
                log4jParamters_tFileInputDelimited_1.append(" | ");
                    log4jParamters_tFileInputDelimited_1.append("TRIMALL" + " = " + "false");
                log4jParamters_tFileInputDelimited_1.append(" | ");
                    log4jParamters_tFileInputDelimited_1.append("TRIMSELECT" + " = " + "[{TRIM="+("false")+", SCHEMA_COLUMN="+("log_table_name")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("technology")+"}]");
                log4jParamters_tFileInputDelimited_1.append(" | ");
                    log4jParamters_tFileInputDelimited_1.append("CHECK_FIELDS_NUM" + " = " + "false");
                log4jParamters_tFileInputDelimited_1.append(" | ");
                    log4jParamters_tFileInputDelimited_1.append("CHECK_DATE" + " = " + "false");
                log4jParamters_tFileInputDelimited_1.append(" | ");
                    log4jParamters_tFileInputDelimited_1.append("ENCODING" + " = " + "\"ISO-8859-15\"");
                log4jParamters_tFileInputDelimited_1.append(" | ");
                    log4jParamters_tFileInputDelimited_1.append("SPLITRECORD" + " = " + "false");
                log4jParamters_tFileInputDelimited_1.append(" | ");
                    log4jParamters_tFileInputDelimited_1.append("ENABLE_DECODE" + " = " + "false");
                log4jParamters_tFileInputDelimited_1.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tFileInputDelimited_1 - "  + (log4jParamters_tFileInputDelimited_1) );
    		}
    	}
    	
        new BytesLimit65535_tFileInputDelimited_1().limitLog4jByte();
	
	
	
 
	
	
	final routines.system.RowState rowstate_tFileInputDelimited_1 = new routines.system.RowState();
	
	
				int nb_line_tFileInputDelimited_1 = 0;
				org.talend.fileprocess.FileInputDelimited fid_tFileInputDelimited_1 = null;
				try{
					
						Object filename_tFileInputDelimited_1 = context.ETL_STORAGE_PATH + "/" +context.GP_SOURCE_NAME + "/" +((String)globalMap.get("timestamp"))+".csv";
						if(filename_tFileInputDelimited_1 instanceof java.io.InputStream){
							
			int footer_value_tFileInputDelimited_1 = 0, random_value_tFileInputDelimited_1 = -1;
			if(footer_value_tFileInputDelimited_1 >0 || random_value_tFileInputDelimited_1 > 0){
				throw new java.lang.Exception("When the input source is a stream,footer and random shouldn't be bigger than 0.");				
			}
		
						}
						try {
							fid_tFileInputDelimited_1 = new org.talend.fileprocess.FileInputDelimited(context.ETL_STORAGE_PATH + "/" +context.GP_SOURCE_NAME + "/" +((String)globalMap.get("timestamp"))+".csv", "ISO-8859-15",";","\n",true,0,0,-1,-1, false);
						} catch(java.lang.Exception e) {
							
								
									log.error("tFileInputDelimited_1 - " +e.getMessage());
								
								System.err.println(e.getMessage());
							
						}
					
				    
				    	log.info("tFileInputDelimited_1 - Retrieving records from the datasource.");
				    
					while (fid_tFileInputDelimited_1!=null && fid_tFileInputDelimited_1.nextRecord()) {
						rowstate_tFileInputDelimited_1.reset();
						
			    						row14 = null;			
												
									boolean whetherReject_tFileInputDelimited_1 = false;
									row14 = new row14Struct();
									try {
										
				int columnIndexWithD_tFileInputDelimited_1 = 0;
				
					columnIndexWithD_tFileInputDelimited_1 = 0;
					
							row14.log_table_name = fid_tFileInputDelimited_1.get(columnIndexWithD_tFileInputDelimited_1);
						
				
					columnIndexWithD_tFileInputDelimited_1 = 1;
					
							row14.technology = fid_tFileInputDelimited_1.get(columnIndexWithD_tFileInputDelimited_1);
						
				
				
										
										if(rowstate_tFileInputDelimited_1.getException()!=null) {
											throw rowstate_tFileInputDelimited_1.getException();
										}
										
										
							
			    					} catch (java.lang.Exception e) {
			        					whetherReject_tFileInputDelimited_1 = true;
			        					
												log.error("tFileInputDelimited_1 - " +e.getMessage());
											
			                					System.err.println(e.getMessage());
			                					row14 = null;
			                				
			    					}
								
			log.debug("tFileInputDelimited_1 - Retrieving the record " + fid_tFileInputDelimited_1.getRowNumber() + ".");
		

 



/**
 * [tFileInputDelimited_1 begin ] stop
 */
	
	/**
	 * [tFileInputDelimited_1 main ] start
	 */

	

	
	
	currentComponent="tFileInputDelimited_1";

	

 


	tos_count_tFileInputDelimited_1++;

/**
 * [tFileInputDelimited_1 main ] stop
 */
// Start of branch "row14"
if(row14 != null) { 



	
	/**
	 * [tJavaRow_6 main ] start
	 */

	

	
	
	currentComponent="tJavaRow_6";

	

			//row14
			//row14


			
				if(execStat){
					runStat.updateStatOnConnection("row14"+iterateId,1, 1);
				} 
			

		
    			if(log.isTraceEnabled()){
    				log.trace("row14 - " + (row14==null? "": row14.toLogString()));
    			}
    		

    context.TABLE_NAME=row14.log_table_name;
context.LOG_TECHNOLOGY=row14.technology;

//System.out.println(row14.log_table_name);
//System.out.println(row14.technology);

    nb_line_tJavaRow_6++;   

 


	tos_count_tJavaRow_6++;

/**
 * [tJavaRow_6 main ] stop
 */

	
	/**
	 * [tFlowToIterate_2 main ] start
	 */

	

	
	
	currentComponent="tFlowToIterate_2";

	

			//row15
			//row15


			
				if(execStat){
					runStat.updateStatOnConnection("row15"+iterateId,1, 1);
				} 
			

		
    			if(log.isTraceEnabled()){
    				log.trace("row15 - " + (row15==null? "": row15.toLogString()));
    			}
    		


    	
 
	   nb_line_tFlowToIterate_2++;  
       counter_tFlowToIterate_2++;
                if(log.isDebugEnabled())
            log.debug("tFlowToIterate_2 - "  + ("Current iteration is: ")  + (counter_tFlowToIterate_2)  + (".") );
       globalMap.put("tFlowToIterate_2_CURRENT_ITERATION", counter_tFlowToIterate_2);
 


	tos_count_tFlowToIterate_2++;

/**
 * [tFlowToIterate_2 main ] stop
 */
	NB_ITERATE_tRunJob_2++;
	
	
				if(execStat){
					runStat.updateStatOnConnection("iterate2", 1, "exec" + NB_ITERATE_tRunJob_2);
					//Thread.sleep(1000);
				}				
			

	
	/**
	 * [tRunJob_2 begin ] start
	 */

	

	
		
		ok_Hash.put("tRunJob_2", false);
		start_Hash.put("tRunJob_2", System.currentTimeMillis());
		
	
	currentComponent="tRunJob_2";

	
		int tos_count_tRunJob_2 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tRunJob_2 - "  + ("Start to work.") );
    	class BytesLimit65535_tRunJob_2{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tRunJob_2 = new StringBuilder();
            log4jParamters_tRunJob_2.append("Parameters:");
                    log4jParamters_tRunJob_2.append("USE_DYNAMIC_JOB" + " = " + "false");
                log4jParamters_tRunJob_2.append(" | ");
                    log4jParamters_tRunJob_2.append("PROCESS" + " = " + "EDL_Prod2Dev_with_GP_FDIST_child");
                log4jParamters_tRunJob_2.append(" | ");
                    log4jParamters_tRunJob_2.append("USE_INDEPENDENT_PROCESS" + " = " + "false");
                log4jParamters_tRunJob_2.append(" | ");
                    log4jParamters_tRunJob_2.append("DIE_ON_CHILD_ERROR" + " = " + "false");
                log4jParamters_tRunJob_2.append(" | ");
                    log4jParamters_tRunJob_2.append("TRANSMIT_WHOLE_CONTEXT" + " = " + "true");
                log4jParamters_tRunJob_2.append(" | ");
                    log4jParamters_tRunJob_2.append("CONTEXTPARAMS" + " = " + "[{PARAM_NAME_COLUMN="+("ORIG_DATABASE_NAME")+", PARAM_VALUE_COLUMN="+("((String)globalMap.get(\"o_database\"))")+"}, {PARAM_NAME_COLUMN="+("FORCE_DROP")+", PARAM_VALUE_COLUMN="+("context.FORCE_DROP")+"}]");
                log4jParamters_tRunJob_2.append(" | ");
                    log4jParamters_tRunJob_2.append("PROPAGATE_CHILD_RESULT" + " = " + "false");
                log4jParamters_tRunJob_2.append(" | ");
                    log4jParamters_tRunJob_2.append("PRINT_PARAMETER" + " = " + "false");
                log4jParamters_tRunJob_2.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tRunJob_2 - "  + (log4jParamters_tRunJob_2) );
    		}
    	}
    	
        new BytesLimit65535_tRunJob_2().limitLog4jByte();


 



/**
 * [tRunJob_2 begin ] stop
 */
	
	/**
	 * [tRunJob_2 main ] start
	 */

	

	
	
	currentComponent="tRunJob_2";

	
	java.util.List<String> paraList_tRunJob_2 = new java.util.ArrayList<String>();
	
	        			paraList_tRunJob_2.add("--father_pid="+pid);
	      			
	        			paraList_tRunJob_2.add("--root_pid="+rootPid);
	      			
	        			paraList_tRunJob_2.add("--father_node=tRunJob_2");
	      			
	        			paraList_tRunJob_2.add("--context=SOURCING_DEV");
	      			
			if(!"".equals(log4jLevel)){
				paraList_tRunJob_2.add("--log4jLevel="+log4jLevel);
			}
		
	//for feature:10589
	
		paraList_tRunJob_2.add("--stat_port=" + portStats);
	

	if(resuming_logs_dir_path != null){
		paraList_tRunJob_2.add("--resuming_logs_dir_path=" + resuming_logs_dir_path);
	}
	String childResumePath_tRunJob_2 = ResumeUtil.getChildJobCheckPointPath(resuming_checkpoint_path);
	String tRunJobName_tRunJob_2 = ResumeUtil.getRighttRunJob(resuming_checkpoint_path);
	if("tRunJob_2".equals(tRunJobName_tRunJob_2) && childResumePath_tRunJob_2 != null){
		paraList_tRunJob_2.add("--resuming_checkpoint_path=" + ResumeUtil.getChildJobCheckPointPath(resuming_checkpoint_path));
	}
	paraList_tRunJob_2.add("--parent_part_launcher=JOB:" + jobName + "/NODE:tRunJob_2");
	
	java.util.Map<String, Object> parentContextMap_tRunJob_2 = new java.util.HashMap<String, Object>();

	
		
		context.synchronizeContext();
		
			parentContextMap_tRunJob_2.put("GP_SOURCE_NAME", context.GP_SOURCE_NAME);
		
			parentContextMap_tRunJob_2.put("TABLE_NAME", context.TABLE_NAME);
		
			parentContextMap_tRunJob_2.put("FORCE_DROP", context.FORCE_DROP);
		
			parentContextMap_tRunJob_2.put("LOAD2HDFS", context.LOAD2HDFS);
		
			parentContextMap_tRunJob_2.put("RUN_ID", context.RUN_ID);
		
			parentContextMap_tRunJob_2.put("ORIG_DATABASE_NAME", context.ORIG_DATABASE_NAME);
		
			parentContextMap_tRunJob_2.put("FDIST_PARAM", context.FDIST_PARAM);
		
			parentContextMap_tRunJob_2.put("LOG_NO_OF_ERRORS", context.LOG_NO_OF_ERRORS);
		
			parentContextMap_tRunJob_2.put("LOG_PLANT_NAME", context.LOG_PLANT_NAME);
		
			parentContextMap_tRunJob_2.put("LOG_NO_OF_UPDATES", context.LOG_NO_OF_UPDATES);
		
			parentContextMap_tRunJob_2.put("LOG_SOURCE_ROW_COUNT", context.LOG_SOURCE_ROW_COUNT);
		
			parentContextMap_tRunJob_2.put("LOG_TECHNOLOGY", context.LOG_TECHNOLOGY);
		
			parentContextMap_tRunJob_2.put("LOG_TABLE_NAME", context.LOG_TABLE_NAME);
		
			parentContextMap_tRunJob_2.put("LOG_NO_OF_INSERTS", context.LOG_NO_OF_INSERTS);
		
			parentContextMap_tRunJob_2.put("LOG_DATA_PATH", context.LOG_DATA_PATH);
		
			parentContextMap_tRunJob_2.put("LOG_NO_OF_DELETES", context.LOG_NO_OF_DELETES);
		
			parentContextMap_tRunJob_2.put("LOG_RUN_ID", context.LOG_RUN_ID);
		
			parentContextMap_tRunJob_2.put("LOG_ERROR_CATEGORY", context.LOG_ERROR_CATEGORY);
		
			parentContextMap_tRunJob_2.put("LOG_JOB_NAME", context.LOG_JOB_NAME);
		
			parentContextMap_tRunJob_2.put("LOG_SYSTEM_NAME", context.LOG_SYSTEM_NAME);
		
			parentContextMap_tRunJob_2.put("LOG_MESSAGE", context.LOG_MESSAGE);
		
			parentContextMap_tRunJob_2.put("LOG_TARGET_ROW_COUNT", context.LOG_TARGET_ROW_COUNT);
		
			parentContextMap_tRunJob_2.put("LOG_STATUS", context.LOG_STATUS);
		
			parentContextMap_tRunJob_2.put("JOB_LABEL_NAME", context.JOB_LABEL_NAME);
		
			parentContextMap_tRunJob_2.put("PLANT_NAME", context.PLANT_NAME);
		
			parentContextMap_tRunJob_2.put("SEND_MAIL", context.SEND_MAIL);
		
			parentContextMap_tRunJob_2.put("MAIL_TO", context.MAIL_TO);
		
			parentContextMap_tRunJob_2.put("PUBLIC", context.PUBLIC);
		
			parentContextMap_tRunJob_2.put("THREAD", context.THREAD);
		
			parentContextMap_tRunJob_2.put("ETL_LOCALHOSTNAME", context.ETL_LOCALHOSTNAME);
		
			parentContextMap_tRunJob_2.put("ETL_STORAGE_PATH", context.ETL_STORAGE_PATH);
		
			parentContextMap_tRunJob_2.put("HAWQ_Source_Ports", context.HAWQ_Source_Ports);
		
			parentContextMap_tRunJob_2.put("SOURCE_DATABASE", context.SOURCE_DATABASE);
		
			parentContextMap_tRunJob_2.put("SOURCE_HOST", context.SOURCE_HOST);
		
			parentContextMap_tRunJob_2.put("SOURCE_PASSWORD", context.SOURCE_PASSWORD);
		
			parentContextMap_tRunJob_2.put("SOURCE_PORT", context.SOURCE_PORT);
		
			parentContextMap_tRunJob_2.put("SOURCE_USER", context.SOURCE_USER);
		
			parentContextMap_tRunJob_2.put("SOURCING_Database", context.SOURCING_Database);
		
			parentContextMap_tRunJob_2.put("SOURCING_Login", context.SOURCING_Login);
		
			parentContextMap_tRunJob_2.put("SOURCING_Password", context.SOURCING_Password);
		
			parentContextMap_tRunJob_2.put("SOURCING_Port", context.SOURCING_Port);
		
			parentContextMap_tRunJob_2.put("SOURCING_Schema", context.SOURCING_Schema);
		
			parentContextMap_tRunJob_2.put("SOURCING_Server", context.SOURCING_Server);
		 
		java.util.Enumeration<?> propertyNames_tRunJob_2 = context.propertyNames();
		while (propertyNames_tRunJob_2.hasMoreElements()) {
			String key_tRunJob_2 = (String) propertyNames_tRunJob_2.nextElement();
			Object value_tRunJob_2 = (Object) context.get(key_tRunJob_2);       
			paraList_tRunJob_2.add("--context_param " + key_tRunJob_2 + "=" + value_tRunJob_2);
			
		}
		

	Object obj_tRunJob_2 = null;

	
		obj_tRunJob_2 = ((String)globalMap.get("o_database"));
		paraList_tRunJob_2.add("--context_param ORIG_DATABASE_NAME=" + RuntimeUtils.tRunJobConvertContext(obj_tRunJob_2));
		
		parentContextMap_tRunJob_2.put("ORIG_DATABASE_NAME", obj_tRunJob_2);
	
		obj_tRunJob_2 = context.FORCE_DROP;
		paraList_tRunJob_2.add("--context_param FORCE_DROP=" + RuntimeUtils.tRunJobConvertContext(obj_tRunJob_2));
		
		parentContextMap_tRunJob_2.put("FORCE_DROP", obj_tRunJob_2);
	
	
		aws_dev_talend_ingestion_framework.edl_prod2dev_with_gp_fdist_child_0_1.EDL_Prod2Dev_with_GP_FDIST_child childJob_tRunJob_2 = new aws_dev_talend_ingestion_framework.edl_prod2dev_with_gp_fdist_child_0_1.EDL_Prod2Dev_with_GP_FDIST_child();
	    // pass DataSources
	    java.util.Map<String, routines.system.TalendDataSource> talendDataSources_tRunJob_2 = (java.util.Map<String, routines.system.TalendDataSource>) globalMap
	            .get(KEY_DB_DATASOURCES);
	    if (null != talendDataSources_tRunJob_2) {
	        java.util.Map<String, javax.sql.DataSource> dataSources_tRunJob_2 = new java.util.HashMap<String, javax.sql.DataSource>();
	        for (java.util.Map.Entry<String, routines.system.TalendDataSource> talendDataSourceEntry_tRunJob_2 : talendDataSources_tRunJob_2
			        .entrySet()) {
	            dataSources_tRunJob_2.put(talendDataSourceEntry_tRunJob_2.getKey(),
	                    talendDataSourceEntry_tRunJob_2.getValue().getRawDataSource());
	        }
	        childJob_tRunJob_2.setDataSources(dataSources_tRunJob_2);
	    }
		  
			childJob_tRunJob_2.parentContextMap = parentContextMap_tRunJob_2;
		  
		
			log.info("tRunJob_2 - The child job 'aws_dev_talend_ingestion_framework.edl_prod2dev_with_gp_fdist_child_0_1.EDL_Prod2Dev_with_GP_FDIST_child' starts on the version '0.1' with the context 'SOURCING_DEV'.");
		
		String[][] childReturn_tRunJob_2 = childJob_tRunJob_2.runJob((String[]) paraList_tRunJob_2.toArray(new String[paraList_tRunJob_2.size()]));
		
			log.info("tRunJob_2 - The child job 'aws_dev_talend_ingestion_framework.edl_prod2dev_with_gp_fdist_child_0_1.EDL_Prod2Dev_with_GP_FDIST_child' is done.");
		
	  	
				((java.util.Map)threadLocal.get()).put("errorCode", childJob_tRunJob_2.getErrorCode());
			
	            
	    	if(childJob_tRunJob_2.getErrorCode() == null){
				globalMap.put("tRunJob_2_CHILD_RETURN_CODE", childJob_tRunJob_2.getStatus() != null && ("failure").equals(childJob_tRunJob_2.getStatus()) ? 1 : 0);
	    	}else{
				globalMap.put("tRunJob_2_CHILD_RETURN_CODE", childJob_tRunJob_2.getErrorCode());
		    }
		    if (childJob_tRunJob_2.getExceptionStackTrace() != null) { 
		    	globalMap.put("tRunJob_2_CHILD_EXCEPTION_STACKTRACE", childJob_tRunJob_2.getExceptionStackTrace());
		    }
	  
			
	  	

 


	tos_count_tRunJob_2++;

/**
 * [tRunJob_2 main ] stop
 */
	
	/**
	 * [tRunJob_2 end ] start
	 */

	

	
	
	currentComponent="tRunJob_2";

	

 
                if(log.isDebugEnabled())
            log.debug("tRunJob_2 - "  + ("Done.") );

ok_Hash.put("tRunJob_2", true);
end_Hash.put("tRunJob_2", System.currentTimeMillis());




/**
 * [tRunJob_2 end ] stop
 */
						if(execStat){
							runStat.updateStatOnConnection("iterate2", 2, "exec" + NB_ITERATE_tRunJob_2);
						}				
					








} // End of branch "row14"




	
	/**
	 * [tFileInputDelimited_1 end ] start
	 */

	

	
	
	currentComponent="tFileInputDelimited_1";

	



            }
            }finally{
                if(!((Object)(context.ETL_STORAGE_PATH + "/" +context.GP_SOURCE_NAME + "/" +((String)globalMap.get("timestamp"))+".csv") instanceof java.io.InputStream)){
                	if(fid_tFileInputDelimited_1!=null){
                		fid_tFileInputDelimited_1.close();
                	}
                }
                if(fid_tFileInputDelimited_1!=null){
                	globalMap.put("tFileInputDelimited_1_NB_LINE", fid_tFileInputDelimited_1.getRowNumber());
					
						log.info("tFileInputDelimited_1 - Retrieved records count: "+ fid_tFileInputDelimited_1.getRowNumber() + ".");
					
                }
			}
			  

 
                if(log.isDebugEnabled())
            log.debug("tFileInputDelimited_1 - "  + ("Done.") );

ok_Hash.put("tFileInputDelimited_1", true);
end_Hash.put("tFileInputDelimited_1", System.currentTimeMillis());




/**
 * [tFileInputDelimited_1 end ] stop
 */

	
	/**
	 * [tJavaRow_6 end ] start
	 */

	

	
	
	currentComponent="tJavaRow_6";

	

globalMap.put("tJavaRow_6_NB_LINE",nb_line_tJavaRow_6);
			if(execStat){
				if(resourceMap.get("inIterateVComp") == null || !((Boolean)resourceMap.get("inIterateVComp"))){
			 		runStat.updateStatOnConnection("row14"+iterateId,2, 0); 
			 	}
			}
		
 

ok_Hash.put("tJavaRow_6", true);
end_Hash.put("tJavaRow_6", System.currentTimeMillis());




/**
 * [tJavaRow_6 end ] stop
 */

	
	/**
	 * [tFlowToIterate_2 end ] start
	 */

	

	
	
	currentComponent="tFlowToIterate_2";

	

globalMap.put("tFlowToIterate_2_NB_LINE",nb_line_tFlowToIterate_2);
			if(execStat){
				if(resourceMap.get("inIterateVComp") == null || !((Boolean)resourceMap.get("inIterateVComp"))){
			 		runStat.updateStatOnConnection("row15"+iterateId,2, 0); 
			 	}
			}
		
 
                if(log.isDebugEnabled())
            log.debug("tFlowToIterate_2 - "  + ("Done.") );

ok_Hash.put("tFlowToIterate_2", true);
end_Hash.put("tFlowToIterate_2", System.currentTimeMillis());




/**
 * [tFlowToIterate_2 end ] stop
 */






				}//end the resume

				
				    			if(resumeEntryMethodName == null || globalResumeTicket){
				    				resumeUtil.addLog("CHECKPOINT", "CONNECTION:SUBJOB_OK:tFileInputDelimited_1:OnSubjobOk1", "", Thread.currentThread().getId() + "", "", "", "", "", "");
								}	    				    			
					    	
								if(execStat){    	
									runStat.updateStatOnConnection("OnSubjobOk33", 0, "ok");
								} 
							
							tFileDelete_2Process(globalMap); 
						
				    			if(resumeEntryMethodName == null || globalResumeTicket){
				    				resumeUtil.addLog("CHECKPOINT", "CONNECTION:SUBJOB_OK:tFileInputDelimited_1:OnSubjobOk2", "", Thread.currentThread().getId() + "", "", "", "", "", "");
								}	    				    			
					    	
								if(execStat){    	
									runStat.updateStatOnConnection("OnSubjobOk34", 0, "ok");
								} 
							
							tGreenplumConnection_6Process(globalMap); 
						
				    			if(resumeEntryMethodName == null || globalResumeTicket){
				    				resumeUtil.addLog("CHECKPOINT", "CONNECTION:SUBJOB_OK:tFileInputDelimited_1:OnSubjobOk3", "", Thread.currentThread().getId() + "", "", "", "", "", "");
								}	    				    			
					    	
								if(execStat){    	
									runStat.updateStatOnConnection("OnSubjobOk40", 0, "ok");
								} 
							
							tGreenplumConnection_8Process(globalMap); 
						



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage());
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tFileInputDelimited_1 finally ] start
	 */

	

	
	
	currentComponent="tFileInputDelimited_1";

	

 



/**
 * [tFileInputDelimited_1 finally ] stop
 */

	
	/**
	 * [tJavaRow_6 finally ] start
	 */

	

	
	
	currentComponent="tJavaRow_6";

	

 



/**
 * [tJavaRow_6 finally ] stop
 */

	
	/**
	 * [tFlowToIterate_2 finally ] start
	 */

	

	
	
	currentComponent="tFlowToIterate_2";

	

 



/**
 * [tFlowToIterate_2 finally ] stop
 */

	
	/**
	 * [tRunJob_2 finally ] start
	 */

	

	
	
	currentComponent="tRunJob_2";

	

 



/**
 * [tRunJob_2 finally ] stop
 */









				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tFileInputDelimited_1_SUBPROCESS_STATE", 1);
	}
	

public void tFileDelete_2Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tFileDelete_2_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;





	
	/**
	 * [tFileDelete_2 begin ] start
	 */

	

	
		
		ok_Hash.put("tFileDelete_2", false);
		start_Hash.put("tFileDelete_2", System.currentTimeMillis());
		
				talendStats_STATS.addMessage("begin","tFileDelete_2");
				talendStats_STATSProcess(globalMap);
			
	
	currentComponent="tFileDelete_2";

	
		int tos_count_tFileDelete_2 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tFileDelete_2 - "  + ("Start to work.") );
    	class BytesLimit65535_tFileDelete_2{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tFileDelete_2 = new StringBuilder();
            log4jParamters_tFileDelete_2.append("Parameters:");
                    log4jParamters_tFileDelete_2.append("FILENAME" + " = " + "context.ETL_STORAGE_PATH + \"/\" +context.GP_SOURCE_NAME + \"/\" +((String)globalMap.get(\"timestamp\"))+\".csv\"");
                log4jParamters_tFileDelete_2.append(" | ");
                    log4jParamters_tFileDelete_2.append("FAILON" + " = " + "true");
                log4jParamters_tFileDelete_2.append(" | ");
                    log4jParamters_tFileDelete_2.append("FOLDER" + " = " + "false");
                log4jParamters_tFileDelete_2.append(" | ");
                    log4jParamters_tFileDelete_2.append("FOLDER_FILE" + " = " + "false");
                log4jParamters_tFileDelete_2.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tFileDelete_2 - "  + (log4jParamters_tFileDelete_2) );
    		}
    	}
    	
        new BytesLimit65535_tFileDelete_2().limitLog4jByte();

 



/**
 * [tFileDelete_2 begin ] stop
 */
	
	/**
	 * [tFileDelete_2 main ] start
	 */

	

	
	
	currentComponent="tFileDelete_2";

	

 

				final StringBuffer log4jSb_tFileDelete_2 = new StringBuffer();
			
class DeleteFoldertFileDelete_2{
	 /**
     * delete all the sub-files in 'file'
     * 
     * @param file
     */
	public boolean delete(java.io.File file) {
        java.io.File[] files = file.listFiles();
        for (int i = 0; i < files.length; i++) {
            if (files[i].isFile()) {
                files[i].delete();
            } else if (files[i].isDirectory()) {
                if (!files[i].delete()) {
                    delete(files[i]);
                }
            }
        }
        deleteDirectory(file);
        return file.delete();
    }

    /**
     * delete all the sub-folders in 'file'
     * 
     * @param file
     */
    private void deleteDirectory(java.io.File file) {
        java.io.File[] filed = file.listFiles();
        for (int i = 0; i < filed.length; i++) {
        	if(filed[i].isDirectory()) {
            	deleteDirectory(filed[i]);
            }
            filed[i].delete();
        }
    }

}
    java.io.File file_tFileDelete_2=new java.io.File(context.ETL_STORAGE_PATH + "/" +context.GP_SOURCE_NAME + "/" +((String)globalMap.get("timestamp"))+".csv");
    if(file_tFileDelete_2.exists()&& file_tFileDelete_2.isFile()){
    	if(file_tFileDelete_2.delete()){
    		globalMap.put("tFileDelete_2_CURRENT_STATUS", "File deleted.");
    		log.info("tFileDelete_2 - File : "+ file_tFileDelete_2.getAbsolutePath() + " is deleted.");
    	}else{
    		globalMap.put("tFileDelete_2_CURRENT_STATUS", "No file deleted.");
    		log.info("tFileDelete_2 - Fail to delete file : "+ file_tFileDelete_2.getAbsolutePath());
    	}
    }else{
    	globalMap.put("tFileDelete_2_CURRENT_STATUS", "File does not exist or is invalid.");
    		throw new RuntimeException("File does not exist or is invalid.");
	}
	globalMap.put("tFileDelete_2_DELETE_PATH",context.ETL_STORAGE_PATH + "/" +context.GP_SOURCE_NAME + "/" +((String)globalMap.get("timestamp"))+".csv");
    
     
 

 


	tos_count_tFileDelete_2++;

/**
 * [tFileDelete_2 main ] stop
 */
	
	/**
	 * [tFileDelete_2 end ] start
	 */

	

	
	
	currentComponent="tFileDelete_2";

	

 
                if(log.isDebugEnabled())
            log.debug("tFileDelete_2 - "  + ("Done.") );

ok_Hash.put("tFileDelete_2", true);
end_Hash.put("tFileDelete_2", System.currentTimeMillis());

talendStats_STATS.addMessage("end","tFileDelete_2", end_Hash.get("tFileDelete_2")-start_Hash.get("tFileDelete_2"));
talendStats_STATSProcess(globalMap);



/**
 * [tFileDelete_2 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage());
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tFileDelete_2 finally ] start
	 */

	

	
	
	currentComponent="tFileDelete_2";

	

 



/**
 * [tFileDelete_2 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tFileDelete_2_SUBPROCESS_STATE", 1);
	}
	

public void tGreenplumConnection_6Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tGreenplumConnection_6_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tGreenplumConnection_6 begin ] start
	 */

	

	
		
		ok_Hash.put("tGreenplumConnection_6", false);
		start_Hash.put("tGreenplumConnection_6", System.currentTimeMillis());
		
	
	currentComponent="tGreenplumConnection_6";

	
		int tos_count_tGreenplumConnection_6 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tGreenplumConnection_6 - "  + ("Start to work.") );
    	class BytesLimit65535_tGreenplumConnection_6{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tGreenplumConnection_6 = new StringBuilder();
            log4jParamters_tGreenplumConnection_6.append("Parameters:");
                    log4jParamters_tGreenplumConnection_6.append("HOST" + " = " + "context.SOURCE_HOST");
                log4jParamters_tGreenplumConnection_6.append(" | ");
                    log4jParamters_tGreenplumConnection_6.append("PORT" + " = " + "context.SOURCE_PORT");
                log4jParamters_tGreenplumConnection_6.append(" | ");
                    log4jParamters_tGreenplumConnection_6.append("DBNAME" + " = " + "context.SOURCE_DATABASE");
                log4jParamters_tGreenplumConnection_6.append(" | ");
                    log4jParamters_tGreenplumConnection_6.append("SCHEMA_DB" + " = " + "\"\"");
                log4jParamters_tGreenplumConnection_6.append(" | ");
                    log4jParamters_tGreenplumConnection_6.append("USER" + " = " + "context.SOURCE_USER");
                log4jParamters_tGreenplumConnection_6.append(" | ");
                    log4jParamters_tGreenplumConnection_6.append("PASS" + " = " + String.valueOf(routines.system.PasswordEncryptUtil.encryptPassword(context.SOURCE_PASSWORD)).substring(0, 4) + "...");     
                log4jParamters_tGreenplumConnection_6.append(" | ");
                    log4jParamters_tGreenplumConnection_6.append("USE_SHARED_CONNECTION" + " = " + "true");
                log4jParamters_tGreenplumConnection_6.append(" | ");
                    log4jParamters_tGreenplumConnection_6.append("SHARED_CONNECTION_NAME" + " = " + "\"base_dynamic\"+((String)globalMap.get(\"timestamp\"))");
                log4jParamters_tGreenplumConnection_6.append(" | ");
                    log4jParamters_tGreenplumConnection_6.append("USE_SSL" + " = " + "true");
                log4jParamters_tGreenplumConnection_6.append(" | ");
                    log4jParamters_tGreenplumConnection_6.append("AUTO_COMMIT" + " = " + "true");
                log4jParamters_tGreenplumConnection_6.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tGreenplumConnection_6 - "  + (log4jParamters_tGreenplumConnection_6) );
    		}
    	}
    	
        new BytesLimit65535_tGreenplumConnection_6().limitLog4jByte();
	

	
				String url_tGreenplumConnection_6 = "jdbc:postgresql://"+context.SOURCE_HOST+":"+context.SOURCE_PORT+"/"+context.SOURCE_DATABASE+"?ssl=true&sslfactory=org.postgresql.ssl.NonValidatingFactory";

	String dbUser_tGreenplumConnection_6 = context.SOURCE_USER;
	
	
		
	final String decryptedPassword_tGreenplumConnection_6 = context.SOURCE_PASSWORD; 
		String dbPwd_tGreenplumConnection_6 = decryptedPassword_tGreenplumConnection_6;
	

	java.sql.Connection conn_tGreenplumConnection_6 = null;
	
	
			SharedDBConnectionLog4j.initLogger(log,"tGreenplumConnection_6");
			String sharedConnectionName_tGreenplumConnection_6 = "base_dynamic"+((String)globalMap.get("timestamp"));
			conn_tGreenplumConnection_6 = SharedDBConnectionLog4j.getDBConnection("org.postgresql.Driver",url_tGreenplumConnection_6,dbUser_tGreenplumConnection_6 , dbPwd_tGreenplumConnection_6 , sharedConnectionName_tGreenplumConnection_6);
	if (null != conn_tGreenplumConnection_6) {
		
			log.debug("tGreenplumConnection_6 - Connection is set auto commit to 'true'.");
			conn_tGreenplumConnection_6.setAutoCommit(true);
	}

	globalMap.put("schema_" + "tGreenplumConnection_6","");

	globalMap.put("conn_" + "tGreenplumConnection_6",conn_tGreenplumConnection_6);
 



/**
 * [tGreenplumConnection_6 begin ] stop
 */
	
	/**
	 * [tGreenplumConnection_6 main ] start
	 */

	

	
	
	currentComponent="tGreenplumConnection_6";

	

 


	tos_count_tGreenplumConnection_6++;

/**
 * [tGreenplumConnection_6 main ] stop
 */
	
	/**
	 * [tGreenplumConnection_6 end ] start
	 */

	

	
	
	currentComponent="tGreenplumConnection_6";

	

 
                if(log.isDebugEnabled())
            log.debug("tGreenplumConnection_6 - "  + ("Done.") );

ok_Hash.put("tGreenplumConnection_6", true);
end_Hash.put("tGreenplumConnection_6", System.currentTimeMillis());




/**
 * [tGreenplumConnection_6 end ] stop
 */
				}//end the resume

				
				    			if(resumeEntryMethodName == null || globalResumeTicket){
				    				resumeUtil.addLog("CHECKPOINT", "CONNECTION:SUBJOB_OK:tGreenplumConnection_6:OnSubjobOk", "", Thread.currentThread().getId() + "", "", "", "", "", "");
								}	    				    			
					    	
								if(execStat){    	
									runStat.updateStatOnConnection("OnSubjobOk23", 0, "ok");
								} 
							
							tGreenplumInput_10Process(globalMap); 
						



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage());
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tGreenplumConnection_6 finally ] start
	 */

	

	
	
	currentComponent="tGreenplumConnection_6";

	

 



/**
 * [tGreenplumConnection_6 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tGreenplumConnection_6_SUBPROCESS_STATE", 1);
	}
	


public static class row11Struct implements routines.system.IPersistableRow<row11Struct> {
    final static byte[] commonByteArrayLock_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Prod2Dev_with_GP_FDIST = new byte[0];
    static byte[] commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Prod2Dev_with_GP_FDIST = new byte[0];

	
			    public Integer row_id;

				public Integer getRow_id () {
					return this.row_id;
				}
				


	private Integer readInteger(ObjectInputStream dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}

	private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException{
		if(intNum == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeInt(intNum);
    	}
	}

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Prod2Dev_with_GP_FDIST) {

        	try {

        		int length = 0;
		
						this.row_id = readInteger(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// Integer
				
						writeInteger(this.row_id,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("row_id="+String.valueOf(row_id));
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				if(row_id == null){
        					sb.append("<null>");
        				}else{
            				sb.append(row_id);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(row11Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}
public void tGreenplumInput_10Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tGreenplumInput_10_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;



		row11Struct row11 = new row11Struct();




	
	/**
	 * [tSetGlobalVar_6 begin ] start
	 */

	

	
		
		ok_Hash.put("tSetGlobalVar_6", false);
		start_Hash.put("tSetGlobalVar_6", System.currentTimeMillis());
		
	
	currentComponent="tSetGlobalVar_6";

	
			if (execStat) {
				if(resourceMap.get("inIterateVComp") == null){
					
						runStat.updateStatOnConnection("row11" + iterateId, 0, 0);
					
				}
			} 

		
		int tos_count_tSetGlobalVar_6 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tSetGlobalVar_6 - "  + ("Start to work.") );
    	class BytesLimit65535_tSetGlobalVar_6{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tSetGlobalVar_6 = new StringBuilder();
            log4jParamters_tSetGlobalVar_6.append("Parameters:");
                    log4jParamters_tSetGlobalVar_6.append("VARIABLES" + " = " + "[{VALUE="+("row11.row_id")+", KEY="+("\"LOG_ROW_ID\"")+"}]");
                log4jParamters_tSetGlobalVar_6.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tSetGlobalVar_6 - "  + (log4jParamters_tSetGlobalVar_6) );
    		}
    	}
    	
        new BytesLimit65535_tSetGlobalVar_6().limitLog4jByte();

 



/**
 * [tSetGlobalVar_6 begin ] stop
 */



	
	/**
	 * [tGreenplumInput_10 begin ] start
	 */

	

	
		
		ok_Hash.put("tGreenplumInput_10", false);
		start_Hash.put("tGreenplumInput_10", System.currentTimeMillis());
		
	
	currentComponent="tGreenplumInput_10";

	
		int tos_count_tGreenplumInput_10 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tGreenplumInput_10 - "  + ("Start to work.") );
    	class BytesLimit65535_tGreenplumInput_10{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tGreenplumInput_10 = new StringBuilder();
            log4jParamters_tGreenplumInput_10.append("Parameters:");
                    log4jParamters_tGreenplumInput_10.append("USE_EXISTING_CONNECTION" + " = " + "true");
                log4jParamters_tGreenplumInput_10.append(" | ");
                    log4jParamters_tGreenplumInput_10.append("CONNECTION" + " = " + "tGreenplumConnection_6");
                log4jParamters_tGreenplumInput_10.append(" | ");
                    log4jParamters_tGreenplumInput_10.append("TABLE" + " = " + "\"\"");
                log4jParamters_tGreenplumInput_10.append(" | ");
                    log4jParamters_tGreenplumInput_10.append("QUERYSTORE" + " = " + "\"\"");
                log4jParamters_tGreenplumInput_10.append(" | ");
                    log4jParamters_tGreenplumInput_10.append("QUERY" + " = " + "\"select row_id from sbdt.edl_log where run_id = \"+((Integer)globalMap.get(\"BASE_RUN_ID\"))");
                log4jParamters_tGreenplumInput_10.append(" | ");
                    log4jParamters_tGreenplumInput_10.append("USE_CURSOR" + " = " + "false");
                log4jParamters_tGreenplumInput_10.append(" | ");
                    log4jParamters_tGreenplumInput_10.append("TRIM_ALL_COLUMN" + " = " + "false");
                log4jParamters_tGreenplumInput_10.append(" | ");
                    log4jParamters_tGreenplumInput_10.append("TRIM_COLUMN" + " = " + "[{TRIM="+("false")+", SCHEMA_COLUMN="+("row_id")+"}]");
                log4jParamters_tGreenplumInput_10.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tGreenplumInput_10 - "  + (log4jParamters_tGreenplumInput_10) );
    		}
    	}
    	
        new BytesLimit65535_tGreenplumInput_10().limitLog4jByte();
	
    
	
		    int nb_line_tGreenplumInput_10 = 0;
		    java.sql.Connection conn_tGreenplumInput_10 = null;
		        conn_tGreenplumInput_10 = (java.sql.Connection)globalMap.get("conn_tGreenplumConnection_6");
				
				if(conn_tGreenplumInput_10 != null) {
					if(conn_tGreenplumInput_10.getMetaData() != null) {
						
						log.debug("tGreenplumInput_10 - Uses an existing connection with username '" + conn_tGreenplumInput_10.getMetaData().getUserName() + "'. Connection URL: " + conn_tGreenplumInput_10.getMetaData().getURL() + ".");
						
					}
				}
			
		    
			java.sql.Statement stmt_tGreenplumInput_10 = conn_tGreenplumInput_10.createStatement();

		    String dbquery_tGreenplumInput_10 = "select row_id from sbdt.edl_log where run_id = "+((Integer)globalMap.get("BASE_RUN_ID"));
			
                log.debug("tGreenplumInput_10 - Executing the query: '"+dbquery_tGreenplumInput_10+"'.");
			

                       globalMap.put("tGreenplumInput_10_QUERY",dbquery_tGreenplumInput_10);

		    java.sql.ResultSet rs_tGreenplumInput_10 = null;
		try{
		    rs_tGreenplumInput_10 = stmt_tGreenplumInput_10.executeQuery(dbquery_tGreenplumInput_10);
		    java.sql.ResultSetMetaData rsmd_tGreenplumInput_10 = rs_tGreenplumInput_10.getMetaData();
		    int colQtyInRs_tGreenplumInput_10 = rsmd_tGreenplumInput_10.getColumnCount();

		    String tmpContent_tGreenplumInput_10 = null;
		    
		    
		    	log.debug("tGreenplumInput_10 - Retrieving records from the database.");
		    
		    while (rs_tGreenplumInput_10.next()) {
		        nb_line_tGreenplumInput_10++;
		        
							if(colQtyInRs_tGreenplumInput_10 < 1) {
								row11.row_id = null;
							} else {
		                          
            if(rs_tGreenplumInput_10.getObject(1) != null) {
                row11.row_id = rs_tGreenplumInput_10.getInt(1);
            } else {
                    row11.row_id = null;
            }
		                    }
					
						log.debug("tGreenplumInput_10 - Retrieving the record " + nb_line_tGreenplumInput_10 + ".");
					


 



/**
 * [tGreenplumInput_10 begin ] stop
 */
	
	/**
	 * [tGreenplumInput_10 main ] start
	 */

	

	
	
	currentComponent="tGreenplumInput_10";

	

 


	tos_count_tGreenplumInput_10++;

/**
 * [tGreenplumInput_10 main ] stop
 */

	
	/**
	 * [tSetGlobalVar_6 main ] start
	 */

	

	
	
	currentComponent="tSetGlobalVar_6";

	

			//row11
			//row11


			
				if(execStat){
					runStat.updateStatOnConnection("row11"+iterateId,1, 1);
				} 
			

		
    			if(log.isTraceEnabled()){
    				log.trace("row11 - " + (row11==null? "": row11.toLogString()));
    			}
    		

globalMap.put("LOG_ROW_ID", row11.row_id);

 


	tos_count_tSetGlobalVar_6++;

/**
 * [tSetGlobalVar_6 main ] stop
 */



	
	/**
	 * [tGreenplumInput_10 end ] start
	 */

	

	
	
	currentComponent="tGreenplumInput_10";

	

	}
}finally{
	stmt_tGreenplumInput_10.close();

}
globalMap.put("tGreenplumInput_10_NB_LINE",nb_line_tGreenplumInput_10);
	    		log.debug("tGreenplumInput_10 - Retrieved records count: "+nb_line_tGreenplumInput_10 + " .");
			

 
                if(log.isDebugEnabled())
            log.debug("tGreenplumInput_10 - "  + ("Done.") );

ok_Hash.put("tGreenplumInput_10", true);
end_Hash.put("tGreenplumInput_10", System.currentTimeMillis());




/**
 * [tGreenplumInput_10 end ] stop
 */

	
	/**
	 * [tSetGlobalVar_6 end ] start
	 */

	

	
	
	currentComponent="tSetGlobalVar_6";

	

			if(execStat){
				if(resourceMap.get("inIterateVComp") == null || !((Boolean)resourceMap.get("inIterateVComp"))){
			 		runStat.updateStatOnConnection("row11"+iterateId,2, 0); 
			 	}
			}
		
 
                if(log.isDebugEnabled())
            log.debug("tSetGlobalVar_6 - "  + ("Done.") );

ok_Hash.put("tSetGlobalVar_6", true);
end_Hash.put("tSetGlobalVar_6", System.currentTimeMillis());




/**
 * [tSetGlobalVar_6 end ] stop
 */



				}//end the resume

				
				    			if(resumeEntryMethodName == null || globalResumeTicket){
				    				resumeUtil.addLog("CHECKPOINT", "CONNECTION:SUBJOB_OK:tGreenplumInput_10:OnSubjobOk", "", Thread.currentThread().getId() + "", "", "", "", "", "");
								}	    				    			
					    	
								if(execStat){    	
									runStat.updateStatOnConnection("OnSubjobOk30", 0, "ok");
								} 
							
							tGreenplumInput_11Process(globalMap); 
						



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage());
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tGreenplumInput_10 finally ] start
	 */

	

	
	
	currentComponent="tGreenplumInput_10";

	

 



/**
 * [tGreenplumInput_10 finally ] stop
 */

	
	/**
	 * [tSetGlobalVar_6 finally ] start
	 */

	

	
	
	currentComponent="tSetGlobalVar_6";

	

 



/**
 * [tSetGlobalVar_6 finally ] stop
 */



				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tGreenplumInput_10_SUBPROCESS_STATE", 1);
	}
	


public static class row7_0Struct implements routines.system.IPersistableRow<row7_0Struct> {
    final static byte[] commonByteArrayLock_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Prod2Dev_with_GP_FDIST = new byte[0];
    static byte[] commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Prod2Dev_with_GP_FDIST = new byte[0];

	
			    public Integer cnt;

				public Integer getCnt () {
					return this.cnt;
				}
				
			    public String messages;

				public String getMessages () {
					return this.messages;
				}
				


	private Integer readInteger(ObjectInputStream dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}

	private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException{
		if(intNum == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeInt(intNum);
    	}
	}

	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Prod2Dev_with_GP_FDIST.length) {
				if(length < 1024 && commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Prod2Dev_with_GP_FDIST.length == 0) {
   					commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Prod2Dev_with_GP_FDIST = new byte[1024];
				} else {
   					commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Prod2Dev_with_GP_FDIST = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Prod2Dev_with_GP_FDIST, 0, length);
			strReturn = new String(commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Prod2Dev_with_GP_FDIST, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Prod2Dev_with_GP_FDIST) {

        	try {

        		int length = 0;
		
						this.cnt = readInteger(dis);
					
					this.messages = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// Integer
				
						writeInteger(this.cnt,dos);
					
					// String
				
						writeString(this.messages,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("cnt="+String.valueOf(cnt));
		sb.append(",messages="+messages);
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				if(cnt == null){
        					sb.append("<null>");
        				}else{
            				sb.append(cnt);
            			}
            		
        			sb.append("|");
        		
        				if(messages == null){
        					sb.append("<null>");
        				}else{
            				sb.append(messages);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(row7_0Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}
public void tGreenplumInput_11Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tGreenplumInput_11_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;



		row7_0Struct row7_0 = new row7_0Struct();




	
	/**
	 * [tSetGlobalVar_7 begin ] start
	 */

	

	
		
		ok_Hash.put("tSetGlobalVar_7", false);
		start_Hash.put("tSetGlobalVar_7", System.currentTimeMillis());
		
	
	currentComponent="tSetGlobalVar_7";

	
			if (execStat) {
				if(resourceMap.get("inIterateVComp") == null){
					
						runStat.updateStatOnConnection("row7_0" + iterateId, 0, 0);
					
				}
			} 

		
		int tos_count_tSetGlobalVar_7 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tSetGlobalVar_7 - "  + ("Start to work.") );
    	class BytesLimit65535_tSetGlobalVar_7{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tSetGlobalVar_7 = new StringBuilder();
            log4jParamters_tSetGlobalVar_7.append("Parameters:");
                    log4jParamters_tSetGlobalVar_7.append("VARIABLES" + " = " + "[{VALUE="+("row7_0.cnt + \" errors occurred: \" + row7_0.messages")+", KEY="+("\"error_message_desc\"")+"}, {VALUE="+("row7_0.cnt ")+", KEY="+("\"error_count\"")+"}]");
                log4jParamters_tSetGlobalVar_7.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tSetGlobalVar_7 - "  + (log4jParamters_tSetGlobalVar_7) );
    		}
    	}
    	
        new BytesLimit65535_tSetGlobalVar_7().limitLog4jByte();

 



/**
 * [tSetGlobalVar_7 begin ] stop
 */



	
	/**
	 * [tGreenplumInput_11 begin ] start
	 */

	

	
		
		ok_Hash.put("tGreenplumInput_11", false);
		start_Hash.put("tGreenplumInput_11", System.currentTimeMillis());
		
	
	currentComponent="tGreenplumInput_11";

	
		int tos_count_tGreenplumInput_11 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tGreenplumInput_11 - "  + ("Start to work.") );
    	class BytesLimit65535_tGreenplumInput_11{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tGreenplumInput_11 = new StringBuilder();
            log4jParamters_tGreenplumInput_11.append("Parameters:");
                    log4jParamters_tGreenplumInput_11.append("USE_EXISTING_CONNECTION" + " = " + "true");
                log4jParamters_tGreenplumInput_11.append(" | ");
                    log4jParamters_tGreenplumInput_11.append("CONNECTION" + " = " + "tGreenplumConnection_6");
                log4jParamters_tGreenplumInput_11.append(" | ");
                    log4jParamters_tGreenplumInput_11.append("TABLE" + " = " + "\"\"");
                log4jParamters_tGreenplumInput_11.append(" | ");
                    log4jParamters_tGreenplumInput_11.append("QUERYSTORE" + " = " + "\"\"");
                log4jParamters_tGreenplumInput_11.append(" | ");
                    log4jParamters_tGreenplumInput_11.append("QUERY" + " = " + "\"select count(*) cnt, substring( string_agg( table_name||' - '||message,' '),0,3950) message  from sbdt.edl_log where  data_path='\"+context.LOG_DATA_PATH+\"' and plant_name='\"+context.LOG_PLANT_NAME+\"' and system_name='\"+context.LOG_SYSTEM_NAME+\"' and status = 'Job Error' and row_id>\"+((Integer)globalMap.get(\"LOG_ROW_ID\"))");
                log4jParamters_tGreenplumInput_11.append(" | ");
                    log4jParamters_tGreenplumInput_11.append("USE_CURSOR" + " = " + "false");
                log4jParamters_tGreenplumInput_11.append(" | ");
                    log4jParamters_tGreenplumInput_11.append("TRIM_ALL_COLUMN" + " = " + "false");
                log4jParamters_tGreenplumInput_11.append(" | ");
                    log4jParamters_tGreenplumInput_11.append("TRIM_COLUMN" + " = " + "[{TRIM="+("false")+", SCHEMA_COLUMN="+("cnt")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("messages")+"}]");
                log4jParamters_tGreenplumInput_11.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tGreenplumInput_11 - "  + (log4jParamters_tGreenplumInput_11) );
    		}
    	}
    	
        new BytesLimit65535_tGreenplumInput_11().limitLog4jByte();
	
    
	
		    int nb_line_tGreenplumInput_11 = 0;
		    java.sql.Connection conn_tGreenplumInput_11 = null;
		        conn_tGreenplumInput_11 = (java.sql.Connection)globalMap.get("conn_tGreenplumConnection_6");
				
				if(conn_tGreenplumInput_11 != null) {
					if(conn_tGreenplumInput_11.getMetaData() != null) {
						
						log.debug("tGreenplumInput_11 - Uses an existing connection with username '" + conn_tGreenplumInput_11.getMetaData().getUserName() + "'. Connection URL: " + conn_tGreenplumInput_11.getMetaData().getURL() + ".");
						
					}
				}
			
		    
			java.sql.Statement stmt_tGreenplumInput_11 = conn_tGreenplumInput_11.createStatement();

		    String dbquery_tGreenplumInput_11 = "select count(*) cnt, substring( string_agg( table_name||' - '||message,' '),0,3950) message  from sbdt.edl_log where  data_path='"+context.LOG_DATA_PATH+"' and plant_name='"+context.LOG_PLANT_NAME+"' and system_name='"+context.LOG_SYSTEM_NAME+"' and status = 'Job Error' and row_id>"+((Integer)globalMap.get("LOG_ROW_ID"));
			
                log.debug("tGreenplumInput_11 - Executing the query: '"+dbquery_tGreenplumInput_11+"'.");
			

                       globalMap.put("tGreenplumInput_11_QUERY",dbquery_tGreenplumInput_11);

		    java.sql.ResultSet rs_tGreenplumInput_11 = null;
		try{
		    rs_tGreenplumInput_11 = stmt_tGreenplumInput_11.executeQuery(dbquery_tGreenplumInput_11);
		    java.sql.ResultSetMetaData rsmd_tGreenplumInput_11 = rs_tGreenplumInput_11.getMetaData();
		    int colQtyInRs_tGreenplumInput_11 = rsmd_tGreenplumInput_11.getColumnCount();

		    String tmpContent_tGreenplumInput_11 = null;
		    
		    
		    	log.debug("tGreenplumInput_11 - Retrieving records from the database.");
		    
		    while (rs_tGreenplumInput_11.next()) {
		        nb_line_tGreenplumInput_11++;
		        
							if(colQtyInRs_tGreenplumInput_11 < 1) {
								row7_0.cnt = null;
							} else {
		                          
            if(rs_tGreenplumInput_11.getObject(1) != null) {
                row7_0.cnt = rs_tGreenplumInput_11.getInt(1);
            } else {
                    row7_0.cnt = null;
            }
		                    }
							if(colQtyInRs_tGreenplumInput_11 < 2) {
								row7_0.messages = null;
							} else {
	                         		
        	row7_0.messages = routines.system.JDBCUtil.getString(rs_tGreenplumInput_11, 2, false);
		                    }
					
						log.debug("tGreenplumInput_11 - Retrieving the record " + nb_line_tGreenplumInput_11 + ".");
					


 



/**
 * [tGreenplumInput_11 begin ] stop
 */
	
	/**
	 * [tGreenplumInput_11 main ] start
	 */

	

	
	
	currentComponent="tGreenplumInput_11";

	

 


	tos_count_tGreenplumInput_11++;

/**
 * [tGreenplumInput_11 main ] stop
 */

	
	/**
	 * [tSetGlobalVar_7 main ] start
	 */

	

	
	
	currentComponent="tSetGlobalVar_7";

	

			//row7_0
			//row7_0


			
				if(execStat){
					runStat.updateStatOnConnection("row7_0"+iterateId,1, 1);
				} 
			

		
    			if(log.isTraceEnabled()){
    				log.trace("row7_0 - " + (row7_0==null? "": row7_0.toLogString()));
    			}
    		

globalMap.put("error_message_desc", row7_0.cnt + " errors occurred: " + row7_0.messages);
globalMap.put("error_count", row7_0.cnt );

 


	tos_count_tSetGlobalVar_7++;

/**
 * [tSetGlobalVar_7 main ] stop
 */



	
	/**
	 * [tGreenplumInput_11 end ] start
	 */

	

	
	
	currentComponent="tGreenplumInput_11";

	

	}
}finally{
	stmt_tGreenplumInput_11.close();

}
globalMap.put("tGreenplumInput_11_NB_LINE",nb_line_tGreenplumInput_11);
	    		log.debug("tGreenplumInput_11 - Retrieved records count: "+nb_line_tGreenplumInput_11 + " .");
			

 
                if(log.isDebugEnabled())
            log.debug("tGreenplumInput_11 - "  + ("Done.") );

ok_Hash.put("tGreenplumInput_11", true);
end_Hash.put("tGreenplumInput_11", System.currentTimeMillis());

   			if (((Integer)globalMap.get("error_count"))>0) {
   				
					if(execStat){   
   	 					runStat.updateStatOnConnection("If7", 0, "true");
					}
				
    			tJava_11Process(globalMap);
   			}

			   
   				else{
					if(execStat){   
   	 					runStat.updateStatOnConnection("If7", 0, "false");
					}   	 
   				}
   			if (((Integer)globalMap.get("error_count"))==0) {
   				
					if(execStat){   
   	 					runStat.updateStatOnConnection("If8", 0, "true");
					}
				
    			tJava_9Process(globalMap);
   			}

			   
   				else{
					if(execStat){   
   	 					runStat.updateStatOnConnection("If8", 0, "false");
					}   	 
   				}



/**
 * [tGreenplumInput_11 end ] stop
 */

	
	/**
	 * [tSetGlobalVar_7 end ] start
	 */

	

	
	
	currentComponent="tSetGlobalVar_7";

	

			if(execStat){
				if(resourceMap.get("inIterateVComp") == null || !((Boolean)resourceMap.get("inIterateVComp"))){
			 		runStat.updateStatOnConnection("row7_0"+iterateId,2, 0); 
			 	}
			}
		
 
                if(log.isDebugEnabled())
            log.debug("tSetGlobalVar_7 - "  + ("Done.") );

ok_Hash.put("tSetGlobalVar_7", true);
end_Hash.put("tSetGlobalVar_7", System.currentTimeMillis());




/**
 * [tSetGlobalVar_7 end ] stop
 */



				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage());
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tGreenplumInput_11 finally ] start
	 */

	

	
	
	currentComponent="tGreenplumInput_11";

	

 



/**
 * [tGreenplumInput_11 finally ] stop
 */

	
	/**
	 * [tSetGlobalVar_7 finally ] start
	 */

	

	
	
	currentComponent="tSetGlobalVar_7";

	

 



/**
 * [tSetGlobalVar_7 finally ] stop
 */



				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tGreenplumInput_11_SUBPROCESS_STATE", 1);
	}
	

public void tJava_11Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tJava_11_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tJava_11 begin ] start
	 */

	

	
		
		ok_Hash.put("tJava_11", false);
		start_Hash.put("tJava_11", System.currentTimeMillis());
		
	
	currentComponent="tJava_11";

	
		int tos_count_tJava_11 = 0;
		
    	class BytesLimit65535_tJava_11{
    		public void limitLog4jByte() throws Exception{
    			
    		}
    	}
    	
        new BytesLimit65535_tJava_11().limitLog4jByte();


//context.LOG_PLANT_NAME="NULL";
//context.LOG_SYSTEM_NAME="NULL";
//context.LOG_TABLE_NAME="NULL";
//context.LOG_JOB_NAME="NULL";
//context.LOG_DATA_PATH="NULL";
//context.LOG_TECHNOLOGY="NULL";
context.LOG_STATUS="Job Error";
context.LOG_MESSAGE=(String)globalMap.get("error_message_desc");
context.LOG_ERROR_CATEGORY="NULL";
context.LOG_NO_OF_INSERTS=0;
context.LOG_NO_OF_UPDATES=0;
context.LOG_NO_OF_DELETES=0;
context.LOG_NO_OF_ERRORS=0;
context.LOG_SOURCE_ROW_COUNT=0;
context.LOG_TARGET_ROW_COUNT=0;

context.LOG_MESSAGE = context.LOG_MESSAGE.replace ("'", "''");

String strInsertLogSql=(String)globalMap.get("insert_log_template");
strInsertLogSql=strInsertLogSql.replace("#PLANT_NAME", "'"+context.LOG_PLANT_NAME+"'");
strInsertLogSql=strInsertLogSql.replace("#SYSTEM_NAME", "'"+context.LOG_SYSTEM_NAME+"'");
strInsertLogSql=strInsertLogSql.replace("#JOB_NAME", "'"+((String)globalMap.get("jobname_prefix"))+context.LOG_JOB_NAME+"'");
strInsertLogSql=strInsertLogSql.replace("#TABLE_NAME", "'"+(String)globalMap.get("orig_table_name")+"'");
strInsertLogSql=strInsertLogSql.replace("#STATUS", "'"+context.LOG_STATUS+"'");
strInsertLogSql=strInsertLogSql.replace("#DATA_PATH", "'"+context.LOG_DATA_PATH+"'");
strInsertLogSql=strInsertLogSql.replace("#TECHNOLOGY", "'"+context.LOG_TECHNOLOGY+"'");
strInsertLogSql=strInsertLogSql.replace("#NO_OF_INSERTS", ((Integer)context.LOG_NO_OF_INSERTS).toString());
strInsertLogSql=strInsertLogSql.replace("#NO_OF_UPDATES", ((Integer)context.LOG_NO_OF_UPDATES).toString());
strInsertLogSql=strInsertLogSql.replace("#NO_OF_DELETES", ((Integer)context.LOG_NO_OF_DELETES).toString());
strInsertLogSql=strInsertLogSql.replace("#NO_OF_ERRORS", ((Integer)context.LOG_NO_OF_ERRORS).toString());
strInsertLogSql=strInsertLogSql.replace("#MESSAGE", "'"+context.LOG_MESSAGE+"'");
strInsertLogSql=strInsertLogSql.replace("#SOURCE_ROW_COUNT", ((Integer)context.LOG_SOURCE_ROW_COUNT).toString());
strInsertLogSql=strInsertLogSql.replace("#TARGET_ROW_COUNT", ((Integer)context.LOG_TARGET_ROW_COUNT).toString());
strInsertLogSql=strInsertLogSql.replace("#ERROR_CATEGORY", "'"+context.LOG_ERROR_CATEGORY+"'");
globalMap.put("insert_log_sql",strInsertLogSql);

//System.out.println(globalMap.get("insert_log_sql"));
//System.out.println(globalMap.get("error_message_desc"));
//System.out.println("******************************");
//System.out.println("******************************");
//globalMap.put("now",new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(TalendDate.getCurrentDate()).toString());
//System.out.println(globalMap.get("now"));
//((String)globalMap.get("tJavaRow_4_ERROR_MESSAGE")) != null
//((Integer)context.LOG_RUN_ID).toString()
//globalMap.put("now_sql","TO_TIMESTAMP('" + ((String)globalMap.get("now")) + "', 'YYYY-MM-DD HH24:MI:SS')::TIMESTAMP WITH TIME ZONE ");
//System.out.println(globalMap.get("now_sql"));
//if (context.LOG_PLANT_NAME.equals("")==true) {
//  context.LOG_PLANT_NAME="Grove City";
//};
//if (context.LOG_APPLICATION.equals("")==true) {
//  context.LOG_APPLICATION="GET-ABM";
//};
 



/**
 * [tJava_11 begin ] stop
 */
	
	/**
	 * [tJava_11 main ] start
	 */

	

	
	
	currentComponent="tJava_11";

	

 


	tos_count_tJava_11++;

/**
 * [tJava_11 main ] stop
 */
	
	/**
	 * [tJava_11 end ] start
	 */

	

	
	
	currentComponent="tJava_11";

	

 

ok_Hash.put("tJava_11", true);
end_Hash.put("tJava_11", System.currentTimeMillis());




/**
 * [tJava_11 end ] stop
 */
				}//end the resume

				
				    			if(resumeEntryMethodName == null || globalResumeTicket){
				    				resumeUtil.addLog("CHECKPOINT", "CONNECTION:SUBJOB_OK:tJava_11:OnSubjobOk", "", Thread.currentThread().getId() + "", "", "", "", "", "");
								}	    				    			
					    	
								if(execStat){    	
									runStat.updateStatOnConnection("OnSubjobOk29", 0, "ok");
								} 
							
							tGreenplumConnection_7Process(globalMap); 
						



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage());
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tJava_11 finally ] start
	 */

	

	
	
	currentComponent="tJava_11";

	

 



/**
 * [tJava_11 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tJava_11_SUBPROCESS_STATE", 1);
	}
	

public void tGreenplumConnection_7Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tGreenplumConnection_7_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tGreenplumConnection_7 begin ] start
	 */

	

	
		
		ok_Hash.put("tGreenplumConnection_7", false);
		start_Hash.put("tGreenplumConnection_7", System.currentTimeMillis());
		
	
	currentComponent="tGreenplumConnection_7";

	
		int tos_count_tGreenplumConnection_7 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tGreenplumConnection_7 - "  + ("Start to work.") );
    	class BytesLimit65535_tGreenplumConnection_7{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tGreenplumConnection_7 = new StringBuilder();
            log4jParamters_tGreenplumConnection_7.append("Parameters:");
                    log4jParamters_tGreenplumConnection_7.append("HOST" + " = " + "context.SOURCE_HOST");
                log4jParamters_tGreenplumConnection_7.append(" | ");
                    log4jParamters_tGreenplumConnection_7.append("PORT" + " = " + "context.SOURCE_PORT");
                log4jParamters_tGreenplumConnection_7.append(" | ");
                    log4jParamters_tGreenplumConnection_7.append("DBNAME" + " = " + "context.SOURCE_DATABASE");
                log4jParamters_tGreenplumConnection_7.append(" | ");
                    log4jParamters_tGreenplumConnection_7.append("SCHEMA_DB" + " = " + "\"\"");
                log4jParamters_tGreenplumConnection_7.append(" | ");
                    log4jParamters_tGreenplumConnection_7.append("USER" + " = " + "context.SOURCE_USER");
                log4jParamters_tGreenplumConnection_7.append(" | ");
                    log4jParamters_tGreenplumConnection_7.append("PASS" + " = " + String.valueOf(routines.system.PasswordEncryptUtil.encryptPassword(context.SOURCE_PASSWORD)).substring(0, 4) + "...");     
                log4jParamters_tGreenplumConnection_7.append(" | ");
                    log4jParamters_tGreenplumConnection_7.append("USE_SHARED_CONNECTION" + " = " + "true");
                log4jParamters_tGreenplumConnection_7.append(" | ");
                    log4jParamters_tGreenplumConnection_7.append("SHARED_CONNECTION_NAME" + " = " + "\"base_dynamic\"+((String)globalMap.get(\"timestamp\"))");
                log4jParamters_tGreenplumConnection_7.append(" | ");
                    log4jParamters_tGreenplumConnection_7.append("USE_SSL" + " = " + "true");
                log4jParamters_tGreenplumConnection_7.append(" | ");
                    log4jParamters_tGreenplumConnection_7.append("AUTO_COMMIT" + " = " + "true");
                log4jParamters_tGreenplumConnection_7.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tGreenplumConnection_7 - "  + (log4jParamters_tGreenplumConnection_7) );
    		}
    	}
    	
        new BytesLimit65535_tGreenplumConnection_7().limitLog4jByte();
	

	
				String url_tGreenplumConnection_7 = "jdbc:postgresql://"+context.SOURCE_HOST+":"+context.SOURCE_PORT+"/"+context.SOURCE_DATABASE+"?ssl=true&sslfactory=org.postgresql.ssl.NonValidatingFactory";

	String dbUser_tGreenplumConnection_7 = context.SOURCE_USER;
	
	
		
	final String decryptedPassword_tGreenplumConnection_7 = context.SOURCE_PASSWORD; 
		String dbPwd_tGreenplumConnection_7 = decryptedPassword_tGreenplumConnection_7;
	

	java.sql.Connection conn_tGreenplumConnection_7 = null;
	
	
			SharedDBConnectionLog4j.initLogger(log,"tGreenplumConnection_7");
			String sharedConnectionName_tGreenplumConnection_7 = "base_dynamic"+((String)globalMap.get("timestamp"));
			conn_tGreenplumConnection_7 = SharedDBConnectionLog4j.getDBConnection("org.postgresql.Driver",url_tGreenplumConnection_7,dbUser_tGreenplumConnection_7 , dbPwd_tGreenplumConnection_7 , sharedConnectionName_tGreenplumConnection_7);
	if (null != conn_tGreenplumConnection_7) {
		
			log.debug("tGreenplumConnection_7 - Connection is set auto commit to 'true'.");
			conn_tGreenplumConnection_7.setAutoCommit(true);
	}

	globalMap.put("schema_" + "tGreenplumConnection_7","");

	globalMap.put("conn_" + "tGreenplumConnection_7",conn_tGreenplumConnection_7);
 



/**
 * [tGreenplumConnection_7 begin ] stop
 */
	
	/**
	 * [tGreenplumConnection_7 main ] start
	 */

	

	
	
	currentComponent="tGreenplumConnection_7";

	

 


	tos_count_tGreenplumConnection_7++;

/**
 * [tGreenplumConnection_7 main ] stop
 */
	
	/**
	 * [tGreenplumConnection_7 end ] start
	 */

	

	
	
	currentComponent="tGreenplumConnection_7";

	

 
                if(log.isDebugEnabled())
            log.debug("tGreenplumConnection_7 - "  + ("Done.") );

ok_Hash.put("tGreenplumConnection_7", true);
end_Hash.put("tGreenplumConnection_7", System.currentTimeMillis());

   			if (context.LOG_RUN_ID == -1) {
   				
					if(execStat){   
   	 					runStat.updateStatOnConnection("If5", 0, "true");
					}
				
    			tGreenplumInput_12Process(globalMap);
   			}

			   
   				else{
					if(execStat){   
   	 					runStat.updateStatOnConnection("If5", 0, "false");
					}   	 
   				}
   			if (context.LOG_RUN_ID != -1) {
   				
					if(execStat){   
   	 					runStat.updateStatOnConnection("If6", 0, "true");
					}
				
    			tJava_13Process(globalMap);
   			}

			   
   				else{
					if(execStat){   
   	 					runStat.updateStatOnConnection("If6", 0, "false");
					}   	 
   				}



/**
 * [tGreenplumConnection_7 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage());
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tGreenplumConnection_7 finally ] start
	 */

	

	
	
	currentComponent="tGreenplumConnection_7";

	

 



/**
 * [tGreenplumConnection_7 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tGreenplumConnection_7_SUBPROCESS_STATE", 1);
	}
	


public static class row12Struct implements routines.system.IPersistableRow<row12Struct> {
    final static byte[] commonByteArrayLock_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Prod2Dev_with_GP_FDIST = new byte[0];
    static byte[] commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Prod2Dev_with_GP_FDIST = new byte[0];

	
			    public Integer run_id;

				public Integer getRun_id () {
					return this.run_id;
				}
				


	private Integer readInteger(ObjectInputStream dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}

	private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException{
		if(intNum == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeInt(intNum);
    	}
	}

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Prod2Dev_with_GP_FDIST) {

        	try {

        		int length = 0;
		
						this.run_id = readInteger(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// Integer
				
						writeInteger(this.run_id,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("run_id="+String.valueOf(run_id));
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				if(run_id == null){
        					sb.append("<null>");
        				}else{
            				sb.append(run_id);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(row12Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}
public void tGreenplumInput_12Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tGreenplumInput_12_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;



		row12Struct row12 = new row12Struct();




	
	/**
	 * [tJavaRow_5 begin ] start
	 */

	

	
		
		ok_Hash.put("tJavaRow_5", false);
		start_Hash.put("tJavaRow_5", System.currentTimeMillis());
		
	
	currentComponent="tJavaRow_5";

	
			if (execStat) {
				if(resourceMap.get("inIterateVComp") == null){
					
						runStat.updateStatOnConnection("row12" + iterateId, 0, 0);
					
				}
			} 

		
		int tos_count_tJavaRow_5 = 0;
		
    	class BytesLimit65535_tJavaRow_5{
    		public void limitLog4jByte() throws Exception{
    			
    		}
    	}
    	
        new BytesLimit65535_tJavaRow_5().limitLog4jByte();

int nb_line_tJavaRow_5 = 0;

 



/**
 * [tJavaRow_5 begin ] stop
 */



	
	/**
	 * [tGreenplumInput_12 begin ] start
	 */

	

	
		
		ok_Hash.put("tGreenplumInput_12", false);
		start_Hash.put("tGreenplumInput_12", System.currentTimeMillis());
		
	
	currentComponent="tGreenplumInput_12";

	
		int tos_count_tGreenplumInput_12 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tGreenplumInput_12 - "  + ("Start to work.") );
    	class BytesLimit65535_tGreenplumInput_12{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tGreenplumInput_12 = new StringBuilder();
            log4jParamters_tGreenplumInput_12.append("Parameters:");
                    log4jParamters_tGreenplumInput_12.append("USE_EXISTING_CONNECTION" + " = " + "true");
                log4jParamters_tGreenplumInput_12.append(" | ");
                    log4jParamters_tGreenplumInput_12.append("CONNECTION" + " = " + "tGreenplumConnection_7");
                log4jParamters_tGreenplumInput_12.append(" | ");
                    log4jParamters_tGreenplumInput_12.append("TABLE" + " = " + "\"\"");
                log4jParamters_tGreenplumInput_12.append(" | ");
                    log4jParamters_tGreenplumInput_12.append("QUERYSTORE" + " = " + "\"\"");
                log4jParamters_tGreenplumInput_12.append(" | ");
                    log4jParamters_tGreenplumInput_12.append("QUERY" + " = " + "\"select NEXTVAL('sbdt.edl_run_id_seq')\"");
                log4jParamters_tGreenplumInput_12.append(" | ");
                    log4jParamters_tGreenplumInput_12.append("USE_CURSOR" + " = " + "false");
                log4jParamters_tGreenplumInput_12.append(" | ");
                    log4jParamters_tGreenplumInput_12.append("TRIM_ALL_COLUMN" + " = " + "false");
                log4jParamters_tGreenplumInput_12.append(" | ");
                    log4jParamters_tGreenplumInput_12.append("TRIM_COLUMN" + " = " + "[{TRIM="+("false")+", SCHEMA_COLUMN="+("run_id")+"}]");
                log4jParamters_tGreenplumInput_12.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tGreenplumInput_12 - "  + (log4jParamters_tGreenplumInput_12) );
    		}
    	}
    	
        new BytesLimit65535_tGreenplumInput_12().limitLog4jByte();
	
    
	
		    int nb_line_tGreenplumInput_12 = 0;
		    java.sql.Connection conn_tGreenplumInput_12 = null;
		        conn_tGreenplumInput_12 = (java.sql.Connection)globalMap.get("conn_tGreenplumConnection_7");
				
				if(conn_tGreenplumInput_12 != null) {
					if(conn_tGreenplumInput_12.getMetaData() != null) {
						
						log.debug("tGreenplumInput_12 - Uses an existing connection with username '" + conn_tGreenplumInput_12.getMetaData().getUserName() + "'. Connection URL: " + conn_tGreenplumInput_12.getMetaData().getURL() + ".");
						
					}
				}
			
		    
			java.sql.Statement stmt_tGreenplumInput_12 = conn_tGreenplumInput_12.createStatement();

		    String dbquery_tGreenplumInput_12 = "select NEXTVAL('sbdt.edl_run_id_seq')";
			
                log.debug("tGreenplumInput_12 - Executing the query: '"+dbquery_tGreenplumInput_12+"'.");
			

                       globalMap.put("tGreenplumInput_12_QUERY",dbquery_tGreenplumInput_12);

		    java.sql.ResultSet rs_tGreenplumInput_12 = null;
		try{
		    rs_tGreenplumInput_12 = stmt_tGreenplumInput_12.executeQuery(dbquery_tGreenplumInput_12);
		    java.sql.ResultSetMetaData rsmd_tGreenplumInput_12 = rs_tGreenplumInput_12.getMetaData();
		    int colQtyInRs_tGreenplumInput_12 = rsmd_tGreenplumInput_12.getColumnCount();

		    String tmpContent_tGreenplumInput_12 = null;
		    
		    
		    	log.debug("tGreenplumInput_12 - Retrieving records from the database.");
		    
		    while (rs_tGreenplumInput_12.next()) {
		        nb_line_tGreenplumInput_12++;
		        
							if(colQtyInRs_tGreenplumInput_12 < 1) {
								row12.run_id = null;
							} else {
		                          
            if(rs_tGreenplumInput_12.getObject(1) != null) {
                row12.run_id = rs_tGreenplumInput_12.getInt(1);
            } else {
                    row12.run_id = null;
            }
		                    }
					
						log.debug("tGreenplumInput_12 - Retrieving the record " + nb_line_tGreenplumInput_12 + ".");
					


 



/**
 * [tGreenplumInput_12 begin ] stop
 */
	
	/**
	 * [tGreenplumInput_12 main ] start
	 */

	

	
	
	currentComponent="tGreenplumInput_12";

	

 


	tos_count_tGreenplumInput_12++;

/**
 * [tGreenplumInput_12 main ] stop
 */

	
	/**
	 * [tJavaRow_5 main ] start
	 */

	

	
	
	currentComponent="tJavaRow_5";

	

			//row12
			//row12


			
				if(execStat){
					runStat.updateStatOnConnection("row12"+iterateId,1, 1);
				} 
			

		
    			if(log.isTraceEnabled()){
    				log.trace("row12 - " + (row12==null? "": row12.toLogString()));
    			}
    		

    context.LOG_RUN_ID=row12.run_id;
    nb_line_tJavaRow_5++;   

 


	tos_count_tJavaRow_5++;

/**
 * [tJavaRow_5 main ] stop
 */



	
	/**
	 * [tGreenplumInput_12 end ] start
	 */

	

	
	
	currentComponent="tGreenplumInput_12";

	

	}
}finally{
	stmt_tGreenplumInput_12.close();

}
globalMap.put("tGreenplumInput_12_NB_LINE",nb_line_tGreenplumInput_12);
	    		log.debug("tGreenplumInput_12 - Retrieved records count: "+nb_line_tGreenplumInput_12 + " .");
			

 
                if(log.isDebugEnabled())
            log.debug("tGreenplumInput_12 - "  + ("Done.") );

ok_Hash.put("tGreenplumInput_12", true);
end_Hash.put("tGreenplumInput_12", System.currentTimeMillis());




/**
 * [tGreenplumInput_12 end ] stop
 */

	
	/**
	 * [tJavaRow_5 end ] start
	 */

	

	
	
	currentComponent="tJavaRow_5";

	

globalMap.put("tJavaRow_5_NB_LINE",nb_line_tJavaRow_5);
			if(execStat){
				if(resourceMap.get("inIterateVComp") == null || !((Boolean)resourceMap.get("inIterateVComp"))){
			 		runStat.updateStatOnConnection("row12"+iterateId,2, 0); 
			 	}
			}
		
 

ok_Hash.put("tJavaRow_5", true);
end_Hash.put("tJavaRow_5", System.currentTimeMillis());

   			if (true
) {
   				
					if(execStat){   
   	 					runStat.updateStatOnConnection("If9", 0, "true");
					}
				
    			tJava_13Process(globalMap);
   			}

			   
   				else{
					if(execStat){   
   	 					runStat.updateStatOnConnection("If9", 0, "false");
					}   	 
   				}



/**
 * [tJavaRow_5 end ] stop
 */



				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage());
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tGreenplumInput_12 finally ] start
	 */

	

	
	
	currentComponent="tGreenplumInput_12";

	

 



/**
 * [tGreenplumInput_12 finally ] stop
 */

	
	/**
	 * [tJavaRow_5 finally ] start
	 */

	

	
	
	currentComponent="tJavaRow_5";

	

 



/**
 * [tJavaRow_5 finally ] stop
 */



				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tGreenplumInput_12_SUBPROCESS_STATE", 1);
	}
	

public void tJava_13Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tJava_13_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tJava_13 begin ] start
	 */

	

	
		
		ok_Hash.put("tJava_13", false);
		start_Hash.put("tJava_13", System.currentTimeMillis());
		
	
	currentComponent="tJava_13";

	
		int tos_count_tJava_13 = 0;
		
    	class BytesLimit65535_tJava_13{
    		public void limitLog4jByte() throws Exception{
    			
    		}
    	}
    	
        new BytesLimit65535_tJava_13().limitLog4jByte();


String strInsertLogSql = (String)globalMap.get("insert_log_sql");
strInsertLogSql=strInsertLogSql.replace("#RUN_ID", ((Integer)context.LOG_RUN_ID).toString());
globalMap.put("insert_log_sql",strInsertLogSql);

 



/**
 * [tJava_13 begin ] stop
 */
	
	/**
	 * [tJava_13 main ] start
	 */

	

	
	
	currentComponent="tJava_13";

	

 


	tos_count_tJava_13++;

/**
 * [tJava_13 main ] stop
 */
	
	/**
	 * [tJava_13 end ] start
	 */

	

	
	
	currentComponent="tJava_13";

	

 

ok_Hash.put("tJava_13", true);
end_Hash.put("tJava_13", System.currentTimeMillis());




/**
 * [tJava_13 end ] stop
 */
				}//end the resume

				
				    			if(resumeEntryMethodName == null || globalResumeTicket){
				    				resumeUtil.addLog("CHECKPOINT", "CONNECTION:SUBJOB_OK:tJava_13:OnSubjobOk", "", Thread.currentThread().getId() + "", "", "", "", "", "");
								}	    				    			
					    	
								if(execStat){    	
									runStat.updateStatOnConnection("OnSubjobOk31", 0, "ok");
								} 
							
							tGreenplumRow_3Process(globalMap); 
						



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage());
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tJava_13 finally ] start
	 */

	

	
	
	currentComponent="tJava_13";

	

 



/**
 * [tJava_13 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tJava_13_SUBPROCESS_STATE", 1);
	}
	

public void tGreenplumRow_3Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tGreenplumRow_3_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tGreenplumRow_3 begin ] start
	 */

	

	
		
		ok_Hash.put("tGreenplumRow_3", false);
		start_Hash.put("tGreenplumRow_3", System.currentTimeMillis());
		
	
	currentComponent="tGreenplumRow_3";

	
		int tos_count_tGreenplumRow_3 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tGreenplumRow_3 - "  + ("Start to work.") );
    	class BytesLimit65535_tGreenplumRow_3{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tGreenplumRow_3 = new StringBuilder();
            log4jParamters_tGreenplumRow_3.append("Parameters:");
                    log4jParamters_tGreenplumRow_3.append("USE_EXISTING_CONNECTION" + " = " + "true");
                log4jParamters_tGreenplumRow_3.append(" | ");
                    log4jParamters_tGreenplumRow_3.append("CONNECTION" + " = " + "tGreenplumConnection_7");
                log4jParamters_tGreenplumRow_3.append(" | ");
                    log4jParamters_tGreenplumRow_3.append("QUERYSTORE" + " = " + "\"\"");
                log4jParamters_tGreenplumRow_3.append(" | ");
                    log4jParamters_tGreenplumRow_3.append("QUERY" + " = " + "(String)globalMap.get(\"insert_log_sql\")");
                log4jParamters_tGreenplumRow_3.append(" | ");
                    log4jParamters_tGreenplumRow_3.append("DIE_ON_ERROR" + " = " + "true");
                log4jParamters_tGreenplumRow_3.append(" | ");
                    log4jParamters_tGreenplumRow_3.append("PROPAGATE_RECORD_SET" + " = " + "false");
                log4jParamters_tGreenplumRow_3.append(" | ");
                    log4jParamters_tGreenplumRow_3.append("USE_PREPAREDSTATEMENT" + " = " + "false");
                log4jParamters_tGreenplumRow_3.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tGreenplumRow_3 - "  + (log4jParamters_tGreenplumRow_3) );
    		}
    	}
    	
        new BytesLimit65535_tGreenplumRow_3().limitLog4jByte();

	java.sql.Connection conn_tGreenplumRow_3 = null;
	String query_tGreenplumRow_3 = "";
	boolean whetherReject_tGreenplumRow_3 = false;
				conn_tGreenplumRow_3 = (java.sql.Connection)globalMap.get("conn_tGreenplumConnection_7");
			
				if(conn_tGreenplumRow_3 != null) {
					if(conn_tGreenplumRow_3.getMetaData() != null) {
						
						log.debug("tGreenplumRow_3 - Uses an existing connection with username '" + conn_tGreenplumRow_3.getMetaData().getUserName() + "'. Connection URL: " + conn_tGreenplumRow_3.getMetaData().getURL() + ".");
						
					}
				}
			
		java.sql.Statement stmt_tGreenplumRow_3 = conn_tGreenplumRow_3.createStatement();
	

 



/**
 * [tGreenplumRow_3 begin ] stop
 */
	
	/**
	 * [tGreenplumRow_3 main ] start
	 */

	

	
	
	currentComponent="tGreenplumRow_3";

	

	    		log.debug("tGreenplumRow_3 - Executing the query: '" + (String)globalMap.get("insert_log_sql") + "'.");
			
query_tGreenplumRow_3 = (String)globalMap.get("insert_log_sql");
whetherReject_tGreenplumRow_3 = false;
globalMap.put("tGreenplumRow_3_QUERY",query_tGreenplumRow_3);
try {
		stmt_tGreenplumRow_3.execute(query_tGreenplumRow_3);
		
	    		log.info("tGreenplumRow_3 - Execute the query: '" + (String)globalMap.get("insert_log_sql") + "' has finished.");
			
	} catch (java.lang.Exception e) {
		whetherReject_tGreenplumRow_3 = true;
		
			throw(e);
			
	}
	
	if(!whetherReject_tGreenplumRow_3) {
		
	}
	

 


	tos_count_tGreenplumRow_3++;

/**
 * [tGreenplumRow_3 main ] stop
 */
	
	/**
	 * [tGreenplumRow_3 end ] start
	 */

	

	
	
	currentComponent="tGreenplumRow_3";

	

	
	stmt_tGreenplumRow_3.close();	

 
                if(log.isDebugEnabled())
            log.debug("tGreenplumRow_3 - "  + ("Done.") );

ok_Hash.put("tGreenplumRow_3", true);
end_Hash.put("tGreenplumRow_3", System.currentTimeMillis());




/**
 * [tGreenplumRow_3 end ] stop
 */
				}//end the resume

				
				    			if(resumeEntryMethodName == null || globalResumeTicket){
				    				resumeUtil.addLog("CHECKPOINT", "CONNECTION:SUBJOB_OK:tGreenplumRow_3:OnSubjobOk", "", Thread.currentThread().getId() + "", "", "", "", "", "");
								}	    				    			
					    	
								if(execStat){    	
									runStat.updateStatOnConnection("OnSubjobOk32", 0, "ok");
								} 
							
							tGreenplumClose_4Process(globalMap); 
						



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage());
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tGreenplumRow_3 finally ] start
	 */

	

	
	
	currentComponent="tGreenplumRow_3";

	

 



/**
 * [tGreenplumRow_3 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tGreenplumRow_3_SUBPROCESS_STATE", 1);
	}
	

public void tGreenplumClose_4Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tGreenplumClose_4_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tGreenplumClose_4 begin ] start
	 */

	

	
		
		ok_Hash.put("tGreenplumClose_4", false);
		start_Hash.put("tGreenplumClose_4", System.currentTimeMillis());
		
	
	currentComponent="tGreenplumClose_4";

	
		int tos_count_tGreenplumClose_4 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tGreenplumClose_4 - "  + ("Start to work.") );
    	class BytesLimit65535_tGreenplumClose_4{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tGreenplumClose_4 = new StringBuilder();
            log4jParamters_tGreenplumClose_4.append("Parameters:");
                    log4jParamters_tGreenplumClose_4.append("CONNECTION" + " = " + "tGreenplumConnection_7");
                log4jParamters_tGreenplumClose_4.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tGreenplumClose_4 - "  + (log4jParamters_tGreenplumClose_4) );
    		}
    	}
    	
        new BytesLimit65535_tGreenplumClose_4().limitLog4jByte();

 



/**
 * [tGreenplumClose_4 begin ] stop
 */
	
	/**
	 * [tGreenplumClose_4 main ] start
	 */

	

	
	
	currentComponent="tGreenplumClose_4";

	



	java.sql.Connection conn_tGreenplumClose_4 = (java.sql.Connection)globalMap.get("conn_tGreenplumConnection_7");
	if(conn_tGreenplumClose_4 != null && !conn_tGreenplumClose_4.isClosed())
	{
                if(log.isDebugEnabled())
            log.debug("tGreenplumClose_4 - "  + ("Closing the connection ")  + ("conn_tGreenplumConnection_7")  + (" to the database.") );
        conn_tGreenplumClose_4.close();
                if(log.isDebugEnabled())
            log.debug("tGreenplumClose_4 - "  + ("Connection ")  + ("conn_tGreenplumConnection_7")  + (" to the database has closed.") );
	}

 


	tos_count_tGreenplumClose_4++;

/**
 * [tGreenplumClose_4 main ] stop
 */
	
	/**
	 * [tGreenplumClose_4 end ] start
	 */

	

	
	
	currentComponent="tGreenplumClose_4";

	

 
                if(log.isDebugEnabled())
            log.debug("tGreenplumClose_4 - "  + ("Done.") );

ok_Hash.put("tGreenplumClose_4", true);
end_Hash.put("tGreenplumClose_4", System.currentTimeMillis());




/**
 * [tGreenplumClose_4 end ] stop
 */
				}//end the resume

				
				    			if(resumeEntryMethodName == null || globalResumeTicket){
				    				resumeUtil.addLog("CHECKPOINT", "CONNECTION:SUBJOB_OK:tGreenplumClose_4:OnSubjobOk", "", Thread.currentThread().getId() + "", "", "", "", "", "");
								}	    				    			
					    	
								if(execStat){    	
									runStat.updateStatOnConnection("OnSubjobOk36", 0, "ok");
								} 
							
							tJava_15Process(globalMap); 
						



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage());
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tGreenplumClose_4 finally ] start
	 */

	

	
	
	currentComponent="tGreenplumClose_4";

	

 



/**
 * [tGreenplumClose_4 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tGreenplumClose_4_SUBPROCESS_STATE", 1);
	}
	

public void tJava_15Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tJava_15_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tJava_15 begin ] start
	 */

	

	
		
		ok_Hash.put("tJava_15", false);
		start_Hash.put("tJava_15", System.currentTimeMillis());
		
	
	currentComponent="tJava_15";

	
		int tos_count_tJava_15 = 0;
		
    	class BytesLimit65535_tJava_15{
    		public void limitLog4jByte() throws Exception{
    			
    		}
    	}
    	
        new BytesLimit65535_tJava_15().limitLog4jByte();


String foo = "bar";
 



/**
 * [tJava_15 begin ] stop
 */
	
	/**
	 * [tJava_15 main ] start
	 */

	

	
	
	currentComponent="tJava_15";

	

 


	tos_count_tJava_15++;

/**
 * [tJava_15 main ] stop
 */
	
	/**
	 * [tJava_15 end ] start
	 */

	

	
	
	currentComponent="tJava_15";

	

 

ok_Hash.put("tJava_15", true);
end_Hash.put("tJava_15", System.currentTimeMillis());

   			if (context.getProperty("SEND_MAIL").equals("Y")) {
   				
					if(execStat){   
   	 					runStat.updateStatOnConnection("If11", 0, "true");
					}
				
    			tRunJob_3Process(globalMap);
   			}

			   
   				else{
					if(execStat){   
   	 					runStat.updateStatOnConnection("If11", 0, "false");
					}   	 
   				}



/**
 * [tJava_15 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage());
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tJava_15 finally ] start
	 */

	

	
	
	currentComponent="tJava_15";

	

 



/**
 * [tJava_15 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tJava_15_SUBPROCESS_STATE", 1);
	}
	

public void tRunJob_3Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tRunJob_3_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;





	
	/**
	 * [tRunJob_3 begin ] start
	 */

	

	
		
		ok_Hash.put("tRunJob_3", false);
		start_Hash.put("tRunJob_3", System.currentTimeMillis());
		
	
	currentComponent="tRunJob_3";

	
		int tos_count_tRunJob_3 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tRunJob_3 - "  + ("Start to work.") );
    	class BytesLimit65535_tRunJob_3{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tRunJob_3 = new StringBuilder();
            log4jParamters_tRunJob_3.append("Parameters:");
                    log4jParamters_tRunJob_3.append("USE_DYNAMIC_JOB" + " = " + "false");
                log4jParamters_tRunJob_3.append(" | ");
                    log4jParamters_tRunJob_3.append("PROCESS" + " = " + "EDL_Get_Execution_Statistics_prd2dev_GP");
                log4jParamters_tRunJob_3.append(" | ");
                    log4jParamters_tRunJob_3.append("USE_INDEPENDENT_PROCESS" + " = " + "false");
                log4jParamters_tRunJob_3.append(" | ");
                    log4jParamters_tRunJob_3.append("DIE_ON_CHILD_ERROR" + " = " + "false");
                log4jParamters_tRunJob_3.append(" | ");
                    log4jParamters_tRunJob_3.append("TRANSMIT_WHOLE_CONTEXT" + " = " + "true");
                log4jParamters_tRunJob_3.append(" | ");
                    log4jParamters_tRunJob_3.append("CONTEXTPARAMS" + " = " + "[{PARAM_NAME_COLUMN="+("RUN_ID")+", PARAM_VALUE_COLUMN="+("globalMap.get(\"BASE_RUN_ID\") ")+"}, {PARAM_NAME_COLUMN="+("MAIL_TO")+", PARAM_VALUE_COLUMN="+("context.MAIL_TO")+"}, {PARAM_NAME_COLUMN="+("JOB_LABEL_NAME")+", PARAM_VALUE_COLUMN="+("((String)globalMap.get(\"jobname_prefix\"))+context.LOG_JOB_NAME")+"}]");
                log4jParamters_tRunJob_3.append(" | ");
                    log4jParamters_tRunJob_3.append("PROPAGATE_CHILD_RESULT" + " = " + "false");
                log4jParamters_tRunJob_3.append(" | ");
                    log4jParamters_tRunJob_3.append("PRINT_PARAMETER" + " = " + "false");
                log4jParamters_tRunJob_3.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tRunJob_3 - "  + (log4jParamters_tRunJob_3) );
    		}
    	}
    	
        new BytesLimit65535_tRunJob_3().limitLog4jByte();


 



/**
 * [tRunJob_3 begin ] stop
 */
	
	/**
	 * [tRunJob_3 main ] start
	 */

	

	
	
	currentComponent="tRunJob_3";

	
	java.util.List<String> paraList_tRunJob_3 = new java.util.ArrayList<String>();
	
	        			paraList_tRunJob_3.add("--father_pid="+pid);
	      			
	        			paraList_tRunJob_3.add("--root_pid="+rootPid);
	      			
	        			paraList_tRunJob_3.add("--father_node=tRunJob_3");
	      			
	        			paraList_tRunJob_3.add("--context=SOURCING_PROD");
	      			
			if(!"".equals(log4jLevel)){
				paraList_tRunJob_3.add("--log4jLevel="+log4jLevel);
			}
		
	//for feature:10589
	
		paraList_tRunJob_3.add("--stat_port=" + portStats);
	

	if(resuming_logs_dir_path != null){
		paraList_tRunJob_3.add("--resuming_logs_dir_path=" + resuming_logs_dir_path);
	}
	String childResumePath_tRunJob_3 = ResumeUtil.getChildJobCheckPointPath(resuming_checkpoint_path);
	String tRunJobName_tRunJob_3 = ResumeUtil.getRighttRunJob(resuming_checkpoint_path);
	if("tRunJob_3".equals(tRunJobName_tRunJob_3) && childResumePath_tRunJob_3 != null){
		paraList_tRunJob_3.add("--resuming_checkpoint_path=" + ResumeUtil.getChildJobCheckPointPath(resuming_checkpoint_path));
	}
	paraList_tRunJob_3.add("--parent_part_launcher=JOB:" + jobName + "/NODE:tRunJob_3");
	
	java.util.Map<String, Object> parentContextMap_tRunJob_3 = new java.util.HashMap<String, Object>();

	
		
		context.synchronizeContext();
		
			parentContextMap_tRunJob_3.put("GP_SOURCE_NAME", context.GP_SOURCE_NAME);
		
			parentContextMap_tRunJob_3.put("TABLE_NAME", context.TABLE_NAME);
		
			parentContextMap_tRunJob_3.put("FORCE_DROP", context.FORCE_DROP);
		
			parentContextMap_tRunJob_3.put("LOAD2HDFS", context.LOAD2HDFS);
		
			parentContextMap_tRunJob_3.put("RUN_ID", context.RUN_ID);
		
			parentContextMap_tRunJob_3.put("ORIG_DATABASE_NAME", context.ORIG_DATABASE_NAME);
		
			parentContextMap_tRunJob_3.put("FDIST_PARAM", context.FDIST_PARAM);
		
			parentContextMap_tRunJob_3.put("LOG_NO_OF_ERRORS", context.LOG_NO_OF_ERRORS);
		
			parentContextMap_tRunJob_3.put("LOG_PLANT_NAME", context.LOG_PLANT_NAME);
		
			parentContextMap_tRunJob_3.put("LOG_NO_OF_UPDATES", context.LOG_NO_OF_UPDATES);
		
			parentContextMap_tRunJob_3.put("LOG_SOURCE_ROW_COUNT", context.LOG_SOURCE_ROW_COUNT);
		
			parentContextMap_tRunJob_3.put("LOG_TECHNOLOGY", context.LOG_TECHNOLOGY);
		
			parentContextMap_tRunJob_3.put("LOG_TABLE_NAME", context.LOG_TABLE_NAME);
		
			parentContextMap_tRunJob_3.put("LOG_NO_OF_INSERTS", context.LOG_NO_OF_INSERTS);
		
			parentContextMap_tRunJob_3.put("LOG_DATA_PATH", context.LOG_DATA_PATH);
		
			parentContextMap_tRunJob_3.put("LOG_NO_OF_DELETES", context.LOG_NO_OF_DELETES);
		
			parentContextMap_tRunJob_3.put("LOG_RUN_ID", context.LOG_RUN_ID);
		
			parentContextMap_tRunJob_3.put("LOG_ERROR_CATEGORY", context.LOG_ERROR_CATEGORY);
		
			parentContextMap_tRunJob_3.put("LOG_JOB_NAME", context.LOG_JOB_NAME);
		
			parentContextMap_tRunJob_3.put("LOG_SYSTEM_NAME", context.LOG_SYSTEM_NAME);
		
			parentContextMap_tRunJob_3.put("LOG_MESSAGE", context.LOG_MESSAGE);
		
			parentContextMap_tRunJob_3.put("LOG_TARGET_ROW_COUNT", context.LOG_TARGET_ROW_COUNT);
		
			parentContextMap_tRunJob_3.put("LOG_STATUS", context.LOG_STATUS);
		
			parentContextMap_tRunJob_3.put("JOB_LABEL_NAME", context.JOB_LABEL_NAME);
		
			parentContextMap_tRunJob_3.put("PLANT_NAME", context.PLANT_NAME);
		
			parentContextMap_tRunJob_3.put("SEND_MAIL", context.SEND_MAIL);
		
			parentContextMap_tRunJob_3.put("MAIL_TO", context.MAIL_TO);
		
			parentContextMap_tRunJob_3.put("PUBLIC", context.PUBLIC);
		
			parentContextMap_tRunJob_3.put("THREAD", context.THREAD);
		
			parentContextMap_tRunJob_3.put("ETL_LOCALHOSTNAME", context.ETL_LOCALHOSTNAME);
		
			parentContextMap_tRunJob_3.put("ETL_STORAGE_PATH", context.ETL_STORAGE_PATH);
		
			parentContextMap_tRunJob_3.put("HAWQ_Source_Ports", context.HAWQ_Source_Ports);
		
			parentContextMap_tRunJob_3.put("SOURCE_DATABASE", context.SOURCE_DATABASE);
		
			parentContextMap_tRunJob_3.put("SOURCE_HOST", context.SOURCE_HOST);
		
			parentContextMap_tRunJob_3.put("SOURCE_PASSWORD", context.SOURCE_PASSWORD);
		
			parentContextMap_tRunJob_3.put("SOURCE_PORT", context.SOURCE_PORT);
		
			parentContextMap_tRunJob_3.put("SOURCE_USER", context.SOURCE_USER);
		
			parentContextMap_tRunJob_3.put("SOURCING_Database", context.SOURCING_Database);
		
			parentContextMap_tRunJob_3.put("SOURCING_Login", context.SOURCING_Login);
		
			parentContextMap_tRunJob_3.put("SOURCING_Password", context.SOURCING_Password);
		
			parentContextMap_tRunJob_3.put("SOURCING_Port", context.SOURCING_Port);
		
			parentContextMap_tRunJob_3.put("SOURCING_Schema", context.SOURCING_Schema);
		
			parentContextMap_tRunJob_3.put("SOURCING_Server", context.SOURCING_Server);
		 
		java.util.Enumeration<?> propertyNames_tRunJob_3 = context.propertyNames();
		while (propertyNames_tRunJob_3.hasMoreElements()) {
			String key_tRunJob_3 = (String) propertyNames_tRunJob_3.nextElement();
			Object value_tRunJob_3 = (Object) context.get(key_tRunJob_3);       
			paraList_tRunJob_3.add("--context_param " + key_tRunJob_3 + "=" + value_tRunJob_3);
			
		}
		

	Object obj_tRunJob_3 = null;

	
		obj_tRunJob_3 = globalMap.get("BASE_RUN_ID") ;
		paraList_tRunJob_3.add("--context_param RUN_ID=" + RuntimeUtils.tRunJobConvertContext(obj_tRunJob_3));
		
		parentContextMap_tRunJob_3.put("RUN_ID", obj_tRunJob_3);
	
		obj_tRunJob_3 = context.MAIL_TO;
		paraList_tRunJob_3.add("--context_param MAIL_TO=" + RuntimeUtils.tRunJobConvertContext(obj_tRunJob_3));
		
		parentContextMap_tRunJob_3.put("MAIL_TO", obj_tRunJob_3);
	
		obj_tRunJob_3 = ((String)globalMap.get("jobname_prefix"))+context.LOG_JOB_NAME;
		paraList_tRunJob_3.add("--context_param JOB_LABEL_NAME=" + RuntimeUtils.tRunJobConvertContext(obj_tRunJob_3));
		
		parentContextMap_tRunJob_3.put("JOB_LABEL_NAME", obj_tRunJob_3);
	
	
		aws_dev_talend_ingestion_framework.edl_get_execution_statistics_prd2dev_gp_0_1.EDL_Get_Execution_Statistics_prd2dev_GP childJob_tRunJob_3 = new aws_dev_talend_ingestion_framework.edl_get_execution_statistics_prd2dev_gp_0_1.EDL_Get_Execution_Statistics_prd2dev_GP();
	    // pass DataSources
	    java.util.Map<String, routines.system.TalendDataSource> talendDataSources_tRunJob_3 = (java.util.Map<String, routines.system.TalendDataSource>) globalMap
	            .get(KEY_DB_DATASOURCES);
	    if (null != talendDataSources_tRunJob_3) {
	        java.util.Map<String, javax.sql.DataSource> dataSources_tRunJob_3 = new java.util.HashMap<String, javax.sql.DataSource>();
	        for (java.util.Map.Entry<String, routines.system.TalendDataSource> talendDataSourceEntry_tRunJob_3 : talendDataSources_tRunJob_3
			        .entrySet()) {
	            dataSources_tRunJob_3.put(talendDataSourceEntry_tRunJob_3.getKey(),
	                    talendDataSourceEntry_tRunJob_3.getValue().getRawDataSource());
	        }
	        childJob_tRunJob_3.setDataSources(dataSources_tRunJob_3);
	    }
		  
			childJob_tRunJob_3.parentContextMap = parentContextMap_tRunJob_3;
		  
		
			log.info("tRunJob_3 - The child job 'aws_dev_talend_ingestion_framework.edl_get_execution_statistics_prd2dev_gp_0_1.EDL_Get_Execution_Statistics_prd2dev_GP' starts on the version '0.1' with the context 'SOURCING_PROD'.");
		
		String[][] childReturn_tRunJob_3 = childJob_tRunJob_3.runJob((String[]) paraList_tRunJob_3.toArray(new String[paraList_tRunJob_3.size()]));
		
			log.info("tRunJob_3 - The child job 'aws_dev_talend_ingestion_framework.edl_get_execution_statistics_prd2dev_gp_0_1.EDL_Get_Execution_Statistics_prd2dev_GP' is done.");
		
	  	
				((java.util.Map)threadLocal.get()).put("errorCode", childJob_tRunJob_3.getErrorCode());
			
	            
	    	if(childJob_tRunJob_3.getErrorCode() == null){
				globalMap.put("tRunJob_3_CHILD_RETURN_CODE", childJob_tRunJob_3.getStatus() != null && ("failure").equals(childJob_tRunJob_3.getStatus()) ? 1 : 0);
	    	}else{
				globalMap.put("tRunJob_3_CHILD_RETURN_CODE", childJob_tRunJob_3.getErrorCode());
		    }
		    if (childJob_tRunJob_3.getExceptionStackTrace() != null) { 
		    	globalMap.put("tRunJob_3_CHILD_EXCEPTION_STACKTRACE", childJob_tRunJob_3.getExceptionStackTrace());
		    }
	  
			
	  	

 


	tos_count_tRunJob_3++;

/**
 * [tRunJob_3 main ] stop
 */
	
	/**
	 * [tRunJob_3 end ] start
	 */

	

	
	
	currentComponent="tRunJob_3";

	

 
                if(log.isDebugEnabled())
            log.debug("tRunJob_3 - "  + ("Done.") );

ok_Hash.put("tRunJob_3", true);
end_Hash.put("tRunJob_3", System.currentTimeMillis());




/**
 * [tRunJob_3 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage());
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tRunJob_3 finally ] start
	 */

	

	
	
	currentComponent="tRunJob_3";

	

 



/**
 * [tRunJob_3 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tRunJob_3_SUBPROCESS_STATE", 1);
	}
	

public void tJava_9Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tJava_9_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tJava_9 begin ] start
	 */

	

	
		
		ok_Hash.put("tJava_9", false);
		start_Hash.put("tJava_9", System.currentTimeMillis());
		
	
	currentComponent="tJava_9";

	
		int tos_count_tJava_9 = 0;
		
    	class BytesLimit65535_tJava_9{
    		public void limitLog4jByte() throws Exception{
    			
    		}
    	}
    	
        new BytesLimit65535_tJava_9().limitLog4jByte();


//context.LOG_PLANT_NAME="NULL";
//context.LOG_SYSTEM_NAME="NULL";
//context.LOG_TABLE_NAME="NULL";
//context.LOG_JOB_NAME="NULL";
//context.LOG_DATA_PATH="NULL";
//context.LOG_TECHNOLOGY="NULL";
context.LOG_STATUS="Finish";
context.LOG_MESSAGE="NULL";
context.LOG_ERROR_CATEGORY="NULL";
context.LOG_NO_OF_INSERTS=0;
context.LOG_NO_OF_UPDATES=0;
context.LOG_NO_OF_DELETES=0;
context.LOG_NO_OF_ERRORS=0;
context.LOG_SOURCE_ROW_COUNT=0;
context.LOG_TARGET_ROW_COUNT=0;

 



/**
 * [tJava_9 begin ] stop
 */
	
	/**
	 * [tJava_9 main ] start
	 */

	

	
	
	currentComponent="tJava_9";

	

 


	tos_count_tJava_9++;

/**
 * [tJava_9 main ] stop
 */
	
	/**
	 * [tJava_9 end ] start
	 */

	

	
	
	currentComponent="tJava_9";

	

 

ok_Hash.put("tJava_9", true);
end_Hash.put("tJava_9", System.currentTimeMillis());




/**
 * [tJava_9 end ] stop
 */
				}//end the resume

				
				    			if(resumeEntryMethodName == null || globalResumeTicket){
				    				resumeUtil.addLog("CHECKPOINT", "CONNECTION:SUBJOB_OK:tJava_9:OnSubjobOk", "", Thread.currentThread().getId() + "", "", "", "", "", "");
								}	    				    			
					    	
								if(execStat){    	
									runStat.updateStatOnConnection("OnSubjobOk26", 0, "ok");
								} 
							
							tJava_12Process(globalMap); 
						



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage());
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tJava_9 finally ] start
	 */

	

	
	
	currentComponent="tJava_9";

	

 



/**
 * [tJava_9 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tJava_9_SUBPROCESS_STATE", 1);
	}
	

public void tJava_12Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tJava_12_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tJava_12 begin ] start
	 */

	

	
		
		ok_Hash.put("tJava_12", false);
		start_Hash.put("tJava_12", System.currentTimeMillis());
		
	
	currentComponent="tJava_12";

	
		int tos_count_tJava_12 = 0;
		
    	class BytesLimit65535_tJava_12{
    		public void limitLog4jByte() throws Exception{
    			
    		}
    	}
    	
        new BytesLimit65535_tJava_12().limitLog4jByte();



String strInsertLogSql=(String)globalMap.get("insert_log_template");
strInsertLogSql=strInsertLogSql.replace("#RUN_ID", ((Integer)context.LOG_RUN_ID).toString());
strInsertLogSql=strInsertLogSql.replace("#PLANT_NAME", "'"+context.LOG_PLANT_NAME+"'");
strInsertLogSql=strInsertLogSql.replace("#SYSTEM_NAME", "'"+context.LOG_SYSTEM_NAME+"'");
strInsertLogSql=strInsertLogSql.replace("#JOB_NAME", "'"+((String)globalMap.get("jobname_prefix"))+context.LOG_JOB_NAME+"'");
strInsertLogSql=strInsertLogSql.replace("#TABLE_NAME", "'"+(String)globalMap.get("orig_table_name")+"'");
strInsertLogSql=strInsertLogSql.replace("#STATUS", "'"+context.LOG_STATUS+"'");
strInsertLogSql=strInsertLogSql.replace("#DATA_PATH", "'"+context.LOG_DATA_PATH+"'");
strInsertLogSql=strInsertLogSql.replace("#TECHNOLOGY", "'"+context.LOG_TECHNOLOGY+"'");
strInsertLogSql=strInsertLogSql.replace("#NO_OF_INSERTS", ((Integer)context.LOG_NO_OF_INSERTS).toString());
strInsertLogSql=strInsertLogSql.replace("#NO_OF_UPDATES", ((Integer)context.LOG_NO_OF_UPDATES).toString());
strInsertLogSql=strInsertLogSql.replace("#NO_OF_DELETES", ((Integer)context.LOG_NO_OF_DELETES).toString());
strInsertLogSql=strInsertLogSql.replace("#NO_OF_ERRORS", ((Integer)context.LOG_NO_OF_ERRORS).toString());
strInsertLogSql=strInsertLogSql.replace("#MESSAGE", "'"+context.LOG_MESSAGE+"'");
strInsertLogSql=strInsertLogSql.replace("#SOURCE_ROW_COUNT", ((Integer)context.LOG_SOURCE_ROW_COUNT).toString());
strInsertLogSql=strInsertLogSql.replace("#TARGET_ROW_COUNT", ((Integer)context.LOG_TARGET_ROW_COUNT).toString());
strInsertLogSql=strInsertLogSql.replace("#ERROR_CATEGORY", "'"+context.LOG_ERROR_CATEGORY+"'");
globalMap.put("insert_log_sql",strInsertLogSql);
//System.out.println(globalMap.get("insert_log_sql"));
//System.out.println("==============================");
//System.out.println("==============================");
//globalMap.put("now",new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(TalendDate.getCurrentDate()).toString());
//System.out.println(globalMap.get("now"));
//globalMap.put("now_sql","TO_TIMESTAMP('" + ((String)globalMap.get("now")) + "', 'YYYY-MM-DD HH24:MI:SS')::TIMESTAMP WITH TIME ZONE ");
//System.out.println(globalMap.get("now_sql"));
//if (context.LOG_PLANT_NAME.equals("NULL")==true) {
//  context.LOG_PLANT_NAME="Grove City";
//};
//if (context.LOG_APPLICATION.equals("NULL")==true) {
//  context.LOG_APPLICATION="GET-ABM";
//};
 



/**
 * [tJava_12 begin ] stop
 */
	
	/**
	 * [tJava_12 main ] start
	 */

	

	
	
	currentComponent="tJava_12";

	

 


	tos_count_tJava_12++;

/**
 * [tJava_12 main ] stop
 */
	
	/**
	 * [tJava_12 end ] start
	 */

	

	
	
	currentComponent="tJava_12";

	

 

ok_Hash.put("tJava_12", true);
end_Hash.put("tJava_12", System.currentTimeMillis());

				if(execStat){   
   	 				runStat.updateStatOnConnection("OnComponentOk5", 0, "ok");
				}
				tGreenplumConnection_7Process(globalMap);



/**
 * [tJava_12 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage());
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tJava_12 finally ] start
	 */

	

	
	
	currentComponent="tJava_12";

	

 



/**
 * [tJava_12 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tJava_12_SUBPROCESS_STATE", 1);
	}
	

public void tGreenplumConnection_8Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tGreenplumConnection_8_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tGreenplumConnection_8 begin ] start
	 */

	

	
		
		ok_Hash.put("tGreenplumConnection_8", false);
		start_Hash.put("tGreenplumConnection_8", System.currentTimeMillis());
		
	
	currentComponent="tGreenplumConnection_8";

	
		int tos_count_tGreenplumConnection_8 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tGreenplumConnection_8 - "  + ("Start to work.") );
    	class BytesLimit65535_tGreenplumConnection_8{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tGreenplumConnection_8 = new StringBuilder();
            log4jParamters_tGreenplumConnection_8.append("Parameters:");
                    log4jParamters_tGreenplumConnection_8.append("HOST" + " = " + "context.SOURCING_Server");
                log4jParamters_tGreenplumConnection_8.append(" | ");
                    log4jParamters_tGreenplumConnection_8.append("PORT" + " = " + "context.SOURCING_Port");
                log4jParamters_tGreenplumConnection_8.append(" | ");
                    log4jParamters_tGreenplumConnection_8.append("DBNAME" + " = " + "context.SOURCING_Database");
                log4jParamters_tGreenplumConnection_8.append(" | ");
                    log4jParamters_tGreenplumConnection_8.append("SCHEMA_DB" + " = " + "context.SOURCING_Schema");
                log4jParamters_tGreenplumConnection_8.append(" | ");
                    log4jParamters_tGreenplumConnection_8.append("USER" + " = " + "context.SOURCING_Login");
                log4jParamters_tGreenplumConnection_8.append(" | ");
                    log4jParamters_tGreenplumConnection_8.append("PASS" + " = " + String.valueOf(routines.system.PasswordEncryptUtil.encryptPassword(context.SOURCING_Password)).substring(0, 4) + "...");     
                log4jParamters_tGreenplumConnection_8.append(" | ");
                    log4jParamters_tGreenplumConnection_8.append("USE_SHARED_CONNECTION" + " = " + "true");
                log4jParamters_tGreenplumConnection_8.append(" | ");
                    log4jParamters_tGreenplumConnection_8.append("SHARED_CONNECTION_NAME" + " = " + "\"base_dynamic\"+((String)globalMap.get(\"timestamp\"))");
                log4jParamters_tGreenplumConnection_8.append(" | ");
                    log4jParamters_tGreenplumConnection_8.append("USE_SSL" + " = " + "true");
                log4jParamters_tGreenplumConnection_8.append(" | ");
                    log4jParamters_tGreenplumConnection_8.append("AUTO_COMMIT" + " = " + "true");
                log4jParamters_tGreenplumConnection_8.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tGreenplumConnection_8 - "  + (log4jParamters_tGreenplumConnection_8) );
    		}
    	}
    	
        new BytesLimit65535_tGreenplumConnection_8().limitLog4jByte();
	

	
				String url_tGreenplumConnection_8 = "jdbc:postgresql://"+context.SOURCING_Server+":"+context.SOURCING_Port+"/"+context.SOURCING_Database+"?ssl=true&sslfactory=org.postgresql.ssl.NonValidatingFactory";

	String dbUser_tGreenplumConnection_8 = context.SOURCING_Login;
	
	
		
	final String decryptedPassword_tGreenplumConnection_8 = context.SOURCING_Password; 
		String dbPwd_tGreenplumConnection_8 = decryptedPassword_tGreenplumConnection_8;
	

	java.sql.Connection conn_tGreenplumConnection_8 = null;
	
	
			SharedDBConnectionLog4j.initLogger(log,"tGreenplumConnection_8");
			String sharedConnectionName_tGreenplumConnection_8 = "base_dynamic"+((String)globalMap.get("timestamp"));
			conn_tGreenplumConnection_8 = SharedDBConnectionLog4j.getDBConnection("org.postgresql.Driver",url_tGreenplumConnection_8,dbUser_tGreenplumConnection_8 , dbPwd_tGreenplumConnection_8 , sharedConnectionName_tGreenplumConnection_8);
	if (null != conn_tGreenplumConnection_8) {
		
			log.debug("tGreenplumConnection_8 - Connection is set auto commit to 'true'.");
			conn_tGreenplumConnection_8.setAutoCommit(true);
	}

	globalMap.put("schema_" + "tGreenplumConnection_8",context.SOURCING_Schema);

	globalMap.put("conn_" + "tGreenplumConnection_8",conn_tGreenplumConnection_8);
 



/**
 * [tGreenplumConnection_8 begin ] stop
 */
	
	/**
	 * [tGreenplumConnection_8 main ] start
	 */

	

	
	
	currentComponent="tGreenplumConnection_8";

	

 


	tos_count_tGreenplumConnection_8++;

/**
 * [tGreenplumConnection_8 main ] stop
 */
	
	/**
	 * [tGreenplumConnection_8 end ] start
	 */

	

	
	
	currentComponent="tGreenplumConnection_8";

	

 
                if(log.isDebugEnabled())
            log.debug("tGreenplumConnection_8 - "  + ("Done.") );

ok_Hash.put("tGreenplumConnection_8", true);
end_Hash.put("tGreenplumConnection_8", System.currentTimeMillis());




/**
 * [tGreenplumConnection_8 end ] stop
 */
				}//end the resume

				
				    			if(resumeEntryMethodName == null || globalResumeTicket){
				    				resumeUtil.addLog("CHECKPOINT", "CONNECTION:SUBJOB_OK:tGreenplumConnection_8:OnSubjobOk", "", Thread.currentThread().getId() + "", "", "", "", "", "");
								}	    				    			
					    	
								if(execStat){    	
									runStat.updateStatOnConnection("OnSubjobOk38", 0, "ok");
								} 
							
							tGreenplumInput_13Process(globalMap); 
						



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage());
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tGreenplumConnection_8 finally ] start
	 */

	

	
	
	currentComponent="tGreenplumConnection_8";

	

 



/**
 * [tGreenplumConnection_8 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tGreenplumConnection_8_SUBPROCESS_STATE", 1);
	}
	


public static class row16Struct implements routines.system.IPersistableRow<row16Struct> {
    final static byte[] commonByteArrayLock_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Prod2Dev_with_GP_FDIST = new byte[0];
    static byte[] commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Prod2Dev_with_GP_FDIST = new byte[0];

	
			    public String target_schema_priv;

				public String getTarget_schema_priv () {
					return this.target_schema_priv;
				}
				



	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Prod2Dev_with_GP_FDIST.length) {
				if(length < 1024 && commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Prod2Dev_with_GP_FDIST.length == 0) {
   					commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Prod2Dev_with_GP_FDIST = new byte[1024];
				} else {
   					commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Prod2Dev_with_GP_FDIST = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Prod2Dev_with_GP_FDIST, 0, length);
			strReturn = new String(commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Prod2Dev_with_GP_FDIST, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Prod2Dev_with_GP_FDIST) {

        	try {

        		int length = 0;
		
					this.target_schema_priv = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// String
				
						writeString(this.target_schema_priv,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("target_schema_priv="+target_schema_priv);
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				if(target_schema_priv == null){
        					sb.append("<null>");
        				}else{
            				sb.append(target_schema_priv);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(row16Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}
public void tGreenplumInput_13Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tGreenplumInput_13_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;



		row16Struct row16 = new row16Struct();




	
	/**
	 * [tFlowToIterate_3 begin ] start
	 */

				
			int NB_ITERATE_tGreenplumRow_4 = 0; //for statistics
			

	
		
		ok_Hash.put("tFlowToIterate_3", false);
		start_Hash.put("tFlowToIterate_3", System.currentTimeMillis());
		
	
	currentComponent="tFlowToIterate_3";

	
			if (execStat) {
				if(resourceMap.get("inIterateVComp") == null){
					
						runStat.updateStatOnConnection("row16" + iterateId, 0, 0);
					
				}
			} 

		
		int tos_count_tFlowToIterate_3 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tFlowToIterate_3 - "  + ("Start to work.") );
    	class BytesLimit65535_tFlowToIterate_3{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tFlowToIterate_3 = new StringBuilder();
            log4jParamters_tFlowToIterate_3.append("Parameters:");
                    log4jParamters_tFlowToIterate_3.append("DEFAULT_MAP" + " = " + "true");
                log4jParamters_tFlowToIterate_3.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tFlowToIterate_3 - "  + (log4jParamters_tFlowToIterate_3) );
    		}
    	}
    	
        new BytesLimit65535_tFlowToIterate_3().limitLog4jByte();

int nb_line_tFlowToIterate_3 = 0;
int counter_tFlowToIterate_3 = 0;

 



/**
 * [tFlowToIterate_3 begin ] stop
 */



	
	/**
	 * [tGreenplumInput_13 begin ] start
	 */

	

	
		
		ok_Hash.put("tGreenplumInput_13", false);
		start_Hash.put("tGreenplumInput_13", System.currentTimeMillis());
		
	
	currentComponent="tGreenplumInput_13";

	
		int tos_count_tGreenplumInput_13 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tGreenplumInput_13 - "  + ("Start to work.") );
    	class BytesLimit65535_tGreenplumInput_13{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tGreenplumInput_13 = new StringBuilder();
            log4jParamters_tGreenplumInput_13.append("Parameters:");
                    log4jParamters_tGreenplumInput_13.append("USE_EXISTING_CONNECTION" + " = " + "true");
                log4jParamters_tGreenplumInput_13.append(" | ");
                    log4jParamters_tGreenplumInput_13.append("CONNECTION" + " = " + "tGreenplumConnection_8");
                log4jParamters_tGreenplumInput_13.append(" | ");
                    log4jParamters_tGreenplumInput_13.append("TABLE" + " = " + "\"\"");
                log4jParamters_tGreenplumInput_13.append(" | ");
                    log4jParamters_tGreenplumInput_13.append("QUERYSTORE" + " = " + "\"\"");
                log4jParamters_tGreenplumInput_13.append(" | ");
                    log4jParamters_tGreenplumInput_13.append("QUERY" + " = " + "\"select distinct t.target_schema target_schema_priv from sbdt.edl_table t  where lower(t.system_name) = lower( '\" + context.GP_SOURCE_NAME + \"') \"");
                log4jParamters_tGreenplumInput_13.append(" | ");
                    log4jParamters_tGreenplumInput_13.append("USE_CURSOR" + " = " + "false");
                log4jParamters_tGreenplumInput_13.append(" | ");
                    log4jParamters_tGreenplumInput_13.append("TRIM_ALL_COLUMN" + " = " + "false");
                log4jParamters_tGreenplumInput_13.append(" | ");
                    log4jParamters_tGreenplumInput_13.append("TRIM_COLUMN" + " = " + "[{TRIM="+("false")+", SCHEMA_COLUMN="+("target_schema_priv")+"}]");
                log4jParamters_tGreenplumInput_13.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tGreenplumInput_13 - "  + (log4jParamters_tGreenplumInput_13) );
    		}
    	}
    	
        new BytesLimit65535_tGreenplumInput_13().limitLog4jByte();
	
    
	
		    int nb_line_tGreenplumInput_13 = 0;
		    java.sql.Connection conn_tGreenplumInput_13 = null;
		        conn_tGreenplumInput_13 = (java.sql.Connection)globalMap.get("conn_tGreenplumConnection_8");
				
				if(conn_tGreenplumInput_13 != null) {
					if(conn_tGreenplumInput_13.getMetaData() != null) {
						
						log.debug("tGreenplumInput_13 - Uses an existing connection with username '" + conn_tGreenplumInput_13.getMetaData().getUserName() + "'. Connection URL: " + conn_tGreenplumInput_13.getMetaData().getURL() + ".");
						
					}
				}
			
		    
			java.sql.Statement stmt_tGreenplumInput_13 = conn_tGreenplumInput_13.createStatement();

		    String dbquery_tGreenplumInput_13 = "select distinct t.target_schema target_schema_priv from sbdt.edl_table t\nwhere lower(t.system_name) = lower( '" + context.GP_SOURCE_NAME + "') ";
			
                log.debug("tGreenplumInput_13 - Executing the query: '"+dbquery_tGreenplumInput_13+"'.");
			

                       globalMap.put("tGreenplumInput_13_QUERY",dbquery_tGreenplumInput_13);

		    java.sql.ResultSet rs_tGreenplumInput_13 = null;
		try{
		    rs_tGreenplumInput_13 = stmt_tGreenplumInput_13.executeQuery(dbquery_tGreenplumInput_13);
		    java.sql.ResultSetMetaData rsmd_tGreenplumInput_13 = rs_tGreenplumInput_13.getMetaData();
		    int colQtyInRs_tGreenplumInput_13 = rsmd_tGreenplumInput_13.getColumnCount();

		    String tmpContent_tGreenplumInput_13 = null;
		    
		    
		    	log.debug("tGreenplumInput_13 - Retrieving records from the database.");
		    
		    while (rs_tGreenplumInput_13.next()) {
		        nb_line_tGreenplumInput_13++;
		        
							if(colQtyInRs_tGreenplumInput_13 < 1) {
								row16.target_schema_priv = null;
							} else {
	                         		
        	row16.target_schema_priv = routines.system.JDBCUtil.getString(rs_tGreenplumInput_13, 1, false);
		                    }
					
						log.debug("tGreenplumInput_13 - Retrieving the record " + nb_line_tGreenplumInput_13 + ".");
					


 



/**
 * [tGreenplumInput_13 begin ] stop
 */
	
	/**
	 * [tGreenplumInput_13 main ] start
	 */

	

	
	
	currentComponent="tGreenplumInput_13";

	

 


	tos_count_tGreenplumInput_13++;

/**
 * [tGreenplumInput_13 main ] stop
 */

	
	/**
	 * [tFlowToIterate_3 main ] start
	 */

	

	
	
	currentComponent="tFlowToIterate_3";

	

			//row16
			//row16


			
				if(execStat){
					runStat.updateStatOnConnection("row16"+iterateId,1, 1);
				} 
			

		
    			if(log.isTraceEnabled()){
    				log.trace("row16 - " + (row16==null? "": row16.toLogString()));
    			}
    		


    	
                if(log.isTraceEnabled())
            log.trace("tFlowToIterate_3 - "  + ("Set global var, key=row16.target_schema_priv, value=")  + (row16.target_schema_priv)  + (".") );            
            globalMap.put("row16.target_schema_priv", row16.target_schema_priv);
    	
 
	   nb_line_tFlowToIterate_3++;  
       counter_tFlowToIterate_3++;
                if(log.isDebugEnabled())
            log.debug("tFlowToIterate_3 - "  + ("Current iteration is: ")  + (counter_tFlowToIterate_3)  + (".") );
       globalMap.put("tFlowToIterate_3_CURRENT_ITERATION", counter_tFlowToIterate_3);
 


	tos_count_tFlowToIterate_3++;

/**
 * [tFlowToIterate_3 main ] stop
 */
	NB_ITERATE_tGreenplumRow_4++;
	
	
				if(execStat){
					runStat.updateStatOnConnection("iterate3", 1, "exec" + NB_ITERATE_tGreenplumRow_4);
					//Thread.sleep(1000);
				}				
			

	
	/**
	 * [tGreenplumRow_4 begin ] start
	 */

	

	
		
		ok_Hash.put("tGreenplumRow_4", false);
		start_Hash.put("tGreenplumRow_4", System.currentTimeMillis());
		
	
	currentComponent="tGreenplumRow_4";

	
		int tos_count_tGreenplumRow_4 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tGreenplumRow_4 - "  + ("Start to work.") );
    	class BytesLimit65535_tGreenplumRow_4{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tGreenplumRow_4 = new StringBuilder();
            log4jParamters_tGreenplumRow_4.append("Parameters:");
                    log4jParamters_tGreenplumRow_4.append("USE_EXISTING_CONNECTION" + " = " + "true");
                log4jParamters_tGreenplumRow_4.append(" | ");
                    log4jParamters_tGreenplumRow_4.append("CONNECTION" + " = " + "tGreenplumConnection_8");
                log4jParamters_tGreenplumRow_4.append(" | ");
                    log4jParamters_tGreenplumRow_4.append("QUERYSTORE" + " = " + "\"\"");
                log4jParamters_tGreenplumRow_4.append(" | ");
                    log4jParamters_tGreenplumRow_4.append("QUERY" + " = " + "\"SELECT sbdt.force_privileges_by_schema	 (  '\"+ (String)globalMap.get(\"row16.target_schema_priv\") +\"' );\" ");
                log4jParamters_tGreenplumRow_4.append(" | ");
                    log4jParamters_tGreenplumRow_4.append("DIE_ON_ERROR" + " = " + "true");
                log4jParamters_tGreenplumRow_4.append(" | ");
                    log4jParamters_tGreenplumRow_4.append("PROPAGATE_RECORD_SET" + " = " + "false");
                log4jParamters_tGreenplumRow_4.append(" | ");
                    log4jParamters_tGreenplumRow_4.append("USE_PREPAREDSTATEMENT" + " = " + "false");
                log4jParamters_tGreenplumRow_4.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tGreenplumRow_4 - "  + (log4jParamters_tGreenplumRow_4) );
    		}
    	}
    	
        new BytesLimit65535_tGreenplumRow_4().limitLog4jByte();

	java.sql.Connection conn_tGreenplumRow_4 = null;
	String query_tGreenplumRow_4 = "";
	boolean whetherReject_tGreenplumRow_4 = false;
				conn_tGreenplumRow_4 = (java.sql.Connection)globalMap.get("conn_tGreenplumConnection_8");
			
				if(conn_tGreenplumRow_4 != null) {
					if(conn_tGreenplumRow_4.getMetaData() != null) {
						
						log.debug("tGreenplumRow_4 - Uses an existing connection with username '" + conn_tGreenplumRow_4.getMetaData().getUserName() + "'. Connection URL: " + conn_tGreenplumRow_4.getMetaData().getURL() + ".");
						
					}
				}
			
		java.sql.Statement stmt_tGreenplumRow_4 = conn_tGreenplumRow_4.createStatement();
	

 



/**
 * [tGreenplumRow_4 begin ] stop
 */
	
	/**
	 * [tGreenplumRow_4 main ] start
	 */

	

	
	
	currentComponent="tGreenplumRow_4";

	

	    		log.debug("tGreenplumRow_4 - Executing the query: '" + "SELECT sbdt.force_privileges_by_schema	 (  '"+ (String)globalMap.get("row16.target_schema_priv") +"' );"  + "'.");
			
query_tGreenplumRow_4 = "SELECT sbdt.force_privileges_by_schema	 (  '"+ (String)globalMap.get("row16.target_schema_priv") +"' );" ;
whetherReject_tGreenplumRow_4 = false;
globalMap.put("tGreenplumRow_4_QUERY",query_tGreenplumRow_4);
try {
		stmt_tGreenplumRow_4.execute(query_tGreenplumRow_4);
		
	    		log.info("tGreenplumRow_4 - Execute the query: '" + "SELECT sbdt.force_privileges_by_schema	 (  '"+ (String)globalMap.get("row16.target_schema_priv") +"' );"  + "' has finished.");
			
	} catch (java.lang.Exception e) {
		whetherReject_tGreenplumRow_4 = true;
		
			throw(e);
			
	}
	

 


	tos_count_tGreenplumRow_4++;

/**
 * [tGreenplumRow_4 main ] stop
 */
	
	/**
	 * [tGreenplumRow_4 end ] start
	 */

	

	
	
	currentComponent="tGreenplumRow_4";

	

	
	stmt_tGreenplumRow_4.close();	

 
                if(log.isDebugEnabled())
            log.debug("tGreenplumRow_4 - "  + ("Done.") );

ok_Hash.put("tGreenplumRow_4", true);
end_Hash.put("tGreenplumRow_4", System.currentTimeMillis());




/**
 * [tGreenplumRow_4 end ] stop
 */
						if(execStat){
							runStat.updateStatOnConnection("iterate3", 2, "exec" + NB_ITERATE_tGreenplumRow_4);
						}				
					







	
	/**
	 * [tGreenplumInput_13 end ] start
	 */

	

	
	
	currentComponent="tGreenplumInput_13";

	

	}
}finally{
	stmt_tGreenplumInput_13.close();

}
globalMap.put("tGreenplumInput_13_NB_LINE",nb_line_tGreenplumInput_13);
	    		log.debug("tGreenplumInput_13 - Retrieved records count: "+nb_line_tGreenplumInput_13 + " .");
			

 
                if(log.isDebugEnabled())
            log.debug("tGreenplumInput_13 - "  + ("Done.") );

ok_Hash.put("tGreenplumInput_13", true);
end_Hash.put("tGreenplumInput_13", System.currentTimeMillis());




/**
 * [tGreenplumInput_13 end ] stop
 */

	
	/**
	 * [tFlowToIterate_3 end ] start
	 */

	

	
	
	currentComponent="tFlowToIterate_3";

	

globalMap.put("tFlowToIterate_3_NB_LINE",nb_line_tFlowToIterate_3);
			if(execStat){
				if(resourceMap.get("inIterateVComp") == null || !((Boolean)resourceMap.get("inIterateVComp"))){
			 		runStat.updateStatOnConnection("row16"+iterateId,2, 0); 
			 	}
			}
		
 
                if(log.isDebugEnabled())
            log.debug("tFlowToIterate_3 - "  + ("Done.") );

ok_Hash.put("tFlowToIterate_3", true);
end_Hash.put("tFlowToIterate_3", System.currentTimeMillis());




/**
 * [tFlowToIterate_3 end ] stop
 */



				}//end the resume

				
				    			if(resumeEntryMethodName == null || globalResumeTicket){
				    				resumeUtil.addLog("CHECKPOINT", "CONNECTION:SUBJOB_OK:tGreenplumInput_13:OnSubjobOk", "", Thread.currentThread().getId() + "", "", "", "", "", "");
								}	    				    			
					    	
								if(execStat){    	
									runStat.updateStatOnConnection("OnSubjobOk39", 0, "ok");
								} 
							
							tGreenplumClose_5Process(globalMap); 
						



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage());
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tGreenplumInput_13 finally ] start
	 */

	

	
	
	currentComponent="tGreenplumInput_13";

	

 



/**
 * [tGreenplumInput_13 finally ] stop
 */

	
	/**
	 * [tFlowToIterate_3 finally ] start
	 */

	

	
	
	currentComponent="tFlowToIterate_3";

	

 



/**
 * [tFlowToIterate_3 finally ] stop
 */

	
	/**
	 * [tGreenplumRow_4 finally ] start
	 */

	

	
	
	currentComponent="tGreenplumRow_4";

	

 



/**
 * [tGreenplumRow_4 finally ] stop
 */






				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tGreenplumInput_13_SUBPROCESS_STATE", 1);
	}
	

public void tGreenplumClose_5Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tGreenplumClose_5_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;





	
	/**
	 * [tGreenplumClose_5 begin ] start
	 */

	

	
		
		ok_Hash.put("tGreenplumClose_5", false);
		start_Hash.put("tGreenplumClose_5", System.currentTimeMillis());
		
	
	currentComponent="tGreenplumClose_5";

	
		int tos_count_tGreenplumClose_5 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tGreenplumClose_5 - "  + ("Start to work.") );
    	class BytesLimit65535_tGreenplumClose_5{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tGreenplumClose_5 = new StringBuilder();
            log4jParamters_tGreenplumClose_5.append("Parameters:");
                    log4jParamters_tGreenplumClose_5.append("CONNECTION" + " = " + "tGreenplumConnection_8");
                log4jParamters_tGreenplumClose_5.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tGreenplumClose_5 - "  + (log4jParamters_tGreenplumClose_5) );
    		}
    	}
    	
        new BytesLimit65535_tGreenplumClose_5().limitLog4jByte();

 



/**
 * [tGreenplumClose_5 begin ] stop
 */
	
	/**
	 * [tGreenplumClose_5 main ] start
	 */

	

	
	
	currentComponent="tGreenplumClose_5";

	



	java.sql.Connection conn_tGreenplumClose_5 = (java.sql.Connection)globalMap.get("conn_tGreenplumConnection_8");
	if(conn_tGreenplumClose_5 != null && !conn_tGreenplumClose_5.isClosed())
	{
                if(log.isDebugEnabled())
            log.debug("tGreenplumClose_5 - "  + ("Closing the connection ")  + ("conn_tGreenplumConnection_8")  + (" to the database.") );
        conn_tGreenplumClose_5.close();
                if(log.isDebugEnabled())
            log.debug("tGreenplumClose_5 - "  + ("Connection ")  + ("conn_tGreenplumConnection_8")  + (" to the database has closed.") );
	}

 


	tos_count_tGreenplumClose_5++;

/**
 * [tGreenplumClose_5 main ] stop
 */
	
	/**
	 * [tGreenplumClose_5 end ] start
	 */

	

	
	
	currentComponent="tGreenplumClose_5";

	

 
                if(log.isDebugEnabled())
            log.debug("tGreenplumClose_5 - "  + ("Done.") );

ok_Hash.put("tGreenplumClose_5", true);
end_Hash.put("tGreenplumClose_5", System.currentTimeMillis());




/**
 * [tGreenplumClose_5 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage());
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tGreenplumClose_5 finally ] start
	 */

	

	
	
	currentComponent="tGreenplumClose_5";

	

 



/**
 * [tGreenplumClose_5 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tGreenplumClose_5_SUBPROCESS_STATE", 1);
	}
	

public void tJava_3Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tJava_3_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tJava_3 begin ] start
	 */

	

	
		
		ok_Hash.put("tJava_3", false);
		start_Hash.put("tJava_3", System.currentTimeMillis());
		
	
	currentComponent="tJava_3";

	
		int tos_count_tJava_3 = 0;
		
    	class BytesLimit65535_tJava_3{
    		public void limitLog4jByte() throws Exception{
    			
    		}
    	}
    	
        new BytesLimit65535_tJava_3().limitLog4jByte();


String strGpSqlTemplate=
"SELECT target_table_name log_table_name, ingestion_tool technology "+
"FROM sbdt.edl_table t "+
"join (select distinct table_name,system_name from sbdt.edl_log l1 "+
"join (select min(row_id) base_min,max(row_id) base_max from sbdt.edl_log where	run_id = #RUN_ID ) l2 on l1.row_id >base_min  and l1.status ='Finish' "+
") l on l.system_name=t.system_name and l.table_name=t.target_table_name "+
"WHERE t.system_name = '#GP_SOURCE_NAME' "+
" and update_type in ('Incremental', 'Full','Append','softdelete') "+
" #TABLE_NAME  "+
" order by t.load_order";

String strGpSql=strGpSqlTemplate;
//strGpSql=strGpSql.replace("#JOB_NAME", (String)globalMap.get("job_name"));
strGpSql=strGpSql.replace("#RUN_ID", ((Integer)context.RUN_ID).toString());
strGpSql=strGpSql.replace("#GP_SOURCE_NAME", (String)context.GP_SOURCE_NAME);
strGpSql=strGpSql.replace("#TABLE_NAME", (String)context.TABLE_NAME);
globalMap.put("gp_sql",strGpSql);

 



/**
 * [tJava_3 begin ] stop
 */
	
	/**
	 * [tJava_3 main ] start
	 */

	

	
	
	currentComponent="tJava_3";

	

 


	tos_count_tJava_3++;

/**
 * [tJava_3 main ] stop
 */
	
	/**
	 * [tJava_3 end ] start
	 */

	

	
	
	currentComponent="tJava_3";

	

 

ok_Hash.put("tJava_3", true);
end_Hash.put("tJava_3", System.currentTimeMillis());

				if(execStat){   
   	 				runStat.updateStatOnConnection("OnComponentOk6", 0, "ok");
				}
				tGreenplumInput_9Process(globalMap);



/**
 * [tJava_3 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage());
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tJava_3 finally ] start
	 */

	

	
	
	currentComponent="tJava_3";

	

 



/**
 * [tJava_3 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tJava_3_SUBPROCESS_STATE", 1);
	}
	

public void tSetGlobalVar_3Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tSetGlobalVar_3_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tSetGlobalVar_3 begin ] start
	 */

	

	
		
		ok_Hash.put("tSetGlobalVar_3", false);
		start_Hash.put("tSetGlobalVar_3", System.currentTimeMillis());
		
	
	currentComponent="tSetGlobalVar_3";

	
		int tos_count_tSetGlobalVar_3 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tSetGlobalVar_3 - "  + ("Start to work.") );
    	class BytesLimit65535_tSetGlobalVar_3{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tSetGlobalVar_3 = new StringBuilder();
            log4jParamters_tSetGlobalVar_3.append("Parameters:");
                    log4jParamters_tSetGlobalVar_3.append("VARIABLES" + " = " + "[{VALUE="+("\"\"")+", KEY="+("\"insert_log_sql\"")+"}, {VALUE="+("\"\"")+", KEY="+("\"insert_log_template\"")+"}, {VALUE="+("\"\"")+", KEY="+("\"increment_rolling_call\"")+"}, {VALUE="+("\"\"")+", KEY="+("\"increment_rolling_call_template\"")+"}, {VALUE="+("\"\"")+", KEY="+("\"softdelete_call\"")+"}, {VALUE="+("\"\"")+", KEY="+("\"softdelete_call_template\"")+"}, {VALUE="+("\"\"")+", KEY="+("\"data_profiling_call\"")+"}, {VALUE="+("\"\"")+", KEY="+("\"data_profiling_call_template\"")+"}, {VALUE="+("\"\"")+", KEY="+("\"gp_sql\"")+"}, {VALUE="+("TalendDate.getDate(\"yyyyMMddHH24mmssSSS\")")+", KEY="+("\"timestamp\"")+"}, {VALUE="+("\"P2D_\"")+", KEY="+("\"jobname_prefix\"")+"}]");
                log4jParamters_tSetGlobalVar_3.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tSetGlobalVar_3 - "  + (log4jParamters_tSetGlobalVar_3) );
    		}
    	}
    	
        new BytesLimit65535_tSetGlobalVar_3().limitLog4jByte();

 



/**
 * [tSetGlobalVar_3 begin ] stop
 */
	
	/**
	 * [tSetGlobalVar_3 main ] start
	 */

	

	
	
	currentComponent="tSetGlobalVar_3";

	

globalMap.put("insert_log_sql", "");
globalMap.put("insert_log_template", "");
globalMap.put("increment_rolling_call", "");
globalMap.put("increment_rolling_call_template", "");
globalMap.put("softdelete_call", "");
globalMap.put("softdelete_call_template", "");
globalMap.put("data_profiling_call", "");
globalMap.put("data_profiling_call_template", "");
globalMap.put("gp_sql", "");
globalMap.put("timestamp", TalendDate.getDate("yyyyMMddHH24mmssSSS"));
globalMap.put("jobname_prefix", "P2D_");

 


	tos_count_tSetGlobalVar_3++;

/**
 * [tSetGlobalVar_3 main ] stop
 */
	
	/**
	 * [tSetGlobalVar_3 end ] start
	 */

	

	
	
	currentComponent="tSetGlobalVar_3";

	

 
                if(log.isDebugEnabled())
            log.debug("tSetGlobalVar_3 - "  + ("Done.") );

ok_Hash.put("tSetGlobalVar_3", true);
end_Hash.put("tSetGlobalVar_3", System.currentTimeMillis());




/**
 * [tSetGlobalVar_3 end ] stop
 */
				}//end the resume

				
				    			if(resumeEntryMethodName == null || globalResumeTicket){
				    				resumeUtil.addLog("CHECKPOINT", "CONNECTION:SUBJOB_OK:tSetGlobalVar_3:OnSubjobOk", "", Thread.currentThread().getId() + "", "", "", "", "", "");
								}	    				    			
					    	
								if(execStat){    	
									runStat.updateStatOnConnection("OnSubjobOk14", 0, "ok");
								} 
							
							tGreenplumConnection_4Process(globalMap); 
						



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage());
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tSetGlobalVar_3 finally ] start
	 */

	

	
	
	currentComponent="tSetGlobalVar_3";

	

 



/**
 * [tSetGlobalVar_3 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tSetGlobalVar_3_SUBPROCESS_STATE", 1);
	}
	

public void tGreenplumConnection_4Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tGreenplumConnection_4_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tGreenplumConnection_4 begin ] start
	 */

	

	
		
		ok_Hash.put("tGreenplumConnection_4", false);
		start_Hash.put("tGreenplumConnection_4", System.currentTimeMillis());
		
	
	currentComponent="tGreenplumConnection_4";

	
		int tos_count_tGreenplumConnection_4 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tGreenplumConnection_4 - "  + ("Start to work.") );
    	class BytesLimit65535_tGreenplumConnection_4{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tGreenplumConnection_4 = new StringBuilder();
            log4jParamters_tGreenplumConnection_4.append("Parameters:");
                    log4jParamters_tGreenplumConnection_4.append("HOST" + " = " + "context.SOURCE_HOST");
                log4jParamters_tGreenplumConnection_4.append(" | ");
                    log4jParamters_tGreenplumConnection_4.append("PORT" + " = " + "context.SOURCE_PORT");
                log4jParamters_tGreenplumConnection_4.append(" | ");
                    log4jParamters_tGreenplumConnection_4.append("DBNAME" + " = " + "context.SOURCE_DATABASE");
                log4jParamters_tGreenplumConnection_4.append(" | ");
                    log4jParamters_tGreenplumConnection_4.append("SCHEMA_DB" + " = " + "\"\"");
                log4jParamters_tGreenplumConnection_4.append(" | ");
                    log4jParamters_tGreenplumConnection_4.append("USER" + " = " + "context.SOURCE_USER");
                log4jParamters_tGreenplumConnection_4.append(" | ");
                    log4jParamters_tGreenplumConnection_4.append("PASS" + " = " + String.valueOf(routines.system.PasswordEncryptUtil.encryptPassword(context.SOURCE_PASSWORD)).substring(0, 4) + "...");     
                log4jParamters_tGreenplumConnection_4.append(" | ");
                    log4jParamters_tGreenplumConnection_4.append("USE_SHARED_CONNECTION" + " = " + "true");
                log4jParamters_tGreenplumConnection_4.append(" | ");
                    log4jParamters_tGreenplumConnection_4.append("SHARED_CONNECTION_NAME" + " = " + "\"base_dynamic\"+((String)globalMap.get(\"timestamp\"))");
                log4jParamters_tGreenplumConnection_4.append(" | ");
                    log4jParamters_tGreenplumConnection_4.append("USE_SSL" + " = " + "true");
                log4jParamters_tGreenplumConnection_4.append(" | ");
                    log4jParamters_tGreenplumConnection_4.append("AUTO_COMMIT" + " = " + "true");
                log4jParamters_tGreenplumConnection_4.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tGreenplumConnection_4 - "  + (log4jParamters_tGreenplumConnection_4) );
    		}
    	}
    	
        new BytesLimit65535_tGreenplumConnection_4().limitLog4jByte();
	

	
				String url_tGreenplumConnection_4 = "jdbc:postgresql://"+context.SOURCE_HOST+":"+context.SOURCE_PORT+"/"+context.SOURCE_DATABASE+"?ssl=true&sslfactory=org.postgresql.ssl.NonValidatingFactory";

	String dbUser_tGreenplumConnection_4 = context.SOURCE_USER;
	
	
		
	final String decryptedPassword_tGreenplumConnection_4 = context.SOURCE_PASSWORD; 
		String dbPwd_tGreenplumConnection_4 = decryptedPassword_tGreenplumConnection_4;
	

	java.sql.Connection conn_tGreenplumConnection_4 = null;
	
	
			SharedDBConnectionLog4j.initLogger(log,"tGreenplumConnection_4");
			String sharedConnectionName_tGreenplumConnection_4 = "base_dynamic"+((String)globalMap.get("timestamp"));
			conn_tGreenplumConnection_4 = SharedDBConnectionLog4j.getDBConnection("org.postgresql.Driver",url_tGreenplumConnection_4,dbUser_tGreenplumConnection_4 , dbPwd_tGreenplumConnection_4 , sharedConnectionName_tGreenplumConnection_4);
	if (null != conn_tGreenplumConnection_4) {
		
			log.debug("tGreenplumConnection_4 - Connection is set auto commit to 'true'.");
			conn_tGreenplumConnection_4.setAutoCommit(true);
	}

	globalMap.put("schema_" + "tGreenplumConnection_4","");

	globalMap.put("conn_" + "tGreenplumConnection_4",conn_tGreenplumConnection_4);
 



/**
 * [tGreenplumConnection_4 begin ] stop
 */
	
	/**
	 * [tGreenplumConnection_4 main ] start
	 */

	

	
	
	currentComponent="tGreenplumConnection_4";

	

 


	tos_count_tGreenplumConnection_4++;

/**
 * [tGreenplumConnection_4 main ] stop
 */
	
	/**
	 * [tGreenplumConnection_4 end ] start
	 */

	

	
	
	currentComponent="tGreenplumConnection_4";

	

 
                if(log.isDebugEnabled())
            log.debug("tGreenplumConnection_4 - "  + ("Done.") );

ok_Hash.put("tGreenplumConnection_4", true);
end_Hash.put("tGreenplumConnection_4", System.currentTimeMillis());




/**
 * [tGreenplumConnection_4 end ] stop
 */
				}//end the resume

				
				    			if(resumeEntryMethodName == null || globalResumeTicket){
				    				resumeUtil.addLog("CHECKPOINT", "CONNECTION:SUBJOB_OK:tGreenplumConnection_4:OnSubjobOk", "", Thread.currentThread().getId() + "", "", "", "", "", "");
								}	    				    			
					    	
								if(execStat){    	
									runStat.updateStatOnConnection("OnSubjobOk17", 0, "ok");
								} 
							
							tGreenplumInput_6Process(globalMap); 
						



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage());
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tGreenplumConnection_4 finally ] start
	 */

	

	
	
	currentComponent="tGreenplumConnection_4";

	

 



/**
 * [tGreenplumConnection_4 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tGreenplumConnection_4_SUBPROCESS_STATE", 1);
	}
	


public static class row6Struct implements routines.system.IPersistableRow<row6Struct> {
    final static byte[] commonByteArrayLock_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Prod2Dev_with_GP_FDIST = new byte[0];
    static byte[] commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Prod2Dev_with_GP_FDIST = new byte[0];

	
			    public String source_name;

				public String getSource_name () {
					return this.source_name;
				}
				
			    public String host_name;

				public String getHost_name () {
					return this.host_name;
				}
				
			    public String database;

				public String getDatabase () {
					return this.database;
				}
				
			    public Integer port;

				public Integer getPort () {
					return this.port;
				}
				
			    public String user_name;

				public String getUser_name () {
					return this.user_name;
				}
				
			    public String password;

				public String getPassword () {
					return this.password;
				}
				
			    public String type;

				public String getType () {
					return this.type;
				}
				
			    public String job_name;

				public String getJob_name () {
					return this.job_name;
				}
				



	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Prod2Dev_with_GP_FDIST.length) {
				if(length < 1024 && commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Prod2Dev_with_GP_FDIST.length == 0) {
   					commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Prod2Dev_with_GP_FDIST = new byte[1024];
				} else {
   					commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Prod2Dev_with_GP_FDIST = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Prod2Dev_with_GP_FDIST, 0, length);
			strReturn = new String(commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Prod2Dev_with_GP_FDIST, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
	private Integer readInteger(ObjectInputStream dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}

	private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException{
		if(intNum == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeInt(intNum);
    	}
	}

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Prod2Dev_with_GP_FDIST) {

        	try {

        		int length = 0;
		
					this.source_name = readString(dis);
					
					this.host_name = readString(dis);
					
					this.database = readString(dis);
					
						this.port = readInteger(dis);
					
					this.user_name = readString(dis);
					
					this.password = readString(dis);
					
					this.type = readString(dis);
					
					this.job_name = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// String
				
						writeString(this.source_name,dos);
					
					// String
				
						writeString(this.host_name,dos);
					
					// String
				
						writeString(this.database,dos);
					
					// Integer
				
						writeInteger(this.port,dos);
					
					// String
				
						writeString(this.user_name,dos);
					
					// String
				
						writeString(this.password,dos);
					
					// String
				
						writeString(this.type,dos);
					
					// String
				
						writeString(this.job_name,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("source_name="+source_name);
		sb.append(",host_name="+host_name);
		sb.append(",database="+database);
		sb.append(",port="+String.valueOf(port));
		sb.append(",user_name="+user_name);
		sb.append(",password="+password);
		sb.append(",type="+type);
		sb.append(",job_name="+job_name);
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				if(source_name == null){
        					sb.append("<null>");
        				}else{
            				sb.append(source_name);
            			}
            		
        			sb.append("|");
        		
        				if(host_name == null){
        					sb.append("<null>");
        				}else{
            				sb.append(host_name);
            			}
            		
        			sb.append("|");
        		
        				if(database == null){
        					sb.append("<null>");
        				}else{
            				sb.append(database);
            			}
            		
        			sb.append("|");
        		
        				if(port == null){
        					sb.append("<null>");
        				}else{
            				sb.append(port);
            			}
            		
        			sb.append("|");
        		
        				if(user_name == null){
        					sb.append("<null>");
        				}else{
            				sb.append(user_name);
            			}
            		
        			sb.append("|");
        		
        				if(password == null){
        					sb.append("<null>");
        				}else{
            				sb.append(password);
            			}
            		
        			sb.append("|");
        		
        				if(type == null){
        					sb.append("<null>");
        				}else{
            				sb.append(type);
            			}
            		
        			sb.append("|");
        		
        				if(job_name == null){
        					sb.append("<null>");
        				}else{
            				sb.append(job_name);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(row6Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}
public void tGreenplumInput_6Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tGreenplumInput_6_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;



		row6Struct row6 = new row6Struct();




	
	/**
	 * [tSetGlobalVar_4 begin ] start
	 */

	

	
		
		ok_Hash.put("tSetGlobalVar_4", false);
		start_Hash.put("tSetGlobalVar_4", System.currentTimeMillis());
		
	
	currentComponent="tSetGlobalVar_4";

	
			if (execStat) {
				if(resourceMap.get("inIterateVComp") == null){
					
						runStat.updateStatOnConnection("row6" + iterateId, 0, 0);
					
				}
			} 

		
		int tos_count_tSetGlobalVar_4 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tSetGlobalVar_4 - "  + ("Start to work.") );
    	class BytesLimit65535_tSetGlobalVar_4{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tSetGlobalVar_4 = new StringBuilder();
            log4jParamters_tSetGlobalVar_4.append("Parameters:");
                    log4jParamters_tSetGlobalVar_4.append("VARIABLES" + " = " + "[{VALUE="+("row6.host_name")+", KEY="+("\"host_name\"")+"}, {VALUE="+("row6.job_name")+", KEY="+("\"job_name\"")+"}, {VALUE="+("row6.database")+", KEY="+("\"o_database\"")+"}, {VALUE="+("row6.port")+", KEY="+("\"port\"")+"}, {VALUE="+("row6.user_name")+", KEY="+("\"user_name\"")+"}]");
                log4jParamters_tSetGlobalVar_4.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tSetGlobalVar_4 - "  + (log4jParamters_tSetGlobalVar_4) );
    		}
    	}
    	
        new BytesLimit65535_tSetGlobalVar_4().limitLog4jByte();

 



/**
 * [tSetGlobalVar_4 begin ] stop
 */



	
	/**
	 * [tGreenplumInput_6 begin ] start
	 */

	

	
		
		ok_Hash.put("tGreenplumInput_6", false);
		start_Hash.put("tGreenplumInput_6", System.currentTimeMillis());
		
	
	currentComponent="tGreenplumInput_6";

	
		int tos_count_tGreenplumInput_6 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tGreenplumInput_6 - "  + ("Start to work.") );
    	class BytesLimit65535_tGreenplumInput_6{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tGreenplumInput_6 = new StringBuilder();
            log4jParamters_tGreenplumInput_6.append("Parameters:");
                    log4jParamters_tGreenplumInput_6.append("USE_EXISTING_CONNECTION" + " = " + "true");
                log4jParamters_tGreenplumInput_6.append(" | ");
                    log4jParamters_tGreenplumInput_6.append("CONNECTION" + " = " + "tGreenplumConnection_4");
                log4jParamters_tGreenplumInput_6.append(" | ");
                    log4jParamters_tGreenplumInput_6.append("TABLE" + " = " + "\"\"");
                log4jParamters_tGreenplumInput_6.append(" | ");
                    log4jParamters_tGreenplumInput_6.append("QUERYSTORE" + " = " + "\"\"");
                log4jParamters_tGreenplumInput_6.append(" | ");
                    log4jParamters_tGreenplumInput_6.append("QUERY" + " = " + "\"SELECT system_name,host_name, database,port,user_name,'' password, type,  CASE   WHEN type='Oracle Service' THEN 'Oracle_to_greenplum_with_GPLoad_EDL'   WHEN type='Greenplum' THEN 'Greenplum_to_greenplum_with_GPLoad'   WHEN type='Oracle SID' THEN 'Oracle_SID_to_greenplum_with_GPLoad_EDL'   WHEN type='HVR' THEN 'HVR_stats'  WHEN type='File' THEN 'File_to_greenplum_with_GPLoad'  WHEN type='IBM AS400 DB2' THEN 'AS400_to_greenplum_with_GPLoad'   WHEN type='SQL Server' THEN 'MSSQL_to_greenplum_with_GPLoad_EDL'   WHEN type='Teradata' THEN 'Teradata_to_greenplum_with_GPLoad'   ELSE type  END job_name  FROM sbdt.edl_connection c   WHERE lower(system_name) = lower('\" + context.GP_SOURCE_NAME + \"')\"");
                log4jParamters_tGreenplumInput_6.append(" | ");
                    log4jParamters_tGreenplumInput_6.append("USE_CURSOR" + " = " + "false");
                log4jParamters_tGreenplumInput_6.append(" | ");
                    log4jParamters_tGreenplumInput_6.append("TRIM_ALL_COLUMN" + " = " + "false");
                log4jParamters_tGreenplumInput_6.append(" | ");
                    log4jParamters_tGreenplumInput_6.append("TRIM_COLUMN" + " = " + "[{TRIM="+("false")+", SCHEMA_COLUMN="+("source_name")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("host_name")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("database")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("port")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("user_name")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("password")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("type")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("job_name")+"}]");
                log4jParamters_tGreenplumInput_6.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tGreenplumInput_6 - "  + (log4jParamters_tGreenplumInput_6) );
    		}
    	}
    	
        new BytesLimit65535_tGreenplumInput_6().limitLog4jByte();
	
    
	
		    int nb_line_tGreenplumInput_6 = 0;
		    java.sql.Connection conn_tGreenplumInput_6 = null;
		        conn_tGreenplumInput_6 = (java.sql.Connection)globalMap.get("conn_tGreenplumConnection_4");
				
				if(conn_tGreenplumInput_6 != null) {
					if(conn_tGreenplumInput_6.getMetaData() != null) {
						
						log.debug("tGreenplumInput_6 - Uses an existing connection with username '" + conn_tGreenplumInput_6.getMetaData().getUserName() + "'. Connection URL: " + conn_tGreenplumInput_6.getMetaData().getURL() + ".");
						
					}
				}
			
		    
			java.sql.Statement stmt_tGreenplumInput_6 = conn_tGreenplumInput_6.createStatement();

		    String dbquery_tGreenplumInput_6 = "SELECT system_name,host_name, database,port,user_name,'' password, type,\nCASE \nWHEN type='Oracle Service' THEN 'Oracle_to_greenplum_with_GPLoad_EDL' \nWHEN type='Greenplum' THEN 'Greenplum_to_greenplum_with_GPLoad' \nWHEN type='Oracle SID' THEN 'Oracle_SID_to_greenplum_with_GPLoad_EDL' \nWHEN type='HVR' THEN 'HVR_stats'\nWHEN type='File' THEN 'File_to_greenplum_with_GPLoad'\nWHEN type='IBM AS400 DB2' THEN 'AS400_to_greenplum_with_GPLoad' \nWHEN type='SQL Server' THEN 'MSSQL_to_greenplum_with_GPLoad_EDL' \nWHEN type='Teradata' THEN 'Teradata_to_greenplum_with_GPLoad' \nELSE type\nEND job_name\nFROM sbdt.edl_connection c \nWHERE lower(system_name) = lower('" + context.GP_SOURCE_NAME + "')";
			
                log.debug("tGreenplumInput_6 - Executing the query: '"+dbquery_tGreenplumInput_6+"'.");
			

                       globalMap.put("tGreenplumInput_6_QUERY",dbquery_tGreenplumInput_6);

		    java.sql.ResultSet rs_tGreenplumInput_6 = null;
		try{
		    rs_tGreenplumInput_6 = stmt_tGreenplumInput_6.executeQuery(dbquery_tGreenplumInput_6);
		    java.sql.ResultSetMetaData rsmd_tGreenplumInput_6 = rs_tGreenplumInput_6.getMetaData();
		    int colQtyInRs_tGreenplumInput_6 = rsmd_tGreenplumInput_6.getColumnCount();

		    String tmpContent_tGreenplumInput_6 = null;
		    
		    
		    	log.debug("tGreenplumInput_6 - Retrieving records from the database.");
		    
		    while (rs_tGreenplumInput_6.next()) {
		        nb_line_tGreenplumInput_6++;
		        
							if(colQtyInRs_tGreenplumInput_6 < 1) {
								row6.source_name = null;
							} else {
	                         		
        	row6.source_name = routines.system.JDBCUtil.getString(rs_tGreenplumInput_6, 1, false);
		                    }
							if(colQtyInRs_tGreenplumInput_6 < 2) {
								row6.host_name = null;
							} else {
	                         		
        	row6.host_name = routines.system.JDBCUtil.getString(rs_tGreenplumInput_6, 2, false);
		                    }
							if(colQtyInRs_tGreenplumInput_6 < 3) {
								row6.database = null;
							} else {
	                         		
        	row6.database = routines.system.JDBCUtil.getString(rs_tGreenplumInput_6, 3, false);
		                    }
							if(colQtyInRs_tGreenplumInput_6 < 4) {
								row6.port = null;
							} else {
		                          
            if(rs_tGreenplumInput_6.getObject(4) != null) {
                row6.port = rs_tGreenplumInput_6.getInt(4);
            } else {
                    row6.port = null;
            }
		                    }
							if(colQtyInRs_tGreenplumInput_6 < 5) {
								row6.user_name = null;
							} else {
	                         		
        	row6.user_name = routines.system.JDBCUtil.getString(rs_tGreenplumInput_6, 5, false);
		                    }
							if(colQtyInRs_tGreenplumInput_6 < 6) {
								row6.password = null;
							} else {
	                         		
        	row6.password = routines.system.JDBCUtil.getString(rs_tGreenplumInput_6, 6, false);
		                    }
							if(colQtyInRs_tGreenplumInput_6 < 7) {
								row6.type = null;
							} else {
	                         		
        	row6.type = routines.system.JDBCUtil.getString(rs_tGreenplumInput_6, 7, false);
		                    }
							if(colQtyInRs_tGreenplumInput_6 < 8) {
								row6.job_name = null;
							} else {
	                         		
        	row6.job_name = routines.system.JDBCUtil.getString(rs_tGreenplumInput_6, 8, false);
		                    }
					
						log.debug("tGreenplumInput_6 - Retrieving the record " + nb_line_tGreenplumInput_6 + ".");
					


 



/**
 * [tGreenplumInput_6 begin ] stop
 */
	
	/**
	 * [tGreenplumInput_6 main ] start
	 */

	

	
	
	currentComponent="tGreenplumInput_6";

	

 


	tos_count_tGreenplumInput_6++;

/**
 * [tGreenplumInput_6 main ] stop
 */

	
	/**
	 * [tSetGlobalVar_4 main ] start
	 */

	

	
	
	currentComponent="tSetGlobalVar_4";

	

			//row6
			//row6


			
				if(execStat){
					runStat.updateStatOnConnection("row6"+iterateId,1, 1);
				} 
			

		
    			if(log.isTraceEnabled()){
    				log.trace("row6 - " + (row6==null? "": row6.toLogString()));
    			}
    		

globalMap.put("host_name", row6.host_name);
globalMap.put("job_name", row6.job_name);
globalMap.put("o_database", row6.database);
globalMap.put("port", row6.port);
globalMap.put("user_name", row6.user_name);

 


	tos_count_tSetGlobalVar_4++;

/**
 * [tSetGlobalVar_4 main ] stop
 */



	
	/**
	 * [tGreenplumInput_6 end ] start
	 */

	

	
	
	currentComponent="tGreenplumInput_6";

	

	}
}finally{
	stmt_tGreenplumInput_6.close();

}
globalMap.put("tGreenplumInput_6_NB_LINE",nb_line_tGreenplumInput_6);
	    		log.debug("tGreenplumInput_6 - Retrieved records count: "+nb_line_tGreenplumInput_6 + " .");
			

 
                if(log.isDebugEnabled())
            log.debug("tGreenplumInput_6 - "  + ("Done.") );

ok_Hash.put("tGreenplumInput_6", true);
end_Hash.put("tGreenplumInput_6", System.currentTimeMillis());




/**
 * [tGreenplumInput_6 end ] stop
 */

	
	/**
	 * [tSetGlobalVar_4 end ] start
	 */

	

	
	
	currentComponent="tSetGlobalVar_4";

	

			if(execStat){
				if(resourceMap.get("inIterateVComp") == null || !((Boolean)resourceMap.get("inIterateVComp"))){
			 		runStat.updateStatOnConnection("row6"+iterateId,2, 0); 
			 	}
			}
		
 
                if(log.isDebugEnabled())
            log.debug("tSetGlobalVar_4 - "  + ("Done.") );

ok_Hash.put("tSetGlobalVar_4", true);
end_Hash.put("tSetGlobalVar_4", System.currentTimeMillis());




/**
 * [tSetGlobalVar_4 end ] stop
 */



				}//end the resume

				
				    			if(resumeEntryMethodName == null || globalResumeTicket){
				    				resumeUtil.addLog("CHECKPOINT", "CONNECTION:SUBJOB_OK:tGreenplumInput_6:OnSubjobOk", "", Thread.currentThread().getId() + "", "", "", "", "", "");
								}	    				    			
					    	
								if(execStat){    	
									runStat.updateStatOnConnection("OnSubjobOk18", 0, "ok");
								} 
							
							tGreenplumInput_8Process(globalMap); 
						



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage());
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tGreenplumInput_6 finally ] start
	 */

	

	
	
	currentComponent="tGreenplumInput_6";

	

 



/**
 * [tGreenplumInput_6 finally ] stop
 */

	
	/**
	 * [tSetGlobalVar_4 finally ] start
	 */

	

	
	
	currentComponent="tSetGlobalVar_4";

	

 



/**
 * [tSetGlobalVar_4 finally ] stop
 */



				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tGreenplumInput_6_SUBPROCESS_STATE", 1);
	}
	


public static class row7Struct implements routines.system.IPersistableRow<row7Struct> {
    final static byte[] commonByteArrayLock_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Prod2Dev_with_GP_FDIST = new byte[0];
    static byte[] commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Prod2Dev_with_GP_FDIST = new byte[0];

	
			    public String plant_name;

				public String getPlant_name () {
					return this.plant_name;
				}
				
			    public String system_name;

				public String getSystem_name () {
					return this.system_name;
				}
				
			    public String data_path;

				public String getData_path () {
					return this.data_path;
				}
				
			    public String job_label_name;

				public String getJob_label_name () {
					return this.job_label_name;
				}
				
			    public String business;

				public String getBusiness () {
					return this.business;
				}
				
			    public String sub_business;

				public String getSub_business () {
					return this.sub_business;
				}
				
			    public String sbdt_type;

				public String getSbdt_type () {
					return this.sbdt_type;
				}
				
			    public String sbdt_schema_name;

				public String getSbdt_schema_name () {
					return this.sbdt_schema_name;
				}
				
			    public String sbdt_comment;

				public String getSbdt_comment () {
					return this.sbdt_comment;
				}
				
			    public String pod;

				public String getPod () {
					return this.pod;
				}
				



	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Prod2Dev_with_GP_FDIST.length) {
				if(length < 1024 && commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Prod2Dev_with_GP_FDIST.length == 0) {
   					commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Prod2Dev_with_GP_FDIST = new byte[1024];
				} else {
   					commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Prod2Dev_with_GP_FDIST = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Prod2Dev_with_GP_FDIST, 0, length);
			strReturn = new String(commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Prod2Dev_with_GP_FDIST, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Prod2Dev_with_GP_FDIST) {

        	try {

        		int length = 0;
		
					this.plant_name = readString(dis);
					
					this.system_name = readString(dis);
					
					this.data_path = readString(dis);
					
					this.job_label_name = readString(dis);
					
					this.business = readString(dis);
					
					this.sub_business = readString(dis);
					
					this.sbdt_type = readString(dis);
					
					this.sbdt_schema_name = readString(dis);
					
					this.sbdt_comment = readString(dis);
					
					this.pod = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// String
				
						writeString(this.plant_name,dos);
					
					// String
				
						writeString(this.system_name,dos);
					
					// String
				
						writeString(this.data_path,dos);
					
					// String
				
						writeString(this.job_label_name,dos);
					
					// String
				
						writeString(this.business,dos);
					
					// String
				
						writeString(this.sub_business,dos);
					
					// String
				
						writeString(this.sbdt_type,dos);
					
					// String
				
						writeString(this.sbdt_schema_name,dos);
					
					// String
				
						writeString(this.sbdt_comment,dos);
					
					// String
				
						writeString(this.pod,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("plant_name="+plant_name);
		sb.append(",system_name="+system_name);
		sb.append(",data_path="+data_path);
		sb.append(",job_label_name="+job_label_name);
		sb.append(",business="+business);
		sb.append(",sub_business="+sub_business);
		sb.append(",sbdt_type="+sbdt_type);
		sb.append(",sbdt_schema_name="+sbdt_schema_name);
		sb.append(",sbdt_comment="+sbdt_comment);
		sb.append(",pod="+pod);
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				if(plant_name == null){
        					sb.append("<null>");
        				}else{
            				sb.append(plant_name);
            			}
            		
        			sb.append("|");
        		
        				if(system_name == null){
        					sb.append("<null>");
        				}else{
            				sb.append(system_name);
            			}
            		
        			sb.append("|");
        		
        				if(data_path == null){
        					sb.append("<null>");
        				}else{
            				sb.append(data_path);
            			}
            		
        			sb.append("|");
        		
        				if(job_label_name == null){
        					sb.append("<null>");
        				}else{
            				sb.append(job_label_name);
            			}
            		
        			sb.append("|");
        		
        				if(business == null){
        					sb.append("<null>");
        				}else{
            				sb.append(business);
            			}
            		
        			sb.append("|");
        		
        				if(sub_business == null){
        					sb.append("<null>");
        				}else{
            				sb.append(sub_business);
            			}
            		
        			sb.append("|");
        		
        				if(sbdt_type == null){
        					sb.append("<null>");
        				}else{
            				sb.append(sbdt_type);
            			}
            		
        			sb.append("|");
        		
        				if(sbdt_schema_name == null){
        					sb.append("<null>");
        				}else{
            				sb.append(sbdt_schema_name);
            			}
            		
        			sb.append("|");
        		
        				if(sbdt_comment == null){
        					sb.append("<null>");
        				}else{
            				sb.append(sbdt_comment);
            			}
            		
        			sb.append("|");
        		
        				if(pod == null){
        					sb.append("<null>");
        				}else{
            				sb.append(pod);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(row7Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}
public void tGreenplumInput_8Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tGreenplumInput_8_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;



		row7Struct row7 = new row7Struct();




	
	/**
	 * [tSetGlobalVar_5 begin ] start
	 */

	

	
		
		ok_Hash.put("tSetGlobalVar_5", false);
		start_Hash.put("tSetGlobalVar_5", System.currentTimeMillis());
		
	
	currentComponent="tSetGlobalVar_5";

	
			if (execStat) {
				if(resourceMap.get("inIterateVComp") == null){
					
						runStat.updateStatOnConnection("row7" + iterateId, 0, 0);
					
				}
			} 

		
		int tos_count_tSetGlobalVar_5 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tSetGlobalVar_5 - "  + ("Start to work.") );
    	class BytesLimit65535_tSetGlobalVar_5{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tSetGlobalVar_5 = new StringBuilder();
            log4jParamters_tSetGlobalVar_5.append("Parameters:");
                    log4jParamters_tSetGlobalVar_5.append("VARIABLES" + " = " + "[{VALUE="+("row7.plant_name")+", KEY="+("\"plant_name\"")+"}, {VALUE="+("row7.system_name")+", KEY="+("\"system_name\"")+"}, {VALUE="+("row7.data_path")+", KEY="+("\"data_path\"")+"}, {VALUE="+("row7.job_label_name")+", KEY="+("\"job_label_name\"")+"}, {VALUE="+("row7.business")+", KEY="+("\"business\"")+"}, {VALUE="+("row7.sub_business")+", KEY="+("\"sub_business\"")+"}, {VALUE="+("row7.sbdt_type")+", KEY="+("\"sbdt_type\"")+"}, {VALUE="+("row7.sbdt_schema_name")+", KEY="+("\"sbdt_schema_name\"")+"}, {VALUE="+("row7.sbdt_comment")+", KEY="+("\"sbdt_comment\"")+"}, {VALUE="+("row7.pod")+", KEY="+("\"pod\"")+"}, {VALUE="+("\"\"")+", KEY="+("\"gp_sql\"")+"}]");
                log4jParamters_tSetGlobalVar_5.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tSetGlobalVar_5 - "  + (log4jParamters_tSetGlobalVar_5) );
    		}
    	}
    	
        new BytesLimit65535_tSetGlobalVar_5().limitLog4jByte();

 



/**
 * [tSetGlobalVar_5 begin ] stop
 */



	
	/**
	 * [tGreenplumInput_8 begin ] start
	 */

	

	
		
		ok_Hash.put("tGreenplumInput_8", false);
		start_Hash.put("tGreenplumInput_8", System.currentTimeMillis());
		
	
	currentComponent="tGreenplumInput_8";

	
		int tos_count_tGreenplumInput_8 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tGreenplumInput_8 - "  + ("Start to work.") );
    	class BytesLimit65535_tGreenplumInput_8{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tGreenplumInput_8 = new StringBuilder();
            log4jParamters_tGreenplumInput_8.append("Parameters:");
                    log4jParamters_tGreenplumInput_8.append("USE_EXISTING_CONNECTION" + " = " + "true");
                log4jParamters_tGreenplumInput_8.append(" | ");
                    log4jParamters_tGreenplumInput_8.append("CONNECTION" + " = " + "tGreenplumConnection_4");
                log4jParamters_tGreenplumInput_8.append(" | ");
                    log4jParamters_tGreenplumInput_8.append("TABLE" + " = " + "\"\"");
                log4jParamters_tGreenplumInput_8.append(" | ");
                    log4jParamters_tGreenplumInput_8.append("QUERYSTORE" + " = " + "\"\"");
                log4jParamters_tGreenplumInput_8.append(" | ");
                    log4jParamters_tGreenplumInput_8.append("QUERY" + " = " + "\"SELECT    'N/A' plant_name,    edl_source.system_name,    'Prod2Dev' data_path,    'N/A' job_label_name,    edl_source.business,    edl_source.sub_business,    edl_source.type sbdt_type,    edl_source.schema_name sbdt_schema_name,    edl_source.comment sbdt_comment,    edl_source.pod  FROM    sbdt.edl_connection,    sbdt.edl_source  WHERE    sbdt.edl_connection.system_name=edl_source.system_name AND    lower(edl_source.system_name) = lower('\" + context.GP_SOURCE_NAME + \"')\"  ");
                log4jParamters_tGreenplumInput_8.append(" | ");
                    log4jParamters_tGreenplumInput_8.append("USE_CURSOR" + " = " + "false");
                log4jParamters_tGreenplumInput_8.append(" | ");
                    log4jParamters_tGreenplumInput_8.append("TRIM_ALL_COLUMN" + " = " + "false");
                log4jParamters_tGreenplumInput_8.append(" | ");
                    log4jParamters_tGreenplumInput_8.append("TRIM_COLUMN" + " = " + "[{TRIM="+("false")+", SCHEMA_COLUMN="+("plant_name")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("system_name")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("data_path")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("job_label_name")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("business")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("sub_business")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("sbdt_type")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("sbdt_schema_name")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("sbdt_comment")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("pod")+"}]");
                log4jParamters_tGreenplumInput_8.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tGreenplumInput_8 - "  + (log4jParamters_tGreenplumInput_8) );
    		}
    	}
    	
        new BytesLimit65535_tGreenplumInput_8().limitLog4jByte();
	
    
	
		    int nb_line_tGreenplumInput_8 = 0;
		    java.sql.Connection conn_tGreenplumInput_8 = null;
		        conn_tGreenplumInput_8 = (java.sql.Connection)globalMap.get("conn_tGreenplumConnection_4");
				
				if(conn_tGreenplumInput_8 != null) {
					if(conn_tGreenplumInput_8.getMetaData() != null) {
						
						log.debug("tGreenplumInput_8 - Uses an existing connection with username '" + conn_tGreenplumInput_8.getMetaData().getUserName() + "'. Connection URL: " + conn_tGreenplumInput_8.getMetaData().getURL() + ".");
						
					}
				}
			
		    
			java.sql.Statement stmt_tGreenplumInput_8 = conn_tGreenplumInput_8.createStatement();

		    String dbquery_tGreenplumInput_8 = "SELECT\n  'N/A' plant_name,\n  edl_source.system_name,\n  'Prod2Dev' data_path,\n  'N/A' job_label_name,\n  edl_source.business,\n  edl_source.sub_business,\n  edl_source.type sbdt_type,\n  edl_source.schema_name sbdt_schema_name,\n  edl_source.comment sbdt_comment,\n  edl_source.pod\nFROM\n  sbdt.edl_connection,\n  sbdt.edl_source\nWHERE\n  sbdt.edl_connection.system_name=edl_source.system_name AND\n  lower(edl_source.system_name) = lower('" + context.GP_SOURCE_NAME + "')"
;
			
                log.debug("tGreenplumInput_8 - Executing the query: '"+dbquery_tGreenplumInput_8+"'.");
			

                       globalMap.put("tGreenplumInput_8_QUERY",dbquery_tGreenplumInput_8);

		    java.sql.ResultSet rs_tGreenplumInput_8 = null;
		try{
		    rs_tGreenplumInput_8 = stmt_tGreenplumInput_8.executeQuery(dbquery_tGreenplumInput_8);
		    java.sql.ResultSetMetaData rsmd_tGreenplumInput_8 = rs_tGreenplumInput_8.getMetaData();
		    int colQtyInRs_tGreenplumInput_8 = rsmd_tGreenplumInput_8.getColumnCount();

		    String tmpContent_tGreenplumInput_8 = null;
		    
		    
		    	log.debug("tGreenplumInput_8 - Retrieving records from the database.");
		    
		    while (rs_tGreenplumInput_8.next()) {
		        nb_line_tGreenplumInput_8++;
		        
							if(colQtyInRs_tGreenplumInput_8 < 1) {
								row7.plant_name = null;
							} else {
	                         		
        	row7.plant_name = routines.system.JDBCUtil.getString(rs_tGreenplumInput_8, 1, false);
		                    }
							if(colQtyInRs_tGreenplumInput_8 < 2) {
								row7.system_name = null;
							} else {
	                         		
        	row7.system_name = routines.system.JDBCUtil.getString(rs_tGreenplumInput_8, 2, false);
		                    }
							if(colQtyInRs_tGreenplumInput_8 < 3) {
								row7.data_path = null;
							} else {
	                         		
        	row7.data_path = routines.system.JDBCUtil.getString(rs_tGreenplumInput_8, 3, false);
		                    }
							if(colQtyInRs_tGreenplumInput_8 < 4) {
								row7.job_label_name = null;
							} else {
	                         		
        	row7.job_label_name = routines.system.JDBCUtil.getString(rs_tGreenplumInput_8, 4, false);
		                    }
							if(colQtyInRs_tGreenplumInput_8 < 5) {
								row7.business = null;
							} else {
	                         		
        	row7.business = routines.system.JDBCUtil.getString(rs_tGreenplumInput_8, 5, false);
		                    }
							if(colQtyInRs_tGreenplumInput_8 < 6) {
								row7.sub_business = null;
							} else {
	                         		
        	row7.sub_business = routines.system.JDBCUtil.getString(rs_tGreenplumInput_8, 6, false);
		                    }
							if(colQtyInRs_tGreenplumInput_8 < 7) {
								row7.sbdt_type = null;
							} else {
	                         		
        	row7.sbdt_type = routines.system.JDBCUtil.getString(rs_tGreenplumInput_8, 7, false);
		                    }
							if(colQtyInRs_tGreenplumInput_8 < 8) {
								row7.sbdt_schema_name = null;
							} else {
	                         		
        	row7.sbdt_schema_name = routines.system.JDBCUtil.getString(rs_tGreenplumInput_8, 8, false);
		                    }
							if(colQtyInRs_tGreenplumInput_8 < 9) {
								row7.sbdt_comment = null;
							} else {
	                         		
        	row7.sbdt_comment = routines.system.JDBCUtil.getString(rs_tGreenplumInput_8, 9, false);
		                    }
							if(colQtyInRs_tGreenplumInput_8 < 10) {
								row7.pod = null;
							} else {
	                         		
        	row7.pod = routines.system.JDBCUtil.getString(rs_tGreenplumInput_8, 10, false);
		                    }
					
						log.debug("tGreenplumInput_8 - Retrieving the record " + nb_line_tGreenplumInput_8 + ".");
					


 



/**
 * [tGreenplumInput_8 begin ] stop
 */
	
	/**
	 * [tGreenplumInput_8 main ] start
	 */

	

	
	
	currentComponent="tGreenplumInput_8";

	

 


	tos_count_tGreenplumInput_8++;

/**
 * [tGreenplumInput_8 main ] stop
 */

	
	/**
	 * [tSetGlobalVar_5 main ] start
	 */

	

	
	
	currentComponent="tSetGlobalVar_5";

	

			//row7
			//row7


			
				if(execStat){
					runStat.updateStatOnConnection("row7"+iterateId,1, 1);
				} 
			

		
    			if(log.isTraceEnabled()){
    				log.trace("row7 - " + (row7==null? "": row7.toLogString()));
    			}
    		

globalMap.put("plant_name", row7.plant_name);
globalMap.put("system_name", row7.system_name);
globalMap.put("data_path", row7.data_path);
globalMap.put("job_label_name", row7.job_label_name);
globalMap.put("business", row7.business);
globalMap.put("sub_business", row7.sub_business);
globalMap.put("sbdt_type", row7.sbdt_type);
globalMap.put("sbdt_schema_name", row7.sbdt_schema_name);
globalMap.put("sbdt_comment", row7.sbdt_comment);
globalMap.put("pod", row7.pod);
globalMap.put("gp_sql", "");

 


	tos_count_tSetGlobalVar_5++;

/**
 * [tSetGlobalVar_5 main ] stop
 */



	
	/**
	 * [tGreenplumInput_8 end ] start
	 */

	

	
	
	currentComponent="tGreenplumInput_8";

	

	}
}finally{
	stmt_tGreenplumInput_8.close();

}
globalMap.put("tGreenplumInput_8_NB_LINE",nb_line_tGreenplumInput_8);
	    		log.debug("tGreenplumInput_8 - Retrieved records count: "+nb_line_tGreenplumInput_8 + " .");
			

 
                if(log.isDebugEnabled())
            log.debug("tGreenplumInput_8 - "  + ("Done.") );

ok_Hash.put("tGreenplumInput_8", true);
end_Hash.put("tGreenplumInput_8", System.currentTimeMillis());




/**
 * [tGreenplumInput_8 end ] stop
 */

	
	/**
	 * [tSetGlobalVar_5 end ] start
	 */

	

	
	
	currentComponent="tSetGlobalVar_5";

	

			if(execStat){
				if(resourceMap.get("inIterateVComp") == null || !((Boolean)resourceMap.get("inIterateVComp"))){
			 		runStat.updateStatOnConnection("row7"+iterateId,2, 0); 
			 	}
			}
		
 
                if(log.isDebugEnabled())
            log.debug("tSetGlobalVar_5 - "  + ("Done.") );

ok_Hash.put("tSetGlobalVar_5", true);
end_Hash.put("tSetGlobalVar_5", System.currentTimeMillis());




/**
 * [tSetGlobalVar_5 end ] stop
 */



				}//end the resume

				
				    			if(resumeEntryMethodName == null || globalResumeTicket){
				    				resumeUtil.addLog("CHECKPOINT", "CONNECTION:SUBJOB_OK:tGreenplumInput_8:OnSubjobOk", "", Thread.currentThread().getId() + "", "", "", "", "", "");
								}	    				    			
					    	
								if(execStat){    	
									runStat.updateStatOnConnection("OnSubjobOk25", 0, "ok");
								} 
							
							tJava_10Process(globalMap); 
						



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage());
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tGreenplumInput_8 finally ] start
	 */

	

	
	
	currentComponent="tGreenplumInput_8";

	

 



/**
 * [tGreenplumInput_8 finally ] stop
 */

	
	/**
	 * [tSetGlobalVar_5 finally ] start
	 */

	

	
	
	currentComponent="tSetGlobalVar_5";

	

 



/**
 * [tSetGlobalVar_5 finally ] stop
 */



				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tGreenplumInput_8_SUBPROCESS_STATE", 1);
	}
	

public void tJava_10Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tJava_10_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tJava_10 begin ] start
	 */

	

	
		
		ok_Hash.put("tJava_10", false);
		start_Hash.put("tJava_10", System.currentTimeMillis());
		
	
	currentComponent="tJava_10";

	
		int tos_count_tJava_10 = 0;
		
    	class BytesLimit65535_tJava_10{
    		public void limitLog4jByte() throws Exception{
    			
    		}
    	}
    	
        new BytesLimit65535_tJava_10().limitLog4jByte();


//context.SOURCE_HOST=((String)globalMap.get("host_name"));
//context.SOURCE_DATABASE= ((String)globalMap.get("database"));
//context.SOURCE_USER= ((String)globalMap.get("user_name"));
//context.SOURCE_PORT= ((Integer)globalMap.get("port"));
//context.SOURCE_PASSWORD=((String)globalMap.get("password"));
context.LOG_SYSTEM_NAME=(String)globalMap.get("system_name");
context.LOG_DATA_PATH=(String)globalMap.get("data_path");
context.LOG_JOB_NAME=context.JOB_LABEL_NAME;
context.LOG_PLANT_NAME=context.PLANT_NAME;
context.LOG_TECHNOLOGY="Talend";
globalMap.put("orig_table_name", context.getProperty("TABLE_NAME"));
if (context.getProperty("TABLE_NAME").length() != 0) 
{
  String table_list=context.getProperty("TABLE_NAME");
  table_list=(table_list.replace(" ", "")).replace(",","','");
  //context.setProperty("TABLE_NAME", " AND UPPER(target_table_name) IN ('" + table_list.toUpperCase() + "')");
  context.TABLE_NAME=" AND UPPER(target_table_name) IN ('" + table_list.toUpperCase() + "') ";
}



//System.out.println(globalMap.get("gp_sql"));
//context.getProperty("GP_SOURCE_NAME")
//context.getProperty("TABLE_NAME")
//System.out.println("SELECT target_table_name as log_table_name FROM sbdt.edl_table WHERE enabled='Y' and (source_schema <> 'na' or //'HVR_stats'='" + ((String)globalMap.get("job_name")) + "')" +  " and system_name = '" + context.getProperty("GP_SOURCE_NAME") + "' and //update_type in ('incremental', 'full','append','softdelete')" + context.getProperty("TABLE_NAME") +" order by load_order");

 



/**
 * [tJava_10 begin ] stop
 */
	
	/**
	 * [tJava_10 main ] start
	 */

	

	
	
	currentComponent="tJava_10";

	

 


	tos_count_tJava_10++;

/**
 * [tJava_10 main ] stop
 */
	
	/**
	 * [tJava_10 end ] start
	 */

	

	
	
	currentComponent="tJava_10";

	

 

ok_Hash.put("tJava_10", true);
end_Hash.put("tJava_10", System.currentTimeMillis());

   			if (!(context.RUN_ID>0)) {
   				
					if(execStat){   
   	 					runStat.updateStatOnConnection("NoRunID", 0, "true");
					}
				
    			tJava_2Process(globalMap);
   			}

			   
   				else{
					if(execStat){   
   	 					runStat.updateStatOnConnection("NoRunID", 0, "false");
					}   	 
   				}
   			if (context.RUN_ID>0) {
   				
					if(execStat){   
   	 					runStat.updateStatOnConnection("RunIDOK", 0, "true");
					}
				
    			tJava_3Process(globalMap);
   			}

			   
   				else{
					if(execStat){   
   	 					runStat.updateStatOnConnection("RunIDOK", 0, "false");
					}   	 
   				}



/**
 * [tJava_10 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage());
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tJava_10 finally ] start
	 */

	

	
	
	currentComponent="tJava_10";

	

 



/**
 * [tJava_10 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tJava_10_SUBPROCESS_STATE", 1);
	}
	

public void tJava_16Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tJava_16_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tJava_16 begin ] start
	 */

	

	
		
		ok_Hash.put("tJava_16", false);
		start_Hash.put("tJava_16", System.currentTimeMillis());
		
	
	currentComponent="tJava_16";

	
		int tos_count_tJava_16 = 0;
		
    	class BytesLimit65535_tJava_16{
    		public void limitLog4jByte() throws Exception{
    			
    		}
    	}
    	
        new BytesLimit65535_tJava_16().limitLog4jByte();


context.SOURCE_PORT = 5432;
 



/**
 * [tJava_16 begin ] stop
 */
	
	/**
	 * [tJava_16 main ] start
	 */

	

	
	
	currentComponent="tJava_16";

	

 


	tos_count_tJava_16++;

/**
 * [tJava_16 main ] stop
 */
	
	/**
	 * [tJava_16 end ] start
	 */

	

	
	
	currentComponent="tJava_16";

	

 

ok_Hash.put("tJava_16", true);
end_Hash.put("tJava_16", System.currentTimeMillis());

				if(execStat){   
   	 				runStat.updateStatOnConnection("OnComponentOk8", 0, "ok");
				}
				tSetGlobalVar_3Process(globalMap);



/**
 * [tJava_16 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage());
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tJava_16 finally ] start
	 */

	

	
	
	currentComponent="tJava_16";

	

 



/**
 * [tJava_16 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tJava_16_SUBPROCESS_STATE", 1);
	}
	

public void tFileOutputDelimitedGE_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tFileOutputDelimitedGE_1_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;





	
	/**
	 * [tFileOutputDelimitedGE_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tFileOutputDelimitedGE_1", false);
		start_Hash.put("tFileOutputDelimitedGE_1", System.currentTimeMillis());
		
	
	currentComponent="tFileOutputDelimitedGE_1";

	
		int tos_count_tFileOutputDelimitedGE_1 = 0;
		
    	class BytesLimit65535_tFileOutputDelimitedGE_1{
    		public void limitLog4jByte() throws Exception{
    			
    		}
    	}
    	
        new BytesLimit65535_tFileOutputDelimitedGE_1().limitLog4jByte();

    String log4jFileOutputDelimitedParamters_tFileOutputDelimitedGE_1 = "";
    log4jFileOutputDelimitedParamters_tFileOutputDelimitedGE_1 = log4jFileOutputDelimitedParamters_tFileOutputDelimitedGE_1 + "FILENAME = " + context.ETL_STORAGE_PATH + "/" +context.GP_SOURCE_NAME + "/" +((String)globalMap.get("timestamp"))+".csv" + " | ";
    log4jFileOutputDelimitedParamters_tFileOutputDelimitedGE_1 = log4jFileOutputDelimitedParamters_tFileOutputDelimitedGE_1 + "CSV_OPTION = " + false + " | ";
    log4jFileOutputDelimitedParamters_tFileOutputDelimitedGE_1 = log4jFileOutputDelimitedParamters_tFileOutputDelimitedGE_1 + "FIELDSEPARATOR = " + ";" + " | ";
    log4jFileOutputDelimitedParamters_tFileOutputDelimitedGE_1 = log4jFileOutputDelimitedParamters_tFileOutputDelimitedGE_1 + "INCLUDE_HEADER = " + false + " | ";
        log4jFileOutputDelimitedParamters_tFileOutputDelimitedGE_1 = log4jFileOutputDelimitedParamters_tFileOutputDelimitedGE_1 + "COMPRESS = " + false + " | ";
    log4jFileOutputDelimitedParamters_tFileOutputDelimitedGE_1 = log4jFileOutputDelimitedParamters_tFileOutputDelimitedGE_1 + "APPEND = " + false + " | ";
    log4jFileOutputDelimitedParamters_tFileOutputDelimitedGE_1 = log4jFileOutputDelimitedParamters_tFileOutputDelimitedGE_1 + "CREATE_DIRECTORY_IF_NOT_EXISTS = " + true + " | ";
    log4jFileOutputDelimitedParamters_tFileOutputDelimitedGE_1 = log4jFileOutputDelimitedParamters_tFileOutputDelimitedGE_1 + "SPLIT_INTO_SEVERAL_FILES = " + false + " | ";
    log4jFileOutputDelimitedParamters_tFileOutputDelimitedGE_1 = log4jFileOutputDelimitedParamters_tFileOutputDelimitedGE_1 + "OUTPUT_IN_ROW_MODE = " + false + " | ";

    log4jFileOutputDelimitedParamters_tFileOutputDelimitedGE_1 = "tFileOutputDelimitedGE_1 - Parameters:" + log4jFileOutputDelimitedParamters_tFileOutputDelimitedGE_1;
    log.debug(log4jFileOutputDelimitedParamters_tFileOutputDelimitedGE_1);
    StringBuffer log4jSb_tFileOutputDelimitedGE_1 = new StringBuffer();
    log.info("tFileOutputDelimitedGE_1 - Start to work.");
String fileName_tFileOutputDelimitedGE_1 = "";
    fileName_tFileOutputDelimitedGE_1 = (new java.io.File(context.ETL_STORAGE_PATH + "/" +context.GP_SOURCE_NAME + "/" +((String)globalMap.get("timestamp"))+".csv")).getAbsolutePath().replace("\\","/");
    String fullName_tFileOutputDelimitedGE_1 = null;
    String extension_tFileOutputDelimitedGE_1 = null;
    String directory_tFileOutputDelimitedGE_1 = null;
    if((fileName_tFileOutputDelimitedGE_1.indexOf("/") != -1)) {
        if(fileName_tFileOutputDelimitedGE_1.lastIndexOf(".") < fileName_tFileOutputDelimitedGE_1.lastIndexOf("/")) {
            fullName_tFileOutputDelimitedGE_1 = fileName_tFileOutputDelimitedGE_1;
            extension_tFileOutputDelimitedGE_1 = "";
        } else {
            fullName_tFileOutputDelimitedGE_1 = fileName_tFileOutputDelimitedGE_1.substring(0, fileName_tFileOutputDelimitedGE_1.lastIndexOf("."));
            extension_tFileOutputDelimitedGE_1 = fileName_tFileOutputDelimitedGE_1.substring(fileName_tFileOutputDelimitedGE_1.lastIndexOf("."));
        }
        directory_tFileOutputDelimitedGE_1 = fileName_tFileOutputDelimitedGE_1.substring(0, fileName_tFileOutputDelimitedGE_1.lastIndexOf("/"));
    } else {
        if(fileName_tFileOutputDelimitedGE_1.lastIndexOf(".") != -1) {
            fullName_tFileOutputDelimitedGE_1 = fileName_tFileOutputDelimitedGE_1.substring(0, fileName_tFileOutputDelimitedGE_1.lastIndexOf("."));
            extension_tFileOutputDelimitedGE_1 = fileName_tFileOutputDelimitedGE_1.substring(fileName_tFileOutputDelimitedGE_1.lastIndexOf("."));
        } else {
            fullName_tFileOutputDelimitedGE_1 = fileName_tFileOutputDelimitedGE_1;
            extension_tFileOutputDelimitedGE_1 = "";
        }
        directory_tFileOutputDelimitedGE_1 = "";
    }
    boolean isFileGenerated_tFileOutputDelimitedGE_1 = true;
    java.io.File filetFileOutputDelimitedGE_1 = new java.io.File(fileName_tFileOutputDelimitedGE_1);
    globalMap.put("tFileOutputDelimitedGE_1_FILE_NAME",fileName_tFileOutputDelimitedGE_1);
            int nb_line_tFileOutputDelimitedGE_1 = 0;
            int splitEvery_tFileOutputDelimitedGE_1 = 1000;
            int splitedFileNo_tFileOutputDelimitedGE_1 = 0;
            int currentRow_tFileOutputDelimitedGE_1 = 0;

            final String OUT_DELIM_tFileOutputDelimitedGE_1 = /** Start field tFileOutputDelimitedGE_1:FIELDSEPARATOR */";"/** End field tFileOutputDelimitedGE_1:FIELDSEPARATOR */;

            final String OUT_DELIM_ROWSEP_tFileOutputDelimitedGE_1 = /** Start field tFileOutputDelimitedGE_1:ROWSEPARATOR */"\n"/** End field tFileOutputDelimitedGE_1:ROWSEPARATOR */;

                    //create directory only if not exists
                    if(directory_tFileOutputDelimitedGE_1 != null && directory_tFileOutputDelimitedGE_1.trim().length() != 0) {
                        java.io.File dir_tFileOutputDelimitedGE_1 = new java.io.File(directory_tFileOutputDelimitedGE_1);
                        if(!dir_tFileOutputDelimitedGE_1.exists()) {
                                log.info("tFileOutputDelimitedGE_1 - Creating directory '" + dir_tFileOutputDelimitedGE_1.getCanonicalPath() +"'.");
                            dir_tFileOutputDelimitedGE_1.mkdirs();
                                log.info("tFileOutputDelimitedGE_1 - The directoy '"+ dir_tFileOutputDelimitedGE_1.getCanonicalPath() + "' has been created successfully.");
                        }
                    }

                        //routines.system.Row
                        java.io.Writer outtFileOutputDelimitedGE_1 = null;
                        outtFileOutputDelimitedGE_1 = new java.io.BufferedWriter(new java.io.OutputStreamWriter(
                        new java.io.FileOutputStream(fileName_tFileOutputDelimitedGE_1, false),"ISO-8859-15"));


        resourceMap.put("out_tFileOutputDelimitedGE_1", outtFileOutputDelimitedGE_1);
resourceMap.put("nb_line_tFileOutputDelimitedGE_1", nb_line_tFileOutputDelimitedGE_1);
 



/**
 * [tFileOutputDelimitedGE_1 begin ] stop
 */
	
	/**
	 * [tFileOutputDelimitedGE_1 main ] start
	 */

	

	
	
	currentComponent="tFileOutputDelimitedGE_1";

	




 


	tos_count_tFileOutputDelimitedGE_1++;

/**
 * [tFileOutputDelimitedGE_1 main ] stop
 */
	
	/**
	 * [tFileOutputDelimitedGE_1 end ] start
	 */

	

	
	
	currentComponent="tFileOutputDelimitedGE_1";

	



		
	   		synchronized (multiThreadLockWrite) {
		
			
					if(outtFileOutputDelimitedGE_1!=null) {
						outtFileOutputDelimitedGE_1.flush();
						outtFileOutputDelimitedGE_1.close();
					}
				
				globalMap.put("tFileOutputDelimitedGE_1_NB_LINE",nb_line_tFileOutputDelimitedGE_1);
				globalMap.put("tFileOutputDelimitedGE_1_FILE_NAME",fileName_tFileOutputDelimitedGE_1);
			
		
			}
		
		
		resourceMap.put("finish_tFileOutputDelimitedGE_1", true);
	
				log.info("tFileOutputDelimitedGE_1 - Written records count: " + nb_line_tFileOutputDelimitedGE_1 + " .");
				log.info("tFileOutputDelimitedGE_1 - Done.");

 

ok_Hash.put("tFileOutputDelimitedGE_1", true);
end_Hash.put("tFileOutputDelimitedGE_1", System.currentTimeMillis());




/**
 * [tFileOutputDelimitedGE_1 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage());
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tFileOutputDelimitedGE_1 finally ] start
	 */

	

	
	
	currentComponent="tFileOutputDelimitedGE_1";

	


		if(resourceMap.get("finish_tFileOutputDelimitedGE_1") == null){ 
			
		   		synchronized (multiThreadLockWrite) {
			
				
						java.io.Writer outtFileOutputDelimitedGE_1 = (java.io.Writer)resourceMap.get("out_tFileOutputDelimitedGE_1");
						if(outtFileOutputDelimitedGE_1!=null) {
							outtFileOutputDelimitedGE_1.flush();
							outtFileOutputDelimitedGE_1.close();
						}
					
				
				}
			
			
		}
	

 



/**
 * [tFileOutputDelimitedGE_1 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tFileOutputDelimitedGE_1_SUBPROCESS_STATE", 1);
	}
	


public static class row_talendLogs_LOGSStruct implements routines.system.IPersistableRow<row_talendLogs_LOGSStruct> {
    final static byte[] commonByteArrayLock_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Prod2Dev_with_GP_FDIST = new byte[0];
    static byte[] commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Prod2Dev_with_GP_FDIST = new byte[0];

	
			    public java.util.Date moment;

				public java.util.Date getMoment () {
					return this.moment;
				}
				
			    public String pid;

				public String getPid () {
					return this.pid;
				}
				
			    public String root_pid;

				public String getRoot_pid () {
					return this.root_pid;
				}
				
			    public String father_pid;

				public String getFather_pid () {
					return this.father_pid;
				}
				
			    public String project;

				public String getProject () {
					return this.project;
				}
				
			    public String job;

				public String getJob () {
					return this.job;
				}
				
			    public String context;

				public String getContext () {
					return this.context;
				}
				
			    public Integer priority;

				public Integer getPriority () {
					return this.priority;
				}
				
			    public String type;

				public String getType () {
					return this.type;
				}
				
			    public String origin;

				public String getOrigin () {
					return this.origin;
				}
				
			    public String message;

				public String getMessage () {
					return this.message;
				}
				
			    public Integer code;

				public Integer getCode () {
					return this.code;
				}
				



	private java.util.Date readDate(ObjectInputStream dis) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(dis.readLong());
		}
		return dateReturn;
	}

    private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException{
		if(date1 == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeLong(date1.getTime());
    	}
    }

	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Prod2Dev_with_GP_FDIST.length) {
				if(length < 1024 && commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Prod2Dev_with_GP_FDIST.length == 0) {
   					commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Prod2Dev_with_GP_FDIST = new byte[1024];
				} else {
   					commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Prod2Dev_with_GP_FDIST = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Prod2Dev_with_GP_FDIST, 0, length);
			strReturn = new String(commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Prod2Dev_with_GP_FDIST, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
	private Integer readInteger(ObjectInputStream dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}

	private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException{
		if(intNum == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeInt(intNum);
    	}
	}

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Prod2Dev_with_GP_FDIST) {

        	try {

        		int length = 0;
		
					this.moment = readDate(dis);
					
					this.pid = readString(dis);
					
					this.root_pid = readString(dis);
					
					this.father_pid = readString(dis);
					
					this.project = readString(dis);
					
					this.job = readString(dis);
					
					this.context = readString(dis);
					
						this.priority = readInteger(dis);
					
					this.type = readString(dis);
					
					this.origin = readString(dis);
					
					this.message = readString(dis);
					
						this.code = readInteger(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// java.util.Date
				
						writeDate(this.moment,dos);
					
					// String
				
						writeString(this.pid,dos);
					
					// String
				
						writeString(this.root_pid,dos);
					
					// String
				
						writeString(this.father_pid,dos);
					
					// String
				
						writeString(this.project,dos);
					
					// String
				
						writeString(this.job,dos);
					
					// String
				
						writeString(this.context,dos);
					
					// Integer
				
						writeInteger(this.priority,dos);
					
					// String
				
						writeString(this.type,dos);
					
					// String
				
						writeString(this.origin,dos);
					
					// String
				
						writeString(this.message,dos);
					
					// Integer
				
						writeInteger(this.code,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("moment="+String.valueOf(moment));
		sb.append(",pid="+pid);
		sb.append(",root_pid="+root_pid);
		sb.append(",father_pid="+father_pid);
		sb.append(",project="+project);
		sb.append(",job="+job);
		sb.append(",context="+context);
		sb.append(",priority="+String.valueOf(priority));
		sb.append(",type="+type);
		sb.append(",origin="+origin);
		sb.append(",message="+message);
		sb.append(",code="+String.valueOf(code));
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				if(moment == null){
        					sb.append("<null>");
        				}else{
            				sb.append(moment);
            			}
            		
        			sb.append("|");
        		
        				if(pid == null){
        					sb.append("<null>");
        				}else{
            				sb.append(pid);
            			}
            		
        			sb.append("|");
        		
        				if(root_pid == null){
        					sb.append("<null>");
        				}else{
            				sb.append(root_pid);
            			}
            		
        			sb.append("|");
        		
        				if(father_pid == null){
        					sb.append("<null>");
        				}else{
            				sb.append(father_pid);
            			}
            		
        			sb.append("|");
        		
        				if(project == null){
        					sb.append("<null>");
        				}else{
            				sb.append(project);
            			}
            		
        			sb.append("|");
        		
        				if(job == null){
        					sb.append("<null>");
        				}else{
            				sb.append(job);
            			}
            		
        			sb.append("|");
        		
        				if(context == null){
        					sb.append("<null>");
        				}else{
            				sb.append(context);
            			}
            		
        			sb.append("|");
        		
        				if(priority == null){
        					sb.append("<null>");
        				}else{
            				sb.append(priority);
            			}
            		
        			sb.append("|");
        		
        				if(type == null){
        					sb.append("<null>");
        				}else{
            				sb.append(type);
            			}
            		
        			sb.append("|");
        		
        				if(origin == null){
        					sb.append("<null>");
        				}else{
            				sb.append(origin);
            			}
            		
        			sb.append("|");
        		
        				if(message == null){
        					sb.append("<null>");
        				}else{
            				sb.append(message);
            			}
            		
        			sb.append("|");
        		
        				if(code == null){
        					sb.append("<null>");
        				}else{
            				sb.append(code);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(row_talendLogs_LOGSStruct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}
public void talendLogs_LOGSProcess(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("talendLogs_LOGS_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
		String currentVirtualComponent = null;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;



		row_talendLogs_LOGSStruct row_talendLogs_LOGS = new row_talendLogs_LOGSStruct();




	
	/**
	 * [talendLogs_CONSOLE begin ] start
	 */

	

	
		
		ok_Hash.put("talendLogs_CONSOLE", false);
		start_Hash.put("talendLogs_CONSOLE", System.currentTimeMillis());
		
	
		currentVirtualComponent = "talendLogs_CONSOLE";
	
	currentComponent="talendLogs_CONSOLE";

	
			if (execStat) {
				if(resourceMap.get("inIterateVComp") == null){
					
						runStat.updateStatOnConnection("Main" + iterateId, 0, 0);
					
				}
			} 

		
		int tos_count_talendLogs_CONSOLE = 0;
		
                if(log.isDebugEnabled())
            log.debug("talendLogs_CONSOLE - "  + ("Start to work.") );
    	class BytesLimit65535_talendLogs_CONSOLE{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_talendLogs_CONSOLE = new StringBuilder();
            log4jParamters_talendLogs_CONSOLE.append("Parameters:");
                    log4jParamters_talendLogs_CONSOLE.append("BASIC_MODE" + " = " + "true");
                log4jParamters_talendLogs_CONSOLE.append(" | ");
                    log4jParamters_talendLogs_CONSOLE.append("TABLE_PRINT" + " = " + "false");
                log4jParamters_talendLogs_CONSOLE.append(" | ");
                    log4jParamters_talendLogs_CONSOLE.append("VERTICAL" + " = " + "false");
                log4jParamters_talendLogs_CONSOLE.append(" | ");
                    log4jParamters_talendLogs_CONSOLE.append("FIELDSEPARATOR" + " = " + "\"|\"");
                log4jParamters_talendLogs_CONSOLE.append(" | ");
                    log4jParamters_talendLogs_CONSOLE.append("PRINT_HEADER" + " = " + "false");
                log4jParamters_talendLogs_CONSOLE.append(" | ");
                    log4jParamters_talendLogs_CONSOLE.append("PRINT_UNIQUE_NAME" + " = " + "false");
                log4jParamters_talendLogs_CONSOLE.append(" | ");
                    log4jParamters_talendLogs_CONSOLE.append("PRINT_COLNAMES" + " = " + "false");
                log4jParamters_talendLogs_CONSOLE.append(" | ");
                    log4jParamters_talendLogs_CONSOLE.append("USE_FIXED_LENGTH" + " = " + "false");
                log4jParamters_talendLogs_CONSOLE.append(" | ");
                    log4jParamters_talendLogs_CONSOLE.append("PRINT_CONTENT_WITH_LOG4J" + " = " + "true");
                log4jParamters_talendLogs_CONSOLE.append(" | ");
                if(log.isDebugEnabled())
            log.debug("talendLogs_CONSOLE - "  + (log4jParamters_talendLogs_CONSOLE) );
    		}
    	}
    	
        new BytesLimit65535_talendLogs_CONSOLE().limitLog4jByte();

	///////////////////////
	
		final String OUTPUT_FIELD_SEPARATOR_talendLogs_CONSOLE = "|";
		java.io.PrintStream consoleOut_talendLogs_CONSOLE = null;	

 		StringBuilder strBuffer_talendLogs_CONSOLE = null;
		int nb_line_talendLogs_CONSOLE = 0;
///////////////////////    			



 



/**
 * [talendLogs_CONSOLE begin ] stop
 */



	
	/**
	 * [talendLogs_LOGS begin ] start
	 */

	

	
		
		ok_Hash.put("talendLogs_LOGS", false);
		start_Hash.put("talendLogs_LOGS", System.currentTimeMillis());
		
	
		currentVirtualComponent = "talendLogs_LOGS";
	
	currentComponent="talendLogs_LOGS";

	
		int tos_count_talendLogs_LOGS = 0;
		
                if(log.isDebugEnabled())
            log.debug("talendLogs_LOGS - "  + ("Start to work.") );
    	class BytesLimit65535_talendLogs_LOGS{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_talendLogs_LOGS = new StringBuilder();
            log4jParamters_talendLogs_LOGS.append("Parameters:");
                    log4jParamters_talendLogs_LOGS.append("CATCH_JAVA_EXCEPTION" + " = " + "true");
                log4jParamters_talendLogs_LOGS.append(" | ");
                    log4jParamters_talendLogs_LOGS.append("CATCH_TDIE" + " = " + "true");
                log4jParamters_talendLogs_LOGS.append(" | ");
                    log4jParamters_talendLogs_LOGS.append("CATCH_TWARN" + " = " + "true");
                log4jParamters_talendLogs_LOGS.append(" | ");
                    log4jParamters_talendLogs_LOGS.append("CATCH_TACTIONFAILURE" + " = " + "true");
                log4jParamters_talendLogs_LOGS.append(" | ");
                if(log.isDebugEnabled())
            log.debug("talendLogs_LOGS - "  + (log4jParamters_talendLogs_LOGS) );
    		}
    	}
    	
        new BytesLimit65535_talendLogs_LOGS().limitLog4jByte();

	for (LogCatcherUtils.LogCatcherMessage lcm : talendLogs_LOGS.getMessages()) {
		row_talendLogs_LOGS.type = lcm.getType();
		row_talendLogs_LOGS.origin = (lcm.getOrigin()==null || lcm.getOrigin().length()<1 ? null : lcm.getOrigin());
		row_talendLogs_LOGS.priority = lcm.getPriority();
		row_talendLogs_LOGS.message = lcm.getMessage();
		row_talendLogs_LOGS.code = lcm.getCode();
		
		row_talendLogs_LOGS.moment = java.util.Calendar.getInstance().getTime();
	
    	row_talendLogs_LOGS.pid = pid;
		row_talendLogs_LOGS.root_pid = rootPid;
		row_talendLogs_LOGS.father_pid = fatherPid;
	
    	row_talendLogs_LOGS.project = projectName;
    	row_talendLogs_LOGS.job = jobName;
    	row_talendLogs_LOGS.context = contextStr;
    		
 



/**
 * [talendLogs_LOGS begin ] stop
 */
	
	/**
	 * [talendLogs_LOGS main ] start
	 */

	

	
	
		currentVirtualComponent = "talendLogs_LOGS";
	
	currentComponent="talendLogs_LOGS";

	

 


	tos_count_talendLogs_LOGS++;

/**
 * [talendLogs_LOGS main ] stop
 */

	
	/**
	 * [talendLogs_CONSOLE main ] start
	 */

	

	
	
		currentVirtualComponent = "talendLogs_CONSOLE";
	
	currentComponent="talendLogs_CONSOLE";

	

			//Main
			//row_talendLogs_LOGS


			
				if(execStat){
					runStat.updateStatOnConnection("Main"+iterateId,1, 1);
				} 
			

		
///////////////////////		
						



				strBuffer_talendLogs_CONSOLE = new StringBuilder();




   				
	    		if(row_talendLogs_LOGS.moment != null) { //              
                    							
       
				strBuffer_talendLogs_CONSOLE.append(
								FormatterUtils.format_Date(row_talendLogs_LOGS.moment, "yyyy-MM-dd HH:mm:ss")				
				);


							
	    		} //  			

    			strBuffer_talendLogs_CONSOLE.append("|");
    			


   				
	    		if(row_talendLogs_LOGS.pid != null) { //              
                    							
       
				strBuffer_talendLogs_CONSOLE.append(
				                String.valueOf(row_talendLogs_LOGS.pid)							
				);


							
	    		} //  			

    			strBuffer_talendLogs_CONSOLE.append("|");
    			


   				
	    		if(row_talendLogs_LOGS.root_pid != null) { //              
                    							
       
				strBuffer_talendLogs_CONSOLE.append(
				                String.valueOf(row_talendLogs_LOGS.root_pid)							
				);


							
	    		} //  			

    			strBuffer_talendLogs_CONSOLE.append("|");
    			


   				
	    		if(row_talendLogs_LOGS.father_pid != null) { //              
                    							
       
				strBuffer_talendLogs_CONSOLE.append(
				                String.valueOf(row_talendLogs_LOGS.father_pid)							
				);


							
	    		} //  			

    			strBuffer_talendLogs_CONSOLE.append("|");
    			


   				
	    		if(row_talendLogs_LOGS.project != null) { //              
                    							
       
				strBuffer_talendLogs_CONSOLE.append(
				                String.valueOf(row_talendLogs_LOGS.project)							
				);


							
	    		} //  			

    			strBuffer_talendLogs_CONSOLE.append("|");
    			


   				
	    		if(row_talendLogs_LOGS.job != null) { //              
                    							
       
				strBuffer_talendLogs_CONSOLE.append(
				                String.valueOf(row_talendLogs_LOGS.job)							
				);


							
	    		} //  			

    			strBuffer_talendLogs_CONSOLE.append("|");
    			


   				
	    		if(row_talendLogs_LOGS.context != null) { //              
                    							
       
				strBuffer_talendLogs_CONSOLE.append(
				                String.valueOf(row_talendLogs_LOGS.context)							
				);


							
	    		} //  			

    			strBuffer_talendLogs_CONSOLE.append("|");
    			


   				
	    		if(row_talendLogs_LOGS.priority != null) { //              
                    							
       
				strBuffer_talendLogs_CONSOLE.append(
				                String.valueOf(row_talendLogs_LOGS.priority)							
				);


							
	    		} //  			

    			strBuffer_talendLogs_CONSOLE.append("|");
    			


   				
	    		if(row_talendLogs_LOGS.type != null) { //              
                    							
       
				strBuffer_talendLogs_CONSOLE.append(
				                String.valueOf(row_talendLogs_LOGS.type)							
				);


							
	    		} //  			

    			strBuffer_talendLogs_CONSOLE.append("|");
    			


   				
	    		if(row_talendLogs_LOGS.origin != null) { //              
                    							
       
				strBuffer_talendLogs_CONSOLE.append(
				                String.valueOf(row_talendLogs_LOGS.origin)							
				);


							
	    		} //  			

    			strBuffer_talendLogs_CONSOLE.append("|");
    			


   				
	    		if(row_talendLogs_LOGS.message != null) { //              
                    							
       
				strBuffer_talendLogs_CONSOLE.append(
				                String.valueOf(row_talendLogs_LOGS.message)							
				);


							
	    		} //  			

    			strBuffer_talendLogs_CONSOLE.append("|");
    			


   				
	    		if(row_talendLogs_LOGS.code != null) { //              
                    							
       
				strBuffer_talendLogs_CONSOLE.append(
				                String.valueOf(row_talendLogs_LOGS.code)							
				);


							
	    		} //  			
 

                    if (globalMap.get("tLogRow_CONSOLE")!=null)
                    {
                    	consoleOut_talendLogs_CONSOLE = (java.io.PrintStream) globalMap.get("tLogRow_CONSOLE");
                    }
                    else
                    {
                    	consoleOut_talendLogs_CONSOLE = new java.io.PrintStream(new java.io.BufferedOutputStream(System.out));
                    	globalMap.put("tLogRow_CONSOLE",consoleOut_talendLogs_CONSOLE);
                    }
                    	log.info("talendLogs_CONSOLE - Content of row "+(nb_line_talendLogs_CONSOLE+1)+": " + strBuffer_talendLogs_CONSOLE.toString());
                    consoleOut_talendLogs_CONSOLE.println(strBuffer_talendLogs_CONSOLE.toString());
                    consoleOut_talendLogs_CONSOLE.flush();
                    nb_line_talendLogs_CONSOLE++;
//////

//////                    
                    
///////////////////////    			

 


	tos_count_talendLogs_CONSOLE++;

/**
 * [talendLogs_CONSOLE main ] stop
 */



	
	/**
	 * [talendLogs_LOGS end ] start
	 */

	

	
	
		currentVirtualComponent = "talendLogs_LOGS";
	
	currentComponent="talendLogs_LOGS";

	
	}
 
                if(log.isDebugEnabled())
            log.debug("talendLogs_LOGS - "  + ("Done.") );

ok_Hash.put("talendLogs_LOGS", true);
end_Hash.put("talendLogs_LOGS", System.currentTimeMillis());




/**
 * [talendLogs_LOGS end ] stop
 */

	
	/**
	 * [talendLogs_CONSOLE end ] start
	 */

	

	
	
		currentVirtualComponent = "talendLogs_CONSOLE";
	
	currentComponent="talendLogs_CONSOLE";

	


//////
//////
globalMap.put("talendLogs_CONSOLE_NB_LINE",nb_line_talendLogs_CONSOLE);
                if(log.isInfoEnabled())
            log.info("talendLogs_CONSOLE - "  + ("Printed row count: ")  + (nb_line_talendLogs_CONSOLE)  + (".") );

///////////////////////    			

			if(execStat){
				if(resourceMap.get("inIterateVComp") == null || !((Boolean)resourceMap.get("inIterateVComp"))){
			 		runStat.updateStatOnConnection("Main"+iterateId,2, 0); 
			 	}
			}
		
 
                if(log.isDebugEnabled())
            log.debug("talendLogs_CONSOLE - "  + ("Done.") );

ok_Hash.put("talendLogs_CONSOLE", true);
end_Hash.put("talendLogs_CONSOLE", System.currentTimeMillis());




/**
 * [talendLogs_CONSOLE end ] stop
 */



				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage());
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
					te.setVirtualComponentName(currentVirtualComponent);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [talendLogs_LOGS finally ] start
	 */

	

	
	
		currentVirtualComponent = "talendLogs_LOGS";
	
	currentComponent="talendLogs_LOGS";

	

 



/**
 * [talendLogs_LOGS finally ] stop
 */

	
	/**
	 * [talendLogs_CONSOLE finally ] start
	 */

	

	
	
		currentVirtualComponent = "talendLogs_CONSOLE";
	
	currentComponent="talendLogs_CONSOLE";

	

 



/**
 * [talendLogs_CONSOLE finally ] stop
 */



				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("talendLogs_LOGS_SUBPROCESS_STATE", 1);
	}
	


public static class row_talendStats_STATSStruct implements routines.system.IPersistableRow<row_talendStats_STATSStruct> {
    final static byte[] commonByteArrayLock_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Prod2Dev_with_GP_FDIST = new byte[0];
    static byte[] commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Prod2Dev_with_GP_FDIST = new byte[0];

	
			    public java.util.Date moment;

				public java.util.Date getMoment () {
					return this.moment;
				}
				
			    public String pid;

				public String getPid () {
					return this.pid;
				}
				
			    public String father_pid;

				public String getFather_pid () {
					return this.father_pid;
				}
				
			    public String root_pid;

				public String getRoot_pid () {
					return this.root_pid;
				}
				
			    public Long system_pid;

				public Long getSystem_pid () {
					return this.system_pid;
				}
				
			    public String project;

				public String getProject () {
					return this.project;
				}
				
			    public String job;

				public String getJob () {
					return this.job;
				}
				
			    public String job_repository_id;

				public String getJob_repository_id () {
					return this.job_repository_id;
				}
				
			    public String job_version;

				public String getJob_version () {
					return this.job_version;
				}
				
			    public String context;

				public String getContext () {
					return this.context;
				}
				
			    public String origin;

				public String getOrigin () {
					return this.origin;
				}
				
			    public String message_type;

				public String getMessage_type () {
					return this.message_type;
				}
				
			    public String message;

				public String getMessage () {
					return this.message;
				}
				
			    public Long duration;

				public Long getDuration () {
					return this.duration;
				}
				



	private java.util.Date readDate(ObjectInputStream dis) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(dis.readLong());
		}
		return dateReturn;
	}

    private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException{
		if(date1 == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeLong(date1.getTime());
    	}
    }

	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Prod2Dev_with_GP_FDIST.length) {
				if(length < 1024 && commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Prod2Dev_with_GP_FDIST.length == 0) {
   					commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Prod2Dev_with_GP_FDIST = new byte[1024];
				} else {
   					commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Prod2Dev_with_GP_FDIST = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Prod2Dev_with_GP_FDIST, 0, length);
			strReturn = new String(commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Prod2Dev_with_GP_FDIST, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Prod2Dev_with_GP_FDIST) {

        	try {

        		int length = 0;
		
					this.moment = readDate(dis);
					
					this.pid = readString(dis);
					
					this.father_pid = readString(dis);
					
					this.root_pid = readString(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.system_pid = null;
           				} else {
           			    	this.system_pid = dis.readLong();
           				}
					
					this.project = readString(dis);
					
					this.job = readString(dis);
					
					this.job_repository_id = readString(dis);
					
					this.job_version = readString(dis);
					
					this.context = readString(dis);
					
					this.origin = readString(dis);
					
					this.message_type = readString(dis);
					
					this.message = readString(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.duration = null;
           				} else {
           			    	this.duration = dis.readLong();
           				}
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// java.util.Date
				
						writeDate(this.moment,dos);
					
					// String
				
						writeString(this.pid,dos);
					
					// String
				
						writeString(this.father_pid,dos);
					
					// String
				
						writeString(this.root_pid,dos);
					
					// Long
				
						if(this.system_pid == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeLong(this.system_pid);
		            	}
					
					// String
				
						writeString(this.project,dos);
					
					// String
				
						writeString(this.job,dos);
					
					// String
				
						writeString(this.job_repository_id,dos);
					
					// String
				
						writeString(this.job_version,dos);
					
					// String
				
						writeString(this.context,dos);
					
					// String
				
						writeString(this.origin,dos);
					
					// String
				
						writeString(this.message_type,dos);
					
					// String
				
						writeString(this.message,dos);
					
					// Long
				
						if(this.duration == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeLong(this.duration);
		            	}
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("moment="+String.valueOf(moment));
		sb.append(",pid="+pid);
		sb.append(",father_pid="+father_pid);
		sb.append(",root_pid="+root_pid);
		sb.append(",system_pid="+String.valueOf(system_pid));
		sb.append(",project="+project);
		sb.append(",job="+job);
		sb.append(",job_repository_id="+job_repository_id);
		sb.append(",job_version="+job_version);
		sb.append(",context="+context);
		sb.append(",origin="+origin);
		sb.append(",message_type="+message_type);
		sb.append(",message="+message);
		sb.append(",duration="+String.valueOf(duration));
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				if(moment == null){
        					sb.append("<null>");
        				}else{
            				sb.append(moment);
            			}
            		
        			sb.append("|");
        		
        				if(pid == null){
        					sb.append("<null>");
        				}else{
            				sb.append(pid);
            			}
            		
        			sb.append("|");
        		
        				if(father_pid == null){
        					sb.append("<null>");
        				}else{
            				sb.append(father_pid);
            			}
            		
        			sb.append("|");
        		
        				if(root_pid == null){
        					sb.append("<null>");
        				}else{
            				sb.append(root_pid);
            			}
            		
        			sb.append("|");
        		
        				if(system_pid == null){
        					sb.append("<null>");
        				}else{
            				sb.append(system_pid);
            			}
            		
        			sb.append("|");
        		
        				if(project == null){
        					sb.append("<null>");
        				}else{
            				sb.append(project);
            			}
            		
        			sb.append("|");
        		
        				if(job == null){
        					sb.append("<null>");
        				}else{
            				sb.append(job);
            			}
            		
        			sb.append("|");
        		
        				if(job_repository_id == null){
        					sb.append("<null>");
        				}else{
            				sb.append(job_repository_id);
            			}
            		
        			sb.append("|");
        		
        				if(job_version == null){
        					sb.append("<null>");
        				}else{
            				sb.append(job_version);
            			}
            		
        			sb.append("|");
        		
        				if(context == null){
        					sb.append("<null>");
        				}else{
            				sb.append(context);
            			}
            		
        			sb.append("|");
        		
        				if(origin == null){
        					sb.append("<null>");
        				}else{
            				sb.append(origin);
            			}
            		
        			sb.append("|");
        		
        				if(message_type == null){
        					sb.append("<null>");
        				}else{
            				sb.append(message_type);
            			}
            		
        			sb.append("|");
        		
        				if(message == null){
        					sb.append("<null>");
        				}else{
            				sb.append(message);
            			}
            		
        			sb.append("|");
        		
        				if(duration == null){
        					sb.append("<null>");
        				}else{
            				sb.append(duration);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(row_talendStats_STATSStruct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}
public void talendStats_STATSProcess(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("talendStats_STATS_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
		String currentVirtualComponent = null;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;



		row_talendStats_STATSStruct row_talendStats_STATS = new row_talendStats_STATSStruct();




	
	/**
	 * [talendStats_CONSOLE begin ] start
	 */

	

	
		
		ok_Hash.put("talendStats_CONSOLE", false);
		start_Hash.put("talendStats_CONSOLE", System.currentTimeMillis());
		
	
		currentVirtualComponent = "talendStats_CONSOLE";
	
	currentComponent="talendStats_CONSOLE";

	
			if (execStat) {
				if(resourceMap.get("inIterateVComp") == null){
					
						runStat.updateStatOnConnection("Main" + iterateId, 0, 0);
					
				}
			} 

		
		int tos_count_talendStats_CONSOLE = 0;
		
                if(log.isDebugEnabled())
            log.debug("talendStats_CONSOLE - "  + ("Start to work.") );
    	class BytesLimit65535_talendStats_CONSOLE{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_talendStats_CONSOLE = new StringBuilder();
            log4jParamters_talendStats_CONSOLE.append("Parameters:");
                    log4jParamters_talendStats_CONSOLE.append("BASIC_MODE" + " = " + "true");
                log4jParamters_talendStats_CONSOLE.append(" | ");
                    log4jParamters_talendStats_CONSOLE.append("TABLE_PRINT" + " = " + "false");
                log4jParamters_talendStats_CONSOLE.append(" | ");
                    log4jParamters_talendStats_CONSOLE.append("VERTICAL" + " = " + "false");
                log4jParamters_talendStats_CONSOLE.append(" | ");
                    log4jParamters_talendStats_CONSOLE.append("FIELDSEPARATOR" + " = " + "\"|\"");
                log4jParamters_talendStats_CONSOLE.append(" | ");
                    log4jParamters_talendStats_CONSOLE.append("PRINT_HEADER" + " = " + "false");
                log4jParamters_talendStats_CONSOLE.append(" | ");
                    log4jParamters_talendStats_CONSOLE.append("PRINT_UNIQUE_NAME" + " = " + "false");
                log4jParamters_talendStats_CONSOLE.append(" | ");
                    log4jParamters_talendStats_CONSOLE.append("PRINT_COLNAMES" + " = " + "false");
                log4jParamters_talendStats_CONSOLE.append(" | ");
                    log4jParamters_talendStats_CONSOLE.append("USE_FIXED_LENGTH" + " = " + "false");
                log4jParamters_talendStats_CONSOLE.append(" | ");
                    log4jParamters_talendStats_CONSOLE.append("PRINT_CONTENT_WITH_LOG4J" + " = " + "true");
                log4jParamters_talendStats_CONSOLE.append(" | ");
                if(log.isDebugEnabled())
            log.debug("talendStats_CONSOLE - "  + (log4jParamters_talendStats_CONSOLE) );
    		}
    	}
    	
        new BytesLimit65535_talendStats_CONSOLE().limitLog4jByte();

	///////////////////////
	
		final String OUTPUT_FIELD_SEPARATOR_talendStats_CONSOLE = "|";
		java.io.PrintStream consoleOut_talendStats_CONSOLE = null;	

 		StringBuilder strBuffer_talendStats_CONSOLE = null;
		int nb_line_talendStats_CONSOLE = 0;
///////////////////////    			



 



/**
 * [talendStats_CONSOLE begin ] stop
 */



	
	/**
	 * [talendStats_STATS begin ] start
	 */

	

	
		
		ok_Hash.put("talendStats_STATS", false);
		start_Hash.put("talendStats_STATS", System.currentTimeMillis());
		
	
		currentVirtualComponent = "talendStats_STATS";
	
	currentComponent="talendStats_STATS";

	
		int tos_count_talendStats_STATS = 0;
		
                if(log.isDebugEnabled())
            log.debug("talendStats_STATS - "  + ("Start to work.") );
    	class BytesLimit65535_talendStats_STATS{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_talendStats_STATS = new StringBuilder();
            log4jParamters_talendStats_STATS.append("Parameters:");
                if(log.isDebugEnabled())
            log.debug("talendStats_STATS - "  + (log4jParamters_talendStats_STATS) );
    		}
    	}
    	
        new BytesLimit65535_talendStats_STATS().limitLog4jByte();

	for (StatCatcherUtils.StatCatcherMessage scm : talendStats_STATS.getMessages()) {
		row_talendStats_STATS.pid = pid;
		row_talendStats_STATS.root_pid = rootPid;
		row_talendStats_STATS.father_pid = fatherPid;	
    	row_talendStats_STATS.project = projectName;
    	row_talendStats_STATS.job = jobName;
    	row_talendStats_STATS.context = contextStr;
		row_talendStats_STATS.origin = (scm.getOrigin()==null || scm.getOrigin().length()<1 ? null : scm.getOrigin());
		row_talendStats_STATS.message = scm.getMessage();
		row_talendStats_STATS.duration = scm.getDuration();
		row_talendStats_STATS.moment = scm.getMoment();
		row_talendStats_STATS.message_type = scm.getMessageType();
		row_talendStats_STATS.job_version = scm.getJobVersion();
		row_talendStats_STATS.job_repository_id = scm.getJobId();
		row_talendStats_STATS.system_pid = scm.getSystemPid();

 



/**
 * [talendStats_STATS begin ] stop
 */
	
	/**
	 * [talendStats_STATS main ] start
	 */

	

	
	
		currentVirtualComponent = "talendStats_STATS";
	
	currentComponent="talendStats_STATS";

	

 


	tos_count_talendStats_STATS++;

/**
 * [talendStats_STATS main ] stop
 */

	
	/**
	 * [talendStats_CONSOLE main ] start
	 */

	

	
	
		currentVirtualComponent = "talendStats_CONSOLE";
	
	currentComponent="talendStats_CONSOLE";

	

			//Main
			//row_talendStats_STATS


			
				if(execStat){
					runStat.updateStatOnConnection("Main"+iterateId,1, 1);
				} 
			

		
///////////////////////		
						



				strBuffer_talendStats_CONSOLE = new StringBuilder();




   				
	    		if(row_talendStats_STATS.moment != null) { //              
                    							
       
				strBuffer_talendStats_CONSOLE.append(
								FormatterUtils.format_Date(row_talendStats_STATS.moment, "yyyy-MM-dd HH:mm:ss")				
				);


							
	    		} //  			

    			strBuffer_talendStats_CONSOLE.append("|");
    			


   				
	    		if(row_talendStats_STATS.pid != null) { //              
                    							
       
				strBuffer_talendStats_CONSOLE.append(
				                String.valueOf(row_talendStats_STATS.pid)							
				);


							
	    		} //  			

    			strBuffer_talendStats_CONSOLE.append("|");
    			


   				
	    		if(row_talendStats_STATS.father_pid != null) { //              
                    							
       
				strBuffer_talendStats_CONSOLE.append(
				                String.valueOf(row_talendStats_STATS.father_pid)							
				);


							
	    		} //  			

    			strBuffer_talendStats_CONSOLE.append("|");
    			


   				
	    		if(row_talendStats_STATS.root_pid != null) { //              
                    							
       
				strBuffer_talendStats_CONSOLE.append(
				                String.valueOf(row_talendStats_STATS.root_pid)							
				);


							
	    		} //  			

    			strBuffer_talendStats_CONSOLE.append("|");
    			


   				
	    		if(row_talendStats_STATS.system_pid != null) { //              
                    							
       
				strBuffer_talendStats_CONSOLE.append(
				                String.valueOf(row_talendStats_STATS.system_pid)							
				);


							
	    		} //  			

    			strBuffer_talendStats_CONSOLE.append("|");
    			


   				
	    		if(row_talendStats_STATS.project != null) { //              
                    							
       
				strBuffer_talendStats_CONSOLE.append(
				                String.valueOf(row_talendStats_STATS.project)							
				);


							
	    		} //  			

    			strBuffer_talendStats_CONSOLE.append("|");
    			


   				
	    		if(row_talendStats_STATS.job != null) { //              
                    							
       
				strBuffer_talendStats_CONSOLE.append(
				                String.valueOf(row_talendStats_STATS.job)							
				);


							
	    		} //  			

    			strBuffer_talendStats_CONSOLE.append("|");
    			


   				
	    		if(row_talendStats_STATS.job_repository_id != null) { //              
                    							
       
				strBuffer_talendStats_CONSOLE.append(
				                String.valueOf(row_talendStats_STATS.job_repository_id)							
				);


							
	    		} //  			

    			strBuffer_talendStats_CONSOLE.append("|");
    			


   				
	    		if(row_talendStats_STATS.job_version != null) { //              
                    							
       
				strBuffer_talendStats_CONSOLE.append(
				                String.valueOf(row_talendStats_STATS.job_version)							
				);


							
	    		} //  			

    			strBuffer_talendStats_CONSOLE.append("|");
    			


   				
	    		if(row_talendStats_STATS.context != null) { //              
                    							
       
				strBuffer_talendStats_CONSOLE.append(
				                String.valueOf(row_talendStats_STATS.context)							
				);


							
	    		} //  			

    			strBuffer_talendStats_CONSOLE.append("|");
    			


   				
	    		if(row_talendStats_STATS.origin != null) { //              
                    							
       
				strBuffer_talendStats_CONSOLE.append(
				                String.valueOf(row_talendStats_STATS.origin)							
				);


							
	    		} //  			

    			strBuffer_talendStats_CONSOLE.append("|");
    			


   				
	    		if(row_talendStats_STATS.message_type != null) { //              
                    							
       
				strBuffer_talendStats_CONSOLE.append(
				                String.valueOf(row_talendStats_STATS.message_type)							
				);


							
	    		} //  			

    			strBuffer_talendStats_CONSOLE.append("|");
    			


   				
	    		if(row_talendStats_STATS.message != null) { //              
                    							
       
				strBuffer_talendStats_CONSOLE.append(
				                String.valueOf(row_talendStats_STATS.message)							
				);


							
	    		} //  			

    			strBuffer_talendStats_CONSOLE.append("|");
    			


   				
	    		if(row_talendStats_STATS.duration != null) { //              
                    							
       
				strBuffer_talendStats_CONSOLE.append(
				                String.valueOf(row_talendStats_STATS.duration)							
				);


							
	    		} //  			
 

                    if (globalMap.get("tLogRow_CONSOLE")!=null)
                    {
                    	consoleOut_talendStats_CONSOLE = (java.io.PrintStream) globalMap.get("tLogRow_CONSOLE");
                    }
                    else
                    {
                    	consoleOut_talendStats_CONSOLE = new java.io.PrintStream(new java.io.BufferedOutputStream(System.out));
                    	globalMap.put("tLogRow_CONSOLE",consoleOut_talendStats_CONSOLE);
                    }
                    	log.info("talendStats_CONSOLE - Content of row "+(nb_line_talendStats_CONSOLE+1)+": " + strBuffer_talendStats_CONSOLE.toString());
                    consoleOut_talendStats_CONSOLE.println(strBuffer_talendStats_CONSOLE.toString());
                    consoleOut_talendStats_CONSOLE.flush();
                    nb_line_talendStats_CONSOLE++;
//////

//////                    
                    
///////////////////////    			

 


	tos_count_talendStats_CONSOLE++;

/**
 * [talendStats_CONSOLE main ] stop
 */



	
	/**
	 * [talendStats_STATS end ] start
	 */

	

	
	
		currentVirtualComponent = "talendStats_STATS";
	
	currentComponent="talendStats_STATS";

	

	}


 
                if(log.isDebugEnabled())
            log.debug("talendStats_STATS - "  + ("Done.") );

ok_Hash.put("talendStats_STATS", true);
end_Hash.put("talendStats_STATS", System.currentTimeMillis());




/**
 * [talendStats_STATS end ] stop
 */

	
	/**
	 * [talendStats_CONSOLE end ] start
	 */

	

	
	
		currentVirtualComponent = "talendStats_CONSOLE";
	
	currentComponent="talendStats_CONSOLE";

	


//////
//////
globalMap.put("talendStats_CONSOLE_NB_LINE",nb_line_talendStats_CONSOLE);
                if(log.isInfoEnabled())
            log.info("talendStats_CONSOLE - "  + ("Printed row count: ")  + (nb_line_talendStats_CONSOLE)  + (".") );

///////////////////////    			

			if(execStat){
				if(resourceMap.get("inIterateVComp") == null || !((Boolean)resourceMap.get("inIterateVComp"))){
			 		runStat.updateStatOnConnection("Main"+iterateId,2, 0); 
			 	}
			}
		
 
                if(log.isDebugEnabled())
            log.debug("talendStats_CONSOLE - "  + ("Done.") );

ok_Hash.put("talendStats_CONSOLE", true);
end_Hash.put("talendStats_CONSOLE", System.currentTimeMillis());




/**
 * [talendStats_CONSOLE end ] stop
 */



				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage());
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
					te.setVirtualComponentName(currentVirtualComponent);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [talendStats_STATS finally ] start
	 */

	

	
	
		currentVirtualComponent = "talendStats_STATS";
	
	currentComponent="talendStats_STATS";

	

 



/**
 * [talendStats_STATS finally ] stop
 */

	
	/**
	 * [talendStats_CONSOLE finally ] start
	 */

	

	
	
		currentVirtualComponent = "talendStats_CONSOLE";
	
	currentComponent="talendStats_CONSOLE";

	

 



/**
 * [talendStats_CONSOLE finally ] stop
 */



				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("talendStats_STATS_SUBPROCESS_STATE", 1);
	}
	


public static class row_talendMeter_METTERStruct implements routines.system.IPersistableRow<row_talendMeter_METTERStruct> {
    final static byte[] commonByteArrayLock_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Prod2Dev_with_GP_FDIST = new byte[0];
    static byte[] commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Prod2Dev_with_GP_FDIST = new byte[0];

	
			    public java.util.Date moment;

				public java.util.Date getMoment () {
					return this.moment;
				}
				
			    public String pid;

				public String getPid () {
					return this.pid;
				}
				
			    public String father_pid;

				public String getFather_pid () {
					return this.father_pid;
				}
				
			    public String root_pid;

				public String getRoot_pid () {
					return this.root_pid;
				}
				
			    public Long system_pid;

				public Long getSystem_pid () {
					return this.system_pid;
				}
				
			    public String project;

				public String getProject () {
					return this.project;
				}
				
			    public String job;

				public String getJob () {
					return this.job;
				}
				
			    public String job_repository_id;

				public String getJob_repository_id () {
					return this.job_repository_id;
				}
				
			    public String job_version;

				public String getJob_version () {
					return this.job_version;
				}
				
			    public String context;

				public String getContext () {
					return this.context;
				}
				
			    public String origin;

				public String getOrigin () {
					return this.origin;
				}
				
			    public String label;

				public String getLabel () {
					return this.label;
				}
				
			    public Integer count;

				public Integer getCount () {
					return this.count;
				}
				
			    public Integer reference;

				public Integer getReference () {
					return this.reference;
				}
				
			    public String thresholds;

				public String getThresholds () {
					return this.thresholds;
				}
				



	private java.util.Date readDate(ObjectInputStream dis) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(dis.readLong());
		}
		return dateReturn;
	}

    private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException{
		if(date1 == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeLong(date1.getTime());
    	}
    }

	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Prod2Dev_with_GP_FDIST.length) {
				if(length < 1024 && commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Prod2Dev_with_GP_FDIST.length == 0) {
   					commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Prod2Dev_with_GP_FDIST = new byte[1024];
				} else {
   					commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Prod2Dev_with_GP_FDIST = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Prod2Dev_with_GP_FDIST, 0, length);
			strReturn = new String(commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Prod2Dev_with_GP_FDIST, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
	private Integer readInteger(ObjectInputStream dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}

	private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException{
		if(intNum == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeInt(intNum);
    	}
	}

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Prod2Dev_with_GP_FDIST) {

        	try {

        		int length = 0;
		
					this.moment = readDate(dis);
					
					this.pid = readString(dis);
					
					this.father_pid = readString(dis);
					
					this.root_pid = readString(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.system_pid = null;
           				} else {
           			    	this.system_pid = dis.readLong();
           				}
					
					this.project = readString(dis);
					
					this.job = readString(dis);
					
					this.job_repository_id = readString(dis);
					
					this.job_version = readString(dis);
					
					this.context = readString(dis);
					
					this.origin = readString(dis);
					
					this.label = readString(dis);
					
						this.count = readInteger(dis);
					
						this.reference = readInteger(dis);
					
					this.thresholds = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// java.util.Date
				
						writeDate(this.moment,dos);
					
					// String
				
						writeString(this.pid,dos);
					
					// String
				
						writeString(this.father_pid,dos);
					
					// String
				
						writeString(this.root_pid,dos);
					
					// Long
				
						if(this.system_pid == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeLong(this.system_pid);
		            	}
					
					// String
				
						writeString(this.project,dos);
					
					// String
				
						writeString(this.job,dos);
					
					// String
				
						writeString(this.job_repository_id,dos);
					
					// String
				
						writeString(this.job_version,dos);
					
					// String
				
						writeString(this.context,dos);
					
					// String
				
						writeString(this.origin,dos);
					
					// String
				
						writeString(this.label,dos);
					
					// Integer
				
						writeInteger(this.count,dos);
					
					// Integer
				
						writeInteger(this.reference,dos);
					
					// String
				
						writeString(this.thresholds,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("moment="+String.valueOf(moment));
		sb.append(",pid="+pid);
		sb.append(",father_pid="+father_pid);
		sb.append(",root_pid="+root_pid);
		sb.append(",system_pid="+String.valueOf(system_pid));
		sb.append(",project="+project);
		sb.append(",job="+job);
		sb.append(",job_repository_id="+job_repository_id);
		sb.append(",job_version="+job_version);
		sb.append(",context="+context);
		sb.append(",origin="+origin);
		sb.append(",label="+label);
		sb.append(",count="+String.valueOf(count));
		sb.append(",reference="+String.valueOf(reference));
		sb.append(",thresholds="+thresholds);
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				if(moment == null){
        					sb.append("<null>");
        				}else{
            				sb.append(moment);
            			}
            		
        			sb.append("|");
        		
        				if(pid == null){
        					sb.append("<null>");
        				}else{
            				sb.append(pid);
            			}
            		
        			sb.append("|");
        		
        				if(father_pid == null){
        					sb.append("<null>");
        				}else{
            				sb.append(father_pid);
            			}
            		
        			sb.append("|");
        		
        				if(root_pid == null){
        					sb.append("<null>");
        				}else{
            				sb.append(root_pid);
            			}
            		
        			sb.append("|");
        		
        				if(system_pid == null){
        					sb.append("<null>");
        				}else{
            				sb.append(system_pid);
            			}
            		
        			sb.append("|");
        		
        				if(project == null){
        					sb.append("<null>");
        				}else{
            				sb.append(project);
            			}
            		
        			sb.append("|");
        		
        				if(job == null){
        					sb.append("<null>");
        				}else{
            				sb.append(job);
            			}
            		
        			sb.append("|");
        		
        				if(job_repository_id == null){
        					sb.append("<null>");
        				}else{
            				sb.append(job_repository_id);
            			}
            		
        			sb.append("|");
        		
        				if(job_version == null){
        					sb.append("<null>");
        				}else{
            				sb.append(job_version);
            			}
            		
        			sb.append("|");
        		
        				if(context == null){
        					sb.append("<null>");
        				}else{
            				sb.append(context);
            			}
            		
        			sb.append("|");
        		
        				if(origin == null){
        					sb.append("<null>");
        				}else{
            				sb.append(origin);
            			}
            		
        			sb.append("|");
        		
        				if(label == null){
        					sb.append("<null>");
        				}else{
            				sb.append(label);
            			}
            		
        			sb.append("|");
        		
        				if(count == null){
        					sb.append("<null>");
        				}else{
            				sb.append(count);
            			}
            		
        			sb.append("|");
        		
        				if(reference == null){
        					sb.append("<null>");
        				}else{
            				sb.append(reference);
            			}
            		
        			sb.append("|");
        		
        				if(thresholds == null){
        					sb.append("<null>");
        				}else{
            				sb.append(thresholds);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(row_talendMeter_METTERStruct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}
public void talendMeter_METTERProcess(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("talendMeter_METTER_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
		String currentVirtualComponent = null;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;



		row_talendMeter_METTERStruct row_talendMeter_METTER = new row_talendMeter_METTERStruct();




	
	/**
	 * [talendMeter_CONSOLE begin ] start
	 */

	

	
		
		ok_Hash.put("talendMeter_CONSOLE", false);
		start_Hash.put("talendMeter_CONSOLE", System.currentTimeMillis());
		
	
		currentVirtualComponent = "talendMeter_CONSOLE";
	
	currentComponent="talendMeter_CONSOLE";

	
			if (execStat) {
				if(resourceMap.get("inIterateVComp") == null){
					
						runStat.updateStatOnConnection("Main" + iterateId, 0, 0);
					
				}
			} 

		
		int tos_count_talendMeter_CONSOLE = 0;
		
                if(log.isDebugEnabled())
            log.debug("talendMeter_CONSOLE - "  + ("Start to work.") );
    	class BytesLimit65535_talendMeter_CONSOLE{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_talendMeter_CONSOLE = new StringBuilder();
            log4jParamters_talendMeter_CONSOLE.append("Parameters:");
                    log4jParamters_talendMeter_CONSOLE.append("BASIC_MODE" + " = " + "true");
                log4jParamters_talendMeter_CONSOLE.append(" | ");
                    log4jParamters_talendMeter_CONSOLE.append("TABLE_PRINT" + " = " + "false");
                log4jParamters_talendMeter_CONSOLE.append(" | ");
                    log4jParamters_talendMeter_CONSOLE.append("VERTICAL" + " = " + "false");
                log4jParamters_talendMeter_CONSOLE.append(" | ");
                    log4jParamters_talendMeter_CONSOLE.append("FIELDSEPARATOR" + " = " + "\"|\"");
                log4jParamters_talendMeter_CONSOLE.append(" | ");
                    log4jParamters_talendMeter_CONSOLE.append("PRINT_HEADER" + " = " + "false");
                log4jParamters_talendMeter_CONSOLE.append(" | ");
                    log4jParamters_talendMeter_CONSOLE.append("PRINT_UNIQUE_NAME" + " = " + "false");
                log4jParamters_talendMeter_CONSOLE.append(" | ");
                    log4jParamters_talendMeter_CONSOLE.append("PRINT_COLNAMES" + " = " + "false");
                log4jParamters_talendMeter_CONSOLE.append(" | ");
                    log4jParamters_talendMeter_CONSOLE.append("USE_FIXED_LENGTH" + " = " + "false");
                log4jParamters_talendMeter_CONSOLE.append(" | ");
                    log4jParamters_talendMeter_CONSOLE.append("PRINT_CONTENT_WITH_LOG4J" + " = " + "true");
                log4jParamters_talendMeter_CONSOLE.append(" | ");
                if(log.isDebugEnabled())
            log.debug("talendMeter_CONSOLE - "  + (log4jParamters_talendMeter_CONSOLE) );
    		}
    	}
    	
        new BytesLimit65535_talendMeter_CONSOLE().limitLog4jByte();

	///////////////////////
	
		final String OUTPUT_FIELD_SEPARATOR_talendMeter_CONSOLE = "|";
		java.io.PrintStream consoleOut_talendMeter_CONSOLE = null;	

 		StringBuilder strBuffer_talendMeter_CONSOLE = null;
		int nb_line_talendMeter_CONSOLE = 0;
///////////////////////    			



 



/**
 * [talendMeter_CONSOLE begin ] stop
 */



	
	/**
	 * [talendMeter_METTER begin ] start
	 */

	

	
		
		ok_Hash.put("talendMeter_METTER", false);
		start_Hash.put("talendMeter_METTER", System.currentTimeMillis());
		
	
		currentVirtualComponent = "talendMeter_METTER";
	
	currentComponent="talendMeter_METTER";

	
		int tos_count_talendMeter_METTER = 0;
		
                if(log.isDebugEnabled())
            log.debug("talendMeter_METTER - "  + ("Start to work.") );
    	class BytesLimit65535_talendMeter_METTER{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_talendMeter_METTER = new StringBuilder();
            log4jParamters_talendMeter_METTER.append("Parameters:");
                if(log.isDebugEnabled())
            log.debug("talendMeter_METTER - "  + (log4jParamters_talendMeter_METTER) );
    		}
    	}
    	
        new BytesLimit65535_talendMeter_METTER().limitLog4jByte();

	for (MetterCatcherUtils.MetterCatcherMessage mcm : talendMeter_METTER.getMessages()) {
		row_talendMeter_METTER.pid = pid;
		row_talendMeter_METTER.root_pid = rootPid;
		row_talendMeter_METTER.father_pid = fatherPid;	
        row_talendMeter_METTER.project = projectName;
        row_talendMeter_METTER.job = jobName;
        row_talendMeter_METTER.context = contextStr;
		row_talendMeter_METTER.origin = (mcm.getOrigin()==null || mcm.getOrigin().length()<1 ? null : mcm.getOrigin());
		row_talendMeter_METTER.moment = mcm.getMoment();
		row_talendMeter_METTER.job_version = mcm.getJobVersion();
		row_talendMeter_METTER.job_repository_id = mcm.getJobId();
		row_talendMeter_METTER.system_pid = mcm.getSystemPid();
		row_talendMeter_METTER.label = mcm.getLabel();
		row_talendMeter_METTER.count = mcm.getCount();
		row_talendMeter_METTER.reference = talendMeter_METTER.getConnLinesCount(mcm.getReferense()+"_count");
		row_talendMeter_METTER.thresholds = mcm.getThresholds();
		

 



/**
 * [talendMeter_METTER begin ] stop
 */
	
	/**
	 * [talendMeter_METTER main ] start
	 */

	

	
	
		currentVirtualComponent = "talendMeter_METTER";
	
	currentComponent="talendMeter_METTER";

	

 


	tos_count_talendMeter_METTER++;

/**
 * [talendMeter_METTER main ] stop
 */

	
	/**
	 * [talendMeter_CONSOLE main ] start
	 */

	

	
	
		currentVirtualComponent = "talendMeter_CONSOLE";
	
	currentComponent="talendMeter_CONSOLE";

	

			//Main
			//row_talendMeter_METTER


			
				if(execStat){
					runStat.updateStatOnConnection("Main"+iterateId,1, 1);
				} 
			

		
///////////////////////		
						



				strBuffer_talendMeter_CONSOLE = new StringBuilder();




   				
	    		if(row_talendMeter_METTER.moment != null) { //              
                    							
       
				strBuffer_talendMeter_CONSOLE.append(
								FormatterUtils.format_Date(row_talendMeter_METTER.moment, "yyyy-MM-dd HH:mm:ss")				
				);


							
	    		} //  			

    			strBuffer_talendMeter_CONSOLE.append("|");
    			


   				
	    		if(row_talendMeter_METTER.pid != null) { //              
                    							
       
				strBuffer_talendMeter_CONSOLE.append(
				                String.valueOf(row_talendMeter_METTER.pid)							
				);


							
	    		} //  			

    			strBuffer_talendMeter_CONSOLE.append("|");
    			


   				
	    		if(row_talendMeter_METTER.father_pid != null) { //              
                    							
       
				strBuffer_talendMeter_CONSOLE.append(
				                String.valueOf(row_talendMeter_METTER.father_pid)							
				);


							
	    		} //  			

    			strBuffer_talendMeter_CONSOLE.append("|");
    			


   				
	    		if(row_talendMeter_METTER.root_pid != null) { //              
                    							
       
				strBuffer_talendMeter_CONSOLE.append(
				                String.valueOf(row_talendMeter_METTER.root_pid)							
				);


							
	    		} //  			

    			strBuffer_talendMeter_CONSOLE.append("|");
    			


   				
	    		if(row_talendMeter_METTER.system_pid != null) { //              
                    							
       
				strBuffer_talendMeter_CONSOLE.append(
				                String.valueOf(row_talendMeter_METTER.system_pid)							
				);


							
	    		} //  			

    			strBuffer_talendMeter_CONSOLE.append("|");
    			


   				
	    		if(row_talendMeter_METTER.project != null) { //              
                    							
       
				strBuffer_talendMeter_CONSOLE.append(
				                String.valueOf(row_talendMeter_METTER.project)							
				);


							
	    		} //  			

    			strBuffer_talendMeter_CONSOLE.append("|");
    			


   				
	    		if(row_talendMeter_METTER.job != null) { //              
                    							
       
				strBuffer_talendMeter_CONSOLE.append(
				                String.valueOf(row_talendMeter_METTER.job)							
				);


							
	    		} //  			

    			strBuffer_talendMeter_CONSOLE.append("|");
    			


   				
	    		if(row_talendMeter_METTER.job_repository_id != null) { //              
                    							
       
				strBuffer_talendMeter_CONSOLE.append(
				                String.valueOf(row_talendMeter_METTER.job_repository_id)							
				);


							
	    		} //  			

    			strBuffer_talendMeter_CONSOLE.append("|");
    			


   				
	    		if(row_talendMeter_METTER.job_version != null) { //              
                    							
       
				strBuffer_talendMeter_CONSOLE.append(
				                String.valueOf(row_talendMeter_METTER.job_version)							
				);


							
	    		} //  			

    			strBuffer_talendMeter_CONSOLE.append("|");
    			


   				
	    		if(row_talendMeter_METTER.context != null) { //              
                    							
       
				strBuffer_talendMeter_CONSOLE.append(
				                String.valueOf(row_talendMeter_METTER.context)							
				);


							
	    		} //  			

    			strBuffer_talendMeter_CONSOLE.append("|");
    			


   				
	    		if(row_talendMeter_METTER.origin != null) { //              
                    							
       
				strBuffer_talendMeter_CONSOLE.append(
				                String.valueOf(row_talendMeter_METTER.origin)							
				);


							
	    		} //  			

    			strBuffer_talendMeter_CONSOLE.append("|");
    			


   				
	    		if(row_talendMeter_METTER.label != null) { //              
                    							
       
				strBuffer_talendMeter_CONSOLE.append(
				                String.valueOf(row_talendMeter_METTER.label)							
				);


							
	    		} //  			

    			strBuffer_talendMeter_CONSOLE.append("|");
    			


   				
	    		if(row_talendMeter_METTER.count != null) { //              
                    							
       
				strBuffer_talendMeter_CONSOLE.append(
				                String.valueOf(row_talendMeter_METTER.count)							
				);


							
	    		} //  			

    			strBuffer_talendMeter_CONSOLE.append("|");
    			


   				
	    		if(row_talendMeter_METTER.reference != null) { //              
                    							
       
				strBuffer_talendMeter_CONSOLE.append(
				                String.valueOf(row_talendMeter_METTER.reference)							
				);


							
	    		} //  			

    			strBuffer_talendMeter_CONSOLE.append("|");
    			


   				
	    		if(row_talendMeter_METTER.thresholds != null) { //              
                    							
       
				strBuffer_talendMeter_CONSOLE.append(
				                String.valueOf(row_talendMeter_METTER.thresholds)							
				);


							
	    		} //  			
 

                    if (globalMap.get("tLogRow_CONSOLE")!=null)
                    {
                    	consoleOut_talendMeter_CONSOLE = (java.io.PrintStream) globalMap.get("tLogRow_CONSOLE");
                    }
                    else
                    {
                    	consoleOut_talendMeter_CONSOLE = new java.io.PrintStream(new java.io.BufferedOutputStream(System.out));
                    	globalMap.put("tLogRow_CONSOLE",consoleOut_talendMeter_CONSOLE);
                    }
                    	log.info("talendMeter_CONSOLE - Content of row "+(nb_line_talendMeter_CONSOLE+1)+": " + strBuffer_talendMeter_CONSOLE.toString());
                    consoleOut_talendMeter_CONSOLE.println(strBuffer_talendMeter_CONSOLE.toString());
                    consoleOut_talendMeter_CONSOLE.flush();
                    nb_line_talendMeter_CONSOLE++;
//////

//////                    
                    
///////////////////////    			

 


	tos_count_talendMeter_CONSOLE++;

/**
 * [talendMeter_CONSOLE main ] stop
 */



	
	/**
	 * [talendMeter_METTER end ] start
	 */

	

	
	
		currentVirtualComponent = "talendMeter_METTER";
	
	currentComponent="talendMeter_METTER";

	

	}


 
                if(log.isDebugEnabled())
            log.debug("talendMeter_METTER - "  + ("Done.") );

ok_Hash.put("talendMeter_METTER", true);
end_Hash.put("talendMeter_METTER", System.currentTimeMillis());




/**
 * [talendMeter_METTER end ] stop
 */

	
	/**
	 * [talendMeter_CONSOLE end ] start
	 */

	

	
	
		currentVirtualComponent = "talendMeter_CONSOLE";
	
	currentComponent="talendMeter_CONSOLE";

	


//////
//////
globalMap.put("talendMeter_CONSOLE_NB_LINE",nb_line_talendMeter_CONSOLE);
                if(log.isInfoEnabled())
            log.info("talendMeter_CONSOLE - "  + ("Printed row count: ")  + (nb_line_talendMeter_CONSOLE)  + (".") );

///////////////////////    			

			if(execStat){
				if(resourceMap.get("inIterateVComp") == null || !((Boolean)resourceMap.get("inIterateVComp"))){
			 		runStat.updateStatOnConnection("Main"+iterateId,2, 0); 
			 	}
			}
		
 
                if(log.isDebugEnabled())
            log.debug("talendMeter_CONSOLE - "  + ("Done.") );

ok_Hash.put("talendMeter_CONSOLE", true);
end_Hash.put("talendMeter_CONSOLE", System.currentTimeMillis());




/**
 * [talendMeter_CONSOLE end ] stop
 */



				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage());
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
					te.setVirtualComponentName(currentVirtualComponent);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [talendMeter_METTER finally ] start
	 */

	

	
	
		currentVirtualComponent = "talendMeter_METTER";
	
	currentComponent="talendMeter_METTER";

	

 



/**
 * [talendMeter_METTER finally ] stop
 */

	
	/**
	 * [talendMeter_CONSOLE finally ] start
	 */

	

	
	
		currentVirtualComponent = "talendMeter_CONSOLE";
	
	currentComponent="talendMeter_CONSOLE";

	

 



/**
 * [talendMeter_CONSOLE finally ] stop
 */



				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("talendMeter_METTER_SUBPROCESS_STATE", 1);
	}
	
    public String resuming_logs_dir_path = null;
    public String resuming_checkpoint_path = null;
    public String parent_part_launcher = null;
    private String resumeEntryMethodName = null;
    private boolean globalResumeTicket = false;

    public boolean watch = false;
    // portStats is null, it means don't execute the statistics
    public Integer portStats = null;
    public int portTraces = 4334;
    public String clientHost;
    public String defaultClientHost = "localhost";
    public String contextStr = "SOURCING_DEV";
    public boolean isDefaultContext = true;
    public String pid = "0";
    public String rootPid = null;
    public String fatherPid = null;
    public String fatherNode = null;
    public long startTime = 0;
    public boolean isChildJob = false;
    public String log4jLevel = "";

    private boolean execStat = true;

    private ThreadLocal<java.util.Map<String, String>> threadLocal = new ThreadLocal<java.util.Map<String, String>>() {
        protected java.util.Map<String, String> initialValue() {
            java.util.Map<String,String> threadRunResultMap = new java.util.HashMap<String, String>();
            threadRunResultMap.put("errorCode", null);
            threadRunResultMap.put("status", "");
            return threadRunResultMap;
        };
    };


    private SyncInt runningThreadCount =new SyncInt();

    private class SyncInt
    {
        private int count = 0;
        public synchronized void add(int i)
        {
            count +=i;
        }

        public synchronized int getCount()
        {
            return count;
        }
    }

    private java.util.Properties context_param = new java.util.Properties();
    public java.util.Map<String, Object> parentContextMap = new java.util.HashMap<String, Object>();

    public String status= "";

    public static void main(String[] args){
        final EDL_Prod2Dev_with_GP_FDIST EDL_Prod2Dev_with_GP_FDISTClass = new EDL_Prod2Dev_with_GP_FDIST();

        int exitCode = EDL_Prod2Dev_with_GP_FDISTClass.runJobInTOS(args);
	        if(exitCode==0){
		        log.info("TalendJob: 'EDL_Prod2Dev_with_GP_FDIST' - Done.");
	        }

        System.exit(exitCode);
    }


    public String[][] runJob(String[] args) {

        int exitCode = runJobInTOS(args);
        String[][] bufferValue = new String[][] { { Integer.toString(exitCode) } };

        return bufferValue;
    }

    public boolean hastBufferOutputComponent() {
		boolean hastBufferOutput = false;
    	
        return hastBufferOutput;
    }

    public int runJobInTOS(String[] args) {
	   	// reset status
	   	status = "";

        String lastStr = "";
        for (String arg : args) {
            if (arg.equalsIgnoreCase("--context_param")) {
                lastStr = arg;
            } else if (lastStr.equals("")) {
                evalParam(arg);
            } else {
                evalParam(lastStr + " " + arg);
                lastStr = "";
            }
        }

	        if(!"".equals(log4jLevel)){
				if("trace".equalsIgnoreCase(log4jLevel)){
					log.setLevel(org.apache.log4j.Level.TRACE);
				}else if("debug".equalsIgnoreCase(log4jLevel)){
					log.setLevel(org.apache.log4j.Level.DEBUG);
				}else if("info".equalsIgnoreCase(log4jLevel)){
					log.setLevel(org.apache.log4j.Level.INFO);
				}else if("warn".equalsIgnoreCase(log4jLevel)){
					log.setLevel(org.apache.log4j.Level.WARN);
				}else if("error".equalsIgnoreCase(log4jLevel)){
					log.setLevel(org.apache.log4j.Level.ERROR);
				}else if("fatal".equalsIgnoreCase(log4jLevel)){
					log.setLevel(org.apache.log4j.Level.FATAL);
				}else if ("off".equalsIgnoreCase(log4jLevel)){
					log.setLevel(org.apache.log4j.Level.OFF);
				}
				org.apache.log4j.Logger.getRootLogger().setLevel(log.getLevel());
    	    }
        	log.info("TalendJob: 'EDL_Prod2Dev_with_GP_FDIST' - Start.");
    	

        if(clientHost == null) {
            clientHost = defaultClientHost;
        }

        if(pid == null || "0".equals(pid)) {
            pid = TalendString.getAsciiRandomString(6);
        }

        if (rootPid==null) {
            rootPid = pid;
        }
        if (fatherPid==null) {
            fatherPid = pid;
        }else{
            isChildJob = true;
        }

        if (portStats != null) {
            // portStats = -1; //for testing
            if (portStats < 0 || portStats > 65535) {
                // issue:10869, the portStats is invalid, so this client socket can't open
                System.err.println("The statistics socket port " + portStats + " is invalid.");
                execStat = false;
            }
        } else {
            execStat = false;
        }

        try {
            //call job/subjob with an existing context, like: --context=production. if without this parameter, there will use the default context instead.
            java.io.InputStream inContext = EDL_Prod2Dev_with_GP_FDIST.class.getClassLoader().getResourceAsStream("aws_dev_talend_ingestion_framework/edl_prod2dev_with_gp_fdist_0_1/contexts/"+contextStr+".properties");
            if(isDefaultContext && inContext ==null) {

            } else {
                if (inContext!=null) {
                    //defaultProps is in order to keep the original context value
                    defaultProps.load(inContext);
                    inContext.close();
                    context = new ContextProperties(defaultProps);
                }else{
                    //print info and job continue to run, for case: context_param is not empty.
                    System.err.println("Could not find the context " + contextStr);
                }
            }

            if(!context_param.isEmpty()) {
                context.putAll(context_param);
            }
                context.GP_SOURCE_NAME=(String) context.getProperty("GP_SOURCE_NAME");
                context.TABLE_NAME=(String) context.getProperty("TABLE_NAME");
                context.FORCE_DROP=(String) context.getProperty("FORCE_DROP");
                context.LOAD2HDFS=(String) context.getProperty("LOAD2HDFS");
             try{
                 context.RUN_ID=routines.system.ParserUtils.parseTo_Integer (context.getProperty("RUN_ID"));
             }catch(NumberFormatException e){
                 context.RUN_ID=null;
              }
                context.ORIG_DATABASE_NAME=(String) context.getProperty("ORIG_DATABASE_NAME");
                context.FDIST_PARAM=(String) context.getProperty("FDIST_PARAM");
             try{
                 context.LOG_NO_OF_ERRORS=routines.system.ParserUtils.parseTo_Integer (context.getProperty("LOG_NO_OF_ERRORS"));
             }catch(NumberFormatException e){
                 context.LOG_NO_OF_ERRORS=null;
              }
                context.LOG_PLANT_NAME=(String) context.getProperty("LOG_PLANT_NAME");
             try{
                 context.LOG_NO_OF_UPDATES=routines.system.ParserUtils.parseTo_Integer (context.getProperty("LOG_NO_OF_UPDATES"));
             }catch(NumberFormatException e){
                 context.LOG_NO_OF_UPDATES=null;
              }
             try{
                 context.LOG_SOURCE_ROW_COUNT=routines.system.ParserUtils.parseTo_Integer (context.getProperty("LOG_SOURCE_ROW_COUNT"));
             }catch(NumberFormatException e){
                 context.LOG_SOURCE_ROW_COUNT=null;
              }
                context.LOG_TECHNOLOGY=(String) context.getProperty("LOG_TECHNOLOGY");
                context.LOG_TABLE_NAME=(String) context.getProperty("LOG_TABLE_NAME");
             try{
                 context.LOG_NO_OF_INSERTS=routines.system.ParserUtils.parseTo_Integer (context.getProperty("LOG_NO_OF_INSERTS"));
             }catch(NumberFormatException e){
                 context.LOG_NO_OF_INSERTS=null;
              }
                context.LOG_DATA_PATH=(String) context.getProperty("LOG_DATA_PATH");
             try{
                 context.LOG_NO_OF_DELETES=routines.system.ParserUtils.parseTo_Integer (context.getProperty("LOG_NO_OF_DELETES"));
             }catch(NumberFormatException e){
                 context.LOG_NO_OF_DELETES=null;
              }
             try{
                 context.LOG_RUN_ID=routines.system.ParserUtils.parseTo_Integer (context.getProperty("LOG_RUN_ID"));
             }catch(NumberFormatException e){
                 context.LOG_RUN_ID=null;
              }
                context.LOG_ERROR_CATEGORY=(String) context.getProperty("LOG_ERROR_CATEGORY");
                context.LOG_JOB_NAME=(String) context.getProperty("LOG_JOB_NAME");
                context.LOG_SYSTEM_NAME=(String) context.getProperty("LOG_SYSTEM_NAME");
                context.LOG_MESSAGE=(String) context.getProperty("LOG_MESSAGE");
             try{
                 context.LOG_TARGET_ROW_COUNT=routines.system.ParserUtils.parseTo_Integer (context.getProperty("LOG_TARGET_ROW_COUNT"));
             }catch(NumberFormatException e){
                 context.LOG_TARGET_ROW_COUNT=null;
              }
                context.LOG_STATUS=(String) context.getProperty("LOG_STATUS");
                context.JOB_LABEL_NAME=(String) context.getProperty("JOB_LABEL_NAME");
                context.PLANT_NAME=(String) context.getProperty("PLANT_NAME");
                context.SEND_MAIL=(String) context.getProperty("SEND_MAIL");
                context.MAIL_TO=(String) context.getProperty("MAIL_TO");
                context.PUBLIC=(String) context.getProperty("PUBLIC");
             try{
                 context.THREAD=routines.system.ParserUtils.parseTo_Integer (context.getProperty("THREAD"));
             }catch(NumberFormatException e){
                 context.THREAD=null;
              }
                context.ETL_LOCALHOSTNAME=(String) context.getProperty("ETL_LOCALHOSTNAME");
                context.ETL_STORAGE_PATH=(String) context.getProperty("ETL_STORAGE_PATH");
                context.HAWQ_Source_Ports=(String) context.getProperty("HAWQ_Source_Ports");
                context.SOURCE_DATABASE=(String) context.getProperty("SOURCE_DATABASE");
                context.SOURCE_HOST=(String) context.getProperty("SOURCE_HOST");
            		String pwd_SOURCE_PASSWORD_value = context.getProperty("SOURCE_PASSWORD");
            		context.SOURCE_PASSWORD = null;
            		if(pwd_SOURCE_PASSWORD_value!=null) {
            			if(context_param.containsKey("SOURCE_PASSWORD")) {//no need to decrypt if it come from program argument or parent job runtime
            				context.SOURCE_PASSWORD = pwd_SOURCE_PASSWORD_value;
            			} else if (!pwd_SOURCE_PASSWORD_value.isEmpty()) {
            				try {
            					context.SOURCE_PASSWORD = routines.system.PasswordEncryptUtil.decryptPassword(pwd_SOURCE_PASSWORD_value);
            					context.put("SOURCE_PASSWORD",context.SOURCE_PASSWORD);
            				} catch (java.lang.RuntimeException e) {
            					//do nothing
            				}
            			}
            		}
             try{
                 context.SOURCE_PORT=routines.system.ParserUtils.parseTo_Integer (context.getProperty("SOURCE_PORT"));
             }catch(NumberFormatException e){
                 context.SOURCE_PORT=null;
              }
                context.SOURCE_USER=(String) context.getProperty("SOURCE_USER");
                context.SOURCING_Database=(String) context.getProperty("SOURCING_Database");
                context.SOURCING_Login=(String) context.getProperty("SOURCING_Login");
            		String pwd_SOURCING_Password_value = context.getProperty("SOURCING_Password");
            		context.SOURCING_Password = null;
            		if(pwd_SOURCING_Password_value!=null) {
            			if(context_param.containsKey("SOURCING_Password")) {//no need to decrypt if it come from program argument or parent job runtime
            				context.SOURCING_Password = pwd_SOURCING_Password_value;
            			} else if (!pwd_SOURCING_Password_value.isEmpty()) {
            				try {
            					context.SOURCING_Password = routines.system.PasswordEncryptUtil.decryptPassword(pwd_SOURCING_Password_value);
            					context.put("SOURCING_Password",context.SOURCING_Password);
            				} catch (java.lang.RuntimeException e) {
            					//do nothing
            				}
            			}
            		}
                context.SOURCING_Port=(String) context.getProperty("SOURCING_Port");
                context.SOURCING_Schema=(String) context.getProperty("SOURCING_Schema");
                context.SOURCING_Server=(String) context.getProperty("SOURCING_Server");
        } catch (java.io.IOException ie) {
            System.err.println("Could not load context "+contextStr);
            ie.printStackTrace();
        }


        // get context value from parent directly
        if (parentContextMap != null && !parentContextMap.isEmpty()) {if (parentContextMap.containsKey("GP_SOURCE_NAME")) {
                context.GP_SOURCE_NAME = (String) parentContextMap.get("GP_SOURCE_NAME");
            }if (parentContextMap.containsKey("TABLE_NAME")) {
                context.TABLE_NAME = (String) parentContextMap.get("TABLE_NAME");
            }if (parentContextMap.containsKey("FORCE_DROP")) {
                context.FORCE_DROP = (String) parentContextMap.get("FORCE_DROP");
            }if (parentContextMap.containsKey("LOAD2HDFS")) {
                context.LOAD2HDFS = (String) parentContextMap.get("LOAD2HDFS");
            }if (parentContextMap.containsKey("RUN_ID")) {
                context.RUN_ID = (Integer) parentContextMap.get("RUN_ID");
            }if (parentContextMap.containsKey("ORIG_DATABASE_NAME")) {
                context.ORIG_DATABASE_NAME = (String) parentContextMap.get("ORIG_DATABASE_NAME");
            }if (parentContextMap.containsKey("FDIST_PARAM")) {
                context.FDIST_PARAM = (String) parentContextMap.get("FDIST_PARAM");
            }if (parentContextMap.containsKey("LOG_NO_OF_ERRORS")) {
                context.LOG_NO_OF_ERRORS = (Integer) parentContextMap.get("LOG_NO_OF_ERRORS");
            }if (parentContextMap.containsKey("LOG_PLANT_NAME")) {
                context.LOG_PLANT_NAME = (String) parentContextMap.get("LOG_PLANT_NAME");
            }if (parentContextMap.containsKey("LOG_NO_OF_UPDATES")) {
                context.LOG_NO_OF_UPDATES = (Integer) parentContextMap.get("LOG_NO_OF_UPDATES");
            }if (parentContextMap.containsKey("LOG_SOURCE_ROW_COUNT")) {
                context.LOG_SOURCE_ROW_COUNT = (Integer) parentContextMap.get("LOG_SOURCE_ROW_COUNT");
            }if (parentContextMap.containsKey("LOG_TECHNOLOGY")) {
                context.LOG_TECHNOLOGY = (String) parentContextMap.get("LOG_TECHNOLOGY");
            }if (parentContextMap.containsKey("LOG_TABLE_NAME")) {
                context.LOG_TABLE_NAME = (String) parentContextMap.get("LOG_TABLE_NAME");
            }if (parentContextMap.containsKey("LOG_NO_OF_INSERTS")) {
                context.LOG_NO_OF_INSERTS = (Integer) parentContextMap.get("LOG_NO_OF_INSERTS");
            }if (parentContextMap.containsKey("LOG_DATA_PATH")) {
                context.LOG_DATA_PATH = (String) parentContextMap.get("LOG_DATA_PATH");
            }if (parentContextMap.containsKey("LOG_NO_OF_DELETES")) {
                context.LOG_NO_OF_DELETES = (Integer) parentContextMap.get("LOG_NO_OF_DELETES");
            }if (parentContextMap.containsKey("LOG_RUN_ID")) {
                context.LOG_RUN_ID = (Integer) parentContextMap.get("LOG_RUN_ID");
            }if (parentContextMap.containsKey("LOG_ERROR_CATEGORY")) {
                context.LOG_ERROR_CATEGORY = (String) parentContextMap.get("LOG_ERROR_CATEGORY");
            }if (parentContextMap.containsKey("LOG_JOB_NAME")) {
                context.LOG_JOB_NAME = (String) parentContextMap.get("LOG_JOB_NAME");
            }if (parentContextMap.containsKey("LOG_SYSTEM_NAME")) {
                context.LOG_SYSTEM_NAME = (String) parentContextMap.get("LOG_SYSTEM_NAME");
            }if (parentContextMap.containsKey("LOG_MESSAGE")) {
                context.LOG_MESSAGE = (String) parentContextMap.get("LOG_MESSAGE");
            }if (parentContextMap.containsKey("LOG_TARGET_ROW_COUNT")) {
                context.LOG_TARGET_ROW_COUNT = (Integer) parentContextMap.get("LOG_TARGET_ROW_COUNT");
            }if (parentContextMap.containsKey("LOG_STATUS")) {
                context.LOG_STATUS = (String) parentContextMap.get("LOG_STATUS");
            }if (parentContextMap.containsKey("JOB_LABEL_NAME")) {
                context.JOB_LABEL_NAME = (String) parentContextMap.get("JOB_LABEL_NAME");
            }if (parentContextMap.containsKey("PLANT_NAME")) {
                context.PLANT_NAME = (String) parentContextMap.get("PLANT_NAME");
            }if (parentContextMap.containsKey("SEND_MAIL")) {
                context.SEND_MAIL = (String) parentContextMap.get("SEND_MAIL");
            }if (parentContextMap.containsKey("MAIL_TO")) {
                context.MAIL_TO = (String) parentContextMap.get("MAIL_TO");
            }if (parentContextMap.containsKey("PUBLIC")) {
                context.PUBLIC = (String) parentContextMap.get("PUBLIC");
            }if (parentContextMap.containsKey("THREAD")) {
                context.THREAD = (Integer) parentContextMap.get("THREAD");
            }if (parentContextMap.containsKey("ETL_LOCALHOSTNAME")) {
                context.ETL_LOCALHOSTNAME = (String) parentContextMap.get("ETL_LOCALHOSTNAME");
            }if (parentContextMap.containsKey("ETL_STORAGE_PATH")) {
                context.ETL_STORAGE_PATH = (String) parentContextMap.get("ETL_STORAGE_PATH");
            }if (parentContextMap.containsKey("HAWQ_Source_Ports")) {
                context.HAWQ_Source_Ports = (String) parentContextMap.get("HAWQ_Source_Ports");
            }if (parentContextMap.containsKey("SOURCE_DATABASE")) {
                context.SOURCE_DATABASE = (String) parentContextMap.get("SOURCE_DATABASE");
            }if (parentContextMap.containsKey("SOURCE_HOST")) {
                context.SOURCE_HOST = (String) parentContextMap.get("SOURCE_HOST");
            }if (parentContextMap.containsKey("SOURCE_PASSWORD")) {
                context.SOURCE_PASSWORD = (java.lang.String) parentContextMap.get("SOURCE_PASSWORD");
            }if (parentContextMap.containsKey("SOURCE_PORT")) {
                context.SOURCE_PORT = (Integer) parentContextMap.get("SOURCE_PORT");
            }if (parentContextMap.containsKey("SOURCE_USER")) {
                context.SOURCE_USER = (String) parentContextMap.get("SOURCE_USER");
            }if (parentContextMap.containsKey("SOURCING_Database")) {
                context.SOURCING_Database = (String) parentContextMap.get("SOURCING_Database");
            }if (parentContextMap.containsKey("SOURCING_Login")) {
                context.SOURCING_Login = (String) parentContextMap.get("SOURCING_Login");
            }if (parentContextMap.containsKey("SOURCING_Password")) {
                context.SOURCING_Password = (java.lang.String) parentContextMap.get("SOURCING_Password");
            }if (parentContextMap.containsKey("SOURCING_Port")) {
                context.SOURCING_Port = (String) parentContextMap.get("SOURCING_Port");
            }if (parentContextMap.containsKey("SOURCING_Schema")) {
                context.SOURCING_Schema = (String) parentContextMap.get("SOURCING_Schema");
            }if (parentContextMap.containsKey("SOURCING_Server")) {
                context.SOURCING_Server = (String) parentContextMap.get("SOURCING_Server");
            }
        }

        //Resume: init the resumeUtil
        resumeEntryMethodName = ResumeUtil.getResumeEntryMethodName(resuming_checkpoint_path);
        resumeUtil = new ResumeUtil(resuming_logs_dir_path, isChildJob, rootPid);
        resumeUtil.initCommonInfo(pid, rootPid, fatherPid, projectName, jobName, contextStr, jobVersion);

		List<String> parametersToEncrypt = new java.util.ArrayList<String>();
			parametersToEncrypt.add("SOURCE_PASSWORD");
			parametersToEncrypt.add("SOURCING_Password");
        //Resume: jobStart
        resumeUtil.addLog("JOB_STARTED", "JOB:" + jobName, parent_part_launcher, Thread.currentThread().getId() + "", "","","","",resumeUtil.convertToJsonText(context,parametersToEncrypt));

if(execStat) {
    try {
        runStat.openSocket(!isChildJob);
        runStat.setAllPID(rootPid, fatherPid, pid, jobName);
        runStat.startThreadStat(clientHost, portStats);
        runStat.updateStatOnJob(RunStat.JOBSTART, fatherNode);
    } catch (java.io.IOException ioException) {
        ioException.printStackTrace();
    }
}



	
	    java.util.concurrent.ConcurrentHashMap<Object, Object> concurrentHashMap = new java.util.concurrent.ConcurrentHashMap<Object, Object>();
	    globalMap.put("concurrentHashMap", concurrentHashMap);
	

    long startUsedMemory = Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory();
    long endUsedMemory = 0;
    long end = 0;

    startTime = System.currentTimeMillis();
        talendStats_STATS.addMessage("begin");


this.globalResumeTicket = true;//to run tPreJob



        try {
            talendStats_STATSProcess(globalMap);
        } catch (java.lang.Exception e) {
            e.printStackTrace();
        }

this.globalResumeTicket = false;//to run others jobs
final Thread launchingThread = Thread.currentThread();
        runningThreadCount.add(1);
        new Thread(){
            public void run() {
                java.util.Map threadRunResultMap = new java.util.HashMap();
                threadRunResultMap.put("errorCode", null);
                threadRunResultMap.put("status", "");
                threadLocal.set(threadRunResultMap);

                try {
((java.util.Map) threadLocal.get()).put("errorCode", null);tJava_16Process(globalMap);
if ( !"failure".equals(((java.util.Map)threadLocal.get()).get("status")) ) {
((java.util.Map) threadLocal.get()).put("status", "end");
}
}catch (TalendException e_tJava_16) {
globalMap.put("tJava_16_SUBPROCESS_STATE", -1);

e_tJava_16.printStackTrace();

}catch (java.lang.Error e_tJava_16) {
globalMap.put("tJava_16_SUBPROCESS_STATE", -1);
((java.util.Map) threadLocal.get()).put("status", "failure");throw e_tJava_16;

}
                finally {
                    Integer localErrorCode = (Integer)(((java.util.Map)threadLocal.get()).get("errorCode"));
                    String localStatus = (String)(((java.util.Map)threadLocal.get()).get("status"));
                    if (localErrorCode != null) {
                        if (errorCode == null || localErrorCode.compareTo(errorCode) > 0) {
                           errorCode = localErrorCode;
                        }
                    }
                    if (!status.equals("failure")){
                        status = localStatus;
                    }

                    if ("true".equals(((java.util.Map) threadLocal.get()).get("JobInterrupted"))) {
                        launchingThread.interrupt();
                    }

                    runningThreadCount.add(-1);
                }
            }
        }.start();

    boolean interrupted = false;
    while (runningThreadCount.getCount() > 0) {
        try {
            Thread.sleep(10);
        } catch (java.lang.InterruptedException e) {
            interrupted = true;
        } catch (java.lang.Exception e) {
            e.printStackTrace();
        }
    }

    if (interrupted) {
        Thread.currentThread().interrupt();
    }



this.globalResumeTicket = true;//to run tPostJob




        end = System.currentTimeMillis();

        if (watch) {
            System.out.println((end-startTime)+" milliseconds");
        }

        endUsedMemory = Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory();
        if (false) {
            System.out.println((endUsedMemory - startUsedMemory) + " bytes memory increase when running : EDL_Prod2Dev_with_GP_FDIST");
        }
        talendStats_STATS.addMessage(status==""?"end":status, (end-startTime));
        try {
            talendStats_STATSProcess(globalMap);
        } catch (java.lang.Exception e) {
            e.printStackTrace();
        }





if (execStat) {
    runStat.updateStatOnJob(RunStat.JOBEND, fatherNode);
    runStat.stopThreadStat();
}
    int returnCode = 0;
    if(errorCode == null) {
         returnCode = status != null && status.equals("failure") ? 1 : 0;
    } else {
         returnCode = errorCode.intValue();
    }
    resumeUtil.addLog("JOB_ENDED", "JOB:" + jobName, parent_part_launcher, Thread.currentThread().getId() + "", "","" + returnCode,"","","");

    return returnCode;

  }

    // only for OSGi env
    public void destroy() {
    closeSqlDbConnections();


    }



    private void closeSqlDbConnections() {
        try {
            Object obj_conn;
            obj_conn = globalMap.remove("conn_tGreenplumConnection_3");
            if (null != obj_conn) {
                ((java.sql.Connection) obj_conn).close();
            }
            obj_conn = globalMap.remove("conn_tGreenplumConnection_6");
            if (null != obj_conn) {
                ((java.sql.Connection) obj_conn).close();
            }
            obj_conn = globalMap.remove("conn_tGreenplumConnection_7");
            if (null != obj_conn) {
                ((java.sql.Connection) obj_conn).close();
            }
            obj_conn = globalMap.remove("conn_tGreenplumConnection_8");
            if (null != obj_conn) {
                ((java.sql.Connection) obj_conn).close();
            }
            obj_conn = globalMap.remove("conn_tGreenplumConnection_4");
            if (null != obj_conn) {
                ((java.sql.Connection) obj_conn).close();
            }
        } catch (java.lang.Exception e) {
        }
    }

		









    private java.util.Map<String, Object> getSharedConnections4REST() {
        java.util.Map<String, Object> connections = new java.util.HashMap<String, Object>();
            connections.put("conn_tGreenplumConnection_3", globalMap.get("conn_tGreenplumConnection_3"));
            connections.put("conn_tGreenplumConnection_6", globalMap.get("conn_tGreenplumConnection_6"));
            connections.put("conn_tGreenplumConnection_7", globalMap.get("conn_tGreenplumConnection_7"));
            connections.put("conn_tGreenplumConnection_8", globalMap.get("conn_tGreenplumConnection_8"));
            connections.put("conn_tGreenplumConnection_4", globalMap.get("conn_tGreenplumConnection_4"));






        return connections;
    }

    private void evalParam(String arg) {
        if (arg.startsWith("--resuming_logs_dir_path")) {
            resuming_logs_dir_path = arg.substring(25);
        } else if (arg.startsWith("--resuming_checkpoint_path")) {
            resuming_checkpoint_path = arg.substring(27);
        } else if (arg.startsWith("--parent_part_launcher")) {
            parent_part_launcher = arg.substring(23);
        } else if (arg.startsWith("--watch")) {
            watch = true;
        } else if (arg.startsWith("--stat_port=")) {
            String portStatsStr = arg.substring(12);
            if (portStatsStr != null && !portStatsStr.equals("null")) {
                portStats = Integer.parseInt(portStatsStr);
            }
        } else if (arg.startsWith("--trace_port=")) {
            portTraces = Integer.parseInt(arg.substring(13));
        } else if (arg.startsWith("--client_host=")) {
            clientHost = arg.substring(14);
        } else if (arg.startsWith("--context=")) {
            contextStr = arg.substring(10);
            isDefaultContext = false;
        } else if (arg.startsWith("--father_pid=")) {
            fatherPid = arg.substring(13);
        } else if (arg.startsWith("--root_pid=")) {
            rootPid = arg.substring(11);
        } else if (arg.startsWith("--father_node=")) {
            fatherNode = arg.substring(14);
        } else if (arg.startsWith("--pid=")) {
            pid = arg.substring(6);
        } else if (arg.startsWith("--context_param")) {
            String keyValue = arg.substring(16);
            int index = -1;
            if (keyValue != null && (index = keyValue.indexOf('=')) > -1) {
                if (fatherPid==null) {
                    context_param.put(keyValue.substring(0, index), replaceEscapeChars(keyValue.substring(index + 1)));
                } else { // the subjob won't escape the especial chars
                    context_param.put(keyValue.substring(0, index), keyValue.substring(index + 1) );
                }
            }
        }else if (arg.startsWith("--log4jLevel=")) {
            log4jLevel = arg.substring(13);
		}

    }

    private final String[][] escapeChars = {
        {"\\\\","\\"},{"\\n","\n"},{"\\'","\'"},{"\\r","\r"},
        {"\\f","\f"},{"\\b","\b"},{"\\t","\t"}
        };
    private String replaceEscapeChars (String keyValue) {

		if (keyValue == null || ("").equals(keyValue.trim())) {
			return keyValue;
		}

		StringBuilder result = new StringBuilder();
		int currIndex = 0;
		while (currIndex < keyValue.length()) {
			int index = -1;
			// judege if the left string includes escape chars
			for (String[] strArray : escapeChars) {
				index = keyValue.indexOf(strArray[0],currIndex);
				if (index>=0) {

					result.append(keyValue.substring(currIndex, index + strArray[0].length()).replace(strArray[0], strArray[1]));
					currIndex = index + strArray[0].length();
					break;
				}
			}
			// if the left string doesn't include escape chars, append the left into the result
			if (index < 0) {
				result.append(keyValue.substring(currIndex));
				currIndex = currIndex + keyValue.length();
			}
		}

		return result.toString();
    }

    public Integer getErrorCode() {
        return errorCode;
    }


    public String getStatus() {
        return status;
    }

    ResumeUtil resumeUtil = null;
}
/************************************************************************************************
 *     482462 characters generated by Talend Real-time Big Data Platform 
 *     on the October 19, 2018 3:30:23 PM CDT
 ************************************************************************************************/