
package aws_dev_talend_ingestion_framework.edl_prod2dev_with_gp_fdist_child_0_1;

import routines.DataOperation;
import routines.TalendDataGenerator;
import routines.GEDynamicRoutine;
import routines.DataQuality;
import routines.Relational;
import routines.GEroutines;
import routines.Mathematical;
import routines.DataQualityDependencies;
import routines.SQLike;
import routines.Numeric;
import routines.TalendString;
import routines.StringHandling;
import routines.DQTechnical;
import routines.MDM;
import routines.TalendDate;
import routines.DataMasking;
import routines.DqStringHandling;
import routines.GPLoadRoutine;
import routines.system.*;
import routines.system.api.*;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.math.BigDecimal;
import java.io.ByteArrayOutputStream;
import java.io.ByteArrayInputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.ObjectOutputStream;
import java.io.ObjectInputStream;
import java.io.IOException;
import java.util.Comparator;
 




	//the import part of tJava_2
	//import java.util.List;

	//the import part of tJavaRow_1
	//import java.util.List;

	//the import part of tJava_10
	//import java.util.List;

	//the import part of tJava_3
	//import java.util.List;

	//the import part of tJava_11
	//import java.util.List;

	//the import part of tJava_15
	//import java.util.List;

	//the import part of tJava_29
	//import java.util.List;

	//the import part of tJava_4
	//import java.util.List;

	//the import part of tJava_6
	//import java.util.List;

	//the import part of tJava_7
	//import java.util.List;

	//the import part of tJava_8
	//import java.util.List;

	//the import part of tJava_18
	//import java.util.List;

	//the import part of tJavaRow_3
	//import java.util.List;

	//the import part of tJavaRow_10
	//import java.util.List;

	//the import part of tJava_27
	//import java.util.List;

	//the import part of tJava_1
	//import java.util.List;

	//the import part of tJava_19
	import java.io.InputStreamReader;
import java.io.BufferedReader;

	//the import part of tJava_30
	//import java.util.List;

	//the import part of tJava_23
	//import java.util.List;

	//the import part of tJava_24
	//import java.util.List;

	//the import part of tJavaRow_9
	//import java.util.List;

	//the import part of tJava_22
	//import java.util.List;

	//the import part of tJavaRow_11
	//import java.util.List;

	//the import part of tJavaRow_6
	//import java.util.List;

	//the import part of tJava_25
	//import java.util.List;

	//the import part of tJava_26
	//import java.util.List;

	//the import part of tJava_21
	//import java.util.List;

	//the import part of tJava_5
	//import java.util.List;

	//the import part of tJavaRow_2
	//import java.util.List;

	//the import part of tJava_20
	import java.io.InputStreamReader;
import java.io.BufferedReader;

	//the import part of tJavaRow_8
	//import java.util.List;

	//the import part of tJavaRow_12
	//import java.util.List;

	//the import part of tJava_16
	//import java.util.List;

	//the import part of tJava_12
	//import java.util.List;

	//the import part of tJavaRow_4
	//import java.util.List;

	//the import part of tJava_13
	//import java.util.List;

	//the import part of tJava_14
	//import java.util.List;

	//the import part of tJavaRow_5
	//import java.util.List;

	//the import part of tJava_17
	//import java.util.List;

	//the import part of tJava_31
	//import java.util.List;


@SuppressWarnings("unused")

/**
 * Job: EDL_Prod2Dev_with_GP_FDIST_child Purpose: <br>
 * Description:  <br>
 * @author Talend, admin
 * @version 6.3.1.20161216_1026
 * @status 
 */
public class EDL_Prod2Dev_with_GP_FDIST_child implements TalendJob {
	static {System.setProperty("TalendJob.log", "EDL_Prod2Dev_with_GP_FDIST_child.log");}
	private static org.apache.log4j.Logger log = org.apache.log4j.Logger.getLogger(EDL_Prod2Dev_with_GP_FDIST_child.class);



	public final Object obj = new Object();

	// for transmiting parameters purpose
	private Object valueObject = null;

	public Object getValueObject() {
		return this.valueObject;
	}

	public void setValueObject(Object valueObject) {
		this.valueObject = valueObject;
	}
	
	private final static String defaultCharset = java.nio.charset.Charset.defaultCharset().name();

	
	private final static String utf8Charset = "UTF-8";

	// create and load default properties
	private java.util.Properties defaultProps = new java.util.Properties();
	// create application properties with default
	public class ContextProperties extends java.util.Properties {

		private static final long serialVersionUID = 1L;

		public ContextProperties(java.util.Properties properties){
			super(properties);
		}
		public ContextProperties(){
			super();
		}

		public void synchronizeContext(){
			
			if(GP_SOURCE_NAME != null){
				
					this.setProperty("GP_SOURCE_NAME", GP_SOURCE_NAME.toString());
				
			}
			
			if(TABLE_NAME != null){
				
					this.setProperty("TABLE_NAME", TABLE_NAME.toString());
				
			}
			
			if(FORCE_DROP != null){
				
					this.setProperty("FORCE_DROP", FORCE_DROP.toString());
				
			}
			
			if(LOAD2HDFS != null){
				
					this.setProperty("LOAD2HDFS", LOAD2HDFS.toString());
				
			}
			
			if(RUN_ID != null){
				
					this.setProperty("RUN_ID", RUN_ID.toString());
				
			}
			
			if(ORIG_DATABASE_NAME != null){
				
					this.setProperty("ORIG_DATABASE_NAME", ORIG_DATABASE_NAME.toString());
				
			}
			
			if(SOURCING_Server != null){
				
					this.setProperty("SOURCING_Server", SOURCING_Server.toString());
				
			}
			
			if(SOURCING_Login != null){
				
					this.setProperty("SOURCING_Login", SOURCING_Login.toString());
				
			}
			
			if(SOURCING_Password != null){
				
					this.setProperty("SOURCING_Password", SOURCING_Password.toString());
				
			}
			
			if(SOURCING_Port != null){
				
					this.setProperty("SOURCING_Port", SOURCING_Port.toString());
				
			}
			
			if(LOG_Type != null){
				
					this.setProperty("LOG_Type", LOG_Type.toString());
				
			}
			
			if(SOURCING_Schema != null){
				
					this.setProperty("SOURCING_Schema", SOURCING_Schema.toString());
				
			}
			
			if(SOURCING_Database != null){
				
					this.setProperty("SOURCING_Database", SOURCING_Database.toString());
				
			}
			
			if(FDIST_PARAM != null){
				
					this.setProperty("FDIST_PARAM", FDIST_PARAM.toString());
				
			}
			
			if(LOG_NO_OF_ERRORS != null){
				
					this.setProperty("LOG_NO_OF_ERRORS", LOG_NO_OF_ERRORS.toString());
				
			}
			
			if(LOG_PLANT_NAME != null){
				
					this.setProperty("LOG_PLANT_NAME", LOG_PLANT_NAME.toString());
				
			}
			
			if(LOG_NO_OF_UPDATES != null){
				
					this.setProperty("LOG_NO_OF_UPDATES", LOG_NO_OF_UPDATES.toString());
				
			}
			
			if(LOG_SOURCE_ROW_COUNT != null){
				
					this.setProperty("LOG_SOURCE_ROW_COUNT", LOG_SOURCE_ROW_COUNT.toString());
				
			}
			
			if(LOG_TECHNOLOGY != null){
				
					this.setProperty("LOG_TECHNOLOGY", LOG_TECHNOLOGY.toString());
				
			}
			
			if(LOG_TABLE_NAME != null){
				
					this.setProperty("LOG_TABLE_NAME", LOG_TABLE_NAME.toString());
				
			}
			
			if(LOG_NO_OF_INSERTS != null){
				
					this.setProperty("LOG_NO_OF_INSERTS", LOG_NO_OF_INSERTS.toString());
				
			}
			
			if(LOG_DATA_PATH != null){
				
					this.setProperty("LOG_DATA_PATH", LOG_DATA_PATH.toString());
				
			}
			
			if(LOG_NO_OF_DELETES != null){
				
					this.setProperty("LOG_NO_OF_DELETES", LOG_NO_OF_DELETES.toString());
				
			}
			
			if(LOG_RUN_ID != null){
				
					this.setProperty("LOG_RUN_ID", LOG_RUN_ID.toString());
				
			}
			
			if(LOG_ERROR_CATEGORY != null){
				
					this.setProperty("LOG_ERROR_CATEGORY", LOG_ERROR_CATEGORY.toString());
				
			}
			
			if(LOG_JOB_NAME != null){
				
					this.setProperty("LOG_JOB_NAME", LOG_JOB_NAME.toString());
				
			}
			
			if(LOG_SYSTEM_NAME != null){
				
					this.setProperty("LOG_SYSTEM_NAME", LOG_SYSTEM_NAME.toString());
				
			}
			
			if(LOG_MESSAGE != null){
				
					this.setProperty("LOG_MESSAGE", LOG_MESSAGE.toString());
				
			}
			
			if(LOG_TARGET_ROW_COUNT != null){
				
					this.setProperty("LOG_TARGET_ROW_COUNT", LOG_TARGET_ROW_COUNT.toString());
				
			}
			
			if(LOG_STATUS != null){
				
					this.setProperty("LOG_STATUS", LOG_STATUS.toString());
				
			}
			
			if(ETL_LOCALHOSTNAME != null){
				
					this.setProperty("ETL_LOCALHOSTNAME", ETL_LOCALHOSTNAME.toString());
				
			}
			
			if(ETL_STORAGE_PATH != null){
				
					this.setProperty("ETL_STORAGE_PATH", ETL_STORAGE_PATH.toString());
				
			}
			
			if(HAWQ_Source_Ports != null){
				
					this.setProperty("HAWQ_Source_Ports", HAWQ_Source_Ports.toString());
				
			}
			
			if(SOURCE_DATABASE != null){
				
					this.setProperty("SOURCE_DATABASE", SOURCE_DATABASE.toString());
				
			}
			
			if(SOURCE_HOST != null){
				
					this.setProperty("SOURCE_HOST", SOURCE_HOST.toString());
				
			}
			
			if(SOURCE_PASSWORD != null){
				
					this.setProperty("SOURCE_PASSWORD", SOURCE_PASSWORD.toString());
				
			}
			
			if(SOURCE_PORT != null){
				
					this.setProperty("SOURCE_PORT", SOURCE_PORT.toString());
				
			}
			
			if(SOURCE_USER != null){
				
					this.setProperty("SOURCE_USER", SOURCE_USER.toString());
				
			}
			
		}

public String GP_SOURCE_NAME;
public String getGP_SOURCE_NAME(){
	return this.GP_SOURCE_NAME;
}
public String TABLE_NAME;
public String getTABLE_NAME(){
	return this.TABLE_NAME;
}
public String FORCE_DROP;
public String getFORCE_DROP(){
	return this.FORCE_DROP;
}
public String LOAD2HDFS;
public String getLOAD2HDFS(){
	return this.LOAD2HDFS;
}
public Integer RUN_ID;
public Integer getRUN_ID(){
	return this.RUN_ID;
}
public String ORIG_DATABASE_NAME;
public String getORIG_DATABASE_NAME(){
	return this.ORIG_DATABASE_NAME;
}
public String SOURCING_Server;
public String getSOURCING_Server(){
	return this.SOURCING_Server;
}
public String SOURCING_Login;
public String getSOURCING_Login(){
	return this.SOURCING_Login;
}
public java.lang.String SOURCING_Password;
public java.lang.String getSOURCING_Password(){
	return this.SOURCING_Password;
}
public String SOURCING_Port;
public String getSOURCING_Port(){
	return this.SOURCING_Port;
}
public String LOG_Type;
public String getLOG_Type(){
	return this.LOG_Type;
}
public String SOURCING_Schema;
public String getSOURCING_Schema(){
	return this.SOURCING_Schema;
}
public String SOURCING_Database;
public String getSOURCING_Database(){
	return this.SOURCING_Database;
}
public String FDIST_PARAM;
public String getFDIST_PARAM(){
	return this.FDIST_PARAM;
}
public Integer LOG_NO_OF_ERRORS;
public Integer getLOG_NO_OF_ERRORS(){
	return this.LOG_NO_OF_ERRORS;
}
public String LOG_PLANT_NAME;
public String getLOG_PLANT_NAME(){
	return this.LOG_PLANT_NAME;
}
public Integer LOG_NO_OF_UPDATES;
public Integer getLOG_NO_OF_UPDATES(){
	return this.LOG_NO_OF_UPDATES;
}
public Integer LOG_SOURCE_ROW_COUNT;
public Integer getLOG_SOURCE_ROW_COUNT(){
	return this.LOG_SOURCE_ROW_COUNT;
}
public String LOG_TECHNOLOGY;
public String getLOG_TECHNOLOGY(){
	return this.LOG_TECHNOLOGY;
}
public String LOG_TABLE_NAME;
public String getLOG_TABLE_NAME(){
	return this.LOG_TABLE_NAME;
}
public Integer LOG_NO_OF_INSERTS;
public Integer getLOG_NO_OF_INSERTS(){
	return this.LOG_NO_OF_INSERTS;
}
public String LOG_DATA_PATH;
public String getLOG_DATA_PATH(){
	return this.LOG_DATA_PATH;
}
public Integer LOG_NO_OF_DELETES;
public Integer getLOG_NO_OF_DELETES(){
	return this.LOG_NO_OF_DELETES;
}
public Integer LOG_RUN_ID;
public Integer getLOG_RUN_ID(){
	return this.LOG_RUN_ID;
}
public String LOG_ERROR_CATEGORY;
public String getLOG_ERROR_CATEGORY(){
	return this.LOG_ERROR_CATEGORY;
}
public String LOG_JOB_NAME;
public String getLOG_JOB_NAME(){
	return this.LOG_JOB_NAME;
}
public String LOG_SYSTEM_NAME;
public String getLOG_SYSTEM_NAME(){
	return this.LOG_SYSTEM_NAME;
}
public String LOG_MESSAGE;
public String getLOG_MESSAGE(){
	return this.LOG_MESSAGE;
}
public Integer LOG_TARGET_ROW_COUNT;
public Integer getLOG_TARGET_ROW_COUNT(){
	return this.LOG_TARGET_ROW_COUNT;
}
public String LOG_STATUS;
public String getLOG_STATUS(){
	return this.LOG_STATUS;
}
public String ETL_LOCALHOSTNAME;
public String getETL_LOCALHOSTNAME(){
	return this.ETL_LOCALHOSTNAME;
}
public String ETL_STORAGE_PATH;
public String getETL_STORAGE_PATH(){
	return this.ETL_STORAGE_PATH;
}
public String HAWQ_Source_Ports;
public String getHAWQ_Source_Ports(){
	return this.HAWQ_Source_Ports;
}
public String SOURCE_DATABASE;
public String getSOURCE_DATABASE(){
	return this.SOURCE_DATABASE;
}
public String SOURCE_HOST;
public String getSOURCE_HOST(){
	return this.SOURCE_HOST;
}
public java.lang.String SOURCE_PASSWORD;
public java.lang.String getSOURCE_PASSWORD(){
	return this.SOURCE_PASSWORD;
}
public Integer SOURCE_PORT;
public Integer getSOURCE_PORT(){
	return this.SOURCE_PORT;
}
public String SOURCE_USER;
public String getSOURCE_USER(){
	return this.SOURCE_USER;
}
	}
	private ContextProperties context = new ContextProperties();
	public ContextProperties getContext() {
		return this.context;
	}
	private final String jobVersion = "0.1";
	private final String jobName = "EDL_Prod2Dev_with_GP_FDIST_child";
	private final String projectName = "AWS_DEV_TALEND_INGESTION_FRAMEWORK";
	public Integer errorCode = null;
	private String currentComponent = "";
	
		private final java.util.Map<String, Object> globalMap = new java.util.HashMap<String, Object>();
        private final static java.util.Map<String, Object> junitGlobalMap = new java.util.HashMap<String, Object>();
	
		private final java.util.Map<String, Long> start_Hash = new java.util.HashMap<String, Long>();
		private final java.util.Map<String, Long> end_Hash = new java.util.HashMap<String, Long>();
		private final java.util.Map<String, Boolean> ok_Hash = new java.util.HashMap<String, Boolean>();
		public  final java.util.List<String[]> globalBuffer = new java.util.ArrayList<String[]>();
	

private RunStat runStat = new RunStat();

	// OSGi DataSource
	private final static String KEY_DB_DATASOURCES = "KEY_DB_DATASOURCES";

	public void setDataSources(java.util.Map<String, javax.sql.DataSource> dataSources) {
		java.util.Map<String, routines.system.TalendDataSource> talendDataSources = new java.util.HashMap<String, routines.system.TalendDataSource>();
		for (java.util.Map.Entry<String, javax.sql.DataSource> dataSourceEntry : dataSources.entrySet()) {
			talendDataSources.put(dataSourceEntry.getKey(), new routines.system.TalendDataSource(dataSourceEntry.getValue()));
		}
		globalMap.put(KEY_DB_DATASOURCES, talendDataSources);
	}

	LogCatcherUtils tLogCatcher_2 = new LogCatcherUtils();
	LogCatcherUtils talendLogs_LOGS = new LogCatcherUtils();
	StatCatcherUtils talendStats_STATS = new StatCatcherUtils("_QcnuYISiEeaHiLEk6FDciQ", "0.1");
	MetterCatcherUtils talendMeter_METTER = new MetterCatcherUtils("_QcnuYISiEeaHiLEk6FDciQ", "0.1");

private final java.io.ByteArrayOutputStream baos = new java.io.ByteArrayOutputStream();
private final java.io.PrintStream errorMessagePS = new java.io.PrintStream(new java.io.BufferedOutputStream(baos));

public String getExceptionStackTrace() {
	if ("failure".equals(this.getStatus())) {
		errorMessagePS.flush();
		return baos.toString();
	}
	return null;
}

private Exception exception;

public Exception getException() {
	if ("failure".equals(this.getStatus())) {
		return this.exception;
	}
	return null;
}

private class TalendException extends Exception {

	private static final long serialVersionUID = 1L;

	private java.util.Map<String, Object> globalMap = null;
	private Exception e = null;
	private String currentComponent = null;
	private String virtualComponentName = null;
	
	public void setVirtualComponentName (String virtualComponentName){
		this.virtualComponentName = virtualComponentName;
	}

	private TalendException(Exception e, String errorComponent, final java.util.Map<String, Object> globalMap) {
		this.currentComponent= errorComponent;
		this.globalMap = globalMap;
		this.e = e;
	}

	public Exception getException() {
		return this.e;
	}

	public String getCurrentComponent() {
		return this.currentComponent;
	}

	
    public String getExceptionCauseMessage(Exception e){
        Throwable cause = e;
        String message = null;
        int i = 10;
        while (null != cause && 0 < i--) {
            message = cause.getMessage();
            if (null == message) {
                cause = cause.getCause();
            } else {
                break;          
            }
        }
        if (null == message) {
            message = e.getClass().getName();
        }   
        return message;
    }

	@Override
	public void printStackTrace() {
		if (!(e instanceof TalendException || e instanceof TDieException)) {
			if(virtualComponentName!=null && currentComponent.indexOf(virtualComponentName+"_")==0){
				globalMap.put(virtualComponentName+"_ERROR_MESSAGE",getExceptionCauseMessage(e));
			}
			 globalMap.put(currentComponent+"_ERROR_MESSAGE",getExceptionCauseMessage(e));
			System.err.println("Exception in component " + currentComponent);
		}
		if (!(e instanceof TDieException)) {
			if(e instanceof TalendException){
				e.printStackTrace();
			} else {
				e.printStackTrace();
				e.printStackTrace(errorMessagePS);
				EDL_Prod2Dev_with_GP_FDIST_child.this.exception = e;
			}
		}
		if (!(e instanceof TalendException)) {
		try {
			for (java.lang.reflect.Method m : this.getClass().getEnclosingClass().getMethods()) {
				if (m.getName().compareTo(currentComponent + "_error") == 0) {
					m.invoke(EDL_Prod2Dev_with_GP_FDIST_child.this, new Object[] { e , currentComponent, globalMap});
					break;
				}
			}

			if(!(e instanceof TDieException)){
				tLogCatcher_2.addMessage("Java Exception", currentComponent, 6, e.getClass().getName() + ":" + e.getMessage(), 1);
				talendLogs_LOGS.addMessage("Java Exception", currentComponent, 6, e.getClass().getName() + ":" + e.getMessage(), 1);
			try{
				tLogCatcher_2Process(globalMap);
			}finally{
				talendLogs_LOGSProcess(globalMap);
			}
			}
				} catch (TalendException e) {
					// do nothing
				
		} catch (Exception e) {
			this.e.printStackTrace();
		}
		}
	}
}

			public void tJava_2_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tJava_2_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tPostgresqlConnection_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tPostgresqlConnection_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tPostgresqlInput_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tPostgresqlInput_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tJavaRow_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tPostgresqlInput_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tJava_10_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tJava_10_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tPostgresqlInput_2_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tPostgresqlInput_2_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tFlowToIterate_3_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tPostgresqlInput_2_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tJava_3_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tPostgresqlInput_2_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tJava_11_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tJava_11_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tPostgresqlInput_4_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tPostgresqlInput_4_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tFlowToIterate_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tPostgresqlInput_4_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tJava_15_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tPostgresqlInput_4_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tJava_29_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tJava_29_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tPostgresqlInput_3_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tPostgresqlInput_3_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tFlowToIterate_4_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tPostgresqlInput_3_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tJava_4_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tPostgresqlInput_3_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tPostgresqlClose_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tPostgresqlClose_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tJava_6_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tJava_6_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tJava_7_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tJava_7_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tFileExist_2_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tFileExist_2_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tFileProperties_2_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tFileProperties_2_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tSetGlobalVar_5_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tFileProperties_2_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tFileProperties_3_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tFileProperties_3_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tSetGlobalVar_6_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tFileProperties_3_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tJava_8_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tJava_8_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tSetGlobalVar_8_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tSetGlobalVar_8_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tFileTouch_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tFileTouch_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tSystem_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tSystem_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tFlowToIterate_6_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tSystem_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tJava_18_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tSystem_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tSleep_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tSleep_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tFileInputFullRow_2_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tFileInputFullRow_2_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tJavaRow_3_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tFileInputFullRow_2_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tGreenplumConnection_6_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tGreenplumConnection_6_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tGreenplumInput_10_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tGreenplumInput_10_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tJavaRow_10_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tGreenplumInput_10_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tJava_27_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tJava_27_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tJava_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tJava_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tGreenplumRow_11_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tGreenplumRow_11_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tGreenplumClose_9_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tGreenplumClose_9_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tFileExist_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tFileExist_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tFileTouch_2_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tFileTouch_2_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tGreenplumConnection_2_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tGreenplumConnection_2_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tGreenplumRow_4_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
					tGreenplumRow_4_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tGreenplumRow_10_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tGreenplumRow_10_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tGreenplumClose_3_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tGreenplumClose_3_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tFileDelete_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tFileDelete_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tJava_19_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tJava_19_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tGreenplumConnection_11_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tGreenplumConnection_11_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tJava_30_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tJava_30_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tGreenplumRow_15_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tGreenplumRow_15_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tGreenplumClose_6_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tGreenplumClose_6_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tGreenplumConnection_3_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tGreenplumConnection_3_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tGreenplumInput_3_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tGreenplumInput_3_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tSetGlobalVar_4_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tGreenplumInput_3_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tGreenplumClose_11_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tGreenplumClose_11_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tJava_23_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tJava_23_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tGreenplumConnection_9_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tGreenplumConnection_9_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tJava_24_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tJava_24_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tGreenplumRow_16_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tGreenplumRow_16_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tGreenplumClose_13_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tGreenplumClose_13_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tGreenplumRow_2_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tGreenplumRow_2_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tGreenplumRow_3_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tGreenplumRow_3_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tGreenplumRow_22_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tGreenplumRow_22_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tGreenplumInput_7_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tGreenplumInput_7_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tJavaRow_9_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tGreenplumInput_7_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tGreenplumRow_18_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tGreenplumRow_18_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tGreenplumRow_17_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tGreenplumRow_17_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tGreenplumRow_5_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tGreenplumRow_5_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tJava_22_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tJava_22_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tGreenplumInput_9_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tGreenplumInput_9_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tJavaRow_11_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tGreenplumInput_9_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tGreenplumInput_6_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tGreenplumInput_6_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tJavaRow_6_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tGreenplumInput_6_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tJava_25_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tJava_25_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tGreenplumRow_6_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tGreenplumRow_6_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tGreenplumRow_14_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tGreenplumRow_14_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tJava_26_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tJava_26_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tJava_21_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tJava_21_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tJava_5_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tJava_5_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tGreenplumConnection_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tGreenplumConnection_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tGreenplumRow_7_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tGreenplumRow_7_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tGreenplumRow_9_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tGreenplumRow_9_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tGEGreenplumGPLoad_2_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tGEGreenplumGPLoad_2_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tGreenplumRow_21_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tGreenplumRow_21_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tGreenplumRow_23_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tGreenplumRow_23_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tGreenplumClose_5_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tGreenplumClose_5_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tFileInputFullRow_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tFileInputFullRow_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tJavaRow_2_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tFileInputFullRow_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tWarn_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tWarn_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tGreenplumRow_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
					tGreenplumRow_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tJava_20_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tJava_20_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tPostgresqlClose_2_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tPostgresqlClose_2_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tGreenplumClose_4_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tGreenplumClose_4_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tPostgresqlClose_3_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tPostgresqlClose_3_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tGreenplumInput_4_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tGreenplumInput_4_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tFlowToIterate_7_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tGreenplumInput_4_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tSetGlobalVar_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tGreenplumInput_4_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tGreenplumInput_8_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tGreenplumInput_8_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tJavaRow_8_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tGreenplumInput_8_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tGreenplumInput_11_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tGreenplumInput_11_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tJavaRow_12_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tGreenplumInput_11_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tGreenplumClose_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tGreenplumClose_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tGreenplumClose_7_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tGreenplumClose_7_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tGreenplumConnection_7_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tGreenplumConnection_7_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tJava_16_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tJava_16_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tFileDelete_3_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tFileDelete_3_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tFileExist_3_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tFileExist_3_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tSetGlobalVar_7_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tSetGlobalVar_7_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tJava_12_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tJava_12_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tGreenplumConnection_5_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tGreenplumConnection_5_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tGreenplumInput_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tGreenplumInput_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tJavaRow_4_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tGreenplumInput_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tJava_13_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tJava_13_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tGreenplumRow_12_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tGreenplumRow_12_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tGreenplumClose_8_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tGreenplumClose_8_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tLogCatcher_2_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tLogCatcher_2_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tSetGlobalVar_9_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tLogCatcher_2_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tJava_14_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tJava_14_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tGreenplumConnection_8_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tGreenplumConnection_8_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tGreenplumInput_2_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tGreenplumInput_2_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tJavaRow_5_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tGreenplumInput_2_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tJava_17_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tJava_17_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tGreenplumRow_13_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tGreenplumRow_13_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tGreenplumClose_10_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tGreenplumClose_10_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tGreenplumClose_2_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tGreenplumClose_2_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tJava_31_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tJava_31_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void talendLogs_LOGS_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
							talendLogs_CONSOLE_error(exception, errorComponent, globalMap);
						
						}
					
			public void talendLogs_CONSOLE_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					talendLogs_LOGS_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void talendStats_STATS_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
							talendStats_CONSOLE_error(exception, errorComponent, globalMap);
						
						}
					
			public void talendStats_CONSOLE_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					talendStats_STATS_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void talendMeter_METTER_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
							talendMeter_CONSOLE_error(exception, errorComponent, globalMap);
						
						}
					
			public void talendMeter_CONSOLE_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					talendMeter_METTER_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tJava_2_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tPostgresqlConnection_1_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tPostgresqlInput_1_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tJava_10_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tPostgresqlInput_2_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tJava_11_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tPostgresqlInput_4_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tJava_29_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tPostgresqlInput_3_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tPostgresqlClose_1_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tJava_6_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tJava_7_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tFileExist_2_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tFileProperties_2_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tFileProperties_3_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tJava_8_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tSetGlobalVar_8_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tFileTouch_1_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tSystem_1_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tSleep_1_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tFileInputFullRow_2_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tGreenplumConnection_6_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tGreenplumInput_10_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tJava_27_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tJava_1_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tGreenplumRow_11_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tGreenplumClose_9_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tFileExist_1_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tFileTouch_2_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tGreenplumConnection_2_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tGreenplumRow_4_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "ERROR", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

				try {
					
						if(this.execStat){
							runStat.updateStatOnConnection("OnSubjobError1", 0, "error");
						}
					
					errorCode = null;
					tGreenplumRow_2Process(globalMap);
					if (!"failure".equals(status)) {
						status = "end";
					}
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
			public void tGreenplumRow_10_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tGreenplumClose_3_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tFileDelete_1_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tJava_19_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tGreenplumConnection_11_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tJava_30_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tGreenplumRow_15_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tGreenplumClose_6_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tGreenplumConnection_3_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tGreenplumInput_3_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tGreenplumClose_11_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tJava_23_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tGreenplumConnection_9_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tJava_24_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tGreenplumRow_16_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tGreenplumClose_13_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tGreenplumRow_2_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tGreenplumRow_3_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tGreenplumRow_22_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tGreenplumInput_7_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tGreenplumRow_18_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tGreenplumRow_17_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tGreenplumRow_5_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tJava_22_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tGreenplumInput_9_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tGreenplumInput_6_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tJava_25_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tGreenplumRow_6_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tGreenplumRow_14_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tJava_26_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tJava_21_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tJava_5_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tGreenplumConnection_1_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tGreenplumRow_7_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tGreenplumRow_9_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tGEGreenplumGPLoad_2_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tGreenplumRow_21_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tGreenplumRow_23_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tGreenplumClose_5_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tFileInputFullRow_1_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tWarn_1_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tGreenplumRow_1_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "ERROR", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

				try {
					
						if(this.execStat){
							runStat.updateStatOnConnection("OnSubjobError2", 0, "error");
						}
					
					errorCode = null;
					tGreenplumRow_7Process(globalMap);
					if (!"failure".equals(status)) {
						status = "end";
					}
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
			public void tJava_20_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tPostgresqlClose_2_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tGreenplumClose_4_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tPostgresqlClose_3_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tGreenplumInput_4_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tGreenplumInput_8_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tGreenplumInput_11_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tGreenplumClose_1_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tGreenplumClose_7_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tGreenplumConnection_7_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tJava_16_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tFileDelete_3_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tFileExist_3_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tSetGlobalVar_7_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tJava_12_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tGreenplumConnection_5_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tGreenplumInput_1_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tJava_13_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tGreenplumRow_12_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tGreenplumClose_8_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tLogCatcher_2_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tJava_14_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tGreenplumConnection_8_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tGreenplumInput_2_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tJava_17_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tGreenplumRow_13_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tGreenplumClose_10_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tGreenplumClose_2_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tJava_31_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void talendLogs_LOGS_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void talendStats_STATS_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void talendMeter_METTER_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			








public void tJava_2Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tJava_2_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tJava_2 begin ] start
	 */

	

	
		
		ok_Hash.put("tJava_2", false);
		start_Hash.put("tJava_2", System.currentTimeMillis());
		
	
	currentComponent="tJava_2";

	
		int tos_count_tJava_2 = 0;
		
    	class BytesLimit65535_tJava_2{
    		public void limitLog4jByte() throws Exception{
    			
    		}
    	}
    	
        new BytesLimit65535_tJava_2().limitLog4jByte();


globalMap.put("filetocheck", 
context.ETL_STORAGE_PATH + "/" + context.GP_SOURCE_NAME + '/' + "/data/" + 
context.SOURCE_DATABASE + "/" + ((String)globalMap.get("row7.log_table_name")).replace("\"","").replace("#","__hash__").replace("$","__dollar__")  + 
".gz");


globalMap.put("where_cond", "1=1");

 



/**
 * [tJava_2 begin ] stop
 */
	
	/**
	 * [tJava_2 main ] start
	 */

	

	
	
	currentComponent="tJava_2";

	

 


	tos_count_tJava_2++;

/**
 * [tJava_2 main ] stop
 */
	
	/**
	 * [tJava_2 end ] start
	 */

	

	
	
	currentComponent="tJava_2";

	

 

ok_Hash.put("tJava_2", true);
end_Hash.put("tJava_2", System.currentTimeMillis());

				if(execStat){   
   	 				runStat.updateStatOnConnection("OnComponentOk5", 0, "ok");
				}
				tPostgresqlConnection_1Process(globalMap);



/**
 * [tJava_2 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage());
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tJava_2 finally ] start
	 */

	

	
	
	currentComponent="tJava_2";

	

 



/**
 * [tJava_2 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tJava_2_SUBPROCESS_STATE", 1);
	}
	

public void tPostgresqlConnection_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tPostgresqlConnection_1_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tPostgresqlConnection_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tPostgresqlConnection_1", false);
		start_Hash.put("tPostgresqlConnection_1", System.currentTimeMillis());
		
	
	currentComponent="tPostgresqlConnection_1";

	
		int tos_count_tPostgresqlConnection_1 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tPostgresqlConnection_1 - "  + ("Start to work.") );
    	class BytesLimit65535_tPostgresqlConnection_1{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tPostgresqlConnection_1 = new StringBuilder();
            log4jParamters_tPostgresqlConnection_1.append("Parameters:");
                    log4jParamters_tPostgresqlConnection_1.append("DB_VERSION" + " = " + "PRIOR_TO_V9");
                log4jParamters_tPostgresqlConnection_1.append(" | ");
                    log4jParamters_tPostgresqlConnection_1.append("HOST" + " = " + "context.getProperty(\"SOURCE_HOST\")");
                log4jParamters_tPostgresqlConnection_1.append(" | ");
                    log4jParamters_tPostgresqlConnection_1.append("PORT" + " = " + "context.getProperty(\"SOURCE_PORT\").toString()");
                log4jParamters_tPostgresqlConnection_1.append(" | ");
                    log4jParamters_tPostgresqlConnection_1.append("DBNAME" + " = " + "context.getProperty(\"SOURCE_DATABASE\")");
                log4jParamters_tPostgresqlConnection_1.append(" | ");
                    log4jParamters_tPostgresqlConnection_1.append("SCHEMA_DB" + " = " + "((String)globalMap.get(\"row7.target_schema\"))");
                log4jParamters_tPostgresqlConnection_1.append(" | ");
                    log4jParamters_tPostgresqlConnection_1.append("USER" + " = " + "context.getProperty(\"SOURCE_USER\")");
                log4jParamters_tPostgresqlConnection_1.append(" | ");
                    log4jParamters_tPostgresqlConnection_1.append("PASS" + " = " + String.valueOf(routines.system.PasswordEncryptUtil.encryptPassword(context.SOURCE_PASSWORD)).substring(0, 4) + "...");     
                log4jParamters_tPostgresqlConnection_1.append(" | ");
                    log4jParamters_tPostgresqlConnection_1.append("USE_SHARED_CONNECTION" + " = " + "false");
                log4jParamters_tPostgresqlConnection_1.append(" | ");
                    log4jParamters_tPostgresqlConnection_1.append("SPECIFY_DATASOURCE_ALIAS" + " = " + "false");
                log4jParamters_tPostgresqlConnection_1.append(" | ");
                    log4jParamters_tPostgresqlConnection_1.append("USE_SSL" + " = " + "true");
                log4jParamters_tPostgresqlConnection_1.append(" | ");
                    log4jParamters_tPostgresqlConnection_1.append("AUTO_COMMIT" + " = " + "true");
                log4jParamters_tPostgresqlConnection_1.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tPostgresqlConnection_1 - "  + (log4jParamters_tPostgresqlConnection_1) );
    		}
    	}
    	
        new BytesLimit65535_tPostgresqlConnection_1().limitLog4jByte();


	
				String url_tPostgresqlConnection_1 = "jdbc:postgresql://"+context.getProperty("SOURCE_HOST")+":"+context.getProperty("SOURCE_PORT").toString()+"/"+context.getProperty("SOURCE_DATABASE")+"?ssl=true&sslfactory=org.postgresql.ssl.NonValidatingFactory";

	String dbUser_tPostgresqlConnection_1 = context.getProperty("SOURCE_USER");
	
	
		
	final String decryptedPassword_tPostgresqlConnection_1 = context.SOURCE_PASSWORD; 
		String dbPwd_tPostgresqlConnection_1 = decryptedPassword_tPostgresqlConnection_1;
	

	java.sql.Connection conn_tPostgresqlConnection_1 = null;
	
					String driverClass_tPostgresqlConnection_1 = "org.postgresql.Driver";
			java.lang.Class.forName(driverClass_tPostgresqlConnection_1);
		
	    		log.debug("tPostgresqlConnection_1 - Driver ClassName: "+driverClass_tPostgresqlConnection_1+".");
			
	    		log.debug("tPostgresqlConnection_1 - Connection attempt to '" + url_tPostgresqlConnection_1 + "' with the username '" + dbUser_tPostgresqlConnection_1 + "'.");
			
		conn_tPostgresqlConnection_1 = java.sql.DriverManager.getConnection(url_tPostgresqlConnection_1,dbUser_tPostgresqlConnection_1,dbPwd_tPostgresqlConnection_1);
	    		log.debug("tPostgresqlConnection_1 - Connection to '" + url_tPostgresqlConnection_1 + "' has succeeded.");
			

		globalMap.put("conn_tPostgresqlConnection_1", conn_tPostgresqlConnection_1);
	if (null != conn_tPostgresqlConnection_1) {
		
			log.debug("tPostgresqlConnection_1 - Connection is set auto commit to 'true'.");
			conn_tPostgresqlConnection_1.setAutoCommit(true);
	}

	globalMap.put("schema_" + "tPostgresqlConnection_1",((String)globalMap.get("row7.target_schema")));

	globalMap.put("conn_" + "tPostgresqlConnection_1",conn_tPostgresqlConnection_1);

 



/**
 * [tPostgresqlConnection_1 begin ] stop
 */
	
	/**
	 * [tPostgresqlConnection_1 main ] start
	 */

	

	
	
	currentComponent="tPostgresqlConnection_1";

	

 


	tos_count_tPostgresqlConnection_1++;

/**
 * [tPostgresqlConnection_1 main ] stop
 */
	
	/**
	 * [tPostgresqlConnection_1 end ] start
	 */

	

	
	
	currentComponent="tPostgresqlConnection_1";

	

 
                if(log.isDebugEnabled())
            log.debug("tPostgresqlConnection_1 - "  + ("Done.") );

ok_Hash.put("tPostgresqlConnection_1", true);
end_Hash.put("tPostgresqlConnection_1", System.currentTimeMillis());




/**
 * [tPostgresqlConnection_1 end ] stop
 */
				}//end the resume

				
				    			if(resumeEntryMethodName == null || globalResumeTicket){
				    				resumeUtil.addLog("CHECKPOINT", "CONNECTION:SUBJOB_OK:tPostgresqlConnection_1:OnSubjobOk", "", Thread.currentThread().getId() + "", "", "", "", "", "");
								}	    				    			
					    	
								if(execStat){    	
									runStat.updateStatOnConnection("OnSubjobOk15", 0, "ok");
								} 
							
							tPostgresqlInput_1Process(globalMap); 
						



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage());
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tPostgresqlConnection_1 finally ] start
	 */

	

	
	
	currentComponent="tPostgresqlConnection_1";

	

 



/**
 * [tPostgresqlConnection_1 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tPostgresqlConnection_1_SUBPROCESS_STATE", 1);
	}
	


public static class row8Struct implements routines.system.IPersistableRow<row8Struct> {
    final static byte[] commonByteArrayLock_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Prod2Dev_with_GP_FDIST_child = new byte[0];
    static byte[] commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Prod2Dev_with_GP_FDIST_child = new byte[0];

	
			    public Integer cnt;

				public Integer getCnt () {
					return this.cnt;
				}
				


	private Integer readInteger(ObjectInputStream dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}

	private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException{
		if(intNum == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeInt(intNum);
    	}
	}

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Prod2Dev_with_GP_FDIST_child) {

        	try {

        		int length = 0;
		
						this.cnt = readInteger(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// Integer
				
						writeInteger(this.cnt,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("cnt="+String.valueOf(cnt));
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				if(cnt == null){
        					sb.append("<null>");
        				}else{
            				sb.append(cnt);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(row8Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}
public void tPostgresqlInput_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tPostgresqlInput_1_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;



		row8Struct row8 = new row8Struct();




	
	/**
	 * [tJavaRow_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tJavaRow_1", false);
		start_Hash.put("tJavaRow_1", System.currentTimeMillis());
		
	
	currentComponent="tJavaRow_1";

	
			if (execStat) {
				if(resourceMap.get("inIterateVComp") == null){
					
						runStat.updateStatOnConnection("row8" + iterateId, 0, 0);
					
				}
			} 

		
		int tos_count_tJavaRow_1 = 0;
		
    	class BytesLimit65535_tJavaRow_1{
    		public void limitLog4jByte() throws Exception{
    			
    		}
    	}
    	
        new BytesLimit65535_tJavaRow_1().limitLog4jByte();

int nb_line_tJavaRow_1 = 0;

 



/**
 * [tJavaRow_1 begin ] stop
 */



	
	/**
	 * [tPostgresqlInput_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tPostgresqlInput_1", false);
		start_Hash.put("tPostgresqlInput_1", System.currentTimeMillis());
		
	
	currentComponent="tPostgresqlInput_1";

	
		int tos_count_tPostgresqlInput_1 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tPostgresqlInput_1 - "  + ("Start to work.") );
    	class BytesLimit65535_tPostgresqlInput_1{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tPostgresqlInput_1 = new StringBuilder();
            log4jParamters_tPostgresqlInput_1.append("Parameters:");
                    log4jParamters_tPostgresqlInput_1.append("USE_EXISTING_CONNECTION" + " = " + "true");
                log4jParamters_tPostgresqlInput_1.append(" | ");
                    log4jParamters_tPostgresqlInput_1.append("CONNECTION" + " = " + "tPostgresqlConnection_1");
                log4jParamters_tPostgresqlInput_1.append(" | ");
                    log4jParamters_tPostgresqlInput_1.append("QUERYSTORE" + " = " + "\"\"");
                log4jParamters_tPostgresqlInput_1.append(" | ");
                    log4jParamters_tPostgresqlInput_1.append("QUERY" + " = " + "\" select count(*) as cnt\" +  \" from \" +   ((String)globalMap.get(\"row7.target_schema\")) + \".\" + ((String)globalMap.get(\"row7.target_table_name\"))  ");
                log4jParamters_tPostgresqlInput_1.append(" | ");
                    log4jParamters_tPostgresqlInput_1.append("USE_CURSOR" + " = " + "false");
                log4jParamters_tPostgresqlInput_1.append(" | ");
                    log4jParamters_tPostgresqlInput_1.append("TRIM_ALL_COLUMN" + " = " + "false");
                log4jParamters_tPostgresqlInput_1.append(" | ");
                    log4jParamters_tPostgresqlInput_1.append("TRIM_COLUMN" + " = " + "[{TRIM="+("false")+", SCHEMA_COLUMN="+("cnt")+"}]");
                log4jParamters_tPostgresqlInput_1.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tPostgresqlInput_1 - "  + (log4jParamters_tPostgresqlInput_1) );
    		}
    	}
    	
        new BytesLimit65535_tPostgresqlInput_1().limitLog4jByte();
	
    
	
		    int nb_line_tPostgresqlInput_1 = 0;
		    java.sql.Connection conn_tPostgresqlInput_1 = null;
		        conn_tPostgresqlInput_1 = (java.sql.Connection)globalMap.get("conn_tPostgresqlConnection_1");
				
				if(conn_tPostgresqlInput_1 != null) {
					if(conn_tPostgresqlInput_1.getMetaData() != null) {
						
						log.debug("tPostgresqlInput_1 - Uses an existing connection with username '" + conn_tPostgresqlInput_1.getMetaData().getUserName() + "'. Connection URL: " + conn_tPostgresqlInput_1.getMetaData().getURL() + ".");
						
					}
				}
			
		    
			java.sql.Statement stmt_tPostgresqlInput_1 = conn_tPostgresqlInput_1.createStatement();

		    String dbquery_tPostgresqlInput_1 = " select count(*) as cnt" +
" from " + 
((String)globalMap.get("row7.target_schema")) + "." + ((String)globalMap.get("row7.target_table_name"))  ;
			
                log.debug("tPostgresqlInput_1 - Executing the query: '"+dbquery_tPostgresqlInput_1+"'.");
			

                       globalMap.put("tPostgresqlInput_1_QUERY",dbquery_tPostgresqlInput_1);

		    java.sql.ResultSet rs_tPostgresqlInput_1 = null;
		try{
		    rs_tPostgresqlInput_1 = stmt_tPostgresqlInput_1.executeQuery(dbquery_tPostgresqlInput_1);
		    java.sql.ResultSetMetaData rsmd_tPostgresqlInput_1 = rs_tPostgresqlInput_1.getMetaData();
		    int colQtyInRs_tPostgresqlInput_1 = rsmd_tPostgresqlInput_1.getColumnCount();

		    String tmpContent_tPostgresqlInput_1 = null;
		    
		    
		    	log.debug("tPostgresqlInput_1 - Retrieving records from the database.");
		    
		    while (rs_tPostgresqlInput_1.next()) {
		        nb_line_tPostgresqlInput_1++;
		        
							if(colQtyInRs_tPostgresqlInput_1 < 1) {
								row8.cnt = null;
							} else {
		                          
            if(rs_tPostgresqlInput_1.getObject(1) != null) {
                row8.cnt = rs_tPostgresqlInput_1.getInt(1);
            } else {
                    row8.cnt = null;
            }
		                    }
					
						log.debug("tPostgresqlInput_1 - Retrieving the record " + nb_line_tPostgresqlInput_1 + ".");
					


 



/**
 * [tPostgresqlInput_1 begin ] stop
 */
	
	/**
	 * [tPostgresqlInput_1 main ] start
	 */

	

	
	
	currentComponent="tPostgresqlInput_1";

	

 


	tos_count_tPostgresqlInput_1++;

/**
 * [tPostgresqlInput_1 main ] stop
 */

	
	/**
	 * [tJavaRow_1 main ] start
	 */

	

	
	
	currentComponent="tJavaRow_1";

	

			//row8
			//row8


			
				if(execStat){
					runStat.updateStatOnConnection("row8"+iterateId,1, 1);
				} 
			

		
    			if(log.isTraceEnabled()){
    				log.trace("row8 - " + (row8==null? "": row8.toLogString()));
    			}
    		

    System.out.println("source count(*): " + row8.cnt);
globalMap.put("cnt", row8.cnt);
    nb_line_tJavaRow_1++;   

 


	tos_count_tJavaRow_1++;

/**
 * [tJavaRow_1 main ] stop
 */



	
	/**
	 * [tPostgresqlInput_1 end ] start
	 */

	

	
	
	currentComponent="tPostgresqlInput_1";

	

	}
}finally{
	stmt_tPostgresqlInput_1.close();

}
globalMap.put("tPostgresqlInput_1_NB_LINE",nb_line_tPostgresqlInput_1);
	    		log.debug("tPostgresqlInput_1 - Retrieved records count: "+nb_line_tPostgresqlInput_1 + " .");
			
 
                if(log.isDebugEnabled())
            log.debug("tPostgresqlInput_1 - "  + ("Done.") );

ok_Hash.put("tPostgresqlInput_1", true);
end_Hash.put("tPostgresqlInput_1", System.currentTimeMillis());




/**
 * [tPostgresqlInput_1 end ] stop
 */

	
	/**
	 * [tJavaRow_1 end ] start
	 */

	

	
	
	currentComponent="tJavaRow_1";

	

globalMap.put("tJavaRow_1_NB_LINE",nb_line_tJavaRow_1);
			if(execStat){
				if(resourceMap.get("inIterateVComp") == null || !((Boolean)resourceMap.get("inIterateVComp"))){
			 		runStat.updateStatOnConnection("row8"+iterateId,2, 0); 
			 	}
			}
		
 

ok_Hash.put("tJavaRow_1", true);
end_Hash.put("tJavaRow_1", System.currentTimeMillis());

   			if (true) {
   				
					if(execStat){   
   	 					runStat.updateStatOnConnection("If20", 0, "true");
					}
				
    			tJava_10Process(globalMap);
   			}

			   
   				else{
					if(execStat){   
   	 					runStat.updateStatOnConnection("If20", 0, "false");
					}   	 
   				}



/**
 * [tJavaRow_1 end ] stop
 */



				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage());
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tPostgresqlInput_1 finally ] start
	 */

	

	
	
	currentComponent="tPostgresqlInput_1";

	

 



/**
 * [tPostgresqlInput_1 finally ] stop
 */

	
	/**
	 * [tJavaRow_1 finally ] start
	 */

	

	
	
	currentComponent="tJavaRow_1";

	

 



/**
 * [tJavaRow_1 finally ] stop
 */



				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tPostgresqlInput_1_SUBPROCESS_STATE", 1);
	}
	

public void tJava_10Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tJava_10_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tJava_10 begin ] start
	 */

	

	
		
		ok_Hash.put("tJava_10", false);
		start_Hash.put("tJava_10", System.currentTimeMillis());
		
	
	currentComponent="tJava_10";

	
		int tos_count_tJava_10 = 0;
		
    	class BytesLimit65535_tJava_10{
    		public void limitLog4jByte() throws Exception{
    			
    		}
    	}
    	
        new BytesLimit65535_tJava_10().limitLog4jByte();



 



/**
 * [tJava_10 begin ] stop
 */
	
	/**
	 * [tJava_10 main ] start
	 */

	

	
	
	currentComponent="tJava_10";

	

 


	tos_count_tJava_10++;

/**
 * [tJava_10 main ] stop
 */
	
	/**
	 * [tJava_10 end ] start
	 */

	

	
	
	currentComponent="tJava_10";

	

 

ok_Hash.put("tJava_10", true);
end_Hash.put("tJava_10", System.currentTimeMillis());




/**
 * [tJava_10 end ] stop
 */
				}//end the resume

				
				    			if(resumeEntryMethodName == null || globalResumeTicket){
				    				resumeUtil.addLog("CHECKPOINT", "CONNECTION:SUBJOB_OK:tJava_10:OnSubjobOk", "", Thread.currentThread().getId() + "", "", "", "", "", "");
								}	    				    			
					    	
								if(execStat){    	
									runStat.updateStatOnConnection("OnSubjobOk16", 0, "ok");
								} 
							
							tPostgresqlInput_2Process(globalMap); 
						



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage());
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tJava_10 finally ] start
	 */

	

	
	
	currentComponent="tJava_10";

	

 



/**
 * [tJava_10 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tJava_10_SUBPROCESS_STATE", 1);
	}
	


public static class row4Struct implements routines.system.IPersistableRow<row4Struct> {
    final static byte[] commonByteArrayLock_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Prod2Dev_with_GP_FDIST_child = new byte[0];
    static byte[] commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Prod2Dev_with_GP_FDIST_child = new byte[0];

	
			    public String column_list;

				public String getColumn_list () {
					return this.column_list;
				}
				



	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Prod2Dev_with_GP_FDIST_child.length) {
				if(length < 1024 && commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Prod2Dev_with_GP_FDIST_child.length == 0) {
   					commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Prod2Dev_with_GP_FDIST_child = new byte[1024];
				} else {
   					commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Prod2Dev_with_GP_FDIST_child = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Prod2Dev_with_GP_FDIST_child, 0, length);
			strReturn = new String(commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Prod2Dev_with_GP_FDIST_child, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Prod2Dev_with_GP_FDIST_child) {

        	try {

        		int length = 0;
		
					this.column_list = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// String
				
						writeString(this.column_list,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("column_list="+column_list);
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				if(column_list == null){
        					sb.append("<null>");
        				}else{
            				sb.append(column_list);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(row4Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}
public void tPostgresqlInput_2Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tPostgresqlInput_2_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;



		row4Struct row4 = new row4Struct();




	
	/**
	 * [tFlowToIterate_3 begin ] start
	 */

				
			int NB_ITERATE_tJava_3 = 0; //for statistics
			

	
		
		ok_Hash.put("tFlowToIterate_3", false);
		start_Hash.put("tFlowToIterate_3", System.currentTimeMillis());
		
	
	currentComponent="tFlowToIterate_3";

	
			if (execStat) {
				if(resourceMap.get("inIterateVComp") == null){
					
						runStat.updateStatOnConnection("row4" + iterateId, 0, 0);
					
				}
			} 

		
		int tos_count_tFlowToIterate_3 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tFlowToIterate_3 - "  + ("Start to work.") );
    	class BytesLimit65535_tFlowToIterate_3{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tFlowToIterate_3 = new StringBuilder();
            log4jParamters_tFlowToIterate_3.append("Parameters:");
                    log4jParamters_tFlowToIterate_3.append("DEFAULT_MAP" + " = " + "true");
                log4jParamters_tFlowToIterate_3.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tFlowToIterate_3 - "  + (log4jParamters_tFlowToIterate_3) );
    		}
    	}
    	
        new BytesLimit65535_tFlowToIterate_3().limitLog4jByte();

int nb_line_tFlowToIterate_3 = 0;
int counter_tFlowToIterate_3 = 0;

 



/**
 * [tFlowToIterate_3 begin ] stop
 */



	
	/**
	 * [tPostgresqlInput_2 begin ] start
	 */

	

	
		
		ok_Hash.put("tPostgresqlInput_2", false);
		start_Hash.put("tPostgresqlInput_2", System.currentTimeMillis());
		
	
	currentComponent="tPostgresqlInput_2";

	
		int tos_count_tPostgresqlInput_2 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tPostgresqlInput_2 - "  + ("Start to work.") );
    	class BytesLimit65535_tPostgresqlInput_2{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tPostgresqlInput_2 = new StringBuilder();
            log4jParamters_tPostgresqlInput_2.append("Parameters:");
                    log4jParamters_tPostgresqlInput_2.append("USE_EXISTING_CONNECTION" + " = " + "true");
                log4jParamters_tPostgresqlInput_2.append(" | ");
                    log4jParamters_tPostgresqlInput_2.append("CONNECTION" + " = " + "tPostgresqlConnection_1");
                log4jParamters_tPostgresqlInput_2.append(" | ");
                    log4jParamters_tPostgresqlInput_2.append("QUERYSTORE" + " = " + "\"\"");
                log4jParamters_tPostgresqlInput_2.append(" | ");
                    log4jParamters_tPostgresqlInput_2.append("QUERY" + " = " + "\"SELECT string_agg('\\\"'||distribution_keys||'\\\"', ',') as column_list  FROM(  select distribution_keys   from  (  SELECT pgn.nspname as table_owner,  pgc.relname as table_name,  pga.attname as distribution_keys  FROM (SELECT gdp.localoid,  CASE  WHEN ( Array_upper(gdp.attrnums, 1) > 0 ) THEN  Unnest(gdp.attrnums)  ELSE NULL  END AS attnum  FROM gp_distribution_policy gdp  ORDER BY gdp.localoid) AS distrokey  INNER JOIN pg_class AS pgc ON distrokey.localoid = pgc.oid  INNER JOIN pg_namespace pgn ON pgc.relnamespace = pgn.oid  LEFT OUTER JOIN pg_attribute pga ON distrokey.attnum = pga.attnum AND distrokey.localoid = pga.attrelid   WHERE  lower(pgn.nspname)='\" +  ((String)globalMap.get(\"row7.target_schema\")).toLowerCase() +   \"' and lower(pgc.relname)='\" +  ((String)globalMap.get(\"row7.target_table_name\")).toLowerCase()  +\"' ORDER BY pgn.nspname,pgc.relname) as a) a;\"");
                log4jParamters_tPostgresqlInput_2.append(" | ");
                    log4jParamters_tPostgresqlInput_2.append("USE_CURSOR" + " = " + "false");
                log4jParamters_tPostgresqlInput_2.append(" | ");
                    log4jParamters_tPostgresqlInput_2.append("TRIM_ALL_COLUMN" + " = " + "false");
                log4jParamters_tPostgresqlInput_2.append(" | ");
                    log4jParamters_tPostgresqlInput_2.append("TRIM_COLUMN" + " = " + "[{TRIM="+("false")+", SCHEMA_COLUMN="+("column_list")+"}]");
                log4jParamters_tPostgresqlInput_2.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tPostgresqlInput_2 - "  + (log4jParamters_tPostgresqlInput_2) );
    		}
    	}
    	
        new BytesLimit65535_tPostgresqlInput_2().limitLog4jByte();
	
    
	
		    int nb_line_tPostgresqlInput_2 = 0;
		    java.sql.Connection conn_tPostgresqlInput_2 = null;
		        conn_tPostgresqlInput_2 = (java.sql.Connection)globalMap.get("conn_tPostgresqlConnection_1");
				
				if(conn_tPostgresqlInput_2 != null) {
					if(conn_tPostgresqlInput_2.getMetaData() != null) {
						
						log.debug("tPostgresqlInput_2 - Uses an existing connection with username '" + conn_tPostgresqlInput_2.getMetaData().getUserName() + "'. Connection URL: " + conn_tPostgresqlInput_2.getMetaData().getURL() + ".");
						
					}
				}
			
		    
			java.sql.Statement stmt_tPostgresqlInput_2 = conn_tPostgresqlInput_2.createStatement();

		    String dbquery_tPostgresqlInput_2 = "SELECT string_agg('\"'||distribution_keys||'\"', ',') as column_list\nFROM(\nselect distribution_keys\n from\n(\nSELECT pgn.nspname as table_owner,\npgc.relname as table_name,\npga.attname as distribution_keys\nFROM (SELECT gdp.localoid,\nCASE\nWHEN ( Array_upper(gdp.attrnums, 1) > 0 ) THEN\nUnnest(gdp.attrnums)\nELSE NULL\nEND AS attnum\nFROM gp_distribution_policy gdp\nORDER BY gdp.localoid) AS distrokey\nINNER JOIN pg_class AS pgc ON distrokey.localoid = pgc.oid\nINNER JOIN pg_namespace pgn ON pgc.relnamespace = pgn.oid\nLEFT OUTER JOIN pg_attribute pga ON distrokey.attnum = pga.attnum AND distrokey.localoid = pga.attrelid \nWHERE  lower(pgn.nspname)='" +
((String)globalMap.get("row7.target_schema")).toLowerCase() + 
"' and lower(pgc.relname)='" +
((String)globalMap.get("row7.target_table_name")).toLowerCase()
+"' ORDER BY pgn.nspname,pgc.relname) as a) a;";
			
                log.debug("tPostgresqlInput_2 - Executing the query: '"+dbquery_tPostgresqlInput_2+"'.");
			

                       globalMap.put("tPostgresqlInput_2_QUERY",dbquery_tPostgresqlInput_2);

		    java.sql.ResultSet rs_tPostgresqlInput_2 = null;
		try{
		    rs_tPostgresqlInput_2 = stmt_tPostgresqlInput_2.executeQuery(dbquery_tPostgresqlInput_2);
		    java.sql.ResultSetMetaData rsmd_tPostgresqlInput_2 = rs_tPostgresqlInput_2.getMetaData();
		    int colQtyInRs_tPostgresqlInput_2 = rsmd_tPostgresqlInput_2.getColumnCount();

		    String tmpContent_tPostgresqlInput_2 = null;
		    
		    
		    	log.debug("tPostgresqlInput_2 - Retrieving records from the database.");
		    
		    while (rs_tPostgresqlInput_2.next()) {
		        nb_line_tPostgresqlInput_2++;
		        
							if(colQtyInRs_tPostgresqlInput_2 < 1) {
								row4.column_list = null;
							} else {
	                         		
        	row4.column_list = routines.system.JDBCUtil.getString(rs_tPostgresqlInput_2, 1, false);
		                    }
					
						log.debug("tPostgresqlInput_2 - Retrieving the record " + nb_line_tPostgresqlInput_2 + ".");
					


 



/**
 * [tPostgresqlInput_2 begin ] stop
 */
	
	/**
	 * [tPostgresqlInput_2 main ] start
	 */

	

	
	
	currentComponent="tPostgresqlInput_2";

	

 


	tos_count_tPostgresqlInput_2++;

/**
 * [tPostgresqlInput_2 main ] stop
 */

	
	/**
	 * [tFlowToIterate_3 main ] start
	 */

	

	
	
	currentComponent="tFlowToIterate_3";

	

			//row4
			//row4


			
				if(execStat){
					runStat.updateStatOnConnection("row4"+iterateId,1, 1);
				} 
			

		
    			if(log.isTraceEnabled()){
    				log.trace("row4 - " + (row4==null? "": row4.toLogString()));
    			}
    		


    	
                if(log.isTraceEnabled())
            log.trace("tFlowToIterate_3 - "  + ("Set global var, key=row4.column_list, value=")  + (row4.column_list)  + (".") );            
            globalMap.put("row4.column_list", row4.column_list);
    	
 
	   nb_line_tFlowToIterate_3++;  
       counter_tFlowToIterate_3++;
                if(log.isDebugEnabled())
            log.debug("tFlowToIterate_3 - "  + ("Current iteration is: ")  + (counter_tFlowToIterate_3)  + (".") );
       globalMap.put("tFlowToIterate_3_CURRENT_ITERATION", counter_tFlowToIterate_3);
 


	tos_count_tFlowToIterate_3++;

/**
 * [tFlowToIterate_3 main ] stop
 */
	NB_ITERATE_tJava_3++;
	
	
					if(execStat){				
	       				runStat.updateStatOnConnection("OnSubjobOk104", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("OnSubjobOk111", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("OnSubjobOk17", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("If5", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("If22", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("OnComponentOk14", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("If43", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("OnSubjobOk79", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("OnComponentOk20", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("If21", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("OnSubjobOk78", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("OnSubjobOk61", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("OnComponentOk18", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("If25", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("OnComponentOk13", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("If15", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("If51", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("OnSubjobOk96", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("If40", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("OnSubjobOk50", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("OnSubjobOk71", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("If13", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("OnComponentOk19", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("OnComponentOk10", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("OnComponentOk29", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("OnSubjobOk110", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("OnComponentOk35", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("OnComponentOk7", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("If28", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("OnSubjobOk7", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("row9", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("If12", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("If39", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("If42", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("row12", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("row2", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("OnComponentOk22", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("If1", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("OnComponentOk17", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("OnSubjobOk108", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("OnSubjobOk19", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("OnComponentOk27", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("row13", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("If11", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("OnSubjobOk59", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("OnSubjobOk97", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("OnComponentOk33", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("OnSubjobOk103", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("OnComponentOk25", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("row6", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("OnSubjobOk107", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("OnSubjobOk86", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("row20", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("iterate7", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("OnSubjobOk14", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("OnSubjobOk72", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("OnComponentOk11", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("If14", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("If41", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("OnSubjobOk65", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("If49", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("iterate4", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("If8", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("row19", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("OnComponentOk26", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("If9", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("OnComponentOk28", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("OnSubjobOk68", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("OnSubjobError2", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("OnSubjobOk62", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("OnSubjobOk76", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("If38", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("If27", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("row1", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("If6", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("If26", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("OnComponentOk12", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("OnComponentOk34", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("If48", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("OnSubjobOk2", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("iterate8", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("OnComponentOk24", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("OnSubjobOk20", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("OnSubjobError1", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("row5", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("OnSubjobOk64", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("If16", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("row16", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("If47", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("row10", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("row17", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("OnSubjobOk60", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("If46", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("OnSubjobOk38", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("OnComponentOk6", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("OnSubjobOk66", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("OnSubjobOk95", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("OnSubjobOk63", 3, 0);
					}           			
				
				if(execStat){
					runStat.updateStatOnConnection("iterate3", 1, "exec" + NB_ITERATE_tJava_3);
					//Thread.sleep(1000);
				}				
			

	
	/**
	 * [tJava_3 begin ] start
	 */

	

	
		
		ok_Hash.put("tJava_3", false);
		start_Hash.put("tJava_3", System.currentTimeMillis());
		
	
	currentComponent="tJava_3";

	
		int tos_count_tJava_3 = 0;
		
    	class BytesLimit65535_tJava_3{
    		public void limitLog4jByte() throws Exception{
    			
    		}
    	}
    	
        new BytesLimit65535_tJava_3().limitLog4jByte();


if (row4.column_list != null) {
	globalMap.put("distributed", row4.column_list);
}
globalMap.put("distributed_by",globalMap.get("distributed"));
System.out.println((String)globalMap.get("distributed_by"));
 



/**
 * [tJava_3 begin ] stop
 */
	
	/**
	 * [tJava_3 main ] start
	 */

	

	
	
	currentComponent="tJava_3";

	

 


	tos_count_tJava_3++;

/**
 * [tJava_3 main ] stop
 */
	
	/**
	 * [tJava_3 end ] start
	 */

	

	
	
	currentComponent="tJava_3";

	

 

ok_Hash.put("tJava_3", true);
end_Hash.put("tJava_3", System.currentTimeMillis());

   			if (true
) {
   				
					if(execStat){   
   	 					runStat.updateStatOnConnection("If21", 0, "true");
					}
				
    			tJava_11Process(globalMap);
   			}

			   
   				else{
					if(execStat){   
   	 					runStat.updateStatOnConnection("If21", 0, "false");
					}   	 
   				}



/**
 * [tJava_3 end ] stop
 */
						if(execStat){
							runStat.updateStatOnConnection("iterate3", 2, "exec" + NB_ITERATE_tJava_3);
						}				
					







	
	/**
	 * [tPostgresqlInput_2 end ] start
	 */

	

	
	
	currentComponent="tPostgresqlInput_2";

	

	}
}finally{
	stmt_tPostgresqlInput_2.close();

}
globalMap.put("tPostgresqlInput_2_NB_LINE",nb_line_tPostgresqlInput_2);
	    		log.debug("tPostgresqlInput_2 - Retrieved records count: "+nb_line_tPostgresqlInput_2 + " .");
			
 
                if(log.isDebugEnabled())
            log.debug("tPostgresqlInput_2 - "  + ("Done.") );

ok_Hash.put("tPostgresqlInput_2", true);
end_Hash.put("tPostgresqlInput_2", System.currentTimeMillis());




/**
 * [tPostgresqlInput_2 end ] stop
 */

	
	/**
	 * [tFlowToIterate_3 end ] start
	 */

	

	
	
	currentComponent="tFlowToIterate_3";

	

globalMap.put("tFlowToIterate_3_NB_LINE",nb_line_tFlowToIterate_3);
			if(execStat){
				if(resourceMap.get("inIterateVComp") == null || !((Boolean)resourceMap.get("inIterateVComp"))){
			 		runStat.updateStatOnConnection("row4"+iterateId,2, 0); 
			 	}
			}
		
 
                if(log.isDebugEnabled())
            log.debug("tFlowToIterate_3 - "  + ("Done.") );

ok_Hash.put("tFlowToIterate_3", true);
end_Hash.put("tFlowToIterate_3", System.currentTimeMillis());




/**
 * [tFlowToIterate_3 end ] stop
 */



				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage());
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tPostgresqlInput_2 finally ] start
	 */

	

	
	
	currentComponent="tPostgresqlInput_2";

	

 



/**
 * [tPostgresqlInput_2 finally ] stop
 */

	
	/**
	 * [tFlowToIterate_3 finally ] start
	 */

	

	
	
	currentComponent="tFlowToIterate_3";

	

 



/**
 * [tFlowToIterate_3 finally ] stop
 */

	
	/**
	 * [tJava_3 finally ] start
	 */

	

	
	
	currentComponent="tJava_3";

	

 



/**
 * [tJava_3 finally ] stop
 */






				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tPostgresqlInput_2_SUBPROCESS_STATE", 1);
	}
	

public void tJava_11Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tJava_11_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tJava_11 begin ] start
	 */

	

	
		
		ok_Hash.put("tJava_11", false);
		start_Hash.put("tJava_11", System.currentTimeMillis());
		
	
	currentComponent="tJava_11";

	
		int tos_count_tJava_11 = 0;
		
    	class BytesLimit65535_tJava_11{
    		public void limitLog4jByte() throws Exception{
    			
    		}
    	}
    	
        new BytesLimit65535_tJava_11().limitLog4jByte();


String foo = "bar";
 



/**
 * [tJava_11 begin ] stop
 */
	
	/**
	 * [tJava_11 main ] start
	 */

	

	
	
	currentComponent="tJava_11";

	

 


	tos_count_tJava_11++;

/**
 * [tJava_11 main ] stop
 */
	
	/**
	 * [tJava_11 end ] start
	 */

	

	
	
	currentComponent="tJava_11";

	

 

ok_Hash.put("tJava_11", true);
end_Hash.put("tJava_11", System.currentTimeMillis());




/**
 * [tJava_11 end ] stop
 */
				}//end the resume

				
				    			if(resumeEntryMethodName == null || globalResumeTicket){
				    				resumeUtil.addLog("CHECKPOINT", "CONNECTION:SUBJOB_OK:tJava_11:OnSubjobOk", "", Thread.currentThread().getId() + "", "", "", "", "", "");
								}	    				    			
					    	
								if(execStat){    	
									runStat.updateStatOnConnection("OnSubjobOk17", 0, "ok");
								} 
							
							tPostgresqlInput_4Process(globalMap); 
						



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage());
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tJava_11 finally ] start
	 */

	

	
	
	currentComponent="tJava_11";

	

 



/**
 * [tJava_11 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tJava_11_SUBPROCESS_STATE", 1);
	}
	


public static class row17Struct implements routines.system.IPersistableRow<row17Struct> {
    final static byte[] commonByteArrayLock_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Prod2Dev_with_GP_FDIST_child = new byte[0];
    static byte[] commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Prod2Dev_with_GP_FDIST_child = new byte[0];

	
			    public String columnlist_select;

				public String getColumnlist_select () {
					return this.columnlist_select;
				}
				



	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Prod2Dev_with_GP_FDIST_child.length) {
				if(length < 1024 && commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Prod2Dev_with_GP_FDIST_child.length == 0) {
   					commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Prod2Dev_with_GP_FDIST_child = new byte[1024];
				} else {
   					commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Prod2Dev_with_GP_FDIST_child = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Prod2Dev_with_GP_FDIST_child, 0, length);
			strReturn = new String(commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Prod2Dev_with_GP_FDIST_child, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Prod2Dev_with_GP_FDIST_child) {

        	try {

        		int length = 0;
		
					this.columnlist_select = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// String
				
						writeString(this.columnlist_select,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("columnlist_select="+columnlist_select);
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				if(columnlist_select == null){
        					sb.append("<null>");
        				}else{
            				sb.append(columnlist_select);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(row17Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}
public void tPostgresqlInput_4Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tPostgresqlInput_4_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;



		row17Struct row17 = new row17Struct();




	
	/**
	 * [tFlowToIterate_1 begin ] start
	 */

				
			int NB_ITERATE_tJava_15 = 0; //for statistics
			

	
		
		ok_Hash.put("tFlowToIterate_1", false);
		start_Hash.put("tFlowToIterate_1", System.currentTimeMillis());
		
	
	currentComponent="tFlowToIterate_1";

	
			if (execStat) {
				if(resourceMap.get("inIterateVComp") == null){
					
						runStat.updateStatOnConnection("row17" + iterateId, 0, 0);
					
				}
			} 

		
		int tos_count_tFlowToIterate_1 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tFlowToIterate_1 - "  + ("Start to work.") );
    	class BytesLimit65535_tFlowToIterate_1{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tFlowToIterate_1 = new StringBuilder();
            log4jParamters_tFlowToIterate_1.append("Parameters:");
                    log4jParamters_tFlowToIterate_1.append("DEFAULT_MAP" + " = " + "true");
                log4jParamters_tFlowToIterate_1.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tFlowToIterate_1 - "  + (log4jParamters_tFlowToIterate_1) );
    		}
    	}
    	
        new BytesLimit65535_tFlowToIterate_1().limitLog4jByte();

int nb_line_tFlowToIterate_1 = 0;
int counter_tFlowToIterate_1 = 0;

 



/**
 * [tFlowToIterate_1 begin ] stop
 */



	
	/**
	 * [tPostgresqlInput_4 begin ] start
	 */

	

	
		
		ok_Hash.put("tPostgresqlInput_4", false);
		start_Hash.put("tPostgresqlInput_4", System.currentTimeMillis());
		
	
	currentComponent="tPostgresqlInput_4";

	
		int tos_count_tPostgresqlInput_4 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tPostgresqlInput_4 - "  + ("Start to work.") );
    	class BytesLimit65535_tPostgresqlInput_4{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tPostgresqlInput_4 = new StringBuilder();
            log4jParamters_tPostgresqlInput_4.append("Parameters:");
                    log4jParamters_tPostgresqlInput_4.append("USE_EXISTING_CONNECTION" + " = " + "true");
                log4jParamters_tPostgresqlInput_4.append(" | ");
                    log4jParamters_tPostgresqlInput_4.append("CONNECTION" + " = " + "tPostgresqlConnection_1");
                log4jParamters_tPostgresqlInput_4.append(" | ");
                    log4jParamters_tPostgresqlInput_4.append("QUERYSTORE" + " = " + "\"\"");
                log4jParamters_tPostgresqlInput_4.append(" | ");
                    log4jParamters_tPostgresqlInput_4.append("QUERY" + " = " + "\" select string_agg( \" +  \"	'\\\"'||column_name||'\\\" ' \" +    \" , ', ' ORDER BY ordinal_position) as columnlist_select\" +  \" from information_schema.columns\" +  \" where table_schema = '\" +  (String)globalMap.get(\"row7.target_schema\")  + \"' and table_name = '\" +   (String)globalMap.get(\"row7.target_table_name\")   + \"'\"");
                log4jParamters_tPostgresqlInput_4.append(" | ");
                    log4jParamters_tPostgresqlInput_4.append("USE_CURSOR" + " = " + "false");
                log4jParamters_tPostgresqlInput_4.append(" | ");
                    log4jParamters_tPostgresqlInput_4.append("TRIM_ALL_COLUMN" + " = " + "false");
                log4jParamters_tPostgresqlInput_4.append(" | ");
                    log4jParamters_tPostgresqlInput_4.append("TRIM_COLUMN" + " = " + "[{TRIM="+("false")+", SCHEMA_COLUMN="+("columnlist_select")+"}]");
                log4jParamters_tPostgresqlInput_4.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tPostgresqlInput_4 - "  + (log4jParamters_tPostgresqlInput_4) );
    		}
    	}
    	
        new BytesLimit65535_tPostgresqlInput_4().limitLog4jByte();
	
    
	
		    int nb_line_tPostgresqlInput_4 = 0;
		    java.sql.Connection conn_tPostgresqlInput_4 = null;
		        conn_tPostgresqlInput_4 = (java.sql.Connection)globalMap.get("conn_tPostgresqlConnection_1");
				
				if(conn_tPostgresqlInput_4 != null) {
					if(conn_tPostgresqlInput_4.getMetaData() != null) {
						
						log.debug("tPostgresqlInput_4 - Uses an existing connection with username '" + conn_tPostgresqlInput_4.getMetaData().getUserName() + "'. Connection URL: " + conn_tPostgresqlInput_4.getMetaData().getURL() + ".");
						
					}
				}
			
		    
			java.sql.Statement stmt_tPostgresqlInput_4 = conn_tPostgresqlInput_4.createStatement();

		    String dbquery_tPostgresqlInput_4 = " select string_agg( " +
"	'\"'||column_name||'\" ' " +  
" , ', ' ORDER BY ordinal_position) as columnlist_select" +
" from information_schema.columns" +
" where table_schema = '" +
(String)globalMap.get("row7.target_schema")
+ "' and table_name = '" + 
(String)globalMap.get("row7.target_table_name") 
+ "'";
			
                log.debug("tPostgresqlInput_4 - Executing the query: '"+dbquery_tPostgresqlInput_4+"'.");
			

                       globalMap.put("tPostgresqlInput_4_QUERY",dbquery_tPostgresqlInput_4);

		    java.sql.ResultSet rs_tPostgresqlInput_4 = null;
		try{
		    rs_tPostgresqlInput_4 = stmt_tPostgresqlInput_4.executeQuery(dbquery_tPostgresqlInput_4);
		    java.sql.ResultSetMetaData rsmd_tPostgresqlInput_4 = rs_tPostgresqlInput_4.getMetaData();
		    int colQtyInRs_tPostgresqlInput_4 = rsmd_tPostgresqlInput_4.getColumnCount();

		    String tmpContent_tPostgresqlInput_4 = null;
		    
		    
		    	log.debug("tPostgresqlInput_4 - Retrieving records from the database.");
		    
		    while (rs_tPostgresqlInput_4.next()) {
		        nb_line_tPostgresqlInput_4++;
		        
							if(colQtyInRs_tPostgresqlInput_4 < 1) {
								row17.columnlist_select = null;
							} else {
	                         		
        	row17.columnlist_select = routines.system.JDBCUtil.getString(rs_tPostgresqlInput_4, 1, false);
		                    }
					
						log.debug("tPostgresqlInput_4 - Retrieving the record " + nb_line_tPostgresqlInput_4 + ".");
					


 



/**
 * [tPostgresqlInput_4 begin ] stop
 */
	
	/**
	 * [tPostgresqlInput_4 main ] start
	 */

	

	
	
	currentComponent="tPostgresqlInput_4";

	

 


	tos_count_tPostgresqlInput_4++;

/**
 * [tPostgresqlInput_4 main ] stop
 */

	
	/**
	 * [tFlowToIterate_1 main ] start
	 */

	

	
	
	currentComponent="tFlowToIterate_1";

	

			//row17
			//row17


			
				if(execStat){
					runStat.updateStatOnConnection("row17"+iterateId,1, 1);
				} 
			

		
    			if(log.isTraceEnabled()){
    				log.trace("row17 - " + (row17==null? "": row17.toLogString()));
    			}
    		


    	
                if(log.isTraceEnabled())
            log.trace("tFlowToIterate_1 - "  + ("Set global var, key=row17.columnlist_select, value=")  + (row17.columnlist_select)  + (".") );            
            globalMap.put("row17.columnlist_select", row17.columnlist_select);
    	
 
	   nb_line_tFlowToIterate_1++;  
       counter_tFlowToIterate_1++;
                if(log.isDebugEnabled())
            log.debug("tFlowToIterate_1 - "  + ("Current iteration is: ")  + (counter_tFlowToIterate_1)  + (".") );
       globalMap.put("tFlowToIterate_1_CURRENT_ITERATION", counter_tFlowToIterate_1);
 


	tos_count_tFlowToIterate_1++;

/**
 * [tFlowToIterate_1 main ] stop
 */
	NB_ITERATE_tJava_15++;
	
	
					if(execStat){				
	       				runStat.updateStatOnConnection("OnSubjobOk107", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("OnSubjobOk86", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("OnSubjobOk104", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("OnSubjobOk111", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("If5", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("If22", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("row20", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("iterate7", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("OnSubjobOk14", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("OnComponentOk14", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("OnSubjobOk72", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("OnComponentOk11", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("If43", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("OnSubjobOk79", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("OnComponentOk20", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("If14", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("OnSubjobOk78", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("If41", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("OnSubjobOk61", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("OnSubjobOk65", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("OnComponentOk18", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("If25", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("If49", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("OnComponentOk13", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("If15", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("If51", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("iterate4", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("OnSubjobOk96", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("If8", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("If40", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("row19", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("OnSubjobOk50", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("OnComponentOk26", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("OnSubjobOk71", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("If9", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("OnComponentOk28", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("If13", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("OnComponentOk19", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("OnComponentOk10", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("OnSubjobOk68", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("OnComponentOk29", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("OnSubjobError2", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("OnSubjobOk110", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("OnSubjobOk62", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("OnSubjobOk76", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("If38", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("OnComponentOk35", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("If27", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("OnComponentOk7", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("row1", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("If6", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("If26", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("If28", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("OnSubjobOk7", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("OnComponentOk12", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("OnComponentOk34", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("row9", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("If12", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("If39", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("If48", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("OnSubjobOk2", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("If42", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("row12", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("row2", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("OnComponentOk22", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("If1", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("OnComponentOk17", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("OnSubjobOk108", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("OnComponentOk24", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("OnSubjobOk20", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("OnSubjobOk19", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("OnSubjobError1", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("OnComponentOk27", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("row5", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("OnSubjobOk64", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("If16", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("row13", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("row16", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("If47", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("row10", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("If11", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("OnSubjobOk60", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("OnSubjobOk59", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("If46", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("OnSubjobOk97", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("OnSubjobOk38", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("OnComponentOk33", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("OnComponentOk6", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("OnSubjobOk66", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("OnSubjobOk103", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("OnSubjobOk95", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("OnComponentOk25", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("row6", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("OnSubjobOk63", 3, 0);
					}           			
				
				if(execStat){
					runStat.updateStatOnConnection("iterate8", 1, "exec" + NB_ITERATE_tJava_15);
					//Thread.sleep(1000);
				}				
			

	
	/**
	 * [tJava_15 begin ] start
	 */

	

	
		
		ok_Hash.put("tJava_15", false);
		start_Hash.put("tJava_15", System.currentTimeMillis());
		
	
	currentComponent="tJava_15";

	
		int tos_count_tJava_15 = 0;
		
    	class BytesLimit65535_tJava_15{
    		public void limitLog4jByte() throws Exception{
    			
    		}
    	}
    	
        new BytesLimit65535_tJava_15().limitLog4jByte();


if (row17.columnlist_select != null) 
{
	globalMap.put("columnlist_select", row17.columnlist_select);
}
 



/**
 * [tJava_15 begin ] stop
 */
	
	/**
	 * [tJava_15 main ] start
	 */

	

	
	
	currentComponent="tJava_15";

	

 


	tos_count_tJava_15++;

/**
 * [tJava_15 main ] stop
 */
	
	/**
	 * [tJava_15 end ] start
	 */

	

	
	
	currentComponent="tJava_15";

	

 

ok_Hash.put("tJava_15", true);
end_Hash.put("tJava_15", System.currentTimeMillis());

   			if (true
) {
   				
					if(execStat){   
   	 					runStat.updateStatOnConnection("If40", 0, "true");
					}
				
    			tJava_29Process(globalMap);
   			}

			   
   				else{
					if(execStat){   
   	 					runStat.updateStatOnConnection("If40", 0, "false");
					}   	 
   				}



/**
 * [tJava_15 end ] stop
 */
						if(execStat){
							runStat.updateStatOnConnection("iterate8", 2, "exec" + NB_ITERATE_tJava_15);
						}				
					







	
	/**
	 * [tPostgresqlInput_4 end ] start
	 */

	

	
	
	currentComponent="tPostgresqlInput_4";

	

	}
}finally{
	stmt_tPostgresqlInput_4.close();

}
globalMap.put("tPostgresqlInput_4_NB_LINE",nb_line_tPostgresqlInput_4);
	    		log.debug("tPostgresqlInput_4 - Retrieved records count: "+nb_line_tPostgresqlInput_4 + " .");
			
 
                if(log.isDebugEnabled())
            log.debug("tPostgresqlInput_4 - "  + ("Done.") );

ok_Hash.put("tPostgresqlInput_4", true);
end_Hash.put("tPostgresqlInput_4", System.currentTimeMillis());




/**
 * [tPostgresqlInput_4 end ] stop
 */

	
	/**
	 * [tFlowToIterate_1 end ] start
	 */

	

	
	
	currentComponent="tFlowToIterate_1";

	

globalMap.put("tFlowToIterate_1_NB_LINE",nb_line_tFlowToIterate_1);
			if(execStat){
				if(resourceMap.get("inIterateVComp") == null || !((Boolean)resourceMap.get("inIterateVComp"))){
			 		runStat.updateStatOnConnection("row17"+iterateId,2, 0); 
			 	}
			}
		
 
                if(log.isDebugEnabled())
            log.debug("tFlowToIterate_1 - "  + ("Done.") );

ok_Hash.put("tFlowToIterate_1", true);
end_Hash.put("tFlowToIterate_1", System.currentTimeMillis());




/**
 * [tFlowToIterate_1 end ] stop
 */



				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage());
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tPostgresqlInput_4 finally ] start
	 */

	

	
	
	currentComponent="tPostgresqlInput_4";

	

 



/**
 * [tPostgresqlInput_4 finally ] stop
 */

	
	/**
	 * [tFlowToIterate_1 finally ] start
	 */

	

	
	
	currentComponent="tFlowToIterate_1";

	

 



/**
 * [tFlowToIterate_1 finally ] stop
 */

	
	/**
	 * [tJava_15 finally ] start
	 */

	

	
	
	currentComponent="tJava_15";

	

 



/**
 * [tJava_15 finally ] stop
 */






				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tPostgresqlInput_4_SUBPROCESS_STATE", 1);
	}
	

public void tJava_29Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tJava_29_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tJava_29 begin ] start
	 */

	

	
		
		ok_Hash.put("tJava_29", false);
		start_Hash.put("tJava_29", System.currentTimeMillis());
		
	
	currentComponent="tJava_29";

	
		int tos_count_tJava_29 = 0;
		
    	class BytesLimit65535_tJava_29{
    		public void limitLog4jByte() throws Exception{
    			
    		}
    	}
    	
        new BytesLimit65535_tJava_29().limitLog4jByte();


String foo = "bar";
 



/**
 * [tJava_29 begin ] stop
 */
	
	/**
	 * [tJava_29 main ] start
	 */

	

	
	
	currentComponent="tJava_29";

	

 


	tos_count_tJava_29++;

/**
 * [tJava_29 main ] stop
 */
	
	/**
	 * [tJava_29 end ] start
	 */

	

	
	
	currentComponent="tJava_29";

	

 

ok_Hash.put("tJava_29", true);
end_Hash.put("tJava_29", System.currentTimeMillis());




/**
 * [tJava_29 end ] stop
 */
				}//end the resume

				
				    			if(resumeEntryMethodName == null || globalResumeTicket){
				    				resumeUtil.addLog("CHECKPOINT", "CONNECTION:SUBJOB_OK:tJava_29:OnSubjobOk", "", Thread.currentThread().getId() + "", "", "", "", "", "");
								}	    				    			
					    	
								if(execStat){    	
									runStat.updateStatOnConnection("OnSubjobOk50", 0, "ok");
								} 
							
							tPostgresqlInput_3Process(globalMap); 
						



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage());
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tJava_29 finally ] start
	 */

	

	
	
	currentComponent="tJava_29";

	

 



/**
 * [tJava_29 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tJava_29_SUBPROCESS_STATE", 1);
	}
	


public static class row5Struct implements routines.system.IPersistableRow<row5Struct> {
    final static byte[] commonByteArrayLock_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Prod2Dev_with_GP_FDIST_child = new byte[0];
    static byte[] commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Prod2Dev_with_GP_FDIST_child = new byte[0];

	
			    public String ColumnList;

				public String getColumnList () {
					return this.ColumnList;
				}
				



	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Prod2Dev_with_GP_FDIST_child.length) {
				if(length < 1024 && commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Prod2Dev_with_GP_FDIST_child.length == 0) {
   					commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Prod2Dev_with_GP_FDIST_child = new byte[1024];
				} else {
   					commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Prod2Dev_with_GP_FDIST_child = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Prod2Dev_with_GP_FDIST_child, 0, length);
			strReturn = new String(commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Prod2Dev_with_GP_FDIST_child, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Prod2Dev_with_GP_FDIST_child) {

        	try {

        		int length = 0;
		
					this.ColumnList = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// String
				
						writeString(this.ColumnList,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("ColumnList="+ColumnList);
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				if(ColumnList == null){
        					sb.append("<null>");
        				}else{
            				sb.append(ColumnList);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(row5Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}
public void tPostgresqlInput_3Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tPostgresqlInput_3_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;



		row5Struct row5 = new row5Struct();




	
	/**
	 * [tFlowToIterate_4 begin ] start
	 */

				
			int NB_ITERATE_tJava_4 = 0; //for statistics
			

	
		
		ok_Hash.put("tFlowToIterate_4", false);
		start_Hash.put("tFlowToIterate_4", System.currentTimeMillis());
		
	
	currentComponent="tFlowToIterate_4";

	
			if (execStat) {
				if(resourceMap.get("inIterateVComp") == null){
					
						runStat.updateStatOnConnection("row5" + iterateId, 0, 0);
					
				}
			} 

		
		int tos_count_tFlowToIterate_4 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tFlowToIterate_4 - "  + ("Start to work.") );
    	class BytesLimit65535_tFlowToIterate_4{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tFlowToIterate_4 = new StringBuilder();
            log4jParamters_tFlowToIterate_4.append("Parameters:");
                    log4jParamters_tFlowToIterate_4.append("DEFAULT_MAP" + " = " + "true");
                log4jParamters_tFlowToIterate_4.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tFlowToIterate_4 - "  + (log4jParamters_tFlowToIterate_4) );
    		}
    	}
    	
        new BytesLimit65535_tFlowToIterate_4().limitLog4jByte();

int nb_line_tFlowToIterate_4 = 0;
int counter_tFlowToIterate_4 = 0;

 



/**
 * [tFlowToIterate_4 begin ] stop
 */



	
	/**
	 * [tPostgresqlInput_3 begin ] start
	 */

	

	
		
		ok_Hash.put("tPostgresqlInput_3", false);
		start_Hash.put("tPostgresqlInput_3", System.currentTimeMillis());
		
	
	currentComponent="tPostgresqlInput_3";

	
		int tos_count_tPostgresqlInput_3 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tPostgresqlInput_3 - "  + ("Start to work.") );
    	class BytesLimit65535_tPostgresqlInput_3{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tPostgresqlInput_3 = new StringBuilder();
            log4jParamters_tPostgresqlInput_3.append("Parameters:");
                    log4jParamters_tPostgresqlInput_3.append("USE_EXISTING_CONNECTION" + " = " + "true");
                log4jParamters_tPostgresqlInput_3.append(" | ");
                    log4jParamters_tPostgresqlInput_3.append("CONNECTION" + " = " + "tPostgresqlConnection_1");
                log4jParamters_tPostgresqlInput_3.append(" | ");
                    log4jParamters_tPostgresqlInput_3.append("QUERYSTORE" + " = " + "\"\"");
                log4jParamters_tPostgresqlInput_3.append(" | ");
                    log4jParamters_tPostgresqlInput_3.append("QUERY" + " = " + "\" select string_agg( \" +  \"	'\\\"'||column_name||'\\\" '||coalesce(data_type,'')||' '||\" +  \"	case when character_maximum_length is not null then '('||character_maximum_length||')' \" +  \"		 when numeric_scale not in (null, 0) then '('||numeric_precision||','||numeric_scale||')'\" +  \"	else '' end\" +   \" , ', ' ORDER BY ordinal_position) as ColumnList\" +  \" from information_schema.columns\" +  \" where table_schema = '\" +  (String)globalMap.get(\"row7.target_schema\")  + \"' and table_name = '\" +   (String)globalMap.get(\"row7.target_table_name\")  + \"' and column_name not in ('edl_is_deleted','edl_last_updated_date')\"");
                log4jParamters_tPostgresqlInput_3.append(" | ");
                    log4jParamters_tPostgresqlInput_3.append("USE_CURSOR" + " = " + "false");
                log4jParamters_tPostgresqlInput_3.append(" | ");
                    log4jParamters_tPostgresqlInput_3.append("TRIM_ALL_COLUMN" + " = " + "false");
                log4jParamters_tPostgresqlInput_3.append(" | ");
                    log4jParamters_tPostgresqlInput_3.append("TRIM_COLUMN" + " = " + "[{TRIM="+("false")+", SCHEMA_COLUMN="+("ColumnList")+"}]");
                log4jParamters_tPostgresqlInput_3.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tPostgresqlInput_3 - "  + (log4jParamters_tPostgresqlInput_3) );
    		}
    	}
    	
        new BytesLimit65535_tPostgresqlInput_3().limitLog4jByte();
	
    
	
		    int nb_line_tPostgresqlInput_3 = 0;
		    java.sql.Connection conn_tPostgresqlInput_3 = null;
		        conn_tPostgresqlInput_3 = (java.sql.Connection)globalMap.get("conn_tPostgresqlConnection_1");
				
				if(conn_tPostgresqlInput_3 != null) {
					if(conn_tPostgresqlInput_3.getMetaData() != null) {
						
						log.debug("tPostgresqlInput_3 - Uses an existing connection with username '" + conn_tPostgresqlInput_3.getMetaData().getUserName() + "'. Connection URL: " + conn_tPostgresqlInput_3.getMetaData().getURL() + ".");
						
					}
				}
			
		    
			java.sql.Statement stmt_tPostgresqlInput_3 = conn_tPostgresqlInput_3.createStatement();

		    String dbquery_tPostgresqlInput_3 = " select string_agg( " +
"	'\"'||column_name||'\" '||coalesce(data_type,'')||' '||" +
"	case when character_maximum_length is not null then '('||character_maximum_length||')' " +
"		 when numeric_scale not in (null, 0) then '('||numeric_precision||','||numeric_scale||')'" +
"	else '' end" + 
" , ', ' ORDER BY ordinal_position) as ColumnList" +
" from information_schema.columns" +
" where table_schema = '" +
(String)globalMap.get("row7.target_schema")
+ "' and table_name = '" + 
(String)globalMap.get("row7.target_table_name")
+ "' and column_name not in ('edl_is_deleted','edl_last_updated_date')";
			
                log.debug("tPostgresqlInput_3 - Executing the query: '"+dbquery_tPostgresqlInput_3+"'.");
			

                       globalMap.put("tPostgresqlInput_3_QUERY",dbquery_tPostgresqlInput_3);

		    java.sql.ResultSet rs_tPostgresqlInput_3 = null;
		try{
		    rs_tPostgresqlInput_3 = stmt_tPostgresqlInput_3.executeQuery(dbquery_tPostgresqlInput_3);
		    java.sql.ResultSetMetaData rsmd_tPostgresqlInput_3 = rs_tPostgresqlInput_3.getMetaData();
		    int colQtyInRs_tPostgresqlInput_3 = rsmd_tPostgresqlInput_3.getColumnCount();

		    String tmpContent_tPostgresqlInput_3 = null;
		    
		    
		    	log.debug("tPostgresqlInput_3 - Retrieving records from the database.");
		    
		    while (rs_tPostgresqlInput_3.next()) {
		        nb_line_tPostgresqlInput_3++;
		        
							if(colQtyInRs_tPostgresqlInput_3 < 1) {
								row5.ColumnList = null;
							} else {
	                         		
        	row5.ColumnList = routines.system.JDBCUtil.getString(rs_tPostgresqlInput_3, 1, false);
		                    }
					
						log.debug("tPostgresqlInput_3 - Retrieving the record " + nb_line_tPostgresqlInput_3 + ".");
					


 



/**
 * [tPostgresqlInput_3 begin ] stop
 */
	
	/**
	 * [tPostgresqlInput_3 main ] start
	 */

	

	
	
	currentComponent="tPostgresqlInput_3";

	

 


	tos_count_tPostgresqlInput_3++;

/**
 * [tPostgresqlInput_3 main ] stop
 */

	
	/**
	 * [tFlowToIterate_4 main ] start
	 */

	

	
	
	currentComponent="tFlowToIterate_4";

	

			//row5
			//row5


			
				if(execStat){
					runStat.updateStatOnConnection("row5"+iterateId,1, 1);
				} 
			

		
    			if(log.isTraceEnabled()){
    				log.trace("row5 - " + (row5==null? "": row5.toLogString()));
    			}
    		


    	
                if(log.isTraceEnabled())
            log.trace("tFlowToIterate_4 - "  + ("Set global var, key=row5.ColumnList, value=")  + (row5.ColumnList)  + (".") );            
            globalMap.put("row5.ColumnList", row5.ColumnList);
    	
 
	   nb_line_tFlowToIterate_4++;  
       counter_tFlowToIterate_4++;
                if(log.isDebugEnabled())
            log.debug("tFlowToIterate_4 - "  + ("Current iteration is: ")  + (counter_tFlowToIterate_4)  + (".") );
       globalMap.put("tFlowToIterate_4_CURRENT_ITERATION", counter_tFlowToIterate_4);
 


	tos_count_tFlowToIterate_4++;

/**
 * [tFlowToIterate_4 main ] stop
 */
	NB_ITERATE_tJava_4++;
	
	
					if(execStat){				
	       				runStat.updateStatOnConnection("OnSubjobOk107", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("OnSubjobOk86", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("OnSubjobOk104", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("OnSubjobOk111", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("If5", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("If22", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("row20", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("iterate7", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("OnSubjobOk14", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("OnComponentOk14", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("OnSubjobOk72", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("OnComponentOk11", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("If43", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("OnSubjobOk79", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("OnComponentOk20", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("If14", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("OnSubjobOk78", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("If41", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("OnSubjobOk61", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("OnSubjobOk65", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("OnComponentOk18", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("If25", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("If49", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("OnComponentOk13", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("If15", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("If51", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("OnSubjobOk96", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("If8", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("row19", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("OnComponentOk26", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("OnSubjobOk71", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("If9", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("OnComponentOk28", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("If13", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("OnComponentOk19", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("OnComponentOk10", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("OnSubjobOk68", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("OnComponentOk29", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("OnSubjobError2", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("OnSubjobOk110", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("OnSubjobOk62", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("OnSubjobOk76", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("If38", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("OnComponentOk35", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("If27", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("OnComponentOk7", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("row1", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("If6", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("If26", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("If28", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("OnSubjobOk7", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("OnComponentOk12", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("OnComponentOk34", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("row9", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("If12", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("If39", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("If48", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("OnSubjobOk2", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("If42", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("row12", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("row2", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("OnComponentOk22", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("If1", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("OnComponentOk17", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("OnSubjobOk108", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("OnComponentOk24", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("OnSubjobOk20", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("OnSubjobOk19", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("OnSubjobError1", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("OnComponentOk27", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("OnSubjobOk64", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("If16", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("row13", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("row16", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("If47", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("row10", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("If11", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("OnSubjobOk60", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("OnSubjobOk59", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("If46", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("OnSubjobOk97", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("OnSubjobOk38", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("OnComponentOk33", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("OnComponentOk6", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("OnSubjobOk66", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("OnSubjobOk103", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("OnSubjobOk95", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("OnComponentOk25", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("row6", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("OnSubjobOk63", 3, 0);
					}           			
				
				if(execStat){
					runStat.updateStatOnConnection("iterate4", 1, "exec" + NB_ITERATE_tJava_4);
					//Thread.sleep(1000);
				}				
			

	
	/**
	 * [tJava_4 begin ] start
	 */

	

	
		
		ok_Hash.put("tJava_4", false);
		start_Hash.put("tJava_4", System.currentTimeMillis());
		
	
	currentComponent="tJava_4";

	
		int tos_count_tJava_4 = 0;
		
    	class BytesLimit65535_tJava_4{
    		public void limitLog4jByte() throws Exception{
    			
    		}
    	}
    	
        new BytesLimit65535_tJava_4().limitLog4jByte();


globalMap.put("columnlist", (String)globalMap.get("row5.ColumnList"));

if (globalMap.get("distributed").equals("")==false) {
	String str;
	str = "DISTRIBUTED BY (" + globalMap.get("distributed") + ");\n";
/*	str = str + "ALTER TABLE " + (String)globalMap.get("row7.target_schema") +
	"." + ((String)globalMap.get("row1.target_table_name")) +
	" ADD CONSTRAINT uq_" + ((String)globalMap.get("row7.target_table_name")) +
	" UNIQUE (" + globalMap.get("distributed") + ");";*/
	globalMap.put("distributed", str);
} 

System.out.println(
"CREATE TABLE " + (String)globalMap.get("row7.target_schema") + "." + 
(String)globalMap.get("row7.target_table_name") +" ( " + 
(String)globalMap.get("columnlist") + " )"+
globalMap.get("distributed")
);
 



/**
 * [tJava_4 begin ] stop
 */
	
	/**
	 * [tJava_4 main ] start
	 */

	

	
	
	currentComponent="tJava_4";

	

 


	tos_count_tJava_4++;

/**
 * [tJava_4 main ] stop
 */
	
	/**
	 * [tJava_4 end ] start
	 */

	

	
	
	currentComponent="tJava_4";

	

 

ok_Hash.put("tJava_4", true);
end_Hash.put("tJava_4", System.currentTimeMillis());

				if(execStat){   
   	 				runStat.updateStatOnConnection("OnComponentOk17", 0, "ok");
				}
				tPostgresqlClose_1Process(globalMap);



/**
 * [tJava_4 end ] stop
 */
						if(execStat){
							runStat.updateStatOnConnection("iterate4", 2, "exec" + NB_ITERATE_tJava_4);
						}				
					







	
	/**
	 * [tPostgresqlInput_3 end ] start
	 */

	

	
	
	currentComponent="tPostgresqlInput_3";

	

	}
}finally{
	stmt_tPostgresqlInput_3.close();

}
globalMap.put("tPostgresqlInput_3_NB_LINE",nb_line_tPostgresqlInput_3);
	    		log.debug("tPostgresqlInput_3 - Retrieved records count: "+nb_line_tPostgresqlInput_3 + " .");
			
 
                if(log.isDebugEnabled())
            log.debug("tPostgresqlInput_3 - "  + ("Done.") );

ok_Hash.put("tPostgresqlInput_3", true);
end_Hash.put("tPostgresqlInput_3", System.currentTimeMillis());




/**
 * [tPostgresqlInput_3 end ] stop
 */

	
	/**
	 * [tFlowToIterate_4 end ] start
	 */

	

	
	
	currentComponent="tFlowToIterate_4";

	

globalMap.put("tFlowToIterate_4_NB_LINE",nb_line_tFlowToIterate_4);
			if(execStat){
				if(resourceMap.get("inIterateVComp") == null || !((Boolean)resourceMap.get("inIterateVComp"))){
			 		runStat.updateStatOnConnection("row5"+iterateId,2, 0); 
			 	}
			}
		
 
                if(log.isDebugEnabled())
            log.debug("tFlowToIterate_4 - "  + ("Done.") );

ok_Hash.put("tFlowToIterate_4", true);
end_Hash.put("tFlowToIterate_4", System.currentTimeMillis());




/**
 * [tFlowToIterate_4 end ] stop
 */



				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage());
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tPostgresqlInput_3 finally ] start
	 */

	

	
	
	currentComponent="tPostgresqlInput_3";

	

 



/**
 * [tPostgresqlInput_3 finally ] stop
 */

	
	/**
	 * [tFlowToIterate_4 finally ] start
	 */

	

	
	
	currentComponent="tFlowToIterate_4";

	

 



/**
 * [tFlowToIterate_4 finally ] stop
 */

	
	/**
	 * [tJava_4 finally ] start
	 */

	

	
	
	currentComponent="tJava_4";

	

 



/**
 * [tJava_4 finally ] stop
 */






				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tPostgresqlInput_3_SUBPROCESS_STATE", 1);
	}
	

public void tPostgresqlClose_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tPostgresqlClose_1_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tPostgresqlClose_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tPostgresqlClose_1", false);
		start_Hash.put("tPostgresqlClose_1", System.currentTimeMillis());
		
	
	currentComponent="tPostgresqlClose_1";

	
		int tos_count_tPostgresqlClose_1 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tPostgresqlClose_1 - "  + ("Start to work.") );
    	class BytesLimit65535_tPostgresqlClose_1{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tPostgresqlClose_1 = new StringBuilder();
            log4jParamters_tPostgresqlClose_1.append("Parameters:");
                    log4jParamters_tPostgresqlClose_1.append("CONNECTION" + " = " + "tPostgresqlConnection_1");
                log4jParamters_tPostgresqlClose_1.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tPostgresqlClose_1 - "  + (log4jParamters_tPostgresqlClose_1) );
    		}
    	}
    	
        new BytesLimit65535_tPostgresqlClose_1().limitLog4jByte();

 



/**
 * [tPostgresqlClose_1 begin ] stop
 */
	
	/**
	 * [tPostgresqlClose_1 main ] start
	 */

	

	
	
	currentComponent="tPostgresqlClose_1";

	



	java.sql.Connection conn_tPostgresqlClose_1 = (java.sql.Connection)globalMap.get("conn_tPostgresqlConnection_1");
	if(conn_tPostgresqlClose_1 != null && !conn_tPostgresqlClose_1.isClosed())
	{
                if(log.isDebugEnabled())
            log.debug("tPostgresqlClose_1 - "  + ("Closing the connection ")  + ("conn_tPostgresqlConnection_1")  + (" to the database.") );
        conn_tPostgresqlClose_1.close();
                if(log.isDebugEnabled())
            log.debug("tPostgresqlClose_1 - "  + ("Connection ")  + ("conn_tPostgresqlConnection_1")  + (" to the database has closed.") );
	}

 


	tos_count_tPostgresqlClose_1++;

/**
 * [tPostgresqlClose_1 main ] stop
 */
	
	/**
	 * [tPostgresqlClose_1 end ] start
	 */

	

	
	
	currentComponent="tPostgresqlClose_1";

	

 
                if(log.isDebugEnabled())
            log.debug("tPostgresqlClose_1 - "  + ("Done.") );

ok_Hash.put("tPostgresqlClose_1", true);
end_Hash.put("tPostgresqlClose_1", System.currentTimeMillis());




/**
 * [tPostgresqlClose_1 end ] stop
 */
				}//end the resume

				
				    			if(resumeEntryMethodName == null || globalResumeTicket){
				    				resumeUtil.addLog("CHECKPOINT", "CONNECTION:SUBJOB_OK:tPostgresqlClose_1:OnSubjobOk", "", Thread.currentThread().getId() + "", "", "", "", "", "");
								}	    				    			
					    	
								if(execStat){    	
									runStat.updateStatOnConnection("OnSubjobOk79", 0, "ok");
								} 
							
							tJava_6Process(globalMap); 
						



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage());
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tPostgresqlClose_1 finally ] start
	 */

	

	
	
	currentComponent="tPostgresqlClose_1";

	

 



/**
 * [tPostgresqlClose_1 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tPostgresqlClose_1_SUBPROCESS_STATE", 1);
	}
	

public void tJava_6Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tJava_6_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tJava_6 begin ] start
	 */

	

	
		
		ok_Hash.put("tJava_6", false);
		start_Hash.put("tJava_6", System.currentTimeMillis());
		
	
	currentComponent="tJava_6";

	
		int tos_count_tJava_6 = 0;
		
    	class BytesLimit65535_tJava_6{
    		public void limitLog4jByte() throws Exception{
    			
    		}
    	}
    	
        new BytesLimit65535_tJava_6().limitLog4jByte();


//System.out.println(((String)globalMap.get("row7.update_type")));
System.out.println(((String)globalMap.get("where_cond")));
 



/**
 * [tJava_6 begin ] stop
 */
	
	/**
	 * [tJava_6 main ] start
	 */

	

	
	
	currentComponent="tJava_6";

	

 


	tos_count_tJava_6++;

/**
 * [tJava_6 main ] stop
 */
	
	/**
	 * [tJava_6 end ] start
	 */

	

	
	
	currentComponent="tJava_6";

	

 

ok_Hash.put("tJava_6", true);
end_Hash.put("tJava_6", System.currentTimeMillis());

   			if (((String)globalMap.get("row7.update_type")).equals("Full")
) {
   				
					if(execStat){   
   	 					runStat.updateStatOnConnection("If11", 0, "true");
					}
				
    			tJava_7Process(globalMap);
   			}

			   
   				else{
					if(execStat){   
   	 					runStat.updateStatOnConnection("If11", 0, "false");
					}   	 
   				}
   			if (!((String)globalMap.get("row7.update_type")).equals("Full")) {
   				
					if(execStat){   
   	 					runStat.updateStatOnConnection("If12", 0, "true");
					}
				
    			tSetGlobalVar_8Process(globalMap);
   			}

			   
   				else{
					if(execStat){   
   	 					runStat.updateStatOnConnection("If12", 0, "false");
					}   	 
   				}



/**
 * [tJava_6 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage());
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tJava_6 finally ] start
	 */

	

	
	
	currentComponent="tJava_6";

	

 



/**
 * [tJava_6 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tJava_6_SUBPROCESS_STATE", 1);
	}
	

public void tJava_7Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tJava_7_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tJava_7 begin ] start
	 */

	

	
		
		ok_Hash.put("tJava_7", false);
		start_Hash.put("tJava_7", System.currentTimeMillis());
		
	
	currentComponent="tJava_7";

	
		int tos_count_tJava_7 = 0;
		
    	class BytesLimit65535_tJava_7{
    		public void limitLog4jByte() throws Exception{
    			
    		}
    	}
    	
        new BytesLimit65535_tJava_7().limitLog4jByte();


if (((String)globalMap.get("row7.source_schema")).contains(".") )
{

String str=((String)globalMap.get("row7.source_schema"));

context.ORIG_DATABASE_NAME=str.substring(0,str.indexOf("."));
System.out.println(context.SOURCE_DATABASE);
globalMap.put("glschema", str.substring(str.indexOf(".")+1));
System.out.println(((String)globalMap.get("glschema")));


}

globalMap.put("filetocheck", 
context.ETL_STORAGE_PATH + "/" + context.GP_SOURCE_NAME + '/' + "/data/" + 
context.ORIG_DATABASE_NAME + "/" + ((String)globalMap.get("row7.log_table_name")).replace("\"","").replace("#","__hash__").replace("$","__dollar__")  + 
".gz");
 



/**
 * [tJava_7 begin ] stop
 */
	
	/**
	 * [tJava_7 main ] start
	 */

	

	
	
	currentComponent="tJava_7";

	

 


	tos_count_tJava_7++;

/**
 * [tJava_7 main ] stop
 */
	
	/**
	 * [tJava_7 end ] start
	 */

	

	
	
	currentComponent="tJava_7";

	

 

ok_Hash.put("tJava_7", true);
end_Hash.put("tJava_7", System.currentTimeMillis());




/**
 * [tJava_7 end ] stop
 */
				}//end the resume

				
				    			if(resumeEntryMethodName == null || globalResumeTicket){
				    				resumeUtil.addLog("CHECKPOINT", "CONNECTION:SUBJOB_OK:tJava_7:OnSubjobOk", "", Thread.currentThread().getId() + "", "", "", "", "", "");
								}	    				    			
					    	
								if(execStat){    	
									runStat.updateStatOnConnection("OnSubjobOk38", 0, "ok");
								} 
							
							tFileExist_2Process(globalMap); 
						



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage());
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tJava_7 finally ] start
	 */

	

	
	
	currentComponent="tJava_7";

	

 



/**
 * [tJava_7 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tJava_7_SUBPROCESS_STATE", 1);
	}
	

public void tFileExist_2Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tFileExist_2_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tFileExist_2 begin ] start
	 */

	

	
		
		ok_Hash.put("tFileExist_2", false);
		start_Hash.put("tFileExist_2", System.currentTimeMillis());
		
	
	currentComponent="tFileExist_2";

	
		int tos_count_tFileExist_2 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tFileExist_2 - "  + ("Start to work.") );
    	class BytesLimit65535_tFileExist_2{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tFileExist_2 = new StringBuilder();
            log4jParamters_tFileExist_2.append("Parameters:");
                    log4jParamters_tFileExist_2.append("FILE_NAME" + " = " + "(String)globalMap.get(\"filetocheck\")");
                log4jParamters_tFileExist_2.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tFileExist_2 - "  + (log4jParamters_tFileExist_2) );
    		}
    	}
    	
        new BytesLimit65535_tFileExist_2().limitLog4jByte();

 



/**
 * [tFileExist_2 begin ] stop
 */
	
	/**
	 * [tFileExist_2 main ] start
	 */

	

	
	
	currentComponent="tFileExist_2";

	


				final StringBuffer log4jSb_tFileExist_2 = new StringBuffer();
			

java.io.File file_tFileExist_2 = new java.io.File((String)globalMap.get("filetocheck"));
if (!file_tFileExist_2.exists()) {
    globalMap.put("tFileExist_2_EXISTS",false);
    log.info("tFileExist_2 - Directory or file : " + file_tFileExist_2.getAbsolutePath() + " doesn't exist.");
}else{
	globalMap.put("tFileExist_2_EXISTS",true);
    log.info("tFileExist_2 - Directory or file : " + file_tFileExist_2.getAbsolutePath() + " exists.");
}

globalMap.put("tFileExist_2_FILENAME",(String)globalMap.get("filetocheck"));


 


	tos_count_tFileExist_2++;

/**
 * [tFileExist_2 main ] stop
 */
	
	/**
	 * [tFileExist_2 end ] start
	 */

	

	
	
	currentComponent="tFileExist_2";

	

 
                if(log.isDebugEnabled())
            log.debug("tFileExist_2 - "  + ("Done.") );

ok_Hash.put("tFileExist_2", true);
end_Hash.put("tFileExist_2", System.currentTimeMillis());

   			if (((Boolean)globalMap.get("tFileExist_2_EXISTS"))) {
   				
					if(execStat){   
   	 					runStat.updateStatOnConnection("If13", 0, "true");
					}
				
    			tFileProperties_2Process(globalMap);
   			}

			   
   				else{
					if(execStat){   
   	 					runStat.updateStatOnConnection("If13", 0, "false");
					}   	 
   				}
   			if (!((Boolean)globalMap.get("tFileExist_2_EXISTS"))) {
   				
					if(execStat){   
   	 					runStat.updateStatOnConnection("If16", 0, "true");
					}
				
    			tJava_8Process(globalMap);
   			}

			   
   				else{
					if(execStat){   
   	 					runStat.updateStatOnConnection("If16", 0, "false");
					}   	 
   				}



/**
 * [tFileExist_2 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage());
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tFileExist_2 finally ] start
	 */

	

	
	
	currentComponent="tFileExist_2";

	

 



/**
 * [tFileExist_2 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tFileExist_2_SUBPROCESS_STATE", 1);
	}
	


public static class row10Struct implements routines.system.IPersistableRow<row10Struct> {
    final static byte[] commonByteArrayLock_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Prod2Dev_with_GP_FDIST_child = new byte[0];
    static byte[] commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Prod2Dev_with_GP_FDIST_child = new byte[0];

	
			    public String abs_path;

				public String getAbs_path () {
					return this.abs_path;
				}
				
			    public String dirname;

				public String getDirname () {
					return this.dirname;
				}
				
			    public String basename;

				public String getBasename () {
					return this.basename;
				}
				
			    public String mode_string;

				public String getMode_string () {
					return this.mode_string;
				}
				
			    public Long size;

				public Long getSize () {
					return this.size;
				}
				
			    public Long mtime;

				public Long getMtime () {
					return this.mtime;
				}
				
			    public String mtime_string;

				public String getMtime_string () {
					return this.mtime_string;
				}
				



	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Prod2Dev_with_GP_FDIST_child.length) {
				if(length < 1024 && commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Prod2Dev_with_GP_FDIST_child.length == 0) {
   					commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Prod2Dev_with_GP_FDIST_child = new byte[1024];
				} else {
   					commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Prod2Dev_with_GP_FDIST_child = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Prod2Dev_with_GP_FDIST_child, 0, length);
			strReturn = new String(commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Prod2Dev_with_GP_FDIST_child, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Prod2Dev_with_GP_FDIST_child) {

        	try {

        		int length = 0;
		
					this.abs_path = readString(dis);
					
					this.dirname = readString(dis);
					
					this.basename = readString(dis);
					
					this.mode_string = readString(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.size = null;
           				} else {
           			    	this.size = dis.readLong();
           				}
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.mtime = null;
           				} else {
           			    	this.mtime = dis.readLong();
           				}
					
					this.mtime_string = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// String
				
						writeString(this.abs_path,dos);
					
					// String
				
						writeString(this.dirname,dos);
					
					// String
				
						writeString(this.basename,dos);
					
					// String
				
						writeString(this.mode_string,dos);
					
					// Long
				
						if(this.size == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeLong(this.size);
		            	}
					
					// Long
				
						if(this.mtime == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeLong(this.mtime);
		            	}
					
					// String
				
						writeString(this.mtime_string,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("abs_path="+abs_path);
		sb.append(",dirname="+dirname);
		sb.append(",basename="+basename);
		sb.append(",mode_string="+mode_string);
		sb.append(",size="+String.valueOf(size));
		sb.append(",mtime="+String.valueOf(mtime));
		sb.append(",mtime_string="+mtime_string);
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				if(abs_path == null){
        					sb.append("<null>");
        				}else{
            				sb.append(abs_path);
            			}
            		
        			sb.append("|");
        		
        				if(dirname == null){
        					sb.append("<null>");
        				}else{
            				sb.append(dirname);
            			}
            		
        			sb.append("|");
        		
        				if(basename == null){
        					sb.append("<null>");
        				}else{
            				sb.append(basename);
            			}
            		
        			sb.append("|");
        		
        				if(mode_string == null){
        					sb.append("<null>");
        				}else{
            				sb.append(mode_string);
            			}
            		
        			sb.append("|");
        		
        				if(size == null){
        					sb.append("<null>");
        				}else{
            				sb.append(size);
            			}
            		
        			sb.append("|");
        		
        				if(mtime == null){
        					sb.append("<null>");
        				}else{
            				sb.append(mtime);
            			}
            		
        			sb.append("|");
        		
        				if(mtime_string == null){
        					sb.append("<null>");
        				}else{
            				sb.append(mtime_string);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(row10Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}
public void tFileProperties_2Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tFileProperties_2_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;



		row10Struct row10 = new row10Struct();




	
	/**
	 * [tSetGlobalVar_5 begin ] start
	 */

	

	
		
		ok_Hash.put("tSetGlobalVar_5", false);
		start_Hash.put("tSetGlobalVar_5", System.currentTimeMillis());
		
	
	currentComponent="tSetGlobalVar_5";

	
			if (execStat) {
				if(resourceMap.get("inIterateVComp") == null){
					
						runStat.updateStatOnConnection("row10" + iterateId, 0, 0);
					
				}
			} 

		
		int tos_count_tSetGlobalVar_5 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tSetGlobalVar_5 - "  + ("Start to work.") );
    	class BytesLimit65535_tSetGlobalVar_5{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tSetGlobalVar_5 = new StringBuilder();
            log4jParamters_tSetGlobalVar_5.append("Parameters:");
                    log4jParamters_tSetGlobalVar_5.append("VARIABLES" + " = " + "[{VALUE="+("row10.size == null ? \"0\" : Long.toString(row10.size)")+", KEY="+("\"fileSize\"")+"}]");
                log4jParamters_tSetGlobalVar_5.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tSetGlobalVar_5 - "  + (log4jParamters_tSetGlobalVar_5) );
    		}
    	}
    	
        new BytesLimit65535_tSetGlobalVar_5().limitLog4jByte();

 



/**
 * [tSetGlobalVar_5 begin ] stop
 */



	
	/**
	 * [tFileProperties_2 begin ] start
	 */

	

	
		
		ok_Hash.put("tFileProperties_2", false);
		start_Hash.put("tFileProperties_2", System.currentTimeMillis());
		
	
	currentComponent="tFileProperties_2";

	
		int tos_count_tFileProperties_2 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tFileProperties_2 - "  + ("Start to work.") );
    	class BytesLimit65535_tFileProperties_2{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tFileProperties_2 = new StringBuilder();
            log4jParamters_tFileProperties_2.append("Parameters:");
                    log4jParamters_tFileProperties_2.append("FILENAME" + " = " + "(String)globalMap.get(\"filetocheck\")");
                log4jParamters_tFileProperties_2.append(" | ");
                    log4jParamters_tFileProperties_2.append("MD5" + " = " + "false");
                log4jParamters_tFileProperties_2.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tFileProperties_2 - "  + (log4jParamters_tFileProperties_2) );
    		}
    	}
    	
        new BytesLimit65535_tFileProperties_2().limitLog4jByte();


				final StringBuffer log4jSb_tFileProperties_2 = new StringBuffer();
			

java.io.File file_tFileProperties_2 = new java.io.File((String)globalMap.get("filetocheck"));
row10 = new row10Struct();

if(file_tFileProperties_2.exists()) {
    row10.abs_path = file_tFileProperties_2.getAbsolutePath();
    row10.dirname = file_tFileProperties_2.getParent();
    row10.basename = file_tFileProperties_2.getName();
    String r_tFileProperties_2 = (file_tFileProperties_2.canRead())?"r":"-";
	String w_tFileProperties_2 = (file_tFileProperties_2.canWrite())?"w":"-";
	//String x_ = (file_.canExecute())?"x":"-"; /*since JDK1.6*/
    row10.mode_string = r_tFileProperties_2 + w_tFileProperties_2;
    row10.size = file_tFileProperties_2.length();
    row10.mtime = file_tFileProperties_2.lastModified();
    row10.mtime_string =(new java.util.Date(file_tFileProperties_2.lastModified())).toString();
	
	
}
	else {
		log.info("tFileProperties_2 - File : " + file_tFileProperties_2.getAbsolutePath() + " doesn't exist.");
	}
 



/**
 * [tFileProperties_2 begin ] stop
 */
	
	/**
	 * [tFileProperties_2 main ] start
	 */

	

	
	
	currentComponent="tFileProperties_2";

	

 


	tos_count_tFileProperties_2++;

/**
 * [tFileProperties_2 main ] stop
 */

	
	/**
	 * [tSetGlobalVar_5 main ] start
	 */

	

	
	
	currentComponent="tSetGlobalVar_5";

	

			//row10
			//row10


			
				if(execStat){
					runStat.updateStatOnConnection("row10"+iterateId,1, 1);
				} 
			

		
    			if(log.isTraceEnabled()){
    				log.trace("row10 - " + (row10==null? "": row10.toLogString()));
    			}
    		

globalMap.put("fileSize", row10.size == null ? "0" : Long.toString(row10.size));

 


	tos_count_tSetGlobalVar_5++;

/**
 * [tSetGlobalVar_5 main ] stop
 */



	
	/**
	 * [tFileProperties_2 end ] start
	 */

	

	
	
	currentComponent="tFileProperties_2";

	

 
                if(log.isDebugEnabled())
            log.debug("tFileProperties_2 - "  + ("Done.") );

ok_Hash.put("tFileProperties_2", true);
end_Hash.put("tFileProperties_2", System.currentTimeMillis());




/**
 * [tFileProperties_2 end ] stop
 */

	
	/**
	 * [tSetGlobalVar_5 end ] start
	 */

	

	
	
	currentComponent="tSetGlobalVar_5";

	

			if(execStat){
				if(resourceMap.get("inIterateVComp") == null || !((Boolean)resourceMap.get("inIterateVComp"))){
			 		runStat.updateStatOnConnection("row10"+iterateId,2, 0); 
			 	}
			}
		
 
                if(log.isDebugEnabled())
            log.debug("tSetGlobalVar_5 - "  + ("Done.") );

ok_Hash.put("tSetGlobalVar_5", true);
end_Hash.put("tSetGlobalVar_5", System.currentTimeMillis());

   			if ((row10.size == null ? "20" : Long.toString(row10.size)).equals("20") == false
) {
   				
					if(execStat){   
   	 					runStat.updateStatOnConnection("If14", 0, "true");
					}
				
    			tFileProperties_3Process(globalMap);
   			}

			   
   				else{
					if(execStat){   
   	 					runStat.updateStatOnConnection("If14", 0, "false");
					}   	 
   				}
   			if ((row10.size == null ? "20" : Long.toString(row10.size)).equals("20") == true
) {
   				
					if(execStat){   
   	 					runStat.updateStatOnConnection("If15", 0, "true");
					}
				
    			tJava_8Process(globalMap);
   			}

			   
   				else{
					if(execStat){   
   	 					runStat.updateStatOnConnection("If15", 0, "false");
					}   	 
   				}



/**
 * [tSetGlobalVar_5 end ] stop
 */



				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage());
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tFileProperties_2 finally ] start
	 */

	

	
	
	currentComponent="tFileProperties_2";

	

 



/**
 * [tFileProperties_2 finally ] stop
 */

	
	/**
	 * [tSetGlobalVar_5 finally ] start
	 */

	

	
	
	currentComponent="tSetGlobalVar_5";

	

 



/**
 * [tSetGlobalVar_5 finally ] stop
 */



				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tFileProperties_2_SUBPROCESS_STATE", 1);
	}
	


public static class row1Struct implements routines.system.IPersistableRow<row1Struct> {
    final static byte[] commonByteArrayLock_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Prod2Dev_with_GP_FDIST_child = new byte[0];
    static byte[] commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Prod2Dev_with_GP_FDIST_child = new byte[0];

	
			    public String abs_path;

				public String getAbs_path () {
					return this.abs_path;
				}
				
			    public String dirname;

				public String getDirname () {
					return this.dirname;
				}
				
			    public String basename;

				public String getBasename () {
					return this.basename;
				}
				
			    public String mode_string;

				public String getMode_string () {
					return this.mode_string;
				}
				
			    public Long size;

				public Long getSize () {
					return this.size;
				}
				
			    public Long mtime;

				public Long getMtime () {
					return this.mtime;
				}
				
			    public String mtime_string;

				public String getMtime_string () {
					return this.mtime_string;
				}
				



	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Prod2Dev_with_GP_FDIST_child.length) {
				if(length < 1024 && commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Prod2Dev_with_GP_FDIST_child.length == 0) {
   					commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Prod2Dev_with_GP_FDIST_child = new byte[1024];
				} else {
   					commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Prod2Dev_with_GP_FDIST_child = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Prod2Dev_with_GP_FDIST_child, 0, length);
			strReturn = new String(commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Prod2Dev_with_GP_FDIST_child, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Prod2Dev_with_GP_FDIST_child) {

        	try {

        		int length = 0;
		
					this.abs_path = readString(dis);
					
					this.dirname = readString(dis);
					
					this.basename = readString(dis);
					
					this.mode_string = readString(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.size = null;
           				} else {
           			    	this.size = dis.readLong();
           				}
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.mtime = null;
           				} else {
           			    	this.mtime = dis.readLong();
           				}
					
					this.mtime_string = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// String
				
						writeString(this.abs_path,dos);
					
					// String
				
						writeString(this.dirname,dos);
					
					// String
				
						writeString(this.basename,dos);
					
					// String
				
						writeString(this.mode_string,dos);
					
					// Long
				
						if(this.size == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeLong(this.size);
		            	}
					
					// Long
				
						if(this.mtime == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeLong(this.mtime);
		            	}
					
					// String
				
						writeString(this.mtime_string,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("abs_path="+abs_path);
		sb.append(",dirname="+dirname);
		sb.append(",basename="+basename);
		sb.append(",mode_string="+mode_string);
		sb.append(",size="+String.valueOf(size));
		sb.append(",mtime="+String.valueOf(mtime));
		sb.append(",mtime_string="+mtime_string);
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				if(abs_path == null){
        					sb.append("<null>");
        				}else{
            				sb.append(abs_path);
            			}
            		
        			sb.append("|");
        		
        				if(dirname == null){
        					sb.append("<null>");
        				}else{
            				sb.append(dirname);
            			}
            		
        			sb.append("|");
        		
        				if(basename == null){
        					sb.append("<null>");
        				}else{
            				sb.append(basename);
            			}
            		
        			sb.append("|");
        		
        				if(mode_string == null){
        					sb.append("<null>");
        				}else{
            				sb.append(mode_string);
            			}
            		
        			sb.append("|");
        		
        				if(size == null){
        					sb.append("<null>");
        				}else{
            				sb.append(size);
            			}
            		
        			sb.append("|");
        		
        				if(mtime == null){
        					sb.append("<null>");
        				}else{
            				sb.append(mtime);
            			}
            		
        			sb.append("|");
        		
        				if(mtime_string == null){
        					sb.append("<null>");
        				}else{
            				sb.append(mtime_string);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(row1Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}
public void tFileProperties_3Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tFileProperties_3_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;



		row1Struct row1 = new row1Struct();




	
	/**
	 * [tSetGlobalVar_6 begin ] start
	 */

	

	
		
		ok_Hash.put("tSetGlobalVar_6", false);
		start_Hash.put("tSetGlobalVar_6", System.currentTimeMillis());
		
	
	currentComponent="tSetGlobalVar_6";

	
			if (execStat) {
				if(resourceMap.get("inIterateVComp") == null){
					
						runStat.updateStatOnConnection("row1" + iterateId, 0, 0);
					
				}
			} 

		
		int tos_count_tSetGlobalVar_6 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tSetGlobalVar_6 - "  + ("Start to work.") );
    	class BytesLimit65535_tSetGlobalVar_6{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tSetGlobalVar_6 = new StringBuilder();
            log4jParamters_tSetGlobalVar_6.append("Parameters:");
                    log4jParamters_tSetGlobalVar_6.append("VARIABLES" + " = " + "[{VALUE="+("row1.mtime")+", KEY="+("\"filmtime\"")+"}]");
                log4jParamters_tSetGlobalVar_6.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tSetGlobalVar_6 - "  + (log4jParamters_tSetGlobalVar_6) );
    		}
    	}
    	
        new BytesLimit65535_tSetGlobalVar_6().limitLog4jByte();

 



/**
 * [tSetGlobalVar_6 begin ] stop
 */



	
	/**
	 * [tFileProperties_3 begin ] start
	 */

	

	
		
		ok_Hash.put("tFileProperties_3", false);
		start_Hash.put("tFileProperties_3", System.currentTimeMillis());
		
	
	currentComponent="tFileProperties_3";

	
		int tos_count_tFileProperties_3 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tFileProperties_3 - "  + ("Start to work.") );
    	class BytesLimit65535_tFileProperties_3{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tFileProperties_3 = new StringBuilder();
            log4jParamters_tFileProperties_3.append("Parameters:");
                    log4jParamters_tFileProperties_3.append("FILENAME" + " = " + "(String)globalMap.get(\"filetocheck\")");
                log4jParamters_tFileProperties_3.append(" | ");
                    log4jParamters_tFileProperties_3.append("MD5" + " = " + "false");
                log4jParamters_tFileProperties_3.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tFileProperties_3 - "  + (log4jParamters_tFileProperties_3) );
    		}
    	}
    	
        new BytesLimit65535_tFileProperties_3().limitLog4jByte();


				final StringBuffer log4jSb_tFileProperties_3 = new StringBuffer();
			

java.io.File file_tFileProperties_3 = new java.io.File((String)globalMap.get("filetocheck"));
row1 = new row1Struct();

if(file_tFileProperties_3.exists()) {
    row1.abs_path = file_tFileProperties_3.getAbsolutePath();
    row1.dirname = file_tFileProperties_3.getParent();
    row1.basename = file_tFileProperties_3.getName();
    String r_tFileProperties_3 = (file_tFileProperties_3.canRead())?"r":"-";
	String w_tFileProperties_3 = (file_tFileProperties_3.canWrite())?"w":"-";
	//String x_ = (file_.canExecute())?"x":"-"; /*since JDK1.6*/
    row1.mode_string = r_tFileProperties_3 + w_tFileProperties_3;
    row1.size = file_tFileProperties_3.length();
    row1.mtime = file_tFileProperties_3.lastModified();
    row1.mtime_string =(new java.util.Date(file_tFileProperties_3.lastModified())).toString();
	
	
}
	else {
		log.info("tFileProperties_3 - File : " + file_tFileProperties_3.getAbsolutePath() + " doesn't exist.");
	}
 



/**
 * [tFileProperties_3 begin ] stop
 */
	
	/**
	 * [tFileProperties_3 main ] start
	 */

	

	
	
	currentComponent="tFileProperties_3";

	

 


	tos_count_tFileProperties_3++;

/**
 * [tFileProperties_3 main ] stop
 */

	
	/**
	 * [tSetGlobalVar_6 main ] start
	 */

	

	
	
	currentComponent="tSetGlobalVar_6";

	

			//row1
			//row1


			
				if(execStat){
					runStat.updateStatOnConnection("row1"+iterateId,1, 1);
				} 
			

		
    			if(log.isTraceEnabled()){
    				log.trace("row1 - " + (row1==null? "": row1.toLogString()));
    			}
    		

globalMap.put("filmtime", row1.mtime);

 


	tos_count_tSetGlobalVar_6++;

/**
 * [tSetGlobalVar_6 main ] stop
 */



	
	/**
	 * [tFileProperties_3 end ] start
	 */

	

	
	
	currentComponent="tFileProperties_3";

	

 
                if(log.isDebugEnabled())
            log.debug("tFileProperties_3 - "  + ("Done.") );

ok_Hash.put("tFileProperties_3", true);
end_Hash.put("tFileProperties_3", System.currentTimeMillis());




/**
 * [tFileProperties_3 end ] stop
 */

	
	/**
	 * [tSetGlobalVar_6 end ] start
	 */

	

	
	
	currentComponent="tSetGlobalVar_6";

	

			if(execStat){
				if(resourceMap.get("inIterateVComp") == null || !((Boolean)resourceMap.get("inIterateVComp"))){
			 		runStat.updateStatOnConnection("row1"+iterateId,2, 0); 
			 	}
			}
		
 
                if(log.isDebugEnabled())
            log.debug("tSetGlobalVar_6 - "  + ("Done.") );

ok_Hash.put("tSetGlobalVar_6", true);
end_Hash.put("tSetGlobalVar_6", System.currentTimeMillis());

   			if (((System.currentTimeMillis())-((Long)globalMap.get("filmtime")))>345600000L) {
   				
					if(execStat){   
   	 					runStat.updateStatOnConnection("If26", 0, "true");
					}
				
    			tJava_8Process(globalMap);
   			}

			   
   				else{
					if(execStat){   
   	 					runStat.updateStatOnConnection("If26", 0, "false");
					}   	 
   				}
   			if (!(((System.currentTimeMillis())-((Long)globalMap.get("filmtime")))>345600000L)) {
   				
					if(execStat){   
   	 					runStat.updateStatOnConnection("If27", 0, "true");
					}
				
    			tJava_5Process(globalMap);
   			}

			   
   				else{
					if(execStat){   
   	 					runStat.updateStatOnConnection("If27", 0, "false");
					}   	 
   				}



/**
 * [tSetGlobalVar_6 end ] stop
 */



				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage());
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tFileProperties_3 finally ] start
	 */

	

	
	
	currentComponent="tFileProperties_3";

	

 



/**
 * [tFileProperties_3 finally ] stop
 */

	
	/**
	 * [tSetGlobalVar_6 finally ] start
	 */

	

	
	
	currentComponent="tSetGlobalVar_6";

	

 



/**
 * [tSetGlobalVar_6 finally ] stop
 */



				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tFileProperties_3_SUBPROCESS_STATE", 1);
	}
	

public void tJava_8Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tJava_8_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tJava_8 begin ] start
	 */

	

	
		
		ok_Hash.put("tJava_8", false);
		start_Hash.put("tJava_8", System.currentTimeMillis());
		
	
	currentComponent="tJava_8";

	
		int tos_count_tJava_8 = 0;
		
    	class BytesLimit65535_tJava_8{
    		public void limitLog4jByte() throws Exception{
    			
    		}
    	}
    	
        new BytesLimit65535_tJava_8().limitLog4jByte();


globalMap.put("filetocheck", 
context.ETL_STORAGE_PATH + "/" + context.GP_SOURCE_NAME + '/' + "/data/" + 
context.SOURCE_DATABASE + "/" + ((String)globalMap.get("row7.log_table_name")).replace("\"","").replace("#","__hash__").replace("$","__dollar__")  + 
".gz");
System.out.println(String.valueOf(System.currentTimeMillis()));
System.out.println(String.valueOf( ((Long)globalMap.get("filmtime")) ) );
 



/**
 * [tJava_8 begin ] stop
 */
	
	/**
	 * [tJava_8 main ] start
	 */

	

	
	
	currentComponent="tJava_8";

	

 


	tos_count_tJava_8++;

/**
 * [tJava_8 main ] stop
 */
	
	/**
	 * [tJava_8 end ] start
	 */

	

	
	
	currentComponent="tJava_8";

	

 

ok_Hash.put("tJava_8", true);
end_Hash.put("tJava_8", System.currentTimeMillis());




/**
 * [tJava_8 end ] stop
 */
				}//end the resume

				
				    			if(resumeEntryMethodName == null || globalResumeTicket){
				    				resumeUtil.addLog("CHECKPOINT", "CONNECTION:SUBJOB_OK:tJava_8:OnSubjobOk", "", Thread.currentThread().getId() + "", "", "", "", "", "");
								}	    				    			
					    	
								if(execStat){    	
									runStat.updateStatOnConnection("OnSubjobOk61", 0, "ok");
								} 
							
							tSetGlobalVar_8Process(globalMap); 
						



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage());
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tJava_8 finally ] start
	 */

	

	
	
	currentComponent="tJava_8";

	

 



/**
 * [tJava_8 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tJava_8_SUBPROCESS_STATE", 1);
	}
	

public void tSetGlobalVar_8Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tSetGlobalVar_8_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tSetGlobalVar_8 begin ] start
	 */

	

	
		
		ok_Hash.put("tSetGlobalVar_8", false);
		start_Hash.put("tSetGlobalVar_8", System.currentTimeMillis());
		
	
	currentComponent="tSetGlobalVar_8";

	
		int tos_count_tSetGlobalVar_8 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tSetGlobalVar_8 - "  + ("Start to work.") );
    	class BytesLimit65535_tSetGlobalVar_8{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tSetGlobalVar_8 = new StringBuilder();
            log4jParamters_tSetGlobalVar_8.append("Parameters:");
                    log4jParamters_tSetGlobalVar_8.append("VARIABLES" + " = " + "[{VALUE="+("TalendDate.getDate(\"yyyyMMddHH24mmssSSS\")")+", KEY="+("\"stringtimestamp\"")+"}, {VALUE="+("\"\"")+", KEY="+("\"port\"")+"}]");
                log4jParamters_tSetGlobalVar_8.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tSetGlobalVar_8 - "  + (log4jParamters_tSetGlobalVar_8) );
    		}
    	}
    	
        new BytesLimit65535_tSetGlobalVar_8().limitLog4jByte();

 



/**
 * [tSetGlobalVar_8 begin ] stop
 */
	
	/**
	 * [tSetGlobalVar_8 main ] start
	 */

	

	
	
	currentComponent="tSetGlobalVar_8";

	

globalMap.put("stringtimestamp", TalendDate.getDate("yyyyMMddHH24mmssSSS"));
globalMap.put("port", "");

 


	tos_count_tSetGlobalVar_8++;

/**
 * [tSetGlobalVar_8 main ] stop
 */
	
	/**
	 * [tSetGlobalVar_8 end ] start
	 */

	

	
	
	currentComponent="tSetGlobalVar_8";

	

 
                if(log.isDebugEnabled())
            log.debug("tSetGlobalVar_8 - "  + ("Done.") );

ok_Hash.put("tSetGlobalVar_8", true);
end_Hash.put("tSetGlobalVar_8", System.currentTimeMillis());




/**
 * [tSetGlobalVar_8 end ] stop
 */
				}//end the resume

				
				    			if(resumeEntryMethodName == null || globalResumeTicket){
				    				resumeUtil.addLog("CHECKPOINT", "CONNECTION:SUBJOB_OK:tSetGlobalVar_8:OnSubjobOk", "", Thread.currentThread().getId() + "", "", "", "", "", "");
								}	    				    			
					    	
								if(execStat){    	
									runStat.updateStatOnConnection("OnSubjobOk68", 0, "ok");
								} 
							
							tFileTouch_1Process(globalMap); 
						



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage());
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tSetGlobalVar_8 finally ] start
	 */

	

	
	
	currentComponent="tSetGlobalVar_8";

	

 



/**
 * [tSetGlobalVar_8 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tSetGlobalVar_8_SUBPROCESS_STATE", 1);
	}
	

public void tFileTouch_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tFileTouch_1_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tFileTouch_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tFileTouch_1", false);
		start_Hash.put("tFileTouch_1", System.currentTimeMillis());
		
	
	currentComponent="tFileTouch_1";

	
		int tos_count_tFileTouch_1 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tFileTouch_1 - "  + ("Start to work.") );
    	class BytesLimit65535_tFileTouch_1{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tFileTouch_1 = new StringBuilder();
            log4jParamters_tFileTouch_1.append("Parameters:");
                    log4jParamters_tFileTouch_1.append("FILENAME" + " = " + "context.ETL_STORAGE_PATH + \"/\" + context.GP_SOURCE_NAME + '/' + \"/data/\" + context.SOURCE_DATABASE + \"/log_\"+((String)globalMap.get(\"stringtimestamp\"))");
                log4jParamters_tFileTouch_1.append(" | ");
                    log4jParamters_tFileTouch_1.append("CREATEDIR" + " = " + "true");
                log4jParamters_tFileTouch_1.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tFileTouch_1 - "  + (log4jParamters_tFileTouch_1) );
    		}
    	}
    	
        new BytesLimit65535_tFileTouch_1().limitLog4jByte();

 



/**
 * [tFileTouch_1 begin ] stop
 */
	
	/**
	 * [tFileTouch_1 main ] start
	 */

	

	
	
	currentComponent="tFileTouch_1";

	
	

 

				final StringBuffer log4jSb_tFileTouch_1 = new StringBuffer();
			     
		java.io.File file_tFileTouch_1 = new java.io.File((context.ETL_STORAGE_PATH + "/" + context.GP_SOURCE_NAME + '/' + "/data/" + context.SOURCE_DATABASE + "/log_"+((String)globalMap.get("stringtimestamp"))));
		java.io.File dir_tFileTouch_1 = file_tFileTouch_1.getParentFile();
		if(dir_tFileTouch_1!= null){
		dir_tFileTouch_1.mkdirs();
		}        
        
        //create new file
        boolean resulttFileTouch_1 = file_tFileTouch_1.createNewFile();
        //if file already exists, modify the last-modified-time of the file
        if (!resulttFileTouch_1) {
    		log.info("tFileTouch_1 - File : " + file_tFileTouch_1.getAbsolutePath() + " already exist, only modify the last-modified-time of the file.");
    		
        	file_tFileTouch_1.setLastModified((new Date()).getTime());
        }
        else {
        	log.info("tFileTouch_1 - File : " + file_tFileTouch_1.getAbsolutePath() + " is created successfully");
        }
  		
  		      

 


	tos_count_tFileTouch_1++;

/**
 * [tFileTouch_1 main ] stop
 */
	
	/**
	 * [tFileTouch_1 end ] start
	 */

	

	
	
	currentComponent="tFileTouch_1";

	

 
                if(log.isDebugEnabled())
            log.debug("tFileTouch_1 - "  + ("Done.") );

ok_Hash.put("tFileTouch_1", true);
end_Hash.put("tFileTouch_1", System.currentTimeMillis());




/**
 * [tFileTouch_1 end ] stop
 */
				}//end the resume

				
				    			if(resumeEntryMethodName == null || globalResumeTicket){
				    				resumeUtil.addLog("CHECKPOINT", "CONNECTION:SUBJOB_OK:tFileTouch_1:OnSubjobOk", "", Thread.currentThread().getId() + "", "", "", "", "", "");
								}	    				    			
					    	
								if(execStat){    	
									runStat.updateStatOnConnection("OnSubjobOk2", 0, "ok");
								} 
							
							tSystem_1Process(globalMap); 
						



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage());
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tFileTouch_1 finally ] start
	 */

	

	
	
	currentComponent="tFileTouch_1";

	

 



/**
 * [tFileTouch_1 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tFileTouch_1_SUBPROCESS_STATE", 1);
	}
	


public static class row12Struct implements routines.system.IPersistableRow<row12Struct> {
    final static byte[] commonByteArrayLock_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Prod2Dev_with_GP_FDIST_child = new byte[0];
    static byte[] commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Prod2Dev_with_GP_FDIST_child = new byte[0];

	
			    public String outputline;

				public String getOutputline () {
					return this.outputline;
				}
				



	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Prod2Dev_with_GP_FDIST_child.length) {
				if(length < 1024 && commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Prod2Dev_with_GP_FDIST_child.length == 0) {
   					commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Prod2Dev_with_GP_FDIST_child = new byte[1024];
				} else {
   					commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Prod2Dev_with_GP_FDIST_child = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Prod2Dev_with_GP_FDIST_child, 0, length);
			strReturn = new String(commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Prod2Dev_with_GP_FDIST_child, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Prod2Dev_with_GP_FDIST_child) {

        	try {

        		int length = 0;
		
					this.outputline = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// String
				
						writeString(this.outputline,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("outputline="+outputline);
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				if(outputline == null){
        					sb.append("<null>");
        				}else{
            				sb.append(outputline);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(row12Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}
public void tSystem_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tSystem_1_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;



		row12Struct row12 = new row12Struct();




	
	/**
	 * [tFlowToIterate_6 begin ] start
	 */

				
			int NB_ITERATE_tJava_18 = 0; //for statistics
			

	
		
		ok_Hash.put("tFlowToIterate_6", false);
		start_Hash.put("tFlowToIterate_6", System.currentTimeMillis());
		
	
	currentComponent="tFlowToIterate_6";

	
			if (execStat) {
				if(resourceMap.get("inIterateVComp") == null){
					
						runStat.updateStatOnConnection("row12" + iterateId, 0, 0);
					
				}
			} 

		
		int tos_count_tFlowToIterate_6 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tFlowToIterate_6 - "  + ("Start to work.") );
    	class BytesLimit65535_tFlowToIterate_6{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tFlowToIterate_6 = new StringBuilder();
            log4jParamters_tFlowToIterate_6.append("Parameters:");
                    log4jParamters_tFlowToIterate_6.append("DEFAULT_MAP" + " = " + "true");
                log4jParamters_tFlowToIterate_6.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tFlowToIterate_6 - "  + (log4jParamters_tFlowToIterate_6) );
    		}
    	}
    	
        new BytesLimit65535_tFlowToIterate_6().limitLog4jByte();

int nb_line_tFlowToIterate_6 = 0;
int counter_tFlowToIterate_6 = 0;

 



/**
 * [tFlowToIterate_6 begin ] stop
 */



	
	/**
	 * [tSystem_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tSystem_1", false);
		start_Hash.put("tSystem_1", System.currentTimeMillis());
		
	
	currentComponent="tSystem_1";

	
		int tos_count_tSystem_1 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tSystem_1 - "  + ("Start to work.") );
    	class BytesLimit65535_tSystem_1{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tSystem_1 = new StringBuilder();
            log4jParamters_tSystem_1.append("Parameters:");
                    log4jParamters_tSystem_1.append("ROOTDIR" + " = " + "false");
                log4jParamters_tSystem_1.append(" | ");
                    log4jParamters_tSystem_1.append("USE_SINGLE_COMMAND" + " = " + "true");
                log4jParamters_tSystem_1.append(" | ");
                    log4jParamters_tSystem_1.append("COMMAND" + " = " + "new String[]{\"/bin/bash\",\"-c\",\" gpfdist \"+context.FDIST_PARAM+\" -d \"+context.ETL_STORAGE_PATH + \"/\" + context.GP_SOURCE_NAME  + \"/data/\" + context.SOURCE_DATABASE + \"/\" + \" &>\"+context.ETL_STORAGE_PATH + \"/\" + context.GP_SOURCE_NAME  + \"/data/\" + context.SOURCE_DATABASE + \"/log_\"+((String)globalMap.get(\"stringtimestamp\"))+\"  & echo $!\"}");
                log4jParamters_tSystem_1.append(" | ");
                    log4jParamters_tSystem_1.append("USE_ARRAY_COMMAND" + " = " + "false");
                log4jParamters_tSystem_1.append(" | ");
                    log4jParamters_tSystem_1.append("OUTPUT" + " = " + "NORMAL_OUTPUT");
                log4jParamters_tSystem_1.append(" | ");
                    log4jParamters_tSystem_1.append("ERROROUTPUT" + " = " + "OUTPUT_TO_CONSOLE");
                log4jParamters_tSystem_1.append(" | ");
                    log4jParamters_tSystem_1.append("PARAMS" + " = " + "[]");
                log4jParamters_tSystem_1.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tSystem_1 - "  + (log4jParamters_tSystem_1) );
    		}
    	}
    	
        new BytesLimit65535_tSystem_1().limitLog4jByte();

final java.util.Vector<String> output_tSystem_1 = new java.util.Vector<String>();
Runtime runtime_tSystem_1 = Runtime.getRuntime();

String[] env_tSystem_1= null;
java.util.Map<String,String> envMap_tSystem_1= System.getenv();
java.util.Map<String,String> envMapClone_tSystem_1= new java.util.HashMap();
envMapClone_tSystem_1.putAll(envMap_tSystem_1);

	log.info("tSystem_1 - Setting the parameters.");
final Process ps_tSystem_1 = runtime_tSystem_1.exec( new String[]{"/bin/bash","-c"," gpfdist "+context.FDIST_PARAM+" -d "+context.ETL_STORAGE_PATH + "/" + context.GP_SOURCE_NAME  + "/data/" + context.SOURCE_DATABASE + "/" + " &>"+context.ETL_STORAGE_PATH + "/" + context.GP_SOURCE_NAME  + "/data/" + context.SOURCE_DATABASE + "/log_"+((String)globalMap.get("stringtimestamp"))+"  & echo $!"} ,env_tSystem_1);

globalMap.remove("tSystem_1_OUTPUT");
globalMap.remove("tSystem_1_ERROROUTPUT");

Thread normal_tSystem_1 = new Thread() {
	public void run() {
		try {
			java.io.BufferedReader reader = new java.io.BufferedReader(new java.io.InputStreamReader(ps_tSystem_1.getInputStream()));
			String line = "";
			try {
				while((line = reader.readLine()) != null) {
					
						log.debug("tSystem_1 - Sending the standard output to a column of the schema.");
					
					output_tSystem_1.add(line);
				}
			} finally {
				reader.close();
			}
		} catch(java.io.IOException ioe) {
			
				log.error("tSystem_1 - "  + ioe.getMessage());
			
			ioe.printStackTrace();
		}
	}
};
	log.info("tSystem_1 - Executing the command.");
	log.info("tSystem_1 - Command to execute: '" +  new String[]{"/bin/bash","-c"," gpfdist "+context.FDIST_PARAM+" -d "+context.ETL_STORAGE_PATH + "/" + context.GP_SOURCE_NAME  + "/data/" + context.SOURCE_DATABASE + "/" + " &>"+context.ETL_STORAGE_PATH + "/" + context.GP_SOURCE_NAME  + "/data/" + context.SOURCE_DATABASE + "/log_"+((String)globalMap.get("stringtimestamp"))+"  & echo $!"}  + "'.");
normal_tSystem_1.start();
	log.info("tSystem_1 - The command has been executed successfully.");

Thread error_tSystem_1 = new Thread() {
	public void run() {
		try {
			java.io.BufferedReader reader = new java.io.BufferedReader(new java.io.InputStreamReader(ps_tSystem_1.getErrorStream()));
			String line = "";
			try {
				while((line = reader.readLine()) != null) {
					
						log.debug("tSystem_1 - Sending the error output to the console.");
					
					System.err.println(line);
				}
			} finally {
				reader.close();
			}
		} catch(java.io.IOException ioe) {
			
				log.error("tSystem_1 - "  + ioe.getMessage());
			
			ioe.printStackTrace();
		}
	}
};
error_tSystem_1.start();
if(ps_tSystem_1.getOutputStream()!=null){
    ps_tSystem_1.getOutputStream().close();
}
ps_tSystem_1.waitFor();
normal_tSystem_1.join(10000);
error_tSystem_1.join(10000);

				for(String tmp_tSystem_1:output_tSystem_1){
							row12.outputline = tmp_tSystem_1;				

 



/**
 * [tSystem_1 begin ] stop
 */
	
	/**
	 * [tSystem_1 main ] start
	 */

	

	
	
	currentComponent="tSystem_1";

	


 


	tos_count_tSystem_1++;

/**
 * [tSystem_1 main ] stop
 */

	
	/**
	 * [tFlowToIterate_6 main ] start
	 */

	

	
	
	currentComponent="tFlowToIterate_6";

	

			//row12
			//row12


			
				if(execStat){
					runStat.updateStatOnConnection("row12"+iterateId,1, 1);
				} 
			

		
    			if(log.isTraceEnabled()){
    				log.trace("row12 - " + (row12==null? "": row12.toLogString()));
    			}
    		


    	
                if(log.isTraceEnabled())
            log.trace("tFlowToIterate_6 - "  + ("Set global var, key=row12.outputline, value=")  + (row12.outputline)  + (".") );            
            globalMap.put("row12.outputline", row12.outputline);
    	
 
	   nb_line_tFlowToIterate_6++;  
       counter_tFlowToIterate_6++;
                if(log.isDebugEnabled())
            log.debug("tFlowToIterate_6 - "  + ("Current iteration is: ")  + (counter_tFlowToIterate_6)  + (".") );
       globalMap.put("tFlowToIterate_6_CURRENT_ITERATION", counter_tFlowToIterate_6);
 


	tos_count_tFlowToIterate_6++;

/**
 * [tFlowToIterate_6 main ] stop
 */
	NB_ITERATE_tJava_18++;
	
	
				if(execStat){
					runStat.updateStatOnConnection("iterate7", 1, "exec" + NB_ITERATE_tJava_18);
					//Thread.sleep(1000);
				}				
			

	
	/**
	 * [tJava_18 begin ] start
	 */

	

	
		
		ok_Hash.put("tJava_18", false);
		start_Hash.put("tJava_18", System.currentTimeMillis());
		
	
	currentComponent="tJava_18";

	
		int tos_count_tJava_18 = 0;
		
    	class BytesLimit65535_tJava_18{
    		public void limitLog4jByte() throws Exception{
    			
    		}
    	}
    	
        new BytesLimit65535_tJava_18().limitLog4jByte();


System.out.println(new String[]{"/bin/bash","-c"," gpfdist "+context.FDIST_PARAM+" -d "+context.ETL_STORAGE_PATH + "/" + context.GP_SOURCE_NAME  + "/data/" + context.SOURCE_DATABASE + "/" + " &>"+context.ETL_STORAGE_PATH + "/" + context.GP_SOURCE_NAME  + "/data/" + context.SOURCE_DATABASE + "/log_"+((String)globalMap.get("stringtimestamp"))+"  & echo $!"});
System.out.println(((String)globalMap.get("row12.outputline")));
 



/**
 * [tJava_18 begin ] stop
 */
	
	/**
	 * [tJava_18 main ] start
	 */

	

	
	
	currentComponent="tJava_18";

	

 


	tos_count_tJava_18++;

/**
 * [tJava_18 main ] stop
 */
	
	/**
	 * [tJava_18 end ] start
	 */

	

	
	
	currentComponent="tJava_18";

	

 

ok_Hash.put("tJava_18", true);
end_Hash.put("tJava_18", System.currentTimeMillis());




/**
 * [tJava_18 end ] stop
 */
						if(execStat){
							runStat.updateStatOnConnection("iterate7", 2, "exec" + NB_ITERATE_tJava_18);
						}				
					







	
	/**
	 * [tSystem_1 end ] start
	 */

	

	
	
	currentComponent="tSystem_1";

	

}			
globalMap.put("tSystem_1_EXIT_VALUE", ps_tSystem_1.exitValue());

 
                if(log.isDebugEnabled())
            log.debug("tSystem_1 - "  + ("Done.") );

ok_Hash.put("tSystem_1", true);
end_Hash.put("tSystem_1", System.currentTimeMillis());




/**
 * [tSystem_1 end ] stop
 */

	
	/**
	 * [tFlowToIterate_6 end ] start
	 */

	

	
	
	currentComponent="tFlowToIterate_6";

	

globalMap.put("tFlowToIterate_6_NB_LINE",nb_line_tFlowToIterate_6);
			if(execStat){
				if(resourceMap.get("inIterateVComp") == null || !((Boolean)resourceMap.get("inIterateVComp"))){
			 		runStat.updateStatOnConnection("row12"+iterateId,2, 0); 
			 	}
			}
		
 
                if(log.isDebugEnabled())
            log.debug("tFlowToIterate_6 - "  + ("Done.") );

ok_Hash.put("tFlowToIterate_6", true);
end_Hash.put("tFlowToIterate_6", System.currentTimeMillis());




/**
 * [tFlowToIterate_6 end ] stop
 */



				}//end the resume

				
				    			if(resumeEntryMethodName == null || globalResumeTicket){
				    				resumeUtil.addLog("CHECKPOINT", "CONNECTION:SUBJOB_OK:tSystem_1:OnSubjobOk", "", Thread.currentThread().getId() + "", "", "", "", "", "");
								}	    				    			
					    	
								if(execStat){    	
									runStat.updateStatOnConnection("OnSubjobOk63", 0, "ok");
								} 
							
							tSleep_1Process(globalMap); 
						



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage());
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tSystem_1 finally ] start
	 */

	

	
	
	currentComponent="tSystem_1";

	

 



/**
 * [tSystem_1 finally ] stop
 */

	
	/**
	 * [tFlowToIterate_6 finally ] start
	 */

	

	
	
	currentComponent="tFlowToIterate_6";

	

 



/**
 * [tFlowToIterate_6 finally ] stop
 */

	
	/**
	 * [tJava_18 finally ] start
	 */

	

	
	
	currentComponent="tJava_18";

	

 



/**
 * [tJava_18 finally ] stop
 */






				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tSystem_1_SUBPROCESS_STATE", 1);
	}
	

public void tSleep_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tSleep_1_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tSleep_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tSleep_1", false);
		start_Hash.put("tSleep_1", System.currentTimeMillis());
		
	
	currentComponent="tSleep_1";

	
		int tos_count_tSleep_1 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tSleep_1 - "  + ("Start to work.") );
    	class BytesLimit65535_tSleep_1{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tSleep_1 = new StringBuilder();
            log4jParamters_tSleep_1.append("Parameters:");
                    log4jParamters_tSleep_1.append("PAUSE" + " = " + "4");
                log4jParamters_tSleep_1.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tSleep_1 - "  + (log4jParamters_tSleep_1) );
    		}
    	}
    	
        new BytesLimit65535_tSleep_1().limitLog4jByte();

 



/**
 * [tSleep_1 begin ] stop
 */
	
	/**
	 * [tSleep_1 main ] start
	 */

	

	
	
	currentComponent="tSleep_1";

	

    Thread.sleep((4)*1000);

 


	tos_count_tSleep_1++;

/**
 * [tSleep_1 main ] stop
 */
	
	/**
	 * [tSleep_1 end ] start
	 */

	

	
	
	currentComponent="tSleep_1";

	

 
                if(log.isDebugEnabled())
            log.debug("tSleep_1 - "  + ("Done.") );

ok_Hash.put("tSleep_1", true);
end_Hash.put("tSleep_1", System.currentTimeMillis());




/**
 * [tSleep_1 end ] stop
 */
				}//end the resume

				
				    			if(resumeEntryMethodName == null || globalResumeTicket){
				    				resumeUtil.addLog("CHECKPOINT", "CONNECTION:SUBJOB_OK:tSleep_1:OnSubjobOk", "", Thread.currentThread().getId() + "", "", "", "", "", "");
								}	    				    			
					    	
								if(execStat){    	
									runStat.updateStatOnConnection("OnSubjobOk64", 0, "ok");
								} 
							
							tFileInputFullRow_2Process(globalMap); 
						



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage());
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tSleep_1 finally ] start
	 */

	

	
	
	currentComponent="tSleep_1";

	

 



/**
 * [tSleep_1 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tSleep_1_SUBPROCESS_STATE", 1);
	}
	


public static class row13Struct implements routines.system.IPersistableRow<row13Struct> {
    final static byte[] commonByteArrayLock_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Prod2Dev_with_GP_FDIST_child = new byte[0];
    static byte[] commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Prod2Dev_with_GP_FDIST_child = new byte[0];

	
			    public String line;

				public String getLine () {
					return this.line;
				}
				



	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Prod2Dev_with_GP_FDIST_child.length) {
				if(length < 1024 && commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Prod2Dev_with_GP_FDIST_child.length == 0) {
   					commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Prod2Dev_with_GP_FDIST_child = new byte[1024];
				} else {
   					commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Prod2Dev_with_GP_FDIST_child = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Prod2Dev_with_GP_FDIST_child, 0, length);
			strReturn = new String(commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Prod2Dev_with_GP_FDIST_child, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Prod2Dev_with_GP_FDIST_child) {

        	try {

        		int length = 0;
		
					this.line = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// String
				
						writeString(this.line,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("line="+line);
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				if(line == null){
        					sb.append("<null>");
        				}else{
            				sb.append(line);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(row13Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}
public void tFileInputFullRow_2Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tFileInputFullRow_2_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;



		row13Struct row13 = new row13Struct();




	
	/**
	 * [tJavaRow_3 begin ] start
	 */

	

	
		
		ok_Hash.put("tJavaRow_3", false);
		start_Hash.put("tJavaRow_3", System.currentTimeMillis());
		
	
	currentComponent="tJavaRow_3";

	
			if (execStat) {
				if(resourceMap.get("inIterateVComp") == null){
					
						runStat.updateStatOnConnection("row13" + iterateId, 0, 0);
					
				}
			} 

		
		int tos_count_tJavaRow_3 = 0;
		
    	class BytesLimit65535_tJavaRow_3{
    		public void limitLog4jByte() throws Exception{
    			
    		}
    	}
    	
        new BytesLimit65535_tJavaRow_3().limitLog4jByte();

int nb_line_tJavaRow_3 = 0;

 



/**
 * [tJavaRow_3 begin ] stop
 */



	
	/**
	 * [tFileInputFullRow_2 begin ] start
	 */

	

	
		
		ok_Hash.put("tFileInputFullRow_2", false);
		start_Hash.put("tFileInputFullRow_2", System.currentTimeMillis());
		
	
	currentComponent="tFileInputFullRow_2";

	
		int tos_count_tFileInputFullRow_2 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tFileInputFullRow_2 - "  + ("Start to work.") );
    	class BytesLimit65535_tFileInputFullRow_2{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tFileInputFullRow_2 = new StringBuilder();
            log4jParamters_tFileInputFullRow_2.append("Parameters:");
                    log4jParamters_tFileInputFullRow_2.append("FILENAME" + " = " + "context.ETL_STORAGE_PATH + \"/\" + context.GP_SOURCE_NAME + '/' + \"/data/\" + context.SOURCE_DATABASE + \"/log_\"+((String)globalMap.get(\"stringtimestamp\"))");
                log4jParamters_tFileInputFullRow_2.append(" | ");
                    log4jParamters_tFileInputFullRow_2.append("ROWSEPARATOR" + " = " + "\"\\n\"");
                log4jParamters_tFileInputFullRow_2.append(" | ");
                    log4jParamters_tFileInputFullRow_2.append("HEADER" + " = " + "");
                log4jParamters_tFileInputFullRow_2.append(" | ");
                    log4jParamters_tFileInputFullRow_2.append("FOOTER" + " = " + "");
                log4jParamters_tFileInputFullRow_2.append(" | ");
                    log4jParamters_tFileInputFullRow_2.append("LIMIT" + " = " + "");
                log4jParamters_tFileInputFullRow_2.append(" | ");
                    log4jParamters_tFileInputFullRow_2.append("REMOVE_EMPTY_ROW" + " = " + "true");
                log4jParamters_tFileInputFullRow_2.append(" | ");
                    log4jParamters_tFileInputFullRow_2.append("ENCODING" + " = " + "\"UTF-8\"");
                log4jParamters_tFileInputFullRow_2.append(" | ");
                    log4jParamters_tFileInputFullRow_2.append("RANDOM" + " = " + "false");
                log4jParamters_tFileInputFullRow_2.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tFileInputFullRow_2 - "  + (log4jParamters_tFileInputFullRow_2) );
    		}
    	}
    	
        new BytesLimit65535_tFileInputFullRow_2().limitLog4jByte();

				final StringBuffer log4jSb_tFileInputFullRow_2 = new StringBuffer();
			
	org.talend.fileprocess.FileInputDelimited fid_tFileInputFullRow_2 = null;

					log.debug("tFileInputFullRow_2 - Retrieving records from the datasource.");
			

	try{//}
		fid_tFileInputFullRow_2 =new org.talend.fileprocess.FileInputDelimited(context.ETL_STORAGE_PATH + "/" + context.GP_SOURCE_NAME + '/' + "/data/" + context.SOURCE_DATABASE + "/log_"+((String)globalMap.get("stringtimestamp")),"UTF-8","","\n",true,0,0,-1,-1,false);
		while (fid_tFileInputFullRow_2.nextRecord()) {//}
			row13 = null;						
	boolean whetherReject_tFileInputFullRow_2 = false;
	row13 = new row13Struct();
		row13.line = fid_tFileInputFullRow_2.get(0);

 



/**
 * [tFileInputFullRow_2 begin ] stop
 */
	
	/**
	 * [tFileInputFullRow_2 main ] start
	 */

	

	
	
	currentComponent="tFileInputFullRow_2";

	

 


	tos_count_tFileInputFullRow_2++;

/**
 * [tFileInputFullRow_2 main ] stop
 */

	
	/**
	 * [tJavaRow_3 main ] start
	 */

	

	
	
	currentComponent="tJavaRow_3";

	

			//row13
			//row13


			
				if(execStat){
					runStat.updateStatOnConnection("row13"+iterateId,1, 1);
				} 
			

		
    			if(log.isTraceEnabled()){
    				log.trace("row13 - " + (row13==null? "": row13.toLogString()));
    			}
    		

    System.out.println(row13.line);
//Serving HTTP on port 8224, directory /data/home/corp_sourcing
String ports=((String)row13.line).replace("Serving HTTP on port ","").replaceAll(", directory(.*)","");

System.out.println(ports);
if(!(((String)globalMap.get("port")).length()<6 && ((String)globalMap.get("port")).length()>3))
globalMap.put("port",ports);
    nb_line_tJavaRow_3++;   

 


	tos_count_tJavaRow_3++;

/**
 * [tJavaRow_3 main ] stop
 */



	
	/**
	 * [tFileInputFullRow_2 end ] start
	 */

	

	
	
	currentComponent="tFileInputFullRow_2";

	

	


            }
           	}finally{
           		if(fid_tFileInputFullRow_2!=null){
            		fid_tFileInputFullRow_2.close();
            	}
            }
            globalMap.put("tFileInputFullRow_2_NB_LINE", fid_tFileInputFullRow_2.getRowNumber());
				log.debug("tFileInputFullRow_2 - Retrieved records count: "+ globalMap.get("tFileInputFullRow_2_NB_LINE") + " .");
			
 
                if(log.isDebugEnabled())
            log.debug("tFileInputFullRow_2 - "  + ("Done.") );

ok_Hash.put("tFileInputFullRow_2", true);
end_Hash.put("tFileInputFullRow_2", System.currentTimeMillis());




/**
 * [tFileInputFullRow_2 end ] stop
 */

	
	/**
	 * [tJavaRow_3 end ] start
	 */

	

	
	
	currentComponent="tJavaRow_3";

	

globalMap.put("tJavaRow_3_NB_LINE",nb_line_tJavaRow_3);
			if(execStat){
				if(resourceMap.get("inIterateVComp") == null || !((Boolean)resourceMap.get("inIterateVComp"))){
			 		runStat.updateStatOnConnection("row13"+iterateId,2, 0); 
			 	}
			}
		
 

ok_Hash.put("tJavaRow_3", true);
end_Hash.put("tJavaRow_3", System.currentTimeMillis());




/**
 * [tJavaRow_3 end ] stop
 */



				}//end the resume

				
				    			if(resumeEntryMethodName == null || globalResumeTicket){
				    				resumeUtil.addLog("CHECKPOINT", "CONNECTION:SUBJOB_OK:tFileInputFullRow_2:OnSubjobOk", "", Thread.currentThread().getId() + "", "", "", "", "", "");
								}	    				    			
					    	
								if(execStat){    	
									runStat.updateStatOnConnection("OnSubjobOk76", 0, "ok");
								} 
							
							tGreenplumConnection_6Process(globalMap); 
						



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage());
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tFileInputFullRow_2 finally ] start
	 */

	

	
	
	currentComponent="tFileInputFullRow_2";

	

 



/**
 * [tFileInputFullRow_2 finally ] stop
 */

	
	/**
	 * [tJavaRow_3 finally ] start
	 */

	

	
	
	currentComponent="tJavaRow_3";

	

 



/**
 * [tJavaRow_3 finally ] stop
 */



				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tFileInputFullRow_2_SUBPROCESS_STATE", 1);
	}
	

public void tGreenplumConnection_6Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tGreenplumConnection_6_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tGreenplumConnection_6 begin ] start
	 */

	

	
		
		ok_Hash.put("tGreenplumConnection_6", false);
		start_Hash.put("tGreenplumConnection_6", System.currentTimeMillis());
		
	
	currentComponent="tGreenplumConnection_6";

	
		int tos_count_tGreenplumConnection_6 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tGreenplumConnection_6 - "  + ("Start to work.") );
    	class BytesLimit65535_tGreenplumConnection_6{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tGreenplumConnection_6 = new StringBuilder();
            log4jParamters_tGreenplumConnection_6.append("Parameters:");
                    log4jParamters_tGreenplumConnection_6.append("HOST" + " = " + "context.getProperty(\"SOURCE_HOST\")");
                log4jParamters_tGreenplumConnection_6.append(" | ");
                    log4jParamters_tGreenplumConnection_6.append("PORT" + " = " + "context.getProperty(\"SOURCE_PORT\")");
                log4jParamters_tGreenplumConnection_6.append(" | ");
                    log4jParamters_tGreenplumConnection_6.append("DBNAME" + " = " + "context.getProperty(\"SOURCE_DATABASE\")");
                log4jParamters_tGreenplumConnection_6.append(" | ");
                    log4jParamters_tGreenplumConnection_6.append("SCHEMA_DB" + " = " + "\"\"");
                log4jParamters_tGreenplumConnection_6.append(" | ");
                    log4jParamters_tGreenplumConnection_6.append("USER" + " = " + "context.getProperty(\"SOURCE_USER\")");
                log4jParamters_tGreenplumConnection_6.append(" | ");
                    log4jParamters_tGreenplumConnection_6.append("PASS" + " = " + String.valueOf(routines.system.PasswordEncryptUtil.encryptPassword(context.SOURCE_PASSWORD)).substring(0, 4) + "...");     
                log4jParamters_tGreenplumConnection_6.append(" | ");
                    log4jParamters_tGreenplumConnection_6.append("USE_SHARED_CONNECTION" + " = " + "false");
                log4jParamters_tGreenplumConnection_6.append(" | ");
                    log4jParamters_tGreenplumConnection_6.append("USE_SSL" + " = " + "true");
                log4jParamters_tGreenplumConnection_6.append(" | ");
                    log4jParamters_tGreenplumConnection_6.append("AUTO_COMMIT" + " = " + "true");
                log4jParamters_tGreenplumConnection_6.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tGreenplumConnection_6 - "  + (log4jParamters_tGreenplumConnection_6) );
    		}
    	}
    	
        new BytesLimit65535_tGreenplumConnection_6().limitLog4jByte();
	

	
				String url_tGreenplumConnection_6 = "jdbc:postgresql://"+context.getProperty("SOURCE_HOST")+":"+context.getProperty("SOURCE_PORT")+"/"+context.getProperty("SOURCE_DATABASE")+"?ssl=true&sslfactory=org.postgresql.ssl.NonValidatingFactory";

	String dbUser_tGreenplumConnection_6 = context.getProperty("SOURCE_USER");
	
	
		
	final String decryptedPassword_tGreenplumConnection_6 = context.SOURCE_PASSWORD; 
		String dbPwd_tGreenplumConnection_6 = decryptedPassword_tGreenplumConnection_6;
	

	java.sql.Connection conn_tGreenplumConnection_6 = null;
	
		
			String driverClass_tGreenplumConnection_6 = "org.postgresql.Driver";
			java.lang.Class.forName(driverClass_tGreenplumConnection_6);
		
	    		log.debug("tGreenplumConnection_6 - Driver ClassName: "+driverClass_tGreenplumConnection_6+".");
			
	    		log.debug("tGreenplumConnection_6 - Connection attempt to '" + url_tGreenplumConnection_6 + "' with the username '" + dbUser_tGreenplumConnection_6 + "'.");
			
		conn_tGreenplumConnection_6 = java.sql.DriverManager.getConnection(url_tGreenplumConnection_6,dbUser_tGreenplumConnection_6,dbPwd_tGreenplumConnection_6);
	    		log.debug("tGreenplumConnection_6 - Connection to '" + url_tGreenplumConnection_6 + "' has succeeded.");
			

		globalMap.put("conn_tGreenplumConnection_6", conn_tGreenplumConnection_6);
	if (null != conn_tGreenplumConnection_6) {
		
			log.debug("tGreenplumConnection_6 - Connection is set auto commit to 'true'.");
			conn_tGreenplumConnection_6.setAutoCommit(true);
	}

	globalMap.put("schema_" + "tGreenplumConnection_6","");

	globalMap.put("conn_" + "tGreenplumConnection_6",conn_tGreenplumConnection_6);
 



/**
 * [tGreenplumConnection_6 begin ] stop
 */
	
	/**
	 * [tGreenplumConnection_6 main ] start
	 */

	

	
	
	currentComponent="tGreenplumConnection_6";

	

 


	tos_count_tGreenplumConnection_6++;

/**
 * [tGreenplumConnection_6 main ] stop
 */
	
	/**
	 * [tGreenplumConnection_6 end ] start
	 */

	

	
	
	currentComponent="tGreenplumConnection_6";

	

 
                if(log.isDebugEnabled())
            log.debug("tGreenplumConnection_6 - "  + ("Done.") );

ok_Hash.put("tGreenplumConnection_6", true);
end_Hash.put("tGreenplumConnection_6", System.currentTimeMillis());




/**
 * [tGreenplumConnection_6 end ] stop
 */
				}//end the resume

				
				    			if(resumeEntryMethodName == null || globalResumeTicket){
				    				resumeUtil.addLog("CHECKPOINT", "CONNECTION:SUBJOB_OK:tGreenplumConnection_6:OnSubjobOk", "", Thread.currentThread().getId() + "", "", "", "", "", "");
								}	    				    			
					    	
								if(execStat){    	
									runStat.updateStatOnConnection("OnSubjobOk65", 0, "ok");
								} 
							
							tGreenplumInput_10Process(globalMap); 
						



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage());
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tGreenplumConnection_6 finally ] start
	 */

	

	
	
	currentComponent="tGreenplumConnection_6";

	

 



/**
 * [tGreenplumConnection_6 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tGreenplumConnection_6_SUBPROCESS_STATE", 1);
	}
	


public static class row20Struct implements routines.system.IPersistableRow<row20Struct> {
    final static byte[] commonByteArrayLock_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Prod2Dev_with_GP_FDIST_child = new byte[0];
    static byte[] commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Prod2Dev_with_GP_FDIST_child = new byte[0];

	
			    public String colList;

				public String getColList () {
					return this.colList;
				}
				



	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Prod2Dev_with_GP_FDIST_child.length) {
				if(length < 1024 && commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Prod2Dev_with_GP_FDIST_child.length == 0) {
   					commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Prod2Dev_with_GP_FDIST_child = new byte[1024];
				} else {
   					commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Prod2Dev_with_GP_FDIST_child = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Prod2Dev_with_GP_FDIST_child, 0, length);
			strReturn = new String(commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Prod2Dev_with_GP_FDIST_child, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Prod2Dev_with_GP_FDIST_child) {

        	try {

        		int length = 0;
		
					this.colList = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// String
				
						writeString(this.colList,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("colList="+colList);
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				if(colList == null){
        					sb.append("<null>");
        				}else{
            				sb.append(colList);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(row20Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}
public void tGreenplumInput_10Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tGreenplumInput_10_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;



		row20Struct row20 = new row20Struct();




	
	/**
	 * [tJavaRow_10 begin ] start
	 */

	

	
		
		ok_Hash.put("tJavaRow_10", false);
		start_Hash.put("tJavaRow_10", System.currentTimeMillis());
		
	
	currentComponent="tJavaRow_10";

	
			if (execStat) {
				if(resourceMap.get("inIterateVComp") == null){
					
						runStat.updateStatOnConnection("row20" + iterateId, 0, 0);
					
				}
			} 

		
		int tos_count_tJavaRow_10 = 0;
		
    	class BytesLimit65535_tJavaRow_10{
    		public void limitLog4jByte() throws Exception{
    			
    		}
    	}
    	
        new BytesLimit65535_tJavaRow_10().limitLog4jByte();

int nb_line_tJavaRow_10 = 0;

 



/**
 * [tJavaRow_10 begin ] stop
 */



	
	/**
	 * [tGreenplumInput_10 begin ] start
	 */

	

	
		
		ok_Hash.put("tGreenplumInput_10", false);
		start_Hash.put("tGreenplumInput_10", System.currentTimeMillis());
		
	
	currentComponent="tGreenplumInput_10";

	
		int tos_count_tGreenplumInput_10 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tGreenplumInput_10 - "  + ("Start to work.") );
    	class BytesLimit65535_tGreenplumInput_10{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tGreenplumInput_10 = new StringBuilder();
            log4jParamters_tGreenplumInput_10.append("Parameters:");
                    log4jParamters_tGreenplumInput_10.append("USE_EXISTING_CONNECTION" + " = " + "true");
                log4jParamters_tGreenplumInput_10.append(" | ");
                    log4jParamters_tGreenplumInput_10.append("CONNECTION" + " = " + "tGreenplumConnection_6");
                log4jParamters_tGreenplumInput_10.append(" | ");
                    log4jParamters_tGreenplumInput_10.append("TABLE" + " = " + "\"\"");
                log4jParamters_tGreenplumInput_10.append(" | ");
                    log4jParamters_tGreenplumInput_10.append("QUERYSTORE" + " = " + "\"\"");
                log4jParamters_tGreenplumInput_10.append(" | ");
                    log4jParamters_tGreenplumInput_10.append("QUERY" + " = " + "\" select string_agg( \" +  \"	'\\\"'||column_name||'\\\" '||coalesce(data_type,'')||' '||\" +  \"	case when character_maximum_length is not null then '('||character_maximum_length||')' \" +  \"		 when numeric_scale not in (null, 0) then '('||numeric_precision||','||numeric_scale||')'\" +  \"	else '' end\" +   \" , ', ' ORDER BY ordinal_position) as ColumnList\" +  \" from information_schema.columns\" +  \" where upper(table_schema) = '\" +  ((String)globalMap.get(\"row7.target_schema\")).toUpperCase()  + \"' and upper(table_name) = '\" +   ((String)globalMap.get(\"row7.target_table_name\")).toUpperCase()  + \"'\"");
                log4jParamters_tGreenplumInput_10.append(" | ");
                    log4jParamters_tGreenplumInput_10.append("USE_CURSOR" + " = " + "false");
                log4jParamters_tGreenplumInput_10.append(" | ");
                    log4jParamters_tGreenplumInput_10.append("TRIM_ALL_COLUMN" + " = " + "false");
                log4jParamters_tGreenplumInput_10.append(" | ");
                    log4jParamters_tGreenplumInput_10.append("TRIM_COLUMN" + " = " + "[{TRIM="+("false")+", SCHEMA_COLUMN="+("colList")+"}]");
                log4jParamters_tGreenplumInput_10.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tGreenplumInput_10 - "  + (log4jParamters_tGreenplumInput_10) );
    		}
    	}
    	
        new BytesLimit65535_tGreenplumInput_10().limitLog4jByte();
	
    
	
		    int nb_line_tGreenplumInput_10 = 0;
		    java.sql.Connection conn_tGreenplumInput_10 = null;
		        conn_tGreenplumInput_10 = (java.sql.Connection)globalMap.get("conn_tGreenplumConnection_6");
				
				if(conn_tGreenplumInput_10 != null) {
					if(conn_tGreenplumInput_10.getMetaData() != null) {
						
						log.debug("tGreenplumInput_10 - Uses an existing connection with username '" + conn_tGreenplumInput_10.getMetaData().getUserName() + "'. Connection URL: " + conn_tGreenplumInput_10.getMetaData().getURL() + ".");
						
					}
				}
			
		    
			java.sql.Statement stmt_tGreenplumInput_10 = conn_tGreenplumInput_10.createStatement();

		    String dbquery_tGreenplumInput_10 = " select string_agg( " +
"	'\"'||column_name||'\" '||coalesce(data_type,'')||' '||" +
"	case when character_maximum_length is not null then '('||character_maximum_length||')' " +
"		 when numeric_scale not in (null, 0) then '('||numeric_precision||','||numeric_scale||')'" +
"	else '' end" + 
" , ', ' ORDER BY ordinal_position) as ColumnList" +
" from information_schema.columns" +
" where upper(table_schema) = '" +
((String)globalMap.get("row7.target_schema")).toUpperCase()
+ "' and upper(table_name) = '" + 
((String)globalMap.get("row7.target_table_name")).toUpperCase()
+ "'";
			
                log.debug("tGreenplumInput_10 - Executing the query: '"+dbquery_tGreenplumInput_10+"'.");
			

                       globalMap.put("tGreenplumInput_10_QUERY",dbquery_tGreenplumInput_10);

		    java.sql.ResultSet rs_tGreenplumInput_10 = null;
		try{
		    rs_tGreenplumInput_10 = stmt_tGreenplumInput_10.executeQuery(dbquery_tGreenplumInput_10);
		    java.sql.ResultSetMetaData rsmd_tGreenplumInput_10 = rs_tGreenplumInput_10.getMetaData();
		    int colQtyInRs_tGreenplumInput_10 = rsmd_tGreenplumInput_10.getColumnCount();

		    String tmpContent_tGreenplumInput_10 = null;
		    
		    
		    	log.debug("tGreenplumInput_10 - Retrieving records from the database.");
		    
		    while (rs_tGreenplumInput_10.next()) {
		        nb_line_tGreenplumInput_10++;
		        
							if(colQtyInRs_tGreenplumInput_10 < 1) {
								row20.colList = null;
							} else {
	                         		
        	row20.colList = routines.system.JDBCUtil.getString(rs_tGreenplumInput_10, 1, false);
		                    }
					
						log.debug("tGreenplumInput_10 - Retrieving the record " + nb_line_tGreenplumInput_10 + ".");
					


 



/**
 * [tGreenplumInput_10 begin ] stop
 */
	
	/**
	 * [tGreenplumInput_10 main ] start
	 */

	

	
	
	currentComponent="tGreenplumInput_10";

	

 


	tos_count_tGreenplumInput_10++;

/**
 * [tGreenplumInput_10 main ] stop
 */

	
	/**
	 * [tJavaRow_10 main ] start
	 */

	

	
	
	currentComponent="tJavaRow_10";

	

			//row20
			//row20


			
				if(execStat){
					runStat.updateStatOnConnection("row20"+iterateId,1, 1);
				} 
			

		
    			if(log.isTraceEnabled()){
    				log.trace("row20 - " + (row20==null? "": row20.toLogString()));
    			}
    		

    
globalMap.put("columns_list", (String)row20.colList);
    nb_line_tJavaRow_10++;   

 


	tos_count_tJavaRow_10++;

/**
 * [tJavaRow_10 main ] stop
 */



	
	/**
	 * [tGreenplumInput_10 end ] start
	 */

	

	
	
	currentComponent="tGreenplumInput_10";

	

	}
}finally{
	stmt_tGreenplumInput_10.close();

}
globalMap.put("tGreenplumInput_10_NB_LINE",nb_line_tGreenplumInput_10);
	    		log.debug("tGreenplumInput_10 - Retrieved records count: "+nb_line_tGreenplumInput_10 + " .");
			

 
                if(log.isDebugEnabled())
            log.debug("tGreenplumInput_10 - "  + ("Done.") );

ok_Hash.put("tGreenplumInput_10", true);
end_Hash.put("tGreenplumInput_10", System.currentTimeMillis());




/**
 * [tGreenplumInput_10 end ] stop
 */

	
	/**
	 * [tJavaRow_10 end ] start
	 */

	

	
	
	currentComponent="tJavaRow_10";

	

globalMap.put("tJavaRow_10_NB_LINE",nb_line_tJavaRow_10);
			if(execStat){
				if(resourceMap.get("inIterateVComp") == null || !((Boolean)resourceMap.get("inIterateVComp"))){
			 		runStat.updateStatOnConnection("row20"+iterateId,2, 0); 
			 	}
			}
		
 

ok_Hash.put("tJavaRow_10", true);
end_Hash.put("tJavaRow_10", System.currentTimeMillis());

				if(execStat){   
   	 				runStat.updateStatOnConnection("OnComponentOk6", 0, "ok");
				}
				tJava_27Process(globalMap);



/**
 * [tJavaRow_10 end ] stop
 */



				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage());
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tGreenplumInput_10 finally ] start
	 */

	

	
	
	currentComponent="tGreenplumInput_10";

	

 



/**
 * [tGreenplumInput_10 finally ] stop
 */

	
	/**
	 * [tJavaRow_10 finally ] start
	 */

	

	
	
	currentComponent="tJavaRow_10";

	

 



/**
 * [tJavaRow_10 finally ] stop
 */



				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tGreenplumInput_10_SUBPROCESS_STATE", 1);
	}
	

public void tJava_27Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tJava_27_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tJava_27 begin ] start
	 */

	

	
		
		ok_Hash.put("tJava_27", false);
		start_Hash.put("tJava_27", System.currentTimeMillis());
		
	
	currentComponent="tJava_27";

	
		int tos_count_tJava_27 = 0;
		
    	class BytesLimit65535_tJava_27{
    		public void limitLog4jByte() throws Exception{
    			
    		}
    	}
    	
        new BytesLimit65535_tJava_27().limitLog4jByte();


System.out.println("set where clause in case of incremental load");
if  (((String)globalMap.get("row7.update_type")).equals("Incremental")
	  && context.getProperty("FORCE_DROP").equals("N")) 
{	
	
	String where = " where " + ((String)globalMap.get("row7.update_col")) + " > to_timestamp('" + new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(((java.util.Date)globalMap.get("row7.last_prod2dev_date"))).toString() + "', 'YYYY-MM-DD HH24:MI:SS')";

	globalMap.put("where_cond", where);
}
else{ globalMap.put("where_cond", " where 1=1 ");}
	
System.out.println("MMMMMM where clause added MMMMMMM");
System.out.println((String)globalMap.get("row7.update_type"));
System.out.println((String)globalMap.get("where_cond"));

 



/**
 * [tJava_27 begin ] stop
 */
	
	/**
	 * [tJava_27 main ] start
	 */

	

	
	
	currentComponent="tJava_27";

	

 


	tos_count_tJava_27++;

/**
 * [tJava_27 main ] stop
 */
	
	/**
	 * [tJava_27 end ] start
	 */

	

	
	
	currentComponent="tJava_27";

	

 

ok_Hash.put("tJava_27", true);
end_Hash.put("tJava_27", System.currentTimeMillis());

				if(execStat){   
   	 				runStat.updateStatOnConnection("OnComponentOk12", 0, "ok");
				}
				tJava_1Process(globalMap);



/**
 * [tJava_27 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage());
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tJava_27 finally ] start
	 */

	

	
	
	currentComponent="tJava_27";

	

 



/**
 * [tJava_27 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tJava_27_SUBPROCESS_STATE", 1);
	}
	

public void tJava_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tJava_1_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tJava_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tJava_1", false);
		start_Hash.put("tJava_1", System.currentTimeMillis());
		
	
	currentComponent="tJava_1";

	
		int tos_count_tJava_1 = 0;
		
    	class BytesLimit65535_tJava_1{
    		public void limitLog4jByte() throws Exception{
    			
    		}
    	}
    	
        new BytesLimit65535_tJava_1().limitLog4jByte();


System.out.println("CREATE WRITABLE EXTERNAL TABLE increments."+((String)globalMap.get("row7.log_table_name"))+"_ext ( LIKE " +((String)globalMap.get("row7.target_schema_orig"))+"."+((String)globalMap.get("row7.log_table_name"))+ " ) LOCATION gpfdist://"+context.ETL_LOCALHOSTNAME+":"+((String)globalMap.get("port"))+"/"+((String)globalMap.get("row7.log_table_name")).replace("\"","").replace("#","__hash__").replace("$","__dollar__")+".txt"+"' ) FORMAT 'TEXT' (delimiter E'\\013' null '\\\\N' escape '\\\\' ) encoding 'UTF8' DISTRIBUTED "+(((String)globalMap.get("distributed_by")).equals("")?"RANDOMLY":"BY ("+(String)globalMap.get("distributed_by")+")"  )  + "   ; insert into increments."+((String)globalMap.get("row7.log_table_name"))+"_ext select * from "+((String)globalMap.get("row7.target_schema_orig"))+"."+((String)globalMap.get("row7.log_table_name"))+((String)globalMap.get("where_cond"))+"; drop external table increments."+((String)globalMap.get("row7.log_table_name"))+"_ext ; ");
 



/**
 * [tJava_1 begin ] stop
 */
	
	/**
	 * [tJava_1 main ] start
	 */

	

	
	
	currentComponent="tJava_1";

	

 


	tos_count_tJava_1++;

/**
 * [tJava_1 main ] stop
 */
	
	/**
	 * [tJava_1 end ] start
	 */

	

	
	
	currentComponent="tJava_1";

	

 

ok_Hash.put("tJava_1", true);
end_Hash.put("tJava_1", System.currentTimeMillis());

				if(execStat){   
   	 				runStat.updateStatOnConnection("OnComponentOk26", 0, "ok");
				}
				tGreenplumRow_11Process(globalMap);



/**
 * [tJava_1 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage());
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tJava_1 finally ] start
	 */

	

	
	
	currentComponent="tJava_1";

	

 



/**
 * [tJava_1 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tJava_1_SUBPROCESS_STATE", 1);
	}
	

public void tGreenplumRow_11Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tGreenplumRow_11_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tGreenplumRow_11 begin ] start
	 */

	

	
		
		ok_Hash.put("tGreenplumRow_11", false);
		start_Hash.put("tGreenplumRow_11", System.currentTimeMillis());
		
	
	currentComponent="tGreenplumRow_11";

	
		int tos_count_tGreenplumRow_11 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tGreenplumRow_11 - "  + ("Start to work.") );
    	class BytesLimit65535_tGreenplumRow_11{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tGreenplumRow_11 = new StringBuilder();
            log4jParamters_tGreenplumRow_11.append("Parameters:");
                    log4jParamters_tGreenplumRow_11.append("USE_EXISTING_CONNECTION" + " = " + "true");
                log4jParamters_tGreenplumRow_11.append(" | ");
                    log4jParamters_tGreenplumRow_11.append("CONNECTION" + " = " + "tGreenplumConnection_6");
                log4jParamters_tGreenplumRow_11.append(" | ");
                    log4jParamters_tGreenplumRow_11.append("QUERYSTORE" + " = " + "\"\"");
                log4jParamters_tGreenplumRow_11.append(" | ");
                    log4jParamters_tGreenplumRow_11.append("QUERY" + " = " + "\"  drop external table if EXISTS increments.\"+((String)globalMap.get(\"row7.log_table_name\"))+\"_ext ;   CREATE WRITABLE EXTERNAL TABLE increments.\"+((String)globalMap.get(\"row7.log_table_name\"))+\"_ext   ( LIKE \" +((String)globalMap.get(\"row7.target_schema_orig\"))+\".\"+((String)globalMap.get(\"row7.log_table_name\"))+ \" )   LOCATION ('gpfdist://\"+context.ETL_LOCALHOSTNAME+\":\"+((String)globalMap.get(\"port\"))+\"/\"+((String)globalMap.get(\"row7.log_table_name\")).replace(\"\\\"\",\"\").replace(\"#\",\"__hash__\").replace(\"$\",\"__dollar__\")+\".txt\"+  \"'   )   FORMAT 'TEXT' (delimiter E'\\\\013' null '\\\\\\\\N' escape '\\\\\\\\' )   encoding 'UTF8'   DISTRIBUTED \"+( ((String)globalMap.get(\"distributed_by\")).equals(\"\")?\"RANDOMLY\":\"BY (\"+(String)globalMap.get(\"distributed_by\")+\")\"  )  + \"   ;      insert into increments.\"+((String)globalMap.get(\"row7.log_table_name\"))+\"_ext   select * from \"+((String)globalMap.get(\"row7.target_schema_orig\"))+\".\"+((String)globalMap.get(\"row7.log_table_name\")) + ((String)globalMap.get(\"where_cond\"))+\"  ;      drop external table increments.\"+((String)globalMap.get(\"row7.log_table_name\"))+\"_ext ;   \"");
                log4jParamters_tGreenplumRow_11.append(" | ");
                    log4jParamters_tGreenplumRow_11.append("DIE_ON_ERROR" + " = " + "true");
                log4jParamters_tGreenplumRow_11.append(" | ");
                    log4jParamters_tGreenplumRow_11.append("PROPAGATE_RECORD_SET" + " = " + "false");
                log4jParamters_tGreenplumRow_11.append(" | ");
                    log4jParamters_tGreenplumRow_11.append("USE_PREPAREDSTATEMENT" + " = " + "false");
                log4jParamters_tGreenplumRow_11.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tGreenplumRow_11 - "  + (log4jParamters_tGreenplumRow_11) );
    		}
    	}
    	
        new BytesLimit65535_tGreenplumRow_11().limitLog4jByte();

	java.sql.Connection conn_tGreenplumRow_11 = null;
	String query_tGreenplumRow_11 = "";
	boolean whetherReject_tGreenplumRow_11 = false;
				conn_tGreenplumRow_11 = (java.sql.Connection)globalMap.get("conn_tGreenplumConnection_6");
			
				if(conn_tGreenplumRow_11 != null) {
					if(conn_tGreenplumRow_11.getMetaData() != null) {
						
						log.debug("tGreenplumRow_11 - Uses an existing connection with username '" + conn_tGreenplumRow_11.getMetaData().getUserName() + "'. Connection URL: " + conn_tGreenplumRow_11.getMetaData().getURL() + ".");
						
					}
				}
			
		java.sql.Statement stmt_tGreenplumRow_11 = conn_tGreenplumRow_11.createStatement();
	

 



/**
 * [tGreenplumRow_11 begin ] stop
 */
	
	/**
	 * [tGreenplumRow_11 main ] start
	 */

	

	
	
	currentComponent="tGreenplumRow_11";

	

	    		log.debug("tGreenplumRow_11 - Executing the query: '" + "  drop external table if EXISTS increments."+((String)globalMap.get("row7.log_table_name"))+"_ext ;   CREATE WRITABLE EXTERNAL TABLE increments."+((String)globalMap.get("row7.log_table_name"))+"_ext   ( LIKE " +((String)globalMap.get("row7.target_schema_orig"))+"."+((String)globalMap.get("row7.log_table_name"))+ " )   LOCATION ('gpfdist://"+context.ETL_LOCALHOSTNAME+":"+((String)globalMap.get("port"))+"/"+((String)globalMap.get("row7.log_table_name")).replace("\"","").replace("#","__hash__").replace("$","__dollar__")+".txt"+  "'   )   FORMAT 'TEXT' (delimiter E'\\013' null '\\\\N' escape '\\\\' )   encoding 'UTF8'   DISTRIBUTED "+( ((String)globalMap.get("distributed_by")).equals("")?"RANDOMLY":"BY ("+(String)globalMap.get("distributed_by")+")"  )  + "   ;      insert into increments."+((String)globalMap.get("row7.log_table_name"))+"_ext   select * from "+((String)globalMap.get("row7.target_schema_orig"))+"."+((String)globalMap.get("row7.log_table_name")) + ((String)globalMap.get("where_cond"))+"  ;      drop external table increments."+((String)globalMap.get("row7.log_table_name"))+"_ext ;   " + "'.");
			
query_tGreenplumRow_11 = "\ndrop external table if EXISTS increments."+((String)globalMap.get("row7.log_table_name"))+"_ext ; \nCREATE WRITABLE EXTERNAL TABLE increments."+((String)globalMap.get("row7.log_table_name"))+"_ext \n( LIKE " +((String)globalMap.get("row7.target_schema_orig"))+"."+((String)globalMap.get("row7.log_table_name"))+ " ) \nLOCATION ('gpfdist://"+context.ETL_LOCALHOSTNAME+":"+((String)globalMap.get("port"))+"/"+((String)globalMap.get("row7.log_table_name")).replace("\"","").replace("#","__hash__").replace("$","__dollar__")+".txt"+
"' \n) \nFORMAT 'TEXT' (delimiter E'\\013' null '\\\\N' escape '\\\\' ) \nencoding 'UTF8' \nDISTRIBUTED "+( ((String)globalMap.get("distributed_by")).equals("")?"RANDOMLY":"BY ("+(String)globalMap.get("distributed_by")+")"  )  + "   ; \n \ninsert into increments."+((String)globalMap.get("row7.log_table_name"))+"_ext \nselect * from "+((String)globalMap.get("row7.target_schema_orig"))+"."+((String)globalMap.get("row7.log_table_name")) + ((String)globalMap.get("where_cond"))+"  ; \n \ndrop external table increments."+((String)globalMap.get("row7.log_table_name"))+"_ext ; \n";
whetherReject_tGreenplumRow_11 = false;
globalMap.put("tGreenplumRow_11_QUERY",query_tGreenplumRow_11);
try {
		stmt_tGreenplumRow_11.execute(query_tGreenplumRow_11);
		
	    		log.info("tGreenplumRow_11 - Execute the query: '" + "\ndrop external table if EXISTS increments."+((String)globalMap.get("row7.log_table_name"))+"_ext ; \nCREATE WRITABLE EXTERNAL TABLE increments."+((String)globalMap.get("row7.log_table_name"))+"_ext \n( LIKE " +((String)globalMap.get("row7.target_schema_orig"))+"."+((String)globalMap.get("row7.log_table_name"))+ " ) \nLOCATION ('gpfdist://"+context.ETL_LOCALHOSTNAME+":"+((String)globalMap.get("port"))+"/"+((String)globalMap.get("row7.log_table_name")).replace("\"","").replace("#","__hash__").replace("$","__dollar__")+".txt"+
"' \n) \nFORMAT 'TEXT' (delimiter E'\\013' null '\\\\N' escape '\\\\' ) \nencoding 'UTF8' \nDISTRIBUTED "+( ((String)globalMap.get("distributed_by")).equals("")?"RANDOMLY":"BY ("+(String)globalMap.get("distributed_by")+")"  )  + "   ; \n \ninsert into increments."+((String)globalMap.get("row7.log_table_name"))+"_ext \nselect * from "+((String)globalMap.get("row7.target_schema_orig"))+"."+((String)globalMap.get("row7.log_table_name")) + ((String)globalMap.get("where_cond"))+"  ; \n \ndrop external table increments."+((String)globalMap.get("row7.log_table_name"))+"_ext ; \n" + "' has finished.");
			
	} catch (java.lang.Exception e) {
		whetherReject_tGreenplumRow_11 = true;
		
			throw(e);
			
	}
	
	if(!whetherReject_tGreenplumRow_11) {
		
	}
	

 


	tos_count_tGreenplumRow_11++;

/**
 * [tGreenplumRow_11 main ] stop
 */
	
	/**
	 * [tGreenplumRow_11 end ] start
	 */

	

	
	
	currentComponent="tGreenplumRow_11";

	

	
	stmt_tGreenplumRow_11.close();	

 
                if(log.isDebugEnabled())
            log.debug("tGreenplumRow_11 - "  + ("Done.") );

ok_Hash.put("tGreenplumRow_11", true);
end_Hash.put("tGreenplumRow_11", System.currentTimeMillis());

				if(execStat){   
   	 				runStat.updateStatOnConnection("OnComponentOk27", 0, "ok");
				}
				tGreenplumClose_9Process(globalMap);



/**
 * [tGreenplumRow_11 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage());
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tGreenplumRow_11 finally ] start
	 */

	

	
	
	currentComponent="tGreenplumRow_11";

	

 



/**
 * [tGreenplumRow_11 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tGreenplumRow_11_SUBPROCESS_STATE", 1);
	}
	

public void tGreenplumClose_9Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tGreenplumClose_9_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tGreenplumClose_9 begin ] start
	 */

	

	
		
		ok_Hash.put("tGreenplumClose_9", false);
		start_Hash.put("tGreenplumClose_9", System.currentTimeMillis());
		
	
	currentComponent="tGreenplumClose_9";

	
		int tos_count_tGreenplumClose_9 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tGreenplumClose_9 - "  + ("Start to work.") );
    	class BytesLimit65535_tGreenplumClose_9{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tGreenplumClose_9 = new StringBuilder();
            log4jParamters_tGreenplumClose_9.append("Parameters:");
                    log4jParamters_tGreenplumClose_9.append("CONNECTION" + " = " + "tGreenplumConnection_7");
                log4jParamters_tGreenplumClose_9.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tGreenplumClose_9 - "  + (log4jParamters_tGreenplumClose_9) );
    		}
    	}
    	
        new BytesLimit65535_tGreenplumClose_9().limitLog4jByte();

 



/**
 * [tGreenplumClose_9 begin ] stop
 */
	
	/**
	 * [tGreenplumClose_9 main ] start
	 */

	

	
	
	currentComponent="tGreenplumClose_9";

	



	java.sql.Connection conn_tGreenplumClose_9 = (java.sql.Connection)globalMap.get("conn_tGreenplumConnection_7");
	if(conn_tGreenplumClose_9 != null && !conn_tGreenplumClose_9.isClosed())
	{
                if(log.isDebugEnabled())
            log.debug("tGreenplumClose_9 - "  + ("Closing the connection ")  + ("conn_tGreenplumConnection_7")  + (" to the database.") );
        conn_tGreenplumClose_9.close();
                if(log.isDebugEnabled())
            log.debug("tGreenplumClose_9 - "  + ("Connection ")  + ("conn_tGreenplumConnection_7")  + (" to the database has closed.") );
	}

 


	tos_count_tGreenplumClose_9++;

/**
 * [tGreenplumClose_9 main ] stop
 */
	
	/**
	 * [tGreenplumClose_9 end ] start
	 */

	

	
	
	currentComponent="tGreenplumClose_9";

	

 
                if(log.isDebugEnabled())
            log.debug("tGreenplumClose_9 - "  + ("Done.") );

ok_Hash.put("tGreenplumClose_9", true);
end_Hash.put("tGreenplumClose_9", System.currentTimeMillis());

				if(execStat){   
   	 				runStat.updateStatOnConnection("OnComponentOk28", 0, "ok");
				}
				tFileExist_1Process(globalMap);



/**
 * [tGreenplumClose_9 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage());
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tGreenplumClose_9 finally ] start
	 */

	

	
	
	currentComponent="tGreenplumClose_9";

	

 



/**
 * [tGreenplumClose_9 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tGreenplumClose_9_SUBPROCESS_STATE", 1);
	}
	

public void tFileExist_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tFileExist_1_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tFileExist_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tFileExist_1", false);
		start_Hash.put("tFileExist_1", System.currentTimeMillis());
		
	
	currentComponent="tFileExist_1";

	
		int tos_count_tFileExist_1 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tFileExist_1 - "  + ("Start to work.") );
    	class BytesLimit65535_tFileExist_1{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tFileExist_1 = new StringBuilder();
            log4jParamters_tFileExist_1.append("Parameters:");
                    log4jParamters_tFileExist_1.append("FILE_NAME" + " = " + "context.ETL_STORAGE_PATH + \"/\" + context.GP_SOURCE_NAME + '/' + \"/data/\" + context.SOURCE_DATABASE + \"/\" + ((String)globalMap.get(\"row7.log_table_name\")).replace(\"\\\"\",\"\").replace(\"#\",\"__hash__\").replace(\"$\",\"__dollar__\")+\".txt\"");
                log4jParamters_tFileExist_1.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tFileExist_1 - "  + (log4jParamters_tFileExist_1) );
    		}
    	}
    	
        new BytesLimit65535_tFileExist_1().limitLog4jByte();

 



/**
 * [tFileExist_1 begin ] stop
 */
	
	/**
	 * [tFileExist_1 main ] start
	 */

	

	
	
	currentComponent="tFileExist_1";

	


				final StringBuffer log4jSb_tFileExist_1 = new StringBuffer();
			

java.io.File file_tFileExist_1 = new java.io.File(context.ETL_STORAGE_PATH + "/" + context.GP_SOURCE_NAME + '/' + "/data/" + context.SOURCE_DATABASE + "/" + ((String)globalMap.get("row7.log_table_name")).replace("\"","").replace("#","__hash__").replace("$","__dollar__")+".txt");
if (!file_tFileExist_1.exists()) {
    globalMap.put("tFileExist_1_EXISTS",false);
    log.info("tFileExist_1 - Directory or file : " + file_tFileExist_1.getAbsolutePath() + " doesn't exist.");
}else{
	globalMap.put("tFileExist_1_EXISTS",true);
    log.info("tFileExist_1 - Directory or file : " + file_tFileExist_1.getAbsolutePath() + " exists.");
}

globalMap.put("tFileExist_1_FILENAME",context.ETL_STORAGE_PATH + "/" + context.GP_SOURCE_NAME + '/' + "/data/" + context.SOURCE_DATABASE + "/" + ((String)globalMap.get("row7.log_table_name")).replace("\"","").replace("#","__hash__").replace("$","__dollar__")+".txt");


 


	tos_count_tFileExist_1++;

/**
 * [tFileExist_1 main ] stop
 */
	
	/**
	 * [tFileExist_1 end ] start
	 */

	

	
	
	currentComponent="tFileExist_1";

	

 
                if(log.isDebugEnabled())
            log.debug("tFileExist_1 - "  + ("Done.") );

ok_Hash.put("tFileExist_1", true);
end_Hash.put("tFileExist_1", System.currentTimeMillis());

   			if (!((Boolean)globalMap.get("tFileExist_1_EXISTS"))


) {
   				
					if(execStat){   
   	 					runStat.updateStatOnConnection("If22", 0, "true");
					}
				
    			tFileTouch_2Process(globalMap);
   			}

			   
   				else{
					if(execStat){   
   	 					runStat.updateStatOnConnection("If22", 0, "false");
					}   	 
   				}
   			if (((Boolean)globalMap.get("tFileExist_1_EXISTS"))) {
   				
					if(execStat){   
   	 					runStat.updateStatOnConnection("If6", 0, "true");
					}
				
    			tGreenplumConnection_2Process(globalMap);
   			}

			   
   				else{
					if(execStat){   
   	 					runStat.updateStatOnConnection("If6", 0, "false");
					}   	 
   				}



/**
 * [tFileExist_1 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage());
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tFileExist_1 finally ] start
	 */

	

	
	
	currentComponent="tFileExist_1";

	

 



/**
 * [tFileExist_1 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tFileExist_1_SUBPROCESS_STATE", 1);
	}
	

public void tFileTouch_2Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tFileTouch_2_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tFileTouch_2 begin ] start
	 */

	

	
		
		ok_Hash.put("tFileTouch_2", false);
		start_Hash.put("tFileTouch_2", System.currentTimeMillis());
		
	
	currentComponent="tFileTouch_2";

	
		int tos_count_tFileTouch_2 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tFileTouch_2 - "  + ("Start to work.") );
    	class BytesLimit65535_tFileTouch_2{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tFileTouch_2 = new StringBuilder();
            log4jParamters_tFileTouch_2.append("Parameters:");
                    log4jParamters_tFileTouch_2.append("FILENAME" + " = " + "context.ETL_STORAGE_PATH + \"/\" + context.GP_SOURCE_NAME + '/' + \"/data/\" + context.SOURCE_DATABASE + \"/\" + ((String)globalMap.get(\"row7.log_table_name\")).replace(\"\\\"\",\"\").replace(\"#\",\"__hash__\").replace(\"$\",\"__dollar__\")+\".txt\"");
                log4jParamters_tFileTouch_2.append(" | ");
                    log4jParamters_tFileTouch_2.append("CREATEDIR" + " = " + "false");
                log4jParamters_tFileTouch_2.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tFileTouch_2 - "  + (log4jParamters_tFileTouch_2) );
    		}
    	}
    	
        new BytesLimit65535_tFileTouch_2().limitLog4jByte();

 



/**
 * [tFileTouch_2 begin ] stop
 */
	
	/**
	 * [tFileTouch_2 main ] start
	 */

	

	
	
	currentComponent="tFileTouch_2";

	
	

 

				final StringBuffer log4jSb_tFileTouch_2 = new StringBuffer();
			     
		java.io.File file_tFileTouch_2 = new java.io.File((context.ETL_STORAGE_PATH + "/" + context.GP_SOURCE_NAME + '/' + "/data/" + context.SOURCE_DATABASE + "/" + ((String)globalMap.get("row7.log_table_name")).replace("\"","").replace("#","__hash__").replace("$","__dollar__")+".txt"));        
        
        //create new file
        boolean resulttFileTouch_2 = file_tFileTouch_2.createNewFile();
        //if file already exists, modify the last-modified-time of the file
        if (!resulttFileTouch_2) {
    		log.info("tFileTouch_2 - File : " + file_tFileTouch_2.getAbsolutePath() + " already exist, only modify the last-modified-time of the file.");
    		
        	file_tFileTouch_2.setLastModified((new Date()).getTime());
        }
        else {
        	log.info("tFileTouch_2 - File : " + file_tFileTouch_2.getAbsolutePath() + " is created successfully");
        }
  		
  		      

 


	tos_count_tFileTouch_2++;

/**
 * [tFileTouch_2 main ] stop
 */
	
	/**
	 * [tFileTouch_2 end ] start
	 */

	

	
	
	currentComponent="tFileTouch_2";

	

 
                if(log.isDebugEnabled())
            log.debug("tFileTouch_2 - "  + ("Done.") );

ok_Hash.put("tFileTouch_2", true);
end_Hash.put("tFileTouch_2", System.currentTimeMillis());




/**
 * [tFileTouch_2 end ] stop
 */
				}//end the resume

				
				    			if(resumeEntryMethodName == null || globalResumeTicket){
				    				resumeUtil.addLog("CHECKPOINT", "CONNECTION:SUBJOB_OK:tFileTouch_2:OnSubjobOk", "", Thread.currentThread().getId() + "", "", "", "", "", "");
								}	    				    			
					    	
								if(execStat){    	
									runStat.updateStatOnConnection("OnSubjobOk103", 0, "ok");
								} 
							
							tGreenplumConnection_2Process(globalMap); 
						



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage());
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tFileTouch_2 finally ] start
	 */

	

	
	
	currentComponent="tFileTouch_2";

	

 



/**
 * [tFileTouch_2 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tFileTouch_2_SUBPROCESS_STATE", 1);
	}
	

public void tGreenplumConnection_2Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tGreenplumConnection_2_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tGreenplumConnection_2 begin ] start
	 */

	

	
		
		ok_Hash.put("tGreenplumConnection_2", false);
		start_Hash.put("tGreenplumConnection_2", System.currentTimeMillis());
		
	
	currentComponent="tGreenplumConnection_2";

	
		int tos_count_tGreenplumConnection_2 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tGreenplumConnection_2 - "  + ("Start to work.") );
    	class BytesLimit65535_tGreenplumConnection_2{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tGreenplumConnection_2 = new StringBuilder();
            log4jParamters_tGreenplumConnection_2.append("Parameters:");
                    log4jParamters_tGreenplumConnection_2.append("HOST" + " = " + "context.SOURCING_Server");
                log4jParamters_tGreenplumConnection_2.append(" | ");
                    log4jParamters_tGreenplumConnection_2.append("PORT" + " = " + "context.SOURCING_Port");
                log4jParamters_tGreenplumConnection_2.append(" | ");
                    log4jParamters_tGreenplumConnection_2.append("DBNAME" + " = " + "context.SOURCING_Database");
                log4jParamters_tGreenplumConnection_2.append(" | ");
                    log4jParamters_tGreenplumConnection_2.append("SCHEMA_DB" + " = " + "context.SOURCING_Schema");
                log4jParamters_tGreenplumConnection_2.append(" | ");
                    log4jParamters_tGreenplumConnection_2.append("USER" + " = " + "context.SOURCING_Login");
                log4jParamters_tGreenplumConnection_2.append(" | ");
                    log4jParamters_tGreenplumConnection_2.append("PASS" + " = " + String.valueOf(routines.system.PasswordEncryptUtil.encryptPassword(context.SOURCING_Password)).substring(0, 4) + "...");     
                log4jParamters_tGreenplumConnection_2.append(" | ");
                    log4jParamters_tGreenplumConnection_2.append("USE_SHARED_CONNECTION" + " = " + "false");
                log4jParamters_tGreenplumConnection_2.append(" | ");
                    log4jParamters_tGreenplumConnection_2.append("USE_SSL" + " = " + "true");
                log4jParamters_tGreenplumConnection_2.append(" | ");
                    log4jParamters_tGreenplumConnection_2.append("AUTO_COMMIT" + " = " + "true");
                log4jParamters_tGreenplumConnection_2.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tGreenplumConnection_2 - "  + (log4jParamters_tGreenplumConnection_2) );
    		}
    	}
    	
        new BytesLimit65535_tGreenplumConnection_2().limitLog4jByte();
	

	
				String url_tGreenplumConnection_2 = "jdbc:postgresql://"+context.SOURCING_Server+":"+context.SOURCING_Port+"/"+context.SOURCING_Database+"?ssl=true&sslfactory=org.postgresql.ssl.NonValidatingFactory";

	String dbUser_tGreenplumConnection_2 = context.SOURCING_Login;
	
	
		
	final String decryptedPassword_tGreenplumConnection_2 = context.SOURCING_Password; 
		String dbPwd_tGreenplumConnection_2 = decryptedPassword_tGreenplumConnection_2;
	

	java.sql.Connection conn_tGreenplumConnection_2 = null;
	
		
			String driverClass_tGreenplumConnection_2 = "org.postgresql.Driver";
			java.lang.Class.forName(driverClass_tGreenplumConnection_2);
		
	    		log.debug("tGreenplumConnection_2 - Driver ClassName: "+driverClass_tGreenplumConnection_2+".");
			
	    		log.debug("tGreenplumConnection_2 - Connection attempt to '" + url_tGreenplumConnection_2 + "' with the username '" + dbUser_tGreenplumConnection_2 + "'.");
			
		conn_tGreenplumConnection_2 = java.sql.DriverManager.getConnection(url_tGreenplumConnection_2,dbUser_tGreenplumConnection_2,dbPwd_tGreenplumConnection_2);
	    		log.debug("tGreenplumConnection_2 - Connection to '" + url_tGreenplumConnection_2 + "' has succeeded.");
			

		globalMap.put("conn_tGreenplumConnection_2", conn_tGreenplumConnection_2);
	if (null != conn_tGreenplumConnection_2) {
		
			log.debug("tGreenplumConnection_2 - Connection is set auto commit to 'true'.");
			conn_tGreenplumConnection_2.setAutoCommit(true);
	}

	globalMap.put("schema_" + "tGreenplumConnection_2",context.SOURCING_Schema);

	globalMap.put("conn_" + "tGreenplumConnection_2",conn_tGreenplumConnection_2);
 



/**
 * [tGreenplumConnection_2 begin ] stop
 */
	
	/**
	 * [tGreenplumConnection_2 main ] start
	 */

	

	
	
	currentComponent="tGreenplumConnection_2";

	

 


	tos_count_tGreenplumConnection_2++;

/**
 * [tGreenplumConnection_2 main ] stop
 */
	
	/**
	 * [tGreenplumConnection_2 end ] start
	 */

	

	
	
	currentComponent="tGreenplumConnection_2";

	

 
                if(log.isDebugEnabled())
            log.debug("tGreenplumConnection_2 - "  + ("Done.") );

ok_Hash.put("tGreenplumConnection_2", true);
end_Hash.put("tGreenplumConnection_2", System.currentTimeMillis());

   			if (!context.getProperty("FORCE_DROP").equals("Y")  && !((String)globalMap.get("row7.update_type")).equals("Incremental")
) {
   				
					if(execStat){   
   	 					runStat.updateStatOnConnection("If5", 0, "true");
					}
				
    			tGreenplumRow_4Process(globalMap);
   			}

			   
   				else{
					if(execStat){   
   	 					runStat.updateStatOnConnection("If5", 0, "false");
					}   	 
   				}
   			if (context.getProperty("FORCE_DROP").equals("Y")) {
   				
					if(execStat){   
   	 					runStat.updateStatOnConnection("If1", 0, "true");
					}
				
    			tGreenplumRow_2Process(globalMap);
   			}

			   
   				else{
					if(execStat){   
   	 					runStat.updateStatOnConnection("If1", 0, "false");
					}   	 
   				}
   			if (!context.getProperty("FORCE_DROP").equals("Y") && ((String)globalMap.get("row7.update_type")).equals("Incremental") && (!((String)globalMap.get("PU_Key")).equals("") || !((String)globalMap.get("UK_Key")).equals("") )

) {
   				
					if(execStat){   
   	 					runStat.updateStatOnConnection("If39", 0, "true");
					}
				
    			tGreenplumInput_7Process(globalMap);
   			}

			   
   				else{
					if(execStat){   
   	 					runStat.updateStatOnConnection("If39", 0, "false");
					}   	 
   				}
   			if (!context.getProperty("FORCE_DROP").equals("Y") && ((String)globalMap.get("row7.update_type")).equals("Incremental") &&  ((String)globalMap.get("PU_Key")).equals("")  && ((String)globalMap.get("UK_Key")).equals("")
) {
   				
					if(execStat){   
   	 					runStat.updateStatOnConnection("If41", 0, "true");
					}
				
    			tJava_21Process(globalMap);
   			}

			   
   				else{
					if(execStat){   
   	 					runStat.updateStatOnConnection("If41", 0, "false");
					}   	 
   				}



/**
 * [tGreenplumConnection_2 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage());
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tGreenplumConnection_2 finally ] start
	 */

	

	
	
	currentComponent="tGreenplumConnection_2";

	

 



/**
 * [tGreenplumConnection_2 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tGreenplumConnection_2_SUBPROCESS_STATE", 1);
	}
	

public void tGreenplumRow_4Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tGreenplumRow_4_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tGreenplumRow_4 begin ] start
	 */

	

	
		
		ok_Hash.put("tGreenplumRow_4", false);
		start_Hash.put("tGreenplumRow_4", System.currentTimeMillis());
		
	
	currentComponent="tGreenplumRow_4";

	
		int tos_count_tGreenplumRow_4 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tGreenplumRow_4 - "  + ("Start to work.") );
    	class BytesLimit65535_tGreenplumRow_4{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tGreenplumRow_4 = new StringBuilder();
            log4jParamters_tGreenplumRow_4.append("Parameters:");
                    log4jParamters_tGreenplumRow_4.append("USE_EXISTING_CONNECTION" + " = " + "true");
                log4jParamters_tGreenplumRow_4.append(" | ");
                    log4jParamters_tGreenplumRow_4.append("CONNECTION" + " = " + "tGreenplumConnection_2");
                log4jParamters_tGreenplumRow_4.append(" | ");
                    log4jParamters_tGreenplumRow_4.append("QUERYSTORE" + " = " + "\"\"");
                log4jParamters_tGreenplumRow_4.append(" | ");
                    log4jParamters_tGreenplumRow_4.append("QUERY" + " = " + "\"truncate table \" + (String)globalMap.get(\"row7.target_schema\") + \".\" + (String)globalMap.get(\"row7.log_table_name\")");
                log4jParamters_tGreenplumRow_4.append(" | ");
                    log4jParamters_tGreenplumRow_4.append("DIE_ON_ERROR" + " = " + "false");
                log4jParamters_tGreenplumRow_4.append(" | ");
                    log4jParamters_tGreenplumRow_4.append("PROPAGATE_RECORD_SET" + " = " + "false");
                log4jParamters_tGreenplumRow_4.append(" | ");
                    log4jParamters_tGreenplumRow_4.append("USE_PREPAREDSTATEMENT" + " = " + "false");
                log4jParamters_tGreenplumRow_4.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tGreenplumRow_4 - "  + (log4jParamters_tGreenplumRow_4) );
    		}
    	}
    	
        new BytesLimit65535_tGreenplumRow_4().limitLog4jByte();

	java.sql.Connection conn_tGreenplumRow_4 = null;
	String query_tGreenplumRow_4 = "";
	boolean whetherReject_tGreenplumRow_4 = false;
				conn_tGreenplumRow_4 = (java.sql.Connection)globalMap.get("conn_tGreenplumConnection_2");
			
				if(conn_tGreenplumRow_4 != null) {
					if(conn_tGreenplumRow_4.getMetaData() != null) {
						
						log.debug("tGreenplumRow_4 - Uses an existing connection with username '" + conn_tGreenplumRow_4.getMetaData().getUserName() + "'. Connection URL: " + conn_tGreenplumRow_4.getMetaData().getURL() + ".");
						
					}
				}
			
		java.sql.Statement stmt_tGreenplumRow_4 = conn_tGreenplumRow_4.createStatement();
	

 



/**
 * [tGreenplumRow_4 begin ] stop
 */
	
	/**
	 * [tGreenplumRow_4 main ] start
	 */

	

	
	
	currentComponent="tGreenplumRow_4";

	

	    		log.debug("tGreenplumRow_4 - Executing the query: '" + "truncate table " + (String)globalMap.get("row7.target_schema") + "." + (String)globalMap.get("row7.log_table_name") + "'.");
			
query_tGreenplumRow_4 = "truncate table " + (String)globalMap.get("row7.target_schema") + "." + (String)globalMap.get("row7.log_table_name");
whetherReject_tGreenplumRow_4 = false;
globalMap.put("tGreenplumRow_4_QUERY",query_tGreenplumRow_4);
try {
		stmt_tGreenplumRow_4.execute(query_tGreenplumRow_4);
		
	    		log.info("tGreenplumRow_4 - Execute the query: '" + "truncate table " + (String)globalMap.get("row7.target_schema") + "." + (String)globalMap.get("row7.log_table_name") + "' has finished.");
			
	} catch (java.lang.Exception e) {
		whetherReject_tGreenplumRow_4 = true;
		
				log.error("tGreenplumRow_4 - " + e.getMessage());
			
				System.err.print(e.getMessage());
				
	}
	
	if(!whetherReject_tGreenplumRow_4) {
		
	}
	

 


	tos_count_tGreenplumRow_4++;

/**
 * [tGreenplumRow_4 main ] stop
 */
	
	/**
	 * [tGreenplumRow_4 end ] start
	 */

	

	
	
	currentComponent="tGreenplumRow_4";

	

	
	stmt_tGreenplumRow_4.close();	

 
                if(log.isDebugEnabled())
            log.debug("tGreenplumRow_4 - "  + ("Done.") );

ok_Hash.put("tGreenplumRow_4", true);
end_Hash.put("tGreenplumRow_4", System.currentTimeMillis());




/**
 * [tGreenplumRow_4 end ] stop
 */
				}//end the resume

				
				    			if(resumeEntryMethodName == null || globalResumeTicket){
				    				resumeUtil.addLog("CHECKPOINT", "CONNECTION:SUBJOB_OK:tGreenplumRow_4:OnSubjobOk", "", Thread.currentThread().getId() + "", "", "", "", "", "");
								}	    				    			
					    	
								if(execStat){    	
									runStat.updateStatOnConnection("OnSubjobOk20", 0, "ok");
								} 
							
							tGreenplumRow_10Process(globalMap); 
						



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage());
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tGreenplumRow_4 finally ] start
	 */

	

	
	
	currentComponent="tGreenplumRow_4";

	

 



/**
 * [tGreenplumRow_4 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tGreenplumRow_4_SUBPROCESS_STATE", 1);
	}
	

public void tGreenplumRow_10Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tGreenplumRow_10_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tGreenplumRow_10 begin ] start
	 */

	

	
		
		ok_Hash.put("tGreenplumRow_10", false);
		start_Hash.put("tGreenplumRow_10", System.currentTimeMillis());
		
	
	currentComponent="tGreenplumRow_10";

	
		int tos_count_tGreenplumRow_10 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tGreenplumRow_10 - "  + ("Start to work.") );
    	class BytesLimit65535_tGreenplumRow_10{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tGreenplumRow_10 = new StringBuilder();
            log4jParamters_tGreenplumRow_10.append("Parameters:");
                    log4jParamters_tGreenplumRow_10.append("USE_EXISTING_CONNECTION" + " = " + "true");
                log4jParamters_tGreenplumRow_10.append(" | ");
                    log4jParamters_tGreenplumRow_10.append("CONNECTION" + " = " + "tGreenplumConnection_2");
                log4jParamters_tGreenplumRow_10.append(" | ");
                    log4jParamters_tGreenplumRow_10.append("QUERYSTORE" + " = " + "\"\"");
                log4jParamters_tGreenplumRow_10.append(" | ");
                    log4jParamters_tGreenplumRow_10.append("QUERY" + " = " + "\"  drop external table IF EXISTS increments.\"+((String)globalMap.get(\"row7.log_table_name\"))+\"_ext ;   create external table increments.\"+((String)globalMap.get(\"row7.log_table_name\"))+\"_ext  ( LIKE \"+((String)globalMap.get(\"row7.target_schema_orig\"))+\".\"+((String)globalMap.get(\"row7.log_table_name\"))+\" )  LOCATION ('gpfdist://\"+context.ETL_LOCALHOSTNAME+\":\"+((String)globalMap.get(\"port\"))+\"/\"+((String)globalMap.get(\"row7.log_table_name\")).replace(\"\\\"\",\"\").replace(\"#\",\"__hash__\").replace(\"$\",\"__dollar__\")+\".txt\"+\"'  )  FORMAT 'TEXT' (delimiter E'\\\\013' null '\\\\\\\\N' escape '\\\\\\\\' )   encoding 'UTF8'   ;    insert into \"+((String)globalMap.get(\"row7.target_schema_orig\"))+\".\"+((String)globalMap.get(\"row7.log_table_name\"))+\"   select * from increments.\"+((String)globalMap.get(\"row7.log_table_name\"))+\"_ext ;   drop external table increments.\"+((String)globalMap.get(\"row7.log_table_name\"))+\"_ext ;  \"");
                log4jParamters_tGreenplumRow_10.append(" | ");
                    log4jParamters_tGreenplumRow_10.append("DIE_ON_ERROR" + " = " + "true");
                log4jParamters_tGreenplumRow_10.append(" | ");
                    log4jParamters_tGreenplumRow_10.append("PROPAGATE_RECORD_SET" + " = " + "false");
                log4jParamters_tGreenplumRow_10.append(" | ");
                    log4jParamters_tGreenplumRow_10.append("USE_PREPAREDSTATEMENT" + " = " + "false");
                log4jParamters_tGreenplumRow_10.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tGreenplumRow_10 - "  + (log4jParamters_tGreenplumRow_10) );
    		}
    	}
    	
        new BytesLimit65535_tGreenplumRow_10().limitLog4jByte();

	java.sql.Connection conn_tGreenplumRow_10 = null;
	String query_tGreenplumRow_10 = "";
	boolean whetherReject_tGreenplumRow_10 = false;
				conn_tGreenplumRow_10 = (java.sql.Connection)globalMap.get("conn_tGreenplumConnection_2");
			
				if(conn_tGreenplumRow_10 != null) {
					if(conn_tGreenplumRow_10.getMetaData() != null) {
						
						log.debug("tGreenplumRow_10 - Uses an existing connection with username '" + conn_tGreenplumRow_10.getMetaData().getUserName() + "'. Connection URL: " + conn_tGreenplumRow_10.getMetaData().getURL() + ".");
						
					}
				}
			
		java.sql.Statement stmt_tGreenplumRow_10 = conn_tGreenplumRow_10.createStatement();
	

 



/**
 * [tGreenplumRow_10 begin ] stop
 */
	
	/**
	 * [tGreenplumRow_10 main ] start
	 */

	

	
	
	currentComponent="tGreenplumRow_10";

	

	    		log.debug("tGreenplumRow_10 - Executing the query: '" + "  drop external table IF EXISTS increments."+((String)globalMap.get("row7.log_table_name"))+"_ext ;   create external table increments."+((String)globalMap.get("row7.log_table_name"))+"_ext  ( LIKE "+((String)globalMap.get("row7.target_schema_orig"))+"."+((String)globalMap.get("row7.log_table_name"))+" )  LOCATION ('gpfdist://"+context.ETL_LOCALHOSTNAME+":"+((String)globalMap.get("port"))+"/"+((String)globalMap.get("row7.log_table_name")).replace("\"","").replace("#","__hash__").replace("$","__dollar__")+".txt"+"'  )  FORMAT 'TEXT' (delimiter E'\\013' null '\\\\N' escape '\\\\' )   encoding 'UTF8'   ;    insert into "+((String)globalMap.get("row7.target_schema_orig"))+"."+((String)globalMap.get("row7.log_table_name"))+"   select * from increments."+((String)globalMap.get("row7.log_table_name"))+"_ext ;   drop external table increments."+((String)globalMap.get("row7.log_table_name"))+"_ext ;  " + "'.");
			
query_tGreenplumRow_10 = "\ndrop external table IF EXISTS increments."+((String)globalMap.get("row7.log_table_name"))+"_ext ; \ncreate external table increments."+((String)globalMap.get("row7.log_table_name"))+"_ext\n( LIKE "+((String)globalMap.get("row7.target_schema_orig"))+"."+((String)globalMap.get("row7.log_table_name"))+" )\nLOCATION ('gpfdist://"+context.ETL_LOCALHOSTNAME+":"+((String)globalMap.get("port"))+"/"+((String)globalMap.get("row7.log_table_name")).replace("\"","").replace("#","__hash__").replace("$","__dollar__")+".txt"+"'\n)\nFORMAT 'TEXT' (delimiter E'\\013' null '\\\\N' escape '\\\\' ) \nencoding 'UTF8'\n ;\n\ninsert into "+((String)globalMap.get("row7.target_schema_orig"))+"."+((String)globalMap.get("row7.log_table_name"))+" \nselect * from increments."+((String)globalMap.get("row7.log_table_name"))+"_ext ; \ndrop external table increments."+((String)globalMap.get("row7.log_table_name"))+"_ext ;\n";
whetherReject_tGreenplumRow_10 = false;
globalMap.put("tGreenplumRow_10_QUERY",query_tGreenplumRow_10);
try {
		stmt_tGreenplumRow_10.execute(query_tGreenplumRow_10);
		
	    		log.info("tGreenplumRow_10 - Execute the query: '" + "\ndrop external table IF EXISTS increments."+((String)globalMap.get("row7.log_table_name"))+"_ext ; \ncreate external table increments."+((String)globalMap.get("row7.log_table_name"))+"_ext\n( LIKE "+((String)globalMap.get("row7.target_schema_orig"))+"."+((String)globalMap.get("row7.log_table_name"))+" )\nLOCATION ('gpfdist://"+context.ETL_LOCALHOSTNAME+":"+((String)globalMap.get("port"))+"/"+((String)globalMap.get("row7.log_table_name")).replace("\"","").replace("#","__hash__").replace("$","__dollar__")+".txt"+"'\n)\nFORMAT 'TEXT' (delimiter E'\\013' null '\\\\N' escape '\\\\' ) \nencoding 'UTF8'\n ;\n\ninsert into "+((String)globalMap.get("row7.target_schema_orig"))+"."+((String)globalMap.get("row7.log_table_name"))+" \nselect * from increments."+((String)globalMap.get("row7.log_table_name"))+"_ext ; \ndrop external table increments."+((String)globalMap.get("row7.log_table_name"))+"_ext ;\n" + "' has finished.");
			
	} catch (java.lang.Exception e) {
		whetherReject_tGreenplumRow_10 = true;
		
			throw(e);
			
	}
	
	if(!whetherReject_tGreenplumRow_10) {
		
	}
	

 


	tos_count_tGreenplumRow_10++;

/**
 * [tGreenplumRow_10 main ] stop
 */
	
	/**
	 * [tGreenplumRow_10 end ] start
	 */

	

	
	
	currentComponent="tGreenplumRow_10";

	

	
	stmt_tGreenplumRow_10.close();	

 
                if(log.isDebugEnabled())
            log.debug("tGreenplumRow_10 - "  + ("Done.") );

ok_Hash.put("tGreenplumRow_10", true);
end_Hash.put("tGreenplumRow_10", System.currentTimeMillis());

				if(execStat){   
   	 				runStat.updateStatOnConnection("OnComponentOk10", 0, "ok");
				}
				tGreenplumClose_3Process(globalMap);



/**
 * [tGreenplumRow_10 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage());
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tGreenplumRow_10 finally ] start
	 */

	

	
	
	currentComponent="tGreenplumRow_10";

	

 



/**
 * [tGreenplumRow_10 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tGreenplumRow_10_SUBPROCESS_STATE", 1);
	}
	

public void tGreenplumClose_3Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tGreenplumClose_3_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tGreenplumClose_3 begin ] start
	 */

	

	
		
		ok_Hash.put("tGreenplumClose_3", false);
		start_Hash.put("tGreenplumClose_3", System.currentTimeMillis());
		
	
	currentComponent="tGreenplumClose_3";

	
		int tos_count_tGreenplumClose_3 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tGreenplumClose_3 - "  + ("Start to work.") );
    	class BytesLimit65535_tGreenplumClose_3{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tGreenplumClose_3 = new StringBuilder();
            log4jParamters_tGreenplumClose_3.append("Parameters:");
                    log4jParamters_tGreenplumClose_3.append("CONNECTION" + " = " + "tGreenplumConnection_2");
                log4jParamters_tGreenplumClose_3.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tGreenplumClose_3 - "  + (log4jParamters_tGreenplumClose_3) );
    		}
    	}
    	
        new BytesLimit65535_tGreenplumClose_3().limitLog4jByte();

 



/**
 * [tGreenplumClose_3 begin ] stop
 */
	
	/**
	 * [tGreenplumClose_3 main ] start
	 */

	

	
	
	currentComponent="tGreenplumClose_3";

	



	java.sql.Connection conn_tGreenplumClose_3 = (java.sql.Connection)globalMap.get("conn_tGreenplumConnection_2");
	if(conn_tGreenplumClose_3 != null && !conn_tGreenplumClose_3.isClosed())
	{
                if(log.isDebugEnabled())
            log.debug("tGreenplumClose_3 - "  + ("Closing the connection ")  + ("conn_tGreenplumConnection_2")  + (" to the database.") );
        conn_tGreenplumClose_3.close();
                if(log.isDebugEnabled())
            log.debug("tGreenplumClose_3 - "  + ("Connection ")  + ("conn_tGreenplumConnection_2")  + (" to the database has closed.") );
	}

 


	tos_count_tGreenplumClose_3++;

/**
 * [tGreenplumClose_3 main ] stop
 */
	
	/**
	 * [tGreenplumClose_3 end ] start
	 */

	

	
	
	currentComponent="tGreenplumClose_3";

	

 
                if(log.isDebugEnabled())
            log.debug("tGreenplumClose_3 - "  + ("Done.") );

ok_Hash.put("tGreenplumClose_3", true);
end_Hash.put("tGreenplumClose_3", System.currentTimeMillis());

				if(execStat){   
   	 				runStat.updateStatOnConnection("OnComponentOk14", 0, "ok");
				}
				tFileDelete_1Process(globalMap);



/**
 * [tGreenplumClose_3 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage());
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tGreenplumClose_3 finally ] start
	 */

	

	
	
	currentComponent="tGreenplumClose_3";

	

 



/**
 * [tGreenplumClose_3 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tGreenplumClose_3_SUBPROCESS_STATE", 1);
	}
	

public void tFileDelete_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tFileDelete_1_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tFileDelete_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tFileDelete_1", false);
		start_Hash.put("tFileDelete_1", System.currentTimeMillis());
		
	
	currentComponent="tFileDelete_1";

	
		int tos_count_tFileDelete_1 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tFileDelete_1 - "  + ("Start to work.") );
    	class BytesLimit65535_tFileDelete_1{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tFileDelete_1 = new StringBuilder();
            log4jParamters_tFileDelete_1.append("Parameters:");
                    log4jParamters_tFileDelete_1.append("FILENAME" + " = " + "context.ETL_STORAGE_PATH + \"/\" + context.GP_SOURCE_NAME + '/' + \"/data/\" + context.SOURCE_DATABASE + \"/\" + ((String)globalMap.get(\"row7.log_table_name\")).replace(\"\\\"\",\"\").replace(\"#\",\"__hash__\").replace(\"$\",\"__dollar__\")+\".txt\"");
                log4jParamters_tFileDelete_1.append(" | ");
                    log4jParamters_tFileDelete_1.append("FAILON" + " = " + "false");
                log4jParamters_tFileDelete_1.append(" | ");
                    log4jParamters_tFileDelete_1.append("FOLDER" + " = " + "false");
                log4jParamters_tFileDelete_1.append(" | ");
                    log4jParamters_tFileDelete_1.append("FOLDER_FILE" + " = " + "false");
                log4jParamters_tFileDelete_1.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tFileDelete_1 - "  + (log4jParamters_tFileDelete_1) );
    		}
    	}
    	
        new BytesLimit65535_tFileDelete_1().limitLog4jByte();

 



/**
 * [tFileDelete_1 begin ] stop
 */
	
	/**
	 * [tFileDelete_1 main ] start
	 */

	

	
	
	currentComponent="tFileDelete_1";

	

 

				final StringBuffer log4jSb_tFileDelete_1 = new StringBuffer();
			
class DeleteFoldertFileDelete_1{
	 /**
     * delete all the sub-files in 'file'
     * 
     * @param file
     */
	public boolean delete(java.io.File file) {
        java.io.File[] files = file.listFiles();
        for (int i = 0; i < files.length; i++) {
            if (files[i].isFile()) {
                files[i].delete();
            } else if (files[i].isDirectory()) {
                if (!files[i].delete()) {
                    delete(files[i]);
                }
            }
        }
        deleteDirectory(file);
        return file.delete();
    }

    /**
     * delete all the sub-folders in 'file'
     * 
     * @param file
     */
    private void deleteDirectory(java.io.File file) {
        java.io.File[] filed = file.listFiles();
        for (int i = 0; i < filed.length; i++) {
        	if(filed[i].isDirectory()) {
            	deleteDirectory(filed[i]);
            }
            filed[i].delete();
        }
    }

}
    java.io.File file_tFileDelete_1=new java.io.File(context.ETL_STORAGE_PATH + "/" + context.GP_SOURCE_NAME + '/' + "/data/" + context.SOURCE_DATABASE + "/" + ((String)globalMap.get("row7.log_table_name")).replace("\"","").replace("#","__hash__").replace("$","__dollar__")+".txt");
    if(file_tFileDelete_1.exists()&& file_tFileDelete_1.isFile()){
    	if(file_tFileDelete_1.delete()){
    		globalMap.put("tFileDelete_1_CURRENT_STATUS", "File deleted.");
    		log.info("tFileDelete_1 - File : "+ file_tFileDelete_1.getAbsolutePath() + " is deleted.");
    	}else{
    		globalMap.put("tFileDelete_1_CURRENT_STATUS", "No file deleted.");
    		log.info("tFileDelete_1 - Fail to delete file : "+ file_tFileDelete_1.getAbsolutePath());
    	}
    }else{
    	globalMap.put("tFileDelete_1_CURRENT_STATUS", "File does not exist or is invalid.");
			log.error("tFileDelete_1 - "+ file_tFileDelete_1.getAbsolutePath() + " does not exist or is invalid or is not a file.");
	}
	globalMap.put("tFileDelete_1_DELETE_PATH",context.ETL_STORAGE_PATH + "/" + context.GP_SOURCE_NAME + '/' + "/data/" + context.SOURCE_DATABASE + "/" + ((String)globalMap.get("row7.log_table_name")).replace("\"","").replace("#","__hash__").replace("$","__dollar__")+".txt");
    
     
 

 


	tos_count_tFileDelete_1++;

/**
 * [tFileDelete_1 main ] stop
 */
	
	/**
	 * [tFileDelete_1 end ] start
	 */

	

	
	
	currentComponent="tFileDelete_1";

	

 
                if(log.isDebugEnabled())
            log.debug("tFileDelete_1 - "  + ("Done.") );

ok_Hash.put("tFileDelete_1", true);
end_Hash.put("tFileDelete_1", System.currentTimeMillis());

				if(execStat){   
   	 				runStat.updateStatOnConnection("OnComponentOk20", 0, "ok");
				}
				tJava_19Process(globalMap);



/**
 * [tFileDelete_1 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage());
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tFileDelete_1 finally ] start
	 */

	

	
	
	currentComponent="tFileDelete_1";

	

 



/**
 * [tFileDelete_1 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tFileDelete_1_SUBPROCESS_STATE", 1);
	}
	

public void tJava_19Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tJava_19_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tJava_19 begin ] start
	 */

	

	
		
		ok_Hash.put("tJava_19", false);
		start_Hash.put("tJava_19", System.currentTimeMillis());
		
	
	currentComponent="tJava_19";

	
		int tos_count_tJava_19 = 0;
		
    	class BytesLimit65535_tJava_19{
    		public void limitLog4jByte() throws Exception{
    			
    		}
    	}
    	
        new BytesLimit65535_tJava_19().limitLog4jByte();



Runtime r = Runtime.getRuntime();
//Process p = r.exec("gpfdist -p 8216 -P 8888 & echo $!");
System.out.println("kill "+((String)globalMap.get("row12.outputline")));
Process p = r.exec("kill "+((String)globalMap.get("row12.outputline")));
p.waitFor();


BufferedReader b = new BufferedReader(new InputStreamReader(p.getInputStream()));
String line = "";

while ((line = b.readLine()) != null) {
  System.out.println(line);
}

b.close();

 



/**
 * [tJava_19 begin ] stop
 */
	
	/**
	 * [tJava_19 main ] start
	 */

	

	
	
	currentComponent="tJava_19";

	

 


	tos_count_tJava_19++;

/**
 * [tJava_19 main ] stop
 */
	
	/**
	 * [tJava_19 end ] start
	 */

	

	
	
	currentComponent="tJava_19";

	

 

ok_Hash.put("tJava_19", true);
end_Hash.put("tJava_19", System.currentTimeMillis());

   			if (context.LOG_MESSAGE.equals("") || context.LOG_MESSAGE.equals("NULL")) {
   				
					if(execStat){   
   	 					runStat.updateStatOnConnection("If46", 0, "true");
					}
				
    			tGreenplumConnection_11Process(globalMap);
   			}

			   
   				else{
					if(execStat){   
   	 					runStat.updateStatOnConnection("If46", 0, "false");
					}   	 
   				}
   			if (!context.LOG_MESSAGE.equals("") || !context.LOG_MESSAGE.equals("NULL")) {
   				
					if(execStat){   
   	 					runStat.updateStatOnConnection("If47", 0, "true");
					}
				
    			tGreenplumConnection_3Process(globalMap);
   			}

			   
   				else{
					if(execStat){   
   	 					runStat.updateStatOnConnection("If47", 0, "false");
					}   	 
   				}



/**
 * [tJava_19 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage());
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tJava_19 finally ] start
	 */

	

	
	
	currentComponent="tJava_19";

	

 



/**
 * [tJava_19 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tJava_19_SUBPROCESS_STATE", 1);
	}
	

public void tGreenplumConnection_11Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tGreenplumConnection_11_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tGreenplumConnection_11 begin ] start
	 */

	

	
		
		ok_Hash.put("tGreenplumConnection_11", false);
		start_Hash.put("tGreenplumConnection_11", System.currentTimeMillis());
		
	
	currentComponent="tGreenplumConnection_11";

	
		int tos_count_tGreenplumConnection_11 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tGreenplumConnection_11 - "  + ("Start to work.") );
    	class BytesLimit65535_tGreenplumConnection_11{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tGreenplumConnection_11 = new StringBuilder();
            log4jParamters_tGreenplumConnection_11.append("Parameters:");
                    log4jParamters_tGreenplumConnection_11.append("HOST" + " = " + "context.getProperty(\"SOURCE_HOST\")");
                log4jParamters_tGreenplumConnection_11.append(" | ");
                    log4jParamters_tGreenplumConnection_11.append("PORT" + " = " + "context.getProperty(\"SOURCE_PORT\")");
                log4jParamters_tGreenplumConnection_11.append(" | ");
                    log4jParamters_tGreenplumConnection_11.append("DBNAME" + " = " + "context.getProperty(\"SOURCE_DATABASE\")");
                log4jParamters_tGreenplumConnection_11.append(" | ");
                    log4jParamters_tGreenplumConnection_11.append("SCHEMA_DB" + " = " + "\"\"");
                log4jParamters_tGreenplumConnection_11.append(" | ");
                    log4jParamters_tGreenplumConnection_11.append("USER" + " = " + "context.getProperty(\"SOURCE_USER\")");
                log4jParamters_tGreenplumConnection_11.append(" | ");
                    log4jParamters_tGreenplumConnection_11.append("PASS" + " = " + String.valueOf(routines.system.PasswordEncryptUtil.encryptPassword(context.SOURCE_PASSWORD)).substring(0, 4) + "...");     
                log4jParamters_tGreenplumConnection_11.append(" | ");
                    log4jParamters_tGreenplumConnection_11.append("USE_SHARED_CONNECTION" + " = " + "false");
                log4jParamters_tGreenplumConnection_11.append(" | ");
                    log4jParamters_tGreenplumConnection_11.append("USE_SSL" + " = " + "true");
                log4jParamters_tGreenplumConnection_11.append(" | ");
                    log4jParamters_tGreenplumConnection_11.append("AUTO_COMMIT" + " = " + "true");
                log4jParamters_tGreenplumConnection_11.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tGreenplumConnection_11 - "  + (log4jParamters_tGreenplumConnection_11) );
    		}
    	}
    	
        new BytesLimit65535_tGreenplumConnection_11().limitLog4jByte();
	

	
				String url_tGreenplumConnection_11 = "jdbc:postgresql://"+context.getProperty("SOURCE_HOST")+":"+context.getProperty("SOURCE_PORT")+"/"+context.getProperty("SOURCE_DATABASE")+"?ssl=true&sslfactory=org.postgresql.ssl.NonValidatingFactory";

	String dbUser_tGreenplumConnection_11 = context.getProperty("SOURCE_USER");
	
	
		
	final String decryptedPassword_tGreenplumConnection_11 = context.SOURCE_PASSWORD; 
		String dbPwd_tGreenplumConnection_11 = decryptedPassword_tGreenplumConnection_11;
	

	java.sql.Connection conn_tGreenplumConnection_11 = null;
	
		
			String driverClass_tGreenplumConnection_11 = "org.postgresql.Driver";
			java.lang.Class.forName(driverClass_tGreenplumConnection_11);
		
	    		log.debug("tGreenplumConnection_11 - Driver ClassName: "+driverClass_tGreenplumConnection_11+".");
			
	    		log.debug("tGreenplumConnection_11 - Connection attempt to '" + url_tGreenplumConnection_11 + "' with the username '" + dbUser_tGreenplumConnection_11 + "'.");
			
		conn_tGreenplumConnection_11 = java.sql.DriverManager.getConnection(url_tGreenplumConnection_11,dbUser_tGreenplumConnection_11,dbPwd_tGreenplumConnection_11);
	    		log.debug("tGreenplumConnection_11 - Connection to '" + url_tGreenplumConnection_11 + "' has succeeded.");
			

		globalMap.put("conn_tGreenplumConnection_11", conn_tGreenplumConnection_11);
	if (null != conn_tGreenplumConnection_11) {
		
			log.debug("tGreenplumConnection_11 - Connection is set auto commit to 'true'.");
			conn_tGreenplumConnection_11.setAutoCommit(true);
	}

	globalMap.put("schema_" + "tGreenplumConnection_11","");

	globalMap.put("conn_" + "tGreenplumConnection_11",conn_tGreenplumConnection_11);
 



/**
 * [tGreenplumConnection_11 begin ] stop
 */
	
	/**
	 * [tGreenplumConnection_11 main ] start
	 */

	

	
	
	currentComponent="tGreenplumConnection_11";

	

 


	tos_count_tGreenplumConnection_11++;

/**
 * [tGreenplumConnection_11 main ] stop
 */
	
	/**
	 * [tGreenplumConnection_11 end ] start
	 */

	

	
	
	currentComponent="tGreenplumConnection_11";

	

 
                if(log.isDebugEnabled())
            log.debug("tGreenplumConnection_11 - "  + ("Done.") );

ok_Hash.put("tGreenplumConnection_11", true);
end_Hash.put("tGreenplumConnection_11", System.currentTimeMillis());

				if(execStat){   
   	 				runStat.updateStatOnConnection("OnComponentOk11", 0, "ok");
				}
				tJava_30Process(globalMap);



/**
 * [tGreenplumConnection_11 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage());
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tGreenplumConnection_11 finally ] start
	 */

	

	
	
	currentComponent="tGreenplumConnection_11";

	

 



/**
 * [tGreenplumConnection_11 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tGreenplumConnection_11_SUBPROCESS_STATE", 1);
	}
	

public void tJava_30Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tJava_30_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tJava_30 begin ] start
	 */

	

	
		
		ok_Hash.put("tJava_30", false);
		start_Hash.put("tJava_30", System.currentTimeMillis());
		
	
	currentComponent="tJava_30";

	
		int tos_count_tJava_30 = 0;
		
    	class BytesLimit65535_tJava_30{
    		public void limitLog4jByte() throws Exception{
    			
    		}
    	}
    	
        new BytesLimit65535_tJava_30().limitLog4jByte();



System.out.println(globalMap.get("row7.last_update_date"));

String foo = "update sbdt.edl_table set last_prod2dev_date = " +
" to_timestamp(" + 
((globalMap.get("row7.last_update_date")==null) ? "null" : ("'" + String.valueOf(new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(((java.util.Date)globalMap.get("row7.last_update_date")))) + "'")) +
", 'YYYY-MM-DD HH24:MI:SS')::timestamp without time zone  " + 
" where system_name='" + ((String)globalMap.get("row7.source_name")) + "' and " +
" target_table_name='" + ((String)globalMap.get("row7.log_table_name")) + "';";

System.out.println(foo);
 



/**
 * [tJava_30 begin ] stop
 */
	
	/**
	 * [tJava_30 main ] start
	 */

	

	
	
	currentComponent="tJava_30";

	

 


	tos_count_tJava_30++;

/**
 * [tJava_30 main ] stop
 */
	
	/**
	 * [tJava_30 end ] start
	 */

	

	
	
	currentComponent="tJava_30";

	

 

ok_Hash.put("tJava_30", true);
end_Hash.put("tJava_30", System.currentTimeMillis());




/**
 * [tJava_30 end ] stop
 */
				}//end the resume

				
				    			if(resumeEntryMethodName == null || globalResumeTicket){
				    				resumeUtil.addLog("CHECKPOINT", "CONNECTION:SUBJOB_OK:tJava_30:OnSubjobOk", "", Thread.currentThread().getId() + "", "", "", "", "", "");
								}	    				    			
					    	
								if(execStat){    	
									runStat.updateStatOnConnection("OnSubjobOk60", 0, "ok");
								} 
							
							tGreenplumRow_15Process(globalMap); 
						



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage());
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tJava_30 finally ] start
	 */

	

	
	
	currentComponent="tJava_30";

	

 



/**
 * [tJava_30 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tJava_30_SUBPROCESS_STATE", 1);
	}
	

public void tGreenplumRow_15Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tGreenplumRow_15_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tGreenplumRow_15 begin ] start
	 */

	

	
		
		ok_Hash.put("tGreenplumRow_15", false);
		start_Hash.put("tGreenplumRow_15", System.currentTimeMillis());
		
	
	currentComponent="tGreenplumRow_15";

	
		int tos_count_tGreenplumRow_15 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tGreenplumRow_15 - "  + ("Start to work.") );
    	class BytesLimit65535_tGreenplumRow_15{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tGreenplumRow_15 = new StringBuilder();
            log4jParamters_tGreenplumRow_15.append("Parameters:");
                    log4jParamters_tGreenplumRow_15.append("USE_EXISTING_CONNECTION" + " = " + "true");
                log4jParamters_tGreenplumRow_15.append(" | ");
                    log4jParamters_tGreenplumRow_15.append("CONNECTION" + " = " + "tGreenplumConnection_11");
                log4jParamters_tGreenplumRow_15.append(" | ");
                    log4jParamters_tGreenplumRow_15.append("QUERYSTORE" + " = " + "\"\"");
                log4jParamters_tGreenplumRow_15.append(" | ");
                    log4jParamters_tGreenplumRow_15.append("QUERY" + " = " + "\"update sbdt.edl_table set last_prod2dev_date = \" +  \" to_timestamp(\" +   ((globalMap.get(\"row7.last_update_date\")==null) ? \"now()\" : (\"'\" + String.valueOf(new SimpleDateFormat(\"yyyy-MM-dd HH:mm:ss\").format(((java.util.Date)globalMap.get(\"row7.last_update_date\")))) + \"'\")) +  \", 'YYYY-MM-DD HH24:MI:SS')::timestamp without time zone  \" +   \" where system_name='\" + ((String)globalMap.get(\"row7.source_name\")) + \"' and \" +  \" target_table_name='\" + ((String)globalMap.get(\"row7.log_table_name\")) + \"';\" ");
                log4jParamters_tGreenplumRow_15.append(" | ");
                    log4jParamters_tGreenplumRow_15.append("DIE_ON_ERROR" + " = " + "true");
                log4jParamters_tGreenplumRow_15.append(" | ");
                    log4jParamters_tGreenplumRow_15.append("PROPAGATE_RECORD_SET" + " = " + "false");
                log4jParamters_tGreenplumRow_15.append(" | ");
                    log4jParamters_tGreenplumRow_15.append("USE_PREPAREDSTATEMENT" + " = " + "false");
                log4jParamters_tGreenplumRow_15.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tGreenplumRow_15 - "  + (log4jParamters_tGreenplumRow_15) );
    		}
    	}
    	
        new BytesLimit65535_tGreenplumRow_15().limitLog4jByte();

	java.sql.Connection conn_tGreenplumRow_15 = null;
	String query_tGreenplumRow_15 = "";
	boolean whetherReject_tGreenplumRow_15 = false;
				conn_tGreenplumRow_15 = (java.sql.Connection)globalMap.get("conn_tGreenplumConnection_11");
			
				if(conn_tGreenplumRow_15 != null) {
					if(conn_tGreenplumRow_15.getMetaData() != null) {
						
						log.debug("tGreenplumRow_15 - Uses an existing connection with username '" + conn_tGreenplumRow_15.getMetaData().getUserName() + "'. Connection URL: " + conn_tGreenplumRow_15.getMetaData().getURL() + ".");
						
					}
				}
			
		java.sql.Statement stmt_tGreenplumRow_15 = conn_tGreenplumRow_15.createStatement();
	

 



/**
 * [tGreenplumRow_15 begin ] stop
 */
	
	/**
	 * [tGreenplumRow_15 main ] start
	 */

	

	
	
	currentComponent="tGreenplumRow_15";

	

	    		log.debug("tGreenplumRow_15 - Executing the query: '" + "update sbdt.edl_table set last_prod2dev_date = " +  " to_timestamp(" +   ((globalMap.get("row7.last_update_date")==null) ? "now()" : ("'" + String.valueOf(new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(((java.util.Date)globalMap.get("row7.last_update_date")))) + "'")) +  ", 'YYYY-MM-DD HH24:MI:SS')::timestamp without time zone  " +   " where system_name='" + ((String)globalMap.get("row7.source_name")) + "' and " +  " target_table_name='" + ((String)globalMap.get("row7.log_table_name")) + "';"  + "'.");
			
query_tGreenplumRow_15 = "update sbdt.edl_table set last_prod2dev_date = " +
" to_timestamp(" + 
((globalMap.get("row7.last_update_date")==null) ? "now()" : ("'" + String.valueOf(new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(((java.util.Date)globalMap.get("row7.last_update_date")))) + "'")) +
", 'YYYY-MM-DD HH24:MI:SS')::timestamp without time zone  " + 
" where system_name='" + ((String)globalMap.get("row7.source_name")) + "' and " +
" target_table_name='" + ((String)globalMap.get("row7.log_table_name")) + "';" ;
whetherReject_tGreenplumRow_15 = false;
globalMap.put("tGreenplumRow_15_QUERY",query_tGreenplumRow_15);
try {
		stmt_tGreenplumRow_15.execute(query_tGreenplumRow_15);
		
	    		log.info("tGreenplumRow_15 - Execute the query: '" + "update sbdt.edl_table set last_prod2dev_date = " +
" to_timestamp(" + 
((globalMap.get("row7.last_update_date")==null) ? "now()" : ("'" + String.valueOf(new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(((java.util.Date)globalMap.get("row7.last_update_date")))) + "'")) +
", 'YYYY-MM-DD HH24:MI:SS')::timestamp without time zone  " + 
" where system_name='" + ((String)globalMap.get("row7.source_name")) + "' and " +
" target_table_name='" + ((String)globalMap.get("row7.log_table_name")) + "';"  + "' has finished.");
			
	} catch (java.lang.Exception e) {
		whetherReject_tGreenplumRow_15 = true;
		
			throw(e);
			
	}
	
	if(!whetherReject_tGreenplumRow_15) {
		
	}
	

 


	tos_count_tGreenplumRow_15++;

/**
 * [tGreenplumRow_15 main ] stop
 */
	
	/**
	 * [tGreenplumRow_15 end ] start
	 */

	

	
	
	currentComponent="tGreenplumRow_15";

	

	
	stmt_tGreenplumRow_15.close();	

 
                if(log.isDebugEnabled())
            log.debug("tGreenplumRow_15 - "  + ("Done.") );

ok_Hash.put("tGreenplumRow_15", true);
end_Hash.put("tGreenplumRow_15", System.currentTimeMillis());




/**
 * [tGreenplumRow_15 end ] stop
 */
				}//end the resume

				
				    			if(resumeEntryMethodName == null || globalResumeTicket){
				    				resumeUtil.addLog("CHECKPOINT", "CONNECTION:SUBJOB_OK:tGreenplumRow_15:OnSubjobOk", "", Thread.currentThread().getId() + "", "", "", "", "", "");
								}	    				    			
					    	
								if(execStat){    	
									runStat.updateStatOnConnection("OnSubjobOk7", 0, "ok");
								} 
							
							tGreenplumClose_6Process(globalMap); 
						



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage());
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tGreenplumRow_15 finally ] start
	 */

	

	
	
	currentComponent="tGreenplumRow_15";

	

 



/**
 * [tGreenplumRow_15 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tGreenplumRow_15_SUBPROCESS_STATE", 1);
	}
	

public void tGreenplumClose_6Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tGreenplumClose_6_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tGreenplumClose_6 begin ] start
	 */

	

	
		
		ok_Hash.put("tGreenplumClose_6", false);
		start_Hash.put("tGreenplumClose_6", System.currentTimeMillis());
		
	
	currentComponent="tGreenplumClose_6";

	
		int tos_count_tGreenplumClose_6 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tGreenplumClose_6 - "  + ("Start to work.") );
    	class BytesLimit65535_tGreenplumClose_6{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tGreenplumClose_6 = new StringBuilder();
            log4jParamters_tGreenplumClose_6.append("Parameters:");
                    log4jParamters_tGreenplumClose_6.append("CONNECTION" + " = " + "tGreenplumConnection_11");
                log4jParamters_tGreenplumClose_6.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tGreenplumClose_6 - "  + (log4jParamters_tGreenplumClose_6) );
    		}
    	}
    	
        new BytesLimit65535_tGreenplumClose_6().limitLog4jByte();

 



/**
 * [tGreenplumClose_6 begin ] stop
 */
	
	/**
	 * [tGreenplumClose_6 main ] start
	 */

	

	
	
	currentComponent="tGreenplumClose_6";

	



	java.sql.Connection conn_tGreenplumClose_6 = (java.sql.Connection)globalMap.get("conn_tGreenplumConnection_11");
	if(conn_tGreenplumClose_6 != null && !conn_tGreenplumClose_6.isClosed())
	{
                if(log.isDebugEnabled())
            log.debug("tGreenplumClose_6 - "  + ("Closing the connection ")  + ("conn_tGreenplumConnection_11")  + (" to the database.") );
        conn_tGreenplumClose_6.close();
                if(log.isDebugEnabled())
            log.debug("tGreenplumClose_6 - "  + ("Connection ")  + ("conn_tGreenplumConnection_11")  + (" to the database has closed.") );
	}

 


	tos_count_tGreenplumClose_6++;

/**
 * [tGreenplumClose_6 main ] stop
 */
	
	/**
	 * [tGreenplumClose_6 end ] start
	 */

	

	
	
	currentComponent="tGreenplumClose_6";

	

 
                if(log.isDebugEnabled())
            log.debug("tGreenplumClose_6 - "  + ("Done.") );

ok_Hash.put("tGreenplumClose_6", true);
end_Hash.put("tGreenplumClose_6", System.currentTimeMillis());




/**
 * [tGreenplumClose_6 end ] stop
 */
				}//end the resume

				
				    			if(resumeEntryMethodName == null || globalResumeTicket){
				    				resumeUtil.addLog("CHECKPOINT", "CONNECTION:SUBJOB_OK:tGreenplumClose_6:OnSubjobOk", "", Thread.currentThread().getId() + "", "", "", "", "", "");
								}	    				    			
					    	
								if(execStat){    	
									runStat.updateStatOnConnection("OnSubjobOk107", 0, "ok");
								} 
							
							tGreenplumConnection_3Process(globalMap); 
						



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage());
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tGreenplumClose_6 finally ] start
	 */

	

	
	
	currentComponent="tGreenplumClose_6";

	

 



/**
 * [tGreenplumClose_6 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tGreenplumClose_6_SUBPROCESS_STATE", 1);
	}
	

public void tGreenplumConnection_3Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tGreenplumConnection_3_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tGreenplumConnection_3 begin ] start
	 */

	

	
		
		ok_Hash.put("tGreenplumConnection_3", false);
		start_Hash.put("tGreenplumConnection_3", System.currentTimeMillis());
		
	
	currentComponent="tGreenplumConnection_3";

	
		int tos_count_tGreenplumConnection_3 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tGreenplumConnection_3 - "  + ("Start to work.") );
    	class BytesLimit65535_tGreenplumConnection_3{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tGreenplumConnection_3 = new StringBuilder();
            log4jParamters_tGreenplumConnection_3.append("Parameters:");
                    log4jParamters_tGreenplumConnection_3.append("HOST" + " = " + "context.SOURCING_Server");
                log4jParamters_tGreenplumConnection_3.append(" | ");
                    log4jParamters_tGreenplumConnection_3.append("PORT" + " = " + "context.SOURCING_Port");
                log4jParamters_tGreenplumConnection_3.append(" | ");
                    log4jParamters_tGreenplumConnection_3.append("DBNAME" + " = " + "context.SOURCING_Database");
                log4jParamters_tGreenplumConnection_3.append(" | ");
                    log4jParamters_tGreenplumConnection_3.append("SCHEMA_DB" + " = " + "context.SOURCING_Schema");
                log4jParamters_tGreenplumConnection_3.append(" | ");
                    log4jParamters_tGreenplumConnection_3.append("USER" + " = " + "context.SOURCING_Login");
                log4jParamters_tGreenplumConnection_3.append(" | ");
                    log4jParamters_tGreenplumConnection_3.append("PASS" + " = " + String.valueOf(routines.system.PasswordEncryptUtil.encryptPassword(context.SOURCING_Password)).substring(0, 4) + "...");     
                log4jParamters_tGreenplumConnection_3.append(" | ");
                    log4jParamters_tGreenplumConnection_3.append("USE_SHARED_CONNECTION" + " = " + "false");
                log4jParamters_tGreenplumConnection_3.append(" | ");
                    log4jParamters_tGreenplumConnection_3.append("USE_SSL" + " = " + "true");
                log4jParamters_tGreenplumConnection_3.append(" | ");
                    log4jParamters_tGreenplumConnection_3.append("AUTO_COMMIT" + " = " + "true");
                log4jParamters_tGreenplumConnection_3.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tGreenplumConnection_3 - "  + (log4jParamters_tGreenplumConnection_3) );
    		}
    	}
    	
        new BytesLimit65535_tGreenplumConnection_3().limitLog4jByte();
	

	
				String url_tGreenplumConnection_3 = "jdbc:postgresql://"+context.SOURCING_Server+":"+context.SOURCING_Port+"/"+context.SOURCING_Database+"?ssl=true&sslfactory=org.postgresql.ssl.NonValidatingFactory";

	String dbUser_tGreenplumConnection_3 = context.SOURCING_Login;
	
	
		
	final String decryptedPassword_tGreenplumConnection_3 = context.SOURCING_Password; 
		String dbPwd_tGreenplumConnection_3 = decryptedPassword_tGreenplumConnection_3;
	

	java.sql.Connection conn_tGreenplumConnection_3 = null;
	
		
			String driverClass_tGreenplumConnection_3 = "org.postgresql.Driver";
			java.lang.Class.forName(driverClass_tGreenplumConnection_3);
		
	    		log.debug("tGreenplumConnection_3 - Driver ClassName: "+driverClass_tGreenplumConnection_3+".");
			
	    		log.debug("tGreenplumConnection_3 - Connection attempt to '" + url_tGreenplumConnection_3 + "' with the username '" + dbUser_tGreenplumConnection_3 + "'.");
			
		conn_tGreenplumConnection_3 = java.sql.DriverManager.getConnection(url_tGreenplumConnection_3,dbUser_tGreenplumConnection_3,dbPwd_tGreenplumConnection_3);
	    		log.debug("tGreenplumConnection_3 - Connection to '" + url_tGreenplumConnection_3 + "' has succeeded.");
			

		globalMap.put("conn_tGreenplumConnection_3", conn_tGreenplumConnection_3);
	if (null != conn_tGreenplumConnection_3) {
		
			log.debug("tGreenplumConnection_3 - Connection is set auto commit to 'true'.");
			conn_tGreenplumConnection_3.setAutoCommit(true);
	}

	globalMap.put("schema_" + "tGreenplumConnection_3",context.SOURCING_Schema);

	globalMap.put("conn_" + "tGreenplumConnection_3",conn_tGreenplumConnection_3);
 



/**
 * [tGreenplumConnection_3 begin ] stop
 */
	
	/**
	 * [tGreenplumConnection_3 main ] start
	 */

	

	
	
	currentComponent="tGreenplumConnection_3";

	

 


	tos_count_tGreenplumConnection_3++;

/**
 * [tGreenplumConnection_3 main ] stop
 */
	
	/**
	 * [tGreenplumConnection_3 end ] start
	 */

	

	
	
	currentComponent="tGreenplumConnection_3";

	

 
                if(log.isDebugEnabled())
            log.debug("tGreenplumConnection_3 - "  + ("Done.") );

ok_Hash.put("tGreenplumConnection_3", true);
end_Hash.put("tGreenplumConnection_3", System.currentTimeMillis());




/**
 * [tGreenplumConnection_3 end ] stop
 */
				}//end the resume

				
				    			if(resumeEntryMethodName == null || globalResumeTicket){
				    				resumeUtil.addLog("CHECKPOINT", "CONNECTION:SUBJOB_OK:tGreenplumConnection_3:OnSubjobOk", "", Thread.currentThread().getId() + "", "", "", "", "", "");
								}	    				    			
					    	
								if(execStat){    	
									runStat.updateStatOnConnection("OnSubjobOk14", 0, "ok");
								} 
							
							tGreenplumInput_3Process(globalMap); 
						



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage());
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tGreenplumConnection_3 finally ] start
	 */

	

	
	
	currentComponent="tGreenplumConnection_3";

	

 



/**
 * [tGreenplumConnection_3 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tGreenplumConnection_3_SUBPROCESS_STATE", 1);
	}
	


public static class row2Struct implements routines.system.IPersistableRow<row2Struct> {
    final static byte[] commonByteArrayLock_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Prod2Dev_with_GP_FDIST_child = new byte[0];
    static byte[] commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Prod2Dev_with_GP_FDIST_child = new byte[0];

	
			    public Integer cnt_inserted;

				public Integer getCnt_inserted () {
					return this.cnt_inserted;
				}
				


	private Integer readInteger(ObjectInputStream dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}

	private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException{
		if(intNum == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeInt(intNum);
    	}
	}

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Prod2Dev_with_GP_FDIST_child) {

        	try {

        		int length = 0;
		
						this.cnt_inserted = readInteger(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// Integer
				
						writeInteger(this.cnt_inserted,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("cnt_inserted="+String.valueOf(cnt_inserted));
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				if(cnt_inserted == null){
        					sb.append("<null>");
        				}else{
            				sb.append(cnt_inserted);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(row2Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}
public void tGreenplumInput_3Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tGreenplumInput_3_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;



		row2Struct row2 = new row2Struct();




	
	/**
	 * [tSetGlobalVar_4 begin ] start
	 */

	

	
		
		ok_Hash.put("tSetGlobalVar_4", false);
		start_Hash.put("tSetGlobalVar_4", System.currentTimeMillis());
		
	
	currentComponent="tSetGlobalVar_4";

	
			if (execStat) {
				if(resourceMap.get("inIterateVComp") == null){
					
						runStat.updateStatOnConnection("row2" + iterateId, 0, 0);
					
				}
			} 

		
		int tos_count_tSetGlobalVar_4 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tSetGlobalVar_4 - "  + ("Start to work.") );
    	class BytesLimit65535_tSetGlobalVar_4{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tSetGlobalVar_4 = new StringBuilder();
            log4jParamters_tSetGlobalVar_4.append("Parameters:");
                    log4jParamters_tSetGlobalVar_4.append("VARIABLES" + " = " + "[{VALUE="+("row2.cnt_inserted")+", KEY="+("\"cnt_inserted_rows\"")+"}]");
                log4jParamters_tSetGlobalVar_4.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tSetGlobalVar_4 - "  + (log4jParamters_tSetGlobalVar_4) );
    		}
    	}
    	
        new BytesLimit65535_tSetGlobalVar_4().limitLog4jByte();

 



/**
 * [tSetGlobalVar_4 begin ] stop
 */



	
	/**
	 * [tGreenplumInput_3 begin ] start
	 */

	

	
		
		ok_Hash.put("tGreenplumInput_3", false);
		start_Hash.put("tGreenplumInput_3", System.currentTimeMillis());
		
	
	currentComponent="tGreenplumInput_3";

	
		int tos_count_tGreenplumInput_3 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tGreenplumInput_3 - "  + ("Start to work.") );
    	class BytesLimit65535_tGreenplumInput_3{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tGreenplumInput_3 = new StringBuilder();
            log4jParamters_tGreenplumInput_3.append("Parameters:");
                    log4jParamters_tGreenplumInput_3.append("USE_EXISTING_CONNECTION" + " = " + "true");
                log4jParamters_tGreenplumInput_3.append(" | ");
                    log4jParamters_tGreenplumInput_3.append("CONNECTION" + " = " + "tGreenplumConnection_3");
                log4jParamters_tGreenplumInput_3.append(" | ");
                    log4jParamters_tGreenplumInput_3.append("TABLE" + " = " + "\"\"");
                log4jParamters_tGreenplumInput_3.append(" | ");
                    log4jParamters_tGreenplumInput_3.append("QUERYSTORE" + " = " + "\"\"");
                log4jParamters_tGreenplumInput_3.append(" | ");
                    log4jParamters_tGreenplumInput_3.append("QUERY" + " = " + "\" select count(*) as cnt_inserted\" +  \" from \" +   ((String)globalMap.get(\"row7.target_schema_orig\"))+\".\"+((String)globalMap.get(\"row7.log_table_name\"))");
                log4jParamters_tGreenplumInput_3.append(" | ");
                    log4jParamters_tGreenplumInput_3.append("USE_CURSOR" + " = " + "false");
                log4jParamters_tGreenplumInput_3.append(" | ");
                    log4jParamters_tGreenplumInput_3.append("TRIM_ALL_COLUMN" + " = " + "false");
                log4jParamters_tGreenplumInput_3.append(" | ");
                    log4jParamters_tGreenplumInput_3.append("TRIM_COLUMN" + " = " + "[{TRIM="+("false")+", SCHEMA_COLUMN="+("cnt_inserted")+"}]");
                log4jParamters_tGreenplumInput_3.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tGreenplumInput_3 - "  + (log4jParamters_tGreenplumInput_3) );
    		}
    	}
    	
        new BytesLimit65535_tGreenplumInput_3().limitLog4jByte();
	
    
	
		    int nb_line_tGreenplumInput_3 = 0;
		    java.sql.Connection conn_tGreenplumInput_3 = null;
		        conn_tGreenplumInput_3 = (java.sql.Connection)globalMap.get("conn_tGreenplumConnection_3");
				
				if(conn_tGreenplumInput_3 != null) {
					if(conn_tGreenplumInput_3.getMetaData() != null) {
						
						log.debug("tGreenplumInput_3 - Uses an existing connection with username '" + conn_tGreenplumInput_3.getMetaData().getUserName() + "'. Connection URL: " + conn_tGreenplumInput_3.getMetaData().getURL() + ".");
						
					}
				}
			
		    
			java.sql.Statement stmt_tGreenplumInput_3 = conn_tGreenplumInput_3.createStatement();

		    String dbquery_tGreenplumInput_3 = " select count(*) as cnt_inserted" +
" from " + 
((String)globalMap.get("row7.target_schema_orig"))+"."+((String)globalMap.get("row7.log_table_name"));
			
                log.debug("tGreenplumInput_3 - Executing the query: '"+dbquery_tGreenplumInput_3+"'.");
			

                       globalMap.put("tGreenplumInput_3_QUERY",dbquery_tGreenplumInput_3);

		    java.sql.ResultSet rs_tGreenplumInput_3 = null;
		try{
		    rs_tGreenplumInput_3 = stmt_tGreenplumInput_3.executeQuery(dbquery_tGreenplumInput_3);
		    java.sql.ResultSetMetaData rsmd_tGreenplumInput_3 = rs_tGreenplumInput_3.getMetaData();
		    int colQtyInRs_tGreenplumInput_3 = rsmd_tGreenplumInput_3.getColumnCount();

		    String tmpContent_tGreenplumInput_3 = null;
		    
		    
		    	log.debug("tGreenplumInput_3 - Retrieving records from the database.");
		    
		    while (rs_tGreenplumInput_3.next()) {
		        nb_line_tGreenplumInput_3++;
		        
							if(colQtyInRs_tGreenplumInput_3 < 1) {
								row2.cnt_inserted = null;
							} else {
		                          
            if(rs_tGreenplumInput_3.getObject(1) != null) {
                row2.cnt_inserted = rs_tGreenplumInput_3.getInt(1);
            } else {
                    row2.cnt_inserted = null;
            }
		                    }
					
						log.debug("tGreenplumInput_3 - Retrieving the record " + nb_line_tGreenplumInput_3 + ".");
					


 



/**
 * [tGreenplumInput_3 begin ] stop
 */
	
	/**
	 * [tGreenplumInput_3 main ] start
	 */

	

	
	
	currentComponent="tGreenplumInput_3";

	

 


	tos_count_tGreenplumInput_3++;

/**
 * [tGreenplumInput_3 main ] stop
 */

	
	/**
	 * [tSetGlobalVar_4 main ] start
	 */

	

	
	
	currentComponent="tSetGlobalVar_4";

	

			//row2
			//row2


			
				if(execStat){
					runStat.updateStatOnConnection("row2"+iterateId,1, 1);
				} 
			

		
    			if(log.isTraceEnabled()){
    				log.trace("row2 - " + (row2==null? "": row2.toLogString()));
    			}
    		

globalMap.put("cnt_inserted_rows", row2.cnt_inserted);

 


	tos_count_tSetGlobalVar_4++;

/**
 * [tSetGlobalVar_4 main ] stop
 */



	
	/**
	 * [tGreenplumInput_3 end ] start
	 */

	

	
	
	currentComponent="tGreenplumInput_3";

	

	}
}finally{
	stmt_tGreenplumInput_3.close();

}
globalMap.put("tGreenplumInput_3_NB_LINE",nb_line_tGreenplumInput_3);
	    		log.debug("tGreenplumInput_3 - Retrieved records count: "+nb_line_tGreenplumInput_3 + " .");
			

 
                if(log.isDebugEnabled())
            log.debug("tGreenplumInput_3 - "  + ("Done.") );

ok_Hash.put("tGreenplumInput_3", true);
end_Hash.put("tGreenplumInput_3", System.currentTimeMillis());




/**
 * [tGreenplumInput_3 end ] stop
 */

	
	/**
	 * [tSetGlobalVar_4 end ] start
	 */

	

	
	
	currentComponent="tSetGlobalVar_4";

	

			if(execStat){
				if(resourceMap.get("inIterateVComp") == null || !((Boolean)resourceMap.get("inIterateVComp"))){
			 		runStat.updateStatOnConnection("row2"+iterateId,2, 0); 
			 	}
			}
		
 
                if(log.isDebugEnabled())
            log.debug("tSetGlobalVar_4 - "  + ("Done.") );

ok_Hash.put("tSetGlobalVar_4", true);
end_Hash.put("tSetGlobalVar_4", System.currentTimeMillis());




/**
 * [tSetGlobalVar_4 end ] stop
 */



				}//end the resume

				
				    			if(resumeEntryMethodName == null || globalResumeTicket){
				    				resumeUtil.addLog("CHECKPOINT", "CONNECTION:SUBJOB_OK:tGreenplumInput_3:OnSubjobOk", "", Thread.currentThread().getId() + "", "", "", "", "", "");
								}	    				    			
					    	
								if(execStat){    	
									runStat.updateStatOnConnection("OnSubjobOk71", 0, "ok");
								} 
							
							tGreenplumClose_11Process(globalMap); 
						



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage());
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tGreenplumInput_3 finally ] start
	 */

	

	
	
	currentComponent="tGreenplumInput_3";

	

 



/**
 * [tGreenplumInput_3 finally ] stop
 */

	
	/**
	 * [tSetGlobalVar_4 finally ] start
	 */

	

	
	
	currentComponent="tSetGlobalVar_4";

	

 



/**
 * [tSetGlobalVar_4 finally ] stop
 */



				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tGreenplumInput_3_SUBPROCESS_STATE", 1);
	}
	

public void tGreenplumClose_11Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tGreenplumClose_11_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tGreenplumClose_11 begin ] start
	 */

	

	
		
		ok_Hash.put("tGreenplumClose_11", false);
		start_Hash.put("tGreenplumClose_11", System.currentTimeMillis());
		
	
	currentComponent="tGreenplumClose_11";

	
		int tos_count_tGreenplumClose_11 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tGreenplumClose_11 - "  + ("Start to work.") );
    	class BytesLimit65535_tGreenplumClose_11{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tGreenplumClose_11 = new StringBuilder();
            log4jParamters_tGreenplumClose_11.append("Parameters:");
                    log4jParamters_tGreenplumClose_11.append("CONNECTION" + " = " + "tGreenplumConnection_2");
                log4jParamters_tGreenplumClose_11.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tGreenplumClose_11 - "  + (log4jParamters_tGreenplumClose_11) );
    		}
    	}
    	
        new BytesLimit65535_tGreenplumClose_11().limitLog4jByte();

 



/**
 * [tGreenplumClose_11 begin ] stop
 */
	
	/**
	 * [tGreenplumClose_11 main ] start
	 */

	

	
	
	currentComponent="tGreenplumClose_11";

	



	java.sql.Connection conn_tGreenplumClose_11 = (java.sql.Connection)globalMap.get("conn_tGreenplumConnection_2");
	if(conn_tGreenplumClose_11 != null && !conn_tGreenplumClose_11.isClosed())
	{
                if(log.isDebugEnabled())
            log.debug("tGreenplumClose_11 - "  + ("Closing the connection ")  + ("conn_tGreenplumConnection_2")  + (" to the database.") );
        conn_tGreenplumClose_11.close();
                if(log.isDebugEnabled())
            log.debug("tGreenplumClose_11 - "  + ("Connection ")  + ("conn_tGreenplumConnection_2")  + (" to the database has closed.") );
	}

 


	tos_count_tGreenplumClose_11++;

/**
 * [tGreenplumClose_11 main ] stop
 */
	
	/**
	 * [tGreenplumClose_11 end ] start
	 */

	

	
	
	currentComponent="tGreenplumClose_11";

	

 
                if(log.isDebugEnabled())
            log.debug("tGreenplumClose_11 - "  + ("Done.") );

ok_Hash.put("tGreenplumClose_11", true);
end_Hash.put("tGreenplumClose_11", System.currentTimeMillis());




/**
 * [tGreenplumClose_11 end ] stop
 */
				}//end the resume

				
				    			if(resumeEntryMethodName == null || globalResumeTicket){
				    				resumeUtil.addLog("CHECKPOINT", "CONNECTION:SUBJOB_OK:tGreenplumClose_11:OnSubjobOk", "", Thread.currentThread().getId() + "", "", "", "", "", "");
								}	    				    			
					    	
								if(execStat){    	
									runStat.updateStatOnConnection("OnSubjobOk78", 0, "ok");
								} 
							
							tJava_23Process(globalMap); 
						



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage());
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tGreenplumClose_11 finally ] start
	 */

	

	
	
	currentComponent="tGreenplumClose_11";

	

 



/**
 * [tGreenplumClose_11 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tGreenplumClose_11_SUBPROCESS_STATE", 1);
	}
	

public void tJava_23Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tJava_23_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tJava_23 begin ] start
	 */

	

	
		
		ok_Hash.put("tJava_23", false);
		start_Hash.put("tJava_23", System.currentTimeMillis());
		
	
	currentComponent="tJava_23";

	
		int tos_count_tJava_23 = 0;
		
    	class BytesLimit65535_tJava_23{
    		public void limitLog4jByte() throws Exception{
    			
    		}
    	}
    	
        new BytesLimit65535_tJava_23().limitLog4jByte();


//context.LOG_PLANT_NAME="NULL";
//context.LOG_SYSTEM_NAME="NULL";
//context.LOG_TABLE_NAME="NULL";
//context.LOG_JOB_NAME="NULL";
//context.LOG_DATA_PATH="NULL";
//context.LOG_TECHNOLOGY="NULL";
context.LOG_STATUS="Finish";
//context.LOG_MESSAGE="NULL";
context.LOG_ERROR_CATEGORY="NULL";
//context.LOG_NO_OF_INSERTS=((Integer)globalMap.get("cnt")) ;
//context.LOG_NO_OF_UPDATES=0;
//context.LOG_NO_OF_DELETES=0;
//context.LOG_NO_OF_ERRORS=0;
context.LOG_SOURCE_ROW_COUNT=(Integer)globalMap.get("cnt");
context.LOG_TARGET_ROW_COUNT=(Integer)globalMap.get("cnt_inserted_rows");

 



/**
 * [tJava_23 begin ] stop
 */
	
	/**
	 * [tJava_23 main ] start
	 */

	

	
	
	currentComponent="tJava_23";

	

 


	tos_count_tJava_23++;

/**
 * [tJava_23 main ] stop
 */
	
	/**
	 * [tJava_23 end ] start
	 */

	

	
	
	currentComponent="tJava_23";

	

 

ok_Hash.put("tJava_23", true);
end_Hash.put("tJava_23", System.currentTimeMillis());




/**
 * [tJava_23 end ] stop
 */
				}//end the resume

				
				    			if(resumeEntryMethodName == null || globalResumeTicket){
				    				resumeUtil.addLog("CHECKPOINT", "CONNECTION:SUBJOB_OK:tJava_23:OnSubjobOk", "", Thread.currentThread().getId() + "", "", "", "", "", "");
								}	    				    			
					    	
								if(execStat){    	
									runStat.updateStatOnConnection("OnSubjobOk86", 0, "ok");
								} 
							
							tGreenplumConnection_9Process(globalMap); 
						



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage());
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tJava_23 finally ] start
	 */

	

	
	
	currentComponent="tJava_23";

	

 



/**
 * [tJava_23 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tJava_23_SUBPROCESS_STATE", 1);
	}
	

public void tGreenplumConnection_9Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tGreenplumConnection_9_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tGreenplumConnection_9 begin ] start
	 */

	

	
		
		ok_Hash.put("tGreenplumConnection_9", false);
		start_Hash.put("tGreenplumConnection_9", System.currentTimeMillis());
		
	
	currentComponent="tGreenplumConnection_9";

	
		int tos_count_tGreenplumConnection_9 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tGreenplumConnection_9 - "  + ("Start to work.") );
    	class BytesLimit65535_tGreenplumConnection_9{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tGreenplumConnection_9 = new StringBuilder();
            log4jParamters_tGreenplumConnection_9.append("Parameters:");
                    log4jParamters_tGreenplumConnection_9.append("HOST" + " = " + "context.SOURCE_HOST");
                log4jParamters_tGreenplumConnection_9.append(" | ");
                    log4jParamters_tGreenplumConnection_9.append("PORT" + " = " + "context.SOURCE_PORT");
                log4jParamters_tGreenplumConnection_9.append(" | ");
                    log4jParamters_tGreenplumConnection_9.append("DBNAME" + " = " + "context.SOURCE_DATABASE");
                log4jParamters_tGreenplumConnection_9.append(" | ");
                    log4jParamters_tGreenplumConnection_9.append("SCHEMA_DB" + " = " + "\"\"");
                log4jParamters_tGreenplumConnection_9.append(" | ");
                    log4jParamters_tGreenplumConnection_9.append("USER" + " = " + "context.SOURCE_USER");
                log4jParamters_tGreenplumConnection_9.append(" | ");
                    log4jParamters_tGreenplumConnection_9.append("PASS" + " = " + String.valueOf(routines.system.PasswordEncryptUtil.encryptPassword(context.SOURCE_PASSWORD)).substring(0, 4) + "...");     
                log4jParamters_tGreenplumConnection_9.append(" | ");
                    log4jParamters_tGreenplumConnection_9.append("USE_SHARED_CONNECTION" + " = " + "false");
                log4jParamters_tGreenplumConnection_9.append(" | ");
                    log4jParamters_tGreenplumConnection_9.append("USE_SSL" + " = " + "true");
                log4jParamters_tGreenplumConnection_9.append(" | ");
                    log4jParamters_tGreenplumConnection_9.append("AUTO_COMMIT" + " = " + "true");
                log4jParamters_tGreenplumConnection_9.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tGreenplumConnection_9 - "  + (log4jParamters_tGreenplumConnection_9) );
    		}
    	}
    	
        new BytesLimit65535_tGreenplumConnection_9().limitLog4jByte();
	

	
				String url_tGreenplumConnection_9 = "jdbc:postgresql://"+context.SOURCE_HOST+":"+context.SOURCE_PORT+"/"+context.SOURCE_DATABASE+"?ssl=true&sslfactory=org.postgresql.ssl.NonValidatingFactory";

	String dbUser_tGreenplumConnection_9 = context.SOURCE_USER;
	
	
		
	final String decryptedPassword_tGreenplumConnection_9 = context.SOURCE_PASSWORD; 
		String dbPwd_tGreenplumConnection_9 = decryptedPassword_tGreenplumConnection_9;
	

	java.sql.Connection conn_tGreenplumConnection_9 = null;
	
		
			String driverClass_tGreenplumConnection_9 = "org.postgresql.Driver";
			java.lang.Class.forName(driverClass_tGreenplumConnection_9);
		
	    		log.debug("tGreenplumConnection_9 - Driver ClassName: "+driverClass_tGreenplumConnection_9+".");
			
	    		log.debug("tGreenplumConnection_9 - Connection attempt to '" + url_tGreenplumConnection_9 + "' with the username '" + dbUser_tGreenplumConnection_9 + "'.");
			
		conn_tGreenplumConnection_9 = java.sql.DriverManager.getConnection(url_tGreenplumConnection_9,dbUser_tGreenplumConnection_9,dbPwd_tGreenplumConnection_9);
	    		log.debug("tGreenplumConnection_9 - Connection to '" + url_tGreenplumConnection_9 + "' has succeeded.");
			

		globalMap.put("conn_tGreenplumConnection_9", conn_tGreenplumConnection_9);
	if (null != conn_tGreenplumConnection_9) {
		
			log.debug("tGreenplumConnection_9 - Connection is set auto commit to 'true'.");
			conn_tGreenplumConnection_9.setAutoCommit(true);
	}

	globalMap.put("schema_" + "tGreenplumConnection_9","");

	globalMap.put("conn_" + "tGreenplumConnection_9",conn_tGreenplumConnection_9);
 



/**
 * [tGreenplumConnection_9 begin ] stop
 */
	
	/**
	 * [tGreenplumConnection_9 main ] start
	 */

	

	
	
	currentComponent="tGreenplumConnection_9";

	

 


	tos_count_tGreenplumConnection_9++;

/**
 * [tGreenplumConnection_9 main ] stop
 */
	
	/**
	 * [tGreenplumConnection_9 end ] start
	 */

	

	
	
	currentComponent="tGreenplumConnection_9";

	

 
                if(log.isDebugEnabled())
            log.debug("tGreenplumConnection_9 - "  + ("Done.") );

ok_Hash.put("tGreenplumConnection_9", true);
end_Hash.put("tGreenplumConnection_9", System.currentTimeMillis());




/**
 * [tGreenplumConnection_9 end ] stop
 */
				}//end the resume

				
				    			if(resumeEntryMethodName == null || globalResumeTicket){
				    				resumeUtil.addLog("CHECKPOINT", "CONNECTION:SUBJOB_OK:tGreenplumConnection_9:OnSubjobOk", "", Thread.currentThread().getId() + "", "", "", "", "", "");
								}	    				    			
					    	
								if(execStat){    	
									runStat.updateStatOnConnection("OnSubjobOk95", 0, "ok");
								} 
							
							tJava_24Process(globalMap); 
						



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage());
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tGreenplumConnection_9 finally ] start
	 */

	

	
	
	currentComponent="tGreenplumConnection_9";

	

 



/**
 * [tGreenplumConnection_9 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tGreenplumConnection_9_SUBPROCESS_STATE", 1);
	}
	

public void tJava_24Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tJava_24_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tJava_24 begin ] start
	 */

	

	
		
		ok_Hash.put("tJava_24", false);
		start_Hash.put("tJava_24", System.currentTimeMillis());
		
	
	currentComponent="tJava_24";

	
		int tos_count_tJava_24 = 0;
		
    	class BytesLimit65535_tJava_24{
    		public void limitLog4jByte() throws Exception{
    			
    		}
    	}
    	
        new BytesLimit65535_tJava_24().limitLog4jByte();


System.out.println(((Integer)context.LOG_RUN_ID).toString());
System.out.println(context.LOG_PLANT_NAME);
System.out.println(context.LOG_SYSTEM_NAME);
System.out.println(context.LOG_PLANT_NAME);
System.out.println(context.LOG_PLANT_NAME);
System.out.println(context.LOG_PLANT_NAME);
System.out.println(((Integer)context.LOG_SOURCE_ROW_COUNT).toString());
System.out.println(((Integer)context.LOG_TARGET_ROW_COUNT).toString());

String strInsertLogSql=(String)globalMap.get("insert_log_template");
strInsertLogSql=strInsertLogSql.replace("#RUN_ID", ((Integer)context.LOG_RUN_ID).toString());
strInsertLogSql=strInsertLogSql.replace("#PLANT_NAME", "'"+context.LOG_PLANT_NAME+"'");
strInsertLogSql=strInsertLogSql.replace("#SYSTEM_NAME", "'"+context.LOG_SYSTEM_NAME+"'");
strInsertLogSql=strInsertLogSql.replace("#JOB_NAME", "'"+context.LOG_JOB_NAME+"'");
strInsertLogSql=strInsertLogSql.replace("#TABLE_NAME", "'"+context.TABLE_NAME+"'");
strInsertLogSql=strInsertLogSql.replace("#STATUS", "'"+context.LOG_STATUS+"'");
strInsertLogSql=strInsertLogSql.replace("#DATA_PATH", "'"+context.LOG_DATA_PATH+"'");
strInsertLogSql=strInsertLogSql.replace("#TECHNOLOGY", "'"+context.LOG_TECHNOLOGY+"'");
strInsertLogSql=strInsertLogSql.replace("#NO_OF_INSERTS", ((Integer)context.LOG_NO_OF_INSERTS).toString());
strInsertLogSql=strInsertLogSql.replace("#NO_OF_UPDATES", ((Integer)context.LOG_NO_OF_UPDATES).toString());
strInsertLogSql=strInsertLogSql.replace("#NO_OF_DELETES", ((Integer)context.LOG_NO_OF_DELETES).toString());
strInsertLogSql=strInsertLogSql.replace("#NO_OF_ERRORS", ((Integer)context.LOG_NO_OF_ERRORS).toString());
strInsertLogSql=strInsertLogSql.replace("#MESSAGE", "'"+context.LOG_MESSAGE+"'");
strInsertLogSql=strInsertLogSql.replace("#SOURCE_ROW_COUNT", ((Integer)context.LOG_SOURCE_ROW_COUNT).toString());
strInsertLogSql=strInsertLogSql.replace("#TARGET_ROW_COUNT", ((Integer)context.LOG_TARGET_ROW_COUNT).toString());
strInsertLogSql=strInsertLogSql.replace("#ERROR_CATEGORY", "'"+context.LOG_ERROR_CATEGORY+"'");
globalMap.put("insert_log_sql",strInsertLogSql);
//System.out.println(globalMap.get("insert_log_sql"));
//System.out.println("==============================");
//System.out.println("==============================");
//globalMap.put("now",new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(TalendDate.getCurrentDate()).toString());
//System.out.println(globalMap.get("now"));
//globalMap.put("now_sql","TO_TIMESTAMP('" + ((String)globalMap.get("now")) + "', 'YYYY-MM-DD HH24:MI:SS')::TIMESTAMP WITH TIME ZONE ");
//System.out.println(globalMap.get("now_sql"));
//if (context.LOG_PLANT_NAME.equals("NULL")==true) {
//  context.LOG_PLANT_NAME="Grove City";
//};
//if (context.LOG_APPLICATION.equals("NULL")==true) {
//  context.LOG_APPLICATION="GET-ABM";
//};
 



/**
 * [tJava_24 begin ] stop
 */
	
	/**
	 * [tJava_24 main ] start
	 */

	

	
	
	currentComponent="tJava_24";

	

 


	tos_count_tJava_24++;

/**
 * [tJava_24 main ] stop
 */
	
	/**
	 * [tJava_24 end ] start
	 */

	

	
	
	currentComponent="tJava_24";

	

 

ok_Hash.put("tJava_24", true);
end_Hash.put("tJava_24", System.currentTimeMillis());




/**
 * [tJava_24 end ] stop
 */
				}//end the resume

				
				    			if(resumeEntryMethodName == null || globalResumeTicket){
				    				resumeUtil.addLog("CHECKPOINT", "CONNECTION:SUBJOB_OK:tJava_24:OnSubjobOk", "", Thread.currentThread().getId() + "", "", "", "", "", "");
								}	    				    			
					    	
								if(execStat){    	
									runStat.updateStatOnConnection("OnSubjobOk96", 0, "ok");
								} 
							
							tGreenplumRow_16Process(globalMap); 
						



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage());
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tJava_24 finally ] start
	 */

	

	
	
	currentComponent="tJava_24";

	

 



/**
 * [tJava_24 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tJava_24_SUBPROCESS_STATE", 1);
	}
	

public void tGreenplumRow_16Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tGreenplumRow_16_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tGreenplumRow_16 begin ] start
	 */

	

	
		
		ok_Hash.put("tGreenplumRow_16", false);
		start_Hash.put("tGreenplumRow_16", System.currentTimeMillis());
		
	
	currentComponent="tGreenplumRow_16";

	
		int tos_count_tGreenplumRow_16 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tGreenplumRow_16 - "  + ("Start to work.") );
    	class BytesLimit65535_tGreenplumRow_16{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tGreenplumRow_16 = new StringBuilder();
            log4jParamters_tGreenplumRow_16.append("Parameters:");
                    log4jParamters_tGreenplumRow_16.append("USE_EXISTING_CONNECTION" + " = " + "true");
                log4jParamters_tGreenplumRow_16.append(" | ");
                    log4jParamters_tGreenplumRow_16.append("CONNECTION" + " = " + "tGreenplumConnection_9");
                log4jParamters_tGreenplumRow_16.append(" | ");
                    log4jParamters_tGreenplumRow_16.append("QUERYSTORE" + " = " + "\"\"");
                log4jParamters_tGreenplumRow_16.append(" | ");
                    log4jParamters_tGreenplumRow_16.append("QUERY" + " = " + "(String)globalMap.get(\"insert_log_sql\")");
                log4jParamters_tGreenplumRow_16.append(" | ");
                    log4jParamters_tGreenplumRow_16.append("DIE_ON_ERROR" + " = " + "true");
                log4jParamters_tGreenplumRow_16.append(" | ");
                    log4jParamters_tGreenplumRow_16.append("PROPAGATE_RECORD_SET" + " = " + "false");
                log4jParamters_tGreenplumRow_16.append(" | ");
                    log4jParamters_tGreenplumRow_16.append("USE_PREPAREDSTATEMENT" + " = " + "false");
                log4jParamters_tGreenplumRow_16.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tGreenplumRow_16 - "  + (log4jParamters_tGreenplumRow_16) );
    		}
    	}
    	
        new BytesLimit65535_tGreenplumRow_16().limitLog4jByte();

	java.sql.Connection conn_tGreenplumRow_16 = null;
	String query_tGreenplumRow_16 = "";
	boolean whetherReject_tGreenplumRow_16 = false;
				conn_tGreenplumRow_16 = (java.sql.Connection)globalMap.get("conn_tGreenplumConnection_9");
			
				if(conn_tGreenplumRow_16 != null) {
					if(conn_tGreenplumRow_16.getMetaData() != null) {
						
						log.debug("tGreenplumRow_16 - Uses an existing connection with username '" + conn_tGreenplumRow_16.getMetaData().getUserName() + "'. Connection URL: " + conn_tGreenplumRow_16.getMetaData().getURL() + ".");
						
					}
				}
			
		java.sql.Statement stmt_tGreenplumRow_16 = conn_tGreenplumRow_16.createStatement();
	

 



/**
 * [tGreenplumRow_16 begin ] stop
 */
	
	/**
	 * [tGreenplumRow_16 main ] start
	 */

	

	
	
	currentComponent="tGreenplumRow_16";

	

	    		log.debug("tGreenplumRow_16 - Executing the query: '" + (String)globalMap.get("insert_log_sql") + "'.");
			
query_tGreenplumRow_16 = (String)globalMap.get("insert_log_sql");
whetherReject_tGreenplumRow_16 = false;
globalMap.put("tGreenplumRow_16_QUERY",query_tGreenplumRow_16);
try {
		stmt_tGreenplumRow_16.execute(query_tGreenplumRow_16);
		
	    		log.info("tGreenplumRow_16 - Execute the query: '" + (String)globalMap.get("insert_log_sql") + "' has finished.");
			
	} catch (java.lang.Exception e) {
		whetherReject_tGreenplumRow_16 = true;
		
			throw(e);
			
	}
	
	if(!whetherReject_tGreenplumRow_16) {
		
	}
	

 


	tos_count_tGreenplumRow_16++;

/**
 * [tGreenplumRow_16 main ] stop
 */
	
	/**
	 * [tGreenplumRow_16 end ] start
	 */

	

	
	
	currentComponent="tGreenplumRow_16";

	

	
	stmt_tGreenplumRow_16.close();	

 
                if(log.isDebugEnabled())
            log.debug("tGreenplumRow_16 - "  + ("Done.") );

ok_Hash.put("tGreenplumRow_16", true);
end_Hash.put("tGreenplumRow_16", System.currentTimeMillis());




/**
 * [tGreenplumRow_16 end ] stop
 */
				}//end the resume

				
				    			if(resumeEntryMethodName == null || globalResumeTicket){
				    				resumeUtil.addLog("CHECKPOINT", "CONNECTION:SUBJOB_OK:tGreenplumRow_16:OnSubjobOk", "", Thread.currentThread().getId() + "", "", "", "", "", "");
								}	    				    			
					    	
								if(execStat){    	
									runStat.updateStatOnConnection("OnSubjobOk97", 0, "ok");
								} 
							
							tGreenplumClose_13Process(globalMap); 
						



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage());
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tGreenplumRow_16 finally ] start
	 */

	

	
	
	currentComponent="tGreenplumRow_16";

	

 



/**
 * [tGreenplumRow_16 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tGreenplumRow_16_SUBPROCESS_STATE", 1);
	}
	

public void tGreenplumClose_13Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tGreenplumClose_13_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;





	
	/**
	 * [tGreenplumClose_13 begin ] start
	 */

	

	
		
		ok_Hash.put("tGreenplumClose_13", false);
		start_Hash.put("tGreenplumClose_13", System.currentTimeMillis());
		
	
	currentComponent="tGreenplumClose_13";

	
		int tos_count_tGreenplumClose_13 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tGreenplumClose_13 - "  + ("Start to work.") );
    	class BytesLimit65535_tGreenplumClose_13{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tGreenplumClose_13 = new StringBuilder();
            log4jParamters_tGreenplumClose_13.append("Parameters:");
                    log4jParamters_tGreenplumClose_13.append("CONNECTION" + " = " + "tGreenplumConnection_9");
                log4jParamters_tGreenplumClose_13.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tGreenplumClose_13 - "  + (log4jParamters_tGreenplumClose_13) );
    		}
    	}
    	
        new BytesLimit65535_tGreenplumClose_13().limitLog4jByte();

 



/**
 * [tGreenplumClose_13 begin ] stop
 */
	
	/**
	 * [tGreenplumClose_13 main ] start
	 */

	

	
	
	currentComponent="tGreenplumClose_13";

	



	java.sql.Connection conn_tGreenplumClose_13 = (java.sql.Connection)globalMap.get("conn_tGreenplumConnection_9");
	if(conn_tGreenplumClose_13 != null && !conn_tGreenplumClose_13.isClosed())
	{
                if(log.isDebugEnabled())
            log.debug("tGreenplumClose_13 - "  + ("Closing the connection ")  + ("conn_tGreenplumConnection_9")  + (" to the database.") );
        conn_tGreenplumClose_13.close();
                if(log.isDebugEnabled())
            log.debug("tGreenplumClose_13 - "  + ("Connection ")  + ("conn_tGreenplumConnection_9")  + (" to the database has closed.") );
	}

 


	tos_count_tGreenplumClose_13++;

/**
 * [tGreenplumClose_13 main ] stop
 */
	
	/**
	 * [tGreenplumClose_13 end ] start
	 */

	

	
	
	currentComponent="tGreenplumClose_13";

	

 
                if(log.isDebugEnabled())
            log.debug("tGreenplumClose_13 - "  + ("Done.") );

ok_Hash.put("tGreenplumClose_13", true);
end_Hash.put("tGreenplumClose_13", System.currentTimeMillis());




/**
 * [tGreenplumClose_13 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage());
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tGreenplumClose_13 finally ] start
	 */

	

	
	
	currentComponent="tGreenplumClose_13";

	

 



/**
 * [tGreenplumClose_13 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tGreenplumClose_13_SUBPROCESS_STATE", 1);
	}
	

public void tGreenplumRow_2Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tGreenplumRow_2_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tGreenplumRow_2 begin ] start
	 */

	

	
		
		ok_Hash.put("tGreenplumRow_2", false);
		start_Hash.put("tGreenplumRow_2", System.currentTimeMillis());
		
	
	currentComponent="tGreenplumRow_2";

	
		int tos_count_tGreenplumRow_2 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tGreenplumRow_2 - "  + ("Start to work.") );
    	class BytesLimit65535_tGreenplumRow_2{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tGreenplumRow_2 = new StringBuilder();
            log4jParamters_tGreenplumRow_2.append("Parameters:");
                    log4jParamters_tGreenplumRow_2.append("USE_EXISTING_CONNECTION" + " = " + "true");
                log4jParamters_tGreenplumRow_2.append(" | ");
                    log4jParamters_tGreenplumRow_2.append("CONNECTION" + " = " + "tGreenplumConnection_2");
                log4jParamters_tGreenplumRow_2.append(" | ");
                    log4jParamters_tGreenplumRow_2.append("QUERYSTORE" + " = " + "\"\"");
                log4jParamters_tGreenplumRow_2.append(" | ");
                    log4jParamters_tGreenplumRow_2.append("QUERY" + " = " + "GEroutines.sqlDropTable((String)globalMap.get(\"row7.target_schema\"), \"\", (String)globalMap.get(\"row7.log_table_name\") )");
                log4jParamters_tGreenplumRow_2.append(" | ");
                    log4jParamters_tGreenplumRow_2.append("DIE_ON_ERROR" + " = " + "true");
                log4jParamters_tGreenplumRow_2.append(" | ");
                    log4jParamters_tGreenplumRow_2.append("PROPAGATE_RECORD_SET" + " = " + "false");
                log4jParamters_tGreenplumRow_2.append(" | ");
                    log4jParamters_tGreenplumRow_2.append("USE_PREPAREDSTATEMENT" + " = " + "false");
                log4jParamters_tGreenplumRow_2.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tGreenplumRow_2 - "  + (log4jParamters_tGreenplumRow_2) );
    		}
    	}
    	
        new BytesLimit65535_tGreenplumRow_2().limitLog4jByte();

	java.sql.Connection conn_tGreenplumRow_2 = null;
	String query_tGreenplumRow_2 = "";
	boolean whetherReject_tGreenplumRow_2 = false;
				conn_tGreenplumRow_2 = (java.sql.Connection)globalMap.get("conn_tGreenplumConnection_2");
			
				if(conn_tGreenplumRow_2 != null) {
					if(conn_tGreenplumRow_2.getMetaData() != null) {
						
						log.debug("tGreenplumRow_2 - Uses an existing connection with username '" + conn_tGreenplumRow_2.getMetaData().getUserName() + "'. Connection URL: " + conn_tGreenplumRow_2.getMetaData().getURL() + ".");
						
					}
				}
			
		java.sql.Statement stmt_tGreenplumRow_2 = conn_tGreenplumRow_2.createStatement();
	

 



/**
 * [tGreenplumRow_2 begin ] stop
 */
	
	/**
	 * [tGreenplumRow_2 main ] start
	 */

	

	
	
	currentComponent="tGreenplumRow_2";

	

	    		log.debug("tGreenplumRow_2 - Executing the query: '" + GEroutines.sqlDropTable((String)globalMap.get("row7.target_schema"), "", (String)globalMap.get("row7.log_table_name") ) + "'.");
			
query_tGreenplumRow_2 = GEroutines.sqlDropTable((String)globalMap.get("row7.target_schema"), "", (String)globalMap.get("row7.log_table_name") );
whetherReject_tGreenplumRow_2 = false;
globalMap.put("tGreenplumRow_2_QUERY",query_tGreenplumRow_2);
try {
		stmt_tGreenplumRow_2.execute(query_tGreenplumRow_2);
		
	    		log.info("tGreenplumRow_2 - Execute the query: '" + GEroutines.sqlDropTable((String)globalMap.get("row7.target_schema"), "", (String)globalMap.get("row7.log_table_name") ) + "' has finished.");
			
	} catch (java.lang.Exception e) {
		whetherReject_tGreenplumRow_2 = true;
		
			throw(e);
			
	}
	
	if(!whetherReject_tGreenplumRow_2) {
		
	}
	

 


	tos_count_tGreenplumRow_2++;

/**
 * [tGreenplumRow_2 main ] stop
 */
	
	/**
	 * [tGreenplumRow_2 end ] start
	 */

	

	
	
	currentComponent="tGreenplumRow_2";

	

	
	stmt_tGreenplumRow_2.close();	

 
                if(log.isDebugEnabled())
            log.debug("tGreenplumRow_2 - "  + ("Done.") );

ok_Hash.put("tGreenplumRow_2", true);
end_Hash.put("tGreenplumRow_2", System.currentTimeMillis());




/**
 * [tGreenplumRow_2 end ] stop
 */
				}//end the resume

				
				    			if(resumeEntryMethodName == null || globalResumeTicket){
				    				resumeUtil.addLog("CHECKPOINT", "CONNECTION:SUBJOB_OK:tGreenplumRow_2:OnSubjobOk", "", Thread.currentThread().getId() + "", "", "", "", "", "");
								}	    				    			
					    	
								if(execStat){    	
									runStat.updateStatOnConnection("OnSubjobOk66", 0, "ok");
								} 
							
							tGreenplumRow_3Process(globalMap); 
						



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage());
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tGreenplumRow_2 finally ] start
	 */

	

	
	
	currentComponent="tGreenplumRow_2";

	

 



/**
 * [tGreenplumRow_2 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tGreenplumRow_2_SUBPROCESS_STATE", 1);
	}
	

public void tGreenplumRow_3Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tGreenplumRow_3_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tGreenplumRow_3 begin ] start
	 */

	

	
		
		ok_Hash.put("tGreenplumRow_3", false);
		start_Hash.put("tGreenplumRow_3", System.currentTimeMillis());
		
	
	currentComponent="tGreenplumRow_3";

	
		int tos_count_tGreenplumRow_3 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tGreenplumRow_3 - "  + ("Start to work.") );
    	class BytesLimit65535_tGreenplumRow_3{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tGreenplumRow_3 = new StringBuilder();
            log4jParamters_tGreenplumRow_3.append("Parameters:");
                    log4jParamters_tGreenplumRow_3.append("USE_EXISTING_CONNECTION" + " = " + "true");
                log4jParamters_tGreenplumRow_3.append(" | ");
                    log4jParamters_tGreenplumRow_3.append("CONNECTION" + " = " + "tGreenplumConnection_2");
                log4jParamters_tGreenplumRow_3.append(" | ");
                    log4jParamters_tGreenplumRow_3.append("QUERYSTORE" + " = " + "\"\"");
                log4jParamters_tGreenplumRow_3.append(" | ");
                    log4jParamters_tGreenplumRow_3.append("QUERY" + " = " + "\"CREATE TABLE \" + (String)globalMap.get(\"row7.target_schema\") + \".\" +   (String)globalMap.get(\"row7.log_table_name\") +\" ( \" +   (String)globalMap.get(\"columns_list\") + \" )\"+  globalMap.get(\"distributed\")");
                log4jParamters_tGreenplumRow_3.append(" | ");
                    log4jParamters_tGreenplumRow_3.append("DIE_ON_ERROR" + " = " + "true");
                log4jParamters_tGreenplumRow_3.append(" | ");
                    log4jParamters_tGreenplumRow_3.append("PROPAGATE_RECORD_SET" + " = " + "false");
                log4jParamters_tGreenplumRow_3.append(" | ");
                    log4jParamters_tGreenplumRow_3.append("USE_PREPAREDSTATEMENT" + " = " + "false");
                log4jParamters_tGreenplumRow_3.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tGreenplumRow_3 - "  + (log4jParamters_tGreenplumRow_3) );
    		}
    	}
    	
        new BytesLimit65535_tGreenplumRow_3().limitLog4jByte();

	java.sql.Connection conn_tGreenplumRow_3 = null;
	String query_tGreenplumRow_3 = "";
	boolean whetherReject_tGreenplumRow_3 = false;
				conn_tGreenplumRow_3 = (java.sql.Connection)globalMap.get("conn_tGreenplumConnection_2");
			
				if(conn_tGreenplumRow_3 != null) {
					if(conn_tGreenplumRow_3.getMetaData() != null) {
						
						log.debug("tGreenplumRow_3 - Uses an existing connection with username '" + conn_tGreenplumRow_3.getMetaData().getUserName() + "'. Connection URL: " + conn_tGreenplumRow_3.getMetaData().getURL() + ".");
						
					}
				}
			
		java.sql.Statement stmt_tGreenplumRow_3 = conn_tGreenplumRow_3.createStatement();
	

 



/**
 * [tGreenplumRow_3 begin ] stop
 */
	
	/**
	 * [tGreenplumRow_3 main ] start
	 */

	

	
	
	currentComponent="tGreenplumRow_3";

	

	    		log.debug("tGreenplumRow_3 - Executing the query: '" + "CREATE TABLE " + (String)globalMap.get("row7.target_schema") + "." +   (String)globalMap.get("row7.log_table_name") +" ( " +   (String)globalMap.get("columns_list") + " )"+  globalMap.get("distributed") + "'.");
			
query_tGreenplumRow_3 = "CREATE TABLE " + (String)globalMap.get("row7.target_schema") + "." + 
(String)globalMap.get("row7.log_table_name") +" ( " + 
(String)globalMap.get("columns_list") + " )"+
globalMap.get("distributed");
whetherReject_tGreenplumRow_3 = false;
globalMap.put("tGreenplumRow_3_QUERY",query_tGreenplumRow_3);
try {
		stmt_tGreenplumRow_3.execute(query_tGreenplumRow_3);
		
	    		log.info("tGreenplumRow_3 - Execute the query: '" + "CREATE TABLE " + (String)globalMap.get("row7.target_schema") + "." + 
(String)globalMap.get("row7.log_table_name") +" ( " + 
(String)globalMap.get("columns_list") + " )"+
globalMap.get("distributed") + "' has finished.");
			
	} catch (java.lang.Exception e) {
		whetherReject_tGreenplumRow_3 = true;
		
			throw(e);
			
	}
	
	if(!whetherReject_tGreenplumRow_3) {
		
	}
	

 


	tos_count_tGreenplumRow_3++;

/**
 * [tGreenplumRow_3 main ] stop
 */
	
	/**
	 * [tGreenplumRow_3 end ] start
	 */

	

	
	
	currentComponent="tGreenplumRow_3";

	

	
	stmt_tGreenplumRow_3.close();	

 
                if(log.isDebugEnabled())
            log.debug("tGreenplumRow_3 - "  + ("Done.") );

ok_Hash.put("tGreenplumRow_3", true);
end_Hash.put("tGreenplumRow_3", System.currentTimeMillis());

   			if (!((String)globalMap.get("PU_Key")).equals("") || !((String)globalMap.get("UK_Key")).equals("")
) {
   				
					if(execStat){   
   	 					runStat.updateStatOnConnection("If42", 0, "true");
					}
				
    			tGreenplumRow_22Process(globalMap);
   			}

			   
   				else{
					if(execStat){   
   	 					runStat.updateStatOnConnection("If42", 0, "false");
					}   	 
   				}
   			if (((String)globalMap.get("PU_Key")).equals("") && ((String)globalMap.get("UK_Key")).equals("")) {
   				
					if(execStat){   
   	 					runStat.updateStatOnConnection("If49", 0, "true");
					}
				
    			tGreenplumRow_10Process(globalMap);
   			}

			   
   				else{
					if(execStat){   
   	 					runStat.updateStatOnConnection("If49", 0, "false");
					}   	 
   				}



/**
 * [tGreenplumRow_3 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage());
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tGreenplumRow_3 finally ] start
	 */

	

	
	
	currentComponent="tGreenplumRow_3";

	

 



/**
 * [tGreenplumRow_3 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tGreenplumRow_3_SUBPROCESS_STATE", 1);
	}
	

public void tGreenplumRow_22Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tGreenplumRow_22_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tGreenplumRow_22 begin ] start
	 */

	

	
		
		ok_Hash.put("tGreenplumRow_22", false);
		start_Hash.put("tGreenplumRow_22", System.currentTimeMillis());
		
	
	currentComponent="tGreenplumRow_22";

	
		int tos_count_tGreenplumRow_22 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tGreenplumRow_22 - "  + ("Start to work.") );
    	class BytesLimit65535_tGreenplumRow_22{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tGreenplumRow_22 = new StringBuilder();
            log4jParamters_tGreenplumRow_22.append("Parameters:");
                    log4jParamters_tGreenplumRow_22.append("USE_EXISTING_CONNECTION" + " = " + "true");
                log4jParamters_tGreenplumRow_22.append(" | ");
                    log4jParamters_tGreenplumRow_22.append("CONNECTION" + " = " + "tGreenplumConnection_2");
                log4jParamters_tGreenplumRow_22.append(" | ");
                    log4jParamters_tGreenplumRow_22.append("QUERYSTORE" + " = " + "\"\"");
                log4jParamters_tGreenplumRow_22.append(" | ");
                    log4jParamters_tGreenplumRow_22.append("QUERY" + " = " + "(String)globalMap.get(\"PU_Key\")  +\" \" + (String)globalMap.get(\"UK_Key\")");
                log4jParamters_tGreenplumRow_22.append(" | ");
                    log4jParamters_tGreenplumRow_22.append("DIE_ON_ERROR" + " = " + "true");
                log4jParamters_tGreenplumRow_22.append(" | ");
                    log4jParamters_tGreenplumRow_22.append("PROPAGATE_RECORD_SET" + " = " + "false");
                log4jParamters_tGreenplumRow_22.append(" | ");
                    log4jParamters_tGreenplumRow_22.append("USE_PREPAREDSTATEMENT" + " = " + "false");
                log4jParamters_tGreenplumRow_22.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tGreenplumRow_22 - "  + (log4jParamters_tGreenplumRow_22) );
    		}
    	}
    	
        new BytesLimit65535_tGreenplumRow_22().limitLog4jByte();

	java.sql.Connection conn_tGreenplumRow_22 = null;
	String query_tGreenplumRow_22 = "";
	boolean whetherReject_tGreenplumRow_22 = false;
				conn_tGreenplumRow_22 = (java.sql.Connection)globalMap.get("conn_tGreenplumConnection_2");
			
				if(conn_tGreenplumRow_22 != null) {
					if(conn_tGreenplumRow_22.getMetaData() != null) {
						
						log.debug("tGreenplumRow_22 - Uses an existing connection with username '" + conn_tGreenplumRow_22.getMetaData().getUserName() + "'. Connection URL: " + conn_tGreenplumRow_22.getMetaData().getURL() + ".");
						
					}
				}
			
		java.sql.Statement stmt_tGreenplumRow_22 = conn_tGreenplumRow_22.createStatement();
	

 



/**
 * [tGreenplumRow_22 begin ] stop
 */
	
	/**
	 * [tGreenplumRow_22 main ] start
	 */

	

	
	
	currentComponent="tGreenplumRow_22";

	

	    		log.debug("tGreenplumRow_22 - Executing the query: '" + (String)globalMap.get("PU_Key")  +" " + (String)globalMap.get("UK_Key") + "'.");
			
query_tGreenplumRow_22 = (String)globalMap.get("PU_Key")  +" " + (String)globalMap.get("UK_Key");
whetherReject_tGreenplumRow_22 = false;
globalMap.put("tGreenplumRow_22_QUERY",query_tGreenplumRow_22);
try {
		stmt_tGreenplumRow_22.execute(query_tGreenplumRow_22);
		
	    		log.info("tGreenplumRow_22 - Execute the query: '" + (String)globalMap.get("PU_Key")  +" " + (String)globalMap.get("UK_Key") + "' has finished.");
			
	} catch (java.lang.Exception e) {
		whetherReject_tGreenplumRow_22 = true;
		
			throw(e);
			
	}
	
	if(!whetherReject_tGreenplumRow_22) {
		
	}
	

 


	tos_count_tGreenplumRow_22++;

/**
 * [tGreenplumRow_22 main ] stop
 */
	
	/**
	 * [tGreenplumRow_22 end ] start
	 */

	

	
	
	currentComponent="tGreenplumRow_22";

	

	
	stmt_tGreenplumRow_22.close();	

 
                if(log.isDebugEnabled())
            log.debug("tGreenplumRow_22 - "  + ("Done.") );

ok_Hash.put("tGreenplumRow_22", true);
end_Hash.put("tGreenplumRow_22", System.currentTimeMillis());

				if(execStat){   
   	 				runStat.updateStatOnConnection("OnComponentOk29", 0, "ok");
				}
				tGreenplumRow_10Process(globalMap);



/**
 * [tGreenplumRow_22 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage());
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tGreenplumRow_22 finally ] start
	 */

	

	
	
	currentComponent="tGreenplumRow_22";

	

 



/**
 * [tGreenplumRow_22 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tGreenplumRow_22_SUBPROCESS_STATE", 1);
	}
	


public static class row16Struct implements routines.system.IPersistableRow<row16Struct> {
    final static byte[] commonByteArrayLock_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Prod2Dev_with_GP_FDIST_child = new byte[0];
    static byte[] commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Prod2Dev_with_GP_FDIST_child = new byte[0];

	
			    public Integer pk_cnt;

				public Integer getPk_cnt () {
					return this.pk_cnt;
				}
				
			    public Integer uk_cnt;

				public Integer getUk_cnt () {
					return this.uk_cnt;
				}
				


	private Integer readInteger(ObjectInputStream dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}

	private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException{
		if(intNum == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeInt(intNum);
    	}
	}

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Prod2Dev_with_GP_FDIST_child) {

        	try {

        		int length = 0;
		
						this.pk_cnt = readInteger(dis);
					
						this.uk_cnt = readInteger(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// Integer
				
						writeInteger(this.pk_cnt,dos);
					
					// Integer
				
						writeInteger(this.uk_cnt,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("pk_cnt="+String.valueOf(pk_cnt));
		sb.append(",uk_cnt="+String.valueOf(uk_cnt));
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				if(pk_cnt == null){
        					sb.append("<null>");
        				}else{
            				sb.append(pk_cnt);
            			}
            		
        			sb.append("|");
        		
        				if(uk_cnt == null){
        					sb.append("<null>");
        				}else{
            				sb.append(uk_cnt);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(row16Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}
public void tGreenplumInput_7Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tGreenplumInput_7_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;



		row16Struct row16 = new row16Struct();




	
	/**
	 * [tJavaRow_9 begin ] start
	 */

	

	
		
		ok_Hash.put("tJavaRow_9", false);
		start_Hash.put("tJavaRow_9", System.currentTimeMillis());
		
	
	currentComponent="tJavaRow_9";

	
			if (execStat) {
				if(resourceMap.get("inIterateVComp") == null){
					
						runStat.updateStatOnConnection("row16" + iterateId, 0, 0);
					
				}
			} 

		
		int tos_count_tJavaRow_9 = 0;
		
    	class BytesLimit65535_tJavaRow_9{
    		public void limitLog4jByte() throws Exception{
    			
    		}
    	}
    	
        new BytesLimit65535_tJavaRow_9().limitLog4jByte();

int nb_line_tJavaRow_9 = 0;

 



/**
 * [tJavaRow_9 begin ] stop
 */



	
	/**
	 * [tGreenplumInput_7 begin ] start
	 */

	

	
		
		ok_Hash.put("tGreenplumInput_7", false);
		start_Hash.put("tGreenplumInput_7", System.currentTimeMillis());
		
	
	currentComponent="tGreenplumInput_7";

	
		int tos_count_tGreenplumInput_7 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tGreenplumInput_7 - "  + ("Start to work.") );
    	class BytesLimit65535_tGreenplumInput_7{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tGreenplumInput_7 = new StringBuilder();
            log4jParamters_tGreenplumInput_7.append("Parameters:");
                    log4jParamters_tGreenplumInput_7.append("USE_EXISTING_CONNECTION" + " = " + "true");
                log4jParamters_tGreenplumInput_7.append(" | ");
                    log4jParamters_tGreenplumInput_7.append("CONNECTION" + " = " + "tGreenplumConnection_2");
                log4jParamters_tGreenplumInput_7.append(" | ");
                    log4jParamters_tGreenplumInput_7.append("TABLE" + " = " + "\"\"");
                log4jParamters_tGreenplumInput_7.append(" | ");
                    log4jParamters_tGreenplumInput_7.append("QUERYSTORE" + " = " + "\"\"");
                log4jParamters_tGreenplumInput_7.append(" | ");
                    log4jParamters_tGreenplumInput_7.append("QUERY" + " = " + "  \"select  coalesce(sum (case when  constraint_type = 'PRIMARY KEY' or upper(constraint_name) like 'PK%' then 1  		else 0  	     end),0)  as pk_cnt,       coalesce(sum (case when  constraint_type = 'UNIQUE' or upper(constraint_name) like 'UK%' then 1  	else 0       end),0) uk_cnt  from  (select  tc.constraint_name, constraint_type  from        information_schema.table_constraints tc       where 1=1  	and upper(tc.table_name)='\"+((String)globalMap.get(\"row7.target_table_name\")).toUpperCase()+\"'  	and upper(tc.table_schema) = '\"+((String)globalMap.get(\"row7.target_schema\")).toUpperCase()+\"') as key_exists ;\"");
                log4jParamters_tGreenplumInput_7.append(" | ");
                    log4jParamters_tGreenplumInput_7.append("USE_CURSOR" + " = " + "false");
                log4jParamters_tGreenplumInput_7.append(" | ");
                    log4jParamters_tGreenplumInput_7.append("TRIM_ALL_COLUMN" + " = " + "false");
                log4jParamters_tGreenplumInput_7.append(" | ");
                    log4jParamters_tGreenplumInput_7.append("TRIM_COLUMN" + " = " + "[{TRIM="+("false")+", SCHEMA_COLUMN="+("pk_cnt")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("uk_cnt")+"}]");
                log4jParamters_tGreenplumInput_7.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tGreenplumInput_7 - "  + (log4jParamters_tGreenplumInput_7) );
    		}
    	}
    	
        new BytesLimit65535_tGreenplumInput_7().limitLog4jByte();
	
    
	
		    int nb_line_tGreenplumInput_7 = 0;
		    java.sql.Connection conn_tGreenplumInput_7 = null;
		        conn_tGreenplumInput_7 = (java.sql.Connection)globalMap.get("conn_tGreenplumConnection_2");
				
				if(conn_tGreenplumInput_7 != null) {
					if(conn_tGreenplumInput_7.getMetaData() != null) {
						
						log.debug("tGreenplumInput_7 - Uses an existing connection with username '" + conn_tGreenplumInput_7.getMetaData().getUserName() + "'. Connection URL: " + conn_tGreenplumInput_7.getMetaData().getURL() + ".");
						
					}
				}
			
		    
			java.sql.Statement stmt_tGreenplumInput_7 = conn_tGreenplumInput_7.createStatement();

		    String dbquery_tGreenplumInput_7 = 
"select  coalesce(sum (case when  constraint_type = 'PRIMARY KEY' or upper(constraint_name) like 'PK%' then 1\n		else 0\n	     end),0)  as pk_cnt,\n     coalesce(sum (case when  constraint_type = 'UNIQUE' or upper(constraint_name) like 'UK%' then 1\n	else 0\n     end),0) uk_cnt\nfrom  (select  tc.constraint_name, constraint_type\nfrom  \n    information_schema.table_constraints tc     \nwhere 1=1\n	and upper(tc.table_name)='"+((String)globalMap.get("row7.target_table_name")).toUpperCase()+"'\n	and upper(tc.table_schema) = '"+((String)globalMap.get("row7.target_schema")).toUpperCase()+"') as key_exists ;";
			
                log.debug("tGreenplumInput_7 - Executing the query: '"+dbquery_tGreenplumInput_7+"'.");
			

                       globalMap.put("tGreenplumInput_7_QUERY",dbquery_tGreenplumInput_7);

		    java.sql.ResultSet rs_tGreenplumInput_7 = null;
		try{
		    rs_tGreenplumInput_7 = stmt_tGreenplumInput_7.executeQuery(dbquery_tGreenplumInput_7);
		    java.sql.ResultSetMetaData rsmd_tGreenplumInput_7 = rs_tGreenplumInput_7.getMetaData();
		    int colQtyInRs_tGreenplumInput_7 = rsmd_tGreenplumInput_7.getColumnCount();

		    String tmpContent_tGreenplumInput_7 = null;
		    
		    
		    	log.debug("tGreenplumInput_7 - Retrieving records from the database.");
		    
		    while (rs_tGreenplumInput_7.next()) {
		        nb_line_tGreenplumInput_7++;
		        
							if(colQtyInRs_tGreenplumInput_7 < 1) {
								row16.pk_cnt = null;
							} else {
		                          
            if(rs_tGreenplumInput_7.getObject(1) != null) {
                row16.pk_cnt = rs_tGreenplumInput_7.getInt(1);
            } else {
                    row16.pk_cnt = null;
            }
		                    }
							if(colQtyInRs_tGreenplumInput_7 < 2) {
								row16.uk_cnt = null;
							} else {
		                          
            if(rs_tGreenplumInput_7.getObject(2) != null) {
                row16.uk_cnt = rs_tGreenplumInput_7.getInt(2);
            } else {
                    row16.uk_cnt = null;
            }
		                    }
					
						log.debug("tGreenplumInput_7 - Retrieving the record " + nb_line_tGreenplumInput_7 + ".");
					


 



/**
 * [tGreenplumInput_7 begin ] stop
 */
	
	/**
	 * [tGreenplumInput_7 main ] start
	 */

	

	
	
	currentComponent="tGreenplumInput_7";

	

 


	tos_count_tGreenplumInput_7++;

/**
 * [tGreenplumInput_7 main ] stop
 */

	
	/**
	 * [tJavaRow_9 main ] start
	 */

	

	
	
	currentComponent="tJavaRow_9";

	

			//row16
			//row16


			
				if(execStat){
					runStat.updateStatOnConnection("row16"+iterateId,1, 1);
				} 
			

		
    			if(log.isTraceEnabled()){
    				log.trace("row16 - " + (row16==null? "": row16.toLogString()));
    			}
    		

    System.out.println("pk_count: "+row16.pk_cnt);
System.out.println("uk_count: "+row16.uk_cnt);



String keyMatrix =  String.valueOf(row16.pk_cnt) +  String.valueOf(row16.uk_cnt);
System.out.println("key_mtx: "+keyMatrix);



globalMap.put("key_mtx", keyMatrix);

System.out.println("key_mtx: "+keyMatrix);



/*

if ((Integer)row16.pk_cnt>0) 
{
	globalMap.put("pk_exists", "true");
} else{
	globalMap.put("pk_exists", "false");
}

System.out.println("Primary key exists");
System.out.println((String)globalMap.get("pk_exists"));


if ((Integer)row16.uk_cnt>0) 
{
	globalMap.put("uk_exists", "true");
} else{
	globalMap.put("uk_exists", "false");
}


System.out.println("Unique key exists");
System.out.println((String)globalMap.get("uk_exists"));
*/

    nb_line_tJavaRow_9++;   

 


	tos_count_tJavaRow_9++;

/**
 * [tJavaRow_9 main ] stop
 */



	
	/**
	 * [tGreenplumInput_7 end ] start
	 */

	

	
	
	currentComponent="tGreenplumInput_7";

	

	}
}finally{
	stmt_tGreenplumInput_7.close();

}
globalMap.put("tGreenplumInput_7_NB_LINE",nb_line_tGreenplumInput_7);
	    		log.debug("tGreenplumInput_7 - Retrieved records count: "+nb_line_tGreenplumInput_7 + " .");
			

 
                if(log.isDebugEnabled())
            log.debug("tGreenplumInput_7 - "  + ("Done.") );

ok_Hash.put("tGreenplumInput_7", true);
end_Hash.put("tGreenplumInput_7", System.currentTimeMillis());




/**
 * [tGreenplumInput_7 end ] stop
 */

	
	/**
	 * [tJavaRow_9 end ] start
	 */

	

	
	
	currentComponent="tJavaRow_9";

	

globalMap.put("tJavaRow_9_NB_LINE",nb_line_tJavaRow_9);
			if(execStat){
				if(resourceMap.get("inIterateVComp") == null || !((Boolean)resourceMap.get("inIterateVComp"))){
			 		runStat.updateStatOnConnection("row16"+iterateId,2, 0); 
			 	}
			}
		
 

ok_Hash.put("tJavaRow_9", true);
end_Hash.put("tJavaRow_9", System.currentTimeMillis());

   			if (/*!((String)globalMap.get("pk_exists")).equals("true")*/ /*|| !((String)globalMap.get("uk_exists")).equals("true")*/
((String)globalMap.get("key_mtx")).equals("00")) {
   				
					if(execStat){   
   	 					runStat.updateStatOnConnection("If48", 0, "true");
					}
				
    			tGreenplumRow_18Process(globalMap);
   			}

			   
   				else{
					if(execStat){   
   	 					runStat.updateStatOnConnection("If48", 0, "false");
					}   	 
   				}
   			if ( /*((String)globalMap.get("pk_exists")).equals("true")*//* || ((String)globalMap.get("uk_exists")).equals("true")*/
((String)globalMap.get("key_mtx")).equals("11") || ((String)globalMap.get("key_mtx")).equals("10") || 
((String)globalMap.get("key_mtx")).equals("01")) {
   				
					if(execStat){   
   	 					runStat.updateStatOnConnection("If38", 0, "true");
					}
				
    			tGreenplumRow_17Process(globalMap);
   			}

			   
   				else{
					if(execStat){   
   	 					runStat.updateStatOnConnection("If38", 0, "false");
					}   	 
   				}



/**
 * [tJavaRow_9 end ] stop
 */



				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage());
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tGreenplumInput_7 finally ] start
	 */

	

	
	
	currentComponent="tGreenplumInput_7";

	

 



/**
 * [tGreenplumInput_7 finally ] stop
 */

	
	/**
	 * [tJavaRow_9 finally ] start
	 */

	

	
	
	currentComponent="tJavaRow_9";

	

 



/**
 * [tJavaRow_9 finally ] stop
 */



				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tGreenplumInput_7_SUBPROCESS_STATE", 1);
	}
	

public void tGreenplumRow_18Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tGreenplumRow_18_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tGreenplumRow_18 begin ] start
	 */

	

	
		
		ok_Hash.put("tGreenplumRow_18", false);
		start_Hash.put("tGreenplumRow_18", System.currentTimeMillis());
		
	
	currentComponent="tGreenplumRow_18";

	
		int tos_count_tGreenplumRow_18 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tGreenplumRow_18 - "  + ("Start to work.") );
    	class BytesLimit65535_tGreenplumRow_18{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tGreenplumRow_18 = new StringBuilder();
            log4jParamters_tGreenplumRow_18.append("Parameters:");
                    log4jParamters_tGreenplumRow_18.append("USE_EXISTING_CONNECTION" + " = " + "true");
                log4jParamters_tGreenplumRow_18.append(" | ");
                    log4jParamters_tGreenplumRow_18.append("CONNECTION" + " = " + "tGreenplumConnection_2");
                log4jParamters_tGreenplumRow_18.append(" | ");
                    log4jParamters_tGreenplumRow_18.append("QUERYSTORE" + " = " + "\"\"");
                log4jParamters_tGreenplumRow_18.append(" | ");
                    log4jParamters_tGreenplumRow_18.append("QUERY" + " = " + "(String)globalMap.get(\"PU_Key\")  + \" \" +(String)globalMap.get(\"UK_Key\")");
                log4jParamters_tGreenplumRow_18.append(" | ");
                    log4jParamters_tGreenplumRow_18.append("DIE_ON_ERROR" + " = " + "false");
                log4jParamters_tGreenplumRow_18.append(" | ");
                    log4jParamters_tGreenplumRow_18.append("PROPAGATE_RECORD_SET" + " = " + "false");
                log4jParamters_tGreenplumRow_18.append(" | ");
                    log4jParamters_tGreenplumRow_18.append("USE_PREPAREDSTATEMENT" + " = " + "false");
                log4jParamters_tGreenplumRow_18.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tGreenplumRow_18 - "  + (log4jParamters_tGreenplumRow_18) );
    		}
    	}
    	
        new BytesLimit65535_tGreenplumRow_18().limitLog4jByte();

	java.sql.Connection conn_tGreenplumRow_18 = null;
	String query_tGreenplumRow_18 = "";
	boolean whetherReject_tGreenplumRow_18 = false;
				conn_tGreenplumRow_18 = (java.sql.Connection)globalMap.get("conn_tGreenplumConnection_2");
			
				if(conn_tGreenplumRow_18 != null) {
					if(conn_tGreenplumRow_18.getMetaData() != null) {
						
						log.debug("tGreenplumRow_18 - Uses an existing connection with username '" + conn_tGreenplumRow_18.getMetaData().getUserName() + "'. Connection URL: " + conn_tGreenplumRow_18.getMetaData().getURL() + ".");
						
					}
				}
			
		java.sql.Statement stmt_tGreenplumRow_18 = conn_tGreenplumRow_18.createStatement();
	

 



/**
 * [tGreenplumRow_18 begin ] stop
 */
	
	/**
	 * [tGreenplumRow_18 main ] start
	 */

	

	
	
	currentComponent="tGreenplumRow_18";

	

	    		log.debug("tGreenplumRow_18 - Executing the query: '" + (String)globalMap.get("PU_Key")  + " " +(String)globalMap.get("UK_Key") + "'.");
			
query_tGreenplumRow_18 = (String)globalMap.get("PU_Key")  + " " +(String)globalMap.get("UK_Key");
whetherReject_tGreenplumRow_18 = false;
globalMap.put("tGreenplumRow_18_QUERY",query_tGreenplumRow_18);
try {
		stmt_tGreenplumRow_18.execute(query_tGreenplumRow_18);
		
	    		log.info("tGreenplumRow_18 - Execute the query: '" + (String)globalMap.get("PU_Key")  + " " +(String)globalMap.get("UK_Key") + "' has finished.");
			
	} catch (java.lang.Exception e) {
		whetherReject_tGreenplumRow_18 = true;
		
				log.error("tGreenplumRow_18 - " + e.getMessage());
			
				System.err.print(e.getMessage());
				
	}
	
	if(!whetherReject_tGreenplumRow_18) {
		
	}
	

 


	tos_count_tGreenplumRow_18++;

/**
 * [tGreenplumRow_18 main ] stop
 */
	
	/**
	 * [tGreenplumRow_18 end ] start
	 */

	

	
	
	currentComponent="tGreenplumRow_18";

	

	
	stmt_tGreenplumRow_18.close();	

 
                if(log.isDebugEnabled())
            log.debug("tGreenplumRow_18 - "  + ("Done.") );

ok_Hash.put("tGreenplumRow_18", true);
end_Hash.put("tGreenplumRow_18", System.currentTimeMillis());

				if(execStat){   
   	 				runStat.updateStatOnConnection("OnComponentOk18", 0, "ok");
				}
				tGreenplumRow_17Process(globalMap);



/**
 * [tGreenplumRow_18 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage());
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tGreenplumRow_18 finally ] start
	 */

	

	
	
	currentComponent="tGreenplumRow_18";

	

 



/**
 * [tGreenplumRow_18 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tGreenplumRow_18_SUBPROCESS_STATE", 1);
	}
	

public void tGreenplumRow_17Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tGreenplumRow_17_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tGreenplumRow_17 begin ] start
	 */

	

	
		
		ok_Hash.put("tGreenplumRow_17", false);
		start_Hash.put("tGreenplumRow_17", System.currentTimeMillis());
		
	
	currentComponent="tGreenplumRow_17";

	
		int tos_count_tGreenplumRow_17 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tGreenplumRow_17 - "  + ("Start to work.") );
    	class BytesLimit65535_tGreenplumRow_17{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tGreenplumRow_17 = new StringBuilder();
            log4jParamters_tGreenplumRow_17.append("Parameters:");
                    log4jParamters_tGreenplumRow_17.append("USE_EXISTING_CONNECTION" + " = " + "true");
                log4jParamters_tGreenplumRow_17.append(" | ");
                    log4jParamters_tGreenplumRow_17.append("CONNECTION" + " = " + "tGreenplumConnection_2");
                log4jParamters_tGreenplumRow_17.append(" | ");
                    log4jParamters_tGreenplumRow_17.append("QUERYSTORE" + " = " + "\"\"");
                log4jParamters_tGreenplumRow_17.append(" | ");
                    log4jParamters_tGreenplumRow_17.append("QUERY" + " = " + "\" drop table IF EXISTS increments.\"+((String)globalMap.get(\"row7.target_table_name_incr\"))+\";\"+  \"create table increments.\"+((String)globalMap.get(\"row7.target_table_name_incr\"))+\" ( \"+  ((String)globalMap.get(\"columnlist_select\") ) +\" )  \"+  \" as select \"+((String)globalMap.get(\"columnlist_select\") ) +   \" from \"+((String)globalMap.get(\"row7.target_schema_orig\"))+\".\"+((String)globalMap.get(\"row7.log_table_name\"))+\" where 1=2;   \"  ");
                log4jParamters_tGreenplumRow_17.append(" | ");
                    log4jParamters_tGreenplumRow_17.append("DIE_ON_ERROR" + " = " + "false");
                log4jParamters_tGreenplumRow_17.append(" | ");
                    log4jParamters_tGreenplumRow_17.append("PROPAGATE_RECORD_SET" + " = " + "false");
                log4jParamters_tGreenplumRow_17.append(" | ");
                    log4jParamters_tGreenplumRow_17.append("USE_PREPAREDSTATEMENT" + " = " + "false");
                log4jParamters_tGreenplumRow_17.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tGreenplumRow_17 - "  + (log4jParamters_tGreenplumRow_17) );
    		}
    	}
    	
        new BytesLimit65535_tGreenplumRow_17().limitLog4jByte();

	java.sql.Connection conn_tGreenplumRow_17 = null;
	String query_tGreenplumRow_17 = "";
	boolean whetherReject_tGreenplumRow_17 = false;
				conn_tGreenplumRow_17 = (java.sql.Connection)globalMap.get("conn_tGreenplumConnection_2");
			
				if(conn_tGreenplumRow_17 != null) {
					if(conn_tGreenplumRow_17.getMetaData() != null) {
						
						log.debug("tGreenplumRow_17 - Uses an existing connection with username '" + conn_tGreenplumRow_17.getMetaData().getUserName() + "'. Connection URL: " + conn_tGreenplumRow_17.getMetaData().getURL() + ".");
						
					}
				}
			
		java.sql.Statement stmt_tGreenplumRow_17 = conn_tGreenplumRow_17.createStatement();
	

 



/**
 * [tGreenplumRow_17 begin ] stop
 */
	
	/**
	 * [tGreenplumRow_17 main ] start
	 */

	

	
	
	currentComponent="tGreenplumRow_17";

	

	    		log.debug("tGreenplumRow_17 - Executing the query: '" + " drop table IF EXISTS increments."+((String)globalMap.get("row7.target_table_name_incr"))+";"+  "create table increments."+((String)globalMap.get("row7.target_table_name_incr"))+" ( "+  ((String)globalMap.get("columnlist_select") ) +" )  "+  " as select "+((String)globalMap.get("columnlist_select") ) +   " from "+((String)globalMap.get("row7.target_schema_orig"))+"."+((String)globalMap.get("row7.log_table_name"))+" where 1=2;   "   + "'.");
			
query_tGreenplumRow_17 = " drop table IF EXISTS increments."+((String)globalMap.get("row7.target_table_name_incr"))+";"+
"create table increments."+((String)globalMap.get("row7.target_table_name_incr"))+" ( "+
((String)globalMap.get("columnlist_select") ) +" )  "+
" as select "+((String)globalMap.get("columnlist_select") ) +
 " from "+((String)globalMap.get("row7.target_schema_orig"))+"."+((String)globalMap.get("row7.log_table_name"))+" where 1=2;\n "
;
whetherReject_tGreenplumRow_17 = false;
globalMap.put("tGreenplumRow_17_QUERY",query_tGreenplumRow_17);
try {
		stmt_tGreenplumRow_17.execute(query_tGreenplumRow_17);
		
	    		log.info("tGreenplumRow_17 - Execute the query: '" + " drop table IF EXISTS increments."+((String)globalMap.get("row7.target_table_name_incr"))+";"+
"create table increments."+((String)globalMap.get("row7.target_table_name_incr"))+" ( "+
((String)globalMap.get("columnlist_select") ) +" )  "+
" as select "+((String)globalMap.get("columnlist_select") ) +
 " from "+((String)globalMap.get("row7.target_schema_orig"))+"."+((String)globalMap.get("row7.log_table_name"))+" where 1=2;\n "
 + "' has finished.");
			
	} catch (java.lang.Exception e) {
		whetherReject_tGreenplumRow_17 = true;
		
				log.error("tGreenplumRow_17 - " + e.getMessage());
			
				System.err.print(e.getMessage());
				
	}
	
	if(!whetherReject_tGreenplumRow_17) {
		
	}
	

 


	tos_count_tGreenplumRow_17++;

/**
 * [tGreenplumRow_17 main ] stop
 */
	
	/**
	 * [tGreenplumRow_17 end ] start
	 */

	

	
	
	currentComponent="tGreenplumRow_17";

	

	
	stmt_tGreenplumRow_17.close();	

 
                if(log.isDebugEnabled())
            log.debug("tGreenplumRow_17 - "  + ("Done.") );

ok_Hash.put("tGreenplumRow_17", true);
end_Hash.put("tGreenplumRow_17", System.currentTimeMillis());




/**
 * [tGreenplumRow_17 end ] stop
 */
				}//end the resume

				
				    			if(resumeEntryMethodName == null || globalResumeTicket){
				    				resumeUtil.addLog("CHECKPOINT", "CONNECTION:SUBJOB_OK:tGreenplumRow_17:OnSubjobOk", "", Thread.currentThread().getId() + "", "", "", "", "", "");
								}	    				    			
					    	
								if(execStat){    	
									runStat.updateStatOnConnection("OnSubjobOk59", 0, "ok");
								} 
							
							tGreenplumRow_5Process(globalMap); 
						



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage());
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tGreenplumRow_17 finally ] start
	 */

	

	
	
	currentComponent="tGreenplumRow_17";

	

 



/**
 * [tGreenplumRow_17 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tGreenplumRow_17_SUBPROCESS_STATE", 1);
	}
	

public void tGreenplumRow_5Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tGreenplumRow_5_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tGreenplumRow_5 begin ] start
	 */

	

	
		
		ok_Hash.put("tGreenplumRow_5", false);
		start_Hash.put("tGreenplumRow_5", System.currentTimeMillis());
		
	
	currentComponent="tGreenplumRow_5";

	
		int tos_count_tGreenplumRow_5 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tGreenplumRow_5 - "  + ("Start to work.") );
    	class BytesLimit65535_tGreenplumRow_5{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tGreenplumRow_5 = new StringBuilder();
            log4jParamters_tGreenplumRow_5.append("Parameters:");
                    log4jParamters_tGreenplumRow_5.append("USE_EXISTING_CONNECTION" + " = " + "true");
                log4jParamters_tGreenplumRow_5.append(" | ");
                    log4jParamters_tGreenplumRow_5.append("CONNECTION" + " = " + "tGreenplumConnection_2");
                log4jParamters_tGreenplumRow_5.append(" | ");
                    log4jParamters_tGreenplumRow_5.append("QUERYSTORE" + " = " + "\"\"");
                log4jParamters_tGreenplumRow_5.append(" | ");
                    log4jParamters_tGreenplumRow_5.append("QUERY" + " = " + "\"  drop external table IF EXISTS increments.\"+((String)globalMap.get(\"row7.log_table_name\"))+  \"_ext ;   create external table increments.\"+  ((String)globalMap.get(\"row7.log_table_name\"))+  \"_ext  ( LIKE \"+((String)globalMap.get(\"row7.target_schema_orig\"))+\".\"+((String)globalMap.get(\"row7.log_table_name\"))+  \" ) LOCATION ('gpfdist://\"+context.ETL_LOCALHOSTNAME+\":\"+((String)globalMap.get(\"port\"))+\"/\"+((String)globalMap.get(\"row7.log_table_name\")).replace(\"\\\"\",\"\").replace(\"#\",\"__hash__\").replace(\"$\",\"__dollar__\")+\".txt\"+\"'  )  FORMAT 'TEXT' (delimiter E'\\\\013' null '\\\\\\\\N' escape '\\\\\\\\' )   encoding 'UTF8' ;\" +  \"insert into increments\"+\".\"+((String)globalMap.get(\"row7.target_table_name_incr\"))+\" ( \"+  ((String)globalMap.get(\"columnlist_select\") ) +\" )  \"+  \"select \"+((String)globalMap.get(\"columnlist_select\") ) + \" from   increments.\"+((String)globalMap.get(\"row7.log_table_name\"))+\"_ext  ;   drop external table increments.\"+((String)globalMap.get(\"row7.log_table_name\"))+\"_ext ;     \"");
                log4jParamters_tGreenplumRow_5.append(" | ");
                    log4jParamters_tGreenplumRow_5.append("DIE_ON_ERROR" + " = " + "true");
                log4jParamters_tGreenplumRow_5.append(" | ");
                    log4jParamters_tGreenplumRow_5.append("PROPAGATE_RECORD_SET" + " = " + "false");
                log4jParamters_tGreenplumRow_5.append(" | ");
                    log4jParamters_tGreenplumRow_5.append("USE_PREPAREDSTATEMENT" + " = " + "false");
                log4jParamters_tGreenplumRow_5.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tGreenplumRow_5 - "  + (log4jParamters_tGreenplumRow_5) );
    		}
    	}
    	
        new BytesLimit65535_tGreenplumRow_5().limitLog4jByte();

	java.sql.Connection conn_tGreenplumRow_5 = null;
	String query_tGreenplumRow_5 = "";
	boolean whetherReject_tGreenplumRow_5 = false;
				conn_tGreenplumRow_5 = (java.sql.Connection)globalMap.get("conn_tGreenplumConnection_2");
			
				if(conn_tGreenplumRow_5 != null) {
					if(conn_tGreenplumRow_5.getMetaData() != null) {
						
						log.debug("tGreenplumRow_5 - Uses an existing connection with username '" + conn_tGreenplumRow_5.getMetaData().getUserName() + "'. Connection URL: " + conn_tGreenplumRow_5.getMetaData().getURL() + ".");
						
					}
				}
			
		java.sql.Statement stmt_tGreenplumRow_5 = conn_tGreenplumRow_5.createStatement();
	

 



/**
 * [tGreenplumRow_5 begin ] stop
 */
	
	/**
	 * [tGreenplumRow_5 main ] start
	 */

	

	
	
	currentComponent="tGreenplumRow_5";

	

	    		log.debug("tGreenplumRow_5 - Executing the query: '" + "  drop external table IF EXISTS increments."+((String)globalMap.get("row7.log_table_name"))+  "_ext ;   create external table increments."+  ((String)globalMap.get("row7.log_table_name"))+  "_ext  ( LIKE "+((String)globalMap.get("row7.target_schema_orig"))+"."+((String)globalMap.get("row7.log_table_name"))+  " ) LOCATION ('gpfdist://"+context.ETL_LOCALHOSTNAME+":"+((String)globalMap.get("port"))+"/"+((String)globalMap.get("row7.log_table_name")).replace("\"","").replace("#","__hash__").replace("$","__dollar__")+".txt"+"'  )  FORMAT 'TEXT' (delimiter E'\\013' null '\\\\N' escape '\\\\' )   encoding 'UTF8' ;" +  "insert into increments"+"."+((String)globalMap.get("row7.target_table_name_incr"))+" ( "+  ((String)globalMap.get("columnlist_select") ) +" )  "+  "select "+((String)globalMap.get("columnlist_select") ) + " from   increments."+((String)globalMap.get("row7.log_table_name"))+"_ext  ;   drop external table increments."+((String)globalMap.get("row7.log_table_name"))+"_ext ;     " + "'.");
			
query_tGreenplumRow_5 = "\ndrop external table IF EXISTS increments."+((String)globalMap.get("row7.log_table_name"))+
"_ext ; \ncreate external table increments."+
((String)globalMap.get("row7.log_table_name"))+
"_ext  ( LIKE "+((String)globalMap.get("row7.target_schema_orig"))+"."+((String)globalMap.get("row7.log_table_name"))+
" ) LOCATION ('gpfdist://"+context.ETL_LOCALHOSTNAME+":"+((String)globalMap.get("port"))+"/"+((String)globalMap.get("row7.log_table_name")).replace("\"","").replace("#","__hash__").replace("$","__dollar__")+".txt"+"'\n)\nFORMAT 'TEXT' (delimiter E'\\013' null '\\\\N' escape '\\\\' ) \nencoding 'UTF8' ;" +
"insert into increments"+"."+((String)globalMap.get("row7.target_table_name_incr"))+" ( "+
((String)globalMap.get("columnlist_select") ) +" )  "+
"select "+((String)globalMap.get("columnlist_select") ) + " from \nincrements."+((String)globalMap.get("row7.log_table_name"))+"_ext  ; \ndrop external table increments."+((String)globalMap.get("row7.log_table_name"))+"_ext ; \n\n";
whetherReject_tGreenplumRow_5 = false;
globalMap.put("tGreenplumRow_5_QUERY",query_tGreenplumRow_5);
try {
		stmt_tGreenplumRow_5.execute(query_tGreenplumRow_5);
		
	    		log.info("tGreenplumRow_5 - Execute the query: '" + "\ndrop external table IF EXISTS increments."+((String)globalMap.get("row7.log_table_name"))+
"_ext ; \ncreate external table increments."+
((String)globalMap.get("row7.log_table_name"))+
"_ext  ( LIKE "+((String)globalMap.get("row7.target_schema_orig"))+"."+((String)globalMap.get("row7.log_table_name"))+
" ) LOCATION ('gpfdist://"+context.ETL_LOCALHOSTNAME+":"+((String)globalMap.get("port"))+"/"+((String)globalMap.get("row7.log_table_name")).replace("\"","").replace("#","__hash__").replace("$","__dollar__")+".txt"+"'\n)\nFORMAT 'TEXT' (delimiter E'\\013' null '\\\\N' escape '\\\\' ) \nencoding 'UTF8' ;" +
"insert into increments"+"."+((String)globalMap.get("row7.target_table_name_incr"))+" ( "+
((String)globalMap.get("columnlist_select") ) +" )  "+
"select "+((String)globalMap.get("columnlist_select") ) + " from \nincrements."+((String)globalMap.get("row7.log_table_name"))+"_ext  ; \ndrop external table increments."+((String)globalMap.get("row7.log_table_name"))+"_ext ; \n\n" + "' has finished.");
			
	} catch (java.lang.Exception e) {
		whetherReject_tGreenplumRow_5 = true;
		
			throw(e);
			
	}
	
	if(!whetherReject_tGreenplumRow_5) {
		
	}
	

 


	tos_count_tGreenplumRow_5++;

/**
 * [tGreenplumRow_5 main ] stop
 */
	
	/**
	 * [tGreenplumRow_5 end ] start
	 */

	

	
	
	currentComponent="tGreenplumRow_5";

	

	
	stmt_tGreenplumRow_5.close();	

 
                if(log.isDebugEnabled())
            log.debug("tGreenplumRow_5 - "  + ("Done.") );

ok_Hash.put("tGreenplumRow_5", true);
end_Hash.put("tGreenplumRow_5", System.currentTimeMillis());

				if(execStat){   
   	 				runStat.updateStatOnConnection("OnComponentOk24", 0, "ok");
				}
				tJava_22Process(globalMap);



/**
 * [tGreenplumRow_5 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage());
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tGreenplumRow_5 finally ] start
	 */

	

	
	
	currentComponent="tGreenplumRow_5";

	

 



/**
 * [tGreenplumRow_5 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tGreenplumRow_5_SUBPROCESS_STATE", 1);
	}
	

public void tJava_22Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tJava_22_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tJava_22 begin ] start
	 */

	

	
		
		ok_Hash.put("tJava_22", false);
		start_Hash.put("tJava_22", System.currentTimeMillis());
		
	
	currentComponent="tJava_22";

	
		int tos_count_tJava_22 = 0;
		
    	class BytesLimit65535_tJava_22{
    		public void limitLog4jByte() throws Exception{
    			
    		}
    	}
    	
        new BytesLimit65535_tJava_22().limitLog4jByte();


String strIncrementRollingCall=(String)globalMap.get("increment_rolling_call_template");
strIncrementRollingCall=strIncrementRollingCall.replace("#TARGET_SCHEMA", "'"+(String)globalMap.get("row7.target_schema_orig")+"'");
strIncrementRollingCall=strIncrementRollingCall.replace("#TARGET_TABLE_NAME", "'"+(String)globalMap.get("row7.log_table_name")+"'");
globalMap.put("increment_rolling_call", strIncrementRollingCall);

//System.out.println("******************************");
//globalMap.put("now",new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(TalendDate.getCurrentDate()).toString());
//globalMap.put("now_sql","TO_TIMESTAMP('" + ((String)globalMap.get("now")) + "', 'YYYY-MM-DD HH24:MI:SS')::TIMESTAMP WITH TIME ZONE ");
//System.out.println((String)globalMap.get("increment_rolling_call"));
 



/**
 * [tJava_22 begin ] stop
 */
	
	/**
	 * [tJava_22 main ] start
	 */

	

	
	
	currentComponent="tJava_22";

	

 


	tos_count_tJava_22++;

/**
 * [tJava_22 main ] stop
 */
	
	/**
	 * [tJava_22 end ] start
	 */

	

	
	
	currentComponent="tJava_22";

	

 

ok_Hash.put("tJava_22", true);
end_Hash.put("tJava_22", System.currentTimeMillis());

				if(execStat){   
   	 				runStat.updateStatOnConnection("OnComponentOk25", 0, "ok");
				}
				tGreenplumInput_9Process(globalMap);



/**
 * [tJava_22 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage());
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tJava_22 finally ] start
	 */

	

	
	
	currentComponent="tJava_22";

	

 



/**
 * [tJava_22 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tJava_22_SUBPROCESS_STATE", 1);
	}
	


public static class row19Struct implements routines.system.IPersistableRow<row19Struct> {
    final static byte[] commonByteArrayLock_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Prod2Dev_with_GP_FDIST_child = new byte[0];
    static byte[] commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Prod2Dev_with_GP_FDIST_child = new byte[0];

	
			    public Boolean not_empty;

				public Boolean getNot_empty () {
					return this.not_empty;
				}
				



    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Prod2Dev_with_GP_FDIST_child) {

        	try {

        		int length = 0;
		
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.not_empty = null;
           				} else {
           			    	this.not_empty = dis.readBoolean();
           				}
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// Boolean
				
						if(this.not_empty == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeBoolean(this.not_empty);
		            	}
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("not_empty="+String.valueOf(not_empty));
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				if(not_empty == null){
        					sb.append("<null>");
        				}else{
            				sb.append(not_empty);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(row19Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}
public void tGreenplumInput_9Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tGreenplumInput_9_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;



		row19Struct row19 = new row19Struct();




	
	/**
	 * [tJavaRow_11 begin ] start
	 */

	

	
		
		ok_Hash.put("tJavaRow_11", false);
		start_Hash.put("tJavaRow_11", System.currentTimeMillis());
		
	
	currentComponent="tJavaRow_11";

	
			if (execStat) {
				if(resourceMap.get("inIterateVComp") == null){
					
						runStat.updateStatOnConnection("row19" + iterateId, 0, 0);
					
				}
			} 

		
		int tos_count_tJavaRow_11 = 0;
		
    	class BytesLimit65535_tJavaRow_11{
    		public void limitLog4jByte() throws Exception{
    			
    		}
    	}
    	
        new BytesLimit65535_tJavaRow_11().limitLog4jByte();

int nb_line_tJavaRow_11 = 0;

 



/**
 * [tJavaRow_11 begin ] stop
 */



	
	/**
	 * [tGreenplumInput_9 begin ] start
	 */

	

	
		
		ok_Hash.put("tGreenplumInput_9", false);
		start_Hash.put("tGreenplumInput_9", System.currentTimeMillis());
		
	
	currentComponent="tGreenplumInput_9";

	
		int tos_count_tGreenplumInput_9 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tGreenplumInput_9 - "  + ("Start to work.") );
    	class BytesLimit65535_tGreenplumInput_9{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tGreenplumInput_9 = new StringBuilder();
            log4jParamters_tGreenplumInput_9.append("Parameters:");
                    log4jParamters_tGreenplumInput_9.append("USE_EXISTING_CONNECTION" + " = " + "true");
                log4jParamters_tGreenplumInput_9.append(" | ");
                    log4jParamters_tGreenplumInput_9.append("CONNECTION" + " = " + "tGreenplumConnection_2");
                log4jParamters_tGreenplumInput_9.append(" | ");
                    log4jParamters_tGreenplumInput_9.append("TABLE" + " = " + "\"\"");
                log4jParamters_tGreenplumInput_9.append(" | ");
                    log4jParamters_tGreenplumInput_9.append("QUERYSTORE" + " = " + "\"\"");
                log4jParamters_tGreenplumInput_9.append(" | ");
                    log4jParamters_tGreenplumInput_9.append("QUERY" + " = " + "\" select exists ( select 'true'  from increments\"+\".\"+((String)globalMap.get(\"row7.target_table_name_incr\"))+\" limit 1 ) as not_empty ;\"      ");
                log4jParamters_tGreenplumInput_9.append(" | ");
                    log4jParamters_tGreenplumInput_9.append("USE_CURSOR" + " = " + "false");
                log4jParamters_tGreenplumInput_9.append(" | ");
                    log4jParamters_tGreenplumInput_9.append("TRIM_ALL_COLUMN" + " = " + "false");
                log4jParamters_tGreenplumInput_9.append(" | ");
                    log4jParamters_tGreenplumInput_9.append("TRIM_COLUMN" + " = " + "[{TRIM="+("false")+", SCHEMA_COLUMN="+("not_empty")+"}]");
                log4jParamters_tGreenplumInput_9.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tGreenplumInput_9 - "  + (log4jParamters_tGreenplumInput_9) );
    		}
    	}
    	
        new BytesLimit65535_tGreenplumInput_9().limitLog4jByte();
	
    
	
		    int nb_line_tGreenplumInput_9 = 0;
		    java.sql.Connection conn_tGreenplumInput_9 = null;
		        conn_tGreenplumInput_9 = (java.sql.Connection)globalMap.get("conn_tGreenplumConnection_2");
				
				if(conn_tGreenplumInput_9 != null) {
					if(conn_tGreenplumInput_9.getMetaData() != null) {
						
						log.debug("tGreenplumInput_9 - Uses an existing connection with username '" + conn_tGreenplumInput_9.getMetaData().getUserName() + "'. Connection URL: " + conn_tGreenplumInput_9.getMetaData().getURL() + ".");
						
					}
				}
			
		    
			java.sql.Statement stmt_tGreenplumInput_9 = conn_tGreenplumInput_9.createStatement();

		    String dbquery_tGreenplumInput_9 = " select exists ( select 'true'  from increments"+"."+((String)globalMap.get("row7.target_table_name_incr"))+" limit 1 ) as not_empty ;"


;
			
                log.debug("tGreenplumInput_9 - Executing the query: '"+dbquery_tGreenplumInput_9+"'.");
			

                       globalMap.put("tGreenplumInput_9_QUERY",dbquery_tGreenplumInput_9);

		    java.sql.ResultSet rs_tGreenplumInput_9 = null;
		try{
		    rs_tGreenplumInput_9 = stmt_tGreenplumInput_9.executeQuery(dbquery_tGreenplumInput_9);
		    java.sql.ResultSetMetaData rsmd_tGreenplumInput_9 = rs_tGreenplumInput_9.getMetaData();
		    int colQtyInRs_tGreenplumInput_9 = rsmd_tGreenplumInput_9.getColumnCount();

		    String tmpContent_tGreenplumInput_9 = null;
		    
		    
		    	log.debug("tGreenplumInput_9 - Retrieving records from the database.");
		    
		    while (rs_tGreenplumInput_9.next()) {
		        nb_line_tGreenplumInput_9++;
		        
							if(colQtyInRs_tGreenplumInput_9 < 1) {
								row19.not_empty = null;
							} else {
	                         		
            if(rs_tGreenplumInput_9.getObject(1) != null) {
                row19.not_empty = rs_tGreenplumInput_9.getBoolean(1);
            } else {
                    row19.not_empty = null;
            }
		                    }
					
						log.debug("tGreenplumInput_9 - Retrieving the record " + nb_line_tGreenplumInput_9 + ".");
					


 



/**
 * [tGreenplumInput_9 begin ] stop
 */
	
	/**
	 * [tGreenplumInput_9 main ] start
	 */

	

	
	
	currentComponent="tGreenplumInput_9";

	

 


	tos_count_tGreenplumInput_9++;

/**
 * [tGreenplumInput_9 main ] stop
 */

	
	/**
	 * [tJavaRow_11 main ] start
	 */

	

	
	
	currentComponent="tJavaRow_11";

	

			//row19
			//row19


			
				if(execStat){
					runStat.updateStatOnConnection("row19"+iterateId,1, 1);
				} 
			

		
    			if(log.isTraceEnabled()){
    				log.trace("row19 - " + (row19==null? "": row19.toLogString()));
    			}
    		

    if ((boolean)row19.not_empty) 
{
	globalMap.put("not_empty","true");
}else{
	globalMap.put("not_empty","false");

}

System.out.println("There are incremental records:");
System.out.println((String)globalMap.get("not_empty"));



    nb_line_tJavaRow_11++;   

 


	tos_count_tJavaRow_11++;

/**
 * [tJavaRow_11 main ] stop
 */



	
	/**
	 * [tGreenplumInput_9 end ] start
	 */

	

	
	
	currentComponent="tGreenplumInput_9";

	

	}
}finally{
	stmt_tGreenplumInput_9.close();

}
globalMap.put("tGreenplumInput_9_NB_LINE",nb_line_tGreenplumInput_9);
	    		log.debug("tGreenplumInput_9 - Retrieved records count: "+nb_line_tGreenplumInput_9 + " .");
			

 
                if(log.isDebugEnabled())
            log.debug("tGreenplumInput_9 - "  + ("Done.") );

ok_Hash.put("tGreenplumInput_9", true);
end_Hash.put("tGreenplumInput_9", System.currentTimeMillis());




/**
 * [tGreenplumInput_9 end ] stop
 */

	
	/**
	 * [tJavaRow_11 end ] start
	 */

	

	
	
	currentComponent="tJavaRow_11";

	

globalMap.put("tJavaRow_11_NB_LINE",nb_line_tJavaRow_11);
			if(execStat){
				if(resourceMap.get("inIterateVComp") == null || !((Boolean)resourceMap.get("inIterateVComp"))){
			 		runStat.updateStatOnConnection("row19"+iterateId,2, 0); 
			 	}
			}
		
 

ok_Hash.put("tJavaRow_11", true);
end_Hash.put("tJavaRow_11", System.currentTimeMillis());

   			if (!((String)globalMap.get("not_empty")).equals("false")) {
   				
					if(execStat){   
   	 					runStat.updateStatOnConnection("If51", 0, "true");
					}
				
    			tGreenplumInput_6Process(globalMap);
   			}

			   
   				else{
					if(execStat){   
   	 					runStat.updateStatOnConnection("If51", 0, "false");
					}   	 
   				}
   			if (((String)globalMap.get("not_empty")).equals("false")) {
   				
					if(execStat){   
   	 					runStat.updateStatOnConnection("If43", 0, "true");
					}
				
    			tGreenplumClose_3Process(globalMap);
   			}

			   
   				else{
					if(execStat){   
   	 					runStat.updateStatOnConnection("If43", 0, "false");
					}   	 
   				}



/**
 * [tJavaRow_11 end ] stop
 */



				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage());
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tGreenplumInput_9 finally ] start
	 */

	

	
	
	currentComponent="tGreenplumInput_9";

	

 



/**
 * [tGreenplumInput_9 finally ] stop
 */

	
	/**
	 * [tJavaRow_11 finally ] start
	 */

	

	
	
	currentComponent="tJavaRow_11";

	

 



/**
 * [tJavaRow_11 finally ] stop
 */



				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tGreenplumInput_9_SUBPROCESS_STATE", 1);
	}
	


public static class row6Struct implements routines.system.IPersistableRow<row6Struct> {
    final static byte[] commonByteArrayLock_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Prod2Dev_with_GP_FDIST_child = new byte[0];
    static byte[] commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Prod2Dev_with_GP_FDIST_child = new byte[0];

	
			    public String result;

				public String getResult () {
					return this.result;
				}
				



	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Prod2Dev_with_GP_FDIST_child.length) {
				if(length < 1024 && commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Prod2Dev_with_GP_FDIST_child.length == 0) {
   					commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Prod2Dev_with_GP_FDIST_child = new byte[1024];
				} else {
   					commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Prod2Dev_with_GP_FDIST_child = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Prod2Dev_with_GP_FDIST_child, 0, length);
			strReturn = new String(commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Prod2Dev_with_GP_FDIST_child, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Prod2Dev_with_GP_FDIST_child) {

        	try {

        		int length = 0;
		
					this.result = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// String
				
						writeString(this.result,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("result="+result);
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				if(result == null){
        					sb.append("<null>");
        				}else{
            				sb.append(result);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(row6Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}
public void tGreenplumInput_6Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tGreenplumInput_6_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;



		row6Struct row6 = new row6Struct();




	
	/**
	 * [tJavaRow_6 begin ] start
	 */

	

	
		
		ok_Hash.put("tJavaRow_6", false);
		start_Hash.put("tJavaRow_6", System.currentTimeMillis());
		
	
	currentComponent="tJavaRow_6";

	
			if (execStat) {
				if(resourceMap.get("inIterateVComp") == null){
					
						runStat.updateStatOnConnection("row6" + iterateId, 0, 0);
					
				}
			} 

		
		int tos_count_tJavaRow_6 = 0;
		
    	class BytesLimit65535_tJavaRow_6{
    		public void limitLog4jByte() throws Exception{
    			
    		}
    	}
    	
        new BytesLimit65535_tJavaRow_6().limitLog4jByte();

int nb_line_tJavaRow_6 = 0;

 



/**
 * [tJavaRow_6 begin ] stop
 */



	
	/**
	 * [tGreenplumInput_6 begin ] start
	 */

	

	
		
		ok_Hash.put("tGreenplumInput_6", false);
		start_Hash.put("tGreenplumInput_6", System.currentTimeMillis());
		
	
	currentComponent="tGreenplumInput_6";

	
		int tos_count_tGreenplumInput_6 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tGreenplumInput_6 - "  + ("Start to work.") );
    	class BytesLimit65535_tGreenplumInput_6{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tGreenplumInput_6 = new StringBuilder();
            log4jParamters_tGreenplumInput_6.append("Parameters:");
                    log4jParamters_tGreenplumInput_6.append("USE_EXISTING_CONNECTION" + " = " + "true");
                log4jParamters_tGreenplumInput_6.append(" | ");
                    log4jParamters_tGreenplumInput_6.append("CONNECTION" + " = " + "tGreenplumConnection_2");
                log4jParamters_tGreenplumInput_6.append(" | ");
                    log4jParamters_tGreenplumInput_6.append("TABLE" + " = " + "\"\"");
                log4jParamters_tGreenplumInput_6.append(" | ");
                    log4jParamters_tGreenplumInput_6.append("QUERYSTORE" + " = " + "\"\"");
                log4jParamters_tGreenplumInput_6.append(" | ");
                    log4jParamters_tGreenplumInput_6.append("QUERY" + " = " + "(String)globalMap.get(\"increment_rolling_call\")");
                log4jParamters_tGreenplumInput_6.append(" | ");
                    log4jParamters_tGreenplumInput_6.append("USE_CURSOR" + " = " + "false");
                log4jParamters_tGreenplumInput_6.append(" | ");
                    log4jParamters_tGreenplumInput_6.append("TRIM_ALL_COLUMN" + " = " + "false");
                log4jParamters_tGreenplumInput_6.append(" | ");
                    log4jParamters_tGreenplumInput_6.append("TRIM_COLUMN" + " = " + "[{TRIM="+("false")+", SCHEMA_COLUMN="+("result")+"}]");
                log4jParamters_tGreenplumInput_6.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tGreenplumInput_6 - "  + (log4jParamters_tGreenplumInput_6) );
    		}
    	}
    	
        new BytesLimit65535_tGreenplumInput_6().limitLog4jByte();
	
    
	
		    int nb_line_tGreenplumInput_6 = 0;
		    java.sql.Connection conn_tGreenplumInput_6 = null;
		        conn_tGreenplumInput_6 = (java.sql.Connection)globalMap.get("conn_tGreenplumConnection_2");
				
				if(conn_tGreenplumInput_6 != null) {
					if(conn_tGreenplumInput_6.getMetaData() != null) {
						
						log.debug("tGreenplumInput_6 - Uses an existing connection with username '" + conn_tGreenplumInput_6.getMetaData().getUserName() + "'. Connection URL: " + conn_tGreenplumInput_6.getMetaData().getURL() + ".");
						
					}
				}
			
		    
			java.sql.Statement stmt_tGreenplumInput_6 = conn_tGreenplumInput_6.createStatement();

		    String dbquery_tGreenplumInput_6 = (String)globalMap.get("increment_rolling_call");
			
                log.debug("tGreenplumInput_6 - Executing the query: '"+dbquery_tGreenplumInput_6+"'.");
			

                       globalMap.put("tGreenplumInput_6_QUERY",dbquery_tGreenplumInput_6);

		    java.sql.ResultSet rs_tGreenplumInput_6 = null;
		try{
		    rs_tGreenplumInput_6 = stmt_tGreenplumInput_6.executeQuery(dbquery_tGreenplumInput_6);
		    java.sql.ResultSetMetaData rsmd_tGreenplumInput_6 = rs_tGreenplumInput_6.getMetaData();
		    int colQtyInRs_tGreenplumInput_6 = rsmd_tGreenplumInput_6.getColumnCount();

		    String tmpContent_tGreenplumInput_6 = null;
		    
		    
		    	log.debug("tGreenplumInput_6 - Retrieving records from the database.");
		    
		    while (rs_tGreenplumInput_6.next()) {
		        nb_line_tGreenplumInput_6++;
		        
							if(colQtyInRs_tGreenplumInput_6 < 1) {
								row6.result = null;
							} else {
	                         		
        	row6.result = routines.system.JDBCUtil.getString(rs_tGreenplumInput_6, 1, false);
		                    }
					
						log.debug("tGreenplumInput_6 - Retrieving the record " + nb_line_tGreenplumInput_6 + ".");
					


 



/**
 * [tGreenplumInput_6 begin ] stop
 */
	
	/**
	 * [tGreenplumInput_6 main ] start
	 */

	

	
	
	currentComponent="tGreenplumInput_6";

	

 


	tos_count_tGreenplumInput_6++;

/**
 * [tGreenplumInput_6 main ] stop
 */

	
	/**
	 * [tJavaRow_6 main ] start
	 */

	

	
	
	currentComponent="tJavaRow_6";

	

			//row6
			//row6


			
				if(execStat){
					runStat.updateStatOnConnection("row6"+iterateId,1, 1);
				} 
			

		
    			if(log.isTraceEnabled()){
    				log.trace("row6 - " + (row6==null? "": row6.toLogString()));
    			}
    		

    String[] parts = ((String)row6.result).split("\\|");
String part1 = (parts[0]).trim();
String part2 = (parts[1]).trim();
String part3 = (parts[2]).trim();
String part4 = (parts[3]).trim();
String part5 = (parts[4]).trim();
String part6 = (parts[5]).trim();
String part7 = (parts[6]).trim();
String part8 = (parts[7]).trim();


context.LOG_NO_OF_INSERTS=Integer.parseInt(part1);
context.LOG_NO_OF_UPDATES=Integer.parseInt(part2);
context.LOG_NO_OF_DELETES=Integer.parseInt(part3);
context.LOG_NO_OF_ERRORS=Integer.parseInt(part4);
//context.LOG_SOURCE_ROW_COUNT=Integer.parseInt(part5);
context.LOG_SOURCE_ROW_COUNT=(Integer)globalMap.get("cnt");
context.LOG_TARGET_ROW_COUNT=Integer.parseInt(part6);
context.LOG_STATUS=(String)part7;
//if ((String)part7.equals("Update")==true) context.LOG_STATUS="Finish"; else context.LOG_STATUS=(String)part7;
context.LOG_MESSAGE=(String)part8;
context.LOG_ERROR_CATEGORY="NULL";

//if (context.LOG_PLANT_NAME.equals("")==true) {
//  context.LOG_PLANT_NAME="Grove City";
//};




System.out.println("**********");
System.out.println(((String)row6.result));
System.out.println("**********");
System.out.println(context.LOG_NO_OF_INSERTS);
System.out.println(context.LOG_NO_OF_UPDATES);
System.out.println(context.LOG_NO_OF_DELETES);
System.out.println(context.LOG_NO_OF_ERRORS);
System.out.println(context.LOG_SOURCE_ROW_COUNT);
System.out.println(context.LOG_TARGET_ROW_COUNT);
System.out.println("**********");

// code sample:
//
// multiply by 2 the row identifier
// output_row.id = row6.id * 2;
//
// lowercase the name
// output_row.name = row6.name.toLowerCase();
//System.out.println(((String)globalMap.get("tGreenplumRow_1_QUERY")));
//System.out.println(((String)globalMap.get("tGreenplumRow_1_ERROR_MESSAGE")));
//System.out.println(part1);
//System.out.println(part2);
//System.out.println(part3);
//System.out.println(part4);
//System.out.println(part5);
//System.out.println(part6);
//System.out.println(part7);

    nb_line_tJavaRow_6++;   

 


	tos_count_tJavaRow_6++;

/**
 * [tJavaRow_6 main ] stop
 */



	
	/**
	 * [tGreenplumInput_6 end ] start
	 */

	

	
	
	currentComponent="tGreenplumInput_6";

	

	}
}finally{
	stmt_tGreenplumInput_6.close();

}
globalMap.put("tGreenplumInput_6_NB_LINE",nb_line_tGreenplumInput_6);
	    		log.debug("tGreenplumInput_6 - Retrieved records count: "+nb_line_tGreenplumInput_6 + " .");
			

 
                if(log.isDebugEnabled())
            log.debug("tGreenplumInput_6 - "  + ("Done.") );

ok_Hash.put("tGreenplumInput_6", true);
end_Hash.put("tGreenplumInput_6", System.currentTimeMillis());




/**
 * [tGreenplumInput_6 end ] stop
 */

	
	/**
	 * [tJavaRow_6 end ] start
	 */

	

	
	
	currentComponent="tJavaRow_6";

	

globalMap.put("tJavaRow_6_NB_LINE",nb_line_tJavaRow_6);
			if(execStat){
				if(resourceMap.get("inIterateVComp") == null || !((Boolean)resourceMap.get("inIterateVComp"))){
			 		runStat.updateStatOnConnection("row6"+iterateId,2, 0); 
			 	}
			}
		
 

ok_Hash.put("tJavaRow_6", true);
end_Hash.put("tJavaRow_6", System.currentTimeMillis());




/**
 * [tJavaRow_6 end ] stop
 */



				}//end the resume

				
				    			if(resumeEntryMethodName == null || globalResumeTicket){
				    				resumeUtil.addLog("CHECKPOINT", "CONNECTION:SUBJOB_OK:tGreenplumInput_6:OnSubjobOk", "", Thread.currentThread().getId() + "", "", "", "", "", "");
								}	    				    			
					    	
								if(execStat){    	
									runStat.updateStatOnConnection("OnSubjobOk104", 0, "ok");
								} 
							
							tJava_25Process(globalMap); 
						



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage());
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tGreenplumInput_6 finally ] start
	 */

	

	
	
	currentComponent="tGreenplumInput_6";

	

 



/**
 * [tGreenplumInput_6 finally ] stop
 */

	
	/**
	 * [tJavaRow_6 finally ] start
	 */

	

	
	
	currentComponent="tJavaRow_6";

	

 



/**
 * [tJavaRow_6 finally ] stop
 */



				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tGreenplumInput_6_SUBPROCESS_STATE", 1);
	}
	

public void tJava_25Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tJava_25_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tJava_25 begin ] start
	 */

	

	
		
		ok_Hash.put("tJava_25", false);
		start_Hash.put("tJava_25", System.currentTimeMillis());
		
	
	currentComponent="tJava_25";

	
		int tos_count_tJava_25 = 0;
		
    	class BytesLimit65535_tJava_25{
    		public void limitLog4jByte() throws Exception{
    			
    		}
    	}
    	
        new BytesLimit65535_tJava_25().limitLog4jByte();


String strDataProfilingCall=(String)globalMap.get("data_profiling_call_template");
strDataProfilingCall=strDataProfilingCall.replace("#TARGET_SCHEMA", "'"+(String)globalMap.get("row7.target_schema_orig")+"'");
strDataProfilingCall=strDataProfilingCall.replace("#TARGET_TABLE_NAME", "'"+(String)globalMap.get("row7.log_table_name")+"'");
globalMap.put("data_profiling_call", strDataProfilingCall);

 



/**
 * [tJava_25 begin ] stop
 */
	
	/**
	 * [tJava_25 main ] start
	 */

	

	
	
	currentComponent="tJava_25";

	

 


	tos_count_tJava_25++;

/**
 * [tJava_25 main ] stop
 */
	
	/**
	 * [tJava_25 end ] start
	 */

	

	
	
	currentComponent="tJava_25";

	

 

ok_Hash.put("tJava_25", true);
end_Hash.put("tJava_25", System.currentTimeMillis());




/**
 * [tJava_25 end ] stop
 */
				}//end the resume

				
				    			if(resumeEntryMethodName == null || globalResumeTicket){
				    				resumeUtil.addLog("CHECKPOINT", "CONNECTION:SUBJOB_OK:tJava_25:OnSubjobOk", "", Thread.currentThread().getId() + "", "", "", "", "", "");
								}	    				    			
					    	
								if(execStat){    	
									runStat.updateStatOnConnection("OnSubjobOk108", 0, "ok");
								} 
							
							tGreenplumRow_6Process(globalMap); 
						



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage());
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tJava_25 finally ] start
	 */

	

	
	
	currentComponent="tJava_25";

	

 



/**
 * [tJava_25 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tJava_25_SUBPROCESS_STATE", 1);
	}
	

public void tGreenplumRow_6Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tGreenplumRow_6_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tGreenplumRow_6 begin ] start
	 */

	

	
		
		ok_Hash.put("tGreenplumRow_6", false);
		start_Hash.put("tGreenplumRow_6", System.currentTimeMillis());
		
	
	currentComponent="tGreenplumRow_6";

	
		int tos_count_tGreenplumRow_6 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tGreenplumRow_6 - "  + ("Start to work.") );
    	class BytesLimit65535_tGreenplumRow_6{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tGreenplumRow_6 = new StringBuilder();
            log4jParamters_tGreenplumRow_6.append("Parameters:");
                    log4jParamters_tGreenplumRow_6.append("USE_EXISTING_CONNECTION" + " = " + "true");
                log4jParamters_tGreenplumRow_6.append(" | ");
                    log4jParamters_tGreenplumRow_6.append("CONNECTION" + " = " + "tGreenplumConnection_2");
                log4jParamters_tGreenplumRow_6.append(" | ");
                    log4jParamters_tGreenplumRow_6.append("QUERYSTORE" + " = " + "\"\"");
                log4jParamters_tGreenplumRow_6.append(" | ");
                    log4jParamters_tGreenplumRow_6.append("QUERY" + " = " + "(String)globalMap.get(\"data_profiling_call\")");
                log4jParamters_tGreenplumRow_6.append(" | ");
                    log4jParamters_tGreenplumRow_6.append("DIE_ON_ERROR" + " = " + "true");
                log4jParamters_tGreenplumRow_6.append(" | ");
                    log4jParamters_tGreenplumRow_6.append("PROPAGATE_RECORD_SET" + " = " + "false");
                log4jParamters_tGreenplumRow_6.append(" | ");
                    log4jParamters_tGreenplumRow_6.append("USE_PREPAREDSTATEMENT" + " = " + "false");
                log4jParamters_tGreenplumRow_6.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tGreenplumRow_6 - "  + (log4jParamters_tGreenplumRow_6) );
    		}
    	}
    	
        new BytesLimit65535_tGreenplumRow_6().limitLog4jByte();

	java.sql.Connection conn_tGreenplumRow_6 = null;
	String query_tGreenplumRow_6 = "";
	boolean whetherReject_tGreenplumRow_6 = false;
				conn_tGreenplumRow_6 = (java.sql.Connection)globalMap.get("conn_tGreenplumConnection_2");
			
				if(conn_tGreenplumRow_6 != null) {
					if(conn_tGreenplumRow_6.getMetaData() != null) {
						
						log.debug("tGreenplumRow_6 - Uses an existing connection with username '" + conn_tGreenplumRow_6.getMetaData().getUserName() + "'. Connection URL: " + conn_tGreenplumRow_6.getMetaData().getURL() + ".");
						
					}
				}
			
		java.sql.Statement stmt_tGreenplumRow_6 = conn_tGreenplumRow_6.createStatement();
	

 



/**
 * [tGreenplumRow_6 begin ] stop
 */
	
	/**
	 * [tGreenplumRow_6 main ] start
	 */

	

	
	
	currentComponent="tGreenplumRow_6";

	

	    		log.debug("tGreenplumRow_6 - Executing the query: '" + (String)globalMap.get("data_profiling_call") + "'.");
			
query_tGreenplumRow_6 = (String)globalMap.get("data_profiling_call");
whetherReject_tGreenplumRow_6 = false;
globalMap.put("tGreenplumRow_6_QUERY",query_tGreenplumRow_6);
try {
		stmt_tGreenplumRow_6.execute(query_tGreenplumRow_6);
		
	    		log.info("tGreenplumRow_6 - Execute the query: '" + (String)globalMap.get("data_profiling_call") + "' has finished.");
			
	} catch (java.lang.Exception e) {
		whetherReject_tGreenplumRow_6 = true;
		
			throw(e);
			
	}
	
	if(!whetherReject_tGreenplumRow_6) {
		
	}
	

 


	tos_count_tGreenplumRow_6++;

/**
 * [tGreenplumRow_6 main ] stop
 */
	
	/**
	 * [tGreenplumRow_6 end ] start
	 */

	

	
	
	currentComponent="tGreenplumRow_6";

	

	
	stmt_tGreenplumRow_6.close();	

 
                if(log.isDebugEnabled())
            log.debug("tGreenplumRow_6 - "  + ("Done.") );

ok_Hash.put("tGreenplumRow_6", true);
end_Hash.put("tGreenplumRow_6", System.currentTimeMillis());




/**
 * [tGreenplumRow_6 end ] stop
 */
				}//end the resume

				
				    			if(resumeEntryMethodName == null || globalResumeTicket){
				    				resumeUtil.addLog("CHECKPOINT", "CONNECTION:SUBJOB_OK:tGreenplumRow_6:OnSubjobOk", "", Thread.currentThread().getId() + "", "", "", "", "", "");
								}	    				    			
					    	
								if(execStat){    	
									runStat.updateStatOnConnection("OnSubjobOk110", 0, "ok");
								} 
							
							tGreenplumRow_14Process(globalMap); 
						



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage());
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tGreenplumRow_6 finally ] start
	 */

	

	
	
	currentComponent="tGreenplumRow_6";

	

 



/**
 * [tGreenplumRow_6 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tGreenplumRow_6_SUBPROCESS_STATE", 1);
	}
	

public void tGreenplumRow_14Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tGreenplumRow_14_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tGreenplumRow_14 begin ] start
	 */

	

	
		
		ok_Hash.put("tGreenplumRow_14", false);
		start_Hash.put("tGreenplumRow_14", System.currentTimeMillis());
		
	
	currentComponent="tGreenplumRow_14";

	
		int tos_count_tGreenplumRow_14 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tGreenplumRow_14 - "  + ("Start to work.") );
    	class BytesLimit65535_tGreenplumRow_14{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tGreenplumRow_14 = new StringBuilder();
            log4jParamters_tGreenplumRow_14.append("Parameters:");
                    log4jParamters_tGreenplumRow_14.append("USE_EXISTING_CONNECTION" + " = " + "true");
                log4jParamters_tGreenplumRow_14.append(" | ");
                    log4jParamters_tGreenplumRow_14.append("CONNECTION" + " = " + "tGreenplumConnection_2");
                log4jParamters_tGreenplumRow_14.append(" | ");
                    log4jParamters_tGreenplumRow_14.append("QUERYSTORE" + " = " + "\"\"");
                log4jParamters_tGreenplumRow_14.append(" | ");
                    log4jParamters_tGreenplumRow_14.append("QUERY" + " = " + "\"select sbdt.db_size('\" +   globalMap.get(\"row7.target_schema_orig\") + \"', '\" +  globalMap.get(\"row7.log_table_name\") +   \"');\"  ");
                log4jParamters_tGreenplumRow_14.append(" | ");
                    log4jParamters_tGreenplumRow_14.append("DIE_ON_ERROR" + " = " + "true");
                log4jParamters_tGreenplumRow_14.append(" | ");
                    log4jParamters_tGreenplumRow_14.append("PROPAGATE_RECORD_SET" + " = " + "false");
                log4jParamters_tGreenplumRow_14.append(" | ");
                    log4jParamters_tGreenplumRow_14.append("USE_PREPAREDSTATEMENT" + " = " + "false");
                log4jParamters_tGreenplumRow_14.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tGreenplumRow_14 - "  + (log4jParamters_tGreenplumRow_14) );
    		}
    	}
    	
        new BytesLimit65535_tGreenplumRow_14().limitLog4jByte();

	java.sql.Connection conn_tGreenplumRow_14 = null;
	String query_tGreenplumRow_14 = "";
	boolean whetherReject_tGreenplumRow_14 = false;
				conn_tGreenplumRow_14 = (java.sql.Connection)globalMap.get("conn_tGreenplumConnection_2");
			
				if(conn_tGreenplumRow_14 != null) {
					if(conn_tGreenplumRow_14.getMetaData() != null) {
						
						log.debug("tGreenplumRow_14 - Uses an existing connection with username '" + conn_tGreenplumRow_14.getMetaData().getUserName() + "'. Connection URL: " + conn_tGreenplumRow_14.getMetaData().getURL() + ".");
						
					}
				}
			
		java.sql.Statement stmt_tGreenplumRow_14 = conn_tGreenplumRow_14.createStatement();
	

 



/**
 * [tGreenplumRow_14 begin ] stop
 */
	
	/**
	 * [tGreenplumRow_14 main ] start
	 */

	

	
	
	currentComponent="tGreenplumRow_14";

	

	    		log.debug("tGreenplumRow_14 - Executing the query: '" + "select sbdt.db_size('" +   globalMap.get("row7.target_schema_orig") + "', '" +  globalMap.get("row7.log_table_name") +   "');"   + "'.");
			
query_tGreenplumRow_14 = "select sbdt.db_size('" + 
globalMap.get("row7.target_schema_orig") + "', '" +
globalMap.get("row7.log_table_name") + 
"');"
;
whetherReject_tGreenplumRow_14 = false;
globalMap.put("tGreenplumRow_14_QUERY",query_tGreenplumRow_14);
try {
		stmt_tGreenplumRow_14.execute(query_tGreenplumRow_14);
		
	    		log.info("tGreenplumRow_14 - Execute the query: '" + "select sbdt.db_size('" + 
globalMap.get("row7.target_schema_orig") + "', '" +
globalMap.get("row7.log_table_name") + 
"');"
 + "' has finished.");
			
	} catch (java.lang.Exception e) {
		whetherReject_tGreenplumRow_14 = true;
		
			throw(e);
			
	}
	
	if(!whetherReject_tGreenplumRow_14) {
		
	}
	

 


	tos_count_tGreenplumRow_14++;

/**
 * [tGreenplumRow_14 main ] stop
 */
	
	/**
	 * [tGreenplumRow_14 end ] start
	 */

	

	
	
	currentComponent="tGreenplumRow_14";

	

	
	stmt_tGreenplumRow_14.close();	

 
                if(log.isDebugEnabled())
            log.debug("tGreenplumRow_14 - "  + ("Done.") );

ok_Hash.put("tGreenplumRow_14", true);
end_Hash.put("tGreenplumRow_14", System.currentTimeMillis());




/**
 * [tGreenplumRow_14 end ] stop
 */
				}//end the resume

				
				    			if(resumeEntryMethodName == null || globalResumeTicket){
				    				resumeUtil.addLog("CHECKPOINT", "CONNECTION:SUBJOB_OK:tGreenplumRow_14:OnSubjobOk", "", Thread.currentThread().getId() + "", "", "", "", "", "");
								}	    				    			
					    	
								if(execStat){    	
									runStat.updateStatOnConnection("OnSubjobOk111", 0, "ok");
								} 
							
							tJava_26Process(globalMap); 
						



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage());
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tGreenplumRow_14 finally ] start
	 */

	

	
	
	currentComponent="tGreenplumRow_14";

	

 



/**
 * [tGreenplumRow_14 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tGreenplumRow_14_SUBPROCESS_STATE", 1);
	}
	

public void tJava_26Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tJava_26_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tJava_26 begin ] start
	 */

	

	
		
		ok_Hash.put("tJava_26", false);
		start_Hash.put("tJava_26", System.currentTimeMillis());
		
	
	currentComponent="tJava_26";

	
		int tos_count_tJava_26 = 0;
		
    	class BytesLimit65535_tJava_26{
    		public void limitLog4jByte() throws Exception{
    			
    		}
    	}
    	
        new BytesLimit65535_tJava_26().limitLog4jByte();


System.out.println("MMMM");
System.out.println((String)context.LOG_STATUS);
System.out.println("MMMM");

System.out.println(
((String)globalMap.get("tGreenplumRow_14_QUERY"))
);

System.out.println(
((String)globalMap.get("tGreenplumRow_14_ERROR_MESSAGE"))
);


 



/**
 * [tJava_26 begin ] stop
 */
	
	/**
	 * [tJava_26 main ] start
	 */

	

	
	
	currentComponent="tJava_26";

	

 


	tos_count_tJava_26++;

/**
 * [tJava_26 main ] stop
 */
	
	/**
	 * [tJava_26 end ] start
	 */

	

	
	
	currentComponent="tJava_26";

	

 

ok_Hash.put("tJava_26", true);
end_Hash.put("tJava_26", System.currentTimeMillis());

				if(execStat){   
   	 				runStat.updateStatOnConnection("OnComponentOk13", 0, "ok");
				}
				tGreenplumClose_3Process(globalMap);



/**
 * [tJava_26 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage());
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tJava_26 finally ] start
	 */

	

	
	
	currentComponent="tJava_26";

	

 



/**
 * [tJava_26 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tJava_26_SUBPROCESS_STATE", 1);
	}
	

public void tJava_21Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tJava_21_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tJava_21 begin ] start
	 */

	

	
		
		ok_Hash.put("tJava_21", false);
		start_Hash.put("tJava_21", System.currentTimeMillis());
		
	
	currentComponent="tJava_21";

	
		int tos_count_tJava_21 = 0;
		
    	class BytesLimit65535_tJava_21{
    		public void limitLog4jByte() throws Exception{
    			
    		}
    	}
    	
        new BytesLimit65535_tJava_21().limitLog4jByte();


context.LOG_MESSAGE = "Missing unique key or invalid update type";
 



/**
 * [tJava_21 begin ] stop
 */
	
	/**
	 * [tJava_21 main ] start
	 */

	

	
	
	currentComponent="tJava_21";

	

 


	tos_count_tJava_21++;

/**
 * [tJava_21 main ] stop
 */
	
	/**
	 * [tJava_21 end ] start
	 */

	

	
	
	currentComponent="tJava_21";

	

 

ok_Hash.put("tJava_21", true);
end_Hash.put("tJava_21", System.currentTimeMillis());

				if(execStat){   
   	 				runStat.updateStatOnConnection("OnComponentOk19", 0, "ok");
				}
				tGreenplumClose_3Process(globalMap);



/**
 * [tJava_21 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage());
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tJava_21 finally ] start
	 */

	

	
	
	currentComponent="tJava_21";

	

 



/**
 * [tJava_21 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tJava_21_SUBPROCESS_STATE", 1);
	}
	

public void tJava_5Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tJava_5_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tJava_5 begin ] start
	 */

	

	
		
		ok_Hash.put("tJava_5", false);
		start_Hash.put("tJava_5", System.currentTimeMillis());
		
	
	currentComponent="tJava_5";

	
		int tos_count_tJava_5 = 0;
		
    	class BytesLimit65535_tJava_5{
    		public void limitLog4jByte() throws Exception{
    			
    		}
    	}
    	
        new BytesLimit65535_tJava_5().limitLog4jByte();


System.out.println(String.valueOf(System.currentTimeMillis()));
System.out.println(String.valueOf( ((Long)globalMap.get("filmtime")) ) );
 



/**
 * [tJava_5 begin ] stop
 */
	
	/**
	 * [tJava_5 main ] start
	 */

	

	
	
	currentComponent="tJava_5";

	

 


	tos_count_tJava_5++;

/**
 * [tJava_5 main ] stop
 */
	
	/**
	 * [tJava_5 end ] start
	 */

	

	
	
	currentComponent="tJava_5";

	

 

ok_Hash.put("tJava_5", true);
end_Hash.put("tJava_5", System.currentTimeMillis());




/**
 * [tJava_5 end ] stop
 */
				}//end the resume

				
				    			if(resumeEntryMethodName == null || globalResumeTicket){
				    				resumeUtil.addLog("CHECKPOINT", "CONNECTION:SUBJOB_OK:tJava_5:OnSubjobOk", "", Thread.currentThread().getId() + "", "", "", "", "", "");
								}	    				    			
					    	
								if(execStat){    	
									runStat.updateStatOnConnection("OnSubjobOk62", 0, "ok");
								} 
							
							tGreenplumConnection_1Process(globalMap); 
						



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage());
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tJava_5 finally ] start
	 */

	

	
	
	currentComponent="tJava_5";

	

 



/**
 * [tJava_5 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tJava_5_SUBPROCESS_STATE", 1);
	}
	

public void tGreenplumConnection_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tGreenplumConnection_1_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tGreenplumConnection_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tGreenplumConnection_1", false);
		start_Hash.put("tGreenplumConnection_1", System.currentTimeMillis());
		
	
	currentComponent="tGreenplumConnection_1";

	
		int tos_count_tGreenplumConnection_1 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tGreenplumConnection_1 - "  + ("Start to work.") );
    	class BytesLimit65535_tGreenplumConnection_1{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tGreenplumConnection_1 = new StringBuilder();
            log4jParamters_tGreenplumConnection_1.append("Parameters:");
                    log4jParamters_tGreenplumConnection_1.append("HOST" + " = " + "context.SOURCING_Server");
                log4jParamters_tGreenplumConnection_1.append(" | ");
                    log4jParamters_tGreenplumConnection_1.append("PORT" + " = " + "context.SOURCING_Port");
                log4jParamters_tGreenplumConnection_1.append(" | ");
                    log4jParamters_tGreenplumConnection_1.append("DBNAME" + " = " + "context.SOURCING_Database");
                log4jParamters_tGreenplumConnection_1.append(" | ");
                    log4jParamters_tGreenplumConnection_1.append("SCHEMA_DB" + " = " + "context.SOURCING_Schema");
                log4jParamters_tGreenplumConnection_1.append(" | ");
                    log4jParamters_tGreenplumConnection_1.append("USER" + " = " + "context.SOURCING_Login");
                log4jParamters_tGreenplumConnection_1.append(" | ");
                    log4jParamters_tGreenplumConnection_1.append("PASS" + " = " + String.valueOf(routines.system.PasswordEncryptUtil.encryptPassword(context.SOURCING_Password)).substring(0, 4) + "...");     
                log4jParamters_tGreenplumConnection_1.append(" | ");
                    log4jParamters_tGreenplumConnection_1.append("USE_SHARED_CONNECTION" + " = " + "false");
                log4jParamters_tGreenplumConnection_1.append(" | ");
                    log4jParamters_tGreenplumConnection_1.append("USE_SSL" + " = " + "true");
                log4jParamters_tGreenplumConnection_1.append(" | ");
                    log4jParamters_tGreenplumConnection_1.append("AUTO_COMMIT" + " = " + "true");
                log4jParamters_tGreenplumConnection_1.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tGreenplumConnection_1 - "  + (log4jParamters_tGreenplumConnection_1) );
    		}
    	}
    	
        new BytesLimit65535_tGreenplumConnection_1().limitLog4jByte();
	

	
				String url_tGreenplumConnection_1 = "jdbc:postgresql://"+context.SOURCING_Server+":"+context.SOURCING_Port+"/"+context.SOURCING_Database+"?ssl=true&sslfactory=org.postgresql.ssl.NonValidatingFactory";

	String dbUser_tGreenplumConnection_1 = context.SOURCING_Login;
	
	
		
	final String decryptedPassword_tGreenplumConnection_1 = context.SOURCING_Password; 
		String dbPwd_tGreenplumConnection_1 = decryptedPassword_tGreenplumConnection_1;
	

	java.sql.Connection conn_tGreenplumConnection_1 = null;
	
		
			String driverClass_tGreenplumConnection_1 = "org.postgresql.Driver";
			java.lang.Class.forName(driverClass_tGreenplumConnection_1);
		
	    		log.debug("tGreenplumConnection_1 - Driver ClassName: "+driverClass_tGreenplumConnection_1+".");
			
	    		log.debug("tGreenplumConnection_1 - Connection attempt to '" + url_tGreenplumConnection_1 + "' with the username '" + dbUser_tGreenplumConnection_1 + "'.");
			
		conn_tGreenplumConnection_1 = java.sql.DriverManager.getConnection(url_tGreenplumConnection_1,dbUser_tGreenplumConnection_1,dbPwd_tGreenplumConnection_1);
	    		log.debug("tGreenplumConnection_1 - Connection to '" + url_tGreenplumConnection_1 + "' has succeeded.");
			

		globalMap.put("conn_tGreenplumConnection_1", conn_tGreenplumConnection_1);
	if (null != conn_tGreenplumConnection_1) {
		
			log.debug("tGreenplumConnection_1 - Connection is set auto commit to 'true'.");
			conn_tGreenplumConnection_1.setAutoCommit(true);
	}

	globalMap.put("schema_" + "tGreenplumConnection_1",context.SOURCING_Schema);

	globalMap.put("conn_" + "tGreenplumConnection_1",conn_tGreenplumConnection_1);
 



/**
 * [tGreenplumConnection_1 begin ] stop
 */
	
	/**
	 * [tGreenplumConnection_1 main ] start
	 */

	

	
	
	currentComponent="tGreenplumConnection_1";

	

 


	tos_count_tGreenplumConnection_1++;

/**
 * [tGreenplumConnection_1 main ] stop
 */
	
	/**
	 * [tGreenplumConnection_1 end ] start
	 */

	

	
	
	currentComponent="tGreenplumConnection_1";

	

 
                if(log.isDebugEnabled())
            log.debug("tGreenplumConnection_1 - "  + ("Done.") );

ok_Hash.put("tGreenplumConnection_1", true);
end_Hash.put("tGreenplumConnection_1", System.currentTimeMillis());

   			if ( context.getProperty("FORCE_DROP").equals("Y")) {
   				
					if(execStat){   
   	 					runStat.updateStatOnConnection("If25", 0, "true");
					}
				
    			tGreenplumRow_7Process(globalMap);
   			}

			   
   				else{
					if(execStat){   
   	 					runStat.updateStatOnConnection("If25", 0, "false");
					}   	 
   				}
   			if (!context.getProperty("FORCE_DROP").equals("Y")) {
   				
					if(execStat){   
   	 					runStat.updateStatOnConnection("If28", 0, "true");
					}
				
    			tGreenplumRow_1Process(globalMap);
   			}

			   
   				else{
					if(execStat){   
   	 					runStat.updateStatOnConnection("If28", 0, "false");
					}   	 
   				}



/**
 * [tGreenplumConnection_1 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage());
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tGreenplumConnection_1 finally ] start
	 */

	

	
	
	currentComponent="tGreenplumConnection_1";

	

 



/**
 * [tGreenplumConnection_1 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tGreenplumConnection_1_SUBPROCESS_STATE", 1);
	}
	

public void tGreenplumRow_7Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tGreenplumRow_7_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tGreenplumRow_7 begin ] start
	 */

	

	
		
		ok_Hash.put("tGreenplumRow_7", false);
		start_Hash.put("tGreenplumRow_7", System.currentTimeMillis());
		
	
	currentComponent="tGreenplumRow_7";

	
		int tos_count_tGreenplumRow_7 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tGreenplumRow_7 - "  + ("Start to work.") );
    	class BytesLimit65535_tGreenplumRow_7{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tGreenplumRow_7 = new StringBuilder();
            log4jParamters_tGreenplumRow_7.append("Parameters:");
                    log4jParamters_tGreenplumRow_7.append("USE_EXISTING_CONNECTION" + " = " + "true");
                log4jParamters_tGreenplumRow_7.append(" | ");
                    log4jParamters_tGreenplumRow_7.append("CONNECTION" + " = " + "tGreenplumConnection_1");
                log4jParamters_tGreenplumRow_7.append(" | ");
                    log4jParamters_tGreenplumRow_7.append("QUERYSTORE" + " = " + "\"\"");
                log4jParamters_tGreenplumRow_7.append(" | ");
                    log4jParamters_tGreenplumRow_7.append("QUERY" + " = " + "GEroutines.sqlDropTable((String)globalMap.get(\"row7.target_schema\"), \"\", (String)globalMap.get(\"row7.log_table_name\") )");
                log4jParamters_tGreenplumRow_7.append(" | ");
                    log4jParamters_tGreenplumRow_7.append("DIE_ON_ERROR" + " = " + "true");
                log4jParamters_tGreenplumRow_7.append(" | ");
                    log4jParamters_tGreenplumRow_7.append("PROPAGATE_RECORD_SET" + " = " + "false");
                log4jParamters_tGreenplumRow_7.append(" | ");
                    log4jParamters_tGreenplumRow_7.append("USE_PREPAREDSTATEMENT" + " = " + "false");
                log4jParamters_tGreenplumRow_7.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tGreenplumRow_7 - "  + (log4jParamters_tGreenplumRow_7) );
    		}
    	}
    	
        new BytesLimit65535_tGreenplumRow_7().limitLog4jByte();

	java.sql.Connection conn_tGreenplumRow_7 = null;
	String query_tGreenplumRow_7 = "";
	boolean whetherReject_tGreenplumRow_7 = false;
				conn_tGreenplumRow_7 = (java.sql.Connection)globalMap.get("conn_tGreenplumConnection_1");
			
				if(conn_tGreenplumRow_7 != null) {
					if(conn_tGreenplumRow_7.getMetaData() != null) {
						
						log.debug("tGreenplumRow_7 - Uses an existing connection with username '" + conn_tGreenplumRow_7.getMetaData().getUserName() + "'. Connection URL: " + conn_tGreenplumRow_7.getMetaData().getURL() + ".");
						
					}
				}
			
		java.sql.Statement stmt_tGreenplumRow_7 = conn_tGreenplumRow_7.createStatement();
	

 



/**
 * [tGreenplumRow_7 begin ] stop
 */
	
	/**
	 * [tGreenplumRow_7 main ] start
	 */

	

	
	
	currentComponent="tGreenplumRow_7";

	

	    		log.debug("tGreenplumRow_7 - Executing the query: '" + GEroutines.sqlDropTable((String)globalMap.get("row7.target_schema"), "", (String)globalMap.get("row7.log_table_name") ) + "'.");
			
query_tGreenplumRow_7 = GEroutines.sqlDropTable((String)globalMap.get("row7.target_schema"), "", (String)globalMap.get("row7.log_table_name") );
whetherReject_tGreenplumRow_7 = false;
globalMap.put("tGreenplumRow_7_QUERY",query_tGreenplumRow_7);
try {
		stmt_tGreenplumRow_7.execute(query_tGreenplumRow_7);
		
	    		log.info("tGreenplumRow_7 - Execute the query: '" + GEroutines.sqlDropTable((String)globalMap.get("row7.target_schema"), "", (String)globalMap.get("row7.log_table_name") ) + "' has finished.");
			
	} catch (java.lang.Exception e) {
		whetherReject_tGreenplumRow_7 = true;
		
			throw(e);
			
	}
	
	if(!whetherReject_tGreenplumRow_7) {
		
	}
	

 


	tos_count_tGreenplumRow_7++;

/**
 * [tGreenplumRow_7 main ] stop
 */
	
	/**
	 * [tGreenplumRow_7 end ] start
	 */

	

	
	
	currentComponent="tGreenplumRow_7";

	

	
	stmt_tGreenplumRow_7.close();	

 
                if(log.isDebugEnabled())
            log.debug("tGreenplumRow_7 - "  + ("Done.") );

ok_Hash.put("tGreenplumRow_7", true);
end_Hash.put("tGreenplumRow_7", System.currentTimeMillis());




/**
 * [tGreenplumRow_7 end ] stop
 */
				}//end the resume

				
				    			if(resumeEntryMethodName == null || globalResumeTicket){
				    				resumeUtil.addLog("CHECKPOINT", "CONNECTION:SUBJOB_OK:tGreenplumRow_7:OnSubjobOk", "", Thread.currentThread().getId() + "", "", "", "", "", "");
								}	    				    			
					    	
								if(execStat){    	
									runStat.updateStatOnConnection("OnSubjobOk19", 0, "ok");
								} 
							
							tGreenplumRow_9Process(globalMap); 
						



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage());
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tGreenplumRow_7 finally ] start
	 */

	

	
	
	currentComponent="tGreenplumRow_7";

	

 



/**
 * [tGreenplumRow_7 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tGreenplumRow_7_SUBPROCESS_STATE", 1);
	}
	

public void tGreenplumRow_9Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tGreenplumRow_9_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tGreenplumRow_9 begin ] start
	 */

	

	
		
		ok_Hash.put("tGreenplumRow_9", false);
		start_Hash.put("tGreenplumRow_9", System.currentTimeMillis());
		
	
	currentComponent="tGreenplumRow_9";

	
		int tos_count_tGreenplumRow_9 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tGreenplumRow_9 - "  + ("Start to work.") );
    	class BytesLimit65535_tGreenplumRow_9{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tGreenplumRow_9 = new StringBuilder();
            log4jParamters_tGreenplumRow_9.append("Parameters:");
                    log4jParamters_tGreenplumRow_9.append("USE_EXISTING_CONNECTION" + " = " + "true");
                log4jParamters_tGreenplumRow_9.append(" | ");
                    log4jParamters_tGreenplumRow_9.append("CONNECTION" + " = " + "tGreenplumConnection_1");
                log4jParamters_tGreenplumRow_9.append(" | ");
                    log4jParamters_tGreenplumRow_9.append("QUERYSTORE" + " = " + "\"\"");
                log4jParamters_tGreenplumRow_9.append(" | ");
                    log4jParamters_tGreenplumRow_9.append("QUERY" + " = " + "\"CREATE TABLE \" + (String)globalMap.get(\"row7.target_schema\") + \".\" +   (String)globalMap.get(\"row7.log_table_name\") +\" ( \" +   (String)globalMap.get(\"columnlist\") + \" )\"+  globalMap.get(\"distributed\")");
                log4jParamters_tGreenplumRow_9.append(" | ");
                    log4jParamters_tGreenplumRow_9.append("DIE_ON_ERROR" + " = " + "true");
                log4jParamters_tGreenplumRow_9.append(" | ");
                    log4jParamters_tGreenplumRow_9.append("PROPAGATE_RECORD_SET" + " = " + "false");
                log4jParamters_tGreenplumRow_9.append(" | ");
                    log4jParamters_tGreenplumRow_9.append("USE_PREPAREDSTATEMENT" + " = " + "false");
                log4jParamters_tGreenplumRow_9.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tGreenplumRow_9 - "  + (log4jParamters_tGreenplumRow_9) );
    		}
    	}
    	
        new BytesLimit65535_tGreenplumRow_9().limitLog4jByte();

	java.sql.Connection conn_tGreenplumRow_9 = null;
	String query_tGreenplumRow_9 = "";
	boolean whetherReject_tGreenplumRow_9 = false;
				conn_tGreenplumRow_9 = (java.sql.Connection)globalMap.get("conn_tGreenplumConnection_1");
			
				if(conn_tGreenplumRow_9 != null) {
					if(conn_tGreenplumRow_9.getMetaData() != null) {
						
						log.debug("tGreenplumRow_9 - Uses an existing connection with username '" + conn_tGreenplumRow_9.getMetaData().getUserName() + "'. Connection URL: " + conn_tGreenplumRow_9.getMetaData().getURL() + ".");
						
					}
				}
			
		java.sql.Statement stmt_tGreenplumRow_9 = conn_tGreenplumRow_9.createStatement();
	

 



/**
 * [tGreenplumRow_9 begin ] stop
 */
	
	/**
	 * [tGreenplumRow_9 main ] start
	 */

	

	
	
	currentComponent="tGreenplumRow_9";

	

	    		log.debug("tGreenplumRow_9 - Executing the query: '" + "CREATE TABLE " + (String)globalMap.get("row7.target_schema") + "." +   (String)globalMap.get("row7.log_table_name") +" ( " +   (String)globalMap.get("columnlist") + " )"+  globalMap.get("distributed") + "'.");
			
query_tGreenplumRow_9 = "CREATE TABLE " + (String)globalMap.get("row7.target_schema") + "." + 
(String)globalMap.get("row7.log_table_name") +" ( " + 
(String)globalMap.get("columnlist") + " )"+
globalMap.get("distributed");
whetherReject_tGreenplumRow_9 = false;
globalMap.put("tGreenplumRow_9_QUERY",query_tGreenplumRow_9);
try {
		stmt_tGreenplumRow_9.execute(query_tGreenplumRow_9);
		
	    		log.info("tGreenplumRow_9 - Execute the query: '" + "CREATE TABLE " + (String)globalMap.get("row7.target_schema") + "." + 
(String)globalMap.get("row7.log_table_name") +" ( " + 
(String)globalMap.get("columnlist") + " )"+
globalMap.get("distributed") + "' has finished.");
			
	} catch (java.lang.Exception e) {
		whetherReject_tGreenplumRow_9 = true;
		
			throw(e);
			
	}
	
	if(!whetherReject_tGreenplumRow_9) {
		
	}
	

 


	tos_count_tGreenplumRow_9++;

/**
 * [tGreenplumRow_9 main ] stop
 */
	
	/**
	 * [tGreenplumRow_9 end ] start
	 */

	

	
	
	currentComponent="tGreenplumRow_9";

	

	
	stmt_tGreenplumRow_9.close();	

 
                if(log.isDebugEnabled())
            log.debug("tGreenplumRow_9 - "  + ("Done.") );

ok_Hash.put("tGreenplumRow_9", true);
end_Hash.put("tGreenplumRow_9", System.currentTimeMillis());




/**
 * [tGreenplumRow_9 end ] stop
 */
				}//end the resume

				
				    			if(resumeEntryMethodName == null || globalResumeTicket){
				    				resumeUtil.addLog("CHECKPOINT", "CONNECTION:SUBJOB_OK:tGreenplumRow_9:OnSubjobOk", "", Thread.currentThread().getId() + "", "", "", "", "", "");
								}	    				    			
					    	
								if(execStat){    	
									runStat.updateStatOnConnection("OnSubjobOk72", 0, "ok");
								} 
							
							tGEGreenplumGPLoad_2Process(globalMap); 
						



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage());
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tGreenplumRow_9 finally ] start
	 */

	

	
	
	currentComponent="tGreenplumRow_9";

	

 



/**
 * [tGreenplumRow_9 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tGreenplumRow_9_SUBPROCESS_STATE", 1);
	}
	

public void tGEGreenplumGPLoad_2Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tGEGreenplumGPLoad_2_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tGEGreenplumGPLoad_2 begin ] start
	 */

	

	
		
		ok_Hash.put("tGEGreenplumGPLoad_2", false);
		start_Hash.put("tGEGreenplumGPLoad_2", System.currentTimeMillis());
		
	
	currentComponent="tGEGreenplumGPLoad_2";

	
		int tos_count_tGEGreenplumGPLoad_2 = 0;
		
    	class BytesLimit65535_tGEGreenplumGPLoad_2{
    		public void limitLog4jByte() throws Exception{
    			
    		}
    	}
    	
        new BytesLimit65535_tGEGreenplumGPLoad_2().limitLog4jByte();

				log.info("tGEGreenplumGPLoad_2 - Start to work");
				StringBuffer log4jSb_tGEGreenplumGPLoad_2 = new StringBuffer();
	int deletedCount_tGEGreenplumGPLoad_2 = 0;
	int insertedCount_tGEGreenplumGPLoad_2 = 0;

	String tableName_tGEGreenplumGPLoad_2 = (String)globalMap.get("row7.target_table_name");
	String dbschema_tGEGreenplumGPLoad_2 = (String)globalMap.get("row7.target_schema");
	String tableName4Load_tGEGreenplumGPLoad_2 = "\"" + tableName_tGEGreenplumGPLoad_2 + "\"";
	if(dbschema_tGEGreenplumGPLoad_2 != null && dbschema_tGEGreenplumGPLoad_2.trim().length() > 0) {
		tableName_tGEGreenplumGPLoad_2 = dbschema_tGEGreenplumGPLoad_2 + "\".\"" + (String)globalMap.get("row7.target_table_name");
		tableName4Load_tGEGreenplumGPLoad_2 = "\""+dbschema_tGEGreenplumGPLoad_2 + "\".\"" + (String)globalMap.get("row7.target_table_name")+"\"";
	}

		java.lang.Class.forName("org.postgresql.Driver");  
			String url_tGEGreenplumGPLoad_2 = "jdbc:postgresql://"+context.SOURCING_Server+":"+context.SOURCING_Port+"/"+context.SOURCING_Database;
		// String url_tGEGreenplumGPLoad_2 = "jdbc:postgresql://"+context.SOURCING_Server+":"+context.SOURCING_Port+"/"+context.SOURCING_Database+"?ssl=true&sslfactory=org.postgresql.ssl.NonValidatingFactory";
		String dbUser_tGEGreenplumGPLoad_2 = context.SOURCING_Login;
		String dbPwd_tGEGreenplumGPLoad_2 = context.SOURCING_Password;
		java.sql.Connection conn_tGEGreenplumGPLoad_2 = null;
		
				String log4jDebugParamters_tGEGreenplumGPLoad_2 = "";
				
				
					String dbhost_log4j_tGEGreenplumGPLoad_2 = context.SOURCING_Server;
					log4jDebugParamters_tGEGreenplumGPLoad_2 = log4jDebugParamters_tGEGreenplumGPLoad_2 + "HOST = " + dbhost_log4j_tGEGreenplumGPLoad_2 + " | ";
				
				
					String dbport_log4j_tGEGreenplumGPLoad_2 = context.SOURCING_Port;
					log4jDebugParamters_tGEGreenplumGPLoad_2 = log4jDebugParamters_tGEGreenplumGPLoad_2 + "PORT = " + dbport_log4j_tGEGreenplumGPLoad_2 + " | ";
				
				
					String dbname_log4j_tGEGreenplumGPLoad_2 = context.SOURCING_Database;
					log4jDebugParamters_tGEGreenplumGPLoad_2 = log4jDebugParamters_tGEGreenplumGPLoad_2 + "DBNAME = " + dbname_log4j_tGEGreenplumGPLoad_2 + " | ";
				
				
					String dbuser_log4j_tGEGreenplumGPLoad_2 = context.SOURCING_Login;
					log4jDebugParamters_tGEGreenplumGPLoad_2 = log4jDebugParamters_tGEGreenplumGPLoad_2 + "USERNAME = " + dbuser_log4j_tGEGreenplumGPLoad_2 + " | ";
				
				
				
				
					String dbSchema_log4j_tGEGreenplumGPLoad_2 = (String)globalMap.get("row7.target_schema");
					log4jDebugParamters_tGEGreenplumGPLoad_2 = log4jDebugParamters_tGEGreenplumGPLoad_2 + "DBSCHEMA = " + dbSchema_log4j_tGEGreenplumGPLoad_2 + " | ";
				
				
				
				
				
					String table_log4j_tGEGreenplumGPLoad_2 = (String)globalMap.get("row7.target_table_name");
					log4jDebugParamters_tGEGreenplumGPLoad_2 = log4jDebugParamters_tGEGreenplumGPLoad_2 + "TABLE = " + table_log4j_tGEGreenplumGPLoad_2 + " | ";
				
				
				log4jDebugParamters_tGEGreenplumGPLoad_2 = "tGEGreenplumGPLoad_2 - Parameters:" + log4jDebugParamters_tGEGreenplumGPLoad_2;
				log.debug("tGEGreenplumGPLoad_2 - Driver ClassName: org.postgresql.Driver.");
				log.debug(log4jDebugParamters_tGEGreenplumGPLoad_2);	
		
			log.info("tGEGreenplumGPLoad_2 - Connection attempt to '" + url_tGEGreenplumGPLoad_2 + "' with the username '" + dbUser_tGEGreenplumGPLoad_2 + "'.");
		
		conn_tGEGreenplumGPLoad_2 = java.sql.DriverManager.getConnection(url_tGEGreenplumGPLoad_2, dbUser_tGEGreenplumGPLoad_2, dbPwd_tGEGreenplumGPLoad_2);
		
			log.info("tGEGreenplumGPLoad_2 - Connection to '" + url_tGEGreenplumGPLoad_2 + "' has succeeded." );
		
		
        conn_tGEGreenplumGPLoad_2.close();

		
	        String delim_tGEGreenplumGPLoad_2 = "\\013";
		String escape_tGEGreenplumGPLoad_2 = "\\";
		String quote_tGEGreenplumGPLoad_2 = "\"";
		delim_tGEGreenplumGPLoad_2 = "\t".equals(delim_tGEGreenplumGPLoad_2) ? "\\t" : delim_tGEGreenplumGPLoad_2;
		/**
		 Create Directory if does not exists 
		*/
		String directory_tGEGreenplumGPLoad_2 = context.ETL_STORAGE_PATH + "/" + context.GP_SOURCE_NAME + "/data/" +context.SOURCE_DATABASE  + "/" + ((String)globalMap.get("row7.log_table_name"))  + ".yaml";
		//create directory only if not exists
	    if(directory_tGEGreenplumGPLoad_2 != null && directory_tGEGreenplumGPLoad_2.trim().length() != 0 
	    		&& directory_tGEGreenplumGPLoad_2.replace("\\","/").contains("/")) {
	    	directory_tGEGreenplumGPLoad_2 = directory_tGEGreenplumGPLoad_2.substring(0, directory_tGEGreenplumGPLoad_2.replace("\\","/").lastIndexOf("/"));
	    	java.io.File dir_tGEGreenplumGPLoad_2 = new java.io.File(directory_tGEGreenplumGPLoad_2);
	        	if(!dir_tGEGreenplumGPLoad_2.exists()) {
					dir_tGEGreenplumGPLoad_2.mkdirs();
					System.out.println("Created Directory:" + dir_tGEGreenplumGPLoad_2);
	            }
	    }

		java.io.PrintWriter gpctrl_tGEGreenplumGPLoad_2 = new java.io.PrintWriter(new java.io.FileOutputStream(context.ETL_STORAGE_PATH + "/" + context.GP_SOURCE_NAME + "/data/" +context.SOURCE_DATABASE  + "/" + ((String)globalMap.get("row7.log_table_name"))  + ".yaml", false), true);
		gpctrl_tGEGreenplumGPLoad_2.println("---");
		gpctrl_tGEGreenplumGPLoad_2.println("VERSION: 1.0.0.1");
		gpctrl_tGEGreenplumGPLoad_2.println("DATABASE: " + context.SOURCING_Database);
		gpctrl_tGEGreenplumGPLoad_2.println("USER: " + context.SOURCING_Login);
		gpctrl_tGEGreenplumGPLoad_2.println("PASSWORD: " + context.SOURCING_Password);
		gpctrl_tGEGreenplumGPLoad_2.println("HOST: " + context.SOURCING_Server);
		gpctrl_tGEGreenplumGPLoad_2.println("PORT: " + context.SOURCING_Port);
		gpctrl_tGEGreenplumGPLoad_2.println("GPLOAD:");
		gpctrl_tGEGreenplumGPLoad_2.println("  INPUT:");
		gpctrl_tGEGreenplumGPLoad_2.println("    - SOURCE:");
		String sourceLocalHostname_tGEGreenplumGPLoad_2 = context.ETL_LOCALHOSTNAME;
		if(sourceLocalHostname_tGEGreenplumGPLoad_2.length()>0) {
			gpctrl_tGEGreenplumGPLoad_2.println("        LOCAL_HOSTNAME:");
			gpctrl_tGEGreenplumGPLoad_2.println("        - "+context.ETL_LOCALHOSTNAME);
		}
		String sourcePort_tGEGreenplumGPLoad_2 = context.HAWQ_Source_Ports;
		if(sourcePort_tGEGreenplumGPLoad_2.length() > 0 ) {
			gpctrl_tGEGreenplumGPLoad_2.println("        PORT_RANGE: "+context.HAWQ_Source_Ports);
		} else {
			gpctrl_tGEGreenplumGPLoad_2.println("        PORT_RANGE: "+"[8500,8999]");
		}
		gpctrl_tGEGreenplumGPLoad_2.println("        FILE:");
		
		gpctrl_tGEGreenplumGPLoad_2.println("          - " + (String)globalMap.get("filetocheck"));
		
		gpctrl_tGEGreenplumGPLoad_2.println("    - MAX_LINE_LENGTH: 268435456");
		String columnDefList_tGEGreenplumGPLoad_2 = GPLoadRoutine.getGPLoadColumnList((String)globalMap.get("columnlist"));
		if(columnDefList_tGEGreenplumGPLoad_2.length() > 0) {
			gpctrl_tGEGreenplumGPLoad_2.println("    - COLUMNS:");
			gpctrl_tGEGreenplumGPLoad_2.println(GPLoadRoutine.getGPLoadColumnList((String)globalMap.get("columnlist")));
		}
		gpctrl_tGEGreenplumGPLoad_2.println("    - DELIMITER: E'" + delim_tGEGreenplumGPLoad_2 + "'");
		gpctrl_tGEGreenplumGPLoad_2.println("    - ESCAPE: '" + escape_tGEGreenplumGPLoad_2 + "'");
		
		gpctrl_tGEGreenplumGPLoad_2.println("    - FORMAT: text");
		
		
		gpctrl_tGEGreenplumGPLoad_2.println("    - ENCODING: " + "UTF8");
		
				gpctrl_tGEGreenplumGPLoad_2.println("    - ERROR_LIMIT: " + 1000);
				
				gpctrl_tGEGreenplumGPLoad_2.println("    - ERROR_TABLE: " + "sbdt.gpload_errors_");
				
		gpctrl_tGEGreenplumGPLoad_2.println("  OUTPUT: ");
		gpctrl_tGEGreenplumGPLoad_2.println("    - TABLE: " + (String)globalMap.get("row7.target_schema")+"."+(String)globalMap.get("row7.target_table_name"));
		gpctrl_tGEGreenplumGPLoad_2.println("    - MODE: insert");
		

		gpctrl_tGEGreenplumGPLoad_2.close();
		

	final StringBuilder gploadOutput_tGEGreenplumGPLoad_2 = new StringBuilder(200);
	/**
		Create an exception handler to be able to catch exception coming from the thread.
	*/
	final class GpLoadExceptionHandler_tGEGreenplumGPLoad_2 implements Thread.UncaughtExceptionHandler {

		private Thread.UncaughtExceptionHandler defaultUEH;
		private volatile Throwable tr;

		public GpLoadExceptionHandler_tGEGreenplumGPLoad_2() {
        	this.defaultUEH = Thread.getDefaultUncaughtExceptionHandler();
    	}

        public void uncaughtException(Thread t, Throwable e) {
    	    tr = e;
	       	defaultUEH.uncaughtException(t, e);
    	}

    	public Throwable getException() {
    		return tr;
    	}

    	public void resetException() {
    		this.tr = null;
    	}
	}
	GpLoadExceptionHandler_tGEGreenplumGPLoad_2 h_tGEGreenplumGPLoad_2 = new GpLoadExceptionHandler_tGEGreenplumGPLoad_2() ;

	Thread gploadThread_tGEGreenplumGPLoad_2 =
		new Thread() {
		public void run() {
			try {
				String[] envp = null;
				String[] cmds = new String[] {"gpload","-f",context.ETL_STORAGE_PATH + "/" + context.GP_SOURCE_NAME + "/data/" +context.SOURCE_DATABASE  + "/" + ((String)globalMap.get("row7.log_table_name"))  + ".yaml","-h",context.SOURCING_Server,"-p",context.SOURCING_Port,"-U",context.SOURCING_Login,"-d",context.SOURCING_Database,"-l",context.ETL_STORAGE_PATH + "/" +context.GP_SOURCE_NAME + "/data/" + context.SOURCE_DATABASE  + "/" + ((String)globalMap.get("row7.log_table_name")).replace("\"","").replace("#","__hash__").replace("$","__dollar__")  + new SimpleDateFormat("yyyyMMddHHmmss").format(((java.util.Date)globalMap.get("row7.now"))).toString() + ".log","-v"};
				Boolean failure = false;
				Runtime rt = Runtime.getRuntime();
				final Process ps = rt.exec(cmds, envp);
				java.io.BufferedReader reader = new java.io.BufferedReader(new java.io.InputStreamReader(ps.getInputStream()));
				String line = "";
				while ((line = reader.readLine()) != null) {
					gploadOutput_tGEGreenplumGPLoad_2.append(line);
					if(line.contains("|INFO|rows Inserted")){
						globalMap.put("tGEGreenplumGPLoad_2_NB_LINE_INSERTED",Integer.parseInt(line.substring(line.indexOf("=")+1).replace(" ","")));
					} else
					if(line.contains("|INFO|rows Updated")){
					      globalMap.put("tGEGreenplumGPLoad_2_NB_LINE_UPDATED", Integer.parseInt(line.substring(line.indexOf("=")+1).replace(" ","")));
					} else if(line.contains("|INFO|data formatting errors =")){
					      globalMap.put("tGEGreenplumGPLoad_2_NB_DATA_ERRORS", Integer.parseInt(line.substring(line.indexOf("=")+1).replace(" ","")));
					} else if(line.contains("|INFO|gpload ") && !line.contains("session") && !line.contains("gpload.py") ){
					      globalMap.put("tGEGreenplumGPLoad_2_STATUS", line.substring(line.indexOf("gpload ")+7).replace(" ",""));
					} else if(line.contains("|INFO|running time:")){
					      line = line.substring(line.indexOf("time: ")+5).replace(" ","");
					      globalMap.put("tGEGreenplumGPLoad_2_RUNTIME", line.substring(0,line.indexOf("seconds")));
					} else if(line.contains("|ERROR|")){
						failure = true;
					      line = line.substring(line.indexOf("|ERROR|")+7);
					      String line1 = line;
					      if(line.length()>1250) {
					            String tmp = line.substring(0, 1000);
					            tmp += ".....";
					            tmp += line.substring(line.length()-200);
					            line = tmp;
					      }
					      globalMap.put("tGEGreenplumGPLoad_2_ERRORMESSAGE", line);
					      if(true){
					      	throw new RuntimeException ("gpload failed because: " + line1);
					      } else {
					      	System.out.println("WARNING GPLOAD FAILURE:" + line1);
					      }
					}
				}
				reader = new java.io.BufferedReader(new java.io.InputStreamReader(ps.getErrorStream()));
				line = "";
				while ((line = reader.readLine()) != null) {
					gploadOutput_tGEGreenplumGPLoad_2.append(line);

					if (line.contains("name 'tableName' is not defined") ) {
						failure = true;

						String line1 = "Table (" + context.SOURCING_Database + "." + (String)globalMap.get("row7.target_schema") + "." + (String)globalMap.get("row7.target_table_name") + ") is not available in target (" + context.SOURCING_Server + ")!";
						globalMap.put("tGEGreenplumGPLoad_2_ERRORMESSAGE", line1);
					    if(true){
					      	throw new RuntimeException ("gpload failed because: " + line1);
					    } else {
					      	System.out.println("WARNING GPLOAD FAILURE:" + line1);
					    }
					}
					if (line.toUpperCase().contains("ERROR") ) {
						failure = true;
						globalMap.put("tGEGreenplumGPLoad_2_ERRORMESSAGE", line);
					    if(true){
					      	throw new RuntimeException ("gpload failed because: " + line);
					    } else {
					      	System.out.println("WARNING GPLOAD FAILURE:" + line);
					    }
					}
				}
			}
			catch (java.lang.Exception e) {
				
					log.fatal("tGEGreenplumGPLoad_2 - " + e.getMessage());
				
				globalMap.put("tGEGreenplumGPLoad_2_GPLOAD_ERROR",e.getMessage());
				throw new RuntimeException(e.getMessage(),e.getCause());
			}
		}
	};
	gploadThread_tGEGreenplumGPLoad_2.setUncaughtExceptionHandler(h_tGEGreenplumGPLoad_2);
	Thread gploadThread_retry_tGEGreenplumGPLoad_2 =
		new Thread() {
		public void run() {
			try {
				String[] envp = null;
				String[] cmds = new String[] {"gpload","-f",context.ETL_STORAGE_PATH + "/" + context.GP_SOURCE_NAME + "/data/" +context.SOURCE_DATABASE  + "/" + ((String)globalMap.get("row7.log_table_name"))  + ".yaml","-h",context.SOURCING_Server,"-p",context.SOURCING_Port,"-U",context.SOURCING_Login,"-d",context.SOURCING_Database,"-l",context.ETL_STORAGE_PATH + "/" +context.GP_SOURCE_NAME + "/data/" + context.SOURCE_DATABASE  + "/" + ((String)globalMap.get("row7.log_table_name")).replace("\"","").replace("#","__hash__").replace("$","__dollar__")  + new SimpleDateFormat("yyyyMMddHHmmss").format(((java.util.Date)globalMap.get("row7.now"))).toString() + ".log","-v"};
				Boolean failure = false;
				Runtime rt = Runtime.getRuntime();
				final Process ps = rt.exec(cmds, envp);
				java.io.BufferedReader reader = new java.io.BufferedReader(new java.io.InputStreamReader(ps.getInputStream()));
				String line = "";
				while ((line = reader.readLine()) != null) {
					gploadOutput_tGEGreenplumGPLoad_2.append(line);
					if(line.contains("|INFO|rows Inserted")){
						globalMap.put("tGEGreenplumGPLoad_2_NB_LINE_INSERTED",Integer.parseInt(line.substring(line.indexOf("=")+1).replace(" ","")));
					} else
					if(line.contains("|INFO|rows Updated")){
					      globalMap.put("tGEGreenplumGPLoad_2_NB_LINE_UPDATED", Integer.parseInt(line.substring(line.indexOf("=")+1).replace(" ","")));
					} else if(line.contains("|INFO|data formatting errors =")){
					      globalMap.put("tGEGreenplumGPLoad_2_NB_DATA_ERRORS", Integer.parseInt(line.substring(line.indexOf("=")+1).replace(" ","")));
					} else if(line.contains("|INFO|gpload ") && !line.contains("session") && !line.contains("gpload.py") ){
					      globalMap.put("tGEGreenplumGPLoad_2_STATUS", line.substring(line.indexOf("gpload ")+7).replace(" ",""));
					} else if(line.contains("|INFO|running time:")){
					      line = line.substring(line.indexOf("time: ")+5).replace(" ","");
					      globalMap.put("tGEGreenplumGPLoad_2_RUNTIME", line.substring(0,line.indexOf("seconds")));
					} else if(line.contains("|ERROR|")){
						failure = true;
					      line = line.substring(line.indexOf("|ERROR|")+7);
					      String line1 = line;
					      if(line.length()>1250) {
					            String tmp = line.substring(0, 1000);
					            tmp += ".....";
					            tmp += line.substring(line.length()-200);
					            line = tmp;
					      }
					      globalMap.put("tGEGreenplumGPLoad_2_ERRORMESSAGE", line);
					      if(true){
					      	throw new RuntimeException ("gpload failed because: " + line1);
					      } else {
					      	System.out.println("WARNING GPLOAD FAILURE:" + line1);
					      }
					}
				}
				reader = new java.io.BufferedReader(new java.io.InputStreamReader(ps.getErrorStream()));
				line = "";
				while ((line = reader.readLine()) != null) {
					gploadOutput_tGEGreenplumGPLoad_2.append(line);

					if (line.contains("name 'tableName' is not defined") ) {
						failure = true;

						String line1 = "Table (" + context.SOURCING_Database + "." + (String)globalMap.get("row7.target_schema") + "." + (String)globalMap.get("row7.target_table_name") + ") is not available in target (" + context.SOURCING_Server + ")!";
						globalMap.put("tGEGreenplumGPLoad_2_ERRORMESSAGE", line1);
					    if(true){
					      	throw new RuntimeException ("gpload failed because: " + line1);
					    } else {
					      	System.out.println("WARNING GPLOAD FAILURE:" + line1);
					    }
					}
					if (line.toUpperCase().contains("ERROR") ) {
						failure = true;
						globalMap.put("tGEGreenplumGPLoad_2_ERRORMESSAGE", line);
					    if(true){
					      	throw new RuntimeException ("gpload failed because: " + line);
					    } else {
					      	System.out.println("WARNING GPLOAD FAILURE:" + line);
					    }
					}
				}
			}
			catch (java.lang.Exception e) {
				
					log.fatal("tGEGreenplumGPLoad_2 - " + e.getMessage());
				
				globalMap.put("tGEGreenplumGPLoad_2_GPLOAD_ERROR",e.getMessage());
				throw new RuntimeException(e.getMessage(),e.getCause());
			}
		}
	};
	gploadThread_retry_tGEGreenplumGPLoad_2.setUncaughtExceptionHandler(h_tGEGreenplumGPLoad_2);
		
			log.info("tGEGreenplumGPLoad_2 - Loading data into database.");
		
	gploadThread_tGEGreenplumGPLoad_2.start();
	gploadThread_tGEGreenplumGPLoad_2.join(0);
	globalMap.put("tGEGreenplumGPLoad_2_GPLOAD_OUTPUT", gploadOutput_tGEGreenplumGPLoad_2.toString());
	globalMap.put("tGEGreenplumGPLoad_2_NB_LINE", insertedCount_tGEGreenplumGPLoad_2);
		
			log.info("tGEGreenplumGPLoad_2 - Loaded records count:" + insertedCount_tGEGreenplumGPLoad_2 + ".");
			log.info("tGEGreenplumGPLoad_2 - Has finished.");
		

 



/**
 * [tGEGreenplumGPLoad_2 begin ] stop
 */
	
	/**
	 * [tGEGreenplumGPLoad_2 main ] start
	 */

	

	
	
	currentComponent="tGEGreenplumGPLoad_2";

	



 


	tos_count_tGEGreenplumGPLoad_2++;

/**
 * [tGEGreenplumGPLoad_2 main ] stop
 */
	
	/**
	 * [tGEGreenplumGPLoad_2 end ] start
	 */

	

	
	
	currentComponent="tGEGreenplumGPLoad_2";

	


	if (h_tGEGreenplumGPLoad_2.getException() != null ) {
		if (h_tGEGreenplumGPLoad_2.getException() instanceof Error)
           	throw (Error) h_tGEGreenplumGPLoad_2.getException();
        if (h_tGEGreenplumGPLoad_2.getException() instanceof RuntimeException)
           	throw (RuntimeException) h_tGEGreenplumGPLoad_2.getException();
        else
	      	throw new RuntimeException(h_tGEGreenplumGPLoad_2.getException());
	}
	globalMap.put("tGEGreenplumGPLoad_2_GPLOAD_OUTPUT", gploadOutput_tGEGreenplumGPLoad_2.toString());
	globalMap.put("tGEGreenplumGPLoad_2_NB_LINE", insertedCount_tGEGreenplumGPLoad_2);
	
 

ok_Hash.put("tGEGreenplumGPLoad_2", true);
end_Hash.put("tGEGreenplumGPLoad_2", System.currentTimeMillis());

				if(execStat){   
   	 				runStat.updateStatOnConnection("OnComponentOk22", 0, "ok");
				}
				tGreenplumRow_21Process(globalMap);



/**
 * [tGEGreenplumGPLoad_2 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage());
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tGEGreenplumGPLoad_2 finally ] start
	 */

	

	
	
	currentComponent="tGEGreenplumGPLoad_2";

	

 



/**
 * [tGEGreenplumGPLoad_2 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tGEGreenplumGPLoad_2_SUBPROCESS_STATE", 1);
	}
	

public void tGreenplumRow_21Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tGreenplumRow_21_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tGreenplumRow_21 begin ] start
	 */

	

	
		
		ok_Hash.put("tGreenplumRow_21", false);
		start_Hash.put("tGreenplumRow_21", System.currentTimeMillis());
		
	
	currentComponent="tGreenplumRow_21";

	
		int tos_count_tGreenplumRow_21 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tGreenplumRow_21 - "  + ("Start to work.") );
    	class BytesLimit65535_tGreenplumRow_21{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tGreenplumRow_21 = new StringBuilder();
            log4jParamters_tGreenplumRow_21.append("Parameters:");
                    log4jParamters_tGreenplumRow_21.append("USE_EXISTING_CONNECTION" + " = " + "true");
                log4jParamters_tGreenplumRow_21.append(" | ");
                    log4jParamters_tGreenplumRow_21.append("CONNECTION" + " = " + "tGreenplumConnection_1");
                log4jParamters_tGreenplumRow_21.append(" | ");
                    log4jParamters_tGreenplumRow_21.append("QUERYSTORE" + " = " + "\"\"");
                log4jParamters_tGreenplumRow_21.append(" | ");
                    log4jParamters_tGreenplumRow_21.append("QUERY" + " = " + "\"select sbdt.edl_add_two_hvr_cols('\" +  ((String)globalMap.get(\"row7.source_name\")) +  \"');\"");
                log4jParamters_tGreenplumRow_21.append(" | ");
                    log4jParamters_tGreenplumRow_21.append("DIE_ON_ERROR" + " = " + "true");
                log4jParamters_tGreenplumRow_21.append(" | ");
                    log4jParamters_tGreenplumRow_21.append("PROPAGATE_RECORD_SET" + " = " + "false");
                log4jParamters_tGreenplumRow_21.append(" | ");
                    log4jParamters_tGreenplumRow_21.append("USE_PREPAREDSTATEMENT" + " = " + "false");
                log4jParamters_tGreenplumRow_21.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tGreenplumRow_21 - "  + (log4jParamters_tGreenplumRow_21) );
    		}
    	}
    	
        new BytesLimit65535_tGreenplumRow_21().limitLog4jByte();

	java.sql.Connection conn_tGreenplumRow_21 = null;
	String query_tGreenplumRow_21 = "";
	boolean whetherReject_tGreenplumRow_21 = false;
				conn_tGreenplumRow_21 = (java.sql.Connection)globalMap.get("conn_tGreenplumConnection_1");
			
				if(conn_tGreenplumRow_21 != null) {
					if(conn_tGreenplumRow_21.getMetaData() != null) {
						
						log.debug("tGreenplumRow_21 - Uses an existing connection with username '" + conn_tGreenplumRow_21.getMetaData().getUserName() + "'. Connection URL: " + conn_tGreenplumRow_21.getMetaData().getURL() + ".");
						
					}
				}
			
		java.sql.Statement stmt_tGreenplumRow_21 = conn_tGreenplumRow_21.createStatement();
	

 



/**
 * [tGreenplumRow_21 begin ] stop
 */
	
	/**
	 * [tGreenplumRow_21 main ] start
	 */

	

	
	
	currentComponent="tGreenplumRow_21";

	

	    		log.debug("tGreenplumRow_21 - Executing the query: '" + "select sbdt.edl_add_two_hvr_cols('" +  ((String)globalMap.get("row7.source_name")) +  "');" + "'.");
			
query_tGreenplumRow_21 = "select sbdt.edl_add_two_hvr_cols('" +  ((String)globalMap.get("row7.source_name")) +  "');";
whetherReject_tGreenplumRow_21 = false;
globalMap.put("tGreenplumRow_21_QUERY",query_tGreenplumRow_21);
try {
		stmt_tGreenplumRow_21.execute(query_tGreenplumRow_21);
		
	    		log.info("tGreenplumRow_21 - Execute the query: '" + "select sbdt.edl_add_two_hvr_cols('" +  ((String)globalMap.get("row7.source_name")) +  "');" + "' has finished.");
			
	} catch (java.lang.Exception e) {
		whetherReject_tGreenplumRow_21 = true;
		
			throw(e);
			
	}
	
	if(!whetherReject_tGreenplumRow_21) {
		
	}
	

 


	tos_count_tGreenplumRow_21++;

/**
 * [tGreenplumRow_21 main ] stop
 */
	
	/**
	 * [tGreenplumRow_21 end ] start
	 */

	

	
	
	currentComponent="tGreenplumRow_21";

	

	
	stmt_tGreenplumRow_21.close();	

 
                if(log.isDebugEnabled())
            log.debug("tGreenplumRow_21 - "  + ("Done.") );

ok_Hash.put("tGreenplumRow_21", true);
end_Hash.put("tGreenplumRow_21", System.currentTimeMillis());

				if(execStat){   
   	 				runStat.updateStatOnConnection("OnComponentOk33", 0, "ok");
				}
				tGreenplumRow_23Process(globalMap);



/**
 * [tGreenplumRow_21 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage());
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tGreenplumRow_21 finally ] start
	 */

	

	
	
	currentComponent="tGreenplumRow_21";

	

 



/**
 * [tGreenplumRow_21 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tGreenplumRow_21_SUBPROCESS_STATE", 1);
	}
	

public void tGreenplumRow_23Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tGreenplumRow_23_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tGreenplumRow_23 begin ] start
	 */

	

	
		
		ok_Hash.put("tGreenplumRow_23", false);
		start_Hash.put("tGreenplumRow_23", System.currentTimeMillis());
		
	
	currentComponent="tGreenplumRow_23";

	
		int tos_count_tGreenplumRow_23 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tGreenplumRow_23 - "  + ("Start to work.") );
    	class BytesLimit65535_tGreenplumRow_23{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tGreenplumRow_23 = new StringBuilder();
            log4jParamters_tGreenplumRow_23.append("Parameters:");
                    log4jParamters_tGreenplumRow_23.append("USE_EXISTING_CONNECTION" + " = " + "true");
                log4jParamters_tGreenplumRow_23.append(" | ");
                    log4jParamters_tGreenplumRow_23.append("CONNECTION" + " = " + "tGreenplumConnection_1");
                log4jParamters_tGreenplumRow_23.append(" | ");
                    log4jParamters_tGreenplumRow_23.append("QUERYSTORE" + " = " + "\"\"");
                log4jParamters_tGreenplumRow_23.append(" | ");
                    log4jParamters_tGreenplumRow_23.append("QUERY" + " = " + "\"update \"+(String)globalMap.get(\"row7.target_schema\") +\".\"+ (String)globalMap.get(\"row7.target_table_name\") +\" set edl_is_deleted = 0, edl_last_updated_date = current_timestamp;\"");
                log4jParamters_tGreenplumRow_23.append(" | ");
                    log4jParamters_tGreenplumRow_23.append("DIE_ON_ERROR" + " = " + "true");
                log4jParamters_tGreenplumRow_23.append(" | ");
                    log4jParamters_tGreenplumRow_23.append("PROPAGATE_RECORD_SET" + " = " + "false");
                log4jParamters_tGreenplumRow_23.append(" | ");
                    log4jParamters_tGreenplumRow_23.append("USE_PREPAREDSTATEMENT" + " = " + "false");
                log4jParamters_tGreenplumRow_23.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tGreenplumRow_23 - "  + (log4jParamters_tGreenplumRow_23) );
    		}
    	}
    	
        new BytesLimit65535_tGreenplumRow_23().limitLog4jByte();

	java.sql.Connection conn_tGreenplumRow_23 = null;
	String query_tGreenplumRow_23 = "";
	boolean whetherReject_tGreenplumRow_23 = false;
				conn_tGreenplumRow_23 = (java.sql.Connection)globalMap.get("conn_tGreenplumConnection_1");
			
				if(conn_tGreenplumRow_23 != null) {
					if(conn_tGreenplumRow_23.getMetaData() != null) {
						
						log.debug("tGreenplumRow_23 - Uses an existing connection with username '" + conn_tGreenplumRow_23.getMetaData().getUserName() + "'. Connection URL: " + conn_tGreenplumRow_23.getMetaData().getURL() + ".");
						
					}
				}
			
		java.sql.Statement stmt_tGreenplumRow_23 = conn_tGreenplumRow_23.createStatement();
	

 



/**
 * [tGreenplumRow_23 begin ] stop
 */
	
	/**
	 * [tGreenplumRow_23 main ] start
	 */

	

	
	
	currentComponent="tGreenplumRow_23";

	

	    		log.debug("tGreenplumRow_23 - Executing the query: '" + "update "+(String)globalMap.get("row7.target_schema") +"."+ (String)globalMap.get("row7.target_table_name") +" set edl_is_deleted = 0, edl_last_updated_date = current_timestamp;" + "'.");
			
query_tGreenplumRow_23 = "update "+(String)globalMap.get("row7.target_schema") +"."+ (String)globalMap.get("row7.target_table_name") +" set edl_is_deleted = 0, edl_last_updated_date = current_timestamp;";
whetherReject_tGreenplumRow_23 = false;
globalMap.put("tGreenplumRow_23_QUERY",query_tGreenplumRow_23);
try {
		stmt_tGreenplumRow_23.execute(query_tGreenplumRow_23);
		
	    		log.info("tGreenplumRow_23 - Execute the query: '" + "update "+(String)globalMap.get("row7.target_schema") +"."+ (String)globalMap.get("row7.target_table_name") +" set edl_is_deleted = 0, edl_last_updated_date = current_timestamp;" + "' has finished.");
			
	} catch (java.lang.Exception e) {
		whetherReject_tGreenplumRow_23 = true;
		
			throw(e);
			
	}
	
	if(!whetherReject_tGreenplumRow_23) {
		
	}
	

 


	tos_count_tGreenplumRow_23++;

/**
 * [tGreenplumRow_23 main ] stop
 */
	
	/**
	 * [tGreenplumRow_23 end ] start
	 */

	

	
	
	currentComponent="tGreenplumRow_23";

	

	
	stmt_tGreenplumRow_23.close();	

 
                if(log.isDebugEnabled())
            log.debug("tGreenplumRow_23 - "  + ("Done.") );

ok_Hash.put("tGreenplumRow_23", true);
end_Hash.put("tGreenplumRow_23", System.currentTimeMillis());

				if(execStat){   
   	 				runStat.updateStatOnConnection("OnComponentOk35", 0, "ok");
				}
				tGreenplumClose_5Process(globalMap);



/**
 * [tGreenplumRow_23 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage());
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tGreenplumRow_23 finally ] start
	 */

	

	
	
	currentComponent="tGreenplumRow_23";

	

 



/**
 * [tGreenplumRow_23 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tGreenplumRow_23_SUBPROCESS_STATE", 1);
	}
	

public void tGreenplumClose_5Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tGreenplumClose_5_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tGreenplumClose_5 begin ] start
	 */

	

	
		
		ok_Hash.put("tGreenplumClose_5", false);
		start_Hash.put("tGreenplumClose_5", System.currentTimeMillis());
		
	
	currentComponent="tGreenplumClose_5";

	
		int tos_count_tGreenplumClose_5 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tGreenplumClose_5 - "  + ("Start to work.") );
    	class BytesLimit65535_tGreenplumClose_5{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tGreenplumClose_5 = new StringBuilder();
            log4jParamters_tGreenplumClose_5.append("Parameters:");
                    log4jParamters_tGreenplumClose_5.append("CONNECTION" + " = " + "tGreenplumConnection_1");
                log4jParamters_tGreenplumClose_5.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tGreenplumClose_5 - "  + (log4jParamters_tGreenplumClose_5) );
    		}
    	}
    	
        new BytesLimit65535_tGreenplumClose_5().limitLog4jByte();

 



/**
 * [tGreenplumClose_5 begin ] stop
 */
	
	/**
	 * [tGreenplumClose_5 main ] start
	 */

	

	
	
	currentComponent="tGreenplumClose_5";

	



	java.sql.Connection conn_tGreenplumClose_5 = (java.sql.Connection)globalMap.get("conn_tGreenplumConnection_1");
	if(conn_tGreenplumClose_5 != null && !conn_tGreenplumClose_5.isClosed())
	{
                if(log.isDebugEnabled())
            log.debug("tGreenplumClose_5 - "  + ("Closing the connection ")  + ("conn_tGreenplumConnection_1")  + (" to the database.") );
        conn_tGreenplumClose_5.close();
                if(log.isDebugEnabled())
            log.debug("tGreenplumClose_5 - "  + ("Connection ")  + ("conn_tGreenplumConnection_1")  + (" to the database has closed.") );
	}

 


	tos_count_tGreenplumClose_5++;

/**
 * [tGreenplumClose_5 main ] stop
 */
	
	/**
	 * [tGreenplumClose_5 end ] start
	 */

	

	
	
	currentComponent="tGreenplumClose_5";

	

 
                if(log.isDebugEnabled())
            log.debug("tGreenplumClose_5 - "  + ("Done.") );

ok_Hash.put("tGreenplumClose_5", true);
end_Hash.put("tGreenplumClose_5", System.currentTimeMillis());

				if(execStat){   
   	 				runStat.updateStatOnConnection("OnComponentOk34", 0, "ok");
				}
				tFileInputFullRow_1Process(globalMap);



/**
 * [tGreenplumClose_5 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage());
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tGreenplumClose_5 finally ] start
	 */

	

	
	
	currentComponent="tGreenplumClose_5";

	

 



/**
 * [tGreenplumClose_5 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tGreenplumClose_5_SUBPROCESS_STATE", 1);
	}
	


public static class row9Struct implements routines.system.IPersistableRow<row9Struct> {
    final static byte[] commonByteArrayLock_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Prod2Dev_with_GP_FDIST_child = new byte[0];
    static byte[] commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Prod2Dev_with_GP_FDIST_child = new byte[0];

	
			    public String line;

				public String getLine () {
					return this.line;
				}
				



	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Prod2Dev_with_GP_FDIST_child.length) {
				if(length < 1024 && commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Prod2Dev_with_GP_FDIST_child.length == 0) {
   					commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Prod2Dev_with_GP_FDIST_child = new byte[1024];
				} else {
   					commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Prod2Dev_with_GP_FDIST_child = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Prod2Dev_with_GP_FDIST_child, 0, length);
			strReturn = new String(commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Prod2Dev_with_GP_FDIST_child, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Prod2Dev_with_GP_FDIST_child) {

        	try {

        		int length = 0;
		
					this.line = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// String
				
						writeString(this.line,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("line="+line);
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				if(line == null){
        					sb.append("<null>");
        				}else{
            				sb.append(line);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(row9Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}
public void tFileInputFullRow_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tFileInputFullRow_1_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;



		row9Struct row9 = new row9Struct();




	
	/**
	 * [tJavaRow_2 begin ] start
	 */

	

	
		
		ok_Hash.put("tJavaRow_2", false);
		start_Hash.put("tJavaRow_2", System.currentTimeMillis());
		
	
	currentComponent="tJavaRow_2";

	
			if (execStat) {
				if(resourceMap.get("inIterateVComp") == null){
					
						runStat.updateStatOnConnection("row9" + iterateId, 0, 0);
					
				}
			} 

		
		int tos_count_tJavaRow_2 = 0;
		
    	class BytesLimit65535_tJavaRow_2{
    		public void limitLog4jByte() throws Exception{
    			
    		}
    	}
    	
        new BytesLimit65535_tJavaRow_2().limitLog4jByte();

int nb_line_tJavaRow_2 = 0;

 



/**
 * [tJavaRow_2 begin ] stop
 */



	
	/**
	 * [tFileInputFullRow_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tFileInputFullRow_1", false);
		start_Hash.put("tFileInputFullRow_1", System.currentTimeMillis());
		
	
	currentComponent="tFileInputFullRow_1";

	
		int tos_count_tFileInputFullRow_1 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tFileInputFullRow_1 - "  + ("Start to work.") );
    	class BytesLimit65535_tFileInputFullRow_1{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tFileInputFullRow_1 = new StringBuilder();
            log4jParamters_tFileInputFullRow_1.append("Parameters:");
                    log4jParamters_tFileInputFullRow_1.append("FILENAME" + " = " + "context.ETL_STORAGE_PATH + \"/\" +context.GP_SOURCE_NAME + \"/data/\" + context.SOURCE_DATABASE  + \"/\" + ((String)globalMap.get(\"row7.log_table_name\")).replace(\"\\\"\",\"\").replace(\"#\",\"__hash__\").replace(\"$\",\"__dollar__\")  + new SimpleDateFormat(\"yyyyMMddHHmmss\").format(((java.util.Date)globalMap.get(\"row7.now\"))).toString() + \".log\"");
                log4jParamters_tFileInputFullRow_1.append(" | ");
                    log4jParamters_tFileInputFullRow_1.append("ROWSEPARATOR" + " = " + "\"\\n\"");
                log4jParamters_tFileInputFullRow_1.append(" | ");
                    log4jParamters_tFileInputFullRow_1.append("HEADER" + " = " + "");
                log4jParamters_tFileInputFullRow_1.append(" | ");
                    log4jParamters_tFileInputFullRow_1.append("FOOTER" + " = " + "");
                log4jParamters_tFileInputFullRow_1.append(" | ");
                    log4jParamters_tFileInputFullRow_1.append("LIMIT" + " = " + "");
                log4jParamters_tFileInputFullRow_1.append(" | ");
                    log4jParamters_tFileInputFullRow_1.append("REMOVE_EMPTY_ROW" + " = " + "true");
                log4jParamters_tFileInputFullRow_1.append(" | ");
                    log4jParamters_tFileInputFullRow_1.append("ENCODING" + " = " + "\"ISO-8859-15\"");
                log4jParamters_tFileInputFullRow_1.append(" | ");
                    log4jParamters_tFileInputFullRow_1.append("RANDOM" + " = " + "false");
                log4jParamters_tFileInputFullRow_1.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tFileInputFullRow_1 - "  + (log4jParamters_tFileInputFullRow_1) );
    		}
    	}
    	
        new BytesLimit65535_tFileInputFullRow_1().limitLog4jByte();

				final StringBuffer log4jSb_tFileInputFullRow_1 = new StringBuffer();
			
	org.talend.fileprocess.FileInputDelimited fid_tFileInputFullRow_1 = null;

					log.debug("tFileInputFullRow_1 - Retrieving records from the datasource.");
			

	try{//}
		fid_tFileInputFullRow_1 =new org.talend.fileprocess.FileInputDelimited(context.ETL_STORAGE_PATH + "/" +context.GP_SOURCE_NAME + "/data/" + context.SOURCE_DATABASE  + "/" + ((String)globalMap.get("row7.log_table_name")).replace("\"","").replace("#","__hash__").replace("$","__dollar__")  + new SimpleDateFormat("yyyyMMddHHmmss").format(((java.util.Date)globalMap.get("row7.now"))).toString() + ".log","ISO-8859-15","","\n",true,0,0,-1,-1,false);
		while (fid_tFileInputFullRow_1.nextRecord()) {//}
			row9 = null;						
	boolean whetherReject_tFileInputFullRow_1 = false;
	row9 = new row9Struct();
		row9.line = fid_tFileInputFullRow_1.get(0);

 



/**
 * [tFileInputFullRow_1 begin ] stop
 */
	
	/**
	 * [tFileInputFullRow_1 main ] start
	 */

	

	
	
	currentComponent="tFileInputFullRow_1";

	

 


	tos_count_tFileInputFullRow_1++;

/**
 * [tFileInputFullRow_1 main ] stop
 */

	
	/**
	 * [tJavaRow_2 main ] start
	 */

	

	
	
	currentComponent="tJavaRow_2";

	

			//row9
			//row9


			
				if(execStat){
					runStat.updateStatOnConnection("row9"+iterateId,1, 1);
				} 
			

		
    			if(log.isTraceEnabled()){
    				log.trace("row9 - " + (row9==null? "": row9.toLogString()));
    			}
    		

    
String line = row9.line;
if(line.contains("|INFO|rows Inserted")){
	System.out.println("gpload_inserted: " + String.valueOf(Integer.parseInt(line.substring(line.indexOf("=")+1).replace(" ",""))));
} else
if(line.contains("|INFO|rows Updated")){
	System.out.println("gpload_updated: " + String.valueOf(Integer.parseInt(line.substring(line.indexOf("=")+1).replace(" ",""))));
} else if(line.contains("|INFO|data formatting errors =")){
	System.out.println("gpload_data_errors: " +  String.valueOf(Integer.parseInt(line.substring(line.indexOf("=")+1).replace(" ",""))));
} else if(line.contains("|INFO|gpload ") && !line.contains("session")){
	System.out.println("gpload_status: " + line.substring(line.indexOf("gpload ")+7).replace(" ",""));
} else if(line.contains("|INFO|running time:")){
	line = line.substring(line.indexOf("time: ")+5).replace(" ","");
	System.out.println("gpload_runtime: " + line.substring(0,line.indexOf("seconds")));
} else if(line.contains("|ERROR|")){
	line = line.substring(line.indexOf("|ERROR|")+7);
	if(line.length()>1250) {
		String tmp = line.substring(0, 1000);
		tmp += ".....";
		tmp += line.substring(line.length()-200);
		line = tmp;
	}
	globalMap.put("tJavaRow_2_ERROR_MESSAGE", line);
}

    nb_line_tJavaRow_2++;   

 


	tos_count_tJavaRow_2++;

/**
 * [tJavaRow_2 main ] stop
 */



	
	/**
	 * [tFileInputFullRow_1 end ] start
	 */

	

	
	
	currentComponent="tFileInputFullRow_1";

	

	


            }
           	}finally{
           		if(fid_tFileInputFullRow_1!=null){
            		fid_tFileInputFullRow_1.close();
            	}
            }
            globalMap.put("tFileInputFullRow_1_NB_LINE", fid_tFileInputFullRow_1.getRowNumber());
				log.debug("tFileInputFullRow_1 - Retrieved records count: "+ globalMap.get("tFileInputFullRow_1_NB_LINE") + " .");
			
 
                if(log.isDebugEnabled())
            log.debug("tFileInputFullRow_1 - "  + ("Done.") );

ok_Hash.put("tFileInputFullRow_1", true);
end_Hash.put("tFileInputFullRow_1", System.currentTimeMillis());




/**
 * [tFileInputFullRow_1 end ] stop
 */

	
	/**
	 * [tJavaRow_2 end ] start
	 */

	

	
	
	currentComponent="tJavaRow_2";

	

globalMap.put("tJavaRow_2_NB_LINE",nb_line_tJavaRow_2);
			if(execStat){
				if(resourceMap.get("inIterateVComp") == null || !((Boolean)resourceMap.get("inIterateVComp"))){
			 		runStat.updateStatOnConnection("row9"+iterateId,2, 0); 
			 	}
			}
		
 

ok_Hash.put("tJavaRow_2", true);
end_Hash.put("tJavaRow_2", System.currentTimeMillis());

   			if (((String)globalMap.get("tJavaRow_2_ERROR_MESSAGE")) != null
) {
   				
					if(execStat){   
   	 					runStat.updateStatOnConnection("If8", 0, "true");
					}
				
    			tWarn_1Process(globalMap);
   			}

			   
   				else{
					if(execStat){   
   	 					runStat.updateStatOnConnection("If8", 0, "false");
					}   	 
   				}
   			if (((String)globalMap.get("tJavaRow_2_ERROR_MESSAGE")) == null) {
   				
					if(execStat){   
   	 					runStat.updateStatOnConnection("If9", 0, "true");
					}
				
    			tGreenplumConnection_11Process(globalMap);
   			}

			   
   				else{
					if(execStat){   
   	 					runStat.updateStatOnConnection("If9", 0, "false");
					}   	 
   				}



/**
 * [tJavaRow_2 end ] stop
 */



				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage());
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tFileInputFullRow_1 finally ] start
	 */

	

	
	
	currentComponent="tFileInputFullRow_1";

	

 



/**
 * [tFileInputFullRow_1 finally ] stop
 */

	
	/**
	 * [tJavaRow_2 finally ] start
	 */

	

	
	
	currentComponent="tJavaRow_2";

	

 



/**
 * [tJavaRow_2 finally ] stop
 */



				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tFileInputFullRow_1_SUBPROCESS_STATE", 1);
	}
	

public void tWarn_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tWarn_1_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;





	
	/**
	 * [tWarn_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tWarn_1", false);
		start_Hash.put("tWarn_1", System.currentTimeMillis());
		
	
	currentComponent="tWarn_1";

	
		int tos_count_tWarn_1 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tWarn_1 - "  + ("Start to work.") );
    	class BytesLimit65535_tWarn_1{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tWarn_1 = new StringBuilder();
            log4jParamters_tWarn_1.append("Parameters:");
                    log4jParamters_tWarn_1.append("MESSAGE" + " = " + "\"GPload: An error has occurred.\"+((String)globalMap.get(\"tJavaRow_2_ERROR_MESSAGE\"))+\" See the log file...\"");
                log4jParamters_tWarn_1.append(" | ");
                    log4jParamters_tWarn_1.append("CODE" + " = " + "666");
                log4jParamters_tWarn_1.append(" | ");
                    log4jParamters_tWarn_1.append("PRIORITY" + " = " + "6");
                log4jParamters_tWarn_1.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tWarn_1 - "  + (log4jParamters_tWarn_1) );
    		}
    	}
    	
        new BytesLimit65535_tWarn_1().limitLog4jByte();

 



/**
 * [tWarn_1 begin ] stop
 */
	
	/**
	 * [tWarn_1 main ] start
	 */

	

	
	
	currentComponent="tWarn_1";

	

		
	resumeUtil.addLog("USER_DEF_LOG", "NODE:tWarn_1", "", Thread.currentThread().getId() + "", "FATAL","","GPload: An error has occurred."+((String)globalMap.get("tJavaRow_2_ERROR_MESSAGE"))+" See the log file...","", "");
            log.fatal("tWarn_1 - "  + ("Message: ")  + ("GPload: An error has occurred."+((String)globalMap.get("tJavaRow_2_ERROR_MESSAGE"))+" See the log file...")  + (". Code: ")  + (666) );
                if(log.isDebugEnabled())
            log.debug("tWarn_1 - "  + ("Sending message to tLogCatcher_2.") );
	tLogCatcher_2.addMessage("tWarn", "tWarn_1", 6, "GPload: An error has occurred."+((String)globalMap.get("tJavaRow_2_ERROR_MESSAGE"))+" See the log file...", 666);
	tLogCatcher_2Process(globalMap);
                if(log.isDebugEnabled())
            log.debug("tWarn_1 - "  + ("Sending message to talendLogs_LOGS.") );
	talendLogs_LOGS.addMessage("tWarn", "tWarn_1", 6, "GPload: An error has occurred."+((String)globalMap.get("tJavaRow_2_ERROR_MESSAGE"))+" See the log file...", 666);
	talendLogs_LOGSProcess(globalMap);
globalMap.put("tWarn_1_WARN_MESSAGES", "GPload: An error has occurred."+((String)globalMap.get("tJavaRow_2_ERROR_MESSAGE"))+" See the log file..."); 
globalMap.put("tWarn_1_WARN_PRIORITY", 6);
globalMap.put("tWarn_1_WARN_CODE", 666);


 


	tos_count_tWarn_1++;

/**
 * [tWarn_1 main ] stop
 */
	
	/**
	 * [tWarn_1 end ] start
	 */

	

	
	
	currentComponent="tWarn_1";

	

 
                if(log.isDebugEnabled())
            log.debug("tWarn_1 - "  + ("Done.") );

ok_Hash.put("tWarn_1", true);
end_Hash.put("tWarn_1", System.currentTimeMillis());




/**
 * [tWarn_1 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage());
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tWarn_1 finally ] start
	 */

	

	
	
	currentComponent="tWarn_1";

	

 



/**
 * [tWarn_1 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tWarn_1_SUBPROCESS_STATE", 1);
	}
	

public void tGreenplumRow_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tGreenplumRow_1_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tGreenplumRow_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tGreenplumRow_1", false);
		start_Hash.put("tGreenplumRow_1", System.currentTimeMillis());
		
	
	currentComponent="tGreenplumRow_1";

	
		int tos_count_tGreenplumRow_1 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tGreenplumRow_1 - "  + ("Start to work.") );
    	class BytesLimit65535_tGreenplumRow_1{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tGreenplumRow_1 = new StringBuilder();
            log4jParamters_tGreenplumRow_1.append("Parameters:");
                    log4jParamters_tGreenplumRow_1.append("USE_EXISTING_CONNECTION" + " = " + "true");
                log4jParamters_tGreenplumRow_1.append(" | ");
                    log4jParamters_tGreenplumRow_1.append("CONNECTION" + " = " + "tGreenplumConnection_1");
                log4jParamters_tGreenplumRow_1.append(" | ");
                    log4jParamters_tGreenplumRow_1.append("QUERYSTORE" + " = " + "\"\"");
                log4jParamters_tGreenplumRow_1.append(" | ");
                    log4jParamters_tGreenplumRow_1.append("QUERY" + " = " + "\"truncate table \" + (String)globalMap.get(\"row7.target_schema\") + \".\" + (String)globalMap.get(\"row7.log_table_name\")");
                log4jParamters_tGreenplumRow_1.append(" | ");
                    log4jParamters_tGreenplumRow_1.append("DIE_ON_ERROR" + " = " + "false");
                log4jParamters_tGreenplumRow_1.append(" | ");
                    log4jParamters_tGreenplumRow_1.append("PROPAGATE_RECORD_SET" + " = " + "false");
                log4jParamters_tGreenplumRow_1.append(" | ");
                    log4jParamters_tGreenplumRow_1.append("USE_PREPAREDSTATEMENT" + " = " + "false");
                log4jParamters_tGreenplumRow_1.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tGreenplumRow_1 - "  + (log4jParamters_tGreenplumRow_1) );
    		}
    	}
    	
        new BytesLimit65535_tGreenplumRow_1().limitLog4jByte();

	java.sql.Connection conn_tGreenplumRow_1 = null;
	String query_tGreenplumRow_1 = "";
	boolean whetherReject_tGreenplumRow_1 = false;
				conn_tGreenplumRow_1 = (java.sql.Connection)globalMap.get("conn_tGreenplumConnection_1");
			
				if(conn_tGreenplumRow_1 != null) {
					if(conn_tGreenplumRow_1.getMetaData() != null) {
						
						log.debug("tGreenplumRow_1 - Uses an existing connection with username '" + conn_tGreenplumRow_1.getMetaData().getUserName() + "'. Connection URL: " + conn_tGreenplumRow_1.getMetaData().getURL() + ".");
						
					}
				}
			
		java.sql.Statement stmt_tGreenplumRow_1 = conn_tGreenplumRow_1.createStatement();
	

 



/**
 * [tGreenplumRow_1 begin ] stop
 */
	
	/**
	 * [tGreenplumRow_1 main ] start
	 */

	

	
	
	currentComponent="tGreenplumRow_1";

	

	    		log.debug("tGreenplumRow_1 - Executing the query: '" + "truncate table " + (String)globalMap.get("row7.target_schema") + "." + (String)globalMap.get("row7.log_table_name") + "'.");
			
query_tGreenplumRow_1 = "truncate table " + (String)globalMap.get("row7.target_schema") + "." + (String)globalMap.get("row7.log_table_name");
whetherReject_tGreenplumRow_1 = false;
globalMap.put("tGreenplumRow_1_QUERY",query_tGreenplumRow_1);
try {
		stmt_tGreenplumRow_1.execute(query_tGreenplumRow_1);
		
	    		log.info("tGreenplumRow_1 - Execute the query: '" + "truncate table " + (String)globalMap.get("row7.target_schema") + "." + (String)globalMap.get("row7.log_table_name") + "' has finished.");
			
	} catch (java.lang.Exception e) {
		whetherReject_tGreenplumRow_1 = true;
		
				log.error("tGreenplumRow_1 - " + e.getMessage());
			
				System.err.print(e.getMessage());
				
	}
	
	if(!whetherReject_tGreenplumRow_1) {
		
	}
	

 


	tos_count_tGreenplumRow_1++;

/**
 * [tGreenplumRow_1 main ] stop
 */
	
	/**
	 * [tGreenplumRow_1 end ] start
	 */

	

	
	
	currentComponent="tGreenplumRow_1";

	

	
	stmt_tGreenplumRow_1.close();	

 
                if(log.isDebugEnabled())
            log.debug("tGreenplumRow_1 - "  + ("Done.") );

ok_Hash.put("tGreenplumRow_1", true);
end_Hash.put("tGreenplumRow_1", System.currentTimeMillis());

				if(execStat){   
   	 				runStat.updateStatOnConnection("OnComponentOk7", 0, "ok");
				}
				tGEGreenplumGPLoad_2Process(globalMap);



/**
 * [tGreenplumRow_1 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage());
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tGreenplumRow_1 finally ] start
	 */

	

	
	
	currentComponent="tGreenplumRow_1";

	

 



/**
 * [tGreenplumRow_1 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tGreenplumRow_1_SUBPROCESS_STATE", 1);
	}
	

public void tJava_20Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tJava_20_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;





	
	/**
	 * [tJava_20 begin ] start
	 */

	

	
		
		ok_Hash.put("tJava_20", false);
		start_Hash.put("tJava_20", System.currentTimeMillis());
		
	
	currentComponent="tJava_20";

	
		int tos_count_tJava_20 = 0;
		
    	class BytesLimit65535_tJava_20{
    		public void limitLog4jByte() throws Exception{
    			
    		}
    	}
    	
        new BytesLimit65535_tJava_20().limitLog4jByte();



Runtime r = Runtime.getRuntime();
//Process p = r.exec("gpfdist -p 8216 -P 8888 & echo $!");
System.out.println("kill "+((String)globalMap.get("row12.outputline")));
Process p = r.exec("kill "+((String)globalMap.get("row12.outputline")));
p.waitFor();


BufferedReader b = new BufferedReader(new InputStreamReader(p.getInputStream()));
String line = "";

while ((line = b.readLine()) != null) {
  System.out.println(line);
}

b.close();

 



/**
 * [tJava_20 begin ] stop
 */
	
	/**
	 * [tJava_20 main ] start
	 */

	

	
	
	currentComponent="tJava_20";

	

 


	tos_count_tJava_20++;

/**
 * [tJava_20 main ] stop
 */
	
	/**
	 * [tJava_20 end ] start
	 */

	

	
	
	currentComponent="tJava_20";

	

 

ok_Hash.put("tJava_20", true);
end_Hash.put("tJava_20", System.currentTimeMillis());




/**
 * [tJava_20 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage());
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tJava_20 finally ] start
	 */

	

	
	
	currentComponent="tJava_20";

	

 



/**
 * [tJava_20 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tJava_20_SUBPROCESS_STATE", 1);
	}
	

public void tPostgresqlClose_2Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tPostgresqlClose_2_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;





	
	/**
	 * [tPostgresqlClose_2 begin ] start
	 */

	

	
		
		ok_Hash.put("tPostgresqlClose_2", false);
		start_Hash.put("tPostgresqlClose_2", System.currentTimeMillis());
		
	
	currentComponent="tPostgresqlClose_2";

	
		int tos_count_tPostgresqlClose_2 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tPostgresqlClose_2 - "  + ("Start to work.") );
    	class BytesLimit65535_tPostgresqlClose_2{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tPostgresqlClose_2 = new StringBuilder();
            log4jParamters_tPostgresqlClose_2.append("Parameters:");
                    log4jParamters_tPostgresqlClose_2.append("CONNECTION" + " = " + "tPostgresqlConnection_1");
                log4jParamters_tPostgresqlClose_2.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tPostgresqlClose_2 - "  + (log4jParamters_tPostgresqlClose_2) );
    		}
    	}
    	
        new BytesLimit65535_tPostgresqlClose_2().limitLog4jByte();

 



/**
 * [tPostgresqlClose_2 begin ] stop
 */
	
	/**
	 * [tPostgresqlClose_2 main ] start
	 */

	

	
	
	currentComponent="tPostgresqlClose_2";

	



	java.sql.Connection conn_tPostgresqlClose_2 = (java.sql.Connection)globalMap.get("conn_tPostgresqlConnection_1");
	if(conn_tPostgresqlClose_2 != null && !conn_tPostgresqlClose_2.isClosed())
	{
                if(log.isDebugEnabled())
            log.debug("tPostgresqlClose_2 - "  + ("Closing the connection ")  + ("conn_tPostgresqlConnection_1")  + (" to the database.") );
        conn_tPostgresqlClose_2.close();
                if(log.isDebugEnabled())
            log.debug("tPostgresqlClose_2 - "  + ("Connection ")  + ("conn_tPostgresqlConnection_1")  + (" to the database has closed.") );
	}

 


	tos_count_tPostgresqlClose_2++;

/**
 * [tPostgresqlClose_2 main ] stop
 */
	
	/**
	 * [tPostgresqlClose_2 end ] start
	 */

	

	
	
	currentComponent="tPostgresqlClose_2";

	

 
                if(log.isDebugEnabled())
            log.debug("tPostgresqlClose_2 - "  + ("Done.") );

ok_Hash.put("tPostgresqlClose_2", true);
end_Hash.put("tPostgresqlClose_2", System.currentTimeMillis());




/**
 * [tPostgresqlClose_2 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage());
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tPostgresqlClose_2 finally ] start
	 */

	

	
	
	currentComponent="tPostgresqlClose_2";

	

 



/**
 * [tPostgresqlClose_2 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tPostgresqlClose_2_SUBPROCESS_STATE", 1);
	}
	

public void tGreenplumClose_4Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tGreenplumClose_4_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;





	
	/**
	 * [tGreenplumClose_4 begin ] start
	 */

	

	
		
		ok_Hash.put("tGreenplumClose_4", false);
		start_Hash.put("tGreenplumClose_4", System.currentTimeMillis());
		
	
	currentComponent="tGreenplumClose_4";

	
		int tos_count_tGreenplumClose_4 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tGreenplumClose_4 - "  + ("Start to work.") );
    	class BytesLimit65535_tGreenplumClose_4{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tGreenplumClose_4 = new StringBuilder();
            log4jParamters_tGreenplumClose_4.append("Parameters:");
                    log4jParamters_tGreenplumClose_4.append("CONNECTION" + " = " + "tGreenplumConnection_2");
                log4jParamters_tGreenplumClose_4.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tGreenplumClose_4 - "  + (log4jParamters_tGreenplumClose_4) );
    		}
    	}
    	
        new BytesLimit65535_tGreenplumClose_4().limitLog4jByte();

 



/**
 * [tGreenplumClose_4 begin ] stop
 */
	
	/**
	 * [tGreenplumClose_4 main ] start
	 */

	

	
	
	currentComponent="tGreenplumClose_4";

	



	java.sql.Connection conn_tGreenplumClose_4 = (java.sql.Connection)globalMap.get("conn_tGreenplumConnection_2");
	if(conn_tGreenplumClose_4 != null && !conn_tGreenplumClose_4.isClosed())
	{
                if(log.isDebugEnabled())
            log.debug("tGreenplumClose_4 - "  + ("Closing the connection ")  + ("conn_tGreenplumConnection_2")  + (" to the database.") );
        conn_tGreenplumClose_4.close();
                if(log.isDebugEnabled())
            log.debug("tGreenplumClose_4 - "  + ("Connection ")  + ("conn_tGreenplumConnection_2")  + (" to the database has closed.") );
	}

 


	tos_count_tGreenplumClose_4++;

/**
 * [tGreenplumClose_4 main ] stop
 */
	
	/**
	 * [tGreenplumClose_4 end ] start
	 */

	

	
	
	currentComponent="tGreenplumClose_4";

	

 
                if(log.isDebugEnabled())
            log.debug("tGreenplumClose_4 - "  + ("Done.") );

ok_Hash.put("tGreenplumClose_4", true);
end_Hash.put("tGreenplumClose_4", System.currentTimeMillis());




/**
 * [tGreenplumClose_4 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage());
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tGreenplumClose_4 finally ] start
	 */

	

	
	
	currentComponent="tGreenplumClose_4";

	

 



/**
 * [tGreenplumClose_4 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tGreenplumClose_4_SUBPROCESS_STATE", 1);
	}
	

public void tPostgresqlClose_3Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tPostgresqlClose_3_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;





	
	/**
	 * [tPostgresqlClose_3 begin ] start
	 */

	

	
		
		ok_Hash.put("tPostgresqlClose_3", false);
		start_Hash.put("tPostgresqlClose_3", System.currentTimeMillis());
		
	
	currentComponent="tPostgresqlClose_3";

	
		int tos_count_tPostgresqlClose_3 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tPostgresqlClose_3 - "  + ("Start to work.") );
    	class BytesLimit65535_tPostgresqlClose_3{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tPostgresqlClose_3 = new StringBuilder();
            log4jParamters_tPostgresqlClose_3.append("Parameters:");
                    log4jParamters_tPostgresqlClose_3.append("CONNECTION" + " = " + "tPostgresqlConnection_1");
                log4jParamters_tPostgresqlClose_3.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tPostgresqlClose_3 - "  + (log4jParamters_tPostgresqlClose_3) );
    		}
    	}
    	
        new BytesLimit65535_tPostgresqlClose_3().limitLog4jByte();

 



/**
 * [tPostgresqlClose_3 begin ] stop
 */
	
	/**
	 * [tPostgresqlClose_3 main ] start
	 */

	

	
	
	currentComponent="tPostgresqlClose_3";

	



	java.sql.Connection conn_tPostgresqlClose_3 = (java.sql.Connection)globalMap.get("conn_tPostgresqlConnection_1");
	if(conn_tPostgresqlClose_3 != null && !conn_tPostgresqlClose_3.isClosed())
	{
                if(log.isDebugEnabled())
            log.debug("tPostgresqlClose_3 - "  + ("Closing the connection ")  + ("conn_tPostgresqlConnection_1")  + (" to the database.") );
        conn_tPostgresqlClose_3.close();
                if(log.isDebugEnabled())
            log.debug("tPostgresqlClose_3 - "  + ("Connection ")  + ("conn_tPostgresqlConnection_1")  + (" to the database has closed.") );
	}

 


	tos_count_tPostgresqlClose_3++;

/**
 * [tPostgresqlClose_3 main ] stop
 */
	
	/**
	 * [tPostgresqlClose_3 end ] start
	 */

	

	
	
	currentComponent="tPostgresqlClose_3";

	

 
                if(log.isDebugEnabled())
            log.debug("tPostgresqlClose_3 - "  + ("Done.") );

ok_Hash.put("tPostgresqlClose_3", true);
end_Hash.put("tPostgresqlClose_3", System.currentTimeMillis());




/**
 * [tPostgresqlClose_3 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage());
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tPostgresqlClose_3 finally ] start
	 */

	

	
	
	currentComponent="tPostgresqlClose_3";

	

 



/**
 * [tPostgresqlClose_3 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tPostgresqlClose_3_SUBPROCESS_STATE", 1);
	}
	


public static class row7Struct implements routines.system.IPersistableRow<row7Struct> {
    final static byte[] commonByteArrayLock_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Prod2Dev_with_GP_FDIST_child = new byte[0];
    static byte[] commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Prod2Dev_with_GP_FDIST_child = new byte[0];

	
			    public String source_name;

				public String getSource_name () {
					return this.source_name;
				}
				
			    public String source_table_name;

				public String getSource_table_name () {
					return this.source_table_name;
				}
				
			    public String target_table_name;

				public String getTarget_table_name () {
					return this.target_table_name;
				}
				
			    public String target_table_name_incr;

				public String getTarget_table_name_incr () {
					return this.target_table_name_incr;
				}
				
			    public String log_table_name;

				public String getLog_table_name () {
					return this.log_table_name;
				}
				
			    public String update_type;

				public String getUpdate_type () {
					return this.update_type;
				}
				
			    public String update_col;

				public String getUpdate_col () {
					return this.update_col;
				}
				
			    public java.util.Date last_update_date;

				public java.util.Date getLast_update_date () {
					return this.last_update_date;
				}
				
			    public java.util.Date last_prod2dev_date;

				public java.util.Date getLast_prod2dev_date () {
					return this.last_prod2dev_date;
				}
				
			    public String source_schema;

				public String getSource_schema () {
					return this.source_schema;
				}
				
			    public String target_schema;

				public String getTarget_schema () {
					return this.target_schema;
				}
				
			    public String target_schema_orig;

				public String getTarget_schema_orig () {
					return this.target_schema_orig;
				}
				
			    public java.util.Date now;

				public java.util.Date getNow () {
					return this.now;
				}
				



	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Prod2Dev_with_GP_FDIST_child.length) {
				if(length < 1024 && commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Prod2Dev_with_GP_FDIST_child.length == 0) {
   					commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Prod2Dev_with_GP_FDIST_child = new byte[1024];
				} else {
   					commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Prod2Dev_with_GP_FDIST_child = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Prod2Dev_with_GP_FDIST_child, 0, length);
			strReturn = new String(commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Prod2Dev_with_GP_FDIST_child, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }

	private java.util.Date readDate(ObjectInputStream dis) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(dis.readLong());
		}
		return dateReturn;
	}

    private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException{
		if(date1 == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeLong(date1.getTime());
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Prod2Dev_with_GP_FDIST_child) {

        	try {

        		int length = 0;
		
					this.source_name = readString(dis);
					
					this.source_table_name = readString(dis);
					
					this.target_table_name = readString(dis);
					
					this.target_table_name_incr = readString(dis);
					
					this.log_table_name = readString(dis);
					
					this.update_type = readString(dis);
					
					this.update_col = readString(dis);
					
					this.last_update_date = readDate(dis);
					
					this.last_prod2dev_date = readDate(dis);
					
					this.source_schema = readString(dis);
					
					this.target_schema = readString(dis);
					
					this.target_schema_orig = readString(dis);
					
					this.now = readDate(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// String
				
						writeString(this.source_name,dos);
					
					// String
				
						writeString(this.source_table_name,dos);
					
					// String
				
						writeString(this.target_table_name,dos);
					
					// String
				
						writeString(this.target_table_name_incr,dos);
					
					// String
				
						writeString(this.log_table_name,dos);
					
					// String
				
						writeString(this.update_type,dos);
					
					// String
				
						writeString(this.update_col,dos);
					
					// java.util.Date
				
						writeDate(this.last_update_date,dos);
					
					// java.util.Date
				
						writeDate(this.last_prod2dev_date,dos);
					
					// String
				
						writeString(this.source_schema,dos);
					
					// String
				
						writeString(this.target_schema,dos);
					
					// String
				
						writeString(this.target_schema_orig,dos);
					
					// java.util.Date
				
						writeDate(this.now,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("source_name="+source_name);
		sb.append(",source_table_name="+source_table_name);
		sb.append(",target_table_name="+target_table_name);
		sb.append(",target_table_name_incr="+target_table_name_incr);
		sb.append(",log_table_name="+log_table_name);
		sb.append(",update_type="+update_type);
		sb.append(",update_col="+update_col);
		sb.append(",last_update_date="+String.valueOf(last_update_date));
		sb.append(",last_prod2dev_date="+String.valueOf(last_prod2dev_date));
		sb.append(",source_schema="+source_schema);
		sb.append(",target_schema="+target_schema);
		sb.append(",target_schema_orig="+target_schema_orig);
		sb.append(",now="+String.valueOf(now));
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				if(source_name == null){
        					sb.append("<null>");
        				}else{
            				sb.append(source_name);
            			}
            		
        			sb.append("|");
        		
        				if(source_table_name == null){
        					sb.append("<null>");
        				}else{
            				sb.append(source_table_name);
            			}
            		
        			sb.append("|");
        		
        				if(target_table_name == null){
        					sb.append("<null>");
        				}else{
            				sb.append(target_table_name);
            			}
            		
        			sb.append("|");
        		
        				if(target_table_name_incr == null){
        					sb.append("<null>");
        				}else{
            				sb.append(target_table_name_incr);
            			}
            		
        			sb.append("|");
        		
        				if(log_table_name == null){
        					sb.append("<null>");
        				}else{
            				sb.append(log_table_name);
            			}
            		
        			sb.append("|");
        		
        				if(update_type == null){
        					sb.append("<null>");
        				}else{
            				sb.append(update_type);
            			}
            		
        			sb.append("|");
        		
        				if(update_col == null){
        					sb.append("<null>");
        				}else{
            				sb.append(update_col);
            			}
            		
        			sb.append("|");
        		
        				if(last_update_date == null){
        					sb.append("<null>");
        				}else{
            				sb.append(last_update_date);
            			}
            		
        			sb.append("|");
        		
        				if(last_prod2dev_date == null){
        					sb.append("<null>");
        				}else{
            				sb.append(last_prod2dev_date);
            			}
            		
        			sb.append("|");
        		
        				if(source_schema == null){
        					sb.append("<null>");
        				}else{
            				sb.append(source_schema);
            			}
            		
        			sb.append("|");
        		
        				if(target_schema == null){
        					sb.append("<null>");
        				}else{
            				sb.append(target_schema);
            			}
            		
        			sb.append("|");
        		
        				if(target_schema_orig == null){
        					sb.append("<null>");
        				}else{
            				sb.append(target_schema_orig);
            			}
            		
        			sb.append("|");
        		
        				if(now == null){
        					sb.append("<null>");
        				}else{
            				sb.append(now);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(row7Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}
public void tGreenplumInput_4Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tGreenplumInput_4_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;



		row7Struct row7 = new row7Struct();




	
	/**
	 * [tFlowToIterate_7 begin ] start
	 */

				
			int NB_ITERATE_tSetGlobalVar_1 = 0; //for statistics
			

	
		
		ok_Hash.put("tFlowToIterate_7", false);
		start_Hash.put("tFlowToIterate_7", System.currentTimeMillis());
		
	
	currentComponent="tFlowToIterate_7";

	
			if (execStat) {
				if(resourceMap.get("inIterateVComp") == null){
					
						runStat.updateStatOnConnection("row7" + iterateId, 0, 0);
					
				}
			} 

		
		int tos_count_tFlowToIterate_7 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tFlowToIterate_7 - "  + ("Start to work.") );
    	class BytesLimit65535_tFlowToIterate_7{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tFlowToIterate_7 = new StringBuilder();
            log4jParamters_tFlowToIterate_7.append("Parameters:");
                    log4jParamters_tFlowToIterate_7.append("DEFAULT_MAP" + " = " + "true");
                log4jParamters_tFlowToIterate_7.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tFlowToIterate_7 - "  + (log4jParamters_tFlowToIterate_7) );
    		}
    	}
    	
        new BytesLimit65535_tFlowToIterate_7().limitLog4jByte();

int nb_line_tFlowToIterate_7 = 0;
int counter_tFlowToIterate_7 = 0;

 



/**
 * [tFlowToIterate_7 begin ] stop
 */



	
	/**
	 * [tGreenplumInput_4 begin ] start
	 */

	

	
		
		ok_Hash.put("tGreenplumInput_4", false);
		start_Hash.put("tGreenplumInput_4", System.currentTimeMillis());
		
	
	currentComponent="tGreenplumInput_4";

	
		int tos_count_tGreenplumInput_4 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tGreenplumInput_4 - "  + ("Start to work.") );
    	class BytesLimit65535_tGreenplumInput_4{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tGreenplumInput_4 = new StringBuilder();
            log4jParamters_tGreenplumInput_4.append("Parameters:");
                    log4jParamters_tGreenplumInput_4.append("USE_EXISTING_CONNECTION" + " = " + "true");
                log4jParamters_tGreenplumInput_4.append(" | ");
                    log4jParamters_tGreenplumInput_4.append("CONNECTION" + " = " + "tGreenplumConnection_7");
                log4jParamters_tGreenplumInput_4.append(" | ");
                    log4jParamters_tGreenplumInput_4.append("TABLE" + " = " + "\"\"");
                log4jParamters_tGreenplumInput_4.append(" | ");
                    log4jParamters_tGreenplumInput_4.append("QUERYSTORE" + " = " + "\"\"");
                log4jParamters_tGreenplumInput_4.append(" | ");
                    log4jParamters_tGreenplumInput_4.append("QUERY" + " = " + "\"SELECT system_name,   source_table_name,   target_table_name,  case when update_type='Incremental' then LOWER(target_schema)||'_'||target_table_name else target_table_name    end target_table_name_incr,  target_table_name as log_table_name,  case when last_prod2dev_date is null  then 'Full'   else update_type  end as update_type,   update_col,   last_update_date,  last_prod2dev_date,  source_schema,   target_schema,   lower(target_schema)   as target_schema_orig,  now() as now   FROM sbdt.edl_table t   WHERE system_name = '\" + context.getProperty(\"GP_SOURCE_NAME\") +   \"' and update_type in ('Incremental', 'Full','Softdelete','Append') and source_schema <> 'na'\" +  context.getProperty(\"TABLE_NAME\")");
                log4jParamters_tGreenplumInput_4.append(" | ");
                    log4jParamters_tGreenplumInput_4.append("USE_CURSOR" + " = " + "false");
                log4jParamters_tGreenplumInput_4.append(" | ");
                    log4jParamters_tGreenplumInput_4.append("TRIM_ALL_COLUMN" + " = " + "false");
                log4jParamters_tGreenplumInput_4.append(" | ");
                    log4jParamters_tGreenplumInput_4.append("TRIM_COLUMN" + " = " + "[{TRIM="+("false")+", SCHEMA_COLUMN="+("source_name")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("source_table_name")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("target_table_name")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("target_table_name_incr")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("log_table_name")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("update_type")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("update_col")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("last_update_date")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("last_prod2dev_date")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("source_schema")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("target_schema")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("target_schema_orig")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("now")+"}]");
                log4jParamters_tGreenplumInput_4.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tGreenplumInput_4 - "  + (log4jParamters_tGreenplumInput_4) );
    		}
    	}
    	
        new BytesLimit65535_tGreenplumInput_4().limitLog4jByte();
	
    
	
		    int nb_line_tGreenplumInput_4 = 0;
		    java.sql.Connection conn_tGreenplumInput_4 = null;
		        conn_tGreenplumInput_4 = (java.sql.Connection)globalMap.get("conn_tGreenplumConnection_7");
				
				if(conn_tGreenplumInput_4 != null) {
					if(conn_tGreenplumInput_4.getMetaData() != null) {
						
						log.debug("tGreenplumInput_4 - Uses an existing connection with username '" + conn_tGreenplumInput_4.getMetaData().getUserName() + "'. Connection URL: " + conn_tGreenplumInput_4.getMetaData().getURL() + ".");
						
					}
				}
			
		    
			java.sql.Statement stmt_tGreenplumInput_4 = conn_tGreenplumInput_4.createStatement();

		    String dbquery_tGreenplumInput_4 = "SELECT system_name, \nsource_table_name, \ntarget_table_name,\ncase when update_type='Incremental' then LOWER(target_schema)||'_'||target_table_name else target_table_name \n end target_table_name_incr,\ntarget_table_name as log_table_name,\ncase when last_prod2dev_date is null  then 'Full' \nelse update_type\nend as update_type, \nupdate_col, \nlast_update_date,\nlast_prod2dev_date,\nsource_schema, \ntarget_schema, \nlower(target_schema) \nas target_schema_orig,\nnow() as now \nFROM sbdt.edl_table t \nWHERE system_name = '" + context.getProperty("GP_SOURCE_NAME") + 
"' and update_type in ('Incremental', 'Full','Softdelete','Append') and source_schema <> 'na'" +
context.getProperty("TABLE_NAME");
			
                log.debug("tGreenplumInput_4 - Executing the query: '"+dbquery_tGreenplumInput_4+"'.");
			

                       globalMap.put("tGreenplumInput_4_QUERY",dbquery_tGreenplumInput_4);

		    java.sql.ResultSet rs_tGreenplumInput_4 = null;
		try{
		    rs_tGreenplumInput_4 = stmt_tGreenplumInput_4.executeQuery(dbquery_tGreenplumInput_4);
		    java.sql.ResultSetMetaData rsmd_tGreenplumInput_4 = rs_tGreenplumInput_4.getMetaData();
		    int colQtyInRs_tGreenplumInput_4 = rsmd_tGreenplumInput_4.getColumnCount();

		    String tmpContent_tGreenplumInput_4 = null;
		    
		    
		    	log.debug("tGreenplumInput_4 - Retrieving records from the database.");
		    
		    while (rs_tGreenplumInput_4.next()) {
		        nb_line_tGreenplumInput_4++;
		        
							if(colQtyInRs_tGreenplumInput_4 < 1) {
								row7.source_name = null;
							} else {
	                         		
        	row7.source_name = routines.system.JDBCUtil.getString(rs_tGreenplumInput_4, 1, false);
		                    }
							if(colQtyInRs_tGreenplumInput_4 < 2) {
								row7.source_table_name = null;
							} else {
	                         		
        	row7.source_table_name = routines.system.JDBCUtil.getString(rs_tGreenplumInput_4, 2, false);
		                    }
							if(colQtyInRs_tGreenplumInput_4 < 3) {
								row7.target_table_name = null;
							} else {
	                         		
        	row7.target_table_name = routines.system.JDBCUtil.getString(rs_tGreenplumInput_4, 3, false);
		                    }
							if(colQtyInRs_tGreenplumInput_4 < 4) {
								row7.target_table_name_incr = null;
							} else {
	                         		
        	row7.target_table_name_incr = routines.system.JDBCUtil.getString(rs_tGreenplumInput_4, 4, false);
		                    }
							if(colQtyInRs_tGreenplumInput_4 < 5) {
								row7.log_table_name = null;
							} else {
	                         		
        	row7.log_table_name = routines.system.JDBCUtil.getString(rs_tGreenplumInput_4, 5, false);
		                    }
							if(colQtyInRs_tGreenplumInput_4 < 6) {
								row7.update_type = null;
							} else {
	                         		
        	row7.update_type = routines.system.JDBCUtil.getString(rs_tGreenplumInput_4, 6, false);
		                    }
							if(colQtyInRs_tGreenplumInput_4 < 7) {
								row7.update_col = null;
							} else {
	                         		
        	row7.update_col = routines.system.JDBCUtil.getString(rs_tGreenplumInput_4, 7, false);
		                    }
							if(colQtyInRs_tGreenplumInput_4 < 8) {
								row7.last_update_date = null;
							} else {
										
			row7.last_update_date = routines.system.JDBCUtil.getDate(rs_tGreenplumInput_4, 8);
		                    }
							if(colQtyInRs_tGreenplumInput_4 < 9) {
								row7.last_prod2dev_date = null;
							} else {
										
			row7.last_prod2dev_date = routines.system.JDBCUtil.getDate(rs_tGreenplumInput_4, 9);
		                    }
							if(colQtyInRs_tGreenplumInput_4 < 10) {
								row7.source_schema = null;
							} else {
	                         		
        	row7.source_schema = routines.system.JDBCUtil.getString(rs_tGreenplumInput_4, 10, false);
		                    }
							if(colQtyInRs_tGreenplumInput_4 < 11) {
								row7.target_schema = null;
							} else {
	                         		
        	row7.target_schema = routines.system.JDBCUtil.getString(rs_tGreenplumInput_4, 11, false);
		                    }
							if(colQtyInRs_tGreenplumInput_4 < 12) {
								row7.target_schema_orig = null;
							} else {
	                         		
        	row7.target_schema_orig = routines.system.JDBCUtil.getString(rs_tGreenplumInput_4, 12, false);
		                    }
							if(colQtyInRs_tGreenplumInput_4 < 13) {
								row7.now = null;
							} else {
										
			row7.now = routines.system.JDBCUtil.getDate(rs_tGreenplumInput_4, 13);
		                    }
					
						log.debug("tGreenplumInput_4 - Retrieving the record " + nb_line_tGreenplumInput_4 + ".");
					


 



/**
 * [tGreenplumInput_4 begin ] stop
 */
	
	/**
	 * [tGreenplumInput_4 main ] start
	 */

	

	
	
	currentComponent="tGreenplumInput_4";

	

 


	tos_count_tGreenplumInput_4++;

/**
 * [tGreenplumInput_4 main ] stop
 */

	
	/**
	 * [tFlowToIterate_7 main ] start
	 */

	

	
	
	currentComponent="tFlowToIterate_7";

	

			//row7
			//row7


			
				if(execStat){
					runStat.updateStatOnConnection("row7"+iterateId,1, 1);
				} 
			

		
    			if(log.isTraceEnabled()){
    				log.trace("row7 - " + (row7==null? "": row7.toLogString()));
    			}
    		


    	
                if(log.isTraceEnabled())
            log.trace("tFlowToIterate_7 - "  + ("Set global var, key=row7.source_name, value=")  + (row7.source_name)  + (".") );            
            globalMap.put("row7.source_name", row7.source_name);
    	
                if(log.isTraceEnabled())
            log.trace("tFlowToIterate_7 - "  + ("Set global var, key=row7.source_table_name, value=")  + (row7.source_table_name)  + (".") );            
            globalMap.put("row7.source_table_name", row7.source_table_name);
    	
                if(log.isTraceEnabled())
            log.trace("tFlowToIterate_7 - "  + ("Set global var, key=row7.target_table_name, value=")  + (row7.target_table_name)  + (".") );            
            globalMap.put("row7.target_table_name", row7.target_table_name);
    	
                if(log.isTraceEnabled())
            log.trace("tFlowToIterate_7 - "  + ("Set global var, key=row7.target_table_name_incr, value=")  + (row7.target_table_name_incr)  + (".") );            
            globalMap.put("row7.target_table_name_incr", row7.target_table_name_incr);
    	
                if(log.isTraceEnabled())
            log.trace("tFlowToIterate_7 - "  + ("Set global var, key=row7.log_table_name, value=")  + (row7.log_table_name)  + (".") );            
            globalMap.put("row7.log_table_name", row7.log_table_name);
    	
                if(log.isTraceEnabled())
            log.trace("tFlowToIterate_7 - "  + ("Set global var, key=row7.update_type, value=")  + (row7.update_type)  + (".") );            
            globalMap.put("row7.update_type", row7.update_type);
    	
                if(log.isTraceEnabled())
            log.trace("tFlowToIterate_7 - "  + ("Set global var, key=row7.update_col, value=")  + (row7.update_col)  + (".") );            
            globalMap.put("row7.update_col", row7.update_col);
    	
                if(log.isTraceEnabled())
            log.trace("tFlowToIterate_7 - "  + ("Set global var, key=row7.last_update_date, value=")  + (row7.last_update_date)  + (".") );            
            globalMap.put("row7.last_update_date", row7.last_update_date);
    	
                if(log.isTraceEnabled())
            log.trace("tFlowToIterate_7 - "  + ("Set global var, key=row7.last_prod2dev_date, value=")  + (row7.last_prod2dev_date)  + (".") );            
            globalMap.put("row7.last_prod2dev_date", row7.last_prod2dev_date);
    	
                if(log.isTraceEnabled())
            log.trace("tFlowToIterate_7 - "  + ("Set global var, key=row7.source_schema, value=")  + (row7.source_schema)  + (".") );            
            globalMap.put("row7.source_schema", row7.source_schema);
    	
                if(log.isTraceEnabled())
            log.trace("tFlowToIterate_7 - "  + ("Set global var, key=row7.target_schema, value=")  + (row7.target_schema)  + (".") );            
            globalMap.put("row7.target_schema", row7.target_schema);
    	
                if(log.isTraceEnabled())
            log.trace("tFlowToIterate_7 - "  + ("Set global var, key=row7.target_schema_orig, value=")  + (row7.target_schema_orig)  + (".") );            
            globalMap.put("row7.target_schema_orig", row7.target_schema_orig);
    	
                if(log.isTraceEnabled())
            log.trace("tFlowToIterate_7 - "  + ("Set global var, key=row7.now, value=")  + (row7.now)  + (".") );            
            globalMap.put("row7.now", row7.now);
    	
 
	   nb_line_tFlowToIterate_7++;  
       counter_tFlowToIterate_7++;
                if(log.isDebugEnabled())
            log.debug("tFlowToIterate_7 - "  + ("Current iteration is: ")  + (counter_tFlowToIterate_7)  + (".") );
       globalMap.put("tFlowToIterate_7_CURRENT_ITERATION", counter_tFlowToIterate_7);
 


	tos_count_tFlowToIterate_7++;

/**
 * [tFlowToIterate_7 main ] stop
 */
	NB_ITERATE_tSetGlobalVar_1++;
	
	
					if(execStat){				
	       				runStat.updateStatOnConnection("OnSubjobOk104", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("OnSubjobOk111", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("OnSubjobOk17", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("If5", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("If22", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("OnComponentOk14", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("If43", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("OnSubjobOk79", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("OnComponentOk20", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("If21", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("OnSubjobOk78", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("OnSubjobOk61", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("OnComponentOk18", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("If25", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("OnComponentOk13", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("If15", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("If51", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("OnSubjobOk96", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("If40", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("OnSubjobOk50", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("OnSubjobOk71", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("If13", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("OnComponentOk19", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("OnComponentOk10", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("OnComponentOk29", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("OnSubjobOk110", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("OnComponentOk35", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("OnComponentOk7", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("If28", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("OnSubjobOk7", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("OnComponentOk9", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("row9", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("OnSubjobOk16", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("If12", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("If39", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("If42", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("row12", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("row2", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("OnComponentOk22", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("If1", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("OnComponentOk17", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("OnSubjobOk108", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("row21", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("OnSubjobOk19", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("OnComponentOk27", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("row13", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("If11", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("OnSubjobOk59", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("OnSubjobOk97", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("OnComponentOk33", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("OnSubjobOk103", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("OnComponentOk25", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("row6", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("OnSubjobOk107", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("OnSubjobOk86", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("OnComponentOk5", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("row20", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("iterate7", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("OnSubjobOk14", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("OnSubjobOk72", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("OnComponentOk11", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("OnComponentOk38", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("If14", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("If41", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("OnSubjobOk65", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("If49", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("iterate4", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("If8", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("row19", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("OnComponentOk8", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("OnComponentOk26", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("If9", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("OnSubjobOk15", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("OnComponentOk28", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("OnSubjobOk68", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("OnSubjobError2", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("OnSubjobOk62", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("OnSubjobOk76", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("If38", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("If27", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("row1", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("If6", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("If26", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("iterate3", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("OnComponentOk12", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("row4", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("OnComponentOk34", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("If48", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("OnSubjobOk2", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("iterate8", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("OnComponentOk24", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("OnSubjobOk20", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("OnSubjobError1", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("row5", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("OnSubjobOk64", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("If16", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("row16", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("If20", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("OnComponentOk39", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("If47", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("row10", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("row17", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("OnSubjobOk60", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("If46", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("row18", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("OnSubjobOk38", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("OnComponentOk6", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("row8", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("OnSubjobOk66", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("OnSubjobOk95", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("OnSubjobOk63", 3, 0);
					}           			
				
				if(execStat){
					runStat.updateStatOnConnection("iterate9", 1, "exec" + NB_ITERATE_tSetGlobalVar_1);
					//Thread.sleep(1000);
				}				
			

	
	/**
	 * [tSetGlobalVar_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tSetGlobalVar_1", false);
		start_Hash.put("tSetGlobalVar_1", System.currentTimeMillis());
		
	
	currentComponent="tSetGlobalVar_1";

	
		int tos_count_tSetGlobalVar_1 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tSetGlobalVar_1 - "  + ("Start to work.") );
    	class BytesLimit65535_tSetGlobalVar_1{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tSetGlobalVar_1 = new StringBuilder();
            log4jParamters_tSetGlobalVar_1.append("Parameters:");
                    log4jParamters_tSetGlobalVar_1.append("VARIABLES" + " = " + "[{VALUE="+("\"\"")+", KEY="+("\"kicsi\"")+"}, {VALUE="+("0")+", KEY="+("\"cnt\"")+"}, {VALUE="+("\"\"")+", KEY="+("\"where_cond\"")+"}, {VALUE="+("\"\"")+", KEY="+("\"columnlist\"")+"}, {VALUE="+("\"\"")+", KEY="+("\"columnlist_select\"")+"}, {VALUE="+("\"\"")+", KEY="+("\"filetocheck\"")+"}, {VALUE="+("\"\"")+", KEY="+("\"distributed\"")+"}, {VALUE="+("\"\"")+", KEY="+("\"PU_Key\"")+"}, {VALUE="+("\"\"")+", KEY="+("\"UK_Key\"")+"}, {VALUE="+("\"false\"")+", KEY="+("\"pk_exists\"")+"}, {VALUE="+("\"false\"")+", KEY="+("\"uk_exists\"")+"}, {VALUE="+("\"false\"")+", KEY="+("\"not_empty\"")+"}, {VALUE="+("\"00\"")+", KEY="+("\"key_mtx\"")+"}]");
                log4jParamters_tSetGlobalVar_1.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tSetGlobalVar_1 - "  + (log4jParamters_tSetGlobalVar_1) );
    		}
    	}
    	
        new BytesLimit65535_tSetGlobalVar_1().limitLog4jByte();

 



/**
 * [tSetGlobalVar_1 begin ] stop
 */
	
	/**
	 * [tSetGlobalVar_1 main ] start
	 */

	

	
	
	currentComponent="tSetGlobalVar_1";

	

globalMap.put("kicsi", "");
globalMap.put("cnt", 0);
globalMap.put("where_cond", "");
globalMap.put("columnlist", "");
globalMap.put("columnlist_select", "");
globalMap.put("filetocheck", "");
globalMap.put("distributed", "");
globalMap.put("PU_Key", "");
globalMap.put("UK_Key", "");
globalMap.put("pk_exists", "false");
globalMap.put("uk_exists", "false");
globalMap.put("not_empty", "false");
globalMap.put("key_mtx", "00");

 


	tos_count_tSetGlobalVar_1++;

/**
 * [tSetGlobalVar_1 main ] stop
 */
	
	/**
	 * [tSetGlobalVar_1 end ] start
	 */

	

	
	
	currentComponent="tSetGlobalVar_1";

	

 
                if(log.isDebugEnabled())
            log.debug("tSetGlobalVar_1 - "  + ("Done.") );

ok_Hash.put("tSetGlobalVar_1", true);
end_Hash.put("tSetGlobalVar_1", System.currentTimeMillis());

				if(execStat){   
   	 				runStat.updateStatOnConnection("OnComponentOk8", 0, "ok");
				}
				tGreenplumInput_8Process(globalMap);



/**
 * [tSetGlobalVar_1 end ] stop
 */
						if(execStat){
							runStat.updateStatOnConnection("iterate9", 2, "exec" + NB_ITERATE_tSetGlobalVar_1);
						}				
					







	
	/**
	 * [tGreenplumInput_4 end ] start
	 */

	

	
	
	currentComponent="tGreenplumInput_4";

	

	}
}finally{
	stmt_tGreenplumInput_4.close();

}
globalMap.put("tGreenplumInput_4_NB_LINE",nb_line_tGreenplumInput_4);
	    		log.debug("tGreenplumInput_4 - Retrieved records count: "+nb_line_tGreenplumInput_4 + " .");
			

 
                if(log.isDebugEnabled())
            log.debug("tGreenplumInput_4 - "  + ("Done.") );

ok_Hash.put("tGreenplumInput_4", true);
end_Hash.put("tGreenplumInput_4", System.currentTimeMillis());




/**
 * [tGreenplumInput_4 end ] stop
 */

	
	/**
	 * [tFlowToIterate_7 end ] start
	 */

	

	
	
	currentComponent="tFlowToIterate_7";

	

globalMap.put("tFlowToIterate_7_NB_LINE",nb_line_tFlowToIterate_7);
			if(execStat){
				if(resourceMap.get("inIterateVComp") == null || !((Boolean)resourceMap.get("inIterateVComp"))){
			 		runStat.updateStatOnConnection("row7"+iterateId,2, 0); 
			 	}
			}
		
 
                if(log.isDebugEnabled())
            log.debug("tFlowToIterate_7 - "  + ("Done.") );

ok_Hash.put("tFlowToIterate_7", true);
end_Hash.put("tFlowToIterate_7", System.currentTimeMillis());




/**
 * [tFlowToIterate_7 end ] stop
 */



				}//end the resume

				
				    			if(resumeEntryMethodName == null || globalResumeTicket){
				    				resumeUtil.addLog("CHECKPOINT", "CONNECTION:SUBJOB_OK:tGreenplumInput_4:OnSubjobOk", "", Thread.currentThread().getId() + "", "", "", "", "", "");
								}	    				    			
					    	
								if(execStat){    	
									runStat.updateStatOnConnection("OnSubjobOk67", 0, "ok");
								} 
							
							tGreenplumClose_7Process(globalMap); 
						



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage());
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tGreenplumInput_4 finally ] start
	 */

	

	
	
	currentComponent="tGreenplumInput_4";

	

 



/**
 * [tGreenplumInput_4 finally ] stop
 */

	
	/**
	 * [tFlowToIterate_7 finally ] start
	 */

	

	
	
	currentComponent="tFlowToIterate_7";

	

 



/**
 * [tFlowToIterate_7 finally ] stop
 */

	
	/**
	 * [tSetGlobalVar_1 finally ] start
	 */

	

	
	
	currentComponent="tSetGlobalVar_1";

	

 



/**
 * [tSetGlobalVar_1 finally ] stop
 */






				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tGreenplumInput_4_SUBPROCESS_STATE", 1);
	}
	


public static class row18Struct implements routines.system.IPersistableRow<row18Struct> {
    final static byte[] commonByteArrayLock_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Prod2Dev_with_GP_FDIST_child = new byte[0];
    static byte[] commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Prod2Dev_with_GP_FDIST_child = new byte[0];

	
			    public String column_name;

				public String getColumn_name () {
					return this.column_name;
				}
				



	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Prod2Dev_with_GP_FDIST_child.length) {
				if(length < 1024 && commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Prod2Dev_with_GP_FDIST_child.length == 0) {
   					commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Prod2Dev_with_GP_FDIST_child = new byte[1024];
				} else {
   					commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Prod2Dev_with_GP_FDIST_child = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Prod2Dev_with_GP_FDIST_child, 0, length);
			strReturn = new String(commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Prod2Dev_with_GP_FDIST_child, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Prod2Dev_with_GP_FDIST_child) {

        	try {

        		int length = 0;
		
					this.column_name = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// String
				
						writeString(this.column_name,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("column_name="+column_name);
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				if(column_name == null){
        					sb.append("<null>");
        				}else{
            				sb.append(column_name);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(row18Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}
public void tGreenplumInput_8Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tGreenplumInput_8_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;



		row18Struct row18 = new row18Struct();




	
	/**
	 * [tJavaRow_8 begin ] start
	 */

	

	
		
		ok_Hash.put("tJavaRow_8", false);
		start_Hash.put("tJavaRow_8", System.currentTimeMillis());
		
	
	currentComponent="tJavaRow_8";

	
			if (execStat) {
				if(resourceMap.get("inIterateVComp") == null){
					
						runStat.updateStatOnConnection("row18" + iterateId, 0, 0);
					
				}
			} 

		
		int tos_count_tJavaRow_8 = 0;
		
    	class BytesLimit65535_tJavaRow_8{
    		public void limitLog4jByte() throws Exception{
    			
    		}
    	}
    	
        new BytesLimit65535_tJavaRow_8().limitLog4jByte();

int nb_line_tJavaRow_8 = 0;

 



/**
 * [tJavaRow_8 begin ] stop
 */



	
	/**
	 * [tGreenplumInput_8 begin ] start
	 */

	

	
		
		ok_Hash.put("tGreenplumInput_8", false);
		start_Hash.put("tGreenplumInput_8", System.currentTimeMillis());
		
	
	currentComponent="tGreenplumInput_8";

	
		int tos_count_tGreenplumInput_8 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tGreenplumInput_8 - "  + ("Start to work.") );
    	class BytesLimit65535_tGreenplumInput_8{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tGreenplumInput_8 = new StringBuilder();
            log4jParamters_tGreenplumInput_8.append("Parameters:");
                    log4jParamters_tGreenplumInput_8.append("USE_EXISTING_CONNECTION" + " = " + "true");
                log4jParamters_tGreenplumInput_8.append(" | ");
                    log4jParamters_tGreenplumInput_8.append("CONNECTION" + " = " + "tGreenplumConnection_7");
                log4jParamters_tGreenplumInput_8.append(" | ");
                    log4jParamters_tGreenplumInput_8.append("TABLE" + " = " + "\"\"");
                log4jParamters_tGreenplumInput_8.append(" | ");
                    log4jParamters_tGreenplumInput_8.append("QUERYSTORE" + " = " + "\"\"");
                log4jParamters_tGreenplumInput_8.append(" | ");
                    log4jParamters_tGreenplumInput_8.append("QUERY" + " = " + "/*   \"select string_agg( column_name,',')   from (select distinct column_name from sbdt.primary_key_columns  where upper(table_name)='\"+((String)globalMap.get(\"row7.target_table_name\")).toUpperCase()+\"'  and upper(table_schema)='\"+((String)globalMap.get(\"row7.target_schema\")).toUpperCase()+\"') cn;\"  */    \" select string_agg( column_name,',') column_name  from        information_schema.table_constraints tc,        information_schema.key_column_usage kc    where 1=1      and (tc.constraint_type = 'PRIMARY KEY' or upper(tc.constraint_name) like 'PK%')      and kc.table_name = tc.table_name   	and kc.table_schema = tc.table_schema      and kc.constraint_name = tc.constraint_name  	and upper(tc.table_name)='\"+((String)globalMap.get(\"row7.target_table_name\")).toUpperCase()+\"'  	and upper(tc.table_schema) = '\"+((String)globalMap.get(\"row7.target_schema\")).toUpperCase()  +\"' union \"+  \"select string_agg( column_name,',') column_name  from (select distinct column_name from sbdt.primary_key_columns  where upper(table_name)='\"+((String)globalMap.get(\"row7.target_table_name\")).toUpperCase()+\"'  and upper(table_schema)='\"+((String)globalMap.get(\"row7.target_schema\")).toUpperCase()  +\"') cn limit 1; \"");
                log4jParamters_tGreenplumInput_8.append(" | ");
                    log4jParamters_tGreenplumInput_8.append("USE_CURSOR" + " = " + "false");
                log4jParamters_tGreenplumInput_8.append(" | ");
                    log4jParamters_tGreenplumInput_8.append("TRIM_ALL_COLUMN" + " = " + "false");
                log4jParamters_tGreenplumInput_8.append(" | ");
                    log4jParamters_tGreenplumInput_8.append("TRIM_COLUMN" + " = " + "[{TRIM="+("false")+", SCHEMA_COLUMN="+("column_name")+"}]");
                log4jParamters_tGreenplumInput_8.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tGreenplumInput_8 - "  + (log4jParamters_tGreenplumInput_8) );
    		}
    	}
    	
        new BytesLimit65535_tGreenplumInput_8().limitLog4jByte();
	
    
	
		    int nb_line_tGreenplumInput_8 = 0;
		    java.sql.Connection conn_tGreenplumInput_8 = null;
		        conn_tGreenplumInput_8 = (java.sql.Connection)globalMap.get("conn_tGreenplumConnection_7");
				
				if(conn_tGreenplumInput_8 != null) {
					if(conn_tGreenplumInput_8.getMetaData() != null) {
						
						log.debug("tGreenplumInput_8 - Uses an existing connection with username '" + conn_tGreenplumInput_8.getMetaData().getUserName() + "'. Connection URL: " + conn_tGreenplumInput_8.getMetaData().getURL() + ".");
						
					}
				}
			
		    
			java.sql.Statement stmt_tGreenplumInput_8 = conn_tGreenplumInput_8.createStatement();

		    String dbquery_tGreenplumInput_8 = /* 
"select string_agg( column_name,',') \nfrom (select distinct column_name from sbdt.primary_key_columns\nwhere upper(table_name)='"+((String)globalMap.get("row7.target_table_name")).toUpperCase()+"'\nand upper(table_schema)='"+((String)globalMap.get("row7.target_schema")).toUpperCase()+"') cn;"
*/

" select string_agg( column_name,',') column_name\nfrom  \n    information_schema.table_constraints tc,  \n    information_schema.key_column_usage kc  \nwhere 1=1\n    and (tc.constraint_type = 'PRIMARY KEY' or upper(tc.constraint_name) like 'PK%')\n    and kc.table_name = tc.table_name \n	and kc.table_schema = tc.table_schema\n    and kc.constraint_name = tc.constraint_name\n	and upper(tc.table_name)='"+((String)globalMap.get("row7.target_table_name")).toUpperCase()+"'\n	and upper(tc.table_schema) = '"+((String)globalMap.get("row7.target_schema")).toUpperCase()
+"' union "+
"select string_agg( column_name,',') column_name\nfrom (select distinct column_name from sbdt.primary_key_columns\nwhere upper(table_name)='"+((String)globalMap.get("row7.target_table_name")).toUpperCase()+"'\nand upper(table_schema)='"+((String)globalMap.get("row7.target_schema")).toUpperCase()
+"') cn limit 1; ";
			
                log.debug("tGreenplumInput_8 - Executing the query: '"+dbquery_tGreenplumInput_8+"'.");
			

                       globalMap.put("tGreenplumInput_8_QUERY",dbquery_tGreenplumInput_8);

		    java.sql.ResultSet rs_tGreenplumInput_8 = null;
		try{
		    rs_tGreenplumInput_8 = stmt_tGreenplumInput_8.executeQuery(dbquery_tGreenplumInput_8);
		    java.sql.ResultSetMetaData rsmd_tGreenplumInput_8 = rs_tGreenplumInput_8.getMetaData();
		    int colQtyInRs_tGreenplumInput_8 = rsmd_tGreenplumInput_8.getColumnCount();

		    String tmpContent_tGreenplumInput_8 = null;
		    
		    
		    	log.debug("tGreenplumInput_8 - Retrieving records from the database.");
		    
		    while (rs_tGreenplumInput_8.next()) {
		        nb_line_tGreenplumInput_8++;
		        
							if(colQtyInRs_tGreenplumInput_8 < 1) {
								row18.column_name = null;
							} else {
	                         		
        	row18.column_name = routines.system.JDBCUtil.getString(rs_tGreenplumInput_8, 1, false);
		                    }
					
						log.debug("tGreenplumInput_8 - Retrieving the record " + nb_line_tGreenplumInput_8 + ".");
					


 



/**
 * [tGreenplumInput_8 begin ] stop
 */
	
	/**
	 * [tGreenplumInput_8 main ] start
	 */

	

	
	
	currentComponent="tGreenplumInput_8";

	

 


	tos_count_tGreenplumInput_8++;

/**
 * [tGreenplumInput_8 main ] stop
 */

	
	/**
	 * [tJavaRow_8 main ] start
	 */

	

	
	
	currentComponent="tJavaRow_8";

	

			//row18
			//row18


			
				if(execStat){
					runStat.updateStatOnConnection("row18"+iterateId,1, 1);
				} 
			

		
    			if(log.isTraceEnabled()){
    				log.trace("row18 - " + (row18==null? "": row18.toLogString()));
    			}
    		

    System.out.println("Primary and unique columns");
System.out.println(row18.column_name);



if (globalMap.get("PU_Key").equals("") && row18.column_name!=null && !((String)row18.column_name).equals("")) 
{
	globalMap.put("PU_Key", 
	"ALTER TABLE " + (String)globalMap.get("row7.target_schema_orig") +"."+ (String)globalMap.get("row7.log_table_name") + " ADD CONSTRAINT pk_"+(String)globalMap.get("row7.log_table_name") + " PRIMARY KEY ("+(String)row18.column_name+");"
	);
} 
    nb_line_tJavaRow_8++;   

 


	tos_count_tJavaRow_8++;

/**
 * [tJavaRow_8 main ] stop
 */



	
	/**
	 * [tGreenplumInput_8 end ] start
	 */

	

	
	
	currentComponent="tGreenplumInput_8";

	

	}
}finally{
	stmt_tGreenplumInput_8.close();

}
globalMap.put("tGreenplumInput_8_NB_LINE",nb_line_tGreenplumInput_8);
	    		log.debug("tGreenplumInput_8 - Retrieved records count: "+nb_line_tGreenplumInput_8 + " .");
			

 
                if(log.isDebugEnabled())
            log.debug("tGreenplumInput_8 - "  + ("Done.") );

ok_Hash.put("tGreenplumInput_8", true);
end_Hash.put("tGreenplumInput_8", System.currentTimeMillis());

				if(execStat){   
   	 				runStat.updateStatOnConnection("OnComponentOk38", 0, "ok");
				}
				tGreenplumInput_11Process(globalMap);



/**
 * [tGreenplumInput_8 end ] stop
 */

	
	/**
	 * [tJavaRow_8 end ] start
	 */

	

	
	
	currentComponent="tJavaRow_8";

	

globalMap.put("tJavaRow_8_NB_LINE",nb_line_tJavaRow_8);
			if(execStat){
				if(resourceMap.get("inIterateVComp") == null || !((Boolean)resourceMap.get("inIterateVComp"))){
			 		runStat.updateStatOnConnection("row18"+iterateId,2, 0); 
			 	}
			}
		
 

ok_Hash.put("tJavaRow_8", true);
end_Hash.put("tJavaRow_8", System.currentTimeMillis());




/**
 * [tJavaRow_8 end ] stop
 */



				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage());
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tGreenplumInput_8 finally ] start
	 */

	

	
	
	currentComponent="tGreenplumInput_8";

	

 



/**
 * [tGreenplumInput_8 finally ] stop
 */

	
	/**
	 * [tJavaRow_8 finally ] start
	 */

	

	
	
	currentComponent="tJavaRow_8";

	

 



/**
 * [tJavaRow_8 finally ] stop
 */



				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tGreenplumInput_8_SUBPROCESS_STATE", 1);
	}
	


public static class row21Struct implements routines.system.IPersistableRow<row21Struct> {
    final static byte[] commonByteArrayLock_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Prod2Dev_with_GP_FDIST_child = new byte[0];
    static byte[] commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Prod2Dev_with_GP_FDIST_child = new byte[0];

	
			    public String column_name;

				public String getColumn_name () {
					return this.column_name;
				}
				



	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Prod2Dev_with_GP_FDIST_child.length) {
				if(length < 1024 && commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Prod2Dev_with_GP_FDIST_child.length == 0) {
   					commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Prod2Dev_with_GP_FDIST_child = new byte[1024];
				} else {
   					commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Prod2Dev_with_GP_FDIST_child = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Prod2Dev_with_GP_FDIST_child, 0, length);
			strReturn = new String(commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Prod2Dev_with_GP_FDIST_child, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Prod2Dev_with_GP_FDIST_child) {

        	try {

        		int length = 0;
		
					this.column_name = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// String
				
						writeString(this.column_name,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("column_name="+column_name);
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				if(column_name == null){
        					sb.append("<null>");
        				}else{
            				sb.append(column_name);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(row21Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}
public void tGreenplumInput_11Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tGreenplumInput_11_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;



		row21Struct row21 = new row21Struct();




	
	/**
	 * [tJavaRow_12 begin ] start
	 */

	

	
		
		ok_Hash.put("tJavaRow_12", false);
		start_Hash.put("tJavaRow_12", System.currentTimeMillis());
		
	
	currentComponent="tJavaRow_12";

	
			if (execStat) {
				if(resourceMap.get("inIterateVComp") == null){
					
						runStat.updateStatOnConnection("row21" + iterateId, 0, 0);
					
				}
			} 

		
		int tos_count_tJavaRow_12 = 0;
		
    	class BytesLimit65535_tJavaRow_12{
    		public void limitLog4jByte() throws Exception{
    			
    		}
    	}
    	
        new BytesLimit65535_tJavaRow_12().limitLog4jByte();

int nb_line_tJavaRow_12 = 0;

 



/**
 * [tJavaRow_12 begin ] stop
 */



	
	/**
	 * [tGreenplumInput_11 begin ] start
	 */

	

	
		
		ok_Hash.put("tGreenplumInput_11", false);
		start_Hash.put("tGreenplumInput_11", System.currentTimeMillis());
		
	
	currentComponent="tGreenplumInput_11";

	
		int tos_count_tGreenplumInput_11 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tGreenplumInput_11 - "  + ("Start to work.") );
    	class BytesLimit65535_tGreenplumInput_11{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tGreenplumInput_11 = new StringBuilder();
            log4jParamters_tGreenplumInput_11.append("Parameters:");
                    log4jParamters_tGreenplumInput_11.append("USE_EXISTING_CONNECTION" + " = " + "true");
                log4jParamters_tGreenplumInput_11.append(" | ");
                    log4jParamters_tGreenplumInput_11.append("CONNECTION" + " = " + "tGreenplumConnection_7");
                log4jParamters_tGreenplumInput_11.append(" | ");
                    log4jParamters_tGreenplumInput_11.append("TABLE" + " = " + "\"\"");
                log4jParamters_tGreenplumInput_11.append(" | ");
                    log4jParamters_tGreenplumInput_11.append("QUERYSTORE" + " = " + "\"\"");
                log4jParamters_tGreenplumInput_11.append(" | ");
                    log4jParamters_tGreenplumInput_11.append("QUERY" + " = " + "\"select string_agg( column_name,',' order by ordinal_position) column_name  from (  select table_schema, table_name, constraint_type, constraint_name from (  	select table_schema,table_name, constraint_type,constraint_name, row_number() over(partition by table_schema, table_name order by 1) rn   from information_schema.table_constraints tc  where (upper(tc.constraint_type) = 'UNIQUE' or upper(tc.constraint_name) like 'UK%') and upper(table_name) = '\"+((String)globalMap.get(\"row7.target_table_name\")).toUpperCase()+\"' and upper(table_schema) = '\"+((String)globalMap.get(\"row7.target_schema\")).toUpperCase()+\"' ) cont  where rn = 1  ) tc  left outer join information_schema.key_column_usage kc  on  upper(kc.table_name) = upper(tc.table_name)      and upper(kc.table_schema) = upper(tc.table_schema)      and upper(kc.constraint_name) = upper(tc.constraint_name);\"");
                log4jParamters_tGreenplumInput_11.append(" | ");
                    log4jParamters_tGreenplumInput_11.append("USE_CURSOR" + " = " + "false");
                log4jParamters_tGreenplumInput_11.append(" | ");
                    log4jParamters_tGreenplumInput_11.append("TRIM_ALL_COLUMN" + " = " + "false");
                log4jParamters_tGreenplumInput_11.append(" | ");
                    log4jParamters_tGreenplumInput_11.append("TRIM_COLUMN" + " = " + "[{TRIM="+("false")+", SCHEMA_COLUMN="+("column_name")+"}]");
                log4jParamters_tGreenplumInput_11.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tGreenplumInput_11 - "  + (log4jParamters_tGreenplumInput_11) );
    		}
    	}
    	
        new BytesLimit65535_tGreenplumInput_11().limitLog4jByte();
	
    
	
		    int nb_line_tGreenplumInput_11 = 0;
		    java.sql.Connection conn_tGreenplumInput_11 = null;
		        conn_tGreenplumInput_11 = (java.sql.Connection)globalMap.get("conn_tGreenplumConnection_7");
				
				if(conn_tGreenplumInput_11 != null) {
					if(conn_tGreenplumInput_11.getMetaData() != null) {
						
						log.debug("tGreenplumInput_11 - Uses an existing connection with username '" + conn_tGreenplumInput_11.getMetaData().getUserName() + "'. Connection URL: " + conn_tGreenplumInput_11.getMetaData().getURL() + ".");
						
					}
				}
			
		    
			java.sql.Statement stmt_tGreenplumInput_11 = conn_tGreenplumInput_11.createStatement();

		    String dbquery_tGreenplumInput_11 = "select string_agg( column_name,',' order by ordinal_position) column_name  from (\nselect table_schema, table_name, constraint_type, constraint_name from (\n	select table_schema,table_name, constraint_type,constraint_name, row_number() over(partition by table_schema, table_name order by 1) rn \nfrom information_schema.table_constraints tc  where (upper(tc.constraint_type) = 'UNIQUE' or upper(tc.constraint_name) like 'UK%') and upper(table_name) = '"+((String)globalMap.get("row7.target_table_name")).toUpperCase()+"' and upper(table_schema) = '"+((String)globalMap.get("row7.target_schema")).toUpperCase()+"' ) cont\nwhere rn = 1\n) tc\nleft outer join information_schema.key_column_usage kc\non  upper(kc.table_name) = upper(tc.table_name)\n    and upper(kc.table_schema) = upper(tc.table_schema)\n    and upper(kc.constraint_name) = upper(tc.constraint_name);";
			
                log.debug("tGreenplumInput_11 - Executing the query: '"+dbquery_tGreenplumInput_11+"'.");
			

                       globalMap.put("tGreenplumInput_11_QUERY",dbquery_tGreenplumInput_11);

		    java.sql.ResultSet rs_tGreenplumInput_11 = null;
		try{
		    rs_tGreenplumInput_11 = stmt_tGreenplumInput_11.executeQuery(dbquery_tGreenplumInput_11);
		    java.sql.ResultSetMetaData rsmd_tGreenplumInput_11 = rs_tGreenplumInput_11.getMetaData();
		    int colQtyInRs_tGreenplumInput_11 = rsmd_tGreenplumInput_11.getColumnCount();

		    String tmpContent_tGreenplumInput_11 = null;
		    
		    
		    	log.debug("tGreenplumInput_11 - Retrieving records from the database.");
		    
		    while (rs_tGreenplumInput_11.next()) {
		        nb_line_tGreenplumInput_11++;
		        
							if(colQtyInRs_tGreenplumInput_11 < 1) {
								row21.column_name = null;
							} else {
	                         		
        	row21.column_name = routines.system.JDBCUtil.getString(rs_tGreenplumInput_11, 1, false);
		                    }
					
						log.debug("tGreenplumInput_11 - Retrieving the record " + nb_line_tGreenplumInput_11 + ".");
					


 



/**
 * [tGreenplumInput_11 begin ] stop
 */
	
	/**
	 * [tGreenplumInput_11 main ] start
	 */

	

	
	
	currentComponent="tGreenplumInput_11";

	

 


	tos_count_tGreenplumInput_11++;

/**
 * [tGreenplumInput_11 main ] stop
 */

	
	/**
	 * [tJavaRow_12 main ] start
	 */

	

	
	
	currentComponent="tJavaRow_12";

	

			//row21
			//row21


			
				if(execStat){
					runStat.updateStatOnConnection("row21"+iterateId,1, 1);
				} 
			

		
    			if(log.isTraceEnabled()){
    				log.trace("row21 - " + (row21==null? "": row21.toLogString()));
    			}
    		

    System.out.println("Unique columns");
System.out.println(row21.column_name);



if (globalMap.get("UK_Key").equals("") && row21.column_name!=null && !((String)row21.column_name).equals("")) 
{
	globalMap.put("UK_Key", 
	"ALTER TABLE " + (String)globalMap.get("row7.target_schema_orig") +"."+ (String)globalMap.get("row7.log_table_name") + " ADD CONSTRAINT uk_"+(String)globalMap.get("row7.log_table_name") + " UNIQUE ("+(String)row21.column_name+");"
	);
} 
    nb_line_tJavaRow_12++;   

 


	tos_count_tJavaRow_12++;

/**
 * [tJavaRow_12 main ] stop
 */



	
	/**
	 * [tGreenplumInput_11 end ] start
	 */

	

	
	
	currentComponent="tGreenplumInput_11";

	

	}
}finally{
	stmt_tGreenplumInput_11.close();

}
globalMap.put("tGreenplumInput_11_NB_LINE",nb_line_tGreenplumInput_11);
	    		log.debug("tGreenplumInput_11 - Retrieved records count: "+nb_line_tGreenplumInput_11 + " .");
			

 
                if(log.isDebugEnabled())
            log.debug("tGreenplumInput_11 - "  + ("Done.") );

ok_Hash.put("tGreenplumInput_11", true);
end_Hash.put("tGreenplumInput_11", System.currentTimeMillis());

				if(execStat){   
   	 				runStat.updateStatOnConnection("OnComponentOk39", 0, "ok");
				}
				tGreenplumClose_1Process(globalMap);



/**
 * [tGreenplumInput_11 end ] stop
 */

	
	/**
	 * [tJavaRow_12 end ] start
	 */

	

	
	
	currentComponent="tJavaRow_12";

	

globalMap.put("tJavaRow_12_NB_LINE",nb_line_tJavaRow_12);
			if(execStat){
				if(resourceMap.get("inIterateVComp") == null || !((Boolean)resourceMap.get("inIterateVComp"))){
			 		runStat.updateStatOnConnection("row21"+iterateId,2, 0); 
			 	}
			}
		
 

ok_Hash.put("tJavaRow_12", true);
end_Hash.put("tJavaRow_12", System.currentTimeMillis());




/**
 * [tJavaRow_12 end ] stop
 */



				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage());
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tGreenplumInput_11 finally ] start
	 */

	

	
	
	currentComponent="tGreenplumInput_11";

	

 



/**
 * [tGreenplumInput_11 finally ] stop
 */

	
	/**
	 * [tJavaRow_12 finally ] start
	 */

	

	
	
	currentComponent="tJavaRow_12";

	

 



/**
 * [tJavaRow_12 finally ] stop
 */



				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tGreenplumInput_11_SUBPROCESS_STATE", 1);
	}
	

public void tGreenplumClose_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tGreenplumClose_1_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tGreenplumClose_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tGreenplumClose_1", false);
		start_Hash.put("tGreenplumClose_1", System.currentTimeMillis());
		
	
	currentComponent="tGreenplumClose_1";

	
		int tos_count_tGreenplumClose_1 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tGreenplumClose_1 - "  + ("Start to work.") );
    	class BytesLimit65535_tGreenplumClose_1{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tGreenplumClose_1 = new StringBuilder();
            log4jParamters_tGreenplumClose_1.append("Parameters:");
                    log4jParamters_tGreenplumClose_1.append("CONNECTION" + " = " + "tGreenplumConnection_7");
                log4jParamters_tGreenplumClose_1.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tGreenplumClose_1 - "  + (log4jParamters_tGreenplumClose_1) );
    		}
    	}
    	
        new BytesLimit65535_tGreenplumClose_1().limitLog4jByte();

 



/**
 * [tGreenplumClose_1 begin ] stop
 */
	
	/**
	 * [tGreenplumClose_1 main ] start
	 */

	

	
	
	currentComponent="tGreenplumClose_1";

	



	java.sql.Connection conn_tGreenplumClose_1 = (java.sql.Connection)globalMap.get("conn_tGreenplumConnection_7");
	if(conn_tGreenplumClose_1 != null && !conn_tGreenplumClose_1.isClosed())
	{
                if(log.isDebugEnabled())
            log.debug("tGreenplumClose_1 - "  + ("Closing the connection ")  + ("conn_tGreenplumConnection_7")  + (" to the database.") );
        conn_tGreenplumClose_1.close();
                if(log.isDebugEnabled())
            log.debug("tGreenplumClose_1 - "  + ("Connection ")  + ("conn_tGreenplumConnection_7")  + (" to the database has closed.") );
	}

 


	tos_count_tGreenplumClose_1++;

/**
 * [tGreenplumClose_1 main ] stop
 */
	
	/**
	 * [tGreenplumClose_1 end ] start
	 */

	

	
	
	currentComponent="tGreenplumClose_1";

	

 
                if(log.isDebugEnabled())
            log.debug("tGreenplumClose_1 - "  + ("Done.") );

ok_Hash.put("tGreenplumClose_1", true);
end_Hash.put("tGreenplumClose_1", System.currentTimeMillis());

				if(execStat){   
   	 				runStat.updateStatOnConnection("OnComponentOk9", 0, "ok");
				}
				tJava_2Process(globalMap);



/**
 * [tGreenplumClose_1 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage());
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tGreenplumClose_1 finally ] start
	 */

	

	
	
	currentComponent="tGreenplumClose_1";

	

 



/**
 * [tGreenplumClose_1 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tGreenplumClose_1_SUBPROCESS_STATE", 1);
	}
	

public void tGreenplumClose_7Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tGreenplumClose_7_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;





	
	/**
	 * [tGreenplumClose_7 begin ] start
	 */

	

	
		
		ok_Hash.put("tGreenplumClose_7", false);
		start_Hash.put("tGreenplumClose_7", System.currentTimeMillis());
		
	
	currentComponent="tGreenplumClose_7";

	
		int tos_count_tGreenplumClose_7 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tGreenplumClose_7 - "  + ("Start to work.") );
    	class BytesLimit65535_tGreenplumClose_7{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tGreenplumClose_7 = new StringBuilder();
            log4jParamters_tGreenplumClose_7.append("Parameters:");
                    log4jParamters_tGreenplumClose_7.append("CONNECTION" + " = " + "tGreenplumConnection_7");
                log4jParamters_tGreenplumClose_7.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tGreenplumClose_7 - "  + (log4jParamters_tGreenplumClose_7) );
    		}
    	}
    	
        new BytesLimit65535_tGreenplumClose_7().limitLog4jByte();

 



/**
 * [tGreenplumClose_7 begin ] stop
 */
	
	/**
	 * [tGreenplumClose_7 main ] start
	 */

	

	
	
	currentComponent="tGreenplumClose_7";

	



	java.sql.Connection conn_tGreenplumClose_7 = (java.sql.Connection)globalMap.get("conn_tGreenplumConnection_7");
	if(conn_tGreenplumClose_7 != null && !conn_tGreenplumClose_7.isClosed())
	{
                if(log.isDebugEnabled())
            log.debug("tGreenplumClose_7 - "  + ("Closing the connection ")  + ("conn_tGreenplumConnection_7")  + (" to the database.") );
        conn_tGreenplumClose_7.close();
                if(log.isDebugEnabled())
            log.debug("tGreenplumClose_7 - "  + ("Connection ")  + ("conn_tGreenplumConnection_7")  + (" to the database has closed.") );
	}

 


	tos_count_tGreenplumClose_7++;

/**
 * [tGreenplumClose_7 main ] stop
 */
	
	/**
	 * [tGreenplumClose_7 end ] start
	 */

	

	
	
	currentComponent="tGreenplumClose_7";

	

 
                if(log.isDebugEnabled())
            log.debug("tGreenplumClose_7 - "  + ("Done.") );

ok_Hash.put("tGreenplumClose_7", true);
end_Hash.put("tGreenplumClose_7", System.currentTimeMillis());




/**
 * [tGreenplumClose_7 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage());
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tGreenplumClose_7 finally ] start
	 */

	

	
	
	currentComponent="tGreenplumClose_7";

	

 



/**
 * [tGreenplumClose_7 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tGreenplumClose_7_SUBPROCESS_STATE", 1);
	}
	

public void tGreenplumConnection_7Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tGreenplumConnection_7_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tGreenplumConnection_7 begin ] start
	 */

	

	
		
		ok_Hash.put("tGreenplumConnection_7", false);
		start_Hash.put("tGreenplumConnection_7", System.currentTimeMillis());
		
	
	currentComponent="tGreenplumConnection_7";

	
		int tos_count_tGreenplumConnection_7 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tGreenplumConnection_7 - "  + ("Start to work.") );
    	class BytesLimit65535_tGreenplumConnection_7{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tGreenplumConnection_7 = new StringBuilder();
            log4jParamters_tGreenplumConnection_7.append("Parameters:");
                    log4jParamters_tGreenplumConnection_7.append("HOST" + " = " + "context.SOURCE_HOST");
                log4jParamters_tGreenplumConnection_7.append(" | ");
                    log4jParamters_tGreenplumConnection_7.append("PORT" + " = " + "context.SOURCE_PORT");
                log4jParamters_tGreenplumConnection_7.append(" | ");
                    log4jParamters_tGreenplumConnection_7.append("DBNAME" + " = " + "context.SOURCE_DATABASE");
                log4jParamters_tGreenplumConnection_7.append(" | ");
                    log4jParamters_tGreenplumConnection_7.append("SCHEMA_DB" + " = " + "\"\"");
                log4jParamters_tGreenplumConnection_7.append(" | ");
                    log4jParamters_tGreenplumConnection_7.append("USER" + " = " + "context.SOURCE_USER");
                log4jParamters_tGreenplumConnection_7.append(" | ");
                    log4jParamters_tGreenplumConnection_7.append("PASS" + " = " + String.valueOf(routines.system.PasswordEncryptUtil.encryptPassword(context.SOURCE_PASSWORD)).substring(0, 4) + "...");     
                log4jParamters_tGreenplumConnection_7.append(" | ");
                    log4jParamters_tGreenplumConnection_7.append("USE_SHARED_CONNECTION" + " = " + "false");
                log4jParamters_tGreenplumConnection_7.append(" | ");
                    log4jParamters_tGreenplumConnection_7.append("USE_SSL" + " = " + "true");
                log4jParamters_tGreenplumConnection_7.append(" | ");
                    log4jParamters_tGreenplumConnection_7.append("AUTO_COMMIT" + " = " + "true");
                log4jParamters_tGreenplumConnection_7.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tGreenplumConnection_7 - "  + (log4jParamters_tGreenplumConnection_7) );
    		}
    	}
    	
        new BytesLimit65535_tGreenplumConnection_7().limitLog4jByte();
	

	
				String url_tGreenplumConnection_7 = "jdbc:postgresql://"+context.SOURCE_HOST+":"+context.SOURCE_PORT+"/"+context.SOURCE_DATABASE+"?ssl=true&sslfactory=org.postgresql.ssl.NonValidatingFactory";

	String dbUser_tGreenplumConnection_7 = context.SOURCE_USER;
	
	
		
	final String decryptedPassword_tGreenplumConnection_7 = context.SOURCE_PASSWORD; 
		String dbPwd_tGreenplumConnection_7 = decryptedPassword_tGreenplumConnection_7;
	

	java.sql.Connection conn_tGreenplumConnection_7 = null;
	
		
			String driverClass_tGreenplumConnection_7 = "org.postgresql.Driver";
			java.lang.Class.forName(driverClass_tGreenplumConnection_7);
		
	    		log.debug("tGreenplumConnection_7 - Driver ClassName: "+driverClass_tGreenplumConnection_7+".");
			
	    		log.debug("tGreenplumConnection_7 - Connection attempt to '" + url_tGreenplumConnection_7 + "' with the username '" + dbUser_tGreenplumConnection_7 + "'.");
			
		conn_tGreenplumConnection_7 = java.sql.DriverManager.getConnection(url_tGreenplumConnection_7,dbUser_tGreenplumConnection_7,dbPwd_tGreenplumConnection_7);
	    		log.debug("tGreenplumConnection_7 - Connection to '" + url_tGreenplumConnection_7 + "' has succeeded.");
			

		globalMap.put("conn_tGreenplumConnection_7", conn_tGreenplumConnection_7);
	if (null != conn_tGreenplumConnection_7) {
		
			log.debug("tGreenplumConnection_7 - Connection is set auto commit to 'true'.");
			conn_tGreenplumConnection_7.setAutoCommit(true);
	}

	globalMap.put("schema_" + "tGreenplumConnection_7","");

	globalMap.put("conn_" + "tGreenplumConnection_7",conn_tGreenplumConnection_7);
 



/**
 * [tGreenplumConnection_7 begin ] stop
 */
	
	/**
	 * [tGreenplumConnection_7 main ] start
	 */

	

	
	
	currentComponent="tGreenplumConnection_7";

	

 


	tos_count_tGreenplumConnection_7++;

/**
 * [tGreenplumConnection_7 main ] stop
 */
	
	/**
	 * [tGreenplumConnection_7 end ] start
	 */

	

	
	
	currentComponent="tGreenplumConnection_7";

	

 
                if(log.isDebugEnabled())
            log.debug("tGreenplumConnection_7 - "  + ("Done.") );

ok_Hash.put("tGreenplumConnection_7", true);
end_Hash.put("tGreenplumConnection_7", System.currentTimeMillis());




/**
 * [tGreenplumConnection_7 end ] stop
 */
				}//end the resume

				
				    			if(resumeEntryMethodName == null || globalResumeTicket){
				    				resumeUtil.addLog("CHECKPOINT", "CONNECTION:SUBJOB_OK:tGreenplumConnection_7:OnSubjobOk", "", Thread.currentThread().getId() + "", "", "", "", "", "");
								}	    				    			
					    	
								if(execStat){    	
									runStat.updateStatOnConnection("OnSubjobOk73", 0, "ok");
								} 
							
							tGreenplumInput_4Process(globalMap); 
						



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage());
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tGreenplumConnection_7 finally ] start
	 */

	

	
	
	currentComponent="tGreenplumConnection_7";

	

 



/**
 * [tGreenplumConnection_7 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tGreenplumConnection_7_SUBPROCESS_STATE", 1);
	}
	

public void tJava_16Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tJava_16_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tJava_16 begin ] start
	 */

	

	
		
		ok_Hash.put("tJava_16", false);
		start_Hash.put("tJava_16", System.currentTimeMillis());
		
	
	currentComponent="tJava_16";

	
		int tos_count_tJava_16 = 0;
		
    	class BytesLimit65535_tJava_16{
    		public void limitLog4jByte() throws Exception{
    			
    		}
    	}
    	
        new BytesLimit65535_tJava_16().limitLog4jByte();


globalMap.put("orig_table_name", context.getProperty("TABLE_NAME"));
if (context.getProperty("TABLE_NAME").length() != 0) {
	context.setProperty("TABLE_NAME", " and upper(target_table_name) = '" + context.getProperty("TABLE_NAME").toUpperCase() + "'");
}
System.out.println(context.SOURCE_HOST);
 



/**
 * [tJava_16 begin ] stop
 */
	
	/**
	 * [tJava_16 main ] start
	 */

	

	
	
	currentComponent="tJava_16";

	

 


	tos_count_tJava_16++;

/**
 * [tJava_16 main ] stop
 */
	
	/**
	 * [tJava_16 end ] start
	 */

	

	
	
	currentComponent="tJava_16";

	

 

ok_Hash.put("tJava_16", true);
end_Hash.put("tJava_16", System.currentTimeMillis());




/**
 * [tJava_16 end ] stop
 */
				}//end the resume

				
				    			if(resumeEntryMethodName == null || globalResumeTicket){
				    				resumeUtil.addLog("CHECKPOINT", "CONNECTION:SUBJOB_OK:tJava_16:OnSubjobOk", "", Thread.currentThread().getId() + "", "", "", "", "", "");
								}	    				    			
					    	
								if(execStat){    	
									runStat.updateStatOnConnection("OnSubjobOk77", 0, "ok");
								} 
							
							tGreenplumConnection_7Process(globalMap); 
						



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage());
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tJava_16 finally ] start
	 */

	

	
	
	currentComponent="tJava_16";

	

 



/**
 * [tJava_16 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tJava_16_SUBPROCESS_STATE", 1);
	}
	

public void tFileDelete_3Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tFileDelete_3_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;





	
	/**
	 * [tFileDelete_3 begin ] start
	 */

	

	
		
		ok_Hash.put("tFileDelete_3", false);
		start_Hash.put("tFileDelete_3", System.currentTimeMillis());
		
	
	currentComponent="tFileDelete_3";

	
		int tos_count_tFileDelete_3 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tFileDelete_3 - "  + ("Start to work.") );
    	class BytesLimit65535_tFileDelete_3{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tFileDelete_3 = new StringBuilder();
            log4jParamters_tFileDelete_3.append("Parameters:");
                    log4jParamters_tFileDelete_3.append("FILENAME" + " = " + "context.ETL_STORAGE_PATH + \"/\" + context.GP_SOURCE_NAME + '/' + \"/data/\" + context.SOURCE_DATABASE + \"/\" + ((String)globalMap.get(\"row7.log_table_name\")).replace(\"\\\"\",\"\").replace(\"#\",\"__hash__\").replace(\"$\",\"__dollar__\")+\".txt\"");
                log4jParamters_tFileDelete_3.append(" | ");
                    log4jParamters_tFileDelete_3.append("FAILON" + " = " + "false");
                log4jParamters_tFileDelete_3.append(" | ");
                    log4jParamters_tFileDelete_3.append("FOLDER" + " = " + "false");
                log4jParamters_tFileDelete_3.append(" | ");
                    log4jParamters_tFileDelete_3.append("FOLDER_FILE" + " = " + "false");
                log4jParamters_tFileDelete_3.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tFileDelete_3 - "  + (log4jParamters_tFileDelete_3) );
    		}
    	}
    	
        new BytesLimit65535_tFileDelete_3().limitLog4jByte();

 



/**
 * [tFileDelete_3 begin ] stop
 */
	
	/**
	 * [tFileDelete_3 main ] start
	 */

	

	
	
	currentComponent="tFileDelete_3";

	

 

				final StringBuffer log4jSb_tFileDelete_3 = new StringBuffer();
			
class DeleteFoldertFileDelete_3{
	 /**
     * delete all the sub-files in 'file'
     * 
     * @param file
     */
	public boolean delete(java.io.File file) {
        java.io.File[] files = file.listFiles();
        for (int i = 0; i < files.length; i++) {
            if (files[i].isFile()) {
                files[i].delete();
            } else if (files[i].isDirectory()) {
                if (!files[i].delete()) {
                    delete(files[i]);
                }
            }
        }
        deleteDirectory(file);
        return file.delete();
    }

    /**
     * delete all the sub-folders in 'file'
     * 
     * @param file
     */
    private void deleteDirectory(java.io.File file) {
        java.io.File[] filed = file.listFiles();
        for (int i = 0; i < filed.length; i++) {
        	if(filed[i].isDirectory()) {
            	deleteDirectory(filed[i]);
            }
            filed[i].delete();
        }
    }

}
    java.io.File file_tFileDelete_3=new java.io.File(context.ETL_STORAGE_PATH + "/" + context.GP_SOURCE_NAME + '/' + "/data/" + context.SOURCE_DATABASE + "/" + ((String)globalMap.get("row7.log_table_name")).replace("\"","").replace("#","__hash__").replace("$","__dollar__")+".txt");
    if(file_tFileDelete_3.exists()&& file_tFileDelete_3.isFile()){
    	if(file_tFileDelete_3.delete()){
    		globalMap.put("tFileDelete_3_CURRENT_STATUS", "File deleted.");
    		log.info("tFileDelete_3 - File : "+ file_tFileDelete_3.getAbsolutePath() + " is deleted.");
    	}else{
    		globalMap.put("tFileDelete_3_CURRENT_STATUS", "No file deleted.");
    		log.info("tFileDelete_3 - Fail to delete file : "+ file_tFileDelete_3.getAbsolutePath());
    	}
    }else{
    	globalMap.put("tFileDelete_3_CURRENT_STATUS", "File does not exist or is invalid.");
			log.error("tFileDelete_3 - "+ file_tFileDelete_3.getAbsolutePath() + " does not exist or is invalid or is not a file.");
	}
	globalMap.put("tFileDelete_3_DELETE_PATH",context.ETL_STORAGE_PATH + "/" + context.GP_SOURCE_NAME + '/' + "/data/" + context.SOURCE_DATABASE + "/" + ((String)globalMap.get("row7.log_table_name")).replace("\"","").replace("#","__hash__").replace("$","__dollar__")+".txt");
    
     
 

 


	tos_count_tFileDelete_3++;

/**
 * [tFileDelete_3 main ] stop
 */
	
	/**
	 * [tFileDelete_3 end ] start
	 */

	

	
	
	currentComponent="tFileDelete_3";

	

 
                if(log.isDebugEnabled())
            log.debug("tFileDelete_3 - "  + ("Done.") );

ok_Hash.put("tFileDelete_3", true);
end_Hash.put("tFileDelete_3", System.currentTimeMillis());




/**
 * [tFileDelete_3 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage());
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tFileDelete_3 finally ] start
	 */

	

	
	
	currentComponent="tFileDelete_3";

	

 



/**
 * [tFileDelete_3 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tFileDelete_3_SUBPROCESS_STATE", 1);
	}
	

public void tFileExist_3Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tFileExist_3_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tFileExist_3 begin ] start
	 */

	

	
		
		ok_Hash.put("tFileExist_3", false);
		start_Hash.put("tFileExist_3", System.currentTimeMillis());
		
	
	currentComponent="tFileExist_3";

	
		int tos_count_tFileExist_3 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tFileExist_3 - "  + ("Start to work.") );
    	class BytesLimit65535_tFileExist_3{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tFileExist_3 = new StringBuilder();
            log4jParamters_tFileExist_3.append("Parameters:");
                    log4jParamters_tFileExist_3.append("FILE_NAME" + " = " + "context.ETL_STORAGE_PATH + \"/\" + context.GP_SOURCE_NAME + '/' + \"/data/\" + context.SOURCE_DATABASE + \"/\" + ((String)globalMap.get(\"row7.log_table_name\")).replace(\"\\\"\",\"\").replace(\"#\",\"__hash__\").replace(\"$\",\"__dollar__\")+\".txt\"");
                log4jParamters_tFileExist_3.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tFileExist_3 - "  + (log4jParamters_tFileExist_3) );
    		}
    	}
    	
        new BytesLimit65535_tFileExist_3().limitLog4jByte();

 



/**
 * [tFileExist_3 begin ] stop
 */
	
	/**
	 * [tFileExist_3 main ] start
	 */

	

	
	
	currentComponent="tFileExist_3";

	


				final StringBuffer log4jSb_tFileExist_3 = new StringBuffer();
			

java.io.File file_tFileExist_3 = new java.io.File(context.ETL_STORAGE_PATH + "/" + context.GP_SOURCE_NAME + '/' + "/data/" + context.SOURCE_DATABASE + "/" + ((String)globalMap.get("row7.log_table_name")).replace("\"","").replace("#","__hash__").replace("$","__dollar__")+".txt");
if (!file_tFileExist_3.exists()) {
    globalMap.put("tFileExist_3_EXISTS",false);
    log.info("tFileExist_3 - Directory or file : " + file_tFileExist_3.getAbsolutePath() + " doesn't exist.");
}else{
	globalMap.put("tFileExist_3_EXISTS",true);
    log.info("tFileExist_3 - Directory or file : " + file_tFileExist_3.getAbsolutePath() + " exists.");
}

globalMap.put("tFileExist_3_FILENAME",context.ETL_STORAGE_PATH + "/" + context.GP_SOURCE_NAME + '/' + "/data/" + context.SOURCE_DATABASE + "/" + ((String)globalMap.get("row7.log_table_name")).replace("\"","").replace("#","__hash__").replace("$","__dollar__")+".txt");


 


	tos_count_tFileExist_3++;

/**
 * [tFileExist_3 main ] stop
 */
	
	/**
	 * [tFileExist_3 end ] start
	 */

	

	
	
	currentComponent="tFileExist_3";

	

 
                if(log.isDebugEnabled())
            log.debug("tFileExist_3 - "  + ("Done.") );

ok_Hash.put("tFileExist_3", true);
end_Hash.put("tFileExist_3", System.currentTimeMillis());

   			if (((Boolean)globalMap.get("tFileExist_3_EXISTS"))) {
   				
					if(execStat){   
   	 					runStat.updateStatOnConnection("If24", 0, "true");
					}
				
    			tFileDelete_3Process(globalMap);
   			}

			   
   				else{
					if(execStat){   
   	 					runStat.updateStatOnConnection("If24", 0, "false");
					}   	 
   				}



/**
 * [tFileExist_3 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage());
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tFileExist_3 finally ] start
	 */

	

	
	
	currentComponent="tFileExist_3";

	

 



/**
 * [tFileExist_3 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tFileExist_3_SUBPROCESS_STATE", 1);
	}
	

public void tSetGlobalVar_7Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tSetGlobalVar_7_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tSetGlobalVar_7 begin ] start
	 */

	

	
		
		ok_Hash.put("tSetGlobalVar_7", false);
		start_Hash.put("tSetGlobalVar_7", System.currentTimeMillis());
		
	
	currentComponent="tSetGlobalVar_7";

	
		int tos_count_tSetGlobalVar_7 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tSetGlobalVar_7 - "  + ("Start to work.") );
    	class BytesLimit65535_tSetGlobalVar_7{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tSetGlobalVar_7 = new StringBuilder();
            log4jParamters_tSetGlobalVar_7.append("Parameters:");
                    log4jParamters_tSetGlobalVar_7.append("VARIABLES" + " = " + "[{VALUE="+("\"\"")+", KEY="+("\"insert_log_sql\"")+"}, {VALUE="+("\"\"")+", KEY="+("\"insert_log_template\"")+"}, {VALUE="+("\"\"")+", KEY="+("\"increment_rolling_call\"")+"}, {VALUE="+("\"\"")+", KEY="+("\"increment_rolling_call_template\"")+"}, {VALUE="+("\"\"")+", KEY="+("\"softdelete_call\"")+"}, {VALUE="+("\"\"")+", KEY="+("\"softdelete_call_template\"")+"}, {VALUE="+("\"\"")+", KEY="+("\"data_profiling_call\"")+"}, {VALUE="+("\"\"")+", KEY="+("\"data_profiling_call_template\"")+"}, {VALUE="+("\"\"")+", KEY="+("\"gp_sql\"")+"}]");
                log4jParamters_tSetGlobalVar_7.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tSetGlobalVar_7 - "  + (log4jParamters_tSetGlobalVar_7) );
    		}
    	}
    	
        new BytesLimit65535_tSetGlobalVar_7().limitLog4jByte();

 



/**
 * [tSetGlobalVar_7 begin ] stop
 */
	
	/**
	 * [tSetGlobalVar_7 main ] start
	 */

	

	
	
	currentComponent="tSetGlobalVar_7";

	

globalMap.put("insert_log_sql", "");
globalMap.put("insert_log_template", "");
globalMap.put("increment_rolling_call", "");
globalMap.put("increment_rolling_call_template", "");
globalMap.put("softdelete_call", "");
globalMap.put("softdelete_call_template", "");
globalMap.put("data_profiling_call", "");
globalMap.put("data_profiling_call_template", "");
globalMap.put("gp_sql", "");

 


	tos_count_tSetGlobalVar_7++;

/**
 * [tSetGlobalVar_7 main ] stop
 */
	
	/**
	 * [tSetGlobalVar_7 end ] start
	 */

	

	
	
	currentComponent="tSetGlobalVar_7";

	

 
                if(log.isDebugEnabled())
            log.debug("tSetGlobalVar_7 - "  + ("Done.") );

ok_Hash.put("tSetGlobalVar_7", true);
end_Hash.put("tSetGlobalVar_7", System.currentTimeMillis());




/**
 * [tSetGlobalVar_7 end ] stop
 */
				}//end the resume

				
				    			if(resumeEntryMethodName == null || globalResumeTicket){
				    				resumeUtil.addLog("CHECKPOINT", "CONNECTION:SUBJOB_OK:tSetGlobalVar_7:OnSubjobOk", "", Thread.currentThread().getId() + "", "", "", "", "", "");
								}	    				    			
					    	
								if(execStat){    	
									runStat.updateStatOnConnection("OnSubjobOk80", 0, "ok");
								} 
							
							tJava_12Process(globalMap); 
						



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage());
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tSetGlobalVar_7 finally ] start
	 */

	

	
	
	currentComponent="tSetGlobalVar_7";

	

 



/**
 * [tSetGlobalVar_7 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tSetGlobalVar_7_SUBPROCESS_STATE", 1);
	}
	

public void tJava_12Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tJava_12_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tJava_12 begin ] start
	 */

	

	
		
		ok_Hash.put("tJava_12", false);
		start_Hash.put("tJava_12", System.currentTimeMillis());
		
	
	currentComponent="tJava_12";

	
		int tos_count_tJava_12 = 0;
		
    	class BytesLimit65535_tJava_12{
    		public void limitLog4jByte() throws Exception{
    			
    		}
    	}
    	
        new BytesLimit65535_tJava_12().limitLog4jByte();


System.out.println("==============================");
System.out.println("(String)context.TABLE_NAME");
System.out.println(context.getProperty("TABLE_NAME").toUpperCase());
System.out.println("==============================");
System.out.println("(String)context.LOG_PLANT_NAME");
System.out.println(context.getProperty("LOG_PLANT_NAME").toUpperCase());
System.out.println("==============================");
System.out.println("(String)context.LOG_SYSTEM_NAME");
System.out.println(context.getProperty("LOG_SYSTEM_NAME").toUpperCase());
System.out.println("==============================");

context.LOG_RUN_ID=0;
//context.LOG_PLANT_NAME="NULL";
//context.LOG_SYSTEM_NAME="NULL";
//context.LOG_TABLE_NAME="NULL";
//context.LOG_JOB_NAME="NULL";
//context.LOG_DATA_PATH="NULL";
//context.LOG_TECHNOLOGY="NULL";
context.LOG_STATUS="NULL";
context.LOG_NO_OF_INSERTS=0;
context.LOG_NO_OF_UPDATES=0;
context.LOG_NO_OF_DELETES=0;
context.LOG_NO_OF_ERRORS=0;
context.LOG_MESSAGE="NULL";
context.LOG_SOURCE_ROW_COUNT=0;
context.LOG_TARGET_ROW_COUNT=0;
context.LOG_ERROR_CATEGORY="NULL";

String strInsertLogTemplate = 
"SELECT sbdt.edl_log ("+
"  #RUN_ID, " +
"  #PLANT_NAME, " +
"  #SYSTEM_NAME, " +
"  #JOB_NAME, " +
"  #TABLE_NAME, " +
"  #STATUS, " +
"  #DATA_PATH, " +
"  #TECHNOLOGY, " +
"  #NO_OF_INSERTS, " +
"  #NO_OF_UPDATES, " +
"  #NO_OF_DELETES, " +
"  #NO_OF_ERRORS, " +
"  #MESSAGE, " +
"  #SOURCE_ROW_COUNT, " +
"  #TARGET_ROW_COUNT, " +
"  #ERROR_CATEGORY " +
") ";
globalMap.put("insert_log_template", strInsertLogTemplate);

String strIncrementRollingCallTemplate=
"SELECT sbdt.edl_increments_rolling_prod2dev ("+
"  #TARGET_SCHEMA, "+
"  #TARGET_TABLE_NAME "+
"); ";
globalMap.put("increment_rolling_call_template", strIncrementRollingCallTemplate);

String strSoftDeleteCallTemplate=
"SELECT sbdt.edl_softdelete ("+
"  #TARGET_SCHEMA, "+
"  #TARGET_TABLE_NAME "+
"); ";
globalMap.put("softdelete_call_template", strSoftDeleteCallTemplate);

String strDataProfilingCallTemplate=
"SELECT sbdt.edl_data_profiling ("+
"  #TARGET_SCHEMA, "+
"  #TARGET_TABLE_NAME "+
"); ";
globalMap.put("data_profiling_call_template", strDataProfilingCallTemplate);


String strHvrLikeUpdateCallTemplate=
"UPDATE #TARGET_SCHEMA.#TARGET_TABLE_NAME "+
"SET edl_is_deleted='0', edl_last_updated_date=clock_timestamp() "+
"; ";
globalMap.put("hvrlike_update_call_template", strHvrLikeUpdateCallTemplate);


//System.out.println("******************************");
//globalMap.put("now",new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(TalendDate.getCurrentDate()).toString());
//System.out.println(globalMap.get("now"));
//((String)globalMap.get("tJavaRow_5_ERROR_MESSAGE")) != null
//((Integer)context.LOG_RUN_ID).toString()
//globalMap.put("now_sql","TO_TIMESTAMP('" + ((String)globalMap.get("now")) + "', 'YYYY-MM-DD HH24:MI:SS')::TIMESTAMP WITH TIME ZONE ");
//System.out.println(globalMap.get("now_sql"));
//if (context.LOG_PLANT_NAME.equals("")==true) {
//  context.LOG_PLANT_NAME="Grove City";
//};
//System.out.println(globalMap.get("now"));
//((String)globalMap.get("now"))
//if (globalMap.get("now")=="X") {
//}
//if (context.getProperty("BF_SCHEMA").length() == 0) {
//	context.setProperty("TABLE_NAME", "pgpduke_energy");
//}

 



/**
 * [tJava_12 begin ] stop
 */
	
	/**
	 * [tJava_12 main ] start
	 */

	

	
	
	currentComponent="tJava_12";

	

 


	tos_count_tJava_12++;

/**
 * [tJava_12 main ] stop
 */
	
	/**
	 * [tJava_12 end ] start
	 */

	

	
	
	currentComponent="tJava_12";

	

 

ok_Hash.put("tJava_12", true);
end_Hash.put("tJava_12", System.currentTimeMillis());




/**
 * [tJava_12 end ] stop
 */
				}//end the resume

				
				    			if(resumeEntryMethodName == null || globalResumeTicket){
				    				resumeUtil.addLog("CHECKPOINT", "CONNECTION:SUBJOB_OK:tJava_12:OnSubjobOk", "", Thread.currentThread().getId() + "", "", "", "", "", "");
								}	    				    			
					    	
								if(execStat){    	
									runStat.updateStatOnConnection("OnSubjobOk81", 0, "ok");
								} 
							
							tGreenplumConnection_5Process(globalMap); 
						



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage());
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tJava_12 finally ] start
	 */

	

	
	
	currentComponent="tJava_12";

	

 



/**
 * [tJava_12 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tJava_12_SUBPROCESS_STATE", 1);
	}
	

public void tGreenplumConnection_5Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tGreenplumConnection_5_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tGreenplumConnection_5 begin ] start
	 */

	

	
		
		ok_Hash.put("tGreenplumConnection_5", false);
		start_Hash.put("tGreenplumConnection_5", System.currentTimeMillis());
		
	
	currentComponent="tGreenplumConnection_5";

	
		int tos_count_tGreenplumConnection_5 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tGreenplumConnection_5 - "  + ("Start to work.") );
    	class BytesLimit65535_tGreenplumConnection_5{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tGreenplumConnection_5 = new StringBuilder();
            log4jParamters_tGreenplumConnection_5.append("Parameters:");
                    log4jParamters_tGreenplumConnection_5.append("HOST" + " = " + "context.SOURCE_HOST");
                log4jParamters_tGreenplumConnection_5.append(" | ");
                    log4jParamters_tGreenplumConnection_5.append("PORT" + " = " + "context.SOURCE_PORT");
                log4jParamters_tGreenplumConnection_5.append(" | ");
                    log4jParamters_tGreenplumConnection_5.append("DBNAME" + " = " + "context.SOURCE_DATABASE");
                log4jParamters_tGreenplumConnection_5.append(" | ");
                    log4jParamters_tGreenplumConnection_5.append("SCHEMA_DB" + " = " + "\"\"");
                log4jParamters_tGreenplumConnection_5.append(" | ");
                    log4jParamters_tGreenplumConnection_5.append("USER" + " = " + "context.SOURCE_USER");
                log4jParamters_tGreenplumConnection_5.append(" | ");
                    log4jParamters_tGreenplumConnection_5.append("PASS" + " = " + String.valueOf(routines.system.PasswordEncryptUtil.encryptPassword(context.SOURCE_PASSWORD)).substring(0, 4) + "...");     
                log4jParamters_tGreenplumConnection_5.append(" | ");
                    log4jParamters_tGreenplumConnection_5.append("USE_SHARED_CONNECTION" + " = " + "false");
                log4jParamters_tGreenplumConnection_5.append(" | ");
                    log4jParamters_tGreenplumConnection_5.append("USE_SSL" + " = " + "true");
                log4jParamters_tGreenplumConnection_5.append(" | ");
                    log4jParamters_tGreenplumConnection_5.append("AUTO_COMMIT" + " = " + "true");
                log4jParamters_tGreenplumConnection_5.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tGreenplumConnection_5 - "  + (log4jParamters_tGreenplumConnection_5) );
    		}
    	}
    	
        new BytesLimit65535_tGreenplumConnection_5().limitLog4jByte();
	

	
				String url_tGreenplumConnection_5 = "jdbc:postgresql://"+context.SOURCE_HOST+":"+context.SOURCE_PORT+"/"+context.SOURCE_DATABASE+"?ssl=true&sslfactory=org.postgresql.ssl.NonValidatingFactory";

	String dbUser_tGreenplumConnection_5 = context.SOURCE_USER;
	
	
		
	final String decryptedPassword_tGreenplumConnection_5 = context.SOURCE_PASSWORD; 
		String dbPwd_tGreenplumConnection_5 = decryptedPassword_tGreenplumConnection_5;
	

	java.sql.Connection conn_tGreenplumConnection_5 = null;
	
		
			String driverClass_tGreenplumConnection_5 = "org.postgresql.Driver";
			java.lang.Class.forName(driverClass_tGreenplumConnection_5);
		
	    		log.debug("tGreenplumConnection_5 - Driver ClassName: "+driverClass_tGreenplumConnection_5+".");
			
	    		log.debug("tGreenplumConnection_5 - Connection attempt to '" + url_tGreenplumConnection_5 + "' with the username '" + dbUser_tGreenplumConnection_5 + "'.");
			
		conn_tGreenplumConnection_5 = java.sql.DriverManager.getConnection(url_tGreenplumConnection_5,dbUser_tGreenplumConnection_5,dbPwd_tGreenplumConnection_5);
	    		log.debug("tGreenplumConnection_5 - Connection to '" + url_tGreenplumConnection_5 + "' has succeeded.");
			

		globalMap.put("conn_tGreenplumConnection_5", conn_tGreenplumConnection_5);
	if (null != conn_tGreenplumConnection_5) {
		
			log.debug("tGreenplumConnection_5 - Connection is set auto commit to 'true'.");
			conn_tGreenplumConnection_5.setAutoCommit(true);
	}

	globalMap.put("schema_" + "tGreenplumConnection_5","");

	globalMap.put("conn_" + "tGreenplumConnection_5",conn_tGreenplumConnection_5);
 



/**
 * [tGreenplumConnection_5 begin ] stop
 */
	
	/**
	 * [tGreenplumConnection_5 main ] start
	 */

	

	
	
	currentComponent="tGreenplumConnection_5";

	

 


	tos_count_tGreenplumConnection_5++;

/**
 * [tGreenplumConnection_5 main ] stop
 */
	
	/**
	 * [tGreenplumConnection_5 end ] start
	 */

	

	
	
	currentComponent="tGreenplumConnection_5";

	

 
                if(log.isDebugEnabled())
            log.debug("tGreenplumConnection_5 - "  + ("Done.") );

ok_Hash.put("tGreenplumConnection_5", true);
end_Hash.put("tGreenplumConnection_5", System.currentTimeMillis());




/**
 * [tGreenplumConnection_5 end ] stop
 */
				}//end the resume

				
				    			if(resumeEntryMethodName == null || globalResumeTicket){
				    				resumeUtil.addLog("CHECKPOINT", "CONNECTION:SUBJOB_OK:tGreenplumConnection_5:OnSubjobOk", "", Thread.currentThread().getId() + "", "", "", "", "", "");
								}	    				    			
					    	
								if(execStat){    	
									runStat.updateStatOnConnection("OnSubjobOk82", 0, "ok");
								} 
							
							tGreenplumInput_1Process(globalMap); 
						



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage());
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tGreenplumConnection_5 finally ] start
	 */

	

	
	
	currentComponent="tGreenplumConnection_5";

	

 



/**
 * [tGreenplumConnection_5 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tGreenplumConnection_5_SUBPROCESS_STATE", 1);
	}
	


public static class row3Struct implements routines.system.IPersistableRow<row3Struct> {
    final static byte[] commonByteArrayLock_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Prod2Dev_with_GP_FDIST_child = new byte[0];
    static byte[] commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Prod2Dev_with_GP_FDIST_child = new byte[0];

	
			    public Integer run_id;

				public Integer getRun_id () {
					return this.run_id;
				}
				


	private Integer readInteger(ObjectInputStream dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}

	private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException{
		if(intNum == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeInt(intNum);
    	}
	}

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Prod2Dev_with_GP_FDIST_child) {

        	try {

        		int length = 0;
		
						this.run_id = readInteger(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// Integer
				
						writeInteger(this.run_id,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("run_id="+String.valueOf(run_id));
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				if(run_id == null){
        					sb.append("<null>");
        				}else{
            				sb.append(run_id);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(row3Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}
public void tGreenplumInput_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tGreenplumInput_1_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;



		row3Struct row3 = new row3Struct();




	
	/**
	 * [tJavaRow_4 begin ] start
	 */

	

	
		
		ok_Hash.put("tJavaRow_4", false);
		start_Hash.put("tJavaRow_4", System.currentTimeMillis());
		
	
	currentComponent="tJavaRow_4";

	
			if (execStat) {
				if(resourceMap.get("inIterateVComp") == null){
					
						runStat.updateStatOnConnection("row3" + iterateId, 0, 0);
					
				}
			} 

		
		int tos_count_tJavaRow_4 = 0;
		
    	class BytesLimit65535_tJavaRow_4{
    		public void limitLog4jByte() throws Exception{
    			
    		}
    	}
    	
        new BytesLimit65535_tJavaRow_4().limitLog4jByte();

int nb_line_tJavaRow_4 = 0;

 



/**
 * [tJavaRow_4 begin ] stop
 */



	
	/**
	 * [tGreenplumInput_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tGreenplumInput_1", false);
		start_Hash.put("tGreenplumInput_1", System.currentTimeMillis());
		
	
	currentComponent="tGreenplumInput_1";

	
		int tos_count_tGreenplumInput_1 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tGreenplumInput_1 - "  + ("Start to work.") );
    	class BytesLimit65535_tGreenplumInput_1{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tGreenplumInput_1 = new StringBuilder();
            log4jParamters_tGreenplumInput_1.append("Parameters:");
                    log4jParamters_tGreenplumInput_1.append("USE_EXISTING_CONNECTION" + " = " + "true");
                log4jParamters_tGreenplumInput_1.append(" | ");
                    log4jParamters_tGreenplumInput_1.append("CONNECTION" + " = " + "tGreenplumConnection_5");
                log4jParamters_tGreenplumInput_1.append(" | ");
                    log4jParamters_tGreenplumInput_1.append("TABLE" + " = " + "\"\"");
                log4jParamters_tGreenplumInput_1.append(" | ");
                    log4jParamters_tGreenplumInput_1.append("QUERYSTORE" + " = " + "\"\"");
                log4jParamters_tGreenplumInput_1.append(" | ");
                    log4jParamters_tGreenplumInput_1.append("QUERY" + " = " + "\"select NEXTVAL('sbdt.edl_run_id_seq')\";  ");
                log4jParamters_tGreenplumInput_1.append(" | ");
                    log4jParamters_tGreenplumInput_1.append("USE_CURSOR" + " = " + "true");
                log4jParamters_tGreenplumInput_1.append(" | ");
                    log4jParamters_tGreenplumInput_1.append("CURSOR_SIZE" + " = " + "1000");
                log4jParamters_tGreenplumInput_1.append(" | ");
                    log4jParamters_tGreenplumInput_1.append("TRIM_ALL_COLUMN" + " = " + "false");
                log4jParamters_tGreenplumInput_1.append(" | ");
                    log4jParamters_tGreenplumInput_1.append("TRIM_COLUMN" + " = " + "[{TRIM="+("false")+", SCHEMA_COLUMN="+("run_id")+"}]");
                log4jParamters_tGreenplumInput_1.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tGreenplumInput_1 - "  + (log4jParamters_tGreenplumInput_1) );
    		}
    	}
    	
        new BytesLimit65535_tGreenplumInput_1().limitLog4jByte();
	
    
	
		    int nb_line_tGreenplumInput_1 = 0;
		    java.sql.Connection conn_tGreenplumInput_1 = null;
		        conn_tGreenplumInput_1 = (java.sql.Connection)globalMap.get("conn_tGreenplumConnection_5");
				
				if(conn_tGreenplumInput_1 != null) {
					if(conn_tGreenplumInput_1.getMetaData() != null) {
						
						log.debug("tGreenplumInput_1 - Uses an existing connection with username '" + conn_tGreenplumInput_1.getMetaData().getUserName() + "'. Connection URL: " + conn_tGreenplumInput_1.getMetaData().getURL() + ".");
						
					}
				}
			
		    
			java.sql.Statement stmt_tGreenplumInput_1 = conn_tGreenplumInput_1.createStatement();
                stmt_tGreenplumInput_1.setFetchSize(1000);

		    String dbquery_tGreenplumInput_1 = "select NEXTVAL('sbdt.edl_run_id_seq')";
;
			
                log.debug("tGreenplumInput_1 - Executing the query: '"+dbquery_tGreenplumInput_1+"'.");
			

                       globalMap.put("tGreenplumInput_1_QUERY",dbquery_tGreenplumInput_1);

		    java.sql.ResultSet rs_tGreenplumInput_1 = null;
		try{
		    rs_tGreenplumInput_1 = stmt_tGreenplumInput_1.executeQuery(dbquery_tGreenplumInput_1);
		    java.sql.ResultSetMetaData rsmd_tGreenplumInput_1 = rs_tGreenplumInput_1.getMetaData();
		    int colQtyInRs_tGreenplumInput_1 = rsmd_tGreenplumInput_1.getColumnCount();

		    String tmpContent_tGreenplumInput_1 = null;
		    
		    
		    	log.debug("tGreenplumInput_1 - Retrieving records from the database.");
		    
		    while (rs_tGreenplumInput_1.next()) {
		        nb_line_tGreenplumInput_1++;
		        
							if(colQtyInRs_tGreenplumInput_1 < 1) {
								row3.run_id = null;
							} else {
		                          
            if(rs_tGreenplumInput_1.getObject(1) != null) {
                row3.run_id = rs_tGreenplumInput_1.getInt(1);
            } else {
                    row3.run_id = null;
            }
		                    }
					
						log.debug("tGreenplumInput_1 - Retrieving the record " + nb_line_tGreenplumInput_1 + ".");
					


 



/**
 * [tGreenplumInput_1 begin ] stop
 */
	
	/**
	 * [tGreenplumInput_1 main ] start
	 */

	

	
	
	currentComponent="tGreenplumInput_1";

	

 


	tos_count_tGreenplumInput_1++;

/**
 * [tGreenplumInput_1 main ] stop
 */

	
	/**
	 * [tJavaRow_4 main ] start
	 */

	

	
	
	currentComponent="tJavaRow_4";

	

			//row3
			//row3


			
				if(execStat){
					runStat.updateStatOnConnection("row3"+iterateId,1, 1);
				} 
			

		
    			if(log.isTraceEnabled()){
    				log.trace("row3 - " + (row3==null? "": row3.toLogString()));
    			}
    		

    context.LOG_RUN_ID=row3.run_id;
    nb_line_tJavaRow_4++;   

 


	tos_count_tJavaRow_4++;

/**
 * [tJavaRow_4 main ] stop
 */



	
	/**
	 * [tGreenplumInput_1 end ] start
	 */

	

	
	
	currentComponent="tGreenplumInput_1";

	

	}
}finally{
	stmt_tGreenplumInput_1.close();

}
globalMap.put("tGreenplumInput_1_NB_LINE",nb_line_tGreenplumInput_1);
	    		log.debug("tGreenplumInput_1 - Retrieved records count: "+nb_line_tGreenplumInput_1 + " .");
			

 
                if(log.isDebugEnabled())
            log.debug("tGreenplumInput_1 - "  + ("Done.") );

ok_Hash.put("tGreenplumInput_1", true);
end_Hash.put("tGreenplumInput_1", System.currentTimeMillis());




/**
 * [tGreenplumInput_1 end ] stop
 */

	
	/**
	 * [tJavaRow_4 end ] start
	 */

	

	
	
	currentComponent="tJavaRow_4";

	

globalMap.put("tJavaRow_4_NB_LINE",nb_line_tJavaRow_4);
			if(execStat){
				if(resourceMap.get("inIterateVComp") == null || !((Boolean)resourceMap.get("inIterateVComp"))){
			 		runStat.updateStatOnConnection("row3"+iterateId,2, 0); 
			 	}
			}
		
 

ok_Hash.put("tJavaRow_4", true);
end_Hash.put("tJavaRow_4", System.currentTimeMillis());

   			if (true) {
   				
					if(execStat){   
   	 					runStat.updateStatOnConnection("If33", 0, "true");
					}
				
    			tJava_13Process(globalMap);
   			}

			   
   				else{
					if(execStat){   
   	 					runStat.updateStatOnConnection("If33", 0, "false");
					}   	 
   				}



/**
 * [tJavaRow_4 end ] stop
 */



				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage());
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tGreenplumInput_1 finally ] start
	 */

	

	
	
	currentComponent="tGreenplumInput_1";

	

 



/**
 * [tGreenplumInput_1 finally ] stop
 */

	
	/**
	 * [tJavaRow_4 finally ] start
	 */

	

	
	
	currentComponent="tJavaRow_4";

	

 



/**
 * [tJavaRow_4 finally ] stop
 */



				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tGreenplumInput_1_SUBPROCESS_STATE", 1);
	}
	

public void tJava_13Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tJava_13_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tJava_13 begin ] start
	 */

	

	
		
		ok_Hash.put("tJava_13", false);
		start_Hash.put("tJava_13", System.currentTimeMillis());
		
	
	currentComponent="tJava_13";

	
		int tos_count_tJava_13 = 0;
		
    	class BytesLimit65535_tJava_13{
    		public void limitLog4jByte() throws Exception{
    			
    		}
    	}
    	
        new BytesLimit65535_tJava_13().limitLog4jByte();


//context.LOG_PLANT_NAME="NULL";
//context.LOG_SYSTEM_NAME="NULL";
//context.LOG_TABLE_NAME="NULL";
//context.LOG_JOB_NAME="NULL";
//context.LOG_DATA_PATH="NULL";
//context.LOG_TECHNOLOGY="NULL";
context.LOG_STATUS="Start";
context.LOG_MESSAGE="NULL";
context.LOG_ERROR_CATEGORY="NULL";
context.LOG_NO_OF_INSERTS=0;
context.LOG_NO_OF_UPDATES=0;
context.LOG_NO_OF_DELETES=0;
context.LOG_NO_OF_ERRORS=0;
context.LOG_SOURCE_ROW_COUNT=0;
context.LOG_TARGET_ROW_COUNT=0;


String strInsertLogSql=(String)globalMap.get("insert_log_template");
strInsertLogSql=strInsertLogSql.replace("#RUN_ID", ((Integer)context.LOG_RUN_ID).toString());
strInsertLogSql=strInsertLogSql.replace("#PLANT_NAME", "'"+context.LOG_PLANT_NAME+"'");
strInsertLogSql=strInsertLogSql.replace("#SYSTEM_NAME", "'"+context.LOG_SYSTEM_NAME+"'");
strInsertLogSql=strInsertLogSql.replace("#JOB_NAME", "'"+context.LOG_JOB_NAME+"'");
strInsertLogSql=strInsertLogSql.replace("#TABLE_NAME", "'"+context.TABLE_NAME+"'");
strInsertLogSql=strInsertLogSql.replace("#STATUS", "'"+context.LOG_STATUS+"'");
strInsertLogSql=strInsertLogSql.replace("#DATA_PATH", "'"+context.LOG_DATA_PATH+"'");
strInsertLogSql=strInsertLogSql.replace("#TECHNOLOGY", "'"+context.LOG_TECHNOLOGY+"'");
strInsertLogSql=strInsertLogSql.replace("#NO_OF_INSERTS", ((Integer)context.LOG_NO_OF_INSERTS).toString());
strInsertLogSql=strInsertLogSql.replace("#NO_OF_UPDATES", ((Integer)context.LOG_NO_OF_UPDATES).toString());
strInsertLogSql=strInsertLogSql.replace("#NO_OF_DELETES", ((Integer)context.LOG_NO_OF_DELETES).toString());
strInsertLogSql=strInsertLogSql.replace("#NO_OF_ERRORS", ((Integer)context.LOG_NO_OF_ERRORS).toString());
strInsertLogSql=strInsertLogSql.replace("#MESSAGE", "'"+context.LOG_MESSAGE+"'");
strInsertLogSql=strInsertLogSql.replace("#SOURCE_ROW_COUNT", ((Integer)context.LOG_SOURCE_ROW_COUNT).toString());
strInsertLogSql=strInsertLogSql.replace("#TARGET_ROW_COUNT", ((Integer)context.LOG_TARGET_ROW_COUNT).toString());
strInsertLogSql=strInsertLogSql.replace("#ERROR_CATEGORY", "'"+context.LOG_ERROR_CATEGORY+"'");
globalMap.put("insert_log_sql",strInsertLogSql);
//System.out.println(globalMap.get("insert_log_sql"));
//System.out.println("==============================");
//System.out.println("==============================");
//globalMap.put("now",new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(TalendDate.getCurrentDate()).toString());
//System.out.println(globalMap.get("now"));
//globalMap.put("now_sql","TO_TIMESTAMP('" + ((String)globalMap.get("now")) + "', 'YYYY-MM-DD HH24:MI:SS')::TIMESTAMP WITH TIME ZONE ");
//System.out.println(globalMap.get("now_sql"));
//if (context.LOG_PLANT_NAME.equals("")==true) {
//  context.LOG_PLANT_NAME="Grove City";
//};
//if (context.LOG_APPLICATION.equals("")==true) {
//  context.LOG_APPLICATION="GET-ABM";
//};
 



/**
 * [tJava_13 begin ] stop
 */
	
	/**
	 * [tJava_13 main ] start
	 */

	

	
	
	currentComponent="tJava_13";

	

 


	tos_count_tJava_13++;

/**
 * [tJava_13 main ] stop
 */
	
	/**
	 * [tJava_13 end ] start
	 */

	

	
	
	currentComponent="tJava_13";

	

 

ok_Hash.put("tJava_13", true);
end_Hash.put("tJava_13", System.currentTimeMillis());




/**
 * [tJava_13 end ] stop
 */
				}//end the resume

				
				    			if(resumeEntryMethodName == null || globalResumeTicket){
				    				resumeUtil.addLog("CHECKPOINT", "CONNECTION:SUBJOB_OK:tJava_13:OnSubjobOk", "", Thread.currentThread().getId() + "", "", "", "", "", "");
								}	    				    			
					    	
								if(execStat){    	
									runStat.updateStatOnConnection("OnSubjobOk83", 0, "ok");
								} 
							
							tGreenplumRow_12Process(globalMap); 
						



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage());
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tJava_13 finally ] start
	 */

	

	
	
	currentComponent="tJava_13";

	

 



/**
 * [tJava_13 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tJava_13_SUBPROCESS_STATE", 1);
	}
	

public void tGreenplumRow_12Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tGreenplumRow_12_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tGreenplumRow_12 begin ] start
	 */

	

	
		
		ok_Hash.put("tGreenplumRow_12", false);
		start_Hash.put("tGreenplumRow_12", System.currentTimeMillis());
		
	
	currentComponent="tGreenplumRow_12";

	
		int tos_count_tGreenplumRow_12 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tGreenplumRow_12 - "  + ("Start to work.") );
    	class BytesLimit65535_tGreenplumRow_12{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tGreenplumRow_12 = new StringBuilder();
            log4jParamters_tGreenplumRow_12.append("Parameters:");
                    log4jParamters_tGreenplumRow_12.append("USE_EXISTING_CONNECTION" + " = " + "true");
                log4jParamters_tGreenplumRow_12.append(" | ");
                    log4jParamters_tGreenplumRow_12.append("CONNECTION" + " = " + "tGreenplumConnection_5");
                log4jParamters_tGreenplumRow_12.append(" | ");
                    log4jParamters_tGreenplumRow_12.append("QUERYSTORE" + " = " + "\"\"");
                log4jParamters_tGreenplumRow_12.append(" | ");
                    log4jParamters_tGreenplumRow_12.append("QUERY" + " = " + "(String)globalMap.get(\"insert_log_sql\")");
                log4jParamters_tGreenplumRow_12.append(" | ");
                    log4jParamters_tGreenplumRow_12.append("DIE_ON_ERROR" + " = " + "true");
                log4jParamters_tGreenplumRow_12.append(" | ");
                    log4jParamters_tGreenplumRow_12.append("PROPAGATE_RECORD_SET" + " = " + "false");
                log4jParamters_tGreenplumRow_12.append(" | ");
                    log4jParamters_tGreenplumRow_12.append("USE_PREPAREDSTATEMENT" + " = " + "false");
                log4jParamters_tGreenplumRow_12.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tGreenplumRow_12 - "  + (log4jParamters_tGreenplumRow_12) );
    		}
    	}
    	
        new BytesLimit65535_tGreenplumRow_12().limitLog4jByte();

	java.sql.Connection conn_tGreenplumRow_12 = null;
	String query_tGreenplumRow_12 = "";
	boolean whetherReject_tGreenplumRow_12 = false;
				conn_tGreenplumRow_12 = (java.sql.Connection)globalMap.get("conn_tGreenplumConnection_5");
			
				if(conn_tGreenplumRow_12 != null) {
					if(conn_tGreenplumRow_12.getMetaData() != null) {
						
						log.debug("tGreenplumRow_12 - Uses an existing connection with username '" + conn_tGreenplumRow_12.getMetaData().getUserName() + "'. Connection URL: " + conn_tGreenplumRow_12.getMetaData().getURL() + ".");
						
					}
				}
			
		java.sql.Statement stmt_tGreenplumRow_12 = conn_tGreenplumRow_12.createStatement();
	

 



/**
 * [tGreenplumRow_12 begin ] stop
 */
	
	/**
	 * [tGreenplumRow_12 main ] start
	 */

	

	
	
	currentComponent="tGreenplumRow_12";

	

	    		log.debug("tGreenplumRow_12 - Executing the query: '" + (String)globalMap.get("insert_log_sql") + "'.");
			
query_tGreenplumRow_12 = (String)globalMap.get("insert_log_sql");
whetherReject_tGreenplumRow_12 = false;
globalMap.put("tGreenplumRow_12_QUERY",query_tGreenplumRow_12);
try {
		stmt_tGreenplumRow_12.execute(query_tGreenplumRow_12);
		
	    		log.info("tGreenplumRow_12 - Execute the query: '" + (String)globalMap.get("insert_log_sql") + "' has finished.");
			
	} catch (java.lang.Exception e) {
		whetherReject_tGreenplumRow_12 = true;
		
			throw(e);
			
	}
	
	if(!whetherReject_tGreenplumRow_12) {
		
	}
	

 


	tos_count_tGreenplumRow_12++;

/**
 * [tGreenplumRow_12 main ] stop
 */
	
	/**
	 * [tGreenplumRow_12 end ] start
	 */

	

	
	
	currentComponent="tGreenplumRow_12";

	

	
	stmt_tGreenplumRow_12.close();	

 
                if(log.isDebugEnabled())
            log.debug("tGreenplumRow_12 - "  + ("Done.") );

ok_Hash.put("tGreenplumRow_12", true);
end_Hash.put("tGreenplumRow_12", System.currentTimeMillis());




/**
 * [tGreenplumRow_12 end ] stop
 */
				}//end the resume

				
				    			if(resumeEntryMethodName == null || globalResumeTicket){
				    				resumeUtil.addLog("CHECKPOINT", "CONNECTION:SUBJOB_OK:tGreenplumRow_12:OnSubjobOk", "", Thread.currentThread().getId() + "", "", "", "", "", "");
								}	    				    			
					    	
								if(execStat){    	
									runStat.updateStatOnConnection("OnSubjobOk84", 0, "ok");
								} 
							
							tGreenplumClose_8Process(globalMap); 
						



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage());
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tGreenplumRow_12 finally ] start
	 */

	

	
	
	currentComponent="tGreenplumRow_12";

	

 



/**
 * [tGreenplumRow_12 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tGreenplumRow_12_SUBPROCESS_STATE", 1);
	}
	

public void tGreenplumClose_8Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tGreenplumClose_8_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tGreenplumClose_8 begin ] start
	 */

	

	
		
		ok_Hash.put("tGreenplumClose_8", false);
		start_Hash.put("tGreenplumClose_8", System.currentTimeMillis());
		
	
	currentComponent="tGreenplumClose_8";

	
		int tos_count_tGreenplumClose_8 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tGreenplumClose_8 - "  + ("Start to work.") );
    	class BytesLimit65535_tGreenplumClose_8{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tGreenplumClose_8 = new StringBuilder();
            log4jParamters_tGreenplumClose_8.append("Parameters:");
                    log4jParamters_tGreenplumClose_8.append("CONNECTION" + " = " + "tGreenplumConnection_5");
                log4jParamters_tGreenplumClose_8.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tGreenplumClose_8 - "  + (log4jParamters_tGreenplumClose_8) );
    		}
    	}
    	
        new BytesLimit65535_tGreenplumClose_8().limitLog4jByte();

 



/**
 * [tGreenplumClose_8 begin ] stop
 */
	
	/**
	 * [tGreenplumClose_8 main ] start
	 */

	

	
	
	currentComponent="tGreenplumClose_8";

	



	java.sql.Connection conn_tGreenplumClose_8 = (java.sql.Connection)globalMap.get("conn_tGreenplumConnection_5");
	if(conn_tGreenplumClose_8 != null && !conn_tGreenplumClose_8.isClosed())
	{
                if(log.isDebugEnabled())
            log.debug("tGreenplumClose_8 - "  + ("Closing the connection ")  + ("conn_tGreenplumConnection_5")  + (" to the database.") );
        conn_tGreenplumClose_8.close();
                if(log.isDebugEnabled())
            log.debug("tGreenplumClose_8 - "  + ("Connection ")  + ("conn_tGreenplumConnection_5")  + (" to the database has closed.") );
	}

 


	tos_count_tGreenplumClose_8++;

/**
 * [tGreenplumClose_8 main ] stop
 */
	
	/**
	 * [tGreenplumClose_8 end ] start
	 */

	

	
	
	currentComponent="tGreenplumClose_8";

	

 
                if(log.isDebugEnabled())
            log.debug("tGreenplumClose_8 - "  + ("Done.") );

ok_Hash.put("tGreenplumClose_8", true);
end_Hash.put("tGreenplumClose_8", System.currentTimeMillis());




/**
 * [tGreenplumClose_8 end ] stop
 */
				}//end the resume

				
				    			if(resumeEntryMethodName == null || globalResumeTicket){
				    				resumeUtil.addLog("CHECKPOINT", "CONNECTION:SUBJOB_OK:tGreenplumClose_8:OnSubjobOk", "", Thread.currentThread().getId() + "", "", "", "", "", "");
								}	    				    			
					    	
								if(execStat){    	
									runStat.updateStatOnConnection("OnSubjobOk85", 0, "ok");
								} 
							
							tJava_16Process(globalMap); 
						



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage());
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tGreenplumClose_8 finally ] start
	 */

	

	
	
	currentComponent="tGreenplumClose_8";

	

 



/**
 * [tGreenplumClose_8 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tGreenplumClose_8_SUBPROCESS_STATE", 1);
	}
	


public static class row14Struct implements routines.system.IPersistableRow<row14Struct> {
    final static byte[] commonByteArrayLock_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Prod2Dev_with_GP_FDIST_child = new byte[0];
    static byte[] commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Prod2Dev_with_GP_FDIST_child = new byte[0];

	
			    public java.util.Date moment;

				public java.util.Date getMoment () {
					return this.moment;
				}
				
			    public String pid;

				public String getPid () {
					return this.pid;
				}
				
			    public String root_pid;

				public String getRoot_pid () {
					return this.root_pid;
				}
				
			    public String father_pid;

				public String getFather_pid () {
					return this.father_pid;
				}
				
			    public String project;

				public String getProject () {
					return this.project;
				}
				
			    public String job;

				public String getJob () {
					return this.job;
				}
				
			    public String context;

				public String getContext () {
					return this.context;
				}
				
			    public Integer priority;

				public Integer getPriority () {
					return this.priority;
				}
				
			    public String type;

				public String getType () {
					return this.type;
				}
				
			    public String origin;

				public String getOrigin () {
					return this.origin;
				}
				
			    public String message;

				public String getMessage () {
					return this.message;
				}
				
			    public Integer code;

				public Integer getCode () {
					return this.code;
				}
				



	private java.util.Date readDate(ObjectInputStream dis) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(dis.readLong());
		}
		return dateReturn;
	}

    private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException{
		if(date1 == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeLong(date1.getTime());
    	}
    }

	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Prod2Dev_with_GP_FDIST_child.length) {
				if(length < 1024 && commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Prod2Dev_with_GP_FDIST_child.length == 0) {
   					commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Prod2Dev_with_GP_FDIST_child = new byte[1024];
				} else {
   					commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Prod2Dev_with_GP_FDIST_child = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Prod2Dev_with_GP_FDIST_child, 0, length);
			strReturn = new String(commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Prod2Dev_with_GP_FDIST_child, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
	private Integer readInteger(ObjectInputStream dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}

	private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException{
		if(intNum == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeInt(intNum);
    	}
	}

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Prod2Dev_with_GP_FDIST_child) {

        	try {

        		int length = 0;
		
					this.moment = readDate(dis);
					
					this.pid = readString(dis);
					
					this.root_pid = readString(dis);
					
					this.father_pid = readString(dis);
					
					this.project = readString(dis);
					
					this.job = readString(dis);
					
					this.context = readString(dis);
					
						this.priority = readInteger(dis);
					
					this.type = readString(dis);
					
					this.origin = readString(dis);
					
					this.message = readString(dis);
					
						this.code = readInteger(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// java.util.Date
				
						writeDate(this.moment,dos);
					
					// String
				
						writeString(this.pid,dos);
					
					// String
				
						writeString(this.root_pid,dos);
					
					// String
				
						writeString(this.father_pid,dos);
					
					// String
				
						writeString(this.project,dos);
					
					// String
				
						writeString(this.job,dos);
					
					// String
				
						writeString(this.context,dos);
					
					// Integer
				
						writeInteger(this.priority,dos);
					
					// String
				
						writeString(this.type,dos);
					
					// String
				
						writeString(this.origin,dos);
					
					// String
				
						writeString(this.message,dos);
					
					// Integer
				
						writeInteger(this.code,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("moment="+String.valueOf(moment));
		sb.append(",pid="+pid);
		sb.append(",root_pid="+root_pid);
		sb.append(",father_pid="+father_pid);
		sb.append(",project="+project);
		sb.append(",job="+job);
		sb.append(",context="+context);
		sb.append(",priority="+String.valueOf(priority));
		sb.append(",type="+type);
		sb.append(",origin="+origin);
		sb.append(",message="+message);
		sb.append(",code="+String.valueOf(code));
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				if(moment == null){
        					sb.append("<null>");
        				}else{
            				sb.append(moment);
            			}
            		
        			sb.append("|");
        		
        				if(pid == null){
        					sb.append("<null>");
        				}else{
            				sb.append(pid);
            			}
            		
        			sb.append("|");
        		
        				if(root_pid == null){
        					sb.append("<null>");
        				}else{
            				sb.append(root_pid);
            			}
            		
        			sb.append("|");
        		
        				if(father_pid == null){
        					sb.append("<null>");
        				}else{
            				sb.append(father_pid);
            			}
            		
        			sb.append("|");
        		
        				if(project == null){
        					sb.append("<null>");
        				}else{
            				sb.append(project);
            			}
            		
        			sb.append("|");
        		
        				if(job == null){
        					sb.append("<null>");
        				}else{
            				sb.append(job);
            			}
            		
        			sb.append("|");
        		
        				if(context == null){
        					sb.append("<null>");
        				}else{
            				sb.append(context);
            			}
            		
        			sb.append("|");
        		
        				if(priority == null){
        					sb.append("<null>");
        				}else{
            				sb.append(priority);
            			}
            		
        			sb.append("|");
        		
        				if(type == null){
        					sb.append("<null>");
        				}else{
            				sb.append(type);
            			}
            		
        			sb.append("|");
        		
        				if(origin == null){
        					sb.append("<null>");
        				}else{
            				sb.append(origin);
            			}
            		
        			sb.append("|");
        		
        				if(message == null){
        					sb.append("<null>");
        				}else{
            				sb.append(message);
            			}
            		
        			sb.append("|");
        		
        				if(code == null){
        					sb.append("<null>");
        				}else{
            				sb.append(code);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(row14Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}
public void tLogCatcher_2Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tLogCatcher_2_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;



		row14Struct row14 = new row14Struct();




	
	/**
	 * [tSetGlobalVar_9 begin ] start
	 */

	

	
		
		ok_Hash.put("tSetGlobalVar_9", false);
		start_Hash.put("tSetGlobalVar_9", System.currentTimeMillis());
		
	
	currentComponent="tSetGlobalVar_9";

	
			if (execStat) {
				if(resourceMap.get("inIterateVComp") == null){
					
						runStat.updateStatOnConnection("row14" + iterateId, 0, 0);
					
				}
			} 

		
		int tos_count_tSetGlobalVar_9 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tSetGlobalVar_9 - "  + ("Start to work.") );
    	class BytesLimit65535_tSetGlobalVar_9{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tSetGlobalVar_9 = new StringBuilder();
            log4jParamters_tSetGlobalVar_9.append("Parameters:");
                    log4jParamters_tSetGlobalVar_9.append("VARIABLES" + " = " + "[{VALUE="+("row14.job + \" - \" + row14.origin + \" - \" + row14.message")+", KEY="+("\"error_message_desc\"")+"}]");
                log4jParamters_tSetGlobalVar_9.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tSetGlobalVar_9 - "  + (log4jParamters_tSetGlobalVar_9) );
    		}
    	}
    	
        new BytesLimit65535_tSetGlobalVar_9().limitLog4jByte();

 



/**
 * [tSetGlobalVar_9 begin ] stop
 */



	
	/**
	 * [tLogCatcher_2 begin ] start
	 */

	

	
		
		ok_Hash.put("tLogCatcher_2", false);
		start_Hash.put("tLogCatcher_2", System.currentTimeMillis());
		
	
	currentComponent="tLogCatcher_2";

	
		int tos_count_tLogCatcher_2 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tLogCatcher_2 - "  + ("Start to work.") );
    	class BytesLimit65535_tLogCatcher_2{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tLogCatcher_2 = new StringBuilder();
            log4jParamters_tLogCatcher_2.append("Parameters:");
                    log4jParamters_tLogCatcher_2.append("CATCH_JAVA_EXCEPTION" + " = " + "true");
                log4jParamters_tLogCatcher_2.append(" | ");
                    log4jParamters_tLogCatcher_2.append("CATCH_TDIE" + " = " + "true");
                log4jParamters_tLogCatcher_2.append(" | ");
                    log4jParamters_tLogCatcher_2.append("CATCH_TWARN" + " = " + "true");
                log4jParamters_tLogCatcher_2.append(" | ");
                    log4jParamters_tLogCatcher_2.append("CATCH_TACTIONFAILURE" + " = " + "true");
                log4jParamters_tLogCatcher_2.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tLogCatcher_2 - "  + (log4jParamters_tLogCatcher_2) );
    		}
    	}
    	
        new BytesLimit65535_tLogCatcher_2().limitLog4jByte();

	for (LogCatcherUtils.LogCatcherMessage lcm : tLogCatcher_2.getMessages()) {
		row14.type = lcm.getType();
		row14.origin = (lcm.getOrigin()==null || lcm.getOrigin().length()<1 ? null : lcm.getOrigin());
		row14.priority = lcm.getPriority();
		row14.message = lcm.getMessage();
		row14.code = lcm.getCode();
		
		row14.moment = java.util.Calendar.getInstance().getTime();
	
    	row14.pid = pid;
		row14.root_pid = rootPid;
		row14.father_pid = fatherPid;
	
    	row14.project = projectName;
    	row14.job = jobName;
    	row14.context = contextStr;
    		
 



/**
 * [tLogCatcher_2 begin ] stop
 */
	
	/**
	 * [tLogCatcher_2 main ] start
	 */

	

	
	
	currentComponent="tLogCatcher_2";

	

 


	tos_count_tLogCatcher_2++;

/**
 * [tLogCatcher_2 main ] stop
 */

	
	/**
	 * [tSetGlobalVar_9 main ] start
	 */

	

	
	
	currentComponent="tSetGlobalVar_9";

	

			//row14
			//row14


			
				if(execStat){
					runStat.updateStatOnConnection("row14"+iterateId,1, 1);
				} 
			

		
    			if(log.isTraceEnabled()){
    				log.trace("row14 - " + (row14==null? "": row14.toLogString()));
    			}
    		

globalMap.put("error_message_desc", row14.job + " - " + row14.origin + " - " + row14.message);

 


	tos_count_tSetGlobalVar_9++;

/**
 * [tSetGlobalVar_9 main ] stop
 */



	
	/**
	 * [tLogCatcher_2 end ] start
	 */

	

	
	
	currentComponent="tLogCatcher_2";

	
	}
 
                if(log.isDebugEnabled())
            log.debug("tLogCatcher_2 - "  + ("Done.") );

ok_Hash.put("tLogCatcher_2", true);
end_Hash.put("tLogCatcher_2", System.currentTimeMillis());




/**
 * [tLogCatcher_2 end ] stop
 */

	
	/**
	 * [tSetGlobalVar_9 end ] start
	 */

	

	
	
	currentComponent="tSetGlobalVar_9";

	

			if(execStat){
				if(resourceMap.get("inIterateVComp") == null || !((Boolean)resourceMap.get("inIterateVComp"))){
			 		runStat.updateStatOnConnection("row14"+iterateId,2, 0); 
			 	}
			}
		
 
                if(log.isDebugEnabled())
            log.debug("tSetGlobalVar_9 - "  + ("Done.") );

ok_Hash.put("tSetGlobalVar_9", true);
end_Hash.put("tSetGlobalVar_9", System.currentTimeMillis());




/**
 * [tSetGlobalVar_9 end ] stop
 */



				}//end the resume

				
				    			if(resumeEntryMethodName == null || globalResumeTicket){
				    				resumeUtil.addLog("CHECKPOINT", "CONNECTION:SUBJOB_OK:tLogCatcher_2:OnSubjobOk1", "", Thread.currentThread().getId() + "", "", "", "", "", "");
								}	    				    			
					    	
								if(execStat){    	
									runStat.updateStatOnConnection("OnSubjobOk53", 0, "ok");
								} 
							
							tJava_20Process(globalMap); 
						
				    			if(resumeEntryMethodName == null || globalResumeTicket){
				    				resumeUtil.addLog("CHECKPOINT", "CONNECTION:SUBJOB_OK:tLogCatcher_2:OnSubjobOk2", "", Thread.currentThread().getId() + "", "", "", "", "", "");
								}	    				    			
					    	
								if(execStat){    	
									runStat.updateStatOnConnection("OnSubjobOk37", 0, "ok");
								} 
							
							tFileExist_3Process(globalMap); 
						
				    			if(resumeEntryMethodName == null || globalResumeTicket){
				    				resumeUtil.addLog("CHECKPOINT", "CONNECTION:SUBJOB_OK:tLogCatcher_2:OnSubjobOk3", "", Thread.currentThread().getId() + "", "", "", "", "", "");
								}	    				    			
					    	
								if(execStat){    	
									runStat.updateStatOnConnection("OnSubjobOk90", 0, "ok");
								} 
							
							tJava_14Process(globalMap); 
						



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage());
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tLogCatcher_2 finally ] start
	 */

	

	
	
	currentComponent="tLogCatcher_2";

	

 



/**
 * [tLogCatcher_2 finally ] stop
 */

	
	/**
	 * [tSetGlobalVar_9 finally ] start
	 */

	

	
	
	currentComponent="tSetGlobalVar_9";

	

 



/**
 * [tSetGlobalVar_9 finally ] stop
 */



				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tLogCatcher_2_SUBPROCESS_STATE", 1);
	}
	

public void tJava_14Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tJava_14_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tJava_14 begin ] start
	 */

	

	
		
		ok_Hash.put("tJava_14", false);
		start_Hash.put("tJava_14", System.currentTimeMillis());
		
	
	currentComponent="tJava_14";

	
		int tos_count_tJava_14 = 0;
		
    	class BytesLimit65535_tJava_14{
    		public void limitLog4jByte() throws Exception{
    			
    		}
    	}
    	
        new BytesLimit65535_tJava_14().limitLog4jByte();


//context.LOG_PLANT_NAME="NULL";
//context.LOG_SYSTEM_NAME="NULL";
//context.LOG_TABLE_NAME="NULL";
//context.LOG_JOB_NAME="NULL";
//context.LOG_DATA_PATH="NULL";
//context.LOG_TECHNOLOGY="NULL";
context.LOG_STATUS="Job Error";
context.LOG_MESSAGE=(String)globalMap.get("error_message_desc");
context.LOG_ERROR_CATEGORY="NULL";
context.LOG_NO_OF_INSERTS=0;
context.LOG_NO_OF_UPDATES=0;
context.LOG_NO_OF_DELETES=0;
context.LOG_NO_OF_ERRORS=0;
context.LOG_SOURCE_ROW_COUNT=0;
context.LOG_TARGET_ROW_COUNT=0;

context.LOG_MESSAGE = context.LOG_MESSAGE.replace("'", "''");

String strInsertLogSql=(String)globalMap.get("insert_log_template");
strInsertLogSql=strInsertLogSql.replace("#PLANT_NAME", "'"+context.LOG_PLANT_NAME+"'");
strInsertLogSql=strInsertLogSql.replace("#SYSTEM_NAME", "'"+context.LOG_SYSTEM_NAME+"'");
strInsertLogSql=strInsertLogSql.replace("#JOB_NAME", "'"+context.LOG_JOB_NAME+"'");
strInsertLogSql=strInsertLogSql.replace("#TABLE_NAME", "'"+context.TABLE_NAME+"'");
strInsertLogSql=strInsertLogSql.replace("#STATUS", "'"+context.LOG_STATUS+"'");
strInsertLogSql=strInsertLogSql.replace("#DATA_PATH", "'"+context.LOG_DATA_PATH+"'");
strInsertLogSql=strInsertLogSql.replace("#TECHNOLOGY", "'"+context.LOG_TECHNOLOGY+"'");
strInsertLogSql=strInsertLogSql.replace("#NO_OF_INSERTS", ((Integer)context.LOG_NO_OF_INSERTS).toString());
strInsertLogSql=strInsertLogSql.replace("#NO_OF_UPDATES", ((Integer)context.LOG_NO_OF_UPDATES).toString());
strInsertLogSql=strInsertLogSql.replace("#NO_OF_DELETES", ((Integer)context.LOG_NO_OF_DELETES).toString());
strInsertLogSql=strInsertLogSql.replace("#NO_OF_ERRORS", ((Integer)context.LOG_NO_OF_ERRORS).toString());
strInsertLogSql=strInsertLogSql.replace("#MESSAGE", "'"+context.LOG_MESSAGE+"'");
strInsertLogSql=strInsertLogSql.replace("#SOURCE_ROW_COUNT", ((Integer)context.LOG_SOURCE_ROW_COUNT).toString());
strInsertLogSql=strInsertLogSql.replace("#TARGET_ROW_COUNT", ((Integer)context.LOG_TARGET_ROW_COUNT).toString());
strInsertLogSql=strInsertLogSql.replace("#ERROR_CATEGORY", "'"+context.LOG_ERROR_CATEGORY+"'");
globalMap.put("insert_log_sql",strInsertLogSql);

//System.out.println(globalMap.get("insert_log_sql"));
//System.out.println(globalMap.get("error_message_desc"));
//System.out.println("******************************");
//System.out.println("******************************");
//globalMap.put("now",new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(TalendDate.getCurrentDate()).toString());
//System.out.println(globalMap.get("now"));
//((String)globalMap.get("tJavaRow_5_ERROR_MESSAGE")) != null
//((Integer)context.LOG_RUN_ID).toString()
//globalMap.put("now_sql","TO_TIMESTAMP('" + ((String)globalMap.get("now")) + "', 'YYYY-MM-DD HH24:MI:SS')::TIMESTAMP WITH TIME ZONE ");
//System.out.println(globalMap.get("now_sql"));
//if (context.LOG_PLANT_NAME.equals("")==true) {
//  context.LOG_PLANT_NAME="Grove City";
//};
//if (context.LOG_APPLICATION.equals("")==true) {
//  context.LOG_APPLICATION="GET-ABM";
//};
 



/**
 * [tJava_14 begin ] stop
 */
	
	/**
	 * [tJava_14 main ] start
	 */

	

	
	
	currentComponent="tJava_14";

	

 


	tos_count_tJava_14++;

/**
 * [tJava_14 main ] stop
 */
	
	/**
	 * [tJava_14 end ] start
	 */

	

	
	
	currentComponent="tJava_14";

	

 

ok_Hash.put("tJava_14", true);
end_Hash.put("tJava_14", System.currentTimeMillis());




/**
 * [tJava_14 end ] stop
 */
				}//end the resume

				
				    			if(resumeEntryMethodName == null || globalResumeTicket){
				    				resumeUtil.addLog("CHECKPOINT", "CONNECTION:SUBJOB_OK:tJava_14:OnSubjobOk", "", Thread.currentThread().getId() + "", "", "", "", "", "");
								}	    				    			
					    	
								if(execStat){    	
									runStat.updateStatOnConnection("OnSubjobOk87", 0, "ok");
								} 
							
							tGreenplumConnection_8Process(globalMap); 
						



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage());
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tJava_14 finally ] start
	 */

	

	
	
	currentComponent="tJava_14";

	

 



/**
 * [tJava_14 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tJava_14_SUBPROCESS_STATE", 1);
	}
	

public void tGreenplumConnection_8Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tGreenplumConnection_8_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tGreenplumConnection_8 begin ] start
	 */

	

	
		
		ok_Hash.put("tGreenplumConnection_8", false);
		start_Hash.put("tGreenplumConnection_8", System.currentTimeMillis());
		
	
	currentComponent="tGreenplumConnection_8";

	
		int tos_count_tGreenplumConnection_8 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tGreenplumConnection_8 - "  + ("Start to work.") );
    	class BytesLimit65535_tGreenplumConnection_8{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tGreenplumConnection_8 = new StringBuilder();
            log4jParamters_tGreenplumConnection_8.append("Parameters:");
                    log4jParamters_tGreenplumConnection_8.append("HOST" + " = " + "context.SOURCE_HOST");
                log4jParamters_tGreenplumConnection_8.append(" | ");
                    log4jParamters_tGreenplumConnection_8.append("PORT" + " = " + "context.SOURCE_PORT");
                log4jParamters_tGreenplumConnection_8.append(" | ");
                    log4jParamters_tGreenplumConnection_8.append("DBNAME" + " = " + "context.SOURCE_DATABASE");
                log4jParamters_tGreenplumConnection_8.append(" | ");
                    log4jParamters_tGreenplumConnection_8.append("SCHEMA_DB" + " = " + "\"\"");
                log4jParamters_tGreenplumConnection_8.append(" | ");
                    log4jParamters_tGreenplumConnection_8.append("USER" + " = " + "context.SOURCE_USER");
                log4jParamters_tGreenplumConnection_8.append(" | ");
                    log4jParamters_tGreenplumConnection_8.append("PASS" + " = " + String.valueOf(routines.system.PasswordEncryptUtil.encryptPassword(context.SOURCE_PASSWORD)).substring(0, 4) + "...");     
                log4jParamters_tGreenplumConnection_8.append(" | ");
                    log4jParamters_tGreenplumConnection_8.append("USE_SHARED_CONNECTION" + " = " + "false");
                log4jParamters_tGreenplumConnection_8.append(" | ");
                    log4jParamters_tGreenplumConnection_8.append("USE_SSL" + " = " + "true");
                log4jParamters_tGreenplumConnection_8.append(" | ");
                    log4jParamters_tGreenplumConnection_8.append("AUTO_COMMIT" + " = " + "true");
                log4jParamters_tGreenplumConnection_8.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tGreenplumConnection_8 - "  + (log4jParamters_tGreenplumConnection_8) );
    		}
    	}
    	
        new BytesLimit65535_tGreenplumConnection_8().limitLog4jByte();
	

	
				String url_tGreenplumConnection_8 = "jdbc:postgresql://"+context.SOURCE_HOST+":"+context.SOURCE_PORT+"/"+context.SOURCE_DATABASE+"?ssl=true&sslfactory=org.postgresql.ssl.NonValidatingFactory";

	String dbUser_tGreenplumConnection_8 = context.SOURCE_USER;
	
	
		
	final String decryptedPassword_tGreenplumConnection_8 = context.SOURCE_PASSWORD; 
		String dbPwd_tGreenplumConnection_8 = decryptedPassword_tGreenplumConnection_8;
	

	java.sql.Connection conn_tGreenplumConnection_8 = null;
	
		
			String driverClass_tGreenplumConnection_8 = "org.postgresql.Driver";
			java.lang.Class.forName(driverClass_tGreenplumConnection_8);
		
	    		log.debug("tGreenplumConnection_8 - Driver ClassName: "+driverClass_tGreenplumConnection_8+".");
			
	    		log.debug("tGreenplumConnection_8 - Connection attempt to '" + url_tGreenplumConnection_8 + "' with the username '" + dbUser_tGreenplumConnection_8 + "'.");
			
		conn_tGreenplumConnection_8 = java.sql.DriverManager.getConnection(url_tGreenplumConnection_8,dbUser_tGreenplumConnection_8,dbPwd_tGreenplumConnection_8);
	    		log.debug("tGreenplumConnection_8 - Connection to '" + url_tGreenplumConnection_8 + "' has succeeded.");
			

		globalMap.put("conn_tGreenplumConnection_8", conn_tGreenplumConnection_8);
	if (null != conn_tGreenplumConnection_8) {
		
			log.debug("tGreenplumConnection_8 - Connection is set auto commit to 'true'.");
			conn_tGreenplumConnection_8.setAutoCommit(true);
	}

	globalMap.put("schema_" + "tGreenplumConnection_8","");

	globalMap.put("conn_" + "tGreenplumConnection_8",conn_tGreenplumConnection_8);
 



/**
 * [tGreenplumConnection_8 begin ] stop
 */
	
	/**
	 * [tGreenplumConnection_8 main ] start
	 */

	

	
	
	currentComponent="tGreenplumConnection_8";

	

 


	tos_count_tGreenplumConnection_8++;

/**
 * [tGreenplumConnection_8 main ] stop
 */
	
	/**
	 * [tGreenplumConnection_8 end ] start
	 */

	

	
	
	currentComponent="tGreenplumConnection_8";

	

 
                if(log.isDebugEnabled())
            log.debug("tGreenplumConnection_8 - "  + ("Done.") );

ok_Hash.put("tGreenplumConnection_8", true);
end_Hash.put("tGreenplumConnection_8", System.currentTimeMillis());

   			if (context.LOG_RUN_ID == -1) {
   				
					if(execStat){   
   	 					runStat.updateStatOnConnection("If34", 0, "true");
					}
				
    			tGreenplumInput_2Process(globalMap);
   			}

			   
   				else{
					if(execStat){   
   	 					runStat.updateStatOnConnection("If34", 0, "false");
					}   	 
   				}
   			if (context.LOG_RUN_ID != -1) {
   				
					if(execStat){   
   	 					runStat.updateStatOnConnection("If35", 0, "true");
					}
				
    			tJava_17Process(globalMap);
   			}

			   
   				else{
					if(execStat){   
   	 					runStat.updateStatOnConnection("If35", 0, "false");
					}   	 
   				}



/**
 * [tGreenplumConnection_8 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage());
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tGreenplumConnection_8 finally ] start
	 */

	

	
	
	currentComponent="tGreenplumConnection_8";

	

 



/**
 * [tGreenplumConnection_8 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tGreenplumConnection_8_SUBPROCESS_STATE", 1);
	}
	


public static class row15Struct implements routines.system.IPersistableRow<row15Struct> {
    final static byte[] commonByteArrayLock_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Prod2Dev_with_GP_FDIST_child = new byte[0];
    static byte[] commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Prod2Dev_with_GP_FDIST_child = new byte[0];

	
			    public Integer run_id;

				public Integer getRun_id () {
					return this.run_id;
				}
				


	private Integer readInteger(ObjectInputStream dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}

	private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException{
		if(intNum == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeInt(intNum);
    	}
	}

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Prod2Dev_with_GP_FDIST_child) {

        	try {

        		int length = 0;
		
						this.run_id = readInteger(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// Integer
				
						writeInteger(this.run_id,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("run_id="+String.valueOf(run_id));
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				if(run_id == null){
        					sb.append("<null>");
        				}else{
            				sb.append(run_id);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(row15Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}
public void tGreenplumInput_2Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tGreenplumInput_2_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;



		row15Struct row15 = new row15Struct();




	
	/**
	 * [tJavaRow_5 begin ] start
	 */

	

	
		
		ok_Hash.put("tJavaRow_5", false);
		start_Hash.put("tJavaRow_5", System.currentTimeMillis());
		
	
	currentComponent="tJavaRow_5";

	
			if (execStat) {
				if(resourceMap.get("inIterateVComp") == null){
					
						runStat.updateStatOnConnection("row15" + iterateId, 0, 0);
					
				}
			} 

		
		int tos_count_tJavaRow_5 = 0;
		
    	class BytesLimit65535_tJavaRow_5{
    		public void limitLog4jByte() throws Exception{
    			
    		}
    	}
    	
        new BytesLimit65535_tJavaRow_5().limitLog4jByte();

int nb_line_tJavaRow_5 = 0;

 



/**
 * [tJavaRow_5 begin ] stop
 */



	
	/**
	 * [tGreenplumInput_2 begin ] start
	 */

	

	
		
		ok_Hash.put("tGreenplumInput_2", false);
		start_Hash.put("tGreenplumInput_2", System.currentTimeMillis());
		
	
	currentComponent="tGreenplumInput_2";

	
		int tos_count_tGreenplumInput_2 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tGreenplumInput_2 - "  + ("Start to work.") );
    	class BytesLimit65535_tGreenplumInput_2{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tGreenplumInput_2 = new StringBuilder();
            log4jParamters_tGreenplumInput_2.append("Parameters:");
                    log4jParamters_tGreenplumInput_2.append("USE_EXISTING_CONNECTION" + " = " + "true");
                log4jParamters_tGreenplumInput_2.append(" | ");
                    log4jParamters_tGreenplumInput_2.append("CONNECTION" + " = " + "tGreenplumConnection_8");
                log4jParamters_tGreenplumInput_2.append(" | ");
                    log4jParamters_tGreenplumInput_2.append("TABLE" + " = " + "\"\"");
                log4jParamters_tGreenplumInput_2.append(" | ");
                    log4jParamters_tGreenplumInput_2.append("QUERYSTORE" + " = " + "\"\"");
                log4jParamters_tGreenplumInput_2.append(" | ");
                    log4jParamters_tGreenplumInput_2.append("QUERY" + " = " + "\"select NEXTVAL('sbdt.edl_run_id_seq')\"");
                log4jParamters_tGreenplumInput_2.append(" | ");
                    log4jParamters_tGreenplumInput_2.append("USE_CURSOR" + " = " + "false");
                log4jParamters_tGreenplumInput_2.append(" | ");
                    log4jParamters_tGreenplumInput_2.append("TRIM_ALL_COLUMN" + " = " + "false");
                log4jParamters_tGreenplumInput_2.append(" | ");
                    log4jParamters_tGreenplumInput_2.append("TRIM_COLUMN" + " = " + "[{TRIM="+("false")+", SCHEMA_COLUMN="+("run_id")+"}]");
                log4jParamters_tGreenplumInput_2.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tGreenplumInput_2 - "  + (log4jParamters_tGreenplumInput_2) );
    		}
    	}
    	
        new BytesLimit65535_tGreenplumInput_2().limitLog4jByte();
	
    
	
		    int nb_line_tGreenplumInput_2 = 0;
		    java.sql.Connection conn_tGreenplumInput_2 = null;
		        conn_tGreenplumInput_2 = (java.sql.Connection)globalMap.get("conn_tGreenplumConnection_8");
				
				if(conn_tGreenplumInput_2 != null) {
					if(conn_tGreenplumInput_2.getMetaData() != null) {
						
						log.debug("tGreenplumInput_2 - Uses an existing connection with username '" + conn_tGreenplumInput_2.getMetaData().getUserName() + "'. Connection URL: " + conn_tGreenplumInput_2.getMetaData().getURL() + ".");
						
					}
				}
			
		    
			java.sql.Statement stmt_tGreenplumInput_2 = conn_tGreenplumInput_2.createStatement();

		    String dbquery_tGreenplumInput_2 = "select NEXTVAL('sbdt.edl_run_id_seq')";
			
                log.debug("tGreenplumInput_2 - Executing the query: '"+dbquery_tGreenplumInput_2+"'.");
			

                       globalMap.put("tGreenplumInput_2_QUERY",dbquery_tGreenplumInput_2);

		    java.sql.ResultSet rs_tGreenplumInput_2 = null;
		try{
		    rs_tGreenplumInput_2 = stmt_tGreenplumInput_2.executeQuery(dbquery_tGreenplumInput_2);
		    java.sql.ResultSetMetaData rsmd_tGreenplumInput_2 = rs_tGreenplumInput_2.getMetaData();
		    int colQtyInRs_tGreenplumInput_2 = rsmd_tGreenplumInput_2.getColumnCount();

		    String tmpContent_tGreenplumInput_2 = null;
		    
		    
		    	log.debug("tGreenplumInput_2 - Retrieving records from the database.");
		    
		    while (rs_tGreenplumInput_2.next()) {
		        nb_line_tGreenplumInput_2++;
		        
							if(colQtyInRs_tGreenplumInput_2 < 1) {
								row15.run_id = null;
							} else {
		                          
            if(rs_tGreenplumInput_2.getObject(1) != null) {
                row15.run_id = rs_tGreenplumInput_2.getInt(1);
            } else {
                    row15.run_id = null;
            }
		                    }
					
						log.debug("tGreenplumInput_2 - Retrieving the record " + nb_line_tGreenplumInput_2 + ".");
					


 



/**
 * [tGreenplumInput_2 begin ] stop
 */
	
	/**
	 * [tGreenplumInput_2 main ] start
	 */

	

	
	
	currentComponent="tGreenplumInput_2";

	

 


	tos_count_tGreenplumInput_2++;

/**
 * [tGreenplumInput_2 main ] stop
 */

	
	/**
	 * [tJavaRow_5 main ] start
	 */

	

	
	
	currentComponent="tJavaRow_5";

	

			//row15
			//row15


			
				if(execStat){
					runStat.updateStatOnConnection("row15"+iterateId,1, 1);
				} 
			

		
    			if(log.isTraceEnabled()){
    				log.trace("row15 - " + (row15==null? "": row15.toLogString()));
    			}
    		

    context.LOG_RUN_ID=row15.run_id;
    nb_line_tJavaRow_5++;   

 


	tos_count_tJavaRow_5++;

/**
 * [tJavaRow_5 main ] stop
 */



	
	/**
	 * [tGreenplumInput_2 end ] start
	 */

	

	
	
	currentComponent="tGreenplumInput_2";

	

	}
}finally{
	stmt_tGreenplumInput_2.close();

}
globalMap.put("tGreenplumInput_2_NB_LINE",nb_line_tGreenplumInput_2);
	    		log.debug("tGreenplumInput_2 - Retrieved records count: "+nb_line_tGreenplumInput_2 + " .");
			

 
                if(log.isDebugEnabled())
            log.debug("tGreenplumInput_2 - "  + ("Done.") );

ok_Hash.put("tGreenplumInput_2", true);
end_Hash.put("tGreenplumInput_2", System.currentTimeMillis());




/**
 * [tGreenplumInput_2 end ] stop
 */

	
	/**
	 * [tJavaRow_5 end ] start
	 */

	

	
	
	currentComponent="tJavaRow_5";

	

globalMap.put("tJavaRow_5_NB_LINE",nb_line_tJavaRow_5);
			if(execStat){
				if(resourceMap.get("inIterateVComp") == null || !((Boolean)resourceMap.get("inIterateVComp"))){
			 		runStat.updateStatOnConnection("row15"+iterateId,2, 0); 
			 	}
			}
		
 

ok_Hash.put("tJavaRow_5", true);
end_Hash.put("tJavaRow_5", System.currentTimeMillis());

   			if (true
) {
   				
					if(execStat){   
   	 					runStat.updateStatOnConnection("If36", 0, "true");
					}
				
    			tJava_17Process(globalMap);
   			}

			   
   				else{
					if(execStat){   
   	 					runStat.updateStatOnConnection("If36", 0, "false");
					}   	 
   				}



/**
 * [tJavaRow_5 end ] stop
 */



				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage());
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tGreenplumInput_2 finally ] start
	 */

	

	
	
	currentComponent="tGreenplumInput_2";

	

 



/**
 * [tGreenplumInput_2 finally ] stop
 */

	
	/**
	 * [tJavaRow_5 finally ] start
	 */

	

	
	
	currentComponent="tJavaRow_5";

	

 



/**
 * [tJavaRow_5 finally ] stop
 */



				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tGreenplumInput_2_SUBPROCESS_STATE", 1);
	}
	

public void tJava_17Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tJava_17_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tJava_17 begin ] start
	 */

	

	
		
		ok_Hash.put("tJava_17", false);
		start_Hash.put("tJava_17", System.currentTimeMillis());
		
	
	currentComponent="tJava_17";

	
		int tos_count_tJava_17 = 0;
		
    	class BytesLimit65535_tJava_17{
    		public void limitLog4jByte() throws Exception{
    			
    		}
    	}
    	
        new BytesLimit65535_tJava_17().limitLog4jByte();


String strInsertLogSql = (String)globalMap.get("insert_log_sql");
strInsertLogSql=strInsertLogSql.replace("#RUN_ID", ((Integer)context.LOG_RUN_ID).toString());
globalMap.put("insert_log_sql",strInsertLogSql);

 



/**
 * [tJava_17 begin ] stop
 */
	
	/**
	 * [tJava_17 main ] start
	 */

	

	
	
	currentComponent="tJava_17";

	

 


	tos_count_tJava_17++;

/**
 * [tJava_17 main ] stop
 */
	
	/**
	 * [tJava_17 end ] start
	 */

	

	
	
	currentComponent="tJava_17";

	

 

ok_Hash.put("tJava_17", true);
end_Hash.put("tJava_17", System.currentTimeMillis());




/**
 * [tJava_17 end ] stop
 */
				}//end the resume

				
				    			if(resumeEntryMethodName == null || globalResumeTicket){
				    				resumeUtil.addLog("CHECKPOINT", "CONNECTION:SUBJOB_OK:tJava_17:OnSubjobOk", "", Thread.currentThread().getId() + "", "", "", "", "", "");
								}	    				    			
					    	
								if(execStat){    	
									runStat.updateStatOnConnection("OnSubjobOk88", 0, "ok");
								} 
							
							tGreenplumRow_13Process(globalMap); 
						



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage());
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tJava_17 finally ] start
	 */

	

	
	
	currentComponent="tJava_17";

	

 



/**
 * [tJava_17 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tJava_17_SUBPROCESS_STATE", 1);
	}
	

public void tGreenplumRow_13Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tGreenplumRow_13_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tGreenplumRow_13 begin ] start
	 */

	

	
		
		ok_Hash.put("tGreenplumRow_13", false);
		start_Hash.put("tGreenplumRow_13", System.currentTimeMillis());
		
	
	currentComponent="tGreenplumRow_13";

	
		int tos_count_tGreenplumRow_13 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tGreenplumRow_13 - "  + ("Start to work.") );
    	class BytesLimit65535_tGreenplumRow_13{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tGreenplumRow_13 = new StringBuilder();
            log4jParamters_tGreenplumRow_13.append("Parameters:");
                    log4jParamters_tGreenplumRow_13.append("USE_EXISTING_CONNECTION" + " = " + "true");
                log4jParamters_tGreenplumRow_13.append(" | ");
                    log4jParamters_tGreenplumRow_13.append("CONNECTION" + " = " + "tGreenplumConnection_8");
                log4jParamters_tGreenplumRow_13.append(" | ");
                    log4jParamters_tGreenplumRow_13.append("QUERYSTORE" + " = " + "\"\"");
                log4jParamters_tGreenplumRow_13.append(" | ");
                    log4jParamters_tGreenplumRow_13.append("QUERY" + " = " + "(String)globalMap.get(\"insert_log_sql\")");
                log4jParamters_tGreenplumRow_13.append(" | ");
                    log4jParamters_tGreenplumRow_13.append("DIE_ON_ERROR" + " = " + "true");
                log4jParamters_tGreenplumRow_13.append(" | ");
                    log4jParamters_tGreenplumRow_13.append("PROPAGATE_RECORD_SET" + " = " + "false");
                log4jParamters_tGreenplumRow_13.append(" | ");
                    log4jParamters_tGreenplumRow_13.append("USE_PREPAREDSTATEMENT" + " = " + "false");
                log4jParamters_tGreenplumRow_13.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tGreenplumRow_13 - "  + (log4jParamters_tGreenplumRow_13) );
    		}
    	}
    	
        new BytesLimit65535_tGreenplumRow_13().limitLog4jByte();

	java.sql.Connection conn_tGreenplumRow_13 = null;
	String query_tGreenplumRow_13 = "";
	boolean whetherReject_tGreenplumRow_13 = false;
				conn_tGreenplumRow_13 = (java.sql.Connection)globalMap.get("conn_tGreenplumConnection_8");
			
				if(conn_tGreenplumRow_13 != null) {
					if(conn_tGreenplumRow_13.getMetaData() != null) {
						
						log.debug("tGreenplumRow_13 - Uses an existing connection with username '" + conn_tGreenplumRow_13.getMetaData().getUserName() + "'. Connection URL: " + conn_tGreenplumRow_13.getMetaData().getURL() + ".");
						
					}
				}
			
		java.sql.Statement stmt_tGreenplumRow_13 = conn_tGreenplumRow_13.createStatement();
	

 



/**
 * [tGreenplumRow_13 begin ] stop
 */
	
	/**
	 * [tGreenplumRow_13 main ] start
	 */

	

	
	
	currentComponent="tGreenplumRow_13";

	

	    		log.debug("tGreenplumRow_13 - Executing the query: '" + (String)globalMap.get("insert_log_sql") + "'.");
			
query_tGreenplumRow_13 = (String)globalMap.get("insert_log_sql");
whetherReject_tGreenplumRow_13 = false;
globalMap.put("tGreenplumRow_13_QUERY",query_tGreenplumRow_13);
try {
		stmt_tGreenplumRow_13.execute(query_tGreenplumRow_13);
		
	    		log.info("tGreenplumRow_13 - Execute the query: '" + (String)globalMap.get("insert_log_sql") + "' has finished.");
			
	} catch (java.lang.Exception e) {
		whetherReject_tGreenplumRow_13 = true;
		
			throw(e);
			
	}
	
	if(!whetherReject_tGreenplumRow_13) {
		
	}
	

 


	tos_count_tGreenplumRow_13++;

/**
 * [tGreenplumRow_13 main ] stop
 */
	
	/**
	 * [tGreenplumRow_13 end ] start
	 */

	

	
	
	currentComponent="tGreenplumRow_13";

	

	
	stmt_tGreenplumRow_13.close();	

 
                if(log.isDebugEnabled())
            log.debug("tGreenplumRow_13 - "  + ("Done.") );

ok_Hash.put("tGreenplumRow_13", true);
end_Hash.put("tGreenplumRow_13", System.currentTimeMillis());




/**
 * [tGreenplumRow_13 end ] stop
 */
				}//end the resume

				
				    			if(resumeEntryMethodName == null || globalResumeTicket){
				    				resumeUtil.addLog("CHECKPOINT", "CONNECTION:SUBJOB_OK:tGreenplumRow_13:OnSubjobOk", "", Thread.currentThread().getId() + "", "", "", "", "", "");
								}	    				    			
					    	
								if(execStat){    	
									runStat.updateStatOnConnection("OnSubjobOk89", 0, "ok");
								} 
							
							tGreenplumClose_10Process(globalMap); 
						



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage());
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tGreenplumRow_13 finally ] start
	 */

	

	
	
	currentComponent="tGreenplumRow_13";

	

 



/**
 * [tGreenplumRow_13 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tGreenplumRow_13_SUBPROCESS_STATE", 1);
	}
	

public void tGreenplumClose_10Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tGreenplumClose_10_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tGreenplumClose_10 begin ] start
	 */

	

	
		
		ok_Hash.put("tGreenplumClose_10", false);
		start_Hash.put("tGreenplumClose_10", System.currentTimeMillis());
		
	
	currentComponent="tGreenplumClose_10";

	
		int tos_count_tGreenplumClose_10 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tGreenplumClose_10 - "  + ("Start to work.") );
    	class BytesLimit65535_tGreenplumClose_10{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tGreenplumClose_10 = new StringBuilder();
            log4jParamters_tGreenplumClose_10.append("Parameters:");
                    log4jParamters_tGreenplumClose_10.append("CONNECTION" + " = " + "tGreenplumConnection_8");
                log4jParamters_tGreenplumClose_10.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tGreenplumClose_10 - "  + (log4jParamters_tGreenplumClose_10) );
    		}
    	}
    	
        new BytesLimit65535_tGreenplumClose_10().limitLog4jByte();

 



/**
 * [tGreenplumClose_10 begin ] stop
 */
	
	/**
	 * [tGreenplumClose_10 main ] start
	 */

	

	
	
	currentComponent="tGreenplumClose_10";

	



	java.sql.Connection conn_tGreenplumClose_10 = (java.sql.Connection)globalMap.get("conn_tGreenplumConnection_8");
	if(conn_tGreenplumClose_10 != null && !conn_tGreenplumClose_10.isClosed())
	{
                if(log.isDebugEnabled())
            log.debug("tGreenplumClose_10 - "  + ("Closing the connection ")  + ("conn_tGreenplumConnection_8")  + (" to the database.") );
        conn_tGreenplumClose_10.close();
                if(log.isDebugEnabled())
            log.debug("tGreenplumClose_10 - "  + ("Connection ")  + ("conn_tGreenplumConnection_8")  + (" to the database has closed.") );
	}

 


	tos_count_tGreenplumClose_10++;

/**
 * [tGreenplumClose_10 main ] stop
 */
	
	/**
	 * [tGreenplumClose_10 end ] start
	 */

	

	
	
	currentComponent="tGreenplumClose_10";

	

 
                if(log.isDebugEnabled())
            log.debug("tGreenplumClose_10 - "  + ("Done.") );

ok_Hash.put("tGreenplumClose_10", true);
end_Hash.put("tGreenplumClose_10", System.currentTimeMillis());




/**
 * [tGreenplumClose_10 end ] stop
 */
				}//end the resume

				
				    			if(resumeEntryMethodName == null || globalResumeTicket){
				    				resumeUtil.addLog("CHECKPOINT", "CONNECTION:SUBJOB_OK:tGreenplumClose_10:OnSubjobOk1", "", Thread.currentThread().getId() + "", "", "", "", "", "");
								}	    				    			
					    	
								if(execStat){    	
									runStat.updateStatOnConnection("OnSubjobOk1", 0, "ok");
								} 
							
							tPostgresqlClose_2Process(globalMap); 
						
				    			if(resumeEntryMethodName == null || globalResumeTicket){
				    				resumeUtil.addLog("CHECKPOINT", "CONNECTION:SUBJOB_OK:tGreenplumClose_10:OnSubjobOk2", "", Thread.currentThread().getId() + "", "", "", "", "", "");
								}	    				    			
					    	
								if(execStat){    	
									runStat.updateStatOnConnection("OnSubjobOk33", 0, "ok");
								} 
							
							tGreenplumClose_4Process(globalMap); 
						
				    			if(resumeEntryMethodName == null || globalResumeTicket){
				    				resumeUtil.addLog("CHECKPOINT", "CONNECTION:SUBJOB_OK:tGreenplumClose_10:OnSubjobOk3", "", Thread.currentThread().getId() + "", "", "", "", "", "");
								}	    				    			
					    	
								if(execStat){    	
									runStat.updateStatOnConnection("OnSubjobOk34", 0, "ok");
								} 
							
							tPostgresqlClose_3Process(globalMap); 
						
				    			if(resumeEntryMethodName == null || globalResumeTicket){
				    				resumeUtil.addLog("CHECKPOINT", "CONNECTION:SUBJOB_OK:tGreenplumClose_10:OnSubjobOk4", "", Thread.currentThread().getId() + "", "", "", "", "", "");
								}	    				    			
					    	
								if(execStat){    	
									runStat.updateStatOnConnection("OnSubjobOk36", 0, "ok");
								} 
							
							tGreenplumClose_2Process(globalMap); 
						



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage());
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tGreenplumClose_10 finally ] start
	 */

	

	
	
	currentComponent="tGreenplumClose_10";

	

 



/**
 * [tGreenplumClose_10 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tGreenplumClose_10_SUBPROCESS_STATE", 1);
	}
	

public void tGreenplumClose_2Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tGreenplumClose_2_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;





	
	/**
	 * [tGreenplumClose_2 begin ] start
	 */

	

	
		
		ok_Hash.put("tGreenplumClose_2", false);
		start_Hash.put("tGreenplumClose_2", System.currentTimeMillis());
		
	
	currentComponent="tGreenplumClose_2";

	
		int tos_count_tGreenplumClose_2 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tGreenplumClose_2 - "  + ("Start to work.") );
    	class BytesLimit65535_tGreenplumClose_2{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tGreenplumClose_2 = new StringBuilder();
            log4jParamters_tGreenplumClose_2.append("Parameters:");
                    log4jParamters_tGreenplumClose_2.append("CONNECTION" + " = " + "tGreenplumConnection_1");
                log4jParamters_tGreenplumClose_2.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tGreenplumClose_2 - "  + (log4jParamters_tGreenplumClose_2) );
    		}
    	}
    	
        new BytesLimit65535_tGreenplumClose_2().limitLog4jByte();

 



/**
 * [tGreenplumClose_2 begin ] stop
 */
	
	/**
	 * [tGreenplumClose_2 main ] start
	 */

	

	
	
	currentComponent="tGreenplumClose_2";

	



	java.sql.Connection conn_tGreenplumClose_2 = (java.sql.Connection)globalMap.get("conn_tGreenplumConnection_1");
	if(conn_tGreenplumClose_2 != null && !conn_tGreenplumClose_2.isClosed())
	{
                if(log.isDebugEnabled())
            log.debug("tGreenplumClose_2 - "  + ("Closing the connection ")  + ("conn_tGreenplumConnection_1")  + (" to the database.") );
        conn_tGreenplumClose_2.close();
                if(log.isDebugEnabled())
            log.debug("tGreenplumClose_2 - "  + ("Connection ")  + ("conn_tGreenplumConnection_1")  + (" to the database has closed.") );
	}

 


	tos_count_tGreenplumClose_2++;

/**
 * [tGreenplumClose_2 main ] stop
 */
	
	/**
	 * [tGreenplumClose_2 end ] start
	 */

	

	
	
	currentComponent="tGreenplumClose_2";

	

 
                if(log.isDebugEnabled())
            log.debug("tGreenplumClose_2 - "  + ("Done.") );

ok_Hash.put("tGreenplumClose_2", true);
end_Hash.put("tGreenplumClose_2", System.currentTimeMillis());




/**
 * [tGreenplumClose_2 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage());
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tGreenplumClose_2 finally ] start
	 */

	

	
	
	currentComponent="tGreenplumClose_2";

	

 



/**
 * [tGreenplumClose_2 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tGreenplumClose_2_SUBPROCESS_STATE", 1);
	}
	

public void tJava_31Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tJava_31_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;





	
	/**
	 * [tJava_31 begin ] start
	 */

	

	
		
		ok_Hash.put("tJava_31", false);
		start_Hash.put("tJava_31", System.currentTimeMillis());
		
	
	currentComponent="tJava_31";

	
		int tos_count_tJava_31 = 0;
		
    	class BytesLimit65535_tJava_31{
    		public void limitLog4jByte() throws Exception{
    			
    		}
    	}
    	
        new BytesLimit65535_tJava_31().limitLog4jByte();


String foo = "bar";
 



/**
 * [tJava_31 begin ] stop
 */
	
	/**
	 * [tJava_31 main ] start
	 */

	

	
	
	currentComponent="tJava_31";

	

 


	tos_count_tJava_31++;

/**
 * [tJava_31 main ] stop
 */
	
	/**
	 * [tJava_31 end ] start
	 */

	

	
	
	currentComponent="tJava_31";

	

 

ok_Hash.put("tJava_31", true);
end_Hash.put("tJava_31", System.currentTimeMillis());




/**
 * [tJava_31 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage());
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tJava_31 finally ] start
	 */

	

	
	
	currentComponent="tJava_31";

	

 



/**
 * [tJava_31 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tJava_31_SUBPROCESS_STATE", 1);
	}
	


public static class row_talendLogs_LOGSStruct implements routines.system.IPersistableRow<row_talendLogs_LOGSStruct> {
    final static byte[] commonByteArrayLock_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Prod2Dev_with_GP_FDIST_child = new byte[0];
    static byte[] commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Prod2Dev_with_GP_FDIST_child = new byte[0];

	
			    public java.util.Date moment;

				public java.util.Date getMoment () {
					return this.moment;
				}
				
			    public String pid;

				public String getPid () {
					return this.pid;
				}
				
			    public String root_pid;

				public String getRoot_pid () {
					return this.root_pid;
				}
				
			    public String father_pid;

				public String getFather_pid () {
					return this.father_pid;
				}
				
			    public String project;

				public String getProject () {
					return this.project;
				}
				
			    public String job;

				public String getJob () {
					return this.job;
				}
				
			    public String context;

				public String getContext () {
					return this.context;
				}
				
			    public Integer priority;

				public Integer getPriority () {
					return this.priority;
				}
				
			    public String type;

				public String getType () {
					return this.type;
				}
				
			    public String origin;

				public String getOrigin () {
					return this.origin;
				}
				
			    public String message;

				public String getMessage () {
					return this.message;
				}
				
			    public Integer code;

				public Integer getCode () {
					return this.code;
				}
				



	private java.util.Date readDate(ObjectInputStream dis) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(dis.readLong());
		}
		return dateReturn;
	}

    private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException{
		if(date1 == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeLong(date1.getTime());
    	}
    }

	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Prod2Dev_with_GP_FDIST_child.length) {
				if(length < 1024 && commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Prod2Dev_with_GP_FDIST_child.length == 0) {
   					commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Prod2Dev_with_GP_FDIST_child = new byte[1024];
				} else {
   					commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Prod2Dev_with_GP_FDIST_child = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Prod2Dev_with_GP_FDIST_child, 0, length);
			strReturn = new String(commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Prod2Dev_with_GP_FDIST_child, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
	private Integer readInteger(ObjectInputStream dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}

	private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException{
		if(intNum == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeInt(intNum);
    	}
	}

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Prod2Dev_with_GP_FDIST_child) {

        	try {

        		int length = 0;
		
					this.moment = readDate(dis);
					
					this.pid = readString(dis);
					
					this.root_pid = readString(dis);
					
					this.father_pid = readString(dis);
					
					this.project = readString(dis);
					
					this.job = readString(dis);
					
					this.context = readString(dis);
					
						this.priority = readInteger(dis);
					
					this.type = readString(dis);
					
					this.origin = readString(dis);
					
					this.message = readString(dis);
					
						this.code = readInteger(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// java.util.Date
				
						writeDate(this.moment,dos);
					
					// String
				
						writeString(this.pid,dos);
					
					// String
				
						writeString(this.root_pid,dos);
					
					// String
				
						writeString(this.father_pid,dos);
					
					// String
				
						writeString(this.project,dos);
					
					// String
				
						writeString(this.job,dos);
					
					// String
				
						writeString(this.context,dos);
					
					// Integer
				
						writeInteger(this.priority,dos);
					
					// String
				
						writeString(this.type,dos);
					
					// String
				
						writeString(this.origin,dos);
					
					// String
				
						writeString(this.message,dos);
					
					// Integer
				
						writeInteger(this.code,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("moment="+String.valueOf(moment));
		sb.append(",pid="+pid);
		sb.append(",root_pid="+root_pid);
		sb.append(",father_pid="+father_pid);
		sb.append(",project="+project);
		sb.append(",job="+job);
		sb.append(",context="+context);
		sb.append(",priority="+String.valueOf(priority));
		sb.append(",type="+type);
		sb.append(",origin="+origin);
		sb.append(",message="+message);
		sb.append(",code="+String.valueOf(code));
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				if(moment == null){
        					sb.append("<null>");
        				}else{
            				sb.append(moment);
            			}
            		
        			sb.append("|");
        		
        				if(pid == null){
        					sb.append("<null>");
        				}else{
            				sb.append(pid);
            			}
            		
        			sb.append("|");
        		
        				if(root_pid == null){
        					sb.append("<null>");
        				}else{
            				sb.append(root_pid);
            			}
            		
        			sb.append("|");
        		
        				if(father_pid == null){
        					sb.append("<null>");
        				}else{
            				sb.append(father_pid);
            			}
            		
        			sb.append("|");
        		
        				if(project == null){
        					sb.append("<null>");
        				}else{
            				sb.append(project);
            			}
            		
        			sb.append("|");
        		
        				if(job == null){
        					sb.append("<null>");
        				}else{
            				sb.append(job);
            			}
            		
        			sb.append("|");
        		
        				if(context == null){
        					sb.append("<null>");
        				}else{
            				sb.append(context);
            			}
            		
        			sb.append("|");
        		
        				if(priority == null){
        					sb.append("<null>");
        				}else{
            				sb.append(priority);
            			}
            		
        			sb.append("|");
        		
        				if(type == null){
        					sb.append("<null>");
        				}else{
            				sb.append(type);
            			}
            		
        			sb.append("|");
        		
        				if(origin == null){
        					sb.append("<null>");
        				}else{
            				sb.append(origin);
            			}
            		
        			sb.append("|");
        		
        				if(message == null){
        					sb.append("<null>");
        				}else{
            				sb.append(message);
            			}
            		
        			sb.append("|");
        		
        				if(code == null){
        					sb.append("<null>");
        				}else{
            				sb.append(code);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(row_talendLogs_LOGSStruct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}
public void talendLogs_LOGSProcess(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("talendLogs_LOGS_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
		String currentVirtualComponent = null;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;



		row_talendLogs_LOGSStruct row_talendLogs_LOGS = new row_talendLogs_LOGSStruct();




	
	/**
	 * [talendLogs_CONSOLE begin ] start
	 */

	

	
		
		ok_Hash.put("talendLogs_CONSOLE", false);
		start_Hash.put("talendLogs_CONSOLE", System.currentTimeMillis());
		
	
		currentVirtualComponent = "talendLogs_CONSOLE";
	
	currentComponent="talendLogs_CONSOLE";

	
			if (execStat) {
				if(resourceMap.get("inIterateVComp") == null){
					
						runStat.updateStatOnConnection("Main" + iterateId, 0, 0);
					
				}
			} 

		
		int tos_count_talendLogs_CONSOLE = 0;
		
                if(log.isDebugEnabled())
            log.debug("talendLogs_CONSOLE - "  + ("Start to work.") );
    	class BytesLimit65535_talendLogs_CONSOLE{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_talendLogs_CONSOLE = new StringBuilder();
            log4jParamters_talendLogs_CONSOLE.append("Parameters:");
                    log4jParamters_talendLogs_CONSOLE.append("BASIC_MODE" + " = " + "true");
                log4jParamters_talendLogs_CONSOLE.append(" | ");
                    log4jParamters_talendLogs_CONSOLE.append("TABLE_PRINT" + " = " + "false");
                log4jParamters_talendLogs_CONSOLE.append(" | ");
                    log4jParamters_talendLogs_CONSOLE.append("VERTICAL" + " = " + "false");
                log4jParamters_talendLogs_CONSOLE.append(" | ");
                    log4jParamters_talendLogs_CONSOLE.append("FIELDSEPARATOR" + " = " + "\"|\"");
                log4jParamters_talendLogs_CONSOLE.append(" | ");
                    log4jParamters_talendLogs_CONSOLE.append("PRINT_HEADER" + " = " + "false");
                log4jParamters_talendLogs_CONSOLE.append(" | ");
                    log4jParamters_talendLogs_CONSOLE.append("PRINT_UNIQUE_NAME" + " = " + "false");
                log4jParamters_talendLogs_CONSOLE.append(" | ");
                    log4jParamters_talendLogs_CONSOLE.append("PRINT_COLNAMES" + " = " + "false");
                log4jParamters_talendLogs_CONSOLE.append(" | ");
                    log4jParamters_talendLogs_CONSOLE.append("USE_FIXED_LENGTH" + " = " + "false");
                log4jParamters_talendLogs_CONSOLE.append(" | ");
                    log4jParamters_talendLogs_CONSOLE.append("PRINT_CONTENT_WITH_LOG4J" + " = " + "true");
                log4jParamters_talendLogs_CONSOLE.append(" | ");
                if(log.isDebugEnabled())
            log.debug("talendLogs_CONSOLE - "  + (log4jParamters_talendLogs_CONSOLE) );
    		}
    	}
    	
        new BytesLimit65535_talendLogs_CONSOLE().limitLog4jByte();

	///////////////////////
	
		final String OUTPUT_FIELD_SEPARATOR_talendLogs_CONSOLE = "|";
		java.io.PrintStream consoleOut_talendLogs_CONSOLE = null;	

 		StringBuilder strBuffer_talendLogs_CONSOLE = null;
		int nb_line_talendLogs_CONSOLE = 0;
///////////////////////    			



 



/**
 * [talendLogs_CONSOLE begin ] stop
 */



	
	/**
	 * [talendLogs_LOGS begin ] start
	 */

	

	
		
		ok_Hash.put("talendLogs_LOGS", false);
		start_Hash.put("talendLogs_LOGS", System.currentTimeMillis());
		
	
		currentVirtualComponent = "talendLogs_LOGS";
	
	currentComponent="talendLogs_LOGS";

	
		int tos_count_talendLogs_LOGS = 0;
		
                if(log.isDebugEnabled())
            log.debug("talendLogs_LOGS - "  + ("Start to work.") );
    	class BytesLimit65535_talendLogs_LOGS{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_talendLogs_LOGS = new StringBuilder();
            log4jParamters_talendLogs_LOGS.append("Parameters:");
                    log4jParamters_talendLogs_LOGS.append("CATCH_JAVA_EXCEPTION" + " = " + "true");
                log4jParamters_talendLogs_LOGS.append(" | ");
                    log4jParamters_talendLogs_LOGS.append("CATCH_TDIE" + " = " + "true");
                log4jParamters_talendLogs_LOGS.append(" | ");
                    log4jParamters_talendLogs_LOGS.append("CATCH_TWARN" + " = " + "true");
                log4jParamters_talendLogs_LOGS.append(" | ");
                    log4jParamters_talendLogs_LOGS.append("CATCH_TACTIONFAILURE" + " = " + "true");
                log4jParamters_talendLogs_LOGS.append(" | ");
                if(log.isDebugEnabled())
            log.debug("talendLogs_LOGS - "  + (log4jParamters_talendLogs_LOGS) );
    		}
    	}
    	
        new BytesLimit65535_talendLogs_LOGS().limitLog4jByte();

	for (LogCatcherUtils.LogCatcherMessage lcm : talendLogs_LOGS.getMessages()) {
		row_talendLogs_LOGS.type = lcm.getType();
		row_talendLogs_LOGS.origin = (lcm.getOrigin()==null || lcm.getOrigin().length()<1 ? null : lcm.getOrigin());
		row_talendLogs_LOGS.priority = lcm.getPriority();
		row_talendLogs_LOGS.message = lcm.getMessage();
		row_talendLogs_LOGS.code = lcm.getCode();
		
		row_talendLogs_LOGS.moment = java.util.Calendar.getInstance().getTime();
	
    	row_talendLogs_LOGS.pid = pid;
		row_talendLogs_LOGS.root_pid = rootPid;
		row_talendLogs_LOGS.father_pid = fatherPid;
	
    	row_talendLogs_LOGS.project = projectName;
    	row_talendLogs_LOGS.job = jobName;
    	row_talendLogs_LOGS.context = contextStr;
    		
 



/**
 * [talendLogs_LOGS begin ] stop
 */
	
	/**
	 * [talendLogs_LOGS main ] start
	 */

	

	
	
		currentVirtualComponent = "talendLogs_LOGS";
	
	currentComponent="talendLogs_LOGS";

	

 


	tos_count_talendLogs_LOGS++;

/**
 * [talendLogs_LOGS main ] stop
 */

	
	/**
	 * [talendLogs_CONSOLE main ] start
	 */

	

	
	
		currentVirtualComponent = "talendLogs_CONSOLE";
	
	currentComponent="talendLogs_CONSOLE";

	

			//Main
			//row_talendLogs_LOGS


			
				if(execStat){
					runStat.updateStatOnConnection("Main"+iterateId,1, 1);
				} 
			

		
///////////////////////		
						



				strBuffer_talendLogs_CONSOLE = new StringBuilder();




   				
	    		if(row_talendLogs_LOGS.moment != null) { //              
                    							
       
				strBuffer_talendLogs_CONSOLE.append(
								FormatterUtils.format_Date(row_talendLogs_LOGS.moment, "yyyy-MM-dd HH:mm:ss")				
				);


							
	    		} //  			

    			strBuffer_talendLogs_CONSOLE.append("|");
    			


   				
	    		if(row_talendLogs_LOGS.pid != null) { //              
                    							
       
				strBuffer_talendLogs_CONSOLE.append(
				                String.valueOf(row_talendLogs_LOGS.pid)							
				);


							
	    		} //  			

    			strBuffer_talendLogs_CONSOLE.append("|");
    			


   				
	    		if(row_talendLogs_LOGS.root_pid != null) { //              
                    							
       
				strBuffer_talendLogs_CONSOLE.append(
				                String.valueOf(row_talendLogs_LOGS.root_pid)							
				);


							
	    		} //  			

    			strBuffer_talendLogs_CONSOLE.append("|");
    			


   				
	    		if(row_talendLogs_LOGS.father_pid != null) { //              
                    							
       
				strBuffer_talendLogs_CONSOLE.append(
				                String.valueOf(row_talendLogs_LOGS.father_pid)							
				);


							
	    		} //  			

    			strBuffer_talendLogs_CONSOLE.append("|");
    			


   				
	    		if(row_talendLogs_LOGS.project != null) { //              
                    							
       
				strBuffer_talendLogs_CONSOLE.append(
				                String.valueOf(row_talendLogs_LOGS.project)							
				);


							
	    		} //  			

    			strBuffer_talendLogs_CONSOLE.append("|");
    			


   				
	    		if(row_talendLogs_LOGS.job != null) { //              
                    							
       
				strBuffer_talendLogs_CONSOLE.append(
				                String.valueOf(row_talendLogs_LOGS.job)							
				);


							
	    		} //  			

    			strBuffer_talendLogs_CONSOLE.append("|");
    			


   				
	    		if(row_talendLogs_LOGS.context != null) { //              
                    							
       
				strBuffer_talendLogs_CONSOLE.append(
				                String.valueOf(row_talendLogs_LOGS.context)							
				);


							
	    		} //  			

    			strBuffer_talendLogs_CONSOLE.append("|");
    			


   				
	    		if(row_talendLogs_LOGS.priority != null) { //              
                    							
       
				strBuffer_talendLogs_CONSOLE.append(
				                String.valueOf(row_talendLogs_LOGS.priority)							
				);


							
	    		} //  			

    			strBuffer_talendLogs_CONSOLE.append("|");
    			


   				
	    		if(row_talendLogs_LOGS.type != null) { //              
                    							
       
				strBuffer_talendLogs_CONSOLE.append(
				                String.valueOf(row_talendLogs_LOGS.type)							
				);


							
	    		} //  			

    			strBuffer_talendLogs_CONSOLE.append("|");
    			


   				
	    		if(row_talendLogs_LOGS.origin != null) { //              
                    							
       
				strBuffer_talendLogs_CONSOLE.append(
				                String.valueOf(row_talendLogs_LOGS.origin)							
				);


							
	    		} //  			

    			strBuffer_talendLogs_CONSOLE.append("|");
    			


   				
	    		if(row_talendLogs_LOGS.message != null) { //              
                    							
       
				strBuffer_talendLogs_CONSOLE.append(
				                String.valueOf(row_talendLogs_LOGS.message)							
				);


							
	    		} //  			

    			strBuffer_talendLogs_CONSOLE.append("|");
    			


   				
	    		if(row_talendLogs_LOGS.code != null) { //              
                    							
       
				strBuffer_talendLogs_CONSOLE.append(
				                String.valueOf(row_talendLogs_LOGS.code)							
				);


							
	    		} //  			
 

                    if (globalMap.get("tLogRow_CONSOLE")!=null)
                    {
                    	consoleOut_talendLogs_CONSOLE = (java.io.PrintStream) globalMap.get("tLogRow_CONSOLE");
                    }
                    else
                    {
                    	consoleOut_talendLogs_CONSOLE = new java.io.PrintStream(new java.io.BufferedOutputStream(System.out));
                    	globalMap.put("tLogRow_CONSOLE",consoleOut_talendLogs_CONSOLE);
                    }
                    	log.info("talendLogs_CONSOLE - Content of row "+(nb_line_talendLogs_CONSOLE+1)+": " + strBuffer_talendLogs_CONSOLE.toString());
                    consoleOut_talendLogs_CONSOLE.println(strBuffer_talendLogs_CONSOLE.toString());
                    consoleOut_talendLogs_CONSOLE.flush();
                    nb_line_talendLogs_CONSOLE++;
//////

//////                    
                    
///////////////////////    			

 


	tos_count_talendLogs_CONSOLE++;

/**
 * [talendLogs_CONSOLE main ] stop
 */



	
	/**
	 * [talendLogs_LOGS end ] start
	 */

	

	
	
		currentVirtualComponent = "talendLogs_LOGS";
	
	currentComponent="talendLogs_LOGS";

	
	}
 
                if(log.isDebugEnabled())
            log.debug("talendLogs_LOGS - "  + ("Done.") );

ok_Hash.put("talendLogs_LOGS", true);
end_Hash.put("talendLogs_LOGS", System.currentTimeMillis());




/**
 * [talendLogs_LOGS end ] stop
 */

	
	/**
	 * [talendLogs_CONSOLE end ] start
	 */

	

	
	
		currentVirtualComponent = "talendLogs_CONSOLE";
	
	currentComponent="talendLogs_CONSOLE";

	


//////
//////
globalMap.put("talendLogs_CONSOLE_NB_LINE",nb_line_talendLogs_CONSOLE);
                if(log.isInfoEnabled())
            log.info("talendLogs_CONSOLE - "  + ("Printed row count: ")  + (nb_line_talendLogs_CONSOLE)  + (".") );

///////////////////////    			

			if(execStat){
				if(resourceMap.get("inIterateVComp") == null || !((Boolean)resourceMap.get("inIterateVComp"))){
			 		runStat.updateStatOnConnection("Main"+iterateId,2, 0); 
			 	}
			}
		
 
                if(log.isDebugEnabled())
            log.debug("talendLogs_CONSOLE - "  + ("Done.") );

ok_Hash.put("talendLogs_CONSOLE", true);
end_Hash.put("talendLogs_CONSOLE", System.currentTimeMillis());




/**
 * [talendLogs_CONSOLE end ] stop
 */



				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage());
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
					te.setVirtualComponentName(currentVirtualComponent);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [talendLogs_LOGS finally ] start
	 */

	

	
	
		currentVirtualComponent = "talendLogs_LOGS";
	
	currentComponent="talendLogs_LOGS";

	

 



/**
 * [talendLogs_LOGS finally ] stop
 */

	
	/**
	 * [talendLogs_CONSOLE finally ] start
	 */

	

	
	
		currentVirtualComponent = "talendLogs_CONSOLE";
	
	currentComponent="talendLogs_CONSOLE";

	

 



/**
 * [talendLogs_CONSOLE finally ] stop
 */



				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("talendLogs_LOGS_SUBPROCESS_STATE", 1);
	}
	


public static class row_talendStats_STATSStruct implements routines.system.IPersistableRow<row_talendStats_STATSStruct> {
    final static byte[] commonByteArrayLock_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Prod2Dev_with_GP_FDIST_child = new byte[0];
    static byte[] commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Prod2Dev_with_GP_FDIST_child = new byte[0];

	
			    public java.util.Date moment;

				public java.util.Date getMoment () {
					return this.moment;
				}
				
			    public String pid;

				public String getPid () {
					return this.pid;
				}
				
			    public String father_pid;

				public String getFather_pid () {
					return this.father_pid;
				}
				
			    public String root_pid;

				public String getRoot_pid () {
					return this.root_pid;
				}
				
			    public Long system_pid;

				public Long getSystem_pid () {
					return this.system_pid;
				}
				
			    public String project;

				public String getProject () {
					return this.project;
				}
				
			    public String job;

				public String getJob () {
					return this.job;
				}
				
			    public String job_repository_id;

				public String getJob_repository_id () {
					return this.job_repository_id;
				}
				
			    public String job_version;

				public String getJob_version () {
					return this.job_version;
				}
				
			    public String context;

				public String getContext () {
					return this.context;
				}
				
			    public String origin;

				public String getOrigin () {
					return this.origin;
				}
				
			    public String message_type;

				public String getMessage_type () {
					return this.message_type;
				}
				
			    public String message;

				public String getMessage () {
					return this.message;
				}
				
			    public Long duration;

				public Long getDuration () {
					return this.duration;
				}
				



	private java.util.Date readDate(ObjectInputStream dis) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(dis.readLong());
		}
		return dateReturn;
	}

    private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException{
		if(date1 == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeLong(date1.getTime());
    	}
    }

	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Prod2Dev_with_GP_FDIST_child.length) {
				if(length < 1024 && commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Prod2Dev_with_GP_FDIST_child.length == 0) {
   					commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Prod2Dev_with_GP_FDIST_child = new byte[1024];
				} else {
   					commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Prod2Dev_with_GP_FDIST_child = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Prod2Dev_with_GP_FDIST_child, 0, length);
			strReturn = new String(commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Prod2Dev_with_GP_FDIST_child, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Prod2Dev_with_GP_FDIST_child) {

        	try {

        		int length = 0;
		
					this.moment = readDate(dis);
					
					this.pid = readString(dis);
					
					this.father_pid = readString(dis);
					
					this.root_pid = readString(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.system_pid = null;
           				} else {
           			    	this.system_pid = dis.readLong();
           				}
					
					this.project = readString(dis);
					
					this.job = readString(dis);
					
					this.job_repository_id = readString(dis);
					
					this.job_version = readString(dis);
					
					this.context = readString(dis);
					
					this.origin = readString(dis);
					
					this.message_type = readString(dis);
					
					this.message = readString(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.duration = null;
           				} else {
           			    	this.duration = dis.readLong();
           				}
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// java.util.Date
				
						writeDate(this.moment,dos);
					
					// String
				
						writeString(this.pid,dos);
					
					// String
				
						writeString(this.father_pid,dos);
					
					// String
				
						writeString(this.root_pid,dos);
					
					// Long
				
						if(this.system_pid == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeLong(this.system_pid);
		            	}
					
					// String
				
						writeString(this.project,dos);
					
					// String
				
						writeString(this.job,dos);
					
					// String
				
						writeString(this.job_repository_id,dos);
					
					// String
				
						writeString(this.job_version,dos);
					
					// String
				
						writeString(this.context,dos);
					
					// String
				
						writeString(this.origin,dos);
					
					// String
				
						writeString(this.message_type,dos);
					
					// String
				
						writeString(this.message,dos);
					
					// Long
				
						if(this.duration == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeLong(this.duration);
		            	}
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("moment="+String.valueOf(moment));
		sb.append(",pid="+pid);
		sb.append(",father_pid="+father_pid);
		sb.append(",root_pid="+root_pid);
		sb.append(",system_pid="+String.valueOf(system_pid));
		sb.append(",project="+project);
		sb.append(",job="+job);
		sb.append(",job_repository_id="+job_repository_id);
		sb.append(",job_version="+job_version);
		sb.append(",context="+context);
		sb.append(",origin="+origin);
		sb.append(",message_type="+message_type);
		sb.append(",message="+message);
		sb.append(",duration="+String.valueOf(duration));
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				if(moment == null){
        					sb.append("<null>");
        				}else{
            				sb.append(moment);
            			}
            		
        			sb.append("|");
        		
        				if(pid == null){
        					sb.append("<null>");
        				}else{
            				sb.append(pid);
            			}
            		
        			sb.append("|");
        		
        				if(father_pid == null){
        					sb.append("<null>");
        				}else{
            				sb.append(father_pid);
            			}
            		
        			sb.append("|");
        		
        				if(root_pid == null){
        					sb.append("<null>");
        				}else{
            				sb.append(root_pid);
            			}
            		
        			sb.append("|");
        		
        				if(system_pid == null){
        					sb.append("<null>");
        				}else{
            				sb.append(system_pid);
            			}
            		
        			sb.append("|");
        		
        				if(project == null){
        					sb.append("<null>");
        				}else{
            				sb.append(project);
            			}
            		
        			sb.append("|");
        		
        				if(job == null){
        					sb.append("<null>");
        				}else{
            				sb.append(job);
            			}
            		
        			sb.append("|");
        		
        				if(job_repository_id == null){
        					sb.append("<null>");
        				}else{
            				sb.append(job_repository_id);
            			}
            		
        			sb.append("|");
        		
        				if(job_version == null){
        					sb.append("<null>");
        				}else{
            				sb.append(job_version);
            			}
            		
        			sb.append("|");
        		
        				if(context == null){
        					sb.append("<null>");
        				}else{
            				sb.append(context);
            			}
            		
        			sb.append("|");
        		
        				if(origin == null){
        					sb.append("<null>");
        				}else{
            				sb.append(origin);
            			}
            		
        			sb.append("|");
        		
        				if(message_type == null){
        					sb.append("<null>");
        				}else{
            				sb.append(message_type);
            			}
            		
        			sb.append("|");
        		
        				if(message == null){
        					sb.append("<null>");
        				}else{
            				sb.append(message);
            			}
            		
        			sb.append("|");
        		
        				if(duration == null){
        					sb.append("<null>");
        				}else{
            				sb.append(duration);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(row_talendStats_STATSStruct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}
public void talendStats_STATSProcess(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("talendStats_STATS_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
		String currentVirtualComponent = null;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;



		row_talendStats_STATSStruct row_talendStats_STATS = new row_talendStats_STATSStruct();




	
	/**
	 * [talendStats_CONSOLE begin ] start
	 */

	

	
		
		ok_Hash.put("talendStats_CONSOLE", false);
		start_Hash.put("talendStats_CONSOLE", System.currentTimeMillis());
		
	
		currentVirtualComponent = "talendStats_CONSOLE";
	
	currentComponent="talendStats_CONSOLE";

	
			if (execStat) {
				if(resourceMap.get("inIterateVComp") == null){
					
						runStat.updateStatOnConnection("Main" + iterateId, 0, 0);
					
				}
			} 

		
		int tos_count_talendStats_CONSOLE = 0;
		
                if(log.isDebugEnabled())
            log.debug("talendStats_CONSOLE - "  + ("Start to work.") );
    	class BytesLimit65535_talendStats_CONSOLE{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_talendStats_CONSOLE = new StringBuilder();
            log4jParamters_talendStats_CONSOLE.append("Parameters:");
                    log4jParamters_talendStats_CONSOLE.append("BASIC_MODE" + " = " + "true");
                log4jParamters_talendStats_CONSOLE.append(" | ");
                    log4jParamters_talendStats_CONSOLE.append("TABLE_PRINT" + " = " + "false");
                log4jParamters_talendStats_CONSOLE.append(" | ");
                    log4jParamters_talendStats_CONSOLE.append("VERTICAL" + " = " + "false");
                log4jParamters_talendStats_CONSOLE.append(" | ");
                    log4jParamters_talendStats_CONSOLE.append("FIELDSEPARATOR" + " = " + "\"|\"");
                log4jParamters_talendStats_CONSOLE.append(" | ");
                    log4jParamters_talendStats_CONSOLE.append("PRINT_HEADER" + " = " + "false");
                log4jParamters_talendStats_CONSOLE.append(" | ");
                    log4jParamters_talendStats_CONSOLE.append("PRINT_UNIQUE_NAME" + " = " + "false");
                log4jParamters_talendStats_CONSOLE.append(" | ");
                    log4jParamters_talendStats_CONSOLE.append("PRINT_COLNAMES" + " = " + "false");
                log4jParamters_talendStats_CONSOLE.append(" | ");
                    log4jParamters_talendStats_CONSOLE.append("USE_FIXED_LENGTH" + " = " + "false");
                log4jParamters_talendStats_CONSOLE.append(" | ");
                    log4jParamters_talendStats_CONSOLE.append("PRINT_CONTENT_WITH_LOG4J" + " = " + "true");
                log4jParamters_talendStats_CONSOLE.append(" | ");
                if(log.isDebugEnabled())
            log.debug("talendStats_CONSOLE - "  + (log4jParamters_talendStats_CONSOLE) );
    		}
    	}
    	
        new BytesLimit65535_talendStats_CONSOLE().limitLog4jByte();

	///////////////////////
	
		final String OUTPUT_FIELD_SEPARATOR_talendStats_CONSOLE = "|";
		java.io.PrintStream consoleOut_talendStats_CONSOLE = null;	

 		StringBuilder strBuffer_talendStats_CONSOLE = null;
		int nb_line_talendStats_CONSOLE = 0;
///////////////////////    			



 



/**
 * [talendStats_CONSOLE begin ] stop
 */



	
	/**
	 * [talendStats_STATS begin ] start
	 */

	

	
		
		ok_Hash.put("talendStats_STATS", false);
		start_Hash.put("talendStats_STATS", System.currentTimeMillis());
		
	
		currentVirtualComponent = "talendStats_STATS";
	
	currentComponent="talendStats_STATS";

	
		int tos_count_talendStats_STATS = 0;
		
                if(log.isDebugEnabled())
            log.debug("talendStats_STATS - "  + ("Start to work.") );
    	class BytesLimit65535_talendStats_STATS{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_talendStats_STATS = new StringBuilder();
            log4jParamters_talendStats_STATS.append("Parameters:");
                if(log.isDebugEnabled())
            log.debug("talendStats_STATS - "  + (log4jParamters_talendStats_STATS) );
    		}
    	}
    	
        new BytesLimit65535_talendStats_STATS().limitLog4jByte();

	for (StatCatcherUtils.StatCatcherMessage scm : talendStats_STATS.getMessages()) {
		row_talendStats_STATS.pid = pid;
		row_talendStats_STATS.root_pid = rootPid;
		row_talendStats_STATS.father_pid = fatherPid;	
    	row_talendStats_STATS.project = projectName;
    	row_talendStats_STATS.job = jobName;
    	row_talendStats_STATS.context = contextStr;
		row_talendStats_STATS.origin = (scm.getOrigin()==null || scm.getOrigin().length()<1 ? null : scm.getOrigin());
		row_talendStats_STATS.message = scm.getMessage();
		row_talendStats_STATS.duration = scm.getDuration();
		row_talendStats_STATS.moment = scm.getMoment();
		row_talendStats_STATS.message_type = scm.getMessageType();
		row_talendStats_STATS.job_version = scm.getJobVersion();
		row_talendStats_STATS.job_repository_id = scm.getJobId();
		row_talendStats_STATS.system_pid = scm.getSystemPid();

 



/**
 * [talendStats_STATS begin ] stop
 */
	
	/**
	 * [talendStats_STATS main ] start
	 */

	

	
	
		currentVirtualComponent = "talendStats_STATS";
	
	currentComponent="talendStats_STATS";

	

 


	tos_count_talendStats_STATS++;

/**
 * [talendStats_STATS main ] stop
 */

	
	/**
	 * [talendStats_CONSOLE main ] start
	 */

	

	
	
		currentVirtualComponent = "talendStats_CONSOLE";
	
	currentComponent="talendStats_CONSOLE";

	

			//Main
			//row_talendStats_STATS


			
				if(execStat){
					runStat.updateStatOnConnection("Main"+iterateId,1, 1);
				} 
			

		
///////////////////////		
						



				strBuffer_talendStats_CONSOLE = new StringBuilder();




   				
	    		if(row_talendStats_STATS.moment != null) { //              
                    							
       
				strBuffer_talendStats_CONSOLE.append(
								FormatterUtils.format_Date(row_talendStats_STATS.moment, "yyyy-MM-dd HH:mm:ss")				
				);


							
	    		} //  			

    			strBuffer_talendStats_CONSOLE.append("|");
    			


   				
	    		if(row_talendStats_STATS.pid != null) { //              
                    							
       
				strBuffer_talendStats_CONSOLE.append(
				                String.valueOf(row_talendStats_STATS.pid)							
				);


							
	    		} //  			

    			strBuffer_talendStats_CONSOLE.append("|");
    			


   				
	    		if(row_talendStats_STATS.father_pid != null) { //              
                    							
       
				strBuffer_talendStats_CONSOLE.append(
				                String.valueOf(row_talendStats_STATS.father_pid)							
				);


							
	    		} //  			

    			strBuffer_talendStats_CONSOLE.append("|");
    			


   				
	    		if(row_talendStats_STATS.root_pid != null) { //              
                    							
       
				strBuffer_talendStats_CONSOLE.append(
				                String.valueOf(row_talendStats_STATS.root_pid)							
				);


							
	    		} //  			

    			strBuffer_talendStats_CONSOLE.append("|");
    			


   				
	    		if(row_talendStats_STATS.system_pid != null) { //              
                    							
       
				strBuffer_talendStats_CONSOLE.append(
				                String.valueOf(row_talendStats_STATS.system_pid)							
				);


							
	    		} //  			

    			strBuffer_talendStats_CONSOLE.append("|");
    			


   				
	    		if(row_talendStats_STATS.project != null) { //              
                    							
       
				strBuffer_talendStats_CONSOLE.append(
				                String.valueOf(row_talendStats_STATS.project)							
				);


							
	    		} //  			

    			strBuffer_talendStats_CONSOLE.append("|");
    			


   				
	    		if(row_talendStats_STATS.job != null) { //              
                    							
       
				strBuffer_talendStats_CONSOLE.append(
				                String.valueOf(row_talendStats_STATS.job)							
				);


							
	    		} //  			

    			strBuffer_talendStats_CONSOLE.append("|");
    			


   				
	    		if(row_talendStats_STATS.job_repository_id != null) { //              
                    							
       
				strBuffer_talendStats_CONSOLE.append(
				                String.valueOf(row_talendStats_STATS.job_repository_id)							
				);


							
	    		} //  			

    			strBuffer_talendStats_CONSOLE.append("|");
    			


   				
	    		if(row_talendStats_STATS.job_version != null) { //              
                    							
       
				strBuffer_talendStats_CONSOLE.append(
				                String.valueOf(row_talendStats_STATS.job_version)							
				);


							
	    		} //  			

    			strBuffer_talendStats_CONSOLE.append("|");
    			


   				
	    		if(row_talendStats_STATS.context != null) { //              
                    							
       
				strBuffer_talendStats_CONSOLE.append(
				                String.valueOf(row_talendStats_STATS.context)							
				);


							
	    		} //  			

    			strBuffer_talendStats_CONSOLE.append("|");
    			


   				
	    		if(row_talendStats_STATS.origin != null) { //              
                    							
       
				strBuffer_talendStats_CONSOLE.append(
				                String.valueOf(row_talendStats_STATS.origin)							
				);


							
	    		} //  			

    			strBuffer_talendStats_CONSOLE.append("|");
    			


   				
	    		if(row_talendStats_STATS.message_type != null) { //              
                    							
       
				strBuffer_talendStats_CONSOLE.append(
				                String.valueOf(row_talendStats_STATS.message_type)							
				);


							
	    		} //  			

    			strBuffer_talendStats_CONSOLE.append("|");
    			


   				
	    		if(row_talendStats_STATS.message != null) { //              
                    							
       
				strBuffer_talendStats_CONSOLE.append(
				                String.valueOf(row_talendStats_STATS.message)							
				);


							
	    		} //  			

    			strBuffer_talendStats_CONSOLE.append("|");
    			


   				
	    		if(row_talendStats_STATS.duration != null) { //              
                    							
       
				strBuffer_talendStats_CONSOLE.append(
				                String.valueOf(row_talendStats_STATS.duration)							
				);


							
	    		} //  			
 

                    if (globalMap.get("tLogRow_CONSOLE")!=null)
                    {
                    	consoleOut_talendStats_CONSOLE = (java.io.PrintStream) globalMap.get("tLogRow_CONSOLE");
                    }
                    else
                    {
                    	consoleOut_talendStats_CONSOLE = new java.io.PrintStream(new java.io.BufferedOutputStream(System.out));
                    	globalMap.put("tLogRow_CONSOLE",consoleOut_talendStats_CONSOLE);
                    }
                    	log.info("talendStats_CONSOLE - Content of row "+(nb_line_talendStats_CONSOLE+1)+": " + strBuffer_talendStats_CONSOLE.toString());
                    consoleOut_talendStats_CONSOLE.println(strBuffer_talendStats_CONSOLE.toString());
                    consoleOut_talendStats_CONSOLE.flush();
                    nb_line_talendStats_CONSOLE++;
//////

//////                    
                    
///////////////////////    			

 


	tos_count_talendStats_CONSOLE++;

/**
 * [talendStats_CONSOLE main ] stop
 */



	
	/**
	 * [talendStats_STATS end ] start
	 */

	

	
	
		currentVirtualComponent = "talendStats_STATS";
	
	currentComponent="talendStats_STATS";

	

	}


 
                if(log.isDebugEnabled())
            log.debug("talendStats_STATS - "  + ("Done.") );

ok_Hash.put("talendStats_STATS", true);
end_Hash.put("talendStats_STATS", System.currentTimeMillis());




/**
 * [talendStats_STATS end ] stop
 */

	
	/**
	 * [talendStats_CONSOLE end ] start
	 */

	

	
	
		currentVirtualComponent = "talendStats_CONSOLE";
	
	currentComponent="talendStats_CONSOLE";

	


//////
//////
globalMap.put("talendStats_CONSOLE_NB_LINE",nb_line_talendStats_CONSOLE);
                if(log.isInfoEnabled())
            log.info("talendStats_CONSOLE - "  + ("Printed row count: ")  + (nb_line_talendStats_CONSOLE)  + (".") );

///////////////////////    			

			if(execStat){
				if(resourceMap.get("inIterateVComp") == null || !((Boolean)resourceMap.get("inIterateVComp"))){
			 		runStat.updateStatOnConnection("Main"+iterateId,2, 0); 
			 	}
			}
		
 
                if(log.isDebugEnabled())
            log.debug("talendStats_CONSOLE - "  + ("Done.") );

ok_Hash.put("talendStats_CONSOLE", true);
end_Hash.put("talendStats_CONSOLE", System.currentTimeMillis());




/**
 * [talendStats_CONSOLE end ] stop
 */



				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage());
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
					te.setVirtualComponentName(currentVirtualComponent);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [talendStats_STATS finally ] start
	 */

	

	
	
		currentVirtualComponent = "talendStats_STATS";
	
	currentComponent="talendStats_STATS";

	

 



/**
 * [talendStats_STATS finally ] stop
 */

	
	/**
	 * [talendStats_CONSOLE finally ] start
	 */

	

	
	
		currentVirtualComponent = "talendStats_CONSOLE";
	
	currentComponent="talendStats_CONSOLE";

	

 



/**
 * [talendStats_CONSOLE finally ] stop
 */



				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("talendStats_STATS_SUBPROCESS_STATE", 1);
	}
	


public static class row_talendMeter_METTERStruct implements routines.system.IPersistableRow<row_talendMeter_METTERStruct> {
    final static byte[] commonByteArrayLock_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Prod2Dev_with_GP_FDIST_child = new byte[0];
    static byte[] commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Prod2Dev_with_GP_FDIST_child = new byte[0];

	
			    public java.util.Date moment;

				public java.util.Date getMoment () {
					return this.moment;
				}
				
			    public String pid;

				public String getPid () {
					return this.pid;
				}
				
			    public String father_pid;

				public String getFather_pid () {
					return this.father_pid;
				}
				
			    public String root_pid;

				public String getRoot_pid () {
					return this.root_pid;
				}
				
			    public Long system_pid;

				public Long getSystem_pid () {
					return this.system_pid;
				}
				
			    public String project;

				public String getProject () {
					return this.project;
				}
				
			    public String job;

				public String getJob () {
					return this.job;
				}
				
			    public String job_repository_id;

				public String getJob_repository_id () {
					return this.job_repository_id;
				}
				
			    public String job_version;

				public String getJob_version () {
					return this.job_version;
				}
				
			    public String context;

				public String getContext () {
					return this.context;
				}
				
			    public String origin;

				public String getOrigin () {
					return this.origin;
				}
				
			    public String label;

				public String getLabel () {
					return this.label;
				}
				
			    public Integer count;

				public Integer getCount () {
					return this.count;
				}
				
			    public Integer reference;

				public Integer getReference () {
					return this.reference;
				}
				
			    public String thresholds;

				public String getThresholds () {
					return this.thresholds;
				}
				



	private java.util.Date readDate(ObjectInputStream dis) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(dis.readLong());
		}
		return dateReturn;
	}

    private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException{
		if(date1 == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeLong(date1.getTime());
    	}
    }

	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Prod2Dev_with_GP_FDIST_child.length) {
				if(length < 1024 && commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Prod2Dev_with_GP_FDIST_child.length == 0) {
   					commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Prod2Dev_with_GP_FDIST_child = new byte[1024];
				} else {
   					commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Prod2Dev_with_GP_FDIST_child = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Prod2Dev_with_GP_FDIST_child, 0, length);
			strReturn = new String(commonByteArray_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Prod2Dev_with_GP_FDIST_child, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
	private Integer readInteger(ObjectInputStream dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}

	private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException{
		if(intNum == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeInt(intNum);
    	}
	}

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_AWS_DEV_TALEND_INGESTION_FRAMEWORK_EDL_Prod2Dev_with_GP_FDIST_child) {

        	try {

        		int length = 0;
		
					this.moment = readDate(dis);
					
					this.pid = readString(dis);
					
					this.father_pid = readString(dis);
					
					this.root_pid = readString(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.system_pid = null;
           				} else {
           			    	this.system_pid = dis.readLong();
           				}
					
					this.project = readString(dis);
					
					this.job = readString(dis);
					
					this.job_repository_id = readString(dis);
					
					this.job_version = readString(dis);
					
					this.context = readString(dis);
					
					this.origin = readString(dis);
					
					this.label = readString(dis);
					
						this.count = readInteger(dis);
					
						this.reference = readInteger(dis);
					
					this.thresholds = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// java.util.Date
				
						writeDate(this.moment,dos);
					
					// String
				
						writeString(this.pid,dos);
					
					// String
				
						writeString(this.father_pid,dos);
					
					// String
				
						writeString(this.root_pid,dos);
					
					// Long
				
						if(this.system_pid == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeLong(this.system_pid);
		            	}
					
					// String
				
						writeString(this.project,dos);
					
					// String
				
						writeString(this.job,dos);
					
					// String
				
						writeString(this.job_repository_id,dos);
					
					// String
				
						writeString(this.job_version,dos);
					
					// String
				
						writeString(this.context,dos);
					
					// String
				
						writeString(this.origin,dos);
					
					// String
				
						writeString(this.label,dos);
					
					// Integer
				
						writeInteger(this.count,dos);
					
					// Integer
				
						writeInteger(this.reference,dos);
					
					// String
				
						writeString(this.thresholds,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("moment="+String.valueOf(moment));
		sb.append(",pid="+pid);
		sb.append(",father_pid="+father_pid);
		sb.append(",root_pid="+root_pid);
		sb.append(",system_pid="+String.valueOf(system_pid));
		sb.append(",project="+project);
		sb.append(",job="+job);
		sb.append(",job_repository_id="+job_repository_id);
		sb.append(",job_version="+job_version);
		sb.append(",context="+context);
		sb.append(",origin="+origin);
		sb.append(",label="+label);
		sb.append(",count="+String.valueOf(count));
		sb.append(",reference="+String.valueOf(reference));
		sb.append(",thresholds="+thresholds);
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				if(moment == null){
        					sb.append("<null>");
        				}else{
            				sb.append(moment);
            			}
            		
        			sb.append("|");
        		
        				if(pid == null){
        					sb.append("<null>");
        				}else{
            				sb.append(pid);
            			}
            		
        			sb.append("|");
        		
        				if(father_pid == null){
        					sb.append("<null>");
        				}else{
            				sb.append(father_pid);
            			}
            		
        			sb.append("|");
        		
        				if(root_pid == null){
        					sb.append("<null>");
        				}else{
            				sb.append(root_pid);
            			}
            		
        			sb.append("|");
        		
        				if(system_pid == null){
        					sb.append("<null>");
        				}else{
            				sb.append(system_pid);
            			}
            		
        			sb.append("|");
        		
        				if(project == null){
        					sb.append("<null>");
        				}else{
            				sb.append(project);
            			}
            		
        			sb.append("|");
        		
        				if(job == null){
        					sb.append("<null>");
        				}else{
            				sb.append(job);
            			}
            		
        			sb.append("|");
        		
        				if(job_repository_id == null){
        					sb.append("<null>");
        				}else{
            				sb.append(job_repository_id);
            			}
            		
        			sb.append("|");
        		
        				if(job_version == null){
        					sb.append("<null>");
        				}else{
            				sb.append(job_version);
            			}
            		
        			sb.append("|");
        		
        				if(context == null){
        					sb.append("<null>");
        				}else{
            				sb.append(context);
            			}
            		
        			sb.append("|");
        		
        				if(origin == null){
        					sb.append("<null>");
        				}else{
            				sb.append(origin);
            			}
            		
        			sb.append("|");
        		
        				if(label == null){
        					sb.append("<null>");
        				}else{
            				sb.append(label);
            			}
            		
        			sb.append("|");
        		
        				if(count == null){
        					sb.append("<null>");
        				}else{
            				sb.append(count);
            			}
            		
        			sb.append("|");
        		
        				if(reference == null){
        					sb.append("<null>");
        				}else{
            				sb.append(reference);
            			}
            		
        			sb.append("|");
        		
        				if(thresholds == null){
        					sb.append("<null>");
        				}else{
            				sb.append(thresholds);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(row_talendMeter_METTERStruct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}
public void talendMeter_METTERProcess(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("talendMeter_METTER_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
		String currentVirtualComponent = null;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;



		row_talendMeter_METTERStruct row_talendMeter_METTER = new row_talendMeter_METTERStruct();




	
	/**
	 * [talendMeter_CONSOLE begin ] start
	 */

	

	
		
		ok_Hash.put("talendMeter_CONSOLE", false);
		start_Hash.put("talendMeter_CONSOLE", System.currentTimeMillis());
		
	
		currentVirtualComponent = "talendMeter_CONSOLE";
	
	currentComponent="talendMeter_CONSOLE";

	
			if (execStat) {
				if(resourceMap.get("inIterateVComp") == null){
					
						runStat.updateStatOnConnection("Main" + iterateId, 0, 0);
					
				}
			} 

		
		int tos_count_talendMeter_CONSOLE = 0;
		
                if(log.isDebugEnabled())
            log.debug("talendMeter_CONSOLE - "  + ("Start to work.") );
    	class BytesLimit65535_talendMeter_CONSOLE{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_talendMeter_CONSOLE = new StringBuilder();
            log4jParamters_talendMeter_CONSOLE.append("Parameters:");
                    log4jParamters_talendMeter_CONSOLE.append("BASIC_MODE" + " = " + "true");
                log4jParamters_talendMeter_CONSOLE.append(" | ");
                    log4jParamters_talendMeter_CONSOLE.append("TABLE_PRINT" + " = " + "false");
                log4jParamters_talendMeter_CONSOLE.append(" | ");
                    log4jParamters_talendMeter_CONSOLE.append("VERTICAL" + " = " + "false");
                log4jParamters_talendMeter_CONSOLE.append(" | ");
                    log4jParamters_talendMeter_CONSOLE.append("FIELDSEPARATOR" + " = " + "\"|\"");
                log4jParamters_talendMeter_CONSOLE.append(" | ");
                    log4jParamters_talendMeter_CONSOLE.append("PRINT_HEADER" + " = " + "false");
                log4jParamters_talendMeter_CONSOLE.append(" | ");
                    log4jParamters_talendMeter_CONSOLE.append("PRINT_UNIQUE_NAME" + " = " + "false");
                log4jParamters_talendMeter_CONSOLE.append(" | ");
                    log4jParamters_talendMeter_CONSOLE.append("PRINT_COLNAMES" + " = " + "false");
                log4jParamters_talendMeter_CONSOLE.append(" | ");
                    log4jParamters_talendMeter_CONSOLE.append("USE_FIXED_LENGTH" + " = " + "false");
                log4jParamters_talendMeter_CONSOLE.append(" | ");
                    log4jParamters_talendMeter_CONSOLE.append("PRINT_CONTENT_WITH_LOG4J" + " = " + "true");
                log4jParamters_talendMeter_CONSOLE.append(" | ");
                if(log.isDebugEnabled())
            log.debug("talendMeter_CONSOLE - "  + (log4jParamters_talendMeter_CONSOLE) );
    		}
    	}
    	
        new BytesLimit65535_talendMeter_CONSOLE().limitLog4jByte();

	///////////////////////
	
		final String OUTPUT_FIELD_SEPARATOR_talendMeter_CONSOLE = "|";
		java.io.PrintStream consoleOut_talendMeter_CONSOLE = null;	

 		StringBuilder strBuffer_talendMeter_CONSOLE = null;
		int nb_line_talendMeter_CONSOLE = 0;
///////////////////////    			



 



/**
 * [talendMeter_CONSOLE begin ] stop
 */



	
	/**
	 * [talendMeter_METTER begin ] start
	 */

	

	
		
		ok_Hash.put("talendMeter_METTER", false);
		start_Hash.put("talendMeter_METTER", System.currentTimeMillis());
		
	
		currentVirtualComponent = "talendMeter_METTER";
	
	currentComponent="talendMeter_METTER";

	
		int tos_count_talendMeter_METTER = 0;
		
                if(log.isDebugEnabled())
            log.debug("talendMeter_METTER - "  + ("Start to work.") );
    	class BytesLimit65535_talendMeter_METTER{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_talendMeter_METTER = new StringBuilder();
            log4jParamters_talendMeter_METTER.append("Parameters:");
                if(log.isDebugEnabled())
            log.debug("talendMeter_METTER - "  + (log4jParamters_talendMeter_METTER) );
    		}
    	}
    	
        new BytesLimit65535_talendMeter_METTER().limitLog4jByte();

	for (MetterCatcherUtils.MetterCatcherMessage mcm : talendMeter_METTER.getMessages()) {
		row_talendMeter_METTER.pid = pid;
		row_talendMeter_METTER.root_pid = rootPid;
		row_talendMeter_METTER.father_pid = fatherPid;	
        row_talendMeter_METTER.project = projectName;
        row_talendMeter_METTER.job = jobName;
        row_talendMeter_METTER.context = contextStr;
		row_talendMeter_METTER.origin = (mcm.getOrigin()==null || mcm.getOrigin().length()<1 ? null : mcm.getOrigin());
		row_talendMeter_METTER.moment = mcm.getMoment();
		row_talendMeter_METTER.job_version = mcm.getJobVersion();
		row_talendMeter_METTER.job_repository_id = mcm.getJobId();
		row_talendMeter_METTER.system_pid = mcm.getSystemPid();
		row_talendMeter_METTER.label = mcm.getLabel();
		row_talendMeter_METTER.count = mcm.getCount();
		row_talendMeter_METTER.reference = talendMeter_METTER.getConnLinesCount(mcm.getReferense()+"_count");
		row_talendMeter_METTER.thresholds = mcm.getThresholds();
		

 



/**
 * [talendMeter_METTER begin ] stop
 */
	
	/**
	 * [talendMeter_METTER main ] start
	 */

	

	
	
		currentVirtualComponent = "talendMeter_METTER";
	
	currentComponent="talendMeter_METTER";

	

 


	tos_count_talendMeter_METTER++;

/**
 * [talendMeter_METTER main ] stop
 */

	
	/**
	 * [talendMeter_CONSOLE main ] start
	 */

	

	
	
		currentVirtualComponent = "talendMeter_CONSOLE";
	
	currentComponent="talendMeter_CONSOLE";

	

			//Main
			//row_talendMeter_METTER


			
				if(execStat){
					runStat.updateStatOnConnection("Main"+iterateId,1, 1);
				} 
			

		
///////////////////////		
						



				strBuffer_talendMeter_CONSOLE = new StringBuilder();




   				
	    		if(row_talendMeter_METTER.moment != null) { //              
                    							
       
				strBuffer_talendMeter_CONSOLE.append(
								FormatterUtils.format_Date(row_talendMeter_METTER.moment, "yyyy-MM-dd HH:mm:ss")				
				);


							
	    		} //  			

    			strBuffer_talendMeter_CONSOLE.append("|");
    			


   				
	    		if(row_talendMeter_METTER.pid != null) { //              
                    							
       
				strBuffer_talendMeter_CONSOLE.append(
				                String.valueOf(row_talendMeter_METTER.pid)							
				);


							
	    		} //  			

    			strBuffer_talendMeter_CONSOLE.append("|");
    			


   				
	    		if(row_talendMeter_METTER.father_pid != null) { //              
                    							
       
				strBuffer_talendMeter_CONSOLE.append(
				                String.valueOf(row_talendMeter_METTER.father_pid)							
				);


							
	    		} //  			

    			strBuffer_talendMeter_CONSOLE.append("|");
    			


   				
	    		if(row_talendMeter_METTER.root_pid != null) { //              
                    							
       
				strBuffer_talendMeter_CONSOLE.append(
				                String.valueOf(row_talendMeter_METTER.root_pid)							
				);


							
	    		} //  			

    			strBuffer_talendMeter_CONSOLE.append("|");
    			


   				
	    		if(row_talendMeter_METTER.system_pid != null) { //              
                    							
       
				strBuffer_talendMeter_CONSOLE.append(
				                String.valueOf(row_talendMeter_METTER.system_pid)							
				);


							
	    		} //  			

    			strBuffer_talendMeter_CONSOLE.append("|");
    			


   				
	    		if(row_talendMeter_METTER.project != null) { //              
                    							
       
				strBuffer_talendMeter_CONSOLE.append(
				                String.valueOf(row_talendMeter_METTER.project)							
				);


							
	    		} //  			

    			strBuffer_talendMeter_CONSOLE.append("|");
    			


   				
	    		if(row_talendMeter_METTER.job != null) { //              
                    							
       
				strBuffer_talendMeter_CONSOLE.append(
				                String.valueOf(row_talendMeter_METTER.job)							
				);


							
	    		} //  			

    			strBuffer_talendMeter_CONSOLE.append("|");
    			


   				
	    		if(row_talendMeter_METTER.job_repository_id != null) { //              
                    							
       
				strBuffer_talendMeter_CONSOLE.append(
				                String.valueOf(row_talendMeter_METTER.job_repository_id)							
				);


							
	    		} //  			

    			strBuffer_talendMeter_CONSOLE.append("|");
    			


   				
	    		if(row_talendMeter_METTER.job_version != null) { //              
                    							
       
				strBuffer_talendMeter_CONSOLE.append(
				                String.valueOf(row_talendMeter_METTER.job_version)							
				);


							
	    		} //  			

    			strBuffer_talendMeter_CONSOLE.append("|");
    			


   				
	    		if(row_talendMeter_METTER.context != null) { //              
                    							
       
				strBuffer_talendMeter_CONSOLE.append(
				                String.valueOf(row_talendMeter_METTER.context)							
				);


							
	    		} //  			

    			strBuffer_talendMeter_CONSOLE.append("|");
    			


   				
	    		if(row_talendMeter_METTER.origin != null) { //              
                    							
       
				strBuffer_talendMeter_CONSOLE.append(
				                String.valueOf(row_talendMeter_METTER.origin)							
				);


							
	    		} //  			

    			strBuffer_talendMeter_CONSOLE.append("|");
    			


   				
	    		if(row_talendMeter_METTER.label != null) { //              
                    							
       
				strBuffer_talendMeter_CONSOLE.append(
				                String.valueOf(row_talendMeter_METTER.label)							
				);


							
	    		} //  			

    			strBuffer_talendMeter_CONSOLE.append("|");
    			


   				
	    		if(row_talendMeter_METTER.count != null) { //              
                    							
       
				strBuffer_talendMeter_CONSOLE.append(
				                String.valueOf(row_talendMeter_METTER.count)							
				);


							
	    		} //  			

    			strBuffer_talendMeter_CONSOLE.append("|");
    			


   				
	    		if(row_talendMeter_METTER.reference != null) { //              
                    							
       
				strBuffer_talendMeter_CONSOLE.append(
				                String.valueOf(row_talendMeter_METTER.reference)							
				);


							
	    		} //  			

    			strBuffer_talendMeter_CONSOLE.append("|");
    			


   				
	    		if(row_talendMeter_METTER.thresholds != null) { //              
                    							
       
				strBuffer_talendMeter_CONSOLE.append(
				                String.valueOf(row_talendMeter_METTER.thresholds)							
				);


							
	    		} //  			
 

                    if (globalMap.get("tLogRow_CONSOLE")!=null)
                    {
                    	consoleOut_talendMeter_CONSOLE = (java.io.PrintStream) globalMap.get("tLogRow_CONSOLE");
                    }
                    else
                    {
                    	consoleOut_talendMeter_CONSOLE = new java.io.PrintStream(new java.io.BufferedOutputStream(System.out));
                    	globalMap.put("tLogRow_CONSOLE",consoleOut_talendMeter_CONSOLE);
                    }
                    	log.info("talendMeter_CONSOLE - Content of row "+(nb_line_talendMeter_CONSOLE+1)+": " + strBuffer_talendMeter_CONSOLE.toString());
                    consoleOut_talendMeter_CONSOLE.println(strBuffer_talendMeter_CONSOLE.toString());
                    consoleOut_talendMeter_CONSOLE.flush();
                    nb_line_talendMeter_CONSOLE++;
//////

//////                    
                    
///////////////////////    			

 


	tos_count_talendMeter_CONSOLE++;

/**
 * [talendMeter_CONSOLE main ] stop
 */



	
	/**
	 * [talendMeter_METTER end ] start
	 */

	

	
	
		currentVirtualComponent = "talendMeter_METTER";
	
	currentComponent="talendMeter_METTER";

	

	}


 
                if(log.isDebugEnabled())
            log.debug("talendMeter_METTER - "  + ("Done.") );

ok_Hash.put("talendMeter_METTER", true);
end_Hash.put("talendMeter_METTER", System.currentTimeMillis());




/**
 * [talendMeter_METTER end ] stop
 */

	
	/**
	 * [talendMeter_CONSOLE end ] start
	 */

	

	
	
		currentVirtualComponent = "talendMeter_CONSOLE";
	
	currentComponent="talendMeter_CONSOLE";

	


//////
//////
globalMap.put("talendMeter_CONSOLE_NB_LINE",nb_line_talendMeter_CONSOLE);
                if(log.isInfoEnabled())
            log.info("talendMeter_CONSOLE - "  + ("Printed row count: ")  + (nb_line_talendMeter_CONSOLE)  + (".") );

///////////////////////    			

			if(execStat){
				if(resourceMap.get("inIterateVComp") == null || !((Boolean)resourceMap.get("inIterateVComp"))){
			 		runStat.updateStatOnConnection("Main"+iterateId,2, 0); 
			 	}
			}
		
 
                if(log.isDebugEnabled())
            log.debug("talendMeter_CONSOLE - "  + ("Done.") );

ok_Hash.put("talendMeter_CONSOLE", true);
end_Hash.put("talendMeter_CONSOLE", System.currentTimeMillis());




/**
 * [talendMeter_CONSOLE end ] stop
 */



				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage());
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
					te.setVirtualComponentName(currentVirtualComponent);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [talendMeter_METTER finally ] start
	 */

	

	
	
		currentVirtualComponent = "talendMeter_METTER";
	
	currentComponent="talendMeter_METTER";

	

 



/**
 * [talendMeter_METTER finally ] stop
 */

	
	/**
	 * [talendMeter_CONSOLE finally ] start
	 */

	

	
	
		currentVirtualComponent = "talendMeter_CONSOLE";
	
	currentComponent="talendMeter_CONSOLE";

	

 



/**
 * [talendMeter_CONSOLE finally ] stop
 */



				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("talendMeter_METTER_SUBPROCESS_STATE", 1);
	}
	
    public String resuming_logs_dir_path = null;
    public String resuming_checkpoint_path = null;
    public String parent_part_launcher = null;
    private String resumeEntryMethodName = null;
    private boolean globalResumeTicket = false;

    public boolean watch = false;
    // portStats is null, it means don't execute the statistics
    public Integer portStats = null;
    public int portTraces = 4334;
    public String clientHost;
    public String defaultClientHost = "localhost";
    public String contextStr = "SOURCING_DEV";
    public boolean isDefaultContext = true;
    public String pid = "0";
    public String rootPid = null;
    public String fatherPid = null;
    public String fatherNode = null;
    public long startTime = 0;
    public boolean isChildJob = false;
    public String log4jLevel = "";

    private boolean execStat = true;

    private ThreadLocal<java.util.Map<String, String>> threadLocal = new ThreadLocal<java.util.Map<String, String>>() {
        protected java.util.Map<String, String> initialValue() {
            java.util.Map<String,String> threadRunResultMap = new java.util.HashMap<String, String>();
            threadRunResultMap.put("errorCode", null);
            threadRunResultMap.put("status", "");
            return threadRunResultMap;
        };
    };



    private java.util.Properties context_param = new java.util.Properties();
    public java.util.Map<String, Object> parentContextMap = new java.util.HashMap<String, Object>();

    public String status= "";

    public static void main(String[] args){
        final EDL_Prod2Dev_with_GP_FDIST_child EDL_Prod2Dev_with_GP_FDIST_childClass = new EDL_Prod2Dev_with_GP_FDIST_child();

        int exitCode = EDL_Prod2Dev_with_GP_FDIST_childClass.runJobInTOS(args);
	        if(exitCode==0){
		        log.info("TalendJob: 'EDL_Prod2Dev_with_GP_FDIST_child' - Done.");
	        }

        System.exit(exitCode);
    }


    public String[][] runJob(String[] args) {

        int exitCode = runJobInTOS(args);
        String[][] bufferValue = new String[][] { { Integer.toString(exitCode) } };

        return bufferValue;
    }

    public boolean hastBufferOutputComponent() {
		boolean hastBufferOutput = false;
    	
        return hastBufferOutput;
    }

    public int runJobInTOS(String[] args) {
	   	// reset status
	   	status = "";

        String lastStr = "";
        for (String arg : args) {
            if (arg.equalsIgnoreCase("--context_param")) {
                lastStr = arg;
            } else if (lastStr.equals("")) {
                evalParam(arg);
            } else {
                evalParam(lastStr + " " + arg);
                lastStr = "";
            }
        }

	        if(!"".equals(log4jLevel)){
				if("trace".equalsIgnoreCase(log4jLevel)){
					log.setLevel(org.apache.log4j.Level.TRACE);
				}else if("debug".equalsIgnoreCase(log4jLevel)){
					log.setLevel(org.apache.log4j.Level.DEBUG);
				}else if("info".equalsIgnoreCase(log4jLevel)){
					log.setLevel(org.apache.log4j.Level.INFO);
				}else if("warn".equalsIgnoreCase(log4jLevel)){
					log.setLevel(org.apache.log4j.Level.WARN);
				}else if("error".equalsIgnoreCase(log4jLevel)){
					log.setLevel(org.apache.log4j.Level.ERROR);
				}else if("fatal".equalsIgnoreCase(log4jLevel)){
					log.setLevel(org.apache.log4j.Level.FATAL);
				}else if ("off".equalsIgnoreCase(log4jLevel)){
					log.setLevel(org.apache.log4j.Level.OFF);
				}
				org.apache.log4j.Logger.getRootLogger().setLevel(log.getLevel());
    	    }
        	log.info("TalendJob: 'EDL_Prod2Dev_with_GP_FDIST_child' - Start.");
    	

        if(clientHost == null) {
            clientHost = defaultClientHost;
        }

        if(pid == null || "0".equals(pid)) {
            pid = TalendString.getAsciiRandomString(6);
        }

        if (rootPid==null) {
            rootPid = pid;
        }
        if (fatherPid==null) {
            fatherPid = pid;
        }else{
            isChildJob = true;
        }

        if (portStats != null) {
            // portStats = -1; //for testing
            if (portStats < 0 || portStats > 65535) {
                // issue:10869, the portStats is invalid, so this client socket can't open
                System.err.println("The statistics socket port " + portStats + " is invalid.");
                execStat = false;
            }
        } else {
            execStat = false;
        }

        try {
            //call job/subjob with an existing context, like: --context=production. if without this parameter, there will use the default context instead.
            java.io.InputStream inContext = EDL_Prod2Dev_with_GP_FDIST_child.class.getClassLoader().getResourceAsStream("aws_dev_talend_ingestion_framework/edl_prod2dev_with_gp_fdist_child_0_1/contexts/"+contextStr+".properties");
            if(isDefaultContext && inContext ==null) {

            } else {
                if (inContext!=null) {
                    //defaultProps is in order to keep the original context value
                    defaultProps.load(inContext);
                    inContext.close();
                    context = new ContextProperties(defaultProps);
                }else{
                    //print info and job continue to run, for case: context_param is not empty.
                    System.err.println("Could not find the context " + contextStr);
                }
            }

            if(!context_param.isEmpty()) {
                context.putAll(context_param);
            }
                context.GP_SOURCE_NAME=(String) context.getProperty("GP_SOURCE_NAME");
                context.TABLE_NAME=(String) context.getProperty("TABLE_NAME");
                context.FORCE_DROP=(String) context.getProperty("FORCE_DROP");
                context.LOAD2HDFS=(String) context.getProperty("LOAD2HDFS");
             try{
                 context.RUN_ID=routines.system.ParserUtils.parseTo_Integer (context.getProperty("RUN_ID"));
             }catch(NumberFormatException e){
                 context.RUN_ID=null;
              }
                context.ORIG_DATABASE_NAME=(String) context.getProperty("ORIG_DATABASE_NAME");
                context.SOURCING_Server=(String) context.getProperty("SOURCING_Server");
                context.SOURCING_Login=(String) context.getProperty("SOURCING_Login");
            		String pwd_SOURCING_Password_value = context.getProperty("SOURCING_Password");
            		context.SOURCING_Password = null;
            		if(pwd_SOURCING_Password_value!=null) {
            			if(context_param.containsKey("SOURCING_Password")) {//no need to decrypt if it come from program argument or parent job runtime
            				context.SOURCING_Password = pwd_SOURCING_Password_value;
            			} else if (!pwd_SOURCING_Password_value.isEmpty()) {
            				try {
            					context.SOURCING_Password = routines.system.PasswordEncryptUtil.decryptPassword(pwd_SOURCING_Password_value);
            					context.put("SOURCING_Password",context.SOURCING_Password);
            				} catch (java.lang.RuntimeException e) {
            					//do nothing
            				}
            			}
            		}
                context.SOURCING_Port=(String) context.getProperty("SOURCING_Port");
                context.LOG_Type=(String) context.getProperty("LOG_Type");
                context.SOURCING_Schema=(String) context.getProperty("SOURCING_Schema");
                context.SOURCING_Database=(String) context.getProperty("SOURCING_Database");
                context.FDIST_PARAM=(String) context.getProperty("FDIST_PARAM");
             try{
                 context.LOG_NO_OF_ERRORS=routines.system.ParserUtils.parseTo_Integer (context.getProperty("LOG_NO_OF_ERRORS"));
             }catch(NumberFormatException e){
                 context.LOG_NO_OF_ERRORS=null;
              }
                context.LOG_PLANT_NAME=(String) context.getProperty("LOG_PLANT_NAME");
             try{
                 context.LOG_NO_OF_UPDATES=routines.system.ParserUtils.parseTo_Integer (context.getProperty("LOG_NO_OF_UPDATES"));
             }catch(NumberFormatException e){
                 context.LOG_NO_OF_UPDATES=null;
              }
             try{
                 context.LOG_SOURCE_ROW_COUNT=routines.system.ParserUtils.parseTo_Integer (context.getProperty("LOG_SOURCE_ROW_COUNT"));
             }catch(NumberFormatException e){
                 context.LOG_SOURCE_ROW_COUNT=null;
              }
                context.LOG_TECHNOLOGY=(String) context.getProperty("LOG_TECHNOLOGY");
                context.LOG_TABLE_NAME=(String) context.getProperty("LOG_TABLE_NAME");
             try{
                 context.LOG_NO_OF_INSERTS=routines.system.ParserUtils.parseTo_Integer (context.getProperty("LOG_NO_OF_INSERTS"));
             }catch(NumberFormatException e){
                 context.LOG_NO_OF_INSERTS=null;
              }
                context.LOG_DATA_PATH=(String) context.getProperty("LOG_DATA_PATH");
             try{
                 context.LOG_NO_OF_DELETES=routines.system.ParserUtils.parseTo_Integer (context.getProperty("LOG_NO_OF_DELETES"));
             }catch(NumberFormatException e){
                 context.LOG_NO_OF_DELETES=null;
              }
             try{
                 context.LOG_RUN_ID=routines.system.ParserUtils.parseTo_Integer (context.getProperty("LOG_RUN_ID"));
             }catch(NumberFormatException e){
                 context.LOG_RUN_ID=null;
              }
                context.LOG_ERROR_CATEGORY=(String) context.getProperty("LOG_ERROR_CATEGORY");
                context.LOG_JOB_NAME=(String) context.getProperty("LOG_JOB_NAME");
                context.LOG_SYSTEM_NAME=(String) context.getProperty("LOG_SYSTEM_NAME");
                context.LOG_MESSAGE=(String) context.getProperty("LOG_MESSAGE");
             try{
                 context.LOG_TARGET_ROW_COUNT=routines.system.ParserUtils.parseTo_Integer (context.getProperty("LOG_TARGET_ROW_COUNT"));
             }catch(NumberFormatException e){
                 context.LOG_TARGET_ROW_COUNT=null;
              }
                context.LOG_STATUS=(String) context.getProperty("LOG_STATUS");
                context.ETL_LOCALHOSTNAME=(String) context.getProperty("ETL_LOCALHOSTNAME");
                context.ETL_STORAGE_PATH=(String) context.getProperty("ETL_STORAGE_PATH");
                context.HAWQ_Source_Ports=(String) context.getProperty("HAWQ_Source_Ports");
                context.SOURCE_DATABASE=(String) context.getProperty("SOURCE_DATABASE");
                context.SOURCE_HOST=(String) context.getProperty("SOURCE_HOST");
            		String pwd_SOURCE_PASSWORD_value = context.getProperty("SOURCE_PASSWORD");
            		context.SOURCE_PASSWORD = null;
            		if(pwd_SOURCE_PASSWORD_value!=null) {
            			if(context_param.containsKey("SOURCE_PASSWORD")) {//no need to decrypt if it come from program argument or parent job runtime
            				context.SOURCE_PASSWORD = pwd_SOURCE_PASSWORD_value;
            			} else if (!pwd_SOURCE_PASSWORD_value.isEmpty()) {
            				try {
            					context.SOURCE_PASSWORD = routines.system.PasswordEncryptUtil.decryptPassword(pwd_SOURCE_PASSWORD_value);
            					context.put("SOURCE_PASSWORD",context.SOURCE_PASSWORD);
            				} catch (java.lang.RuntimeException e) {
            					//do nothing
            				}
            			}
            		}
             try{
                 context.SOURCE_PORT=routines.system.ParserUtils.parseTo_Integer (context.getProperty("SOURCE_PORT"));
             }catch(NumberFormatException e){
                 context.SOURCE_PORT=null;
              }
                context.SOURCE_USER=(String) context.getProperty("SOURCE_USER");
        } catch (java.io.IOException ie) {
            System.err.println("Could not load context "+contextStr);
            ie.printStackTrace();
        }


        // get context value from parent directly
        if (parentContextMap != null && !parentContextMap.isEmpty()) {if (parentContextMap.containsKey("GP_SOURCE_NAME")) {
                context.GP_SOURCE_NAME = (String) parentContextMap.get("GP_SOURCE_NAME");
            }if (parentContextMap.containsKey("TABLE_NAME")) {
                context.TABLE_NAME = (String) parentContextMap.get("TABLE_NAME");
            }if (parentContextMap.containsKey("FORCE_DROP")) {
                context.FORCE_DROP = (String) parentContextMap.get("FORCE_DROP");
            }if (parentContextMap.containsKey("LOAD2HDFS")) {
                context.LOAD2HDFS = (String) parentContextMap.get("LOAD2HDFS");
            }if (parentContextMap.containsKey("RUN_ID")) {
                context.RUN_ID = (Integer) parentContextMap.get("RUN_ID");
            }if (parentContextMap.containsKey("ORIG_DATABASE_NAME")) {
                context.ORIG_DATABASE_NAME = (String) parentContextMap.get("ORIG_DATABASE_NAME");
            }if (parentContextMap.containsKey("SOURCING_Server")) {
                context.SOURCING_Server = (String) parentContextMap.get("SOURCING_Server");
            }if (parentContextMap.containsKey("SOURCING_Login")) {
                context.SOURCING_Login = (String) parentContextMap.get("SOURCING_Login");
            }if (parentContextMap.containsKey("SOURCING_Password")) {
                context.SOURCING_Password = (java.lang.String) parentContextMap.get("SOURCING_Password");
            }if (parentContextMap.containsKey("SOURCING_Port")) {
                context.SOURCING_Port = (String) parentContextMap.get("SOURCING_Port");
            }if (parentContextMap.containsKey("LOG_Type")) {
                context.LOG_Type = (String) parentContextMap.get("LOG_Type");
            }if (parentContextMap.containsKey("SOURCING_Schema")) {
                context.SOURCING_Schema = (String) parentContextMap.get("SOURCING_Schema");
            }if (parentContextMap.containsKey("SOURCING_Database")) {
                context.SOURCING_Database = (String) parentContextMap.get("SOURCING_Database");
            }if (parentContextMap.containsKey("FDIST_PARAM")) {
                context.FDIST_PARAM = (String) parentContextMap.get("FDIST_PARAM");
            }if (parentContextMap.containsKey("LOG_NO_OF_ERRORS")) {
                context.LOG_NO_OF_ERRORS = (Integer) parentContextMap.get("LOG_NO_OF_ERRORS");
            }if (parentContextMap.containsKey("LOG_PLANT_NAME")) {
                context.LOG_PLANT_NAME = (String) parentContextMap.get("LOG_PLANT_NAME");
            }if (parentContextMap.containsKey("LOG_NO_OF_UPDATES")) {
                context.LOG_NO_OF_UPDATES = (Integer) parentContextMap.get("LOG_NO_OF_UPDATES");
            }if (parentContextMap.containsKey("LOG_SOURCE_ROW_COUNT")) {
                context.LOG_SOURCE_ROW_COUNT = (Integer) parentContextMap.get("LOG_SOURCE_ROW_COUNT");
            }if (parentContextMap.containsKey("LOG_TECHNOLOGY")) {
                context.LOG_TECHNOLOGY = (String) parentContextMap.get("LOG_TECHNOLOGY");
            }if (parentContextMap.containsKey("LOG_TABLE_NAME")) {
                context.LOG_TABLE_NAME = (String) parentContextMap.get("LOG_TABLE_NAME");
            }if (parentContextMap.containsKey("LOG_NO_OF_INSERTS")) {
                context.LOG_NO_OF_INSERTS = (Integer) parentContextMap.get("LOG_NO_OF_INSERTS");
            }if (parentContextMap.containsKey("LOG_DATA_PATH")) {
                context.LOG_DATA_PATH = (String) parentContextMap.get("LOG_DATA_PATH");
            }if (parentContextMap.containsKey("LOG_NO_OF_DELETES")) {
                context.LOG_NO_OF_DELETES = (Integer) parentContextMap.get("LOG_NO_OF_DELETES");
            }if (parentContextMap.containsKey("LOG_RUN_ID")) {
                context.LOG_RUN_ID = (Integer) parentContextMap.get("LOG_RUN_ID");
            }if (parentContextMap.containsKey("LOG_ERROR_CATEGORY")) {
                context.LOG_ERROR_CATEGORY = (String) parentContextMap.get("LOG_ERROR_CATEGORY");
            }if (parentContextMap.containsKey("LOG_JOB_NAME")) {
                context.LOG_JOB_NAME = (String) parentContextMap.get("LOG_JOB_NAME");
            }if (parentContextMap.containsKey("LOG_SYSTEM_NAME")) {
                context.LOG_SYSTEM_NAME = (String) parentContextMap.get("LOG_SYSTEM_NAME");
            }if (parentContextMap.containsKey("LOG_MESSAGE")) {
                context.LOG_MESSAGE = (String) parentContextMap.get("LOG_MESSAGE");
            }if (parentContextMap.containsKey("LOG_TARGET_ROW_COUNT")) {
                context.LOG_TARGET_ROW_COUNT = (Integer) parentContextMap.get("LOG_TARGET_ROW_COUNT");
            }if (parentContextMap.containsKey("LOG_STATUS")) {
                context.LOG_STATUS = (String) parentContextMap.get("LOG_STATUS");
            }if (parentContextMap.containsKey("ETL_LOCALHOSTNAME")) {
                context.ETL_LOCALHOSTNAME = (String) parentContextMap.get("ETL_LOCALHOSTNAME");
            }if (parentContextMap.containsKey("ETL_STORAGE_PATH")) {
                context.ETL_STORAGE_PATH = (String) parentContextMap.get("ETL_STORAGE_PATH");
            }if (parentContextMap.containsKey("HAWQ_Source_Ports")) {
                context.HAWQ_Source_Ports = (String) parentContextMap.get("HAWQ_Source_Ports");
            }if (parentContextMap.containsKey("SOURCE_DATABASE")) {
                context.SOURCE_DATABASE = (String) parentContextMap.get("SOURCE_DATABASE");
            }if (parentContextMap.containsKey("SOURCE_HOST")) {
                context.SOURCE_HOST = (String) parentContextMap.get("SOURCE_HOST");
            }if (parentContextMap.containsKey("SOURCE_PASSWORD")) {
                context.SOURCE_PASSWORD = (java.lang.String) parentContextMap.get("SOURCE_PASSWORD");
            }if (parentContextMap.containsKey("SOURCE_PORT")) {
                context.SOURCE_PORT = (Integer) parentContextMap.get("SOURCE_PORT");
            }if (parentContextMap.containsKey("SOURCE_USER")) {
                context.SOURCE_USER = (String) parentContextMap.get("SOURCE_USER");
            }
        }

        //Resume: init the resumeUtil
        resumeEntryMethodName = ResumeUtil.getResumeEntryMethodName(resuming_checkpoint_path);
        resumeUtil = new ResumeUtil(resuming_logs_dir_path, isChildJob, rootPid);
        resumeUtil.initCommonInfo(pid, rootPid, fatherPid, projectName, jobName, contextStr, jobVersion);

		List<String> parametersToEncrypt = new java.util.ArrayList<String>();
			parametersToEncrypt.add("SOURCING_Password");
			parametersToEncrypt.add("SOURCE_PASSWORD");
        //Resume: jobStart
        resumeUtil.addLog("JOB_STARTED", "JOB:" + jobName, parent_part_launcher, Thread.currentThread().getId() + "", "","","","",resumeUtil.convertToJsonText(context,parametersToEncrypt));

if(execStat) {
    try {
        runStat.openSocket(!isChildJob);
        runStat.setAllPID(rootPid, fatherPid, pid, jobName);
        runStat.startThreadStat(clientHost, portStats);
        runStat.updateStatOnJob(RunStat.JOBSTART, fatherNode);
    } catch (java.io.IOException ioException) {
        ioException.printStackTrace();
    }
}



	
	    java.util.concurrent.ConcurrentHashMap<Object, Object> concurrentHashMap = new java.util.concurrent.ConcurrentHashMap<Object, Object>();
	    globalMap.put("concurrentHashMap", concurrentHashMap);
	

    long startUsedMemory = Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory();
    long endUsedMemory = 0;
    long end = 0;

    startTime = System.currentTimeMillis();
        talendStats_STATS.addMessage("begin");


this.globalResumeTicket = true;//to run tPreJob



        try {
            talendStats_STATSProcess(globalMap);
        } catch (java.lang.Exception e) {
            e.printStackTrace();
        }

this.globalResumeTicket = false;//to run others jobs

try {
errorCode = null;tSetGlobalVar_7Process(globalMap);
if(!"failure".equals(status)) { status = "end"; }
}catch (TalendException e_tSetGlobalVar_7) {
globalMap.put("tSetGlobalVar_7_SUBPROCESS_STATE", -1);

e_tSetGlobalVar_7.printStackTrace();

}
try {
errorCode = null;tJava_31Process(globalMap);
if(!"failure".equals(status)) { status = "end"; }
}catch (TalendException e_tJava_31) {
globalMap.put("tJava_31_SUBPROCESS_STATE", -1);

e_tJava_31.printStackTrace();

}

this.globalResumeTicket = true;//to run tPostJob




        end = System.currentTimeMillis();

        if (watch) {
            System.out.println((end-startTime)+" milliseconds");
        }

        endUsedMemory = Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory();
        if (false) {
            System.out.println((endUsedMemory - startUsedMemory) + " bytes memory increase when running : EDL_Prod2Dev_with_GP_FDIST_child");
        }
        talendStats_STATS.addMessage(status==""?"end":status, (end-startTime));
        try {
            talendStats_STATSProcess(globalMap);
        } catch (java.lang.Exception e) {
            e.printStackTrace();
        }





if (execStat) {
    runStat.updateStatOnJob(RunStat.JOBEND, fatherNode);
    runStat.stopThreadStat();
}
    int returnCode = 0;
    if(errorCode == null) {
         returnCode = status != null && status.equals("failure") ? 1 : 0;
    } else {
         returnCode = errorCode.intValue();
    }
    resumeUtil.addLog("JOB_ENDED", "JOB:" + jobName, parent_part_launcher, Thread.currentThread().getId() + "", "","" + returnCode,"","","");

    return returnCode;

  }

    // only for OSGi env
    public void destroy() {
    closeSqlDbConnections();


    }



    private void closeSqlDbConnections() {
        try {
            Object obj_conn;
            obj_conn = globalMap.remove("conn_tGreenplumConnection_6");
            if (null != obj_conn) {
                ((java.sql.Connection) obj_conn).close();
            }
            obj_conn = globalMap.remove("conn_tGreenplumConnection_2");
            if (null != obj_conn) {
                ((java.sql.Connection) obj_conn).close();
            }
            obj_conn = globalMap.remove("conn_tGreenplumConnection_11");
            if (null != obj_conn) {
                ((java.sql.Connection) obj_conn).close();
            }
            obj_conn = globalMap.remove("conn_tGreenplumConnection_3");
            if (null != obj_conn) {
                ((java.sql.Connection) obj_conn).close();
            }
            obj_conn = globalMap.remove("conn_tGreenplumConnection_9");
            if (null != obj_conn) {
                ((java.sql.Connection) obj_conn).close();
            }
            obj_conn = globalMap.remove("conn_tGreenplumConnection_1");
            if (null != obj_conn) {
                ((java.sql.Connection) obj_conn).close();
            }
            obj_conn = globalMap.remove("conn_tGreenplumConnection_7");
            if (null != obj_conn) {
                ((java.sql.Connection) obj_conn).close();
            }
            obj_conn = globalMap.remove("conn_tGreenplumConnection_5");
            if (null != obj_conn) {
                ((java.sql.Connection) obj_conn).close();
            }
            obj_conn = globalMap.remove("conn_tGreenplumConnection_8");
            if (null != obj_conn) {
                ((java.sql.Connection) obj_conn).close();
            }
            obj_conn = globalMap.remove("conn_tPostgresqlConnection_1");
            if (null != obj_conn) {
                ((java.sql.Connection) obj_conn).close();
            }
        } catch (java.lang.Exception e) {
        }
    }

		









    private java.util.Map<String, Object> getSharedConnections4REST() {
        java.util.Map<String, Object> connections = new java.util.HashMap<String, Object>();
            connections.put("conn_tGreenplumConnection_6", globalMap.get("conn_tGreenplumConnection_6"));
            connections.put("conn_tGreenplumConnection_2", globalMap.get("conn_tGreenplumConnection_2"));
            connections.put("conn_tGreenplumConnection_11", globalMap.get("conn_tGreenplumConnection_11"));
            connections.put("conn_tGreenplumConnection_3", globalMap.get("conn_tGreenplumConnection_3"));
            connections.put("conn_tGreenplumConnection_9", globalMap.get("conn_tGreenplumConnection_9"));
            connections.put("conn_tGreenplumConnection_1", globalMap.get("conn_tGreenplumConnection_1"));
            connections.put("conn_tGreenplumConnection_7", globalMap.get("conn_tGreenplumConnection_7"));
            connections.put("conn_tGreenplumConnection_5", globalMap.get("conn_tGreenplumConnection_5"));
            connections.put("conn_tGreenplumConnection_8", globalMap.get("conn_tGreenplumConnection_8"));
            connections.put("conn_tPostgresqlConnection_1", globalMap.get("conn_tPostgresqlConnection_1"));






        return connections;
    }

    private void evalParam(String arg) {
        if (arg.startsWith("--resuming_logs_dir_path")) {
            resuming_logs_dir_path = arg.substring(25);
        } else if (arg.startsWith("--resuming_checkpoint_path")) {
            resuming_checkpoint_path = arg.substring(27);
        } else if (arg.startsWith("--parent_part_launcher")) {
            parent_part_launcher = arg.substring(23);
        } else if (arg.startsWith("--watch")) {
            watch = true;
        } else if (arg.startsWith("--stat_port=")) {
            String portStatsStr = arg.substring(12);
            if (portStatsStr != null && !portStatsStr.equals("null")) {
                portStats = Integer.parseInt(portStatsStr);
            }
        } else if (arg.startsWith("--trace_port=")) {
            portTraces = Integer.parseInt(arg.substring(13));
        } else if (arg.startsWith("--client_host=")) {
            clientHost = arg.substring(14);
        } else if (arg.startsWith("--context=")) {
            contextStr = arg.substring(10);
            isDefaultContext = false;
        } else if (arg.startsWith("--father_pid=")) {
            fatherPid = arg.substring(13);
        } else if (arg.startsWith("--root_pid=")) {
            rootPid = arg.substring(11);
        } else if (arg.startsWith("--father_node=")) {
            fatherNode = arg.substring(14);
        } else if (arg.startsWith("--pid=")) {
            pid = arg.substring(6);
        } else if (arg.startsWith("--context_param")) {
            String keyValue = arg.substring(16);
            int index = -1;
            if (keyValue != null && (index = keyValue.indexOf('=')) > -1) {
                if (fatherPid==null) {
                    context_param.put(keyValue.substring(0, index), replaceEscapeChars(keyValue.substring(index + 1)));
                } else { // the subjob won't escape the especial chars
                    context_param.put(keyValue.substring(0, index), keyValue.substring(index + 1) );
                }
            }
        }else if (arg.startsWith("--log4jLevel=")) {
            log4jLevel = arg.substring(13);
		}

    }

    private final String[][] escapeChars = {
        {"\\\\","\\"},{"\\n","\n"},{"\\'","\'"},{"\\r","\r"},
        {"\\f","\f"},{"\\b","\b"},{"\\t","\t"}
        };
    private String replaceEscapeChars (String keyValue) {

		if (keyValue == null || ("").equals(keyValue.trim())) {
			return keyValue;
		}

		StringBuilder result = new StringBuilder();
		int currIndex = 0;
		while (currIndex < keyValue.length()) {
			int index = -1;
			// judege if the left string includes escape chars
			for (String[] strArray : escapeChars) {
				index = keyValue.indexOf(strArray[0],currIndex);
				if (index>=0) {

					result.append(keyValue.substring(currIndex, index + strArray[0].length()).replace(strArray[0], strArray[1]));
					currIndex = index + strArray[0].length();
					break;
				}
			}
			// if the left string doesn't include escape chars, append the left into the result
			if (index < 0) {
				result.append(keyValue.substring(currIndex));
				currIndex = currIndex + keyValue.length();
			}
		}

		return result.toString();
    }

    public Integer getErrorCode() {
        return errorCode;
    }


    public String getStatus() {
        return status;
    }

    ResumeUtil resumeUtil = null;
}
/************************************************************************************************
 *     991845 characters generated by Talend Real-time Big Data Platform 
 *     on the October 19, 2018 3:30:19 PM CDT
 ************************************************************************************************/