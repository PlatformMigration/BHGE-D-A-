#!/bin/sh
cd `dirname $0`
ROOT_PATH=`pwd`
java -Xms256M -Xmx4096M -cp classpath.jar: aws_dev_talend_ingestion_framework.edl_base_dynamic_0_1.EDL_Base_dynamic --context=SOURCING_DEV "$@" 